﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x02000278 RID: 632
internal sealed class #=zksRFBXLEHkxJMoHCStlQj3XmHcVD : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x0600131A RID: 4890 RVA: 0x00094AAC File Offset: 0x00092CAC
	public #=zksRFBXLEHkxJMoHCStlQj3XmHcVD(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
	}

	// Token: 0x0600131B RID: 4891 RVA: 0x00094AB8 File Offset: 0x00092CB8
	public #=zksRFBXLEHkxJMoHCStlQj3XmHcVD() : base(EscherRecordType.SPGR)
	{
		this.Version = 1;
		this.#=zJ5GWysk= = new sbyte[16];
	}

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x0600131C RID: 4892 RVA: 0x00094ADC File Offset: 0x00092CDC
	public override sbyte[] Data
	{
		get
		{
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x04000B10 RID: 2832
	private sbyte[] #=zJ5GWysk=;
}
