﻿using System;
using Skink.SnR.Common.Units;

// Token: 0x02000171 RID: 369
internal sealed class #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh
{
	// Token: 0x060009E0 RID: 2528 RVA: 0x0004FF90 File Offset: 0x0004E190
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060009E1 RID: 2529 RVA: 0x0004FF98 File Offset: 0x0004E198
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009E2 RID: 2530 RVA: 0x0004FFA4 File Offset: 0x0004E1A4
	public UnitType #=zaxbi3A2T8mRD()
	{
		return this.#=zFyeF5iEJIM8rpOUncw==;
	}

	// Token: 0x060009E3 RID: 2531 RVA: 0x0004FFAC File Offset: 0x0004E1AC
	public void #=zogj37CiIebAN(UnitType #=z$Ib9gYQ=)
	{
		this.#=zFyeF5iEJIM8rpOUncw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009E4 RID: 2532 RVA: 0x0004FFB8 File Offset: 0x0004E1B8
	public int #=zlIXJ9$NfUZc_()
	{
		return this.#=zxojFZYWVfXhu329mAA==;
	}

	// Token: 0x060009E5 RID: 2533 RVA: 0x0004FFC0 File Offset: 0x0004E1C0
	public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
	{
		this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009E6 RID: 2534 RVA: 0x0004FFCC File Offset: 0x0004E1CC
	public int #=zisvlKsvs85jd()
	{
		return this.#=zwrxFSXxdh_fTOBnHX1jxmt0=;
	}

	// Token: 0x060009E7 RID: 2535 RVA: 0x0004FFD4 File Offset: 0x0004E1D4
	public void #=z2a_u_nRabC8z(int #=z$Ib9gYQ=)
	{
		this.#=zwrxFSXxdh_fTOBnHX1jxmt0= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009E8 RID: 2536 RVA: 0x0004FFE0 File Offset: 0x0004E1E0
	public int #=zzQest3wYXw6v()
	{
		return this.#=ziFRwcp7KTS$71KFUnw==;
	}

	// Token: 0x060009E9 RID: 2537 RVA: 0x0004FFE8 File Offset: 0x0004E1E8
	public void #=zFVqZEtnUxmwZ(int #=z$Ib9gYQ=)
	{
		this.#=ziFRwcp7KTS$71KFUnw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009EA RID: 2538 RVA: 0x0004FFF4 File Offset: 0x0004E1F4
	public override string ToString()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070731), this.#=zaxbi3A2T8mRD().Name, this.#=zlIXJ9$NfUZc_());
	}

	// Token: 0x040005AC RID: 1452
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040005AD RID: 1453
	private UnitType #=zFyeF5iEJIM8rpOUncw==;

	// Token: 0x040005AE RID: 1454
	private int #=zxojFZYWVfXhu329mAA==;

	// Token: 0x040005AF RID: 1455
	private int #=zwrxFSXxdh_fTOBnHX1jxmt0=;

	// Token: 0x040005B0 RID: 1456
	private int #=ziFRwcp7KTS$71KFUnw==;
}
