﻿using System;
using NExcel.Biff;
using NExcel.Format;

// Token: 0x02000029 RID: 41
internal sealed class #=z01DvYK_f6Qaw5r9wXJ$bXHg= : Format, DisplayFormat
{
	// Token: 0x0600008D RID: 141 RVA: 0x00004A44 File Offset: 0x00002C44
	private #=z01DvYK_f6Qaw5r9wXJ$bXHg=(string #=zWj7xLq8=, int #=zH2f5zJg=)
	{
		this.#=zm78IYG4= = #=zH2f5zJg=;
		this.#=z$A8Wio4= = #=zWj7xLq8=;
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00004A5C File Offset: 0x00002C5C
	static #=z01DvYK_f6Qaw5r9wXJ$bXHg=()
	{
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[0] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(string.Empty, 0);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[1] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596), 1);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[2] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076472), 2);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[3] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076471), 3);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[4] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076451), 4);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[5] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076434), 5);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[6] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076411), 6);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[7] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076411), 7);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[8] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076389), 8);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[9] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076089), 9);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[10] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076086), 10);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[11] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076066), 11);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[12] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076061), 12);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[13] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076041), 13);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[14] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076027), 14);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[15] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076008), 15);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[16] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075995), 16);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[17] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075991), 17);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[18] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075968), 18);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[19] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076209), 19);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[20] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076197), 20);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[21] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076176), 21);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[22] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076162), 22);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[37] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076144), 37);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[38] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076123), 38);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[39] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076103), 39);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[40] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075808), 40);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[41] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075782), 41);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[42] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075740), 42);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[43] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075945), 43);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[44] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075890), 44);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[45] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075578), 45);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[46] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075574), 46);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[47] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075553), 47);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[48] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075539), 48);
		#=z01DvYK_f6Qaw5r9wXJ$bXHg=.#=zkwP9S0F6kym3[49] = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075522), 49);
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x0600008F RID: 143 RVA: 0x00004DE4 File Offset: 0x00002FE4
	public string FormatString
	{
		get
		{
			return this.#=z$A8Wio4=;
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000090 RID: 144 RVA: 0x00004DEC File Offset: 0x00002FEC
	public int FormatIndex
	{
		get
		{
			return this.#=zm78IYG4=;
		}
	}

	// Token: 0x06000091 RID: 145 RVA: 0x00004DF4 File Offset: 0x00002FF4
	public bool isInitialized()
	{
		return true;
	}

	// Token: 0x06000092 RID: 146 RVA: 0x00004DF8 File Offset: 0x00002FF8
	public bool isBuiltIn()
	{
		return true;
	}

	// Token: 0x06000093 RID: 147 RVA: 0x00004DFC File Offset: 0x00002FFC
	public void initialize(int #=z4J_G3VM=)
	{
	}

	// Token: 0x0400002E RID: 46
	private string #=z$A8Wio4=;

	// Token: 0x0400002F RID: 47
	private int #=zm78IYG4=;

	// Token: 0x04000030 RID: 48
	public static #=z01DvYK_f6Qaw5r9wXJ$bXHg=[] #=zkwP9S0F6kym3 = new #=z01DvYK_f6Qaw5r9wXJ$bXHg=[50];
}
