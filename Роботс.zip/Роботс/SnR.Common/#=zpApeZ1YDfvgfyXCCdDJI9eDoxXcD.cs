﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;
using Skink.SnR.Common.AppLocal;

// Token: 0x020002A6 RID: 678
internal sealed class #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD : IComparable
{
	// Token: 0x06001492 RID: 5266 RVA: 0x0009CD1C File Offset: 0x0009AF1C
	private #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD()
	{
	}

	// Token: 0x06001494 RID: 5268 RVA: 0x0009CD40 File Offset: 0x0009AF40
	public int #=z$lI_VTM=()
	{
		return this.#=z__DXavI$Z0nzP36F4g==;
	}

	// Token: 0x06001495 RID: 5269 RVA: 0x0009CD48 File Offset: 0x0009AF48
	private void #=zSXBstP4=(int #=z$Ib9gYQ=)
	{
		this.#=z__DXavI$Z0nzP36F4g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x0009CD54 File Offset: 0x0009AF54
	public DateTime #=zbZcWkapB6A0U()
	{
		return this.#=z19GEblE1Uf4PyOIMkA==;
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x0009CD5C File Offset: 0x0009AF5C
	private void #=zqxC9Rd46s$Yn(DateTime #=z$Ib9gYQ=)
	{
		this.#=z19GEblE1Uf4PyOIMkA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x0009CD68 File Offset: 0x0009AF68
	public string #=zqjHOR9Q=()
	{
		return this.#=zMOn$W0DW3iFpiytW9w==;
	}

	// Token: 0x06001499 RID: 5273 RVA: 0x0009CD70 File Offset: 0x0009AF70
	private void #=zeAChU_4=(string #=z$Ib9gYQ=)
	{
		this.#=zMOn$W0DW3iFpiytW9w== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600149A RID: 5274 RVA: 0x0009CD7C File Offset: 0x0009AF7C
	public bool #=zldh1AhDKk90X()
	{
		return this.#=zWJFbsi$tLaTfhf17cA==;
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x0009CD84 File Offset: 0x0009AF84
	public void #=zcQ0besfDGm0C(bool #=z$Ib9gYQ=)
	{
		this.#=zWJFbsi$tLaTfhf17cA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x0009CD90 File Offset: 0x0009AF90
	public int CompareTo(object #=zcltuPyw=)
	{
		if (#=zcltuPyw= is #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD)
		{
			return this.#=z$lI_VTM=().CompareTo((#=zcltuPyw= as #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD).#=z$lI_VTM=());
		}
		return -1;
	}

	// Token: 0x0600149D RID: 5277 RVA: 0x0009CDC0 File Offset: 0x0009AFC0
	public static List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> #=z4WsFPIqF78Zw()
	{
		if (#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zjbBMZXVy7lnP == null)
		{
			object obj = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zjbBMZXVy7lnP == null)
				{
					#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zjbBMZXVy7lnP = new List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD>();
					string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064898), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
					if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
					{
						#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zhsx7yh8=(#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=), #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zjbBMZXVy7lnP, true);
					}
				}
			}
		}
		return #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zjbBMZXVy7lnP;
	}

	// Token: 0x0600149E RID: 5278 RVA: 0x0009CE48 File Offset: 0x0009B048
	public static bool #=zqabR9FvBaKnJSx9K$A==()
	{
		List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> list = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=z4WsFPIqF78Zw();
		return list.Count > 0 && !list[list.Count - 1].#=zldh1AhDKk90X();
	}

	// Token: 0x0600149F RID: 5279 RVA: 0x0009CE7C File Offset: 0x0009B07C
	public static void #=zOB21CVc=()
	{
		if (DateTime.Now >= #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zqCdBoz3jo0J$T31T7g==)
		{
			object obj = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zqCdBoz3jo0J$T31T7g== = DateTime.Now + TimeSpan.FromMinutes(60.0);
				new Thread(new ThreadStart(#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zpyVL5hn1NFVC)).Start();
			}
		}
	}

	// Token: 0x060014A0 RID: 5280 RVA: 0x0009CEFC File Offset: 0x0009B0FC
	public static void #=zpyVL5hn1NFVC()
	{
		List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> list = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=z4WsFPIqF78Zw();
		object obj = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zSV4$mlFB34WM;
		lock (obj)
		{
			try
			{
				#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zhsx7yh8=(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zKOquhttg3c04((list.Count > 0) ? list[list.Count - 1].#=z$lI_VTM=() : 0), #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=z4WsFPIqF78Zw(), false);
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
		}
	}

	// Token: 0x060014A1 RID: 5281 RVA: 0x0009CF80 File Offset: 0x0009B180
	private static void #=zhsx7yh8=(string #=zGt__7W2HodTs, List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> #=zHN2gxUc=, bool #=z$TI6Rng=)
	{
		try
		{
			List<int> list = new List<int>();
			List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> list2 = new List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD>();
			string[] array = #=zGt__7W2HodTs.Split(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070691)
			}, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (text.Contains(Environment.NewLine))
				{
					string text2 = text.Substring(0, text.IndexOf(Environment.NewLine));
					string #=z$Ib9gYQ= = text.Substring(text.IndexOf(Environment.NewLine)).Trim();
					int num;
					int.TryParse(text2.Substring(0, text2.IndexOf('.')), out num);
					if (!list.Contains(num))
					{
						#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD = null;
						if (#=zHN2gxUc=.Count > 0 && num <= #=zHN2gxUc=[#=zHN2gxUc=.Count - 1].#=z$lI_VTM=())
						{
							for (int j = #=zHN2gxUc=.Count - 1; j >= 0; j--)
							{
								if (#=zHN2gxUc=[j].#=z$lI_VTM=() == num)
								{
									#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD = #=zHN2gxUc=[j];
									break;
								}
							}
						}
						if (#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD == null)
						{
							#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD = new #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD();
							#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zSXBstP4=(num);
							#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zcQ0besfDGm0C(#=z$TI6Rng=);
							list.Add(num);
							list2.Add(#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD);
						}
						DateTime #=z$Ib9gYQ=2;
						DateTime.TryParseExact(text2.Substring(text2.IndexOf('.') + 1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874), CultureInfo.InvariantCulture, DateTimeStyles.None, out #=z$Ib9gYQ=2);
						#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zqxC9Rd46s$Yn(#=z$Ib9gYQ=2);
						#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zeAChU_4=(#=z$Ib9gYQ=);
					}
				}
			}
			#=zHN2gxUc=.AddRange(list2);
			#=zHN2gxUc=.Sort();
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
	}

	// Token: 0x060014A2 RID: 5282 RVA: 0x0009D120 File Offset: 0x0009B320
	public static void #=zau1bSOGozML3()
	{
		object obj = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zSV4$mlFB34WM;
		lock (obj)
		{
			List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> list = #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=z4WsFPIqF78Zw();
			for (int i = 0; i < list.Count; i++)
			{
				list[i].#=zcQ0besfDGm0C(true);
			}
			#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zFI9_cObwT61B(list);
		}
	}

	// Token: 0x060014A3 RID: 5283 RVA: 0x0009D184 File Offset: 0x0009B384
	private static void #=zFI9_cObwT61B(List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> #=zHN2gxUc=)
	{
		try
		{
			if (#=zHN2gxUc=.Count > 0)
			{
				StringBuilder stringBuilder = new StringBuilder();
				for (int i = 0; i < #=zHN2gxUc=.Count; i++)
				{
					#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD #=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD = #=zHN2gxUc=[i];
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070691));
					stringBuilder.Append(#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=z$lI_VTM=());
					stringBuilder.Append('.');
					stringBuilder.Append(#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zbZcWkapB6A0U().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874)));
					stringBuilder.Append(Environment.NewLine);
					stringBuilder.Append(#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD.#=zqjHOR9Q=());
					stringBuilder.Append(Environment.NewLine);
					stringBuilder.Append(Environment.NewLine);
				}
				#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064898), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==()), stringBuilder.ToString().Trim(), Encoding.UTF8, false);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
	}

	// Token: 0x04000BB9 RID: 3001
	private int #=z__DXavI$Z0nzP36F4g==;

	// Token: 0x04000BBA RID: 3002
	private DateTime #=z19GEblE1Uf4PyOIMkA==;

	// Token: 0x04000BBB RID: 3003
	private string #=zMOn$W0DW3iFpiytW9w==;

	// Token: 0x04000BBC RID: 3004
	private bool #=zWJFbsi$tLaTfhf17cA==;

	// Token: 0x04000BBD RID: 3005
	private static List<#=zpApeZ1YDfvgfyXCCdDJI9eDoxXcD> #=zjbBMZXVy7lnP = null;

	// Token: 0x04000BBE RID: 3006
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000BBF RID: 3007
	private static DateTime #=zqCdBoz3jo0J$T31T7g== = DateTime.MinValue;
}
