﻿using System;
using Skink.SnR.Common.Tasks;

// Token: 0x02000050 RID: 80
internal sealed class #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ== : Task
{
	// Token: 0x06000260 RID: 608 RVA: 0x00015DE8 File Offset: 0x00013FE8
	public #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources #=zk656SlQ=, TaskSeverities #=z_qaYpFQ=, TaskTypes #=zvRLj9WQ=, DateTime #=zxSBcx18=, TimeSpan #=zKMZQB_CxkF$Q, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo) : base(#=zk656SlQ=, #=z_qaYpFQ=, #=zvRLj9WQ=, #=zxSBcx18=, #=zKMZQB_CxkF$Q, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
	}
}
