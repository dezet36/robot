﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Units;

// Token: 0x02000262 RID: 610
internal sealed class #=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII= : IComparer<UnitSquad>
{
	// Token: 0x0600128E RID: 4750 RVA: 0x00091560 File Offset: 0x0008F760
	public #=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=(#=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=.#=zArez$Gs= #=zvRLj9WQ=)
	{
		this.#=zQ4_NWTk= = #=zvRLj9WQ=;
	}

	// Token: 0x0600128F RID: 4751 RVA: 0x00091570 File Offset: 0x0008F770
	public int Compare(UnitSquad #=zdlNP8FM=, UnitSquad #=zXqmo$FI=)
	{
		if (this.#=zQ4_NWTk= != (#=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=.#=zArez$Gs=)1)
		{
			return #=zdlNP8FM=.Type.Id.CompareTo(#=zXqmo$FI=.Type.Id);
		}
		int num = #=zXqmo$FI=.Type.Class.CompareTo(#=zdlNP8FM=.Type.Class);
		if (num != 0)
		{
			return num;
		}
		return #=zdlNP8FM=.Type.Id.CompareTo(#=zXqmo$FI=.Type.Id);
	}

	// Token: 0x04000AB0 RID: 2736
	private #=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=.#=zArez$Gs= #=zQ4_NWTk=;

	// Token: 0x02000263 RID: 611
	public enum #=zArez$Gs=
	{

	}
}
