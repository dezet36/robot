﻿// Token: 0x020001EF RID: 495
internal sealed partial class #=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY= : global::System.Windows.Forms.Form
{
	// Token: 0x06000F03 RID: 3843 RVA: 0x00076DD4 File Offset: 0x00074FD4
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400085C RID: 2140
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
