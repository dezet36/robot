﻿using System;

// Token: 0x02000253 RID: 595
internal static class #=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C
{
	// Token: 0x06001202 RID: 4610 RVA: 0x0008A7D4 File Offset: 0x000889D4
	public static void #=z2jhTT5ariTIC()
	{
		if (#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zjhy86bdywPfUzhA2OzifHJ8=)
		{
			return;
		}
		object obj = #=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zbtgky0k=;
		lock (obj)
		{
			if (!#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zjhy86bdywPfUzhA2OzifHJ8=)
			{
				#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z1jlGMrg=();
				#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zjhy86bdywPfUzhA2OzifHJ8= = true;
			}
		}
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x0008A82C File Offset: 0x00088A2C
	public static void #=z1jlGMrg=()
	{
		if (#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=z8tkBApM=)
		{
			return;
		}
		object obj = #=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zbtgky0k=;
		lock (obj)
		{
			if (!#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=z8tkBApM=)
			{
				#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=z1jlGMrg=();
				#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=z8tkBApM= = true;
			}
		}
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x0008A884 File Offset: 0x00088A84
	public static void #=zIhEoTo0tDwFVzyvxnw==(string #=zye7amwI=)
	{
		try
		{
			#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929566), #=zye7amwI=));
			Environment.FailFast(#=zye7amwI=);
		}
		catch
		{
			Environment.Exit(57005);
		}
	}

	// Token: 0x04000A0D RID: 2573
	private static bool #=zjhy86bdywPfUzhA2OzifHJ8=;

	// Token: 0x04000A0E RID: 2574
	private static bool #=z8tkBApM=;

	// Token: 0x04000A0F RID: 2575
	private static readonly object #=zbtgky0k= = new object();
}
