﻿using System;

// Token: 0x0200003A RID: 58
internal sealed class #=z0xcs93RQRrwIMe4tGOWkzRwGVBzPKZw2fYonUk7Ku1LyJT9zhA== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060001DD RID: 477 RVA: 0x00012AD4 File Offset: 0x00010CD4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zHlPhtrw= = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		this.#=zHlPhtrw=.#=z20ohAjI=(#=zuJjQ1XU=);
	}

	// Token: 0x060001DE RID: 478 RVA: 0x00012AF0 File Offset: 0x00010CF0
	protected override void #=zvb5bnug=()
	{
		this.#=zHlPhtrw=.#=zyadZ79g=(this.#=zcDRV51Ut$7oP as #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs);
	}

	// Token: 0x0400006C RID: 108
	private #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zHlPhtrw=;
}
