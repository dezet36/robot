﻿using System;
using System.Collections.Generic;

// Token: 0x0200024F RID: 591
internal sealed class #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ== : List<#=zekGeYO3to2Fzt8dHc$KbhRWQexX_>
{
	// Token: 0x060011EE RID: 4590 RVA: 0x0008A564 File Offset: 0x00088764
	public #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==()
	{
		this.#=z57aLKf30dozYHMIIzUjY9M2Iwc5G(new List<int>());
	}

	// Token: 0x060011EF RID: 4591 RVA: 0x0008A578 File Offset: 0x00088778
	public List<int> #=zSeqcSs2s84emDcMs_EHmHqDAfH_U()
	{
		return this.#=zh4wqzBZ0aXrQYX2syzHqAoUSWXwt_jyNAw==;
	}

	// Token: 0x060011F0 RID: 4592 RVA: 0x0008A580 File Offset: 0x00088780
	public void #=z57aLKf30dozYHMIIzUjY9M2Iwc5G(List<int> #=z$Ib9gYQ=)
	{
		this.#=zh4wqzBZ0aXrQYX2syzHqAoUSWXwt_jyNAw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011F1 RID: 4593 RVA: 0x0008A58C File Offset: 0x0008878C
	public void #=zm7nSMZ8=()
	{
		base.Clear();
		this.#=zSeqcSs2s84emDcMs_EHmHqDAfH_U().Clear();
	}

	// Token: 0x04000A08 RID: 2568
	private List<int> #=zh4wqzBZ0aXrQYX2syzHqAoUSWXwt_jyNAw==;
}
