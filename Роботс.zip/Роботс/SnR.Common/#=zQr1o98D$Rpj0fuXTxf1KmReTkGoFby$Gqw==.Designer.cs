﻿// Token: 0x02000189 RID: 393
internal sealed partial class #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw== : global::System.Windows.Forms.Form
{
	// Token: 0x06000B43 RID: 2883 RVA: 0x00056730 File Offset: 0x00054930
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000603 RID: 1539
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
