﻿using System;
using System.Collections.Generic;

// Token: 0x02000170 RID: 368
internal sealed class #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== : List<#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==>
{
	// Token: 0x060009DE RID: 2526 RVA: 0x0004FF30 File Offset: 0x0004E130
	public #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== in this)
		{
			if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==;
			}
		}
		return null;
	}
}
