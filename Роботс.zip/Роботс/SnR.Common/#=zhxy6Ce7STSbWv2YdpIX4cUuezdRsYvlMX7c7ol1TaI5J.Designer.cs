﻿// Token: 0x02000255 RID: 597
internal sealed partial class #=zhxy6Ce7STSbWv2YdpIX4cUuezdRsYvlMX7c7ol1TaI5J : global::System.Windows.Forms.Form
{
	// Token: 0x06001219 RID: 4633 RVA: 0x0008AFE8 File Offset: 0x000891E8
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000A16 RID: 2582
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
