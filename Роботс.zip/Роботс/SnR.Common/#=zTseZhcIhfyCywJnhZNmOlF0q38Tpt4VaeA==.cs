﻿using System;
using System.Collections.Generic;

// Token: 0x020001A8 RID: 424
internal sealed class #=zTseZhcIhfyCywJnhZNmOlF0q38Tpt4VaeA== : #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==
{
	// Token: 0x06000CD7 RID: 3287 RVA: 0x00066558 File Offset: 0x00064758
	public #=zTseZhcIhfyCywJnhZNmOlF0q38Tpt4VaeA==()
	{
		this.#=zdaOsPHYUNSEy = false;
	}

	// Token: 0x06000CD8 RID: 3288 RVA: 0x00066568 File Offset: 0x00064768
	public void #=zVIgqp0Y=()
	{
		base.#=z4HyKJ7m74sB_1gVqzA==(new List<string>());
		this.#=zdaOsPHYUNSEy = true;
	}

	// Token: 0x06000CD9 RID: 3289 RVA: 0x00066580 File Offset: 0x00064780
	public void #=zPC48eGFZAOd4(string #=zVI_2r0M=)
	{
		if (!this.#=zdaOsPHYUNSEy)
		{
			this.#=zVIgqp0Y=();
		}
		base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 1);
	}

	// Token: 0x06000CDA RID: 3290 RVA: 0x00066598 File Offset: 0x00064798
	public new bool #=z5GlD5yOMF10k(string #=zRvgpNx8=)
	{
		return base.#=z5GlD5yOMF10k(#=zRvgpNx8=);
	}

	// Token: 0x06000CDB RID: 3291 RVA: 0x000665A4 File Offset: 0x000647A4
	public new void #=zO9hEXZnX7tvi()
	{
		base.#=zO9hEXZnX7tvi();
	}

	// Token: 0x06000CDC RID: 3292 RVA: 0x000665AC File Offset: 0x000647AC
	public new object #=zx0uresqDtFaL(string #=zUjJKM0I=)
	{
		return base.#=zx0uresqDtFaL(#=zUjJKM0I=);
	}

	// Token: 0x0400076A RID: 1898
	private bool #=zdaOsPHYUNSEy;
}
