﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Managers;

// Token: 0x0200016C RID: 364
internal sealed partial class #=zNWUFwCX3ttLAWzlJhHsKH_Um_zOhrjyFllGc6tWTqJSLTltdtw== : Form
{
	// Token: 0x060009A0 RID: 2464 RVA: 0x0004F014 File Offset: 0x0004D214
	public #=zNWUFwCX3ttLAWzlJhHsKH_Um_zOhrjyFllGc6tWTqJSLTltdtw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, bool #=zL82SKkG$seRE)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zXqKwUc4= = #=z8StzeqE=;
		this.#=zBpfs9Y6fd_Wr = #=zL82SKkG$seRE;
		base.DialogResult = DialogResult.Cancel;
		this.#=zgpzgXirqPT5_();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
		if (this.#=zBpfs9Y6fd_Wr)
		{
			this.#=zx2bfLsiuI9hw.Visible = false;
		}
	}

	// Token: 0x060009A1 RID: 2465 RVA: 0x0004F064 File Offset: 0x0004D264
	private void #=zm$6gtxNaRHjk(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		string #=zdBD5ZXA=;
		bool flag = this.#=zQb2RiJSNv$s$tPWw7g==(new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>
		{
			this.#=zXqKwUc4=
		}, out #=zdBD5ZXA=);
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
		if (flag)
		{
			base.DialogResult = DialogResult.OK;
			base.Close();
		}
	}

	// Token: 0x060009A2 RID: 2466 RVA: 0x0004F0A0 File Offset: 0x0004D2A0
	private void #=z5v0iWN1U7_PQtDpdrA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== = new #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==(this.#=zshVEGQI=, this.#=zXqKwUc4=);
		try
		{
			if (#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.ShowDialog() == DialogResult.OK && #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==().Count > 0)
			{
				List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
				foreach (int index in #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==())
				{
					list.Add(this.#=zshVEGQI=.#=zol80P7TKoihZ()[index]);
				}
				string #=zdBD5ZXA=;
				bool flag = this.#=zQb2RiJSNv$s$tPWw7g==(list, out #=zdBD5ZXA=);
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
				if (flag)
				{
					base.DialogResult = DialogResult.OK;
					base.Close();
				}
			}
		}
		finally
		{
			((IDisposable)#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==).Dispose();
		}
	}

	// Token: 0x060009A3 RID: 2467 RVA: 0x0004F16C File Offset: 0x0004D36C
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060009A4 RID: 2468 RVA: 0x0004F174 File Offset: 0x0004D374
	private bool #=zQb2RiJSNv$s$tPWw7g==(List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zJe6TLpo=, out string #=zx9NCziM=)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zXqKwUc4=);
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = this.#=zk55d778IdJE5fRurDw==(this.#=zALFVMueMgh7C8SORew==.Text, #=z0fnp28WHdHHIomvTDkV56EngzJg, out #=zx9NCziM=);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			return false;
		}
		if (string.IsNullOrEmpty(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==()))
		{
			#=zx9NCziM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088091));
			return false;
		}
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJe6TLpo=)
		{
			if (this.#=zBpfs9Y6fd_Wr)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoRobDontAlliances.Add(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==());
			}
			else
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoRobAlliances.Add(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==());
			}
		}
		#=zx9NCziM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088060));
		if (this.#=zx2bfLsiuI9hw.Checked && !this.#=zBpfs9Y6fd_Wr)
		{
			List<int> list = new List<int>();
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zYAdaM0gb6Gux4qLnpQ==(#=z0fnp28WHdHHIomvTDkV56EngzJg, this.#=zXqKwUc4=.#=zYgvZuBwR$a1C(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088037));
			if (array == null)
			{
				#=zx9NCziM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088017));
				return false;
			}
			foreach (Dictionary<string, object> dictionary in array)
			{
				list.Add(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0));
			}
			object[] array3 = JSONManager.GetArray(JSONManager.GetData(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=z$F1M_0mTucCE(list)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976));
			List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=> list2 = new List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=>();
			if (array3 != null)
			{
				foreach (Dictionary<string, object> dictionary2 in array3)
				{
					Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = new #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0), JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty), JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0), JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zAsCgbAN02olKpq2GjA==(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
					if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zO1FX6YkNZlqlvFZqJg==() == #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==())
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=z6AhOmwNDely78tSumg==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==());
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zGHLCYJmbc1Pd(true);
						list2.Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
					}
				}
			}
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in #=zJe6TLpo=)
			{
				#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= = new #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=();
				#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zi8F0nzW98_9V(list2);
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zeR3QFrc=(#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
			}
			#=zx9NCziM= = #=zx9NCziM= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088229));
		}
		return true;
	}

	// Token: 0x060009A5 RID: 2469 RVA: 0x0004F468 File Offset: 0x0004D668
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zk55d778IdJE5fRurDw==(string #=znUBh3vsamsjU, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, out string #=zx9NCziM=)
	{
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (!#=zNWUFwCX3ttLAWzlJhHsKH_Um_zOhrjyFllGc6tWTqJSLTltdtw==.#=zpFuBGU_pbGgs(#=znUBh3vsamsjU, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			#=zx9NCziM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088151));
			return null;
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(this.#=zXqKwUc4=, #=zhfS69jI=, #=zmWD8vxE=, #=zSJY$s3o=);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			#=zx9NCziM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087869));
			return null;
		}
		#=zx9NCziM= = null;
		return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
	}

	// Token: 0x060009A6 RID: 2470 RVA: 0x0004F4C4 File Offset: 0x0004D6C4
	private static bool #=zpFuBGU_pbGgs(string #=zcpJ6bUA=, out int #=zQrqFdos=, out int #=zKFlJyLE=)
	{
		#=zQrqFdos= = 0;
		#=zKFlJyLE= = 0;
		bool result;
		try
		{
			string[] array = #=zcpJ6bUA=.Split(new char[]
			{
				' ',
				',',
				';',
				'\t'
			}, StringSplitOptions.RemoveEmptyEntries);
			if (array.Length != 2)
			{
				result = false;
			}
			else if (!int.TryParse(array[0], out #=zQrqFdos=))
			{
				result = false;
			}
			else if (!int.TryParse(array[1], out #=zKFlJyLE=))
			{
				result = false;
			}
			else
			{
				result = true;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060009A8 RID: 2472 RVA: 0x0004F554 File Offset: 0x0004D754
	private void #=zgpzgXirqPT5_()
	{
		this.#=zeF2zYRI= = new Button();
		this.#=ztK81DTECKvPc = new Button();
		this.#=zALFVMueMgh7C8SORew== = new TextBox();
		this.#=zMQG_pf87$r9w = new Label();
		this.#=zx2bfLsiuI9hw = new CheckBox();
		this.#=zHeAVXAs= = new Button();
		base.SuspendLayout();
		this.#=zeF2zYRI=.Location = new Point(12, 102);
		this.#=zeF2zYRI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087844);
		this.#=zeF2zYRI=.Size = new Size(75, 23);
		this.#=zeF2zYRI=.TabIndex = 0;
		this.#=zeF2zYRI=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087213);
		this.#=zeF2zYRI=.UseVisualStyleBackColor = true;
		this.#=zeF2zYRI=.Click += this.#=zm$6gtxNaRHjk;
		this.#=ztK81DTECKvPc.Location = new Point(93, 102);
		this.#=ztK81DTECKvPc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087828);
		this.#=ztK81DTECKvPc.Size = new Size(160, 23);
		this.#=ztK81DTECKvPc.TabIndex = 1;
		this.#=ztK81DTECKvPc.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087800);
		this.#=ztK81DTECKvPc.UseVisualStyleBackColor = true;
		this.#=ztK81DTECKvPc.Click += this.#=z5v0iWN1U7_PQtDpdrA==;
		this.#=zALFVMueMgh7C8SORew==.Location = new Point(34, 34);
		this.#=zALFVMueMgh7C8SORew==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087777);
		this.#=zALFVMueMgh7C8SORew==.Size = new Size(100, 20);
		this.#=zALFVMueMgh7C8SORew==.TabIndex = 2;
		this.#=zMQG_pf87$r9w.AutoSize = true;
		this.#=zMQG_pf87$r9w.Location = new Point(12, 9);
		this.#=zMQG_pf87$r9w.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087765);
		this.#=zMQG_pf87$r9w.Size = new Size(233, 13);
		this.#=zMQG_pf87$r9w.TabIndex = 3;
		this.#=zMQG_pf87$r9w.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087749);
		this.#=zx2bfLsiuI9hw.AutoSize = true;
		this.#=zx2bfLsiuI9hw.Location = new Point(34, 69);
		this.#=zx2bfLsiuI9hw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087944);
		this.#=zx2bfLsiuI9hw.Size = new Size(251, 17);
		this.#=zx2bfLsiuI9hw.TabIndex = 4;
		this.#=zx2bfLsiuI9hw.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087921);
		this.#=zx2bfLsiuI9hw.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Location = new Point(259, 102);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 5;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(373, 158);
		base.Controls.Add(this.#=zHeAVXAs=);
		base.Controls.Add(this.#=zx2bfLsiuI9hw);
		base.Controls.Add(this.#=zMQG_pf87$r9w);
		base.Controls.Add(this.#=zALFVMueMgh7C8SORew==);
		base.Controls.Add(this.#=ztK81DTECKvPc);
		base.Controls.Add(this.#=zeF2zYRI=);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089649);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089618);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400058D RID: 1421
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x0400058E RID: 1422
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zXqKwUc4=;

	// Token: 0x0400058F RID: 1423
	private bool #=zBpfs9Y6fd_Wr;

	// Token: 0x04000591 RID: 1425
	private Button #=zeF2zYRI=;

	// Token: 0x04000592 RID: 1426
	private Button #=ztK81DTECKvPc;

	// Token: 0x04000593 RID: 1427
	private TextBox #=zALFVMueMgh7C8SORew==;

	// Token: 0x04000594 RID: 1428
	private Label #=zMQG_pf87$r9w;

	// Token: 0x04000595 RID: 1429
	private CheckBox #=zx2bfLsiuI9hw;

	// Token: 0x04000596 RID: 1430
	private Button #=zHeAVXAs=;
}
