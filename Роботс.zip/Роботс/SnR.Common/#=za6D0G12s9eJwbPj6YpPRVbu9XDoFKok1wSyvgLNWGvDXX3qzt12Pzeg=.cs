﻿using System;
using System.Collections.Generic;
using System.Linq;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020001F7 RID: 503
internal sealed class #=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000F41 RID: 3905 RVA: 0x00078DA0 File Offset: 0x00076FA0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
	}

	// Token: 0x06000F42 RID: 3906 RVA: 0x00078DB0 File Offset: 0x00076FB0
	protected override void #=zvb5bnug=()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsFunctions <= 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933007), Array.Empty<object>());
			return;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit > 0 && this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zsSDs77$0W5eVd$WfMCPFH5o=() > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit - 200)
		{
			if (!(this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zUz3LnE0a7XpsUPo31iaa2Uk=().Date < DateTime.Today))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932682), Array.Empty<object>());
				return;
			}
			this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zrS59ZtEbgkeqtjvPO76sazQ=(0);
		}
		Dictionary<int, List<string>> dictionary = new Dictionary<int, List<string>>();
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() < 0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zuFPZLKs=().#=zvnZc$RhG_1Du() > 1)
			{
				List<string> list;
				if (dictionary.ContainsKey(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zuFPZLKs=().#=zKHqHudNIb2os()))
				{
					list = dictionary[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zuFPZLKs=().#=zKHqHudNIb2os()];
				}
				else
				{
					list = new List<string>();
					dictionary[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zuFPZLKs=().#=zKHqHudNIb2os()] = list;
				}
				list.Add((-#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()).ToString());
			}
		}
		List<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=> list2 = new List<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=>();
		GameApplicationData.#=zdmZ8JO4ttdMN(this.#=z8StzeqE=.#=zYgvZuBwR$a1C());
		foreach (int num in dictionary.Keys)
		{
			#=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=zySoyhx1s5bIqrzqW4SLgcas=(list2, this.#=zBsXSanI=, num, dictionary[num]);
		}
		if (list2.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932639), Array.Empty<object>());
			return;
		}
		list2 = Enumerable.ToList<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=>(Enumerable.OrderByDescending<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=, int>(list2, new Func<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=, int>(#=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=zyDNvciU=.#=zLkw0NRU=.#=zcsmudeX30Cz_MMPuSw==)));
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit > 0)
		{
			int num2 = 0;
			foreach (#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= in list2)
			{
				foreach (#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP in #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zZUNqx7t2T5W7fS1fb5XafzQ=())
				{
					if (#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=zEpmJu0QO9VH_() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=zPHMvvJ8=().Date == DateTime.Today)
					{
						num2 += #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=zlIXJ9$NfUZc_();
					}
				}
			}
			this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zrS59ZtEbgkeqtjvPO76sazQ=(num2);
			this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zxSSEmYWmFdenM$$xeEU8Txk=(DateTime.Today);
			if (this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zsSDs77$0W5eVd$WfMCPFH5o=() > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit - 200)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932682), Array.Empty<object>());
				return;
			}
		}
		foreach (#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2 in list2)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 = null;
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3 in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3.#=zK5gF1KeGk_H_() == -#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zMuFMjGQ=())
				{
					#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3;
					break;
				}
			}
			UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
			foreach (UnitSquad unitSquad in #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD())
			{
				if (unitSquad.Type.Categories_HasNoneBut(new UnitType.Categories[]
				{
					UnitType.Categories.m_Elite,
					UnitType.Categories.r_Denaries
				}) && ((unitSquad.Type.Function == UnitType.Functions.Offence && (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsFunctions & 1) > 0) || (unitSquad.Type.Function == UnitType.Functions.Defence && (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsFunctions & 2) > 0) || (unitSquad.Type.Function == UnitType.Functions.Scouting && (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsFunctions & 4) > 0)) && !#=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=z7XoVAP7V0vvRZFJhtA==.Contains(unitSquad.Type.Id))
				{
					unitSquadCollection.Add(unitSquad);
				}
			}
			unitSquadCollection.Sort(new #=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=((#=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=.#=zArez$Gs=)1));
			foreach (UnitSquad unitSquad2 in unitSquadCollection)
			{
				int num3;
				switch (unitSquad2.Type.Class)
				{
				case UnitType.Classes.LightInfantry:
					num3 = 20;
					break;
				case UnitType.Classes.HeavyInfantry:
					num3 = 50;
					break;
				case UnitType.Classes.Phalanx:
					num3 = 100;
					break;
				case UnitType.Classes.Cavalry:
					num3 = 200;
					break;
				default:
					num3 = 200;
					break;
				}
				int num4 = #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zLvqwQumxHX8WduSlGQ==();
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit > 0 && num4 > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit - this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zsSDs77$0W5eVd$WfMCPFH5o=())
				{
					num4 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit - this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zsSDs77$0W5eVd$WfMCPFH5o=();
				}
				int num5;
				if ((long)unitSquad2.Number * (long)num3 * (long)(100 - this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease) / 100L <= (long)num4)
				{
					num5 = unitSquad2.Number;
				}
				else
				{
					num5 = (int)((long)num4 * 100L / (long)(num3 * (100 - this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease)));
				}
				if (num5 <= 0)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932844), new object[]
					{
						unitSquad2.Type.Name
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932770), new object[]
					{
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zLvqwQumxHX8WduSlGQ==(),
						this.#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsDailyLimit,
						this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zsSDs77$0W5eVd$WfMCPFH5o=(),
						num3,
						this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease,
						unitSquad2.Number,
						num5
					});
					string text = this.#=zBsXSanI=.#=zBFslCXZIXSbSx_Ghqw==(#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2, unitSquad2.Type.Id, num5);
					if (!text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
					{
						int @int = JSONManager.GetInt((Dictionary<string, object>)JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0);
						int num6 = (num3 * 100 - @int * 100 / num5) / num3;
						if (num6 > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease)
						{
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease = num6;
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
						}
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=3 = #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2;
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=3.#=z6U0GQOJYJX1Mx0n3FA==(#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=3.#=zLvqwQumxHX8WduSlGQ==() - @int);
						#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== = this.#=z8StzeqE=.#=z5Fxa9o9ygZWU();
						#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zrS59ZtEbgkeqtjvPO76sazQ=(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zsSDs77$0W5eVd$WfMCPFH5o=() + @int);
						this.#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zxSSEmYWmFdenM$$xeEU8Txk=(DateTime.Today);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932422), new object[]
						{
							unitSquad2.Type.Name,
							num5,
							#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zkfqcY3I=(),
							@int
						});
						if (num4 - @int < 200)
						{
							break;
						}
					}
					else
					{
						if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932361)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932590), new object[]
							{
								unitSquad2.Type.Name,
								num5,
								#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zkfqcY3I=()
							});
							break;
						}
						if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932489)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932214), new object[]
							{
								unitSquad2.Type.Name,
								num5,
								#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zkfqcY3I=()
							});
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OrihalkUsageDecrease = 0;
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
							break;
						}
						if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932151)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932112), new object[]
							{
								unitSquad2.Type.Name,
								num5,
								#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zkfqcY3I=()
							});
							if (#=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=z7XoVAP7V0vvRZFJhtA==.Contains(unitSquad2.Type.Id))
							{
								continue;
							}
							object obj = #=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=zSV4$mlFB34WM;
							lock (obj)
							{
								#=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=z7XoVAP7V0vvRZFJhtA==.Add(unitSquad2.Type.Id);
								continue;
							}
						}
						text = JSONManager.Cut(text);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932283), new object[]
						{
							unitSquad2.Type.Name,
							num5,
							#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=2.#=zkfqcY3I=(),
							text
						});
					}
				}
			}
		}
	}

	// Token: 0x06000F43 RID: 3907 RVA: 0x000798A0 File Offset: 0x00077AA0
	private static void #=zySoyhx1s5bIqrzqW4SLgcas=(List<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=> #=zXr_e11RkUSZTuDuvNA==, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, int #=zCHPchKE=, List<string> #=zrfC66YNK2QgA)
	{
		object[] array = JSONManager.GetArray(JSONManager.GetData(#=zSJY$s3o=.#=zd47NNCPsuiuL(#=zCHPchKE=, #=zrfC66YNK2QgA)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
		if (array != null)
		{
			foreach (Dictionary<string, object> obj in array)
			{
				Dictionary<string, object> dictionary = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932245));
				if (dictionary != null)
				{
					int @int = JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0);
					if (@int >= 200)
					{
						Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
						Dictionary<string, object> dictionary3 = JSONManager.GetDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= = new #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=();
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zbsxKkj4=(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zHD9M6IxBLboIezSsHQ==(JSONManager.GetInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.GetInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zwXKUV2c=(JSONManager.GetString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), null));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zFzGvi_S6jJhE(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zf2R7C9IfGGsfWN39Hw==(#=zCHPchKE=);
						#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=z6U0GQOJYJX1Mx0n3FA==(@int);
						#=zXr_e11RkUSZTuDuvNA==.Add(#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=);
						object[] array3 = JSONManager.GetArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
						if (array3 != null)
						{
							foreach (Dictionary<string, object> dictionary4 in array3)
							{
								List<#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP> list = #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=.#=zZUNqx7t2T5W7fS1fb5XafzQ=();
								#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP = new #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP();
								#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=z_MMDqXnekqn_(Convert.ToInt32(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]));
								#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=zIR9Xlcg=(JSONManager.DecodeTime(Convert.ToString(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)]), false));
								#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP.#=zqoCq5j01dD5w(Convert.ToInt32(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)]));
								list.Add(#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP);
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x0400087E RID: 2174
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x0400087F RID: 2175
	private static List<int> #=z7XoVAP7V0vvRZFJhtA== = new List<int>();

	// Token: 0x04000880 RID: 2176
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x020001F8 RID: 504
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000F46 RID: 3910 RVA: 0x00079AA0 File Offset: 0x00077CA0
		internal int #=zcsmudeX30Cz_MMPuSw==(#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zCTSet$w=)
		{
			return #=zCTSet$w=.#=zvnZc$RhG_1Du();
		}

		// Token: 0x04000881 RID: 2177
		public static readonly #=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=zyDNvciU= #=zLkw0NRU= = new #=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=.#=zyDNvciU=();

		// Token: 0x04000882 RID: 2178
		public static Func<#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=, int> #=zsF_$xkMfvneXOD9Dtw==;
	}
}
