﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000205 RID: 517
internal sealed class #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM : Task
{
	// Token: 0x06000FE9 RID: 4073 RVA: 0x0007B768 File Offset: 0x00079968
	public #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM(int #=zbwrJfOI=, string #=zSlFVX3A=, DateTime #=zKOSDhmzAyJ64KLQHVA==, #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zy0tqKwE=, #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=zrqSAU7y6beqUDVj9nw==) : base(TaskSources.ManualNotSavable, TaskSeverities.Immediate, TaskTypes.SendAndRecallResources, #=zKOSDhmzAyJ64KLQHVA== - TimeSpan.FromSeconds(60.0), TimeSpan.FromSeconds(30.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false)
	{
		this.#=zWIeOkE0$UPjN(#=zbwrJfOI=);
		this.#=zvigQEqS9Zgck(#=zSlFVX3A=);
		this.#=zIR9Xlcg=(#=zKOSDhmzAyJ64KLQHVA==);
		this.#=z$zHAfbjZaxbHFAEiVQ==(#=zrqSAU7y6beqUDVj9nw==.#=zMbI49ITzPNVB());
		if (#=zy0tqKwE=[ResourceTypes.Grain] >= this.#=zAN1jhLGuHk65bjr1aA==())
		{
			this.#=zHtLQyfMx4nLU(ResourceTypes.Grain);
		}
		else if (#=zy0tqKwE=[ResourceTypes.Bronze] >= this.#=zAN1jhLGuHk65bjr1aA==())
		{
			this.#=zHtLQyfMx4nLU(ResourceTypes.Bronze);
		}
		else if (#=zy0tqKwE=[ResourceTypes.Lumber] >= this.#=zAN1jhLGuHk65bjr1aA==())
		{
			this.#=zHtLQyfMx4nLU(ResourceTypes.Lumber);
		}
		else
		{
			this.#=zHtLQyfMx4nLU(ResourceTypes.Unknown);
		}
		base.Options = TaskOptions.NoDataRequired;
	}

	// Token: 0x06000FEA RID: 4074 RVA: 0x0007B82C File Offset: 0x00079A2C
	public #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x06000FEB RID: 4075 RVA: 0x0007B83C File Offset: 0x00079A3C
	public int #=zK5gF1KeGk_H_()
	{
		return this.#=z$PjuEd9p6uF7ftQ3QA==;
	}

	// Token: 0x06000FEC RID: 4076 RVA: 0x0007B844 File Offset: 0x00079A44
	private void #=zWIeOkE0$UPjN(int #=z$Ib9gYQ=)
	{
		this.#=z$PjuEd9p6uF7ftQ3QA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FED RID: 4077 RVA: 0x0007B850 File Offset: 0x00079A50
	public string #=zQC8i3zEav7GT()
	{
		return this.#=z5fEKVfDJKgNKolNyww==;
	}

	// Token: 0x06000FEE RID: 4078 RVA: 0x0007B858 File Offset: 0x00079A58
	private void #=zvigQEqS9Zgck(string #=z$Ib9gYQ=)
	{
		this.#=z5fEKVfDJKgNKolNyww== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FEF RID: 4079 RVA: 0x0007B864 File Offset: 0x00079A64
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x06000FF0 RID: 4080 RVA: 0x0007B86C File Offset: 0x00079A6C
	private void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FF1 RID: 4081 RVA: 0x0007B878 File Offset: 0x00079A78
	public ResourceTypes #=z9F1kCyejOnmm()
	{
		return this.#=z7Spf0p5Y7sP5rF$oiq4lCZo=;
	}

	// Token: 0x06000FF2 RID: 4082 RVA: 0x0007B880 File Offset: 0x00079A80
	public void #=zHtLQyfMx4nLU(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=z7Spf0p5Y7sP5rF$oiq4lCZo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FF3 RID: 4083 RVA: 0x0007B88C File Offset: 0x00079A8C
	public int #=zAN1jhLGuHk65bjr1aA==()
	{
		return this.#=zGhyEWGNZsthGI7XIhbkdYJg=;
	}

	// Token: 0x06000FF4 RID: 4084 RVA: 0x0007B894 File Offset: 0x00079A94
	public void #=z$zHAfbjZaxbHFAEiVQ==(int #=z$Ib9gYQ=)
	{
		this.#=zGhyEWGNZsthGI7XIhbkdYJg= = #=z$Ib9gYQ=;
	}

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000FF5 RID: 4085 RVA: 0x0007B8A0 File Offset: 0x00079AA0
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874093);
		}
	}

	// Token: 0x06000FF6 RID: 4086 RVA: 0x0007B8AC File Offset: 0x00079AAC
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zWIeOkE0$UPjN(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875348), 0));
		this.#=zvigQEqS9Zgck(JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875334), string.Empty));
		this.#=zIR9Xlcg=(JSONManager.UserStringToDate(JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875313), string.Empty)));
		this.#=zHtLQyfMx4nLU((ResourceTypes)JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875296), 0));
		this.#=z$zHAfbjZaxbHFAEiVQ==(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875283), 0));
	}

	// Token: 0x06000FF7 RID: 4087 RVA: 0x0007B93C File Offset: 0x00079B3C
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875348)] = this.#=zK5gF1KeGk_H_();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875334)] = this.#=zQC8i3zEav7GT();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875313)] = JSONManager.DateToUserString(this.#=zPHMvvJ8=());
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875296)] = (int)this.#=z9F1kCyejOnmm();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875283)] = this.#=zAN1jhLGuHk65bjr1aA==();
		return dictionary;
	}

	// Token: 0x040008CE RID: 2254
	private int #=z$PjuEd9p6uF7ftQ3QA==;

	// Token: 0x040008CF RID: 2255
	private string #=z5fEKVfDJKgNKolNyww==;

	// Token: 0x040008D0 RID: 2256
	private DateTime #=zJDEdzIaDvHbnYM06$w==;

	// Token: 0x040008D1 RID: 2257
	private ResourceTypes #=z7Spf0p5Y7sP5rF$oiq4lCZo=;

	// Token: 0x040008D2 RID: 2258
	private int #=zGhyEWGNZsthGI7XIhbkdYJg=;
}
