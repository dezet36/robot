﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.City;

// Token: 0x020001FF RID: 511
internal sealed partial class #=zanGez1y6ixXU2ZoYLARJoROLRVz3eGwc9IcUDyA= : Form
{
	// Token: 0x06000FAC RID: 4012 RVA: 0x0007A59C File Offset: 0x0007879C
	public #=zanGez1y6ixXU2ZoYLARJoROLRVz3eGwc9IcUDyA=(BuildingPlanFrame #=zEfCr8HM=)
	{
		this.#=zqTUsrROtfZh6(#=zEfCr8HM=);
		this.#=zgpzgXirqPT5_();
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		foreach (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF in #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=())
		{
			if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=z97C9Udp8hOam() && #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zgFVkd5ydGXNJ() != (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)5)
			{
				list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Id, #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zNn0PpoXIcD55()));
			}
		}
		this.#=zsrRuizRUiU6YUC3hQw==.#=z20ohAjI=(list, false, false);
		if (#=zEfCr8HM= != null)
		{
			List<int> list2 = new List<int>();
			foreach (int item in #=zEfCr8HM=.Types)
			{
				list2.Add(item);
			}
			this.#=zsrRuizRUiU6YUC3hQw==.#=zsIWrSzQ=(list2);
			this.#=zt7pW1CIU5LUe.Text = #=zEfCr8HM=.Level.ToString();
			if (#=zEfCr8HM=.Number > 0)
			{
				this.#=zGJH6nGCm89aB.Text = #=zEfCr8HM=.Number.ToString();
			}
			this.#=zJiBnBkaEm1GZ7EFdqw==.Checked = #=zEfCr8HM=.IsTimeBoost;
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06000FAD RID: 4013 RVA: 0x0007A6E8 File Offset: 0x000788E8
	public BuildingPlanFrame #=z2rLDbX7PDceR()
	{
		return this.#=zxnGiD$PUPFfP89kZUQ==;
	}

	// Token: 0x06000FAE RID: 4014 RVA: 0x0007A6F0 File Offset: 0x000788F0
	public void #=zqTUsrROtfZh6(BuildingPlanFrame #=z$Ib9gYQ=)
	{
		this.#=zxnGiD$PUPFfP89kZUQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FAF RID: 4015 RVA: 0x0007A6FC File Offset: 0x000788FC
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=z2rLDbX7PDceR() == null)
		{
			this.#=zqTUsrROtfZh6(new BuildingPlanFrame());
		}
		List<int> list = this.#=zsrRuizRUiU6YUC3hQw==.#=zBziBGR4jZQ9z();
		this.#=z2rLDbX7PDceR().Types.Clear();
		foreach (int item in list)
		{
			this.#=z2rLDbX7PDceR().Types.Add(item);
		}
		int level;
		if (int.TryParse(this.#=zt7pW1CIU5LUe.Text, out level))
		{
			this.#=z2rLDbX7PDceR().Level = level;
		}
		int num;
		if (int.TryParse(this.#=zGJH6nGCm89aB.Text, out num))
		{
			if (num < 0)
			{
				num = 0;
			}
			this.#=z2rLDbX7PDceR().Number = num;
		}
		this.#=z2rLDbX7PDceR().IsTimeBoost = this.#=zJiBnBkaEm1GZ7EFdqw==.Checked;
		base.DialogResult = DialogResult.OK;
		base.Close();
	}

	// Token: 0x06000FB0 RID: 4016 RVA: 0x0007A7EC File Offset: 0x000789EC
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.DialogResult = DialogResult.Cancel;
		base.Close();
	}

	// Token: 0x06000FB2 RID: 4018 RVA: 0x0007A81C File Offset: 0x00078A1C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zsrRuizRUiU6YUC3hQw== = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zt7pW1CIU5LUe = new TextBox();
		this.#=z0_OI$vEecjj_ = new Label();
		this.#=zuCaP$Fc= = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zGJH6nGCm89aB = new TextBox();
		this.#=ziHFsfnvJd194 = new Label();
		this.#=zJiBnBkaEm1GZ7EFdqw== = new CheckBox();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		base.SuspendLayout();
		this.#=zsrRuizRUiU6YUC3hQw==.AutoScroll = true;
		this.#=zsrRuizRUiU6YUC3hQw==.BorderStyle = BorderStyle.FixedSingle;
		this.#=zsrRuizRUiU6YUC3hQw==.Dock = DockStyle.Fill;
		this.#=zsrRuizRUiU6YUC3hQw==.Location = new Point(0, 0);
		this.#=zsrRuizRUiU6YUC3hQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909115077);
		this.#=zsrRuizRUiU6YUC3hQw==.Size = new Size(319, 523);
		this.#=zsrRuizRUiU6YUC3hQw==.TabIndex = 4;
		this.#=zt7pW1CIU5LUe.Location = new Point(144, 11);
		this.#=zt7pW1CIU5LUe.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909115049);
		this.#=zt7pW1CIU5LUe.Size = new Size(100, 20);
		this.#=zt7pW1CIU5LUe.TabIndex = 6;
		this.#=z0_OI$vEecjj_.AutoSize = true;
		this.#=z0_OI$vEecjj_.Location = new Point(12, 14);
		this.#=z0_OI$vEecjj_.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909115036);
		this.#=z0_OI$vEecjj_.Size = new Size(106, 13);
		this.#=z0_OI$vEecjj_.TabIndex = 7;
		this.#=z0_OI$vEecjj_.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909115021);
		this.#=zuCaP$Fc=.Location = new Point(43, 87);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(75, 23);
		this.#=zuCaP$Fc=.TabIndex = 8;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112827);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		this.#=zHeAVXAs=.Location = new Point(144, 87);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 9;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel2;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zsrRuizRUiU6YUC3hQw==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zJiBnBkaEm1GZ7EFdqw==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zGJH6nGCm89aB);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zt7pW1CIU5LUe);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zuCaP$Fc=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=ziHFsfnvJd194);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=z0_OI$vEecjj_);
		this.#=zByiHPAwyKD$Q.Size = new Size(319, 649);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 523;
		this.#=zByiHPAwyKD$Q.TabIndex = 10;
		this.#=zGJH6nGCm89aB.Location = new Point(144, 37);
		this.#=zGJH6nGCm89aB.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114734);
		this.#=zGJH6nGCm89aB.Size = new Size(100, 20);
		this.#=zGJH6nGCm89aB.TabIndex = 6;
		this.#=ziHFsfnvJd194.AutoSize = true;
		this.#=ziHFsfnvJd194.Location = new Point(12, 40);
		this.#=ziHFsfnvJd194.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114706);
		this.#=ziHFsfnvJd194.Size = new Size(53, 13);
		this.#=ziHFsfnvJd194.TabIndex = 7;
		this.#=ziHFsfnvJd194.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114688);
		this.#=zJiBnBkaEm1GZ7EFdqw==.AutoSize = true;
		this.#=zJiBnBkaEm1GZ7EFdqw==.Location = new Point(15, 63);
		this.#=zJiBnBkaEm1GZ7EFdqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114672);
		this.#=zJiBnBkaEm1GZ7EFdqw==.Size = new Size(143, 17);
		this.#=zJiBnBkaEm1GZ7EFdqw==.TabIndex = 10;
		this.#=zJiBnBkaEm1GZ7EFdqw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114660);
		this.#=zJiBnBkaEm1GZ7EFdqw==.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(319, 649);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114631);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114631);
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.PerformLayout();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040008AC RID: 2220
	private BuildingPlanFrame #=zxnGiD$PUPFfP89kZUQ==;

	// Token: 0x040008AE RID: 2222
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=zsrRuizRUiU6YUC3hQw==;

	// Token: 0x040008AF RID: 2223
	private TextBox #=zt7pW1CIU5LUe;

	// Token: 0x040008B0 RID: 2224
	private Label #=z0_OI$vEecjj_;

	// Token: 0x040008B1 RID: 2225
	private Button #=zuCaP$Fc=;

	// Token: 0x040008B2 RID: 2226
	private Button #=zHeAVXAs=;

	// Token: 0x040008B3 RID: 2227
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x040008B4 RID: 2228
	private TextBox #=zGJH6nGCm89aB;

	// Token: 0x040008B5 RID: 2229
	private Label #=ziHFsfnvJd194;

	// Token: 0x040008B6 RID: 2230
	private CheckBox #=zJiBnBkaEm1GZ7EFdqw==;
}
