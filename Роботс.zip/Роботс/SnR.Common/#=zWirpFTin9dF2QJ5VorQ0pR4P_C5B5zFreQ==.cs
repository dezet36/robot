﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using Skink.SnR.Common;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020001C9 RID: 457
internal sealed class #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== : List<ProxyInfo>
{
	// Token: 0x06000D8C RID: 3468 RVA: 0x00069980 File Offset: 0x00067B80
	public #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==()
	{
		this.#=zgWw6qOKEp39Tj8C4nw== = new List<#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=>();
	}

	// Token: 0x06000D8D RID: 3469 RVA: 0x00069994 File Offset: 0x00067B94
	public void #=z48rEd0A=(ProxyInfo #=zsHG$Y6w=)
	{
		string proxyKey = #=zsHG$Y6w=.ProxyKey;
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].ProxyKey == proxyKey)
			{
				return;
			}
		}
		base.Add(#=zsHG$Y6w=);
	}

	// Token: 0x06000D8E RID: 3470 RVA: 0x000699D8 File Offset: 0x00067BD8
	public void #=zghsJ8VM=(IEnumerable<ProxyInfo> #=z47HdmrEE_7KL)
	{
		foreach (ProxyInfo #=zsHG$Y6w= in #=z47HdmrEE_7KL)
		{
			this.#=z48rEd0A=(#=zsHG$Y6w=);
		}
	}

	// Token: 0x06000D8F RID: 3471 RVA: 0x00069A20 File Offset: 0x00067C20
	public ProxyInfo #=zoLJcONCi11Oi()
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].Type == ProxyTypes.NoProxy)
			{
				return base[i];
			}
		}
		throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051829));
	}

	// Token: 0x06000D90 RID: 3472 RVA: 0x00069A64 File Offset: 0x00067C64
	public void #=zmIBGvrsO$QbW(ProxyInfo #=zsHG$Y6w=)
	{
		#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC();
		if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zoLzPtcVDz1OXV9drqA==() && #=zsHG$Y6w=.Type == ProxyTypes.DynamicAuto)
		{
			double num = 0.1;
			double num2 = 0.3;
			for (int i = this.#=zgWw6qOKEp39Tj8C4nw==.Count - 1; i >= 0; i--)
			{
				if (this.#=zgWw6qOKEp39Tj8C4nw==[i].#=zQp7G$cHwa5_v() < DateTime.Now - TimeSpan.FromHours(12.0))
				{
					this.#=zgWw6qOKEp39Tj8C4nw==.RemoveAt(i);
				}
			}
			#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= #=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= = null;
			for (int j = 0; j < this.#=zgWw6qOKEp39Tj8C4nw==.Count; j++)
			{
				if (this.#=zgWw6qOKEp39Tj8C4nw==[j].#=z_s$jh$GUqeKE() == #=zsHG$Y6w=.IP)
				{
					#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= = this.#=zgWw6qOKEp39Tj8C4nw==[j];
					break;
				}
			}
			if (#=zsHG$Y6w=.State == ProxyStates.Banned)
			{
				if (#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= != null)
				{
					#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=.#=zSKWZcgJ7CUhZ(DateTime.Now);
					return;
				}
				#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= #=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=2 = new #=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=();
				#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=2.#=zSKWZcgJ7CUhZ(DateTime.Now);
				#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=2.#=zFzxbBjqRMsSC(#=zsHG$Y6w=.IP);
				#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= = #=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=2;
				this.#=zgWw6qOKEp39Tj8C4nw==.Add(#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=);
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==2 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==;
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==2.#=zeK8uW$k$r3SqISDGBizDKLCXPH6E(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==2.#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC() + num);
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==3 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==;
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==3.#=z85QWZwOqZayxq6LoxcnelCWHl6xw(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==3.#=zxZUNpQr446iF4sFzC4IllHyNkuAk() + num);
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zcGgkwprFf4jMm6zoww==(true);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051776), new object[]
				{
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC(),
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxZUNpQr446iF4sFzC4IllHyNkuAk(),
					#=zsHG$Y6w=.IP,
					num
				});
				return;
			}
			else
			{
				if (#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E= != null)
				{
					this.#=zgWw6qOKEp39Tj8C4nw==.Remove(#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=);
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zkNpw_HkXGbLlGZ02xXjTauDMITO4() <= DateTime.Now - TimeSpan.FromHours(6.0) && #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC() + #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxZUNpQr446iF4sFzC4IllHyNkuAk() - num2 >= 10.0)
				{
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==4 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==;
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==4.#=zeK8uW$k$r3SqISDGBizDKLCXPH6E(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==4.#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC() - num2);
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==5 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==;
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==5.#=z85QWZwOqZayxq6LoxcnelCWHl6xw(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==5.#=zxZUNpQr446iF4sFzC4IllHyNkuAk() - num2);
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zcGgkwprFf4jMm6zoww==(true);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051402), new object[]
					{
						#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC(),
						#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zxZUNpQr446iF4sFzC4IllHyNkuAk(),
						num2
					});
				}
			}
		}
	}

	// Token: 0x06000D91 RID: 3473 RVA: 0x00069CA0 File Offset: 0x00067EA0
	public string #=zhv7OhlM=()
	{
		List<object> list = new List<object>();
		for (int i = 0; i < base.Count; i++)
		{
			ProxyInfo proxyInfo = base[i];
			if (proxyInfo.State != ProxyStates.Deleted)
			{
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				if (proxyInfo.Type != ProxyTypes.NoProxy)
				{
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051256)] = proxyInfo.IP;
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051249)] = proxyInfo.Port;
					if (!string.IsNullOrEmpty(proxyInfo.Login))
					{
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909078180)] = proxyInfo.Login;
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051244)] = proxyInfo.Password;
					}
				}
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)] = (int)proxyInfo.Type;
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = (int)proxyInfo.State;
				if (proxyInfo.IsUseForAuth)
				{
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051227)] = 1;
				}
				list.Add(dictionary);
			}
		}
		object[] array = new object[list.Count];
		list.CopyTo(array);
		return JSONManager.SerializeData(array).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051222), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051212) + Environment.NewLine + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205));
	}

	// Token: 0x06000D92 RID: 3474 RVA: 0x00069DFC File Offset: 0x00067FFC
	public bool #=z7YhN0h3LM3Il(string #=zqeYy9OXChYQn)
	{
		if (string.IsNullOrEmpty(#=zqeYy9OXChYQn))
		{
			return false;
		}
		if (!#=zqeYy9OXChYQn.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051197)))
		{
			return false;
		}
		bool result;
		try
		{
			foreach (Dictionary<string, object> dictionary in (object[])JSONManager.DeserializeData(#=zqeYy9OXChYQn))
			{
				ProxyInfo proxyInfo;
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909078180)))
				{
					proxyInfo = new ProxyInfo((ProxyTypes)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051256), string.Empty), JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051249), 0), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909078180), string.Empty), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051244), string.Empty));
				}
				else
				{
					proxyInfo = new ProxyInfo((ProxyTypes)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051256), string.Empty), JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051249), 0));
				}
				if (proxyInfo.Type == ProxyTypes.NoProxy)
				{
					proxyInfo = base.Find(new Predicate<ProxyInfo>(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zjXHA3p7u$ZWq46pYeZgiJjs=));
				}
				else
				{
					this.#=z48rEd0A=(proxyInfo);
				}
				proxyInfo.IsUseForAuth = (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051227), 0) == 1);
				proxyInfo.State = (ProxyStates)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
			}
			result = true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x06000D93 RID: 3475 RVA: 0x00069FA0 File Offset: 0x000681A0
	public static string #=zAxWFUyfvE3VT4Oukew==(string #=z5jgj46Y=)
	{
		List<string[]> list = new List<string[]>();
		foreach (string text in Directory.GetFiles(#=z5jgj46Y=))
		{
			string fileName = Path.GetFileName(text);
			foreach (object obj in Regex.Matches(#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051189)))
			{
				MatchCollection matchCollection = Regex.Matches(((Match)obj).Value, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051383));
				if (matchCollection.Count == 5)
				{
					bool flag = true;
					string[] array = new string[4];
					for (int j = 0; j < 4; j++)
					{
						int num;
						if (!int.TryParse(matchCollection[j].Value, out num))
						{
							flag = false;
						}
						if (num < 0 || num > 255)
						{
							flag = false;
						}
						array[j] = num.ToString();
					}
					string text2 = string.Join(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067993), array);
					int num2;
					if (!int.TryParse(matchCollection[4].Value, out num2))
					{
						flag = false;
					}
					if (num2 <= 0 || num2 >= 65536)
					{
						flag = false;
					}
					if (flag)
					{
						bool flag2 = false;
						for (int k = 0; k < list.Count; k++)
						{
							string[] array2 = list[k];
							if (array2[0] == text2 && array2[1] == num2.ToString() && array2[2] == fileName)
							{
								flag2 = true;
								break;
							}
						}
						if (!flag2)
						{
							list.Add(new string[]
							{
								text2,
								num2.ToString(),
								fileName
							});
						}
					}
				}
			}
		}
		list.Sort(new #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.#=z2ICO3Bs=());
		StringBuilder stringBuilder = new StringBuilder();
		for (int l = 0; l < list.Count; l++)
		{
			StringBuilder stringBuilder2 = stringBuilder;
			string format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051360);
			object[] args = list[l];
			stringBuilder2.AppendFormat(format, args);
			stringBuilder.AppendLine();
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000D94 RID: 3476 RVA: 0x0006A1BC File Offset: 0x000683BC
	private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA== #=zIDO$amMk1EWe()
	{
		if (this.#=zIWl_i8vsiZVh == null)
		{
			this.#=zIWl_i8vsiZVh = new #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==(this);
		}
		return this.#=zIWl_i8vsiZVh;
	}

	// Token: 0x06000D95 RID: 3477 RVA: 0x0006A1D8 File Offset: 0x000683D8
	public ProxyInfo #=zHYTbT9o3ZkEb()
	{
		return this.#=zIDO$amMk1EWe().#=zHYTbT9o3ZkEb();
	}

	// Token: 0x06000D96 RID: 3478 RVA: 0x0006A1E8 File Offset: 0x000683E8
	public ProxyInfo #=zBRHMDb8uMY1n()
	{
		return this.#=zIDO$amMk1EWe().#=zBRHMDb8uMY1n();
	}

	// Token: 0x06000D97 RID: 3479 RVA: 0x0006A1F8 File Offset: 0x000683F8
	public void #=zarxi$nsR5nh$2OfZZw==(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=zIDO$amMk1EWe().#=zarxi$nsR5nh$2OfZZw==(#=zsHG$Y6w=);
	}

	// Token: 0x06000D98 RID: 3480 RVA: 0x0006A208 File Offset: 0x00068408
	public void #=zCF48XOrkrCH5eTWGFRgk1tQ=(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=zIDO$amMk1EWe().#=zCF48XOrkrCH5eTWGFRgk1tQ=(#=zsHG$Y6w=);
	}

	// Token: 0x06000D99 RID: 3481 RVA: 0x0006A218 File Offset: 0x00068418
	public void #=zEto20VH$VX0Sc_GQAoDflTk=(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=zIDO$amMk1EWe().#=zEto20VH$VX0Sc_GQAoDflTk=(#=zsHG$Y6w=);
	}

	// Token: 0x040007C0 RID: 1984
	private List<#=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=> #=zgWw6qOKEp39Tj8C4nw==;

	// Token: 0x040007C1 RID: 1985
	private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA== #=zIWl_i8vsiZVh;

	// Token: 0x020001CA RID: 458
	private sealed class #=z2ICO3Bs= : IComparer<string[]>
	{
		// Token: 0x06000D9B RID: 3483 RVA: 0x0006A230 File Offset: 0x00068430
		public int Compare(string[] #=zm8PpuDU=, string[] #=zcltuPyw=)
		{
			int num = 0;
			for (int i = 0; i < #=zm8PpuDU=.Length; i++)
			{
				num = #=zm8PpuDU=[i].CompareTo(#=zcltuPyw=[i]);
				if (num != 0)
				{
					break;
				}
			}
			return num;
		}
	}

	// Token: 0x020001CB RID: 459
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000D9E RID: 3486 RVA: 0x0006A274 File Offset: 0x00068474
		internal bool #=zjXHA3p7u$ZWq46pYeZgiJjs=(ProxyInfo #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type == ProxyTypes.NoProxy;
		}

		// Token: 0x040007C2 RID: 1986
		public static readonly #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.#=zyDNvciU= #=zLkw0NRU= = new #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.#=zyDNvciU=();

		// Token: 0x040007C3 RID: 1987
		public static Predicate<ProxyInfo> #=zbuynFJ3dZqxYrumr6A==;
	}
}
