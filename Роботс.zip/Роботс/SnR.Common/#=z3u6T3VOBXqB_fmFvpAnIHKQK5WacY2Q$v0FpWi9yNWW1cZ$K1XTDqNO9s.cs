﻿using System;
using Skink.SnR.Common.Tasks;

// Token: 0x02000059 RID: 89
internal sealed class #=z3u6T3VOBXqB_fmFvpAnIHKQK5WacY2Q$v0FpWi9yNWW1cZ$K1XTDqNO9sRPd : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060002AA RID: 682 RVA: 0x000169BC File Offset: 0x00014BBC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x060002AB RID: 683 RVA: 0x000169C0 File Offset: 0x00014BC0
	protected override void #=zvb5bnug=()
	{
		bool flag;
		DateTime dateTime;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsSpreadByTime)
		{
			dateTime = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=ztENUqEM=(this.#=z8StzeqE=, this.#=zcDRV51Ut$7oP, out flag);
		}
		else
		{
			dateTime = DateTime.MinValue;
			flag = false;
		}
		if (dateTime != DateTime.MinValue)
		{
			if (flag)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923344), new object[]
				{
					dateTime
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923283), new object[]
				{
					dateTime
				});
			}
			this.#=zcDRV51Ut$7oP.ExecutionTime = dateTime;
			this.#=zcDRV51Ut$7oP.State = TaskStates.Rescheduled;
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
			return;
		}
		#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = null;
		bool flag2 = false;
		object #=zBCxv0_Eazs = this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zBCxv0_Eazs01;
		lock (#=zBCxv0_Eazs)
		{
			#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobbery);
			if (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= == null)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922979), Array.Empty<object>());
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = new #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=(this.#=zcDRV51Ut$7oP.RepeatDelayMin);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zaG9Dgn2hcyzWaAUsNA==(null);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=ziKpRrk$lWVCJhGJRcA==(null);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zfJg0zSfdHKGW$fTQAQ==(null);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zf2xpHQyExsx20x0Byg==(null);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zyUXiBfaJ5g4UiO5trA==(null);
				#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zGSYXNAWR258T(0);
				this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Add(#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=);
				flag2 = true;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922939), Array.Empty<object>());
			}
		}
		if (flag2)
		{
			#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zYx4FxxkdU5tE(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGV9CLmCENINvspF3MQ==(this.#=z8StzeqE=, this.#=zBsXSanI=));
		}
	}
}
