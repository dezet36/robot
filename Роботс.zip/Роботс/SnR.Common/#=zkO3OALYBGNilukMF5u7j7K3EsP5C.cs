﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x02000274 RID: 628
internal sealed class #=zkO3OALYBGNilukMF5u7j7K3EsP5C
{
	// Token: 0x060012F6 RID: 4854 RVA: 0x00092B7C File Offset: 0x00090D7C
	public #=zkO3OALYBGNilukMF5u7j7K3EsP5C(string #=z7sMfGqU=)
	{
		this.#=z7prY60beR35d(#=z7sMfGqU=);
		this.#=zJXS07AcRhHuf(new List<#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==>());
		this.#=zOtzPGIwlLT4wg_zgmA==(new List<string>());
	}

	// Token: 0x060012F7 RID: 4855 RVA: 0x00092BA4 File Offset: 0x00090DA4
	public string #=z5VV8Oo_dYzMg()
	{
		return this.#=zu5ZOMC2mmC4M5DCiVA==;
	}

	// Token: 0x060012F8 RID: 4856 RVA: 0x00092BAC File Offset: 0x00090DAC
	public void #=z7prY60beR35d(string #=z$Ib9gYQ=)
	{
		this.#=zu5ZOMC2mmC4M5DCiVA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060012F9 RID: 4857 RVA: 0x00092BB8 File Offset: 0x00090DB8
	public List<#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==> #=zbZ6OTR06cyHR()
	{
		return this.#=zYRSHKEd$gApcMnVi$g==;
	}

	// Token: 0x060012FA RID: 4858 RVA: 0x00092BC0 File Offset: 0x00090DC0
	public void #=zJXS07AcRhHuf(List<#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==> #=z$Ib9gYQ=)
	{
		this.#=zYRSHKEd$gApcMnVi$g== = #=z$Ib9gYQ=;
	}

	// Token: 0x060012FB RID: 4859 RVA: 0x00092BCC File Offset: 0x00090DCC
	public List<string> #=zY4i5cKgpca_jXrbzhA==()
	{
		return this.#=zPcfFoWk7Qw4Z6ImFcFyZ3qs=;
	}

	// Token: 0x060012FC RID: 4860 RVA: 0x00092BD4 File Offset: 0x00090DD4
	public void #=zOtzPGIwlLT4wg_zgmA==(List<string> #=z$Ib9gYQ=)
	{
		this.#=zPcfFoWk7Qw4Z6ImFcFyZ3qs= = #=z$Ib9gYQ=;
	}

	// Token: 0x060012FD RID: 4861 RVA: 0x00092BE0 File Offset: 0x00090DE0
	public static string #=z4FxeL2E=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zYgvZuBwR$a1C().ToString();
	}

	// Token: 0x060012FE RID: 4862 RVA: 0x00092BFC File Offset: 0x00090DFC
	public void #=zrUEQrg3CkNfVtOvihA==(ProxyInfo #=zsHG$Y6w=)
	{
		if (!this.#=zY4i5cKgpca_jXrbzhA==().Contains(#=zsHG$Y6w=.ProxyKey))
		{
			this.#=zbZ6OTR06cyHR().Add(new #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==(this, #=zsHG$Y6w=));
			this.#=zY4i5cKgpca_jXrbzhA==().Add(#=zsHG$Y6w=.ProxyKey);
		}
	}

	// Token: 0x060012FF RID: 4863 RVA: 0x00092C34 File Offset: 0x00090E34
	public #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zIllIrRIrMKHU(string #=z7UU1TwM=)
	{
		if (this.#=zY4i5cKgpca_jXrbzhA==().Contains(#=z7UU1TwM=))
		{
			for (int i = this.#=zbZ6OTR06cyHR().Count - 1; i >= 0; i--)
			{
				#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== = this.#=zbZ6OTR06cyHR()[i];
				if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=z9TrQaE7EBV1U().ProxyKey == #=z7UU1TwM=)
				{
					this.#=zbZ6OTR06cyHR().RemoveAt(i);
					this.#=zY4i5cKgpca_jXrbzhA==().Remove(#=z7UU1TwM=);
					return #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==;
				}
			}
		}
		return null;
	}

	// Token: 0x06001300 RID: 4864 RVA: 0x00092CA4 File Offset: 0x00090EA4
	public void #=z$8IxHBJ8gJKf(int #=zSPLDPE4=)
	{
		#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== = this.#=zbZ6OTR06cyHR()[#=zSPLDPE4=];
		this.#=zbZ6OTR06cyHR().RemoveAt(#=zSPLDPE4=);
		this.#=zY4i5cKgpca_jXrbzhA==().Remove(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=z9TrQaE7EBV1U().ProxyKey);
	}

	// Token: 0x04000AE4 RID: 2788
	private string #=zu5ZOMC2mmC4M5DCiVA==;

	// Token: 0x04000AE5 RID: 2789
	private List<#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==> #=zYRSHKEd$gApcMnVi$g==;

	// Token: 0x04000AE6 RID: 2790
	private List<string> #=zPcfFoWk7Qw4Z6ImFcFyZ3qs=;
}
