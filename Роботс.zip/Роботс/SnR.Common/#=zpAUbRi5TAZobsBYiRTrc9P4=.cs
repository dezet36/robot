﻿using System;

// Token: 0x020002A5 RID: 677
internal sealed class #=zpAUbRi5TAZobsBYiRTrc9P4= : #=z36JBXQyrOsCqlqj$QTz_Lzc=
{
	// Token: 0x06001490 RID: 5264 RVA: 0x0009CD0C File Offset: 0x0009AF0C
	internal override #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zZAPsYpRBEGf_()
	{
		return new #=zgJ0MGdKW7_OcG_XAvb6i$58=();
	}

	// Token: 0x06001491 RID: 5265 RVA: 0x0009CD14 File Offset: 0x0009AF14
	internal override #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zlyKJojCmkfuG()
	{
		return new #=zcryzuJdqHJDm55mRqseDxWYoSP9$();
	}
}
