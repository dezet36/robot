﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200017D RID: 381
internal sealed class #=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG
{
	// Token: 0x06000AED RID: 2797 RVA: 0x00054A2C File Offset: 0x00052C2C
	public #=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG(Dictionary<string, object> #=zR1k_w58=, int #=zyDqJEMk=)
	{
		this.#=zOxsGjgI=(#=zyDqJEMk=);
		this.#=zYS7PkdoDrCpC0BlM89GagLQ=(JSONManager.ExtractInt(#=zR1k_w58=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), 0));
		this.#=zFRyh0aFRzgCovXAwTbpaqkSaj8_bFJ94eQ==(new List<string>());
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zR1k_w58=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
		foreach (string text in dictionary.Keys)
		{
			Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, text);
			if (dictionary2 != null && JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 1) == 0)
			{
				this.#=ze_5Gu3r6BR53wz_FwfuqkZZnvzn$DYg4rw==().Add(text);
			}
		}
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x00054AE4 File Offset: 0x00052CE4
	public int #=zVr0Tzd0=()
	{
		return this.#=zEG$5kcHvvjQAA9Pjrw==;
	}

	// Token: 0x06000AEF RID: 2799 RVA: 0x00054AEC File Offset: 0x00052CEC
	public void #=zOxsGjgI=(int #=z$Ib9gYQ=)
	{
		this.#=zEG$5kcHvvjQAA9Pjrw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000AF0 RID: 2800 RVA: 0x00054AF8 File Offset: 0x00052CF8
	public int #=z88Q7U9qUgaUzi0CbXbqRFR4=()
	{
		return this.#=zK4EwQift5JAd9BUMxmUty5b16k2JHtvcEw==;
	}

	// Token: 0x06000AF1 RID: 2801 RVA: 0x00054B00 File Offset: 0x00052D00
	public void #=zYS7PkdoDrCpC0BlM89GagLQ=(int #=z$Ib9gYQ=)
	{
		this.#=zK4EwQift5JAd9BUMxmUty5b16k2JHtvcEw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000AF2 RID: 2802 RVA: 0x00054B0C File Offset: 0x00052D0C
	public List<string> #=ze_5Gu3r6BR53wz_FwfuqkZZnvzn$DYg4rw==()
	{
		return this.#=zKG5TX9FPkBfEdan9Pk03Ak1lNsvwPKF5vir8KlU=;
	}

	// Token: 0x06000AF3 RID: 2803 RVA: 0x00054B14 File Offset: 0x00052D14
	public void #=zFRyh0aFRzgCovXAwTbpaqkSaj8_bFJ94eQ==(List<string> #=z$Ib9gYQ=)
	{
		this.#=zKG5TX9FPkBfEdan9Pk03Ak1lNsvwPKF5vir8KlU= = #=z$Ib9gYQ=;
	}

	// Token: 0x040005D6 RID: 1494
	private int #=zEG$5kcHvvjQAA9Pjrw==;

	// Token: 0x040005D7 RID: 1495
	private int #=zK4EwQift5JAd9BUMxmUty5b16k2JHtvcEw==;

	// Token: 0x040005D8 RID: 1496
	private List<string> #=zKG5TX9FPkBfEdan9Pk03Ak1lNsvwPKF5vir8KlU=;
}
