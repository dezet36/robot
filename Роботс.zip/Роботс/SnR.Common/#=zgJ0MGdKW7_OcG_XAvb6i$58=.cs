﻿using System;

// Token: 0x02000244 RID: 580
internal sealed class #=zgJ0MGdKW7_OcG_XAvb6i$58= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x060011B4 RID: 4532 RVA: 0x00089F54 File Offset: 0x00088154
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z35BEnJ8=;
	}

	// Token: 0x060011B5 RID: 4533 RVA: 0x00089F5C File Offset: 0x0008815C
	internal override int #=zXiDCyaHY58$0()
	{
		return 4;
	}

	// Token: 0x060011B6 RID: 4534 RVA: 0x00089F60 File Offset: 0x00088160
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082);
	}
}
