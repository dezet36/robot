﻿using System;

// Token: 0x02000250 RID: 592
internal sealed class #=zh2F4SJfAgajggNn8He0yBNzii$$P
{
	// Token: 0x060011F2 RID: 4594 RVA: 0x0008A5A0 File Offset: 0x000887A0
	public #=zh2F4SJfAgajggNn8He0yBNzii$$P(#=z8CqmDxy_6zIaDbDlmPbraNb$YR7$fQXBrw== #=zrhvCoyA=)
	{
		this.#=z6WYOZiA=(#=zrhvCoyA=);
		this.#=zojHCQcuGBXly(null);
	}

	// Token: 0x060011F3 RID: 4595 RVA: 0x0008A5B8 File Offset: 0x000887B8
	public #=zh2F4SJfAgajggNn8He0yBNzii$$P(#=z8CqmDxy_6zIaDbDlmPbraNb$YR7$fQXBrw== #=zrhvCoyA=, #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zumeLTQI=)
	{
		this.#=z6WYOZiA=(#=zrhvCoyA=);
		this.#=zojHCQcuGBXly(#=zumeLTQI=);
	}

	// Token: 0x060011F4 RID: 4596 RVA: 0x0008A5D0 File Offset: 0x000887D0
	public #=z8CqmDxy_6zIaDbDlmPbraNb$YR7$fQXBrw== #=zZ_Vdevw=()
	{
		return this.#=zUyPZJFpCvLRcMQPxzQ==;
	}

	// Token: 0x060011F5 RID: 4597 RVA: 0x0008A5D8 File Offset: 0x000887D8
	public void #=z6WYOZiA=(#=z8CqmDxy_6zIaDbDlmPbraNb$YR7$fQXBrw== #=z$Ib9gYQ=)
	{
		this.#=zUyPZJFpCvLRcMQPxzQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011F6 RID: 4598 RVA: 0x0008A5E4 File Offset: 0x000887E4
	public #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zc8qEfLcp5D1z()
	{
		return this.#=zDaROUXHklYaNexJf9Q==;
	}

	// Token: 0x060011F7 RID: 4599 RVA: 0x0008A5EC File Offset: 0x000887EC
	public void #=zojHCQcuGBXly(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z$Ib9gYQ=)
	{
		this.#=zDaROUXHklYaNexJf9Q== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000A09 RID: 2569
	private #=z8CqmDxy_6zIaDbDlmPbraNb$YR7$fQXBrw== #=zUyPZJFpCvLRcMQPxzQ==;

	// Token: 0x04000A0A RID: 2570
	private #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zDaROUXHklYaNexJf9Q==;
}
