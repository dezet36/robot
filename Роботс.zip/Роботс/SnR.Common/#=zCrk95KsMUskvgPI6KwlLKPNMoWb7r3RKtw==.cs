﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x020000D7 RID: 215
internal sealed partial class #=zCrk95KsMUskvgPI6KwlLKPNMoWb7r3RKtw== : Form
{
	// Token: 0x060005C1 RID: 1473 RVA: 0x0002FC24 File Offset: 0x0002DE24
	public #=zCrk95KsMUskvgPI6KwlLKPNMoWb7r3RKtw==(#=zekGeYO3to2Fzt8dHc$KbhRWQexX_ #=zx9NCziM=)
	{
		this.#=zikFZo8g= = #=zx9NCziM=;
		this.#=zgpzgXirqPT5_();
		this.#=zMLOURYxvjceY.Text = this.#=zikFZo8g=.#=zqjHOR9Q=();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x0002FC58 File Offset: 0x0002DE58
	private void #=z1Jl2VQbCLxn23SgSmA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x0002FC80 File Offset: 0x0002DE80
	private void #=zgpzgXirqPT5_()
	{
		this.#=zPkSexJd1zHZV8qjTOw== = new SplitContainer();
		this.#=zMLOURYxvjceY = new TextBox();
		this.#=zXZtFvuFi5rLbGnsEjw== = new Button();
		((ISupportInitialize)this.#=zPkSexJd1zHZV8qjTOw==).BeginInit();
		this.#=zPkSexJd1zHZV8qjTOw==.Panel1.SuspendLayout();
		this.#=zPkSexJd1zHZV8qjTOw==.Panel2.SuspendLayout();
		this.#=zPkSexJd1zHZV8qjTOw==.SuspendLayout();
		base.SuspendLayout();
		this.#=zPkSexJd1zHZV8qjTOw==.Dock = DockStyle.Fill;
		this.#=zPkSexJd1zHZV8qjTOw==.FixedPanel = FixedPanel.Panel2;
		this.#=zPkSexJd1zHZV8qjTOw==.Location = new Point(0, 0);
		this.#=zPkSexJd1zHZV8qjTOw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087471);
		this.#=zPkSexJd1zHZV8qjTOw==.Orientation = Orientation.Horizontal;
		this.#=zPkSexJd1zHZV8qjTOw==.Panel1.Controls.Add(this.#=zMLOURYxvjceY);
		this.#=zPkSexJd1zHZV8qjTOw==.Panel2.Controls.Add(this.#=zXZtFvuFi5rLbGnsEjw==);
		this.#=zPkSexJd1zHZV8qjTOw==.Size = new Size(383, 261);
		this.#=zPkSexJd1zHZV8qjTOw==.SplitterDistance = 214;
		this.#=zPkSexJd1zHZV8qjTOw==.TabIndex = 0;
		this.#=zMLOURYxvjceY.Dock = DockStyle.Fill;
		this.#=zMLOURYxvjceY.Location = new Point(0, 0);
		this.#=zMLOURYxvjceY.Multiline = true;
		this.#=zMLOURYxvjceY.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087427);
		this.#=zMLOURYxvjceY.ReadOnly = true;
		this.#=zMLOURYxvjceY.ScrollBars = ScrollBars.Vertical;
		this.#=zMLOURYxvjceY.Size = new Size(383, 214);
		this.#=zMLOURYxvjceY.TabIndex = 0;
		this.#=zXZtFvuFi5rLbGnsEjw==.Location = new Point(305, 4);
		this.#=zXZtFvuFi5rLbGnsEjw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087407);
		this.#=zXZtFvuFi5rLbGnsEjw==.Size = new Size(75, 23);
		this.#=zXZtFvuFi5rLbGnsEjw==.TabIndex = 2;
		this.#=zXZtFvuFi5rLbGnsEjw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112299);
		this.#=zXZtFvuFi5rLbGnsEjw==.UseVisualStyleBackColor = true;
		this.#=zXZtFvuFi5rLbGnsEjw==.Click += this.#=z1Jl2VQbCLxn23SgSmA==;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(383, 261);
		base.Controls.Add(this.#=zPkSexJd1zHZV8qjTOw==);
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087360);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087081);
		this.#=zPkSexJd1zHZV8qjTOw==.Panel1.ResumeLayout(false);
		this.#=zPkSexJd1zHZV8qjTOw==.Panel1.PerformLayout();
		this.#=zPkSexJd1zHZV8qjTOw==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zPkSexJd1zHZV8qjTOw==).EndInit();
		this.#=zPkSexJd1zHZV8qjTOw==.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000264 RID: 612
	private #=zekGeYO3to2Fzt8dHc$KbhRWQexX_ #=zikFZo8g=;

	// Token: 0x04000266 RID: 614
	private SplitContainer #=zPkSexJd1zHZV8qjTOw==;

	// Token: 0x04000267 RID: 615
	private TextBox #=zMLOURYxvjceY;

	// Token: 0x04000268 RID: 616
	private Button #=zXZtFvuFi5rLbGnsEjw==;
}
