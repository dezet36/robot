﻿// Token: 0x02000276 RID: 630
internal sealed partial class #=zkcJffl91T$0cskgxwEqcyI7W$r7vkJcKRrAW_FED6qTx_SFjexiSos8= : global::System.Windows.Forms.Form
{
	// Token: 0x06001311 RID: 4881 RVA: 0x00093498 File Offset: 0x00091698
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000AF0 RID: 2800
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
