﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Security;
using Microsoft.Win32;

// Token: 0x020001E3 RID: 483
[SuppressUnmanagedCodeSecurity]
internal static class #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==
{
	// Token: 0x06000EA7 RID: 3751
	[DllImport("kernel32.dll", CharSet = CharSet.Auto, EntryPoint = "GetModuleHandle", ExactSpelling = true)]
	private static extern IntPtr #=zV68ZMNWEVu6m(string #=zsLjdoU4QAu30);

	// Token: 0x06000EA8 RID: 3752 RVA: 0x00075D3C File Offset: 0x00073F3C
	public static void #=z1jlGMrg=()
	{
		if (#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=z2p4u06JteMQodVXzkA==() || #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zLi0uSLTm$Hnu() || #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=z9QkGfNDQa3uU())
		{
			#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929906));
		}
	}

	// Token: 0x06000EA9 RID: 3753 RVA: 0x00075D64 File Offset: 0x00073F64
	private static bool #=z2p4u06JteMQodVXzkA==()
	{
		bool result;
		try
		{
			result = Enumerable.Any<string>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zDRXmPSXhr9wR, new Func<string, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=zMMOP90EA$t7Tvp9GQrzZ3V3Nv8Fk));
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAA RID: 3754 RVA: 0x00075DB4 File Offset: 0x00073FB4
	private static bool #=zLi0uSLTm$Hnu()
	{
		bool result;
		try
		{
			result = Enumerable.Any<Process>(Process.GetProcesses(), new Func<Process, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=z7ClcsBe_1W_0lYgqSsYLcGQ=));
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x00075E04 File Offset: 0x00074004
	private static bool #=z9QkGfNDQa3uU()
	{
		bool result;
		try
		{
			result = Enumerable.Any<string>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=z2xhBT_WVxkmL, new Func<string, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=z_LpCO_NxAk6hL$adPDFCzTY=));
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAC RID: 3756 RVA: 0x00075E54 File Offset: 0x00074054
	private static bool #=zSI5E1ITrtXcC()
	{
		bool result;
		try
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929876));
			try
			{
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					object obj = managementBaseObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929811)];
					string #=z53Gn0UQ= = ((obj != null) ? obj.ToString() : null) ?? string.Empty;
					object obj2 = managementBaseObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929798)];
					string #=z53Gn0UQ=2 = ((obj2 != null) ? obj2.ToString() : null) ?? string.Empty;
					if (#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zl$N3cYQXl3teWYGcG_XIyYs=(#=z53Gn0UQ=) || #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zl$N3cYQXl3teWYGcG_XIyYs=(#=z53Gn0UQ=2))
					{
						return true;
					}
				}
			}
			finally
			{
				((IDisposable)managementObjectSearcher).Dispose();
			}
			ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930034));
			try
			{
				foreach (ManagementBaseObject managementBaseObject2 in managementObjectSearcher2.Get())
				{
					object obj3 = managementBaseObject2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929992)];
					if (#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zl$N3cYQXl3teWYGcG_XIyYs=(((obj3 != null) ? obj3.ToString() : null) ?? string.Empty))
					{
						return true;
					}
				}
			}
			finally
			{
				((IDisposable)managementObjectSearcher2).Dispose();
			}
			ManagementObjectSearcher managementObjectSearcher3 = new ManagementObjectSearcher(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929983));
			try
			{
				foreach (ManagementBaseObject managementBaseObject3 in managementObjectSearcher3.Get())
				{
					object obj4 = managementBaseObject3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929923)];
					if (#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zl$N3cYQXl3teWYGcG_XIyYs=(((obj4 != null) ? obj4.ToString() : null) ?? string.Empty))
					{
						return true;
					}
				}
			}
			finally
			{
				((IDisposable)managementObjectSearcher3).Dispose();
			}
			result = false;
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAD RID: 3757 RVA: 0x000760A8 File Offset: 0x000742A8
	private static bool #=z26HXCCKumSCm()
	{
		bool result;
		try
		{
			result = Enumerable.Any<DriveInfo>(Enumerable.Where<DriveInfo>(DriveInfo.GetDrives(), new Func<DriveInfo, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=z15oW9CDG$6Lx3UJdujqsr0c=)), new Func<DriveInfo, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=zgyAFXt8VapsU2bHDFRTcisk=));
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAE RID: 3758 RVA: 0x0007611C File Offset: 0x0007431C
	private static bool #=zEaKhoBRV112x()
	{
		bool result;
		try
		{
			result = Enumerable.Any<NetworkInterface>(NetworkInterface.GetAllNetworkInterfaces(), new Func<NetworkInterface, bool>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=.#=zLkw0NRU=.#=z6QvAo371tG8KpWjojg_vya8=));
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000EAF RID: 3759 RVA: 0x0007616C File Offset: 0x0007436C
	private static bool #=zl$N3cYQXl3teWYGcG_XIyYs=(string #=z53Gn0UQ=)
	{
		#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zbjP7ZBivanWUvybn8iffczU= #=zbjP7ZBivanWUvybn8iffczU= = new #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zbjP7ZBivanWUvybn8iffczU=();
		#=zbjP7ZBivanWUvybn8iffczU=.#=z53Gn0UQ= = #=z53Gn0UQ=;
		return Enumerable.Any<string>(new string[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929649),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929634),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929628),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929611),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929606),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929584),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929568)
		}, new Func<string, bool>(#=zbjP7ZBivanWUvybn8iffczU=.#=zQk3cwrv7XE7M5i414S85ticoC8JLoG$RUw==));
	}

	// Token: 0x0400082E RID: 2094
	private static readonly string[] #=zDRXmPSXhr9wR = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928507),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928494),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928477),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928450),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928432)
	};

	// Token: 0x0400082F RID: 2095
	private static readonly string[] #=zkLWOZJd6F8j_ = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928421),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928395),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928122),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928107),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928090)
	};

	// Token: 0x04000830 RID: 2096
	private static readonly string[] #=z2xhBT_WVxkmL = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928075),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928024),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928241)
	};

	// Token: 0x04000831 RID: 2097
	private static readonly string[] #=z0$8RAtZSWj7IybH_tA== = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928199),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928182),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928161),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928144),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928131)
	};

	// Token: 0x020001E4 RID: 484
	private sealed class #=zbjP7ZBivanWUvybn8iffczU=
	{
		// Token: 0x06000EB1 RID: 3761 RVA: 0x00076200 File Offset: 0x00074400
		internal bool #=zQk3cwrv7XE7M5i414S85ticoC8JLoG$RUw==(string #=zH2f5zJg=)
		{
			return this.#=z53Gn0UQ=.IndexOf(#=zH2f5zJg=, StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x04000832 RID: 2098
		public string #=z53Gn0UQ=;
	}

	// Token: 0x020001E5 RID: 485
	private sealed class #=zekSnAAzuYRupoZBev2r8$yM=
	{
		// Token: 0x06000EB3 RID: 3763 RVA: 0x00076220 File Offset: 0x00074420
		internal bool #=ziq3Jr6U3ritT6ob4k66moxk=(string #=zEqyksG4=)
		{
			return this.#=zH87pW10=.GetPhysicalAddress().ToString().StartsWith(#=zEqyksG4=.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), string.Empty));
		}

		// Token: 0x04000833 RID: 2099
		public NetworkInterface #=zH87pW10=;
	}

	// Token: 0x020001E6 RID: 486
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000EB6 RID: 3766 RVA: 0x00076260 File Offset: 0x00074460
		internal bool #=zMMOP90EA$t7Tvp9GQrzZ3V3Nv8Fk(string #=zfmm48Sw=)
		{
			return #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zV68ZMNWEVu6m(#=zfmm48Sw=) != IntPtr.Zero;
		}

		// Token: 0x06000EB7 RID: 3767 RVA: 0x00076274 File Offset: 0x00074474
		internal bool #=z7ClcsBe_1W_0lYgqSsYLcGQ=(Process #=z6Q8LaXo=)
		{
			return Enumerable.Contains<string>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zkLWOZJd6F8j_, #=z6Q8LaXo=.ProcessName, StringComparer.OrdinalIgnoreCase);
		}

		// Token: 0x06000EB8 RID: 3768 RVA: 0x0007628C File Offset: 0x0007448C
		internal bool #=z_LpCO_NxAk6hL$adPDFCzTY=(string #=zNraCe1Y=)
		{
			return Registry.LocalMachine.OpenSubKey(#=zNraCe1Y=) != null;
		}

		// Token: 0x06000EB9 RID: 3769 RVA: 0x0007629C File Offset: 0x0007449C
		internal bool #=z15oW9CDG$6Lx3UJdujqsr0c=(DriveInfo #=zdqSpY9Q=)
		{
			return #=zdqSpY9Q=.DriveType == DriveType.Fixed;
		}

		// Token: 0x06000EBA RID: 3770 RVA: 0x000762A8 File Offset: 0x000744A8
		internal bool #=zgyAFXt8VapsU2bHDFRTcisk=(DriveInfo #=zdqSpY9Q=)
		{
			return #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zl$N3cYQXl3teWYGcG_XIyYs=(#=zdqSpY9Q=.VolumeLabel);
		}

		// Token: 0x06000EBB RID: 3771 RVA: 0x000762B8 File Offset: 0x000744B8
		internal bool #=z6QvAo371tG8KpWjojg_vya8=(NetworkInterface #=zH87pW10=)
		{
			#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zekSnAAzuYRupoZBev2r8$yM= #=zekSnAAzuYRupoZBev2r8$yM= = new #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zekSnAAzuYRupoZBev2r8$yM=();
			#=zekSnAAzuYRupoZBev2r8$yM=.#=zH87pW10= = #=zH87pW10=;
			return Enumerable.Any<string>(#=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=z0$8RAtZSWj7IybH_tA==, new Func<string, bool>(#=zekSnAAzuYRupoZBev2r8$yM=.#=ziq3Jr6U3ritT6ob4k66moxk=));
		}

		// Token: 0x04000834 RID: 2100
		public static readonly #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU= #=zLkw0NRU= = new #=zYUiwi8xMSciGwrY$RYC27YYgGM7VHoQVAA==.#=zyDNvciU=();

		// Token: 0x04000835 RID: 2101
		public static Func<string, bool> #=zbuynFJ3dZqxYrumr6A==;

		// Token: 0x04000836 RID: 2102
		public static Func<Process, bool> #=zd0BKI0I4rEEqgEDUZw==;

		// Token: 0x04000837 RID: 2103
		public static Func<string, bool> #=zLLcqwWqPPIJnz60lVA==;

		// Token: 0x04000838 RID: 2104
		public static Func<DriveInfo, bool> #=z6kaS0hT02rVUCvrtZA==;

		// Token: 0x04000839 RID: 2105
		public static Func<DriveInfo, bool> #=zWzAzXv2VAShUkmhntw==;

		// Token: 0x0400083A RID: 2106
		public static Func<NetworkInterface, bool> #=zbaoW3zbmp2urVzSQ6A==;
	}
}
