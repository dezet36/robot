﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;

// Token: 0x020000E2 RID: 226
internal sealed class #=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000605 RID: 1541 RVA: 0x000311A4 File Offset: 0x0002F3A4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=z6Bha1HM= = #=zuJjQ1XU=.#=z6Kl4FbeUhsIC();
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x000311C0 File Offset: 0x0002F3C0
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		this.#=zZGTxcJrfYmIYxEYe1xiE3O4=(#=zcTyyNys=, false);
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x000311F0 File Offset: 0x0002F3F0
	private bool #=zWo6XFtUfx_xc4ySSDQ==(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys=, out string #=zIapFsKF23kqB)
	{
		bool result = false;
		#=zIapFsKF23kqB = null;
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z3TrxKisw7nyXMkOe5PjuvHk=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUseStandardBuildingsTemplate);
		if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== != null)
		{
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2 = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
			#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zFY9ihF5o2BCdfI$ovxZVFdA=(this.#=z8StzeqE=, this.#=zBsXSanI=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==, this.#=z6Bha1HM=, this.#=z1pahAF0JqdFM8mgjDQ==, out #=zIapFsKF23kqB);
			if (!string.IsNullOrEmpty(#=zIapFsKF23kqB))
			{
				base.#=zL1HTbwC75LO$(#=zIapFsKF23kqB);
			}
			foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==)
			{
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4() == #=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId)
				{
					bool flag = false;
					foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 in this.#=z1pahAF0JqdFM8mgjDQ==)
					{
						if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFMDiymuLQ7_4() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4() && #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=z_ffm9$kcf9Y8EY_3cw==() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z_ffm9$kcf9Y8EY_3cw==())
						{
							if (GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=())
							{
								if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zlSY2GGkBa6S3MkHuDQ==() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zlSY2GGkBa6S3MkHuDQ==())
								{
									flag = true;
									break;
								}
							}
							else if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zfTB62qendhk_VEy8rw==() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zfTB62qendhk_VEy8rw==() && #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zY0soxphmGIACbOHy6A==() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zY0soxphmGIACbOHy6A==())
							{
								flag = true;
								break;
							}
						}
					}
					if (!flag && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() != null)
					{
						#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
					}
				}
			}
			if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Count > 0)
			{
				using (List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>.Enumerator enumerator = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn3 = enumerator.Current;
						string text = this.#=zBsXSanI=.#=zQ3GmQEFE_q6Y(#=zO6457TajDDxDJIsKqS1bbzDMLckn3, true);
						if (text.Length < 10000)
						{
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926446), new object[]
								{
									#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zkfqcY3I=()
								});
							}
							else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926365)) && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926336)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926041), new object[]
								{
									#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zkfqcY3I=()
								});
							}
							else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925958)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926178), new object[]
								{
									#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zkfqcY3I=()
								});
							}
							else
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926081), new object[]
								{
									#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zkfqcY3I=(),
									text
								});
							}
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976953), new object[]
							{
								#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zkfqcY3I=()
							});
							result = true;
							#=zIapFsKF23kqB = text;
						}
					}
					return result;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976900), Array.Empty<object>());
			result = true;
		}
		return result;
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x0003157C File Offset: 0x0002F77C
	private void #=zZGTxcJrfYmIYxEYe1xiE3O4=(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys=, bool #=zee39xHLnNEcnx3VAlA==)
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = this.#=z1pahAF0JqdFM8mgjDQ==;
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>();
		for (int i = 0; i < #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count; i++)
		{
			#=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP.#=zAzqsXKU9G9G$qkIMsw== #=zAzqsXKU9G9G$qkIMsw== = new #=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP.#=zAzqsXKU9G9G$qkIMsw==();
			#=zAzqsXKU9G9G$qkIMsw==.#=zUOCbBE7lBfRpv5tNuA== = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==[i];
			if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==[i].#=zFMDiymuLQ7_4() == #=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId)
			{
				bool flag = false;
				int num = (int)#=zcTyyNys=.#=zXFnsTSimqiPo().Effect;
				if (num > 0)
				{
					List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zAzqsXKU9G9G$qkIMsw==.#=zR3P7kRfZKIIAav$XwpcsS4D84zTQ));
					list2.Sort(new Comparison<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP.#=zyDNvciU=.#=zLkw0NRU=.#=zzCIhb5ykE1pyR19IhUL08mr7mo86cyRYog==));
					for (int j = num; j < list2.Count; j++)
					{
						if (list2[j].#=zMuFMjGQ=() == #=zAzqsXKU9G9G$qkIMsw==.#=zUOCbBE7lBfRpv5tNuA==.#=zMuFMjGQ=())
						{
							flag = true;
							break;
						}
					}
				}
				if (!flag)
				{
					list.Add(#=zAzqsXKU9G9G$qkIMsw==.#=zUOCbBE7lBfRpv5tNuA==);
				}
			}
		}
		string text;
		if (list.Count == 0 && !#=zee39xHLnNEcnx3VAlA== && this.#=zWo6XFtUfx_xc4ySSDQ==(#=zcTyyNys=, out text))
		{
			if (!string.IsNullOrEmpty(text))
			{
				base.#=zL1HTbwC75LO$(text);
			}
			this.#=zZGTxcJrfYmIYxEYe1xiE3O4=(#=zcTyyNys=, true);
			return;
		}
		for (int k = 0; k < list.Count; k++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = list[k];
			int amount = #=zcTyyNys=.#=zXFnsTSimqiPo().Amount;
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() < amount)
			{
				for (int l = #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du(); l < amount; l++)
				{
					string text2 = this.#=zBsXSanI=.#=zDqCpkITFJ_yR(#=zO6457TajDDxDJIsKqS1bbzDMLckn, true);
					if (text2.Length <= 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976753), new object[]
						{
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=(),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du(),
							JSONManager.Cut(text2)
						});
						break;
					}
					#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn;
					int num2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zvnZc$RhG_1Du();
					#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFzGvi_S6jJhE(num2 + 1);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977084), new object[]
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=(),
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du()
					});
				}
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976667), new object[]
				{
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=(),
					amount
				});
			}
		}
	}

	// Token: 0x0400027C RID: 636
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x0400027D RID: 637
	private int #=z6Bha1HM=;

	// Token: 0x020000E3 RID: 227
	private sealed class #=zAzqsXKU9G9G$qkIMsw==
	{
		// Token: 0x0600060A RID: 1546 RVA: 0x00031800 File Offset: 0x0002FA00
		internal bool #=zR3P7kRfZKIIAav$XwpcsS4D84zTQ(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zUOCbBE7lBfRpv5tNuA==.#=zFMDiymuLQ7_4();
		}

		// Token: 0x0400027E RID: 638
		public #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==;
	}

	// Token: 0x020000E4 RID: 228
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600060D RID: 1549 RVA: 0x0003182C File Offset: 0x0002FA2C
		internal int #=zzCIhb5ykE1pyR19IhUL08mr7mo86cyRYog==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zm8PpuDU=, #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
			{
				#=zcltuPyw=.#=zvnZc$RhG_1Du().CompareTo(#=zm8PpuDU=.#=zvnZc$RhG_1Du()),
				#=zcltuPyw=.#=z5kpAZQpjT2b7().CompareTo(#=zm8PpuDU=.#=z5kpAZQpjT2b7()),
				#=zm8PpuDU=.#=zMuFMjGQ=().CompareTo(#=zcltuPyw=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x0400027F RID: 639
		public static readonly #=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP.#=zyDNvciU= #=zLkw0NRU= = new #=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP.#=zyDNvciU=();

		// Token: 0x04000280 RID: 640
		public static Comparison<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=znz6v2HKWHp3FVkwXIA==;
	}
}
