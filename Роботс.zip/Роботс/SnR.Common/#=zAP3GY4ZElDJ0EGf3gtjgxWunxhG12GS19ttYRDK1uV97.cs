﻿using System;
using Skink.SnR.Common.Tasks;

// Token: 0x020000BA RID: 186
internal sealed class #=zAP3GY4ZElDJ0EGf3gtjgxWunxhG12GS19ttYRDK1uV97 : Task
{
	// Token: 0x060004ED RID: 1261 RVA: 0x0002814C File Offset: 0x0002634C
	public #=zAP3GY4ZElDJ0EGf3gtjgxWunxhG12GS19ttYRDK1uV97(DateTime #=zxSBcx18=) : base(TaskSources.ManualNotSavable, TaskSeverities.Background, TaskTypes.RecallAllTroops, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.FromMilliseconds(10.0), TimeSpan.FromMilliseconds(10.0), DateTime.MaxValue, true)
	{
		this.#=z4kPU_Y9aocKT_50v6Zyh$5WjtkiP(0);
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x00028194 File Offset: 0x00026394
	public int #=z1woUsR6tmZUXOxdONCto1abUIE97()
	{
		return this.#=zhvVtio5DGzUQ9jD_pdRqS_tyqJ48HZpFZA==;
	}

	// Token: 0x060004EF RID: 1263 RVA: 0x0002819C File Offset: 0x0002639C
	public void #=z4kPU_Y9aocKT_50v6Zyh$5WjtkiP(int #=z$Ib9gYQ=)
	{
		this.#=zhvVtio5DGzUQ9jD_pdRqS_tyqJ48HZpFZA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040001E6 RID: 486
	private int #=zhvVtio5DGzUQ9jD_pdRqS_tyqJ48HZpFZA==;
}
