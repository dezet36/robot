﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x0200009F RID: 159
internal sealed class #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==
{
	// Token: 0x06000440 RID: 1088 RVA: 0x000249C4 File Offset: 0x00022BC4
	public #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=z47HdmrEE_7KL)
	{
		this.#=zZHpYil2AFaMtRVmizw== = #=z47HdmrEE_7KL;
		this.#=zkKJigFQ= = 0;
		this.#=za7tcIUD2p4E1 = new Dictionary<string, #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks=>();
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x000249E8 File Offset: 0x00022BE8
	public ProxyInfo #=zHYTbT9o3ZkEb()
	{
		int num = this.#=zkKJigFQ=;
		ProxyInfo proxyInfo = null;
		bool flag = false;
		while (proxyInfo == null)
		{
			if (this.#=zkKJigFQ= < this.#=zZHpYil2AFaMtRVmizw==.Count)
			{
				ProxyInfo proxyInfo2 = this.#=zZHpYil2AFaMtRVmizw==[this.#=zkKJigFQ=];
				if (proxyInfo2.IsUseForAuth)
				{
					flag = true;
					if (this.#=zpFCvXfvlsieR(proxyInfo2) == (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0)
					{
						proxyInfo = proxyInfo2;
					}
				}
			}
			this.#=zkKJigFQ=++;
			if (this.#=zkKJigFQ= >= this.#=zZHpYil2AFaMtRVmizw==.Count)
			{
				this.#=zkKJigFQ= = 0;
			}
			if (this.#=zkKJigFQ= == num)
			{
				break;
			}
		}
		if (proxyInfo == null && !flag)
		{
			ProxyInfo proxyInfo3 = this.#=zZHpYil2AFaMtRVmizw==.#=zoLJcONCi11Oi();
			if (this.#=zpFCvXfvlsieR(proxyInfo3) == (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0)
			{
				proxyInfo = proxyInfo3;
			}
		}
		return proxyInfo;
	}

	// Token: 0x06000442 RID: 1090 RVA: 0x00024A90 File Offset: 0x00022C90
	public ProxyInfo #=zBRHMDb8uMY1n()
	{
		int num = this.#=zkKJigFQ=;
		ProxyInfo proxyInfo = null;
		while (proxyInfo == null)
		{
			ProxyInfo proxyInfo2 = this.#=zZHpYil2AFaMtRVmizw==[this.#=zkKJigFQ=];
			if (this.#=zVK93myjFXBea(proxyInfo2) == (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0)
			{
				proxyInfo = proxyInfo2;
			}
			this.#=zkKJigFQ=++;
			if (this.#=zkKJigFQ= >= this.#=zZHpYil2AFaMtRVmizw==.Count)
			{
				this.#=zkKJigFQ= = 0;
			}
			if (this.#=zkKJigFQ= == num)
			{
				break;
			}
		}
		return proxyInfo;
	}

	// Token: 0x06000443 RID: 1091 RVA: 0x00024AFC File Offset: 0x00022CFC
	private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t #=zpFCvXfvlsieR(ProxyInfo #=zsHG$Y6w=)
	{
		if (this.#=za7tcIUD2p4E1.ContainsKey(#=zsHG$Y6w=.ProxyKey))
		{
			#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks= #=zIyIe_Ks= = this.#=za7tcIUD2p4E1[#=zsHG$Y6w=.ProxyKey];
			if (#=zIyIe_Ks=.#=zfjf8CCcKM0cZ() != (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0 && #=zIyIe_Ks=.#=zdU00esJzPFE$SZe8SQ==() < DateTime.Now - TimeSpan.FromMinutes(60.0))
			{
				#=zIyIe_Ks=.#=zxWkn0yCcjVkU((#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0);
				#=zIyIe_Ks=.#=zJlxBmAppx6RpZRXmAA==(DateTime.MinValue);
			}
			return #=zIyIe_Ks=.#=zfjf8CCcKM0cZ();
		}
		return (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0;
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x00024B78 File Offset: 0x00022D78
	private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk #=zVK93myjFXBea(ProxyInfo #=zsHG$Y6w=)
	{
		if (this.#=za7tcIUD2p4E1.ContainsKey(#=zsHG$Y6w=.ProxyKey))
		{
			#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks= #=zIyIe_Ks= = this.#=za7tcIUD2p4E1[#=zsHG$Y6w=.ProxyKey];
			if (#=zIyIe_Ks=.#=zEW4TQNoDfNUf() != (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0 && #=zIyIe_Ks=.#=zMh620xB6YHWcbnfccg==() < DateTime.Now - TimeSpan.FromMinutes(60.0))
			{
				#=zIyIe_Ks=.#=zQt$1LaQ_Lu5y((#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0);
				#=zIyIe_Ks=.#=zczd$5TWlQa1XBTFXrw==(DateTime.MinValue);
			}
			return #=zIyIe_Ks=.#=zEW4TQNoDfNUf();
		}
		return (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0;
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x00024BF4 File Offset: 0x00022DF4
	public void #=zarxi$nsR5nh$2OfZZw==(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=z6QjjZP7cebmC(#=zsHG$Y6w=, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)1, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0);
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x00024C00 File Offset: 0x00022E00
	public void #=zCF48XOrkrCH5eTWGFRgk1tQ=(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=z6QjjZP7cebmC(#=zsHG$Y6w=, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)2, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0);
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x00024C0C File Offset: 0x00022E0C
	public void #=zEto20VH$VX0Sc_GQAoDflTk=(ProxyInfo #=zsHG$Y6w=)
	{
		this.#=z6QjjZP7cebmC(#=zsHG$Y6w=, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0, (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)1);
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00024C18 File Offset: 0x00022E18
	private void #=z6QjjZP7cebmC(ProxyInfo #=zsHG$Y6w=, #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t #=zOLvrdEA=, #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk #=zL2l59TE=)
	{
		#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks= #=zIyIe_Ks=;
		if (this.#=za7tcIUD2p4E1.ContainsKey(#=zsHG$Y6w=.ProxyKey))
		{
			#=zIyIe_Ks= = this.#=za7tcIUD2p4E1[#=zsHG$Y6w=.ProxyKey];
		}
		else
		{
			#=zIyIe_Ks= = new #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks=();
			this.#=za7tcIUD2p4E1[#=zsHG$Y6w=.ProxyKey] = #=zIyIe_Ks=;
		}
		if (#=zOLvrdEA= != (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0)
		{
			#=zIyIe_Ks=.#=zxWkn0yCcjVkU(#=zOLvrdEA=);
			#=zIyIe_Ks=.#=zJlxBmAppx6RpZRXmAA==(DateTime.Now);
		}
		if (#=zL2l59TE= != (#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0)
		{
			#=zIyIe_Ks=.#=zQt$1LaQ_Lu5y(#=zL2l59TE=);
			#=zIyIe_Ks=.#=zczd$5TWlQa1XBTFXrw==(DateTime.Now);
		}
	}

	// Token: 0x0400018E RID: 398
	private int #=zkKJigFQ=;

	// Token: 0x0400018F RID: 399
	private #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zZHpYil2AFaMtRVmizw==;

	// Token: 0x04000190 RID: 400
	private Dictionary<string, #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zIyIe_Ks=> #=za7tcIUD2p4E1;

	// Token: 0x020000A0 RID: 160
	internal enum #=z1qLgzm2yCe6t
	{

	}

	// Token: 0x020000A1 RID: 161
	internal enum #=zAwGQkjosK$Nk
	{

	}

	// Token: 0x020000A2 RID: 162
	internal sealed class #=zIyIe_Ks=
	{
		// Token: 0x06000449 RID: 1097 RVA: 0x00024C90 File Offset: 0x00022E90
		public #=zIyIe_Ks=()
		{
			this.#=zxWkn0yCcjVkU((#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t)0);
			this.#=zJlxBmAppx6RpZRXmAA==(DateTime.MinValue);
			this.#=zQt$1LaQ_Lu5y((#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk)0);
			this.#=zczd$5TWlQa1XBTFXrw==(DateTime.MinValue);
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x00024CBC File Offset: 0x00022EBC
		public #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t #=zfjf8CCcKM0cZ()
		{
			return this.#=zPbxX5RK8EQfVoi$_wA==;
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00024CC4 File Offset: 0x00022EC4
		public void #=zxWkn0yCcjVkU(#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t #=z$Ib9gYQ=)
		{
			this.#=zPbxX5RK8EQfVoi$_wA== = #=z$Ib9gYQ=;
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00024CD0 File Offset: 0x00022ED0
		public DateTime #=zdU00esJzPFE$SZe8SQ==()
		{
			return this.#=zZ39OffgJ5hEky7lsABMd8p4=;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x00024CD8 File Offset: 0x00022ED8
		public void #=zJlxBmAppx6RpZRXmAA==(DateTime #=z$Ib9gYQ=)
		{
			this.#=zZ39OffgJ5hEky7lsABMd8p4= = #=z$Ib9gYQ=;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00024CE4 File Offset: 0x00022EE4
		public #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk #=zEW4TQNoDfNUf()
		{
			return this.#=zWf80RBiPxmDrL_jVOw==;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x00024CEC File Offset: 0x00022EEC
		public void #=zQt$1LaQ_Lu5y(#=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk #=z$Ib9gYQ=)
		{
			this.#=zWf80RBiPxmDrL_jVOw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x00024CF8 File Offset: 0x00022EF8
		public DateTime #=zMh620xB6YHWcbnfccg==()
		{
			return this.#=zo6Z1jZD$WoLXahzZdB3fChQ=;
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x00024D00 File Offset: 0x00022F00
		public void #=zczd$5TWlQa1XBTFXrw==(DateTime #=z$Ib9gYQ=)
		{
			this.#=zo6Z1jZD$WoLXahzZdB3fChQ= = #=z$Ib9gYQ=;
		}

		// Token: 0x04000193 RID: 403
		private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=z1qLgzm2yCe6t #=zPbxX5RK8EQfVoi$_wA==;

		// Token: 0x04000194 RID: 404
		private DateTime #=zZ39OffgJ5hEky7lsABMd8p4=;

		// Token: 0x04000195 RID: 405
		private #=z8AT1b5fZD6TSCskuNIUUuQ5q21JKUtcdkA==.#=zAwGQkjosK$Nk #=zWf80RBiPxmDrL_jVOw==;

		// Token: 0x04000196 RID: 406
		private DateTime #=zo6Z1jZD$WoLXahzZdB3fChQ=;
	}
}
