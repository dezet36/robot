﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000215 RID: 533
internal sealed class #=zcJaILoueQx4ziYZOhsGXTecvP6_jn8VlbKSw8bMt3_sTBGwotg== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001053 RID: 4179 RVA: 0x0007E204 File Offset: 0x0007C404
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zbkd1_SL26Bt5 = #=zuJjQ1XU=.#=zTbkv095gWozyg_xVnw==();
		this.#=zs$0ZsWySJz6C = #=zuJjQ1XU=.#=z9Jm$ne_kr_H5D_R8UQ==();
	}

	// Token: 0x06001054 RID: 4180 RVA: 0x0007E22C File Offset: 0x0007C42C
	protected override void #=zvb5bnug=()
	{
		#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSFXFmKINPah26TjROQ==(this.#=z8StzeqE=, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zbkd1_SL26Bt5);
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962750), new object[]
		{
			#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==().Count,
			#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zYkDcCtJRo4Kt()
		});
		if (#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=z27qU0v2nVbmq() != 0 || #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zaNJ233J3hmDJ() != 0 || #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zWiYm5yGEKz9k() != 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962694), new object[]
			{
				#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=z27qU0v2nVbmq(),
				#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zaNJ233J3hmDJ(),
				#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zWiYm5yGEKz9k()
			});
		}
		if (#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zZEc75Ho=() != null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zZEc75Ho=());
		}
		if (#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==().Count > 0)
		{
			int num = 2 - this.#=zs$0ZsWySJz6C;
			List<int> list = new List<int>();
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962371), new object[]
			{
				num
			});
			int num2 = 0;
			while (num2 < #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==().Count && num > 0)
			{
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==()[num2];
				if (!list.Contains(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_()) && !#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().#=zsQC8qhbaqVU5q6hkHg==())
				{
					if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=z15ufqu6UkMD2(this.#=z8StzeqE=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=))
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(this.#=z8StzeqE=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_().ToString(), true, this.#=zBsXSanI=);
						string text = (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null) ? #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=() : #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_().ToString();
						string text2 = this.#=zBsXSanI=.#=zjvkC2AJLgQ7VwVU_2A==(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_(), #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz(), #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR());
						if (text2.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909021093), new object[]
							{
								text,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().Name,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR() + 1
							});
							num--;
							#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zqvHy_roSewqZ(this.#=z8StzeqE=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=);
						}
						else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962326)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020763), new object[]
							{
								text,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().Name,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR() + 1,
								JSONManager.Cut(text2)
							});
							#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zkVnCyAE_ovFk(this.#=z8StzeqE=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=);
							#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=z318YUQXJBpE3(this.#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_());
							list.Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_());
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020763), new object[]
							{
								text,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().Name,
								#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR() + 1,
								JSONManager.Cut(text2)
							});
							#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zkVnCyAE_ovFk(this.#=z8StzeqE=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=);
						}
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962543), new object[]
						{
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_(),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().Name,
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR() + 1
						});
					}
				}
				num2++;
			}
		}
	}

	// Token: 0x040008F1 RID: 2289
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x040008F2 RID: 2290
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zbkd1_SL26Bt5;

	// Token: 0x040008F3 RID: 2291
	private int #=zs$0ZsWySJz6C;
}
