﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200003F RID: 63
internal sealed class #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW
{
	// Token: 0x060001F3 RID: 499 RVA: 0x000130C4 File Offset: 0x000112C4
	public #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		bool flag = this.#=zMuFMjGQ=() >= 500 && this.#=zMuFMjGQ=() < 600;
		this.#=zHKKXo3Re_b4C(flag ? 0 : JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
		this.#=zCtHynChfcPEX(0);
		this.#=zyd8AgCuEC_BOlIkrOQ==(0);
		object[] array = JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				int #=z$Ib9gYQ= = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
				if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0) > 1)
				{
					this.#=zyd8AgCuEC_BOlIkrOQ==(#=z$Ib9gYQ=);
				}
				else
				{
					this.#=zCtHynChfcPEX(#=z$Ib9gYQ=);
				}
			}
		}
		this.#=zwXKUV2c=(JSONManager.GetString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		if (flag)
		{
			this.#=zwXKUV2c=(this.#=zkfqcY3I=() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + (this.#=zMuFMjGQ=() - 500).ToString());
		}
		else if (this.#=zVaUA5_qegiur() > 1)
		{
			this.#=zwXKUV2c=(this.#=zkfqcY3I=() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + this.#=zVaUA5_qegiur().ToString());
		}
		this.#=zN$ZzBOHbXzEf(JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)).Length);
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x00013230 File Offset: 0x00011430
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x00013238 File Offset: 0x00011438
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001F6 RID: 502 RVA: 0x00013244 File Offset: 0x00011444
	public int #=zVaUA5_qegiur()
	{
		return this.#=z4bgbc9KraCP04E8LTg==;
	}

	// Token: 0x060001F7 RID: 503 RVA: 0x0001324C File Offset: 0x0001144C
	public void #=zHKKXo3Re_b4C(int #=z$Ib9gYQ=)
	{
		this.#=z4bgbc9KraCP04E8LTg== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001F8 RID: 504 RVA: 0x00013258 File Offset: 0x00011458
	public int #=zkZNDu8up5Nuh()
	{
		return this.#=zhfNY8UPpXQOR7vS2Mg==;
	}

	// Token: 0x060001F9 RID: 505 RVA: 0x00013260 File Offset: 0x00011460
	public void #=zCtHynChfcPEX(int #=z$Ib9gYQ=)
	{
		this.#=zhfNY8UPpXQOR7vS2Mg== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0001326C File Offset: 0x0001146C
	public int #=z5irrWqrwWHrPajKrZw==()
	{
		return this.#=zkwO3jdzh01cQRYjteUvMEpg=;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x00013274 File Offset: 0x00011474
	public void #=zyd8AgCuEC_BOlIkrOQ==(int #=z$Ib9gYQ=)
	{
		this.#=zkwO3jdzh01cQRYjteUvMEpg= = #=z$Ib9gYQ=;
	}

	// Token: 0x060001FC RID: 508 RVA: 0x00013280 File Offset: 0x00011480
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060001FD RID: 509 RVA: 0x00013288 File Offset: 0x00011488
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001FE RID: 510 RVA: 0x00013294 File Offset: 0x00011494
	public int #=zaDKBEnk8Vsod()
	{
		return this.#=zvUGa2pYWJUtRMX01rHA$lx8=;
	}

	// Token: 0x060001FF RID: 511 RVA: 0x0001329C File Offset: 0x0001149C
	public void #=zN$ZzBOHbXzEf(int #=z$Ib9gYQ=)
	{
		this.#=zvUGa2pYWJUtRMX01rHA$lx8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000200 RID: 512 RVA: 0x000132A8 File Offset: 0x000114A8
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x04000075 RID: 117
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000076 RID: 118
	private int #=z4bgbc9KraCP04E8LTg==;

	// Token: 0x04000077 RID: 119
	private int #=zhfNY8UPpXQOR7vS2Mg==;

	// Token: 0x04000078 RID: 120
	private int #=zkwO3jdzh01cQRYjteUvMEpg=;

	// Token: 0x04000079 RID: 121
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x0400007A RID: 122
	private int #=zvUGa2pYWJUtRMX01rHA$lx8=;
}
