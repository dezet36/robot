﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000159 RID: 345
internal sealed class #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=
{
	// Token: 0x06000929 RID: 2345 RVA: 0x0004A790 File Offset: 0x00048990
	public #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=(Dictionary<string, object> #=zIHByRVU=)
	{
		if (#=zIHByRVU= == null)
		{
			this.#=zelNjHoBozvJYF$hacA==(0);
			this.#=zS5eZxG46HErxVRD3RQ==(0);
			this.#=zU74iyX2Vc5C7SFrw5HTzv5g=(new List<int>());
			return;
		}
		this.#=zelNjHoBozvJYF$hacA==(JSONManager.ExtractInt(#=zIHByRVU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0));
		this.#=zS5eZxG46HErxVRD3RQ==(JSONManager.ExtractInt(#=zIHByRVU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060487), 0));
		object[] array = JSONManager.ExtractArray(#=zIHByRVU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060220));
		this.#=zU74iyX2Vc5C7SFrw5HTzv5g=(new List<int>());
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				this.#=zD7ARvSV8xtCfE0_KzW0H$zo=().Add(Convert.ToInt32(array[i]));
			}
		}
	}

	// Token: 0x0600092A RID: 2346 RVA: 0x0004A830 File Offset: 0x00048A30
	public int #=zUZLtmsPiEO15k_Q8Gw==()
	{
		return this.#=zoJUO$89r9B5SER$3GveDg7H9TPJJ;
	}

	// Token: 0x0600092B RID: 2347 RVA: 0x0004A838 File Offset: 0x00048A38
	public void #=zelNjHoBozvJYF$hacA==(int #=z$Ib9gYQ=)
	{
		this.#=zoJUO$89r9B5SER$3GveDg7H9TPJJ = #=z$Ib9gYQ=;
	}

	// Token: 0x0600092C RID: 2348 RVA: 0x0004A844 File Offset: 0x00048A44
	public int #=zTS397QmwRLvBFKxTJQ==()
	{
		return this.#=zZ2YQMxMPiQwOJ2IET4wHEMxlTFt7;
	}

	// Token: 0x0600092D RID: 2349 RVA: 0x0004A84C File Offset: 0x00048A4C
	public void #=zS5eZxG46HErxVRD3RQ==(int #=z$Ib9gYQ=)
	{
		this.#=zZ2YQMxMPiQwOJ2IET4wHEMxlTFt7 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600092E RID: 2350 RVA: 0x0004A858 File Offset: 0x00048A58
	public List<int> #=zD7ARvSV8xtCfE0_KzW0H$zo=()
	{
		return this.#=z_fEs1gwnYFuUMm0Jc1Bkh5kaP_qUUBjytA==;
	}

	// Token: 0x0600092F RID: 2351 RVA: 0x0004A860 File Offset: 0x00048A60
	public void #=zU74iyX2Vc5C7SFrw5HTzv5g=(List<int> #=z$Ib9gYQ=)
	{
		this.#=z_fEs1gwnYFuUMm0Jc1Bkh5kaP_qUUBjytA== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000540 RID: 1344
	private int #=zoJUO$89r9B5SER$3GveDg7H9TPJJ;

	// Token: 0x04000541 RID: 1345
	private int #=zZ2YQMxMPiQwOJ2IET4wHEMxlTFt7;

	// Token: 0x04000542 RID: 1346
	private List<int> #=z_fEs1gwnYFuUMm0Jc1Bkh5kaP_qUUBjytA==;
}
