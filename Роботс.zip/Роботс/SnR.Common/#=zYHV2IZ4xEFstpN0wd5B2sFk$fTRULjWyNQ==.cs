﻿using System;

// Token: 0x020001DA RID: 474
internal class #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==
{
	// Token: 0x06000E4C RID: 3660 RVA: 0x000721D0 File Offset: 0x000703D0
	public #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==()
	{
		this.#=zCLd1HbpOa6Pc(DateTime.MinValue);
		this.#=zniBL6E3VL6qZBQF9fw==(false);
		this.#=zW2Vlp5vytS40(0);
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x000721F4 File Offset: 0x000703F4
	public #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==(int #=zAk8mKBk=, string #=zQrqFdos=, string #=zKFlJyLE=)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zHD9M6IxBLboIezSsHQ==(Convert.ToInt32(#=zQrqFdos=));
		this.#=z2WdNm_CMtqBR6ukyUw==(Convert.ToInt32(#=zKFlJyLE=));
		this.#=zCLd1HbpOa6Pc(DateTime.MinValue);
		this.#=zniBL6E3VL6qZBQF9fw==(false);
		this.#=zW2Vlp5vytS40(0);
	}

	// Token: 0x06000E4E RID: 3662 RVA: 0x00072234 File Offset: 0x00070434
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000E4F RID: 3663 RVA: 0x0007223C File Offset: 0x0007043C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E50 RID: 3664 RVA: 0x00072248 File Offset: 0x00070448
	public int #=zfTB62qendhk_VEy8rw==()
	{
		return this.#=zuCoBS22$SHwioNCsSm1KoiA=;
	}

	// Token: 0x06000E51 RID: 3665 RVA: 0x00072250 File Offset: 0x00070450
	public void #=zHD9M6IxBLboIezSsHQ==(int #=z$Ib9gYQ=)
	{
		this.#=zuCoBS22$SHwioNCsSm1KoiA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E52 RID: 3666 RVA: 0x0007225C File Offset: 0x0007045C
	public int #=zY0soxphmGIACbOHy6A==()
	{
		return this.#=zAZaEN2rHjtRHI7RjIU6YTJk=;
	}

	// Token: 0x06000E53 RID: 3667 RVA: 0x00072264 File Offset: 0x00070464
	public void #=z2WdNm_CMtqBR6ukyUw==(int #=z$Ib9gYQ=)
	{
		this.#=zAZaEN2rHjtRHI7RjIU6YTJk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E54 RID: 3668 RVA: 0x00072270 File Offset: 0x00070470
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06000E55 RID: 3669 RVA: 0x00072278 File Offset: 0x00070478
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E56 RID: 3670 RVA: 0x00072284 File Offset: 0x00070484
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000E57 RID: 3671 RVA: 0x0007228C File Offset: 0x0007048C
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E58 RID: 3672 RVA: 0x00072298 File Offset: 0x00070498
	public DateTime #=z2D1nHbya04wr()
	{
		return this.#=zMT0YWw$CT5ntcUFKLA==;
	}

	// Token: 0x06000E59 RID: 3673 RVA: 0x000722A0 File Offset: 0x000704A0
	public void #=zCLd1HbpOa6Pc(DateTime #=z$Ib9gYQ=)
	{
		this.#=zMT0YWw$CT5ntcUFKLA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E5A RID: 3674 RVA: 0x000722AC File Offset: 0x000704AC
	public bool #=zhP$CfEFuX09dZp5RNA==()
	{
		return this.#=zFTxOO4TRY5InTXblXdLf_a19y7_B;
	}

	// Token: 0x06000E5B RID: 3675 RVA: 0x000722B4 File Offset: 0x000704B4
	public void #=zniBL6E3VL6qZBQF9fw==(bool #=z$Ib9gYQ=)
	{
		this.#=zFTxOO4TRY5InTXblXdLf_a19y7_B = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E5C RID: 3676 RVA: 0x000722C0 File Offset: 0x000704C0
	public int #=zKHqHudNIb2os()
	{
		return this.#=z5gRv1_smzqub_tRhzg==;
	}

	// Token: 0x06000E5D RID: 3677 RVA: 0x000722C8 File Offset: 0x000704C8
	public void #=zW2Vlp5vytS40(int #=z$Ib9gYQ=)
	{
		this.#=z5gRv1_smzqub_tRhzg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E5E RID: 3678 RVA: 0x000722D4 File Offset: 0x000704D4
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x040007F6 RID: 2038
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040007F7 RID: 2039
	private int #=zuCoBS22$SHwioNCsSm1KoiA=;

	// Token: 0x040007F8 RID: 2040
	private int #=zAZaEN2rHjtRHI7RjIU6YTJk=;

	// Token: 0x040007F9 RID: 2041
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040007FA RID: 2042
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x040007FB RID: 2043
	private DateTime #=zMT0YWw$CT5ntcUFKLA==;

	// Token: 0x040007FC RID: 2044
	private bool #=zFTxOO4TRY5InTXblXdLf_a19y7_B;

	// Token: 0x040007FD RID: 2045
	private int #=z5gRv1_smzqub_tRhzg==;
}
