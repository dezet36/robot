﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000095 RID: 149
internal sealed class #=z7jy7QwkVtkyomnRikJhu3R8= : CellValue, LabelCell, Cell
{
	// Token: 0x0600040A RID: 1034 RVA: 0x00023FCC File Offset: 0x000221CC
	public #=z7jy7QwkVtkyomnRikJhu3R8=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=, WorkbookSettings #=z4JisLog=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=z7HqoPh0= = IntegerHelper.getInt(data[6], data[7]);
		if (data[8] == 0)
		{
			this.#=zaiKvawI= = StringHelper.getString(data, this.#=z7HqoPh0=, 9, #=z4JisLog=);
			return;
		}
		this.#=zaiKvawI= = StringHelper.getUnicodeString(data, this.#=z7HqoPh0=, 9);
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x00024030 File Offset: 0x00022230
	public #=z7jy7QwkVtkyomnRikJhu3R8=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=, WorkbookSettings #=z4JisLog=, #=z7jy7QwkVtkyomnRikJhu3R8=.#=zlfjpmgW14u47 #=zMY9_HRM=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=z7HqoPh0= = IntegerHelper.getInt(data[6], data[7]);
		this.#=zaiKvawI= = StringHelper.getString(data, this.#=z7HqoPh0=, 8, #=z4JisLog=);
	}

	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600040D RID: 1037 RVA: 0x00024084 File Offset: 0x00022284
	public string StringValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x0600040E RID: 1038 RVA: 0x0002408C File Offset: 0x0002228C
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x0600040F RID: 1039 RVA: 0x00024094 File Offset: 0x00022294
	public new string Contents
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000410 RID: 1040 RVA: 0x0002409C File Offset: 0x0002229C
	public new CellType Type
	{
		get
		{
			return CellType.LABEL;
		}
	}

	// Token: 0x0400017B RID: 379
	private int #=z7HqoPh0=;

	// Token: 0x0400017C RID: 380
	private string #=zaiKvawI=;

	// Token: 0x0400017D RID: 381
	public static #=z7jy7QwkVtkyomnRikJhu3R8=.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz = new #=z7jy7QwkVtkyomnRikJhu3R8=.#=zlfjpmgW14u47();

	// Token: 0x02000096 RID: 150
	public sealed class #=zlfjpmgW14u47
	{
	}
}
