﻿using System;
using System.Collections.Generic;

// Token: 0x02000261 RID: 609
internal sealed class #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=
{
	// Token: 0x06001285 RID: 4741 RVA: 0x00091494 File Offset: 0x0008F694
	public #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=(Dictionary<string, object> #=zImRpit2fexswVTgipHVP0mc=, Dictionary<int, string> #=z8OQAqQM4bxMSTfrG$jokQHA=)
	{
		this.#=zbsxKkj4=(Convert.ToInt32(#=zImRpit2fexswVTgipHVP0mc=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
		this.#=zwXKUV2c=(#=z8OQAqQM4bxMSTfrG$jokQHA=[this.#=zMuFMjGQ=()]);
		this.#=zFzGvi_S6jJhE(Convert.ToInt32(#=zImRpit2fexswVTgipHVP0mc=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
		this.#=zHJUoCnXLMWhpD64Wf2bcbK_YqjZsZVr7YQ==(Convert.ToInt32(#=zImRpit2fexswVTgipHVP0mc=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)]) == 1);
	}

	// Token: 0x06001286 RID: 4742 RVA: 0x00091510 File Offset: 0x0008F710
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001287 RID: 4743 RVA: 0x00091518 File Offset: 0x0008F718
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001288 RID: 4744 RVA: 0x00091524 File Offset: 0x0008F724
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06001289 RID: 4745 RVA: 0x0009152C File Offset: 0x0008F72C
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600128A RID: 4746 RVA: 0x00091538 File Offset: 0x0008F738
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x0600128B RID: 4747 RVA: 0x00091540 File Offset: 0x0008F740
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600128C RID: 4748 RVA: 0x0009154C File Offset: 0x0008F74C
	public bool #=zY1MCywb8bWJeKmolJ4iPMDZERdKEI_Ze0w==()
	{
		return this.#=zrDD3bioMPVAuwYiRrGlXN$2QRIWwLoNN9Nl8okQ=;
	}

	// Token: 0x0600128D RID: 4749 RVA: 0x00091554 File Offset: 0x0008F754
	public void #=zHJUoCnXLMWhpD64Wf2bcbK_YqjZsZVr7YQ==(bool #=z$Ib9gYQ=)
	{
		this.#=zrDD3bioMPVAuwYiRrGlXN$2QRIWwLoNN9Nl8okQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000AAC RID: 2732
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000AAD RID: 2733
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000AAE RID: 2734
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x04000AAF RID: 2735
	private bool #=zrDD3bioMPVAuwYiRrGlXN$2QRIWwLoNN9Nl8okQ=;
}
