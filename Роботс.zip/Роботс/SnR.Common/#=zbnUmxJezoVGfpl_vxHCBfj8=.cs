﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000209 RID: 521
internal sealed class #=zbnUmxJezoVGfpl_vxHCBfj8= : RecordData
{
	// Token: 0x06001007 RID: 4103 RVA: 0x0007BDE4 File Offset: 0x00079FE4
	public #=zbnUmxJezoVGfpl_vxHCBfj8=(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		if (data.Length == 10)
		{
			this.#=zDkLQq5sQK8pV(data);
			return;
		}
		this.#=zGOC9Y_qoy5gU(data);
	}

	// Token: 0x06001008 RID: 4104 RVA: 0x0007BE18 File Offset: 0x0007A018
	public #=zbnUmxJezoVGfpl_vxHCBfj8=(Record #=zJce$Sys=, #=zbnUmxJezoVGfpl_vxHCBfj8=.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		this.#=zDkLQq5sQK8pV(data);
	}

	// Token: 0x0600100A RID: 4106 RVA: 0x0007BE48 File Offset: 0x0007A048
	public int #=z$2ogfb5H9R6f()
	{
		return this.#=zgTmLAohDTfaZ;
	}

	// Token: 0x0600100B RID: 4107 RVA: 0x0007BE50 File Offset: 0x0007A050
	public int #=zhUfM2IzcS5zU()
	{
		return this.#=zuyRGtIBGTWoN;
	}

	// Token: 0x0600100C RID: 4108 RVA: 0x0007BE58 File Offset: 0x0007A058
	private void #=zDkLQq5sQK8pV(sbyte[] #=zJ5GWysk=)
	{
		this.#=zgTmLAohDTfaZ = IntegerHelper.getInt(#=zJ5GWysk=[2], #=zJ5GWysk=[3]);
		this.#=zuyRGtIBGTWoN = IntegerHelper.getInt(#=zJ5GWysk=[6], #=zJ5GWysk=[7]);
	}

	// Token: 0x0600100D RID: 4109 RVA: 0x0007BE7C File Offset: 0x0007A07C
	private void #=zGOC9Y_qoy5gU(sbyte[] #=zJ5GWysk=)
	{
		this.#=zgTmLAohDTfaZ = IntegerHelper.getInt(#=zJ5GWysk=[4], #=zJ5GWysk=[5], #=zJ5GWysk=[6], #=zJ5GWysk=[7]);
		this.#=zuyRGtIBGTWoN = IntegerHelper.getInt(#=zJ5GWysk=[10], #=zJ5GWysk=[11]);
	}

	// Token: 0x040008DA RID: 2266
	private int #=zgTmLAohDTfaZ;

	// Token: 0x040008DB RID: 2267
	private int #=zuyRGtIBGTWoN;

	// Token: 0x040008DC RID: 2268
	public static #=zbnUmxJezoVGfpl_vxHCBfj8=.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz = new #=zbnUmxJezoVGfpl_vxHCBfj8=.#=zlfjpmgW14u47();

	// Token: 0x0200020A RID: 522
	public sealed class #=zlfjpmgW14u47
	{
	}
}
