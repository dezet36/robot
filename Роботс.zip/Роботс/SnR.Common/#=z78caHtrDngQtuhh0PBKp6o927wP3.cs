﻿using System;

// Token: 0x0200008B RID: 139
internal sealed class #=z78caHtrDngQtuhh0PBKp6o927wP3 : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x060003C9 RID: 969 RVA: 0x0002132C File Offset: 0x0001F52C
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQDVO67WHVcIJN5ZZsQ==;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x00021334 File Offset: 0x0001F534
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x060003CB RID: 971 RVA: 0x00021338 File Offset: 0x0001F538
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080289);
	}
}
