﻿using System;
using System.IO;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x02000040 RID: 64
internal sealed class #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN
{
	// Token: 0x06000201 RID: 513 RVA: 0x000132B0 File Offset: 0x000114B0
	internal #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN(string #=zCXnzjLQ=) : this()
	{
		if (#=zCXnzjLQ= == null)
		{
			throw new ApplicationException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079863));
		}
		this.#=z2ckNN2dRoqW0 = new StringReader(#=zCXnzjLQ=);
	}

	// Token: 0x06000202 RID: 514 RVA: 0x000132D8 File Offset: 0x000114D8
	private #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN()
	{
		this.#=z8z2t_dRfv0KP();
		this.#=zbaevDNLFsN7O = new char[this.#=zUt6e8t84InynV5m1eA==];
		this.#=znT2cvZm44bE5$_U$Tg== = 0;
		this.#=z1JkdyNKDnmRR = 0;
		this.#=zSRgcCTLkrHn8GT9Qpg== = 0;
		this.#=zO9V68XQHbCQMfeSigg== = 0;
		this.#=zLrFOYX73Cywu = 0;
		this.#=zngWPOhpuRYBk = 0;
		this.#=zo$wOumX0A2hw1Zto3A== = true;
		this.#=zK4_QXDEsbndH = this.#=zVRxYS6cZs_d8kuwC2Q==;
	}

	// Token: 0x06000203 RID: 515 RVA: 0x000133C8 File Offset: 0x000115C8
	private void #=z8z2t_dRfv0KP()
	{
		this.#=zCqbqth9XRtLK = new int[]
		{
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=,
			this.#=zzgApbbvWfLEhl3Be0mNstKE=,
			this.#=zrJcP39pQddLVePQfj$Hr9TE=
		};
		this.#=zbqqnSRbrQqB4 = this.#=zU6$YWAIqHhZDozJQ5A==(1, 130, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080015))[0];
		this.#=z28$cNVgVUTv0 = this.#=zU6$YWAIqHhZDozJQ5A==(1, 71, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079591))[0];
		this.#=z55CV_B5312HO = this.#=zU6$YWAIqHhZDozJQ5A==(50, 30, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081449));
	}

	// Token: 0x06000204 RID: 516 RVA: 0x000136F4 File Offset: 0x000118F4
	internal int #=zK7OiD87uox7o()
	{
		return this.#=zLrFOYX73Cywu;
	}

	// Token: 0x06000205 RID: 517 RVA: 0x000136FC File Offset: 0x000118FC
	internal void #=zqi7Ie2gUQ822(ExternalSheet #=z$Ib9gYQ=)
	{
		this.#=z$qdebj6dfyrP = #=z$Ib9gYQ=;
	}

	// Token: 0x06000206 RID: 518 RVA: 0x00013708 File Offset: 0x00011908
	internal void #=zsJ5QVYmSq3En(WorkbookMethods #=z$Ib9gYQ=)
	{
		this.#=zLJGAifU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00013714 File Offset: 0x00011914
	private void #=zlrhN_uu2XWhR(int #=zNhLzguI=)
	{
		this.#=zK4_QXDEsbndH = #=zNhLzguI=;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x00013720 File Offset: 0x00011920
	private int #=z$T5bc73hRkkyb41s4g==()
	{
		int num;
		if (this.#=z1JkdyNKDnmRR < this.#=znT2cvZm44bE5$_U$Tg==)
		{
			char[] array = this.#=zbaevDNLFsN7O;
			num = this.#=z1JkdyNKDnmRR;
			this.#=z1JkdyNKDnmRR = num + 1;
			return array[num];
		}
		if (this.#=zSRgcCTLkrHn8GT9Qpg== != 0)
		{
			int i = this.#=zSRgcCTLkrHn8GT9Qpg==;
			int num2 = 0;
			while (i < this.#=znT2cvZm44bE5$_U$Tg==)
			{
				this.#=zbaevDNLFsN7O[num2] = this.#=zbaevDNLFsN7O[i];
				i++;
				num2++;
			}
			this.#=zO9V68XQHbCQMfeSigg== -= this.#=zSRgcCTLkrHn8GT9Qpg==;
			this.#=zSRgcCTLkrHn8GT9Qpg== = 0;
			this.#=znT2cvZm44bE5$_U$Tg== = num2;
			this.#=z1JkdyNKDnmRR = num2;
			int num3 = this.#=z2ckNN2dRoqW0.Read(this.#=zbaevDNLFsN7O, this.#=znT2cvZm44bE5$_U$Tg==, this.#=zbaevDNLFsN7O.Length - this.#=znT2cvZm44bE5$_U$Tg==);
			if (-1 == num3)
			{
				return this.#=zNc6KWOmfD0ix;
			}
			this.#=znT2cvZm44bE5$_U$Tg== += num3;
		}
		while (this.#=z1JkdyNKDnmRR >= this.#=znT2cvZm44bE5$_U$Tg==)
		{
			if (this.#=z1JkdyNKDnmRR >= this.#=zbaevDNLFsN7O.Length)
			{
				this.#=zbaevDNLFsN7O = this.#=zd8r83YPG$XHA(this.#=zbaevDNLFsN7O);
			}
			int num3 = this.#=z2ckNN2dRoqW0.Read(this.#=zbaevDNLFsN7O, this.#=znT2cvZm44bE5$_U$Tg==, this.#=zbaevDNLFsN7O.Length - this.#=znT2cvZm44bE5$_U$Tg==);
			if (-1 == num3)
			{
				return this.#=zNc6KWOmfD0ix;
			}
			this.#=znT2cvZm44bE5$_U$Tg== += num3;
		}
		char[] array2 = this.#=zbaevDNLFsN7O;
		num = this.#=z1JkdyNKDnmRR;
		this.#=z1JkdyNKDnmRR = num + 1;
		return array2[num];
	}

	// Token: 0x06000209 RID: 521 RVA: 0x00013880 File Offset: 0x00011A80
	private void #=z84mqGsAnoDbNeWeD$g==()
	{
		if (this.#=zO9V68XQHbCQMfeSigg== > this.#=zSRgcCTLkrHn8GT9Qpg== && '\n' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1])
		{
			this.#=zO9V68XQHbCQMfeSigg==--;
		}
		if (this.#=zO9V68XQHbCQMfeSigg== > this.#=zSRgcCTLkrHn8GT9Qpg== && '\r' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1])
		{
			this.#=zO9V68XQHbCQMfeSigg==--;
		}
	}

	// Token: 0x0600020A RID: 522 RVA: 0x000138EC File Offset: 0x00011AEC
	private void #=zFmE$yJXiQm_Z4THW$w==()
	{
		for (int i = this.#=zSRgcCTLkrHn8GT9Qpg==; i < this.#=z1JkdyNKDnmRR; i++)
		{
			if ('\n' == this.#=zbaevDNLFsN7O[i] && !this.#=z$S1BHAZYlWL7j1RLyQ==)
			{
				this.#=zngWPOhpuRYBk++;
			}
			if ('\r' == this.#=zbaevDNLFsN7O[i])
			{
				this.#=zngWPOhpuRYBk++;
				this.#=z$S1BHAZYlWL7j1RLyQ== = true;
			}
			else
			{
				this.#=z$S1BHAZYlWL7j1RLyQ== = false;
			}
		}
		this.#=zLrFOYX73Cywu = this.#=zLrFOYX73Cywu + this.#=z1JkdyNKDnmRR - this.#=zSRgcCTLkrHn8GT9Qpg==;
		this.#=zSRgcCTLkrHn8GT9Qpg== = this.#=z1JkdyNKDnmRR;
	}

	// Token: 0x0600020B RID: 523 RVA: 0x00013984 File Offset: 0x00011B84
	private void #=zVmALIp$DXRa$quNGyg==()
	{
		this.#=zO9V68XQHbCQMfeSigg== = this.#=z1JkdyNKDnmRR;
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00013994 File Offset: 0x00011B94
	private void #=zhswhk_4up$kVZtGLhg==()
	{
		this.#=z1JkdyNKDnmRR = this.#=zO9V68XQHbCQMfeSigg==;
		this.#=zo$wOumX0A2hw1Zto3A== = (this.#=zO9V68XQHbCQMfeSigg== > this.#=zSRgcCTLkrHn8GT9Qpg== && ('\r' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1] || '\n' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1] || '߬' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1] || '߭' == this.#=zbaevDNLFsN7O[this.#=zO9V68XQHbCQMfeSigg== - 1]));
	}

	// Token: 0x0600020D RID: 525 RVA: 0x00013A1C File Offset: 0x00011C1C
	private string #=zEgkDCJMpg5zU()
	{
		return new string(this.#=zbaevDNLFsN7O, this.#=zSRgcCTLkrHn8GT9Qpg==, this.#=zO9V68XQHbCQMfeSigg== - this.#=zSRgcCTLkrHn8GT9Qpg==);
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00013A3C File Offset: 0x00011C3C
	private int #=zwWgsxaXkF$N6Zv9y$g==()
	{
		return this.#=zO9V68XQHbCQMfeSigg== - this.#=zSRgcCTLkrHn8GT9Qpg==;
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00013A4C File Offset: 0x00011C4C
	private char[] #=zd8r83YPG$XHA(char[] #=zXvwCnz8=)
	{
		char[] array = new char[2 * #=zXvwCnz8=.Length];
		for (int i = 0; i < #=zXvwCnz8=.Length; i++)
		{
			array[i] = #=zXvwCnz8=[i];
		}
		return array;
	}

	// Token: 0x06000210 RID: 528 RVA: 0x00013A7C File Offset: 0x00011C7C
	private void #=z3KQip2qR9HOY(int #=zKJA8IWQ=, bool #=zL6Ur3h0=)
	{
		if (#=zL6Ur3h0=)
		{
			throw new ApplicationException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080703));
		}
	}

	// Token: 0x06000211 RID: 529 RVA: 0x00013A94 File Offset: 0x00011C94
	private int[][] #=zU6$YWAIqHhZDozJQ5A==(int #=zcjlGBIc=, int #=z8pytphI=, string #=zfN6NveI=)
	{
		int num = 0;
		int num2 = 0;
		int[][] array = new int[#=zcjlGBIc=][];
		for (int i = 0; i < #=zcjlGBIc=; i++)
		{
			array[i] = new int[#=z8pytphI=];
		}
		for (int j = 0; j < #=zcjlGBIc=; j++)
		{
			for (int k = 0; k < #=z8pytphI=; k++)
			{
				if (num != 0)
				{
					array[j][k] = num2;
					num--;
				}
				else
				{
					int num3 = #=zfN6NveI=.IndexOf(',');
					string text = (num3 == -1) ? #=zfN6NveI= : #=zfN6NveI=.Substring(0, num3);
					#=zfN6NveI= = #=zfN6NveI=.Substring(num3 + 1);
					int num4 = text.IndexOf(':');
					if (num4 == -1)
					{
						array[j][k] = int.Parse(text);
					}
					else
					{
						num = int.Parse(text.Substring(num4 + 1));
						text = text.Substring(0, num4);
						num2 = int.Parse(text);
						array[j][k] = num2;
						num--;
					}
				}
			}
		}
		return array;
	}

	// Token: 0x06000212 RID: 530 RVA: 0x00013B78 File Offset: 0x00011D78
	public #=zoImewjUBfkPyF1oU_G4atTk= #=zDuKUJOe5JTYV()
	{
		int num = this.#=zzgApbbvWfLEhl3Be0mNstKE=;
		int num2 = this.#=zzliAjCLSSNP5SVOTAg==[this.#=zK4_QXDEsbndH];
		int num3 = this.#=z78eDrAkOVD4SHStykA==;
		int num4 = this.#=z78eDrAkOVD4SHStykA==;
		bool flag = true;
		this.#=zFmE$yJXiQm_Z4THW$w==();
		int num5 = this.#=zCqbqth9XRtLK[num2];
		if (this.#=zrJcP39pQddLVePQfj$Hr9TE= != num5)
		{
			num4 = num2;
			this.#=zVmALIp$DXRa$quNGyg==();
		}
		for (;;)
		{
			int num6;
			if (flag && this.#=zo$wOumX0A2hw1Zto3A==)
			{
				num6 = this.#=zsoYQbPx_RDcS;
			}
			else
			{
				num6 = this.#=z$T5bc73hRkkyb41s4g==();
			}
			num3 = this.#=znkBNAbVgGPyo;
			num3 = this.#=z55CV_B5312HO[this.#=z28$cNVgVUTv0[num2]][this.#=zbqqnSRbrQqB4[num6]];
			if (this.#=zNc6KWOmfD0ix == num6 && flag)
			{
				break;
			}
			if (this.#=znkBNAbVgGPyo != num3)
			{
				num2 = num3;
				flag = false;
				num5 = this.#=zCqbqth9XRtLK[num2];
				if (this.#=zrJcP39pQddLVePQfj$Hr9TE= != num5)
				{
					num4 = num2;
					this.#=zVmALIp$DXRa$quNGyg==();
				}
			}
			else
			{
				if (this.#=z78eDrAkOVD4SHStykA== == num4)
				{
					goto Block_8;
				}
				num = this.#=zCqbqth9XRtLK[num4];
				if ((this.#=zwpU_9_Mcx3mM & num) != 0)
				{
					this.#=z84mqGsAnoDbNeWeD$g==();
				}
				this.#=zhswhk_4up$kVZtGLhg==();
				bool flag2 = false;
				switch (num4)
				{
				case -40:
				case -39:
				case -38:
				case -37:
				case -36:
				case -35:
				case -34:
				case -33:
				case -32:
				case -31:
				case -30:
				case -29:
				case -28:
				case -27:
				case -26:
				case -25:
				case -24:
				case -23:
				case -22:
				case -21:
				case -20:
				case -19:
				case -18:
				case -17:
				case -16:
				case -15:
				case -14:
				case -13:
				case -12:
				case -11:
				case -10:
				case -9:
				case -8:
				case -7:
				case -6:
				case -5:
				case -4:
				case -3:
				case -2:
				case -1:
				case 1:
				case 11:
					break;
				case 0:
				case 30:
				case 35:
				case 37:
				case 39:
				case 41:
				case 42:
				case 43:
				case 44:
				case 45:
				case 46:
				case 47:
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57:
				case 58:
				case 59:
				case 60:
				case 61:
				case 63:
				case 65:
				case 66:
				case 67:
				case 68:
					goto IL_49D;
				case 2:
					goto IL_2C3;
				case 3:
					goto IL_2C9;
				case 4:
					goto IL_2CF;
				case 5:
					goto IL_2D5;
				case 6:
					goto IL_2DB;
				case 7:
					goto IL_2E1;
				case 8:
					goto IL_2E7;
				case 9:
					goto IL_2ED;
				case 10:
					goto IL_2F3;
				case 12:
					goto IL_2FF;
				case 13:
					goto IL_305;
				case 14:
					goto IL_30B;
				case 15:
					this.#=z0xWFEkA= = true;
					this.#=zlrhN_uu2XWhR(this.#=zl9qQN$1VzMYdDYNFGw==);
					break;
				case 16:
					goto IL_329;
				case 17:
					goto IL_32F;
				case 18:
					goto IL_335;
				case 19:
					goto IL_33B;
				case 20:
					goto IL_347;
				case 21:
					goto IL_359;
				case 22:
					goto IL_365;
				case 23:
					goto IL_371;
				case 24:
					goto IL_383;
				case 25:
					goto IL_38F;
				case 26:
					goto IL_39B;
				case 27:
					goto IL_3A7;
				case 28:
					goto IL_3B9;
				case 29:
					this.#=zlrhN_uu2XWhR(this.#=zVRxYS6cZs_d8kuwC2Q==);
					if (this.#=z0xWFEkA=)
					{
						goto Block_11;
					}
					break;
				case 31:
					goto IL_3EE;
				case 32:
					goto IL_3FA;
				case 33:
					goto IL_40C;
				case 34:
					goto IL_41E;
				case 36:
					goto IL_431;
				case 38:
					goto IL_443;
				case 40:
					goto IL_455;
				case 62:
					goto IL_467;
				case 64:
					goto IL_479;
				case 69:
					goto IL_48B;
				default:
					goto IL_49D;
				}
				IL_4A0:
				if (flag2)
				{
					this.#=z3KQip2qR9HOY(this.#=zFKWDyzN3XdBB, false);
				}
				flag = true;
				num2 = this.#=zzliAjCLSSNP5SVOTAg==[this.#=zK4_QXDEsbndH];
				num3 = this.#=z78eDrAkOVD4SHStykA==;
				num4 = this.#=z78eDrAkOVD4SHStykA==;
				this.#=zFmE$yJXiQm_Z4THW$w==();
				num5 = this.#=zCqbqth9XRtLK[num2];
				if (this.#=zrJcP39pQddLVePQfj$Hr9TE= != num5)
				{
					num4 = num2;
					this.#=zVmALIp$DXRa$quNGyg==();
					continue;
				}
				continue;
				IL_49D:
				flag2 = true;
				goto IL_4A0;
			}
		}
		return null;
		Block_8:
		throw new ApplicationException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080675));
		IL_2C3:
		return new #=zpAUbRi5TAZobsBYiRTrc9P4=();
		IL_2C9:
		return new #=zYqgyYHzU6wXITHX0$1KpTaY=();
		IL_2CF:
		return new #=z26PVQ4L5c6_XrCwJa_YmAEM=();
		IL_2D5:
		return new #=z_9QeQX33e0ZIk3yCxt1JB0I=();
		IL_2DB:
		return new #=zFG8YXHlzLmur6XFABoDqKLuZrFFV();
		IL_2E1:
		return new #=zoQbOOfZXwfMAZDEEMnMU6Dc=();
		IL_2E7:
		return new #=zGVg9b0SNNZXoUNlnSbs$HHqhofDU();
		IL_2ED:
		return new #=zEXYK_umUb2AVdmteSIANd1sVlDma();
		IL_2F3:
		return new #=ztehYPOx2oo__hagJu3exMP4=(this.#=zEgkDCJMpg5zU());
		IL_2FF:
		return new #=z$3MhmIwEHxQm0c1NetTmL1Z0XPiz();
		IL_305:
		return new #=z6cy6tUTuwcUEnm8g5QDGa6YOEpyz();
		IL_30B:
		return new #=zAwfcpmMuOjMkYcf_C4vnZwMbC5St();
		IL_329:
		return new #=z78caHtrDngQtuhh0PBKp6o927wP3();
		IL_32F:
		return new #=z$NEwNZR20jcfgsC228hQqoE=();
		IL_335:
		return new #=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg();
		IL_33B:
		return new #=zmIoOMk5gpONjUdFBWMzEoSA=(this.#=zEgkDCJMpg5zU());
		IL_347:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_359:
		return new #=zya1IgD5Efg9ZmZdd$BLsbHs=(this.#=zEgkDCJMpg5zU());
		IL_365:
		return new #=zINqPaypOVANwYlpJtujz4xc=(this.#=zEgkDCJMpg5zU());
		IL_371:
		return new #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r(this.#=zEgkDCJMpg5zU(), this.#=z$qdebj6dfyrP);
		IL_383:
		return new #=zjDyGwkfNTtkuN31SOnRKBTs=(this.#=zEgkDCJMpg5zU());
		IL_38F:
		return new #=zRFbnANRws$wumebgXSXu5QM=(this.#=zEgkDCJMpg5zU());
		IL_39B:
		return new #=zjDyGwkfNTtkuN31SOnRKBTs=(this.#=zEgkDCJMpg5zU());
		IL_3A7:
		return new #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU(this.#=zEgkDCJMpg5zU(), this.#=z$qdebj6dfyrP);
		IL_3B9:
		this.#=z0xWFEkA= = false;
		return new #=zPA0EJTEsxNJBLwMFiQxjO9Y=(this.#=zEgkDCJMpg5zU());
		Block_11:
		return new #=zPA0EJTEsxNJBLwMFiQxjO9Y=(string.Empty);
		IL_3EE:
		return new #=zmIoOMk5gpONjUdFBWMzEoSA=(this.#=zEgkDCJMpg5zU());
		IL_3FA:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_40C:
		return new #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r(this.#=zEgkDCJMpg5zU(), this.#=z$qdebj6dfyrP);
		IL_41E:
		this.#=z0xWFEkA= = false;
		return new #=zPA0EJTEsxNJBLwMFiQxjO9Y=(this.#=zEgkDCJMpg5zU());
		IL_431:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_443:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_455:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_467:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_479:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
		IL_48B:
		return new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zEgkDCJMpg5zU(), this.#=zLJGAifU=);
	}

	// Token: 0x0400007B RID: 123
	private int #=zUt6e8t84InynV5m1eA== = 512;

	// Token: 0x0400007C RID: 124
	private int #=znkBNAbVgGPyo = -1;

	// Token: 0x0400007D RID: 125
	private int #=z78eDrAkOVD4SHStykA== = -1;

	// Token: 0x0400007E RID: 126
	private int #=zrJcP39pQddLVePQfj$Hr9TE=;

	// Token: 0x0400007F RID: 127
	private int #=z3v1MeLgJ35IA = 1;

	// Token: 0x04000080 RID: 128
	private int #=zwpU_9_Mcx3mM = 2;

	// Token: 0x04000081 RID: 129
	private int #=zzgApbbvWfLEhl3Be0mNstKE= = 4;

	// Token: 0x04000082 RID: 130
	private int #=zsoYQbPx_RDcS = 128;

	// Token: 0x04000083 RID: 131
	private int #=zNc6KWOmfD0ix = 129;

	// Token: 0x04000084 RID: 132
	private bool #=z0xWFEkA=;

	// Token: 0x04000085 RID: 133
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x04000086 RID: 134
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x04000087 RID: 135
	private StringReader #=z2ckNN2dRoqW0;

	// Token: 0x04000088 RID: 136
	private int #=z1JkdyNKDnmRR;

	// Token: 0x04000089 RID: 137
	private int #=znT2cvZm44bE5$_U$Tg==;

	// Token: 0x0400008A RID: 138
	private int #=zSRgcCTLkrHn8GT9Qpg==;

	// Token: 0x0400008B RID: 139
	private int #=zO9V68XQHbCQMfeSigg==;

	// Token: 0x0400008C RID: 140
	private char[] #=zbaevDNLFsN7O;

	// Token: 0x0400008D RID: 141
	private int #=zLrFOYX73Cywu;

	// Token: 0x0400008E RID: 142
	private int #=zngWPOhpuRYBk;

	// Token: 0x0400008F RID: 143
	private bool #=zo$wOumX0A2hw1Zto3A==;

	// Token: 0x04000090 RID: 144
	private int #=zK4_QXDEsbndH;

	// Token: 0x04000091 RID: 145
	private bool #=zHRuJ_zPEC8zVKi1eXw==;

	// Token: 0x04000092 RID: 146
	private int #=zl9qQN$1VzMYdDYNFGw== = 1;

	// Token: 0x04000093 RID: 147
	private int #=zVRxYS6cZs_d8kuwC2Q==;

	// Token: 0x04000094 RID: 148
	private int[] #=zzliAjCLSSNP5SVOTAg== = new int[]
	{
		0,
		28
	};

	// Token: 0x04000095 RID: 149
	private bool #=z$S1BHAZYlWL7j1RLyQ==;

	// Token: 0x04000096 RID: 150
	private int #=zFKWDyzN3XdBB;

	// Token: 0x04000097 RID: 151
	private int #=zERytUAhrjOo7 = 1;

	// Token: 0x04000098 RID: 152
	private string[] #=zykUasmHUIeIzKMqYIw== = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079810),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080044)
	};

	// Token: 0x04000099 RID: 153
	private int[] #=zCqbqth9XRtLK;

	// Token: 0x0400009A RID: 154
	private int[] #=zbqqnSRbrQqB4;

	// Token: 0x0400009B RID: 155
	private int[] #=z28$cNVgVUTv0;

	// Token: 0x0400009C RID: 156
	private int[][] #=z55CV_B5312HO;
}
