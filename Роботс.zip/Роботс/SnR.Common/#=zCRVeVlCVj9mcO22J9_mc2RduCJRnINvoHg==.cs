﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;
using Skink.SnR.Common.UserMeta;

// Token: 0x020000D2 RID: 210
internal sealed partial class #=zCRVeVlCVj9mcO22J9_mc2RduCJRnINvoHg== : Form
{
	// Token: 0x060005A2 RID: 1442 RVA: 0x0002EE9C File Offset: 0x0002D09C
	public #=zCRVeVlCVj9mcO22J9_mc2RduCJRnINvoHg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zBMwJDJhgPcAP = #=zJUGTDqUtMnBf;
		this.#=zgpzgXirqPT5_();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x0002EEC0 File Offset: 0x0002D0C0
	private void #=zJCGehHOlK9f_35XQmA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=z7z_FFqD1kV0N.ShowDialog() == DialogResult.OK)
		{
			this.#=zCccyDJ8677flQDO$iA==.Text = this.#=z7z_FFqD1kV0N.FileName;
		}
	}

	// Token: 0x060005A4 RID: 1444 RVA: 0x0002EEE8 File Offset: 0x0002D0E8
	private void #=zEEzkpc9C85Fk(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		ActionSettings actionSettings = this.#=zP$T7rqg=();
		if (actionSettings != null)
		{
			actionSettings.CopyAll(this.#=zBMwJDJhgPcAP.#=zv2Kyu17YrGOC(), true);
			this.#=zBMwJDJhgPcAP.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
			base.Close();
		}
	}

	// Token: 0x060005A5 RID: 1445 RVA: 0x0002EF28 File Offset: 0x0002D128
	private void #=zJbN7AMBd12di0Rl_AQ==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		ActionSettings actionSettings = this.#=zP$T7rqg=();
		if (actionSettings != null)
		{
			new #=zFfvixqA1aRfZpRx33abYUnll5YQJ8GcaFA==(this.#=zshVEGQI=, this.#=zBMwJDJhgPcAP, actionSettings).ShowDialog();
			base.Close();
		}
	}

	// Token: 0x060005A6 RID: 1446 RVA: 0x0002EF60 File Offset: 0x0002D160
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060005A7 RID: 1447 RVA: 0x0002EF68 File Offset: 0x0002D168
	private ActionSettings #=zP$T7rqg=()
	{
		ActionSettings result;
		try
		{
			string text;
			if (this.#=zqGU29PfWHhZMyVFjNg==.SelectedIndex == 1)
			{
				if (string.IsNullOrEmpty(this.#=zCccyDJ8677flQDO$iA==.Text))
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029792));
					return null;
				}
				text = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(this.#=zCccyDJ8677flQDO$iA==.Text);
			}
			else
			{
				text = this.#=zoWsOaIGwOm$R4MvjYQ==.Text;
			}
			if (string.IsNullOrWhiteSpace(text))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029775));
				result = null;
			}
			else
			{
				StringReader stringReader = new StringReader(text);
				try
				{
					result = (ActionSettings)new XmlSerializer(typeof(ActionSettings)).Deserialize(stringReader);
				}
				finally
				{
					((IDisposable)stringReader).Dispose();
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
			result = null;
		}
		return result;
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x0002F05C File Offset: 0x0002D25C
	private void #=zgpzgXirqPT5_()
	{
		this.#=z8bcpLWm$DpFw = new SplitContainer();
		this.#=zoiw27qM7AzYz = new Button();
		this.#=z3pO2B3yhFRBi = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=zqGU29PfWHhZMyVFjNg== = new TabControl();
		this.#=zLxa7nLB9JIQS = new TabPage();
		this.#=z8DimCOMwhKCu = new TabPage();
		this.#=zoWsOaIGwOm$R4MvjYQ== = new TextBox();
		this.#=zCccyDJ8677flQDO$iA== = new TextBox();
		this.#=zjeQAlxw6ZiBw = new Button();
		this.#=z7z_FFqD1kV0N = new OpenFileDialog();
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).BeginInit();
		this.#=z8bcpLWm$DpFw.Panel1.SuspendLayout();
		this.#=z8bcpLWm$DpFw.Panel2.SuspendLayout();
		this.#=z8bcpLWm$DpFw.SuspendLayout();
		this.#=zqGU29PfWHhZMyVFjNg==.SuspendLayout();
		this.#=zLxa7nLB9JIQS.SuspendLayout();
		this.#=z8DimCOMwhKCu.SuspendLayout();
		base.SuspendLayout();
		this.#=z8bcpLWm$DpFw.Dock = DockStyle.Fill;
		this.#=z8bcpLWm$DpFw.FixedPanel = FixedPanel.Panel2;
		this.#=z8bcpLWm$DpFw.Location = new Point(0, 0);
		this.#=z8bcpLWm$DpFw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114121);
		this.#=z8bcpLWm$DpFw.Orientation = Orientation.Horizontal;
		this.#=z8bcpLWm$DpFw.Panel1.Controls.Add(this.#=zqGU29PfWHhZMyVFjNg==);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zoiw27qM7AzYz);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=z3pO2B3yhFRBi);
		this.#=z8bcpLWm$DpFw.Size = new Size(356, 321);
		this.#=z8bcpLWm$DpFw.SplitterDistance = 273;
		this.#=z8bcpLWm$DpFw.TabIndex = 0;
		this.#=zoiw27qM7AzYz.Location = new Point(12, 9);
		this.#=zoiw27qM7AzYz.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029474);
		this.#=zoiw27qM7AzYz.Size = new Size(75, 23);
		this.#=zoiw27qM7AzYz.TabIndex = 0;
		this.#=zoiw27qM7AzYz.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113263);
		this.#=zoiw27qM7AzYz.UseVisualStyleBackColor = true;
		this.#=zoiw27qM7AzYz.Click += this.#=zEEzkpc9C85Fk;
		this.#=z3pO2B3yhFRBi.Location = new Point(93, 9);
		this.#=z3pO2B3yhFRBi.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029448);
		this.#=z3pO2B3yhFRBi.Size = new Size(163, 23);
		this.#=z3pO2B3yhFRBi.TabIndex = 0;
		this.#=z3pO2B3yhFRBi.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029431);
		this.#=z3pO2B3yhFRBi.UseVisualStyleBackColor = true;
		this.#=z3pO2B3yhFRBi.Click += this.#=zJbN7AMBd12di0Rl_AQ==;
		this.#=zHeAVXAs=.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
		this.#=zHeAVXAs=.Location = new Point(269, 9);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 1;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zqGU29PfWHhZMyVFjNg==.Controls.Add(this.#=zLxa7nLB9JIQS);
		this.#=zqGU29PfWHhZMyVFjNg==.Controls.Add(this.#=z8DimCOMwhKCu);
		this.#=zqGU29PfWHhZMyVFjNg==.Dock = DockStyle.Fill;
		this.#=zqGU29PfWHhZMyVFjNg==.Location = new Point(0, 0);
		this.#=zqGU29PfWHhZMyVFjNg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029399);
		this.#=zqGU29PfWHhZMyVFjNg==.SelectedIndex = 0;
		this.#=zqGU29PfWHhZMyVFjNg==.Size = new Size(356, 273);
		this.#=zqGU29PfWHhZMyVFjNg==.TabIndex = 0;
		this.#=zLxa7nLB9JIQS.Controls.Add(this.#=zoWsOaIGwOm$R4MvjYQ==);
		this.#=zLxa7nLB9JIQS.Location = new Point(4, 22);
		this.#=zLxa7nLB9JIQS.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029620);
		this.#=zLxa7nLB9JIQS.Padding = new Padding(3);
		this.#=zLxa7nLB9JIQS.Size = new Size(342, 247);
		this.#=zLxa7nLB9JIQS.TabIndex = 0;
		this.#=zLxa7nLB9JIQS.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029598);
		this.#=zLxa7nLB9JIQS.UseVisualStyleBackColor = true;
		this.#=z8DimCOMwhKCu.Controls.Add(this.#=zjeQAlxw6ZiBw);
		this.#=z8DimCOMwhKCu.Controls.Add(this.#=zCccyDJ8677flQDO$iA==);
		this.#=z8DimCOMwhKCu.Location = new Point(4, 22);
		this.#=z8DimCOMwhKCu.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029580);
		this.#=z8DimCOMwhKCu.Padding = new Padding(3);
		this.#=z8DimCOMwhKCu.Size = new Size(348, 247);
		this.#=z8DimCOMwhKCu.TabIndex = 1;
		this.#=z8DimCOMwhKCu.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029558);
		this.#=z8DimCOMwhKCu.UseVisualStyleBackColor = true;
		this.#=zoWsOaIGwOm$R4MvjYQ==.Dock = DockStyle.Fill;
		this.#=zoWsOaIGwOm$R4MvjYQ==.Location = new Point(3, 3);
		this.#=zoWsOaIGwOm$R4MvjYQ==.MaxLength = 0;
		this.#=zoWsOaIGwOm$R4MvjYQ==.Multiline = true;
		this.#=zoWsOaIGwOm$R4MvjYQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029540);
		this.#=zoWsOaIGwOm$R4MvjYQ==.Size = new Size(336, 241);
		this.#=zoWsOaIGwOm$R4MvjYQ==.TabIndex = 0;
		this.#=zCccyDJ8677flQDO$iA==.Dock = DockStyle.Top;
		this.#=zCccyDJ8677flQDO$iA==.Location = new Point(3, 3);
		this.#=zCccyDJ8677flQDO$iA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029506);
		this.#=zCccyDJ8677flQDO$iA==.ReadOnly = true;
		this.#=zCccyDJ8677flQDO$iA==.Size = new Size(342, 20);
		this.#=zCccyDJ8677flQDO$iA==.TabIndex = 0;
		this.#=zjeQAlxw6ZiBw.Location = new Point(114, 29);
		this.#=zjeQAlxw6ZiBw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031272);
		this.#=zjeQAlxw6ZiBw.Size = new Size(75, 23);
		this.#=zjeQAlxw6ZiBw.TabIndex = 1;
		this.#=zjeQAlxw6ZiBw.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113871);
		this.#=zjeQAlxw6ZiBw.UseVisualStyleBackColor = true;
		this.#=zjeQAlxw6ZiBw.Click += this.#=zJCGehHOlK9f_35XQmA==;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(356, 321);
		base.Controls.Add(this.#=z8bcpLWm$DpFw);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031251);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909039801);
		this.#=z8bcpLWm$DpFw.Panel1.ResumeLayout(false);
		this.#=z8bcpLWm$DpFw.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).EndInit();
		this.#=z8bcpLWm$DpFw.ResumeLayout(false);
		this.#=zqGU29PfWHhZMyVFjNg==.ResumeLayout(false);
		this.#=zLxa7nLB9JIQS.ResumeLayout(false);
		this.#=zLxa7nLB9JIQS.PerformLayout();
		this.#=z8DimCOMwhKCu.ResumeLayout(false);
		this.#=z8DimCOMwhKCu.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x0400024B RID: 587
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x0400024C RID: 588
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zBMwJDJhgPcAP;

	// Token: 0x0400024E RID: 590
	private SplitContainer #=z8bcpLWm$DpFw;

	// Token: 0x0400024F RID: 591
	private Button #=zHeAVXAs=;

	// Token: 0x04000250 RID: 592
	private Button #=zoiw27qM7AzYz;

	// Token: 0x04000251 RID: 593
	private Button #=z3pO2B3yhFRBi;

	// Token: 0x04000252 RID: 594
	private TabControl #=zqGU29PfWHhZMyVFjNg==;

	// Token: 0x04000253 RID: 595
	private TabPage #=zLxa7nLB9JIQS;

	// Token: 0x04000254 RID: 596
	private TabPage #=z8DimCOMwhKCu;

	// Token: 0x04000255 RID: 597
	private TextBox #=zoWsOaIGwOm$R4MvjYQ==;

	// Token: 0x04000256 RID: 598
	private TextBox #=zCccyDJ8677flQDO$iA==;

	// Token: 0x04000257 RID: 599
	private Button #=zjeQAlxw6ZiBw;

	// Token: 0x04000258 RID: 600
	private OpenFileDialog #=z7z_FFqD1kV0N;
}
