﻿using System;
using System.Collections;
using System.Text;

// Token: 0x02000073 RID: 115
internal abstract class #=z5f6TTGxcn4$84XHZwuuLpuiShv55 : #=zrACqpkJvpkMu2ypmK4UXXdQ=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600034A RID: 842 RVA: 0x0001EC04 File Offset: 0x0001CE04
	public #=z5f6TTGxcn4$84XHZwuuLpuiShv55()
	{
	}

	// Token: 0x0600034B RID: 843 RVA: 0x0001EC0C File Offset: 0x0001CE0C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		sbyte[] array2 = new sbyte[0];
		for (int i = array.Length - 1; i >= 0; i--)
		{
			sbyte[] array3 = array[i].#=ztbIWLuVjfGLU();
			sbyte[] array4 = new sbyte[array2.Length + array3.Length];
			Array.Copy(array2, 0, array4, 0, array2.Length);
			Array.Copy(array3, 0, array4, array2.Length, array3.Length);
			array2 = array4;
		}
		sbyte[] array5 = new sbyte[array2.Length + 1];
		Array.Copy(array2, 0, array5, 0, array2.Length);
		array5[array2.Length] = this.#=znmVMpDg=().#=zd$BbM3Y=();
		return array5;
	}

	// Token: 0x0600034C RID: 844
	internal abstract #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=();

	// Token: 0x0600034D RID: 845 RVA: 0x0001EC98 File Offset: 0x0001CE98
	public virtual int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		return 0;
	}

	// Token: 0x0600034E RID: 846 RVA: 0x0001EC9C File Offset: 0x0001CE9C
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4= = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
		#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4=2 = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
		this.#=zdJYbEvQ=(#=zpvGJrv4=);
		this.#=zdJYbEvQ=(#=zpvGJrv4=2);
	}

	// Token: 0x0600034F RID: 847 RVA: 0x0001ECD0 File Offset: 0x0001CED0
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=zSpOkW5A=(#=zXvwCnz8=);
		#=zXvwCnz8=.Append(this.#=ze3HB9kQ=());
		array[0].#=zSpOkW5A=(#=zXvwCnz8=);
	}

	// Token: 0x06000350 RID: 848 RVA: 0x0001ECF8 File Offset: 0x0001CEF8
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
		array[0].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
	}

	// Token: 0x06000351 RID: 849 RVA: 0x0001ED14 File Offset: 0x0001CF14
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		array[0].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06000352 RID: 850 RVA: 0x0001ED34 File Offset: 0x0001CF34
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		array[0].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06000353 RID: 851 RVA: 0x0001ED54 File Offset: 0x0001CF54
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		array[0].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x0001ED74 File Offset: 0x0001CF74
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		array[1].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		array[0].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06000355 RID: 853
	public abstract string #=ze3HB9kQ=();
}
