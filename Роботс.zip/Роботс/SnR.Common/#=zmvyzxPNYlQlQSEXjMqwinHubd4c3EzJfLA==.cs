﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x0200028D RID: 653
internal sealed partial class #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== : Form
{
	// Token: 0x060013E3 RID: 5091 RVA: 0x00098F90 File Offset: 0x00097190
	internal #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zBMwJDJhgPcAP = #=zJUGTDqUtMnBf;
		this.#=zKv3CDCW8Hkq75FzKLg==(null);
		this.#=zgpzgXirqPT5_();
		if (#=zJUGTDqUtMnBf != null)
		{
			this.#=zcIGb4QLv47ld.#=z20ohAjI=(this.#=zshVEGQI=.#=zol80P7TKoihZ().FindAll(new Predicate<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(this.#=zvtk1VyLjU6SkE$KUPwUzOa0=)));
		}
		else
		{
			this.#=zcIGb4QLv47ld.#=z20ohAjI=(this.#=zshVEGQI=.#=zol80P7TKoihZ());
		}
		this.#=z40MnTxftey5E();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060013E4 RID: 5092 RVA: 0x0009900C File Offset: 0x0009720C
	public List<int> #=zq7_P5s5zGTyvq8S1AQ==()
	{
		return this.#=z$aOxcfuWtdn8JFyLNq1sIf4=;
	}

	// Token: 0x060013E5 RID: 5093 RVA: 0x00099014 File Offset: 0x00097214
	public void #=zKv3CDCW8Hkq75FzKLg==(List<int> #=z$Ib9gYQ=)
	{
		this.#=z$aOxcfuWtdn8JFyLNq1sIf4= = #=z$Ib9gYQ=;
	}

	// Token: 0x060013E6 RID: 5094 RVA: 0x00099020 File Offset: 0x00097220
	public #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zWcFUKBzZx1_L #=zpJso_yLM1u0C()
	{
		return this.#=zfVVCoyxNZNNBVRs$NQBDHbQ=;
	}

	// Token: 0x060013E7 RID: 5095 RVA: 0x00099028 File Offset: 0x00097228
	public void #=zICocnal_tob$(#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zWcFUKBzZx1_L #=z$Ib9gYQ=)
	{
		this.#=zfVVCoyxNZNNBVRs$NQBDHbQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x060013E8 RID: 5096 RVA: 0x00099034 File Offset: 0x00097234
	private void #=z40MnTxftey5E()
	{
		List<int> list = this.#=z0GxUXow=.#=zBziBGR4jZQ9z();
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list2 = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		for (int i = 0; i < this.#=zshVEGQI=.#=zol80P7TKoihZ().Count; i++)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[i];
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == ((this.#=zBMwJDJhgPcAP != null) ? this.#=zBMwJDJhgPcAP.#=zYgvZuBwR$a1C() : #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C()) && this.#=zcIGb4QLv47ld.#=zQLl7KKs=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==))
			{
				list2.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(i, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==(), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z72grV1lsvZeM(), list.Contains(i)));
			}
		}
		this.#=z0GxUXow=.#=z20ohAjI=(list2, true, false);
	}

	// Token: 0x060013E9 RID: 5097 RVA: 0x000990E4 File Offset: 0x000972E4
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<int> list = this.#=z0GxUXow=.#=zBziBGR4jZQ9z();
		if (this.#=zpJso_yLM1u0C() != null)
		{
			#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== = this.#=zpJso_yLM1u0C()(list);
			if (#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== != null)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
				return;
			}
		}
		this.#=zKv3CDCW8Hkq75FzKLg==(list);
		base.DialogResult = DialogResult.OK;
		base.Close();
	}

	// Token: 0x060013EA RID: 5098 RVA: 0x00099134 File Offset: 0x00097334
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.DialogResult = DialogResult.Cancel;
		base.Close();
	}

	// Token: 0x060013EB RID: 5099 RVA: 0x00099144 File Offset: 0x00097344
	private void #=z0sH6H1CW6kd3hI$lNg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z40MnTxftey5E();
	}

	// Token: 0x060013ED RID: 5101 RVA: 0x0009916C File Offset: 0x0009736C
	private void #=zgpzgXirqPT5_()
	{
		this.#=z0GxUXow= = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zHeAVXAs= = new Button();
		this.#=zuCaP$Fc= = new Button();
		this.#=zLVZn1UbnVZtw = new SplitContainer();
		this.#=zcIGb4QLv47ld = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		((ISupportInitialize)this.#=zLVZn1UbnVZtw).BeginInit();
		this.#=zLVZn1UbnVZtw.Panel1.SuspendLayout();
		this.#=zLVZn1UbnVZtw.Panel2.SuspendLayout();
		this.#=zLVZn1UbnVZtw.SuspendLayout();
		base.SuspendLayout();
		this.#=z0GxUXow=.AutoScroll = true;
		this.#=z0GxUXow=.AutoSize = true;
		this.#=z0GxUXow=.BorderStyle = BorderStyle.FixedSingle;
		this.#=z0GxUXow=.Dock = DockStyle.Fill;
		this.#=z0GxUXow=.Location = new Point(0, 0);
		this.#=z0GxUXow=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030099);
		this.#=z0GxUXow=.Size = new Size(356, 451);
		this.#=z0GxUXow=.TabIndex = 1;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel2;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zLVZn1UbnVZtw);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zuCaP$Fc=);
		this.#=zByiHPAwyKD$Q.Size = new Size(597, 504);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 451;
		this.#=zByiHPAwyKD$Q.TabIndex = 2;
		this.#=zHeAVXAs=.Location = new Point(299, 14);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 1;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zuCaP$Fc=.Location = new Point(64, 14);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(75, 23);
		this.#=zuCaP$Fc=.TabIndex = 0;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051773);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		this.#=zLVZn1UbnVZtw.Dock = DockStyle.Fill;
		this.#=zLVZn1UbnVZtw.Location = new Point(0, 0);
		this.#=zLVZn1UbnVZtw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029889);
		this.#=zLVZn1UbnVZtw.Panel1.Controls.Add(this.#=z0GxUXow=);
		this.#=zLVZn1UbnVZtw.Panel2.Controls.Add(this.#=zcIGb4QLv47ld);
		this.#=zLVZn1UbnVZtw.Size = new Size(597, 451);
		this.#=zLVZn1UbnVZtw.SplitterDistance = 356;
		this.#=zLVZn1UbnVZtw.TabIndex = 2;
		this.#=zcIGb4QLv47ld.Dock = DockStyle.Fill;
		this.#=zcIGb4QLv47ld.Location = new Point(0, 0);
		this.#=zcIGb4QLv47ld.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091904);
		this.#=zcIGb4QLv47ld.Size = new Size(237, 451);
		this.#=zcIGb4QLv47ld.TabIndex = 0;
		this.#=zcIGb4QLv47ld.#=znoclypZSSO9V(new EventHandler(this.#=z0sH6H1CW6kd3hI$lNg==));
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(597, 504);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030086);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030063);
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		this.#=zLVZn1UbnVZtw.Panel1.ResumeLayout(false);
		this.#=zLVZn1UbnVZtw.Panel1.PerformLayout();
		this.#=zLVZn1UbnVZtw.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zLVZn1UbnVZtw).EndInit();
		this.#=zLVZn1UbnVZtw.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x060013EE RID: 5102 RVA: 0x0009967C File Offset: 0x0009787C
	private bool #=zvtk1VyLjU6SkE$KUPwUzOa0=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=)
	{
		return #=zQrqFdos=.#=zYgvZuBwR$a1C() == this.#=zBMwJDJhgPcAP.#=zYgvZuBwR$a1C();
	}

	// Token: 0x04000B6C RID: 2924
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000B6D RID: 2925
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zBMwJDJhgPcAP;

	// Token: 0x04000B6E RID: 2926
	private List<int> #=z$aOxcfuWtdn8JFyLNq1sIf4=;

	// Token: 0x04000B6F RID: 2927
	private #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zWcFUKBzZx1_L #=zfVVCoyxNZNNBVRs$NQBDHbQ=;

	// Token: 0x04000B71 RID: 2929
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=z0GxUXow=;

	// Token: 0x04000B72 RID: 2930
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x04000B73 RID: 2931
	private Button #=zHeAVXAs=;

	// Token: 0x04000B74 RID: 2932
	private Button #=zuCaP$Fc=;

	// Token: 0x04000B75 RID: 2933
	private SplitContainer #=zLVZn1UbnVZtw;

	// Token: 0x04000B76 RID: 2934
	private #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g== #=zcIGb4QLv47ld;

	// Token: 0x0200028E RID: 654
	// (Invoke) Token: 0x060013F0 RID: 5104
	public delegate #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zWcFUKBzZx1_L(List<int> #=zYTJwN28BkWlV);
}
