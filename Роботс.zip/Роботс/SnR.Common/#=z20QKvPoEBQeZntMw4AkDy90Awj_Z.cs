﻿using System;
using Skink.SnR.Common;

// Token: 0x02000042 RID: 66
internal sealed class #=z20QKvPoEBQeZntMw4AkDy90Awj_Z
{
	// Token: 0x06000217 RID: 535 RVA: 0x00014D18 File Offset: 0x00012F18
	public AccessLevels #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000218 RID: 536 RVA: 0x00014D20 File Offset: 0x00012F20
	public void #=zFzGvi_S6jJhE(AccessLevels #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000219 RID: 537 RVA: 0x00014D2C File Offset: 0x00012F2C
	public int #=z6O$zzzXbpQKK()
	{
		return this.#=zFVX7keEK$_ogDTC92pjdpEU=;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x00014D34 File Offset: 0x00012F34
	public void #=zLxATV0X$vbyM(int #=z$Ib9gYQ=)
	{
		this.#=zFVX7keEK$_ogDTC92pjdpEU= = #=z$Ib9gYQ=;
	}

	// Token: 0x0400009E RID: 158
	private AccessLevels #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400009F RID: 159
	private int #=zFVX7keEK$_ogDTC92pjdpEU=;
}
