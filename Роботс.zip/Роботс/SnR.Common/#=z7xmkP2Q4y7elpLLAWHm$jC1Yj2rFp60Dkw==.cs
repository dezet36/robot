﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200009E RID: 158
internal class #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== : Task
{
	// Token: 0x0600042F RID: 1071 RVA: 0x00024698 File Offset: 0x00022898
	public #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSeverities #=z_qaYpFQ=, DateTime #=zxSBcx18=, TimeSpan #=zWYQnr7CKtxq8, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo, TaskSendUnitTypes #=zPJCAPrY=, string #=z40sk5mc=, string #=zQI5IZCs=, string #=zNvCMwussKumm, int #=zQi6$ZU4=, int #=zal_uGJDR5j5ksiE7zg==) : base(TaskSources.Manual, #=z_qaYpFQ=, TaskTypes.SendUnit, #=zxSBcx18=, #=zWYQnr7CKtxq8, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
		this.#=zpl32$sDZaPJk = #=zPJCAPrY=;
		this.#=zmVXP3Bk= = #=z40sk5mc=;
		this.#=zZcIa_pE= = #=zQI5IZCs=;
		this.#=zbgbRZmnkAJUm = #=zNvCMwussKumm;
		this.#=zbmPYZrYJQh6GIS72Kw== = false;
		this.#=zk0v0anqlvme$ = #=zQi6$ZU4=;
		this.#=zC9Fv_XfemebcgWxZeQ== = #=zal_uGJDR5j5ksiE7zg==;
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x000246F0 File Offset: 0x000228F0
	public #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSources #=zk656SlQ=, TaskSeverities #=z_qaYpFQ=, TaskTypes #=zmV6257E=, DateTime #=zxSBcx18=, TimeSpan #=zWYQnr7CKtxq8, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo, TaskSendUnitTypes #=zPJCAPrY=, string #=z40sk5mc=, string #=zQI5IZCs=, string #=zNvCMwussKumm, int #=zQi6$ZU4=, int #=zal_uGJDR5j5ksiE7zg==) : base(#=zk656SlQ=, #=z_qaYpFQ=, #=zmV6257E=, #=zxSBcx18=, #=zWYQnr7CKtxq8, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
		this.#=zpl32$sDZaPJk = #=zPJCAPrY=;
		this.#=zmVXP3Bk= = #=z40sk5mc=;
		this.#=zZcIa_pE= = #=zQI5IZCs=;
		this.#=zbgbRZmnkAJUm = #=zNvCMwussKumm;
		this.#=zbmPYZrYJQh6GIS72Kw== = false;
		this.#=zk0v0anqlvme$ = #=zQi6$ZU4=;
		this.#=zC9Fv_XfemebcgWxZeQ== = #=zal_uGJDR5j5ksiE7zg==;
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x0002474C File Offset: 0x0002294C
	public #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x0002475C File Offset: 0x0002295C
	public #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(MasterTask #=zwcZwAIGe3vUR) : base(#=zwcZwAIGe3vUR)
	{
		#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== = (#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==)#=zwcZwAIGe3vUR.Task;
		this.#=zpl32$sDZaPJk = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zeWSpwqqtMyd5();
		this.#=zmVXP3Bk= = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zuFPZLKs=();
		this.#=zZcIa_pE= = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.Details;
		this.#=zbgbRZmnkAJUm = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zlIXJ9$NfUZc_();
		this.#=zbmPYZrYJQh6GIS72Kw== = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zAhLffS29HflP_FQzRg==();
		this.#=zk0v0anqlvme$ = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zyf0z0_GA_Vwr();
		this.#=zC9Fv_XfemebcgWxZeQ== = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zi0WaUTfkdjJMIVEyAg==();
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x000247D0 File Offset: 0x000229D0
	public TaskSendUnitTypes #=zeWSpwqqtMyd5()
	{
		return this.#=zpl32$sDZaPJk;
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x000247D8 File Offset: 0x000229D8
	public string #=zuFPZLKs=()
	{
		return this.#=zmVXP3Bk=;
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x000247E0 File Offset: 0x000229E0
	public string #=zlIXJ9$NfUZc_()
	{
		return this.#=zbgbRZmnkAJUm;
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x000247E8 File Offset: 0x000229E8
	public bool #=zAhLffS29HflP_FQzRg==()
	{
		return this.#=zbmPYZrYJQh6GIS72Kw==;
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x000247F0 File Offset: 0x000229F0
	public void #=zDQLgsk65lVyJSMVPHQ==(bool #=z$Ib9gYQ=)
	{
		this.#=zbmPYZrYJQh6GIS72Kw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x000247FC File Offset: 0x000229FC
	public int #=zyf0z0_GA_Vwr()
	{
		return this.#=zk0v0anqlvme$;
	}

	// Token: 0x06000439 RID: 1081 RVA: 0x00024804 File Offset: 0x00022A04
	public int #=zi0WaUTfkdjJMIVEyAg==()
	{
		return this.#=zC9Fv_XfemebcgWxZeQ==;
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600043A RID: 1082 RVA: 0x0002480C File Offset: 0x00022A0C
	public override string Details
	{
		get
		{
			return this.#=zZcIa_pE=;
		}
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x00024814 File Offset: 0x00022A14
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zpl32$sDZaPJk = (TaskSendUnitTypes)JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875098), 0);
		this.#=zmVXP3Bk= = JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875081), string.Empty);
		this.#=zZcIa_pE= = JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875065), string.Empty);
		this.#=zbgbRZmnkAJUm = JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875052), string.Empty);
		this.#=zbmPYZrYJQh6GIS72Kw== = (JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875036), 0) == 1);
		this.#=zk0v0anqlvme$ = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875023), 0);
		this.#=zC9Fv_XfemebcgWxZeQ== = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875260), 0);
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x000248D4 File Offset: 0x00022AD4
	public override void UpdateTask(Dictionary<string, object> #=z8e5z318=)
	{
		base.UpdateTask(#=z8e5z318=);
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x1700000D RID: 13
	// (get) Token: 0x0600043D RID: 1085 RVA: 0x000248E4 File Offset: 0x00022AE4
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874248);
		}
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x000248F0 File Offset: 0x00022AF0
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875098)] = (int)this.#=zpl32$sDZaPJk;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875081)] = this.#=zmVXP3Bk=;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875065)] = this.#=zZcIa_pE=;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875052)] = this.#=zbgbRZmnkAJUm;
		if (this.#=zbmPYZrYJQh6GIS72Kw==)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875036)] = 1;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875023)] = this.#=zk0v0anqlvme$;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875260)] = this.#=zC9Fv_XfemebcgWxZeQ==;
		return dictionary;
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x000249B8 File Offset: 0x00022BB8
	public void #=zmeOF8bE=(string #=zNvCMwussKumm)
	{
		this.#=zbgbRZmnkAJUm = #=zNvCMwussKumm;
	}

	// Token: 0x04000187 RID: 391
	private TaskSendUnitTypes #=zpl32$sDZaPJk;

	// Token: 0x04000188 RID: 392
	private string #=zmVXP3Bk=;

	// Token: 0x04000189 RID: 393
	private string #=zZcIa_pE=;

	// Token: 0x0400018A RID: 394
	private string #=zbgbRZmnkAJUm;

	// Token: 0x0400018B RID: 395
	private bool #=zbmPYZrYJQh6GIS72Kw==;

	// Token: 0x0400018C RID: 396
	private int #=zk0v0anqlvme$;

	// Token: 0x0400018D RID: 397
	private int #=zC9Fv_XfemebcgWxZeQ==;
}
