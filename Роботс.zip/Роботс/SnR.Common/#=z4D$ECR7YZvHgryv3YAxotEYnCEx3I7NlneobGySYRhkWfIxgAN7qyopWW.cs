﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000069 RID: 105
internal sealed class #=z4D$ECR7YZvHgryv3YAxotEYnCEx3I7NlneobGySYRhkWfIxgAN7qyopWWSD0 : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600030C RID: 780 RVA: 0x0001C110 File Offset: 0x0001A310
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
	}

	// Token: 0x0600030D RID: 781 RVA: 0x0001C12C File Offset: 0x0001A32C
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==))
		{
			return;
		}
		#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== = (#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==)this.#=zcDRV51Ut$7oP;
		object[] array = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
		if (array == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934751), Array.Empty<object>());
		}
		bool flag = false;
		DateTime dateTime = DateTime.MinValue;
		object[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			Dictionary<string, object> obj = (Dictionary<string, object>)JSONManager.GetObject((Dictionary<string, object>)array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
			if (JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0) == 2)
			{
				int @int = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
				DateTime dateTime2 = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(JSONManager.GetDateTime(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false));
				if (#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==.#=zs6AfR9w58BN2() == @int)
				{
					if (#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==.ExecutionTime - TimeSpan.FromMinutes(10.0) < dateTime2)
					{
						flag = true;
						Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934725));
						StringBuilder stringBuilder = new StringBuilder();
						if (dictionary != null)
						{
							foreach (KeyValuePair<string, object> keyValuePair in dictionary)
							{
								int num = Convert.ToInt32(keyValuePair.Value);
								if (num > 0)
								{
									if (stringBuilder.Length > 0)
									{
										stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
									}
									stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070731), #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=ziW1QRqvFMUe2(keyValuePair.Key), num);
								}
							}
						}
						if (stringBuilder.Length != 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934527), new object[]
							{
								stringBuilder
							});
							break;
						}
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z88R87Aei0uiQ(this.#=z8StzeqE=.#=zYgvZuBwR$a1C(), @int);
						#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobbery);
						#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null) ? #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=z5_3JqsL118hV() : #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGV9CLmCENINvspF3MQ==(this.#=z8StzeqE=, this.#=zBsXSanI=);
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zk$6QZNA=(@int);
						if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= == null)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934707), new object[]
							{
								@int.ToString()
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934678), new object[]
							{
								@int
							});
							break;
						}
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=z5ktH1NpFood7(true);
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zp0wcrTDVPUwj(DateTime.Now);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934851), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
						});
						if (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null)
						{
							#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zsobh2arZ__ufEqVOvA==(true);
							break;
						}
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGncKSH4oJhxW9OLT6A==(#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==, this.#=z8StzeqE=);
						break;
					}
					else if (dateTime2 > dateTime)
					{
						dateTime = dateTime2;
					}
				}
			}
		}
		if (!flag)
		{
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(this.#=zG2wnL_q7IxpD, this.#=z8StzeqE=, null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zFgabd6AP3NvQ(false);
			List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zqWzt0eB5fbATSwpS3Q==();
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = null;
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in list)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_() == #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==.#=zs6AfR9w58BN2() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2 && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0))
				{
					#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2;
					break;
				}
			}
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== != null)
			{
				DateTime d = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() > DateTime.MinValue) ? #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() : DateTime.Now;
				this.#=zcDRV51Ut$7oP.ExecutionTime = d + TimeSpan.FromMinutes(3.0);
				this.#=zcDRV51Ut$7oP.State = TaskStates.Rescheduled;
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934467), new object[]
				{
					this.#=zcDRV51Ut$7oP.ExecutionTime
				});
			}
			else if (dateTime != DateTime.MinValue)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934650), new object[]
				{
					dateTime
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934532), Array.Empty<object>());
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsBuyTroopsAfterRob)
		{
			#=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zx6mAD3WBJ$C1JPgizQctvRQ=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zVG1EPv1OUDdyLeGHGQ==);
			int num2 = this.#=z3yL5bKs=[ResourceTypes.Grain];
			if (num2 > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934217), new object[]
				{
					num2
				});
				object data = JSONManager.GetData(this.#=zBsXSanI=.#=zeoI_JM$qmO3Jp7VRURuP390=());
				base.#=zL1HTbwC75LO$(data);
				#=zcAioOxLrSCaNUY8WB6BWlWow_$LLreAAm98rBuM7Nvlpo_dosw==.#=zwqF5KngciPEuUAe8xmYIVt0=(this.#=zG2wnL_q7IxpD, data);
			}
		}
	}

	// Token: 0x04000110 RID: 272
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x04000111 RID: 273
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;
}
