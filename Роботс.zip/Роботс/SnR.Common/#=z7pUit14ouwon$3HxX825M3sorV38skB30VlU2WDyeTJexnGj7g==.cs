﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.Managers;

// Token: 0x02000098 RID: 152
internal sealed class #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==
{
	// Token: 0x06000416 RID: 1046 RVA: 0x000240CC File Offset: 0x000222CC
	public #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zbsxKkj4=(JSONManager.GetInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zMU3h5OahHKt6(JSONManager.GetInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), 0));
		this.#=zbrtvpkQ=((#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM=)JSONManager.GetInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		object[] array = JSONManager.GetArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399));
		this.#=zdMm8cbXw4OEf(new List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=>());
		if (array != null)
		{
			foreach (Dictionary<string, object> obj in array)
			{
				List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=> list = this.#=z6Uo9D2yKen_Y();
				#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM= #=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM= = new #=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=();
				#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=zq35yvFj7UV2r(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
				#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=zn0NDUGvh2f1QrKM1bg==(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), 0));
				#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=zedb$WwBQsoJF(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
				list.Add(#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=);
			}
		}
		object[] array2 = JSONManager.GetArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
		this.#=z_WNSoYvnuWmrtg2a2Q==(new List<int>());
		if (array2 != null)
		{
			foreach (Dictionary<string, object> obj2 in array2)
			{
				this.#=ziXknzq7jSfAR0g9mRA==().Add(JSONManager.GetInt(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			}
		}
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x00024208 File Offset: 0x00022408
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x00024210 File Offset: 0x00022410
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x0002421C File Offset: 0x0002241C
	public int #=ztj93y6niVpCR()
	{
		return this.#=zW7kHJvkAORBWJxF1eQ==;
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x00024224 File Offset: 0x00022424
	public void #=zMU3h5OahHKt6(int #=z$Ib9gYQ=)
	{
		this.#=zW7kHJvkAORBWJxF1eQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x00024230 File Offset: 0x00022430
	public #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM= #=z9ZHUN$Y=()
	{
		return this.#=zZqJ39hEu7SS_bez5Ag==;
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x00024238 File Offset: 0x00022438
	public void #=zbrtvpkQ=(#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM= #=z$Ib9gYQ=)
	{
		this.#=zZqJ39hEu7SS_bez5Ag== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x00024244 File Offset: 0x00022444
	public List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=> #=z6Uo9D2yKen_Y()
	{
		return this.#=zDAr22$BxOb_X0tWnjA==;
	}

	// Token: 0x0600041E RID: 1054 RVA: 0x0002424C File Offset: 0x0002244C
	public void #=zdMm8cbXw4OEf(List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=> #=z$Ib9gYQ=)
	{
		this.#=zDAr22$BxOb_X0tWnjA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600041F RID: 1055 RVA: 0x00024258 File Offset: 0x00022458
	public List<int> #=ziXknzq7jSfAR0g9mRA==()
	{
		return this.#=znq5U_RPKwa1XDq$XN2bNUUI=;
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x00024260 File Offset: 0x00022460
	public void #=z_WNSoYvnuWmrtg2a2Q==(List<int> #=z$Ib9gYQ=)
	{
		this.#=znq5U_RPKwa1XDq$XN2bNUUI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000421 RID: 1057 RVA: 0x0002426C File Offset: 0x0002246C
	public string #=zl9Bdc6w=(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zyTbmfrB4ge6m)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < this.#=z6Uo9D2yKen_Y().Count; i++)
		{
			#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM= #=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM= = this.#=z6Uo9D2yKen_Y()[i];
			StringBuilder stringBuilder2 = new StringBuilder();
			if (#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=z4zXcBHTOAiAX() > 0)
			{
				if (stringBuilder2.Length > 0)
				{
					stringBuilder2.Append('/');
				}
				stringBuilder2.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060630)));
				stringBuilder2.Append(' ');
				stringBuilder2.Append(#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=z4zXcBHTOAiAX());
			}
			if (#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=z6Dr4DsOt5CbKnBxwYg==() > 0)
			{
				if (stringBuilder2.Length > 0)
				{
					stringBuilder2.Append('/');
				}
				stringBuilder2.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060611)));
				stringBuilder2.Append(' ');
				stringBuilder2.Append(#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=z6Dr4DsOt5CbKnBxwYg==());
			}
			if (#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=zFMDiymuLQ7_4() > 0)
			{
				if (stringBuilder2.Length > 0)
				{
					stringBuilder2.Append('/');
				}
				stringBuilder2.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060850)));
				stringBuilder2.Append(' ');
				stringBuilder2.Append(#=zyTbmfrB4ge6m.#=zd634hMCtcd$T(#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=.#=zFMDiymuLQ7_4()));
			}
			if (stringBuilder2.Length > 0)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(stringBuilder2);
			}
		}
		if (stringBuilder.Length == 0)
		{
			stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060847)));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0400017E RID: 382
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400017F RID: 383
	private int #=zW7kHJvkAORBWJxF1eQ==;

	// Token: 0x04000180 RID: 384
	private #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM= #=zZqJ39hEu7SS_bez5Ag==;

	// Token: 0x04000181 RID: 385
	private List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=> #=zDAr22$BxOb_X0tWnjA==;

	// Token: 0x04000182 RID: 386
	private List<int> #=znq5U_RPKwa1XDq$XN2bNUUI=;

	// Token: 0x02000099 RID: 153
	internal enum #=zY9gFTlM=
	{

	}
}
