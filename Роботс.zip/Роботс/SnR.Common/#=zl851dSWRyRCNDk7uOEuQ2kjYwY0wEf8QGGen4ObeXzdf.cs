﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000279 RID: 633
internal sealed class #=zl851dSWRyRCNDk7uOEuQ2kjYwY0wEf8QGGen4ObeXzdf : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600131E RID: 4894 RVA: 0x00094AF4 File Offset: 0x00092CF4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x0600131F RID: 4895 RVA: 0x00094AF8 File Offset: 0x00092CF8
	protected override void #=zvb5bnug=()
	{
		#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI= #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI= = (#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=)this.#=zcDRV51Ut$7oP;
		bool flag = false;
		for (int i = 0; i < 10; i++)
		{
			int num = #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zf0e9blCCGf6ut3r1Nw==();
			int num2 = #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zbRWovF5fxGmOqm7gAQ==();
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983423), new object[]
			{
				num,
				num2
			});
			string text = this.#=zBsXSanI=.#=zpeSgyDU=(num, num2);
			if (text.Length < 500 && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965698)))
			{
				flag = true;
				break;
			}
			if (text.ToLower().Contains(#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zbfOGJA_8wt3H()) && text.ToLower().Contains(#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zTqDBdc7DKJmY()))
			{
				object[] array = (object[])((Dictionary<string, object>)JSONManager.GetData(text))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)];
				for (int j = 0; j < array.Length; j++)
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zT$2iWxnv3qme((Dictionary<string, object>)array[j]);
					if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=().ToLower().Contains(#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zbfOGJA_8wt3H()) && #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zTqDBdc7DKJmY().ToLower().Contains(#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zTqDBdc7DKJmY()) && !#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zvVU8NknI_fMNii0PDw==().Contains(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=()))
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zY$pvpstqHPJzppOpm5pa2HJPtuI4(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==, this.#=z8StzeqE=, this.#=zBsXSanI=);
						#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ().Add(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==);
						#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zvVU8NknI_fMNii0PDw==().Add(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=());
					}
				}
			}
			#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zrYsCATIY3Mmo();
		}
		if (!flag)
		{
			if (#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ().Count > #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zWJC489bUrBis())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965695), new object[]
				{
					#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ().Count
				});
				#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zYmLC4b5ED0x4(#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ().Count);
				return;
			}
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965634), new object[]
			{
				#=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ().Count
			});
			foreach (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2 in #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=.#=zoK6IbO99EGFZ())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965844), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zkfqcY3I=(),
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zfTB62qendhk_VEy8rw==(),
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zY0soxphmGIACbOHy6A==(),
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zvnZc$RhG_1Du(),
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zj661vGqZTMsoJ4JrPg==()
				});
			}
			this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Remove(this.#=zcDRV51Ut$7oP);
		}
	}
}
