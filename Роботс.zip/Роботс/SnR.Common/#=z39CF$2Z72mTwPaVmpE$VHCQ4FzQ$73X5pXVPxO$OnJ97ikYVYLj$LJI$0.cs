﻿using System;

// Token: 0x0200004E RID: 78
internal sealed class #=z39CF$2Z72mTwPaVmpE$VHCQ4FzQ$73X5pXVPxO$OnJ97ikYVYLj$LJI$0wu8 : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000257 RID: 599 RVA: 0x00015B6C File Offset: 0x00013D6C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06000258 RID: 600 RVA: 0x00015B70 File Offset: 0x00013D70
	protected override void #=zvb5bnug=()
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zY$pvpstqHPJzppOpm5pa2HJPtuI4(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B(), this.#=z8StzeqE=, this.#=zBsXSanI=);
		if (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==() > 0)
		{
			int num = 5;
			int num2 = num;
			bool flag = false;
			while (!flag)
			{
				string text = this.#=zBsXSanI=.#=z8fSxejFvXLJ80rgf3$8DkdQ=(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==(), num2);
				text = text.Trim();
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929381), new object[]
					{
						this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
						num2
					});
					num2 = num;
				}
				else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929325)))
				{
					num2--;
					if (num2 <= 0)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929286), Array.Empty<object>());
						flag = true;
					}
				}
				else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929489)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929472), new object[]
					{
						this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==()
					});
					flag = true;
				}
				else
				{
					if (text.Length > 1000)
					{
						text = text.Substring(0, 1000);
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929408), new object[]
					{
						this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
						text
					});
					flag = true;
				}
			}
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929080), Array.Empty<object>());
	}
}
