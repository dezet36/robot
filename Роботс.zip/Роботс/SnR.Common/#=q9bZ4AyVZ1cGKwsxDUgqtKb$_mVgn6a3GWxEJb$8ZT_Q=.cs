﻿using System;
using Microsoft.Win32;

// Token: 0x02000003 RID: 3
internal static class #=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=
{
	// Token: 0x06000003 RID: 3 RVA: 0x00002060 File Offset: 0x00000260
	public static string #=z9vOm84GISN0P6zkpoNPgeh8=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075326);
	}

	// Token: 0x06000004 RID: 4 RVA: 0x0000206C File Offset: 0x0000026C
	public static bool #=zkoYTeGLud9voSCcSNLwc9m9oqL_kDtNbQ7KdA5eCe7eR()
	{
		bool result;
		try
		{
			OperatingSystem osversion = Environment.OSVersion;
			if (osversion.Platform == PlatformID.Win32NT)
			{
				result = (osversion.Version >= new Version(6, 0));
			}
			else
			{
				result = false;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x000020B8 File Offset: 0x000002B8
	public static bool #=zBA4iw4OubjH304G9CX5qwe77bsimBm1m7g==()
	{
		bool result;
		try
		{
			PlatformID platform = Environment.OSVersion.Platform;
			if (platform <= PlatformID.Win32NT)
			{
				result = true;
			}
			else
			{
				result = false;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x000020F4 File Offset: 0x000002F4
	public static bool #=zllgKH7FxSDp7$ekItH16tc6$pIkD()
	{
		return #=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=zDNslHRCxW_TQsRrkZPx3Pbg=() != null;
	}

	// Token: 0x06000007 RID: 7 RVA: 0x00002100 File Offset: 0x00000300
	private static string #=zDNslHRCxW_TQsRrkZPx3Pbg=()
	{
		string result;
		try
		{
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(#=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=zOuDjPmPVPxXUzHLHFcLIDc0WN_sNEIH01g==());
			if (registryKey == null)
			{
				registryKey = Registry.LocalMachine.OpenSubKey(#=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=zRv8BLXmAvlJLb4GnlB1Z_WBWjWx7E1Zd2g==());
			}
			if (registryKey == null)
			{
				result = null;
			}
			else
			{
				string text = (string)registryKey.GetValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075296), null);
				registryKey.Close();
				result = text;
			}
		}
		catch
		{
			result = null;
		}
		return result;
	}

	// Token: 0x06000008 RID: 8 RVA: 0x0000216C File Offset: 0x0000036C
	private static string #=zOuDjPmPVPxXUzHLHFcLIDc0WN_sNEIH01g==()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075281) + #=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=z9vOm84GISN0P6zkpoNPgeh8=();
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00002184 File Offset: 0x00000384
	private static string #=zRv8BLXmAvlJLb4GnlB1Z_WBWjWx7E1Zd2g==()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075261) + #=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=z9vOm84GISN0P6zkpoNPgeh8=();
	}
}
