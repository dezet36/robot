﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// Token: 0x0200023F RID: 575
internal sealed partial class #=zftHEvWFuuv5SWhTGJj4WVVbjjiPmYMw2W7NwhA0= : Form
{
	// Token: 0x06001198 RID: 4504 RVA: 0x00088D18 File Offset: 0x00086F18
	public #=zftHEvWFuuv5SWhTGJj4WVVbjjiPmYMw2W7NwhA0=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zgpzgXirqPT5_();
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.SelectedIndex = 0;
		this.#=zaWlE314xwdEzz6d5Tg==.SelectedIndex = 0;
		for (int i = 0; i < this.#=zshVEGQI=.#=zOdy_aU_tk1aY().Count; i++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = this.#=zshVEGQI=.#=zOdy_aU_tk1aY()[i];
			if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ().Count > 0)
			{
				this.#=zyOh81vGXmDSr1fHzng==.Rows.Add(new object[]
				{
					false,
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z2ZE0cltcIoE3IY7EAQ==(),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe(),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zbfOGJA_8wt3H(),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7()
				});
			}
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001199 RID: 4505 RVA: 0x00088DE4 File Offset: 0x00086FE4
	private void #=z2gbTxUGyJyrQMMB4B5GUa04=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zJZw1LE$MyrSc.Visible = (this.#=zaWlE314xwdEzz6d5Tg==.SelectedIndex == 0);
	}

	// Token: 0x0600119A RID: 4506 RVA: 0x00088E00 File Offset: 0x00087000
	private void #=zuY0iSUG3AnS3AOpe$j1Qz0M=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		Random random = new Random();
		int i = 0;
		while (i < this.#=zyOh81vGXmDSr1fHzng==.Rows.Count)
		{
			DataGridViewRow dataGridViewRow = this.#=zyOh81vGXmDSr1fHzng==.Rows[i];
			switch (this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.SelectedIndex)
			{
			case 0:
				goto IL_8F;
			case 1:
				if (Convert.ToBoolean(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109696)].Value))
				{
					goto IL_8F;
				}
				break;
			case 2:
				if (string.IsNullOrEmpty(Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109684)].Value)))
				{
					goto IL_8F;
				}
				break;
			default:
				goto IL_8F;
			}
			IL_124:
			i++;
			continue;
			IL_8F:
			string value = null;
			string text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109660);
			int selectedIndex = this.#=zaWlE314xwdEzz6d5Tg==.SelectedIndex;
			if (selectedIndex != 0)
			{
				if (selectedIndex == 1)
				{
					StringBuilder stringBuilder = new StringBuilder();
					int num = random.Next(8, 13);
					for (int j = 0; j < num; j++)
					{
						stringBuilder.Append(text[random.Next(text.Length)]);
					}
					value = stringBuilder.ToString();
				}
			}
			else
			{
				value = this.#=zJZw1LE$MyrSc.Text;
			}
			dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109684)].Value = value;
			goto IL_124;
		}
	}

	// Token: 0x0600119B RID: 4507 RVA: 0x00088F4C File Offset: 0x0008714C
	private void #=zYtnfTR76rfXH(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		int num = 0;
		for (int i = 0; i < this.#=zyOh81vGXmDSr1fHzng==.Rows.Count; i++)
		{
			#=zftHEvWFuuv5SWhTGJj4WVVbjjiPmYMw2W7NwhA0=.#=zjfITWWrauqUMWlwNww== #=zjfITWWrauqUMWlwNww== = new #=zftHEvWFuuv5SWhTGJj4WVVbjjiPmYMw2W7NwhA0=.#=zjfITWWrauqUMWlwNww==();
			DataGridViewRow dataGridViewRow = this.#=zyOh81vGXmDSr1fHzng==.Rows[i];
			#=zjfITWWrauqUMWlwNww==.#=zDu2ZTOnSae3g = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312)].Value);
			string text = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109684)].Value);
			if (!string.IsNullOrEmpty(text))
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = this.#=zshVEGQI=.#=zOdy_aU_tk1aY().Find(new Predicate<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>(#=zjfITWWrauqUMWlwNww==.#=zcahHUp7ksc0H0Tm7M$Z0V_g=));
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== != null)
				{
					if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zHl$V63KooLJO(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, text) == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful)
					{
						dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302)].Value = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109285), Array.Empty<object>());
						num = 0;
					}
					else
					{
						dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302)].Value = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109269), Array.Empty<object>());
						num++;
						if (num >= 3)
						{
							return;
						}
					}
				}
				else
				{
					dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302)].Value = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109254);
				}
				Application.DoEvents();
			}
		}
	}

	// Token: 0x0600119C RID: 4508 RVA: 0x000890A8 File Offset: 0x000872A8
	private void #=zmktfc2uUe0ln(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < this.#=zyOh81vGXmDSr1fHzng==.Rows.Count; i++)
		{
			DataGridViewRow dataGridViewRow = this.#=zyOh81vGXmDSr1fHzng==.Rows[i];
			string value = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109684)].Value);
			if (!string.IsNullOrEmpty(value))
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.AppendLine();
				}
				stringBuilder.Append(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312)].Value);
				stringBuilder.Append('\t');
				stringBuilder.Append(value);
			}
		}
		if (stringBuilder.Length > 0)
		{
			Clipboard.SetText(stringBuilder.ToString());
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109500));
		}
	}

	// Token: 0x0600119E RID: 4510 RVA: 0x0008919C File Offset: 0x0008739C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zJZw1LE$MyrSc = new TextBox();
		this.#=zB6rlaNY= = new Button();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zyOh81vGXmDSr1fHzng== = new DataGridView();
		this.#=zLjL0Bis= = new DataGridViewCheckBoxColumn();
		this.#=zLQCfoJg= = new DataGridViewTextBoxColumn();
		this.#=zAfDv7ow= = new DataGridViewTextBoxColumn();
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=zrAvVh3s= = new DataGridViewTextBoxColumn();
		this.#=zrEWQxfKJiFWs = new DataGridViewTextBoxColumn();
		this.#=zF$GpR2Q= = new DataGridViewTextBoxColumn();
		this.#=zz7L_8T4= = new Button();
		this.#=zB8XVHOrpRTtwxGdOqw== = new Button();
		this.#=zaWlE314xwdEzz6d5Tg== = new ComboBox();
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet = new ComboBox();
		this.#=zzheazblRyoNSAbRbGQ9XXJ8= = new Label();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).BeginInit();
		base.SuspendLayout();
		this.#=zJZw1LE$MyrSc.Location = new Point(450, 10);
		this.#=zJZw1LE$MyrSc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109393);
		this.#=zJZw1LE$MyrSc.Size = new Size(141, 20);
		this.#=zJZw1LE$MyrSc.TabIndex = 0;
		this.#=zB6rlaNY=.Location = new Point(597, 37);
		this.#=zB6rlaNY=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111166);
		this.#=zB6rlaNY=.Size = new Size(203, 23);
		this.#=zB6rlaNY=.TabIndex = 1;
		this.#=zB6rlaNY=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111150);
		this.#=zB6rlaNY=.UseVisualStyleBackColor = true;
		this.#=zB6rlaNY=.Click += this.#=zYtnfTR76rfXH;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel2;
		this.#=zByiHPAwyKD$Q.IsSplitterFixed = true;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zyOh81vGXmDSr1fHzng==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zz7L_8T4=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zB8XVHOrpRTtwxGdOqw==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zaWlE314xwdEzz6d5Tg==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zzheazblRyoNSAbRbGQ9XXJ8=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zJZw1LE$MyrSc);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zB6rlaNY=);
		this.#=zByiHPAwyKD$Q.Size = new Size(812, 450);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 380;
		this.#=zByiHPAwyKD$Q.TabIndex = 2;
		this.#=zyOh81vGXmDSr1fHzng==.AllowUserToAddRows = false;
		this.#=zyOh81vGXmDSr1fHzng==.AllowUserToDeleteRows = false;
		this.#=zyOh81vGXmDSr1fHzng==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zyOh81vGXmDSr1fHzng==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zLjL0Bis=,
			this.#=zLQCfoJg=,
			this.#=zAfDv7ow=,
			this.#=zO0jJkos=,
			this.#=zrAvVh3s=,
			this.#=zrEWQxfKJiFWs,
			this.#=zF$GpR2Q=
		});
		this.#=zyOh81vGXmDSr1fHzng==.Dock = DockStyle.Fill;
		this.#=zyOh81vGXmDSr1fHzng==.EditMode = DataGridViewEditMode.EditOnEnter;
		this.#=zyOh81vGXmDSr1fHzng==.Location = new Point(0, 0);
		this.#=zyOh81vGXmDSr1fHzng==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111099);
		this.#=zyOh81vGXmDSr1fHzng==.RowHeadersVisible = false;
		this.#=zyOh81vGXmDSr1fHzng==.Size = new Size(812, 380);
		this.#=zyOh81vGXmDSr1fHzng==.TabIndex = 12;
		this.#=zLjL0Bis=.HeaderText = string.Empty;
		this.#=zLjL0Bis=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109696);
		this.#=zLjL0Bis=.Width = 30;
		this.#=zLQCfoJg=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111086);
		this.#=zLQCfoJg=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zLQCfoJg=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111054);
		this.#=zLQCfoJg=.ReadOnly = true;
		this.#=zLQCfoJg=.Resizable = DataGridViewTriState.True;
		this.#=zLQCfoJg=.SortMode = DataGridViewColumnSortMode.NotSortable;
		this.#=zLQCfoJg=.Width = 50;
		this.#=zAfDv7ow=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111293);
		this.#=zAfDv7ow=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111277);
		this.#=zAfDv7ow=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312);
		this.#=zAfDv7ow=.ReadOnly = true;
		this.#=zAfDv7ow=.Width = 150;
		this.#=zO0jJkos=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111263);
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.ReadOnly = true;
		this.#=zO0jJkos=.Width = 150;
		this.#=zrAvVh3s=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111208);
		this.#=zrAvVh3s=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111195);
		this.#=zrAvVh3s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111176);
		this.#=zrAvVh3s=.ReadOnly = true;
		this.#=zrAvVh3s=.Width = 150;
		this.#=zrEWQxfKJiFWs.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110909);
		this.#=zrEWQxfKJiFWs.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109684);
		this.#=zrEWQxfKJiFWs.Width = 150;
		this.#=zF$GpR2Q=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110886);
		this.#=zF$GpR2Q=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302);
		this.#=zF$GpR2Q=.ReadOnly = true;
		this.#=zz7L_8T4=.Location = new Point(137, 37);
		this.#=zz7L_8T4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110865);
		this.#=zz7L_8T4=.Size = new Size(93, 23);
		this.#=zz7L_8T4=.TabIndex = 5;
		this.#=zz7L_8T4=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110852);
		this.#=zz7L_8T4=.UseVisualStyleBackColor = true;
		this.#=zz7L_8T4=.Click += this.#=zmktfc2uUe0ln;
		this.#=zB8XVHOrpRTtwxGdOqw==.Location = new Point(597, 8);
		this.#=zB8XVHOrpRTtwxGdOqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110839);
		this.#=zB8XVHOrpRTtwxGdOqw==.Size = new Size(148, 23);
		this.#=zB8XVHOrpRTtwxGdOqw==.TabIndex = 4;
		this.#=zB8XVHOrpRTtwxGdOqw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110815);
		this.#=zB8XVHOrpRTtwxGdOqw==.UseVisualStyleBackColor = true;
		this.#=zB8XVHOrpRTtwxGdOqw==.Click += this.#=zuY0iSUG3AnS3AOpe$j1Qz0M=;
		this.#=zaWlE314xwdEzz6d5Tg==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zaWlE314xwdEzz6d5Tg==.FormattingEnabled = true;
		this.#=zaWlE314xwdEzz6d5Tg==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110795),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111033)
		});
		this.#=zaWlE314xwdEzz6d5Tg==.Location = new Point(322, 10);
		this.#=zaWlE314xwdEzz6d5Tg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111016);
		this.#=zaWlE314xwdEzz6d5Tg==.Size = new Size(122, 21);
		this.#=zaWlE314xwdEzz6d5Tg==.TabIndex = 3;
		this.#=zaWlE314xwdEzz6d5Tg==.SelectedIndexChanged += this.#=z2gbTxUGyJyrQMMB4B5GUa04=;
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.FormattingEnabled = true;
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110984),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110961),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110931)
		});
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.Location = new Point(137, 10);
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110633);
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.Size = new Size(179, 21);
		this.#=z$076Z4_OPHuX41d_yDrPYNkJtJet.TabIndex = 3;
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.AutoSize = true;
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.Location = new Point(12, 13);
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110601);
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.Size = new Size(82, 13);
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.TabIndex = 2;
		this.#=zzheazblRyoNSAbRbGQ9XXJ8=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110577);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(812, 450);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110555);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110555);
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.PerformLayout();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x040009D0 RID: 2512
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x040009D2 RID: 2514
	private TextBox #=zJZw1LE$MyrSc;

	// Token: 0x040009D3 RID: 2515
	private Button #=zB6rlaNY=;

	// Token: 0x040009D4 RID: 2516
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x040009D5 RID: 2517
	private DataGridView #=zyOh81vGXmDSr1fHzng==;

	// Token: 0x040009D6 RID: 2518
	private ComboBox #=z$076Z4_OPHuX41d_yDrPYNkJtJet;

	// Token: 0x040009D7 RID: 2519
	private Label #=zzheazblRyoNSAbRbGQ9XXJ8=;

	// Token: 0x040009D8 RID: 2520
	private ComboBox #=zaWlE314xwdEzz6d5Tg==;

	// Token: 0x040009D9 RID: 2521
	private Button #=zB8XVHOrpRTtwxGdOqw==;

	// Token: 0x040009DA RID: 2522
	private Button #=zz7L_8T4=;

	// Token: 0x040009DB RID: 2523
	private DataGridViewCheckBoxColumn #=zLjL0Bis=;

	// Token: 0x040009DC RID: 2524
	private DataGridViewTextBoxColumn #=zLQCfoJg=;

	// Token: 0x040009DD RID: 2525
	private DataGridViewTextBoxColumn #=zAfDv7ow=;

	// Token: 0x040009DE RID: 2526
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x040009DF RID: 2527
	private DataGridViewTextBoxColumn #=zrAvVh3s=;

	// Token: 0x040009E0 RID: 2528
	private DataGridViewTextBoxColumn #=zrEWQxfKJiFWs;

	// Token: 0x040009E1 RID: 2529
	private DataGridViewTextBoxColumn #=zF$GpR2Q=;

	// Token: 0x02000240 RID: 576
	private sealed class #=zjfITWWrauqUMWlwNww==
	{
		// Token: 0x060011A0 RID: 4512 RVA: 0x00089B74 File Offset: 0x00087D74
		internal bool #=zcahHUp7ksc0H0Tm7M$Z0V_g=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zm8PpuDU=)
		{
			return #=zm8PpuDU=.#=z9Yordw6ZFjQe() == this.#=zDu2ZTOnSae3g;
		}

		// Token: 0x040009E2 RID: 2530
		public string #=zDu2ZTOnSae3g;
	}
}
