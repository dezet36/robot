﻿using System;
using System.Collections.Generic;

// Token: 0x020001D9 RID: 473
internal sealed class #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k= : List<#=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM=>
{
	// Token: 0x06000E47 RID: 3655 RVA: 0x00072038 File Offset: 0x00070238
	public #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k=()
	{
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x00072040 File Offset: 0x00070240
	public #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k=(object[] #=zeJY$3yxiRLlf)
	{
		foreach (Dictionary<string, object> #=zJ5GWysk= in #=zeJY$3yxiRLlf)
		{
			base.Add(new #=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM=(#=zJ5GWysk=));
		}
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x00072078 File Offset: 0x00070278
	public object[] #=zhv7OhlM=()
	{
		object[] array = new object[base.Count];
		for (int i = 0; i < base.Count; i++)
		{
			array[i] = base[i].#=zhv7OhlM=();
		}
		return array;
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x000720B4 File Offset: 0x000702B4
	public #=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM= #=zk$6QZNA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string b = #=z8StzeqE=.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==();
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zMuFMjGQ=() == b)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x000720FC File Offset: 0x000702FC
	public bool #=z8hmMi9dQPSQj(#=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM= #=znvUJxWQWT1Uy)
	{
		if (#=znvUJxWQWT1Uy.#=zz89PpumJ7HSr() != 1)
		{
			return false;
		}
		List<string> list = new List<string>();
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zaMFTrsik9X1nKi3x1g==() == #=znvUJxWQWT1Uy.#=zaMFTrsik9X1nKi3x1g==())
			{
				list.Add(base[i].#=zMuFMjGQ=());
			}
		}
		if (list.Count == 0)
		{
			return false;
		}
		if (list.Count == 1)
		{
			return true;
		}
		#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = null;
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zOdy_aU_tk1aY();
		for (int j = 0; j < list2.Count; j++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2 = list2[j];
			if (list.Contains(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zCCBXDJ5n_DGghKXXmA==()))
			{
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== == null)
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2;
				}
				else if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z5KSZXEKT20zU() < #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z5KSZXEKT20zU())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2;
				}
			}
		}
		return #=znvUJxWQWT1Uy.#=zMuFMjGQ=() == #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==();
	}
}
