﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x02000070 RID: 112
internal class #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== : Task
{
	// Token: 0x06000323 RID: 803 RVA: 0x0001DCC8 File Offset: 0x0001BEC8
	public #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==(TaskTypes #=zmV6257E=) : base(TaskSources.ManualNotSavable, TaskSeverities.Background, #=zmV6257E=, DateTime.Now, TimeSpan.Zero, TimeSpan.FromMilliseconds(10.0), TimeSpan.FromMilliseconds(10.0), DateTime.MaxValue, true)
	{
		this.#=zqgjkaIaQFkvvaYwf1A==(15);
		this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)1);
		this.#=zDesWlpVehD3bGwKPHQ==(-this.#=zPUJG_NRAPCt4mNYkiA==());
		this.#=zru0GRWKXYWO22zQR0A==(-this.#=zPUJG_NRAPCt4mNYkiA==());
		this.#=zYmLC4b5ED0x4(-1);
	}

	// Token: 0x06000324 RID: 804 RVA: 0x0001DD3C File Offset: 0x0001BF3C
	public #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==(TaskTypes #=zmV6257E=, DateTime #=zxSBcx18=) : base(TaskSources.ManualNotSavable, TaskSeverities.Background, #=zmV6257E=, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.FromMilliseconds(10.0), TimeSpan.FromMilliseconds(10.0), DateTime.MaxValue, true)
	{
		this.#=zqgjkaIaQFkvvaYwf1A==(15);
		this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)1);
		this.#=zDesWlpVehD3bGwKPHQ==(-this.#=zPUJG_NRAPCt4mNYkiA==());
		this.#=zru0GRWKXYWO22zQR0A==(-this.#=zPUJG_NRAPCt4mNYkiA==());
		this.#=zYmLC4b5ED0x4(-1);
	}

	// Token: 0x06000325 RID: 805 RVA: 0x0001DDAC File Offset: 0x0001BFAC
	private int #=zPUJG_NRAPCt4mNYkiA==()
	{
		return this.#=zwgXA7k$2vK20k4e4stbEha8=;
	}

	// Token: 0x06000326 RID: 806 RVA: 0x0001DDB4 File Offset: 0x0001BFB4
	private void #=zqgjkaIaQFkvvaYwf1A==(int #=z$Ib9gYQ=)
	{
		this.#=zwgXA7k$2vK20k4e4stbEha8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000327 RID: 807 RVA: 0x0001DDC0 File Offset: 0x0001BFC0
	private #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw== #=zfOlIk$YrVxebm2Uwjw==()
	{
		return this.#=zCFtF1I5UA3XLtQCzprzbU6o=;
	}

	// Token: 0x06000328 RID: 808 RVA: 0x0001DDC8 File Offset: 0x0001BFC8
	private void #=zGj4aqt7S5hC36RikRA==(#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw== #=z$Ib9gYQ=)
	{
		this.#=zCFtF1I5UA3XLtQCzprzbU6o= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000329 RID: 809 RVA: 0x0001DDD4 File Offset: 0x0001BFD4
	public int #=zf0e9blCCGf6ut3r1Nw==()
	{
		return this.#=zpkHL4PgWgr$lxVGexqyDGos=;
	}

	// Token: 0x0600032A RID: 810 RVA: 0x0001DDDC File Offset: 0x0001BFDC
	public void #=zDesWlpVehD3bGwKPHQ==(int #=z$Ib9gYQ=)
	{
		this.#=zpkHL4PgWgr$lxVGexqyDGos= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600032B RID: 811 RVA: 0x0001DDE8 File Offset: 0x0001BFE8
	public int #=zbRWovF5fxGmOqm7gAQ==()
	{
		return this.#=zR26hSZXOXcBvtj5ueEmAkB8=;
	}

	// Token: 0x0600032C RID: 812 RVA: 0x0001DDF0 File Offset: 0x0001BFF0
	public void #=zru0GRWKXYWO22zQR0A==(int #=z$Ib9gYQ=)
	{
		this.#=zR26hSZXOXcBvtj5ueEmAkB8= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600032D RID: 813 RVA: 0x0001DDFC File Offset: 0x0001BFFC
	public int #=zWJC489bUrBis()
	{
		return this.#=z7mRUNZyq7p23Ll_lSEXVNDk=;
	}

	// Token: 0x0600032E RID: 814 RVA: 0x0001DE04 File Offset: 0x0001C004
	public void #=zYmLC4b5ED0x4(int #=z$Ib9gYQ=)
	{
		this.#=z7mRUNZyq7p23Ll_lSEXVNDk= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600032F RID: 815 RVA: 0x0001DE10 File Offset: 0x0001C010
	public void #=z1jlGMrg=(int #=zEEWAvZ84m_uL, int #=zVOdBI6Ll_ZwD)
	{
		this.#=zqgjkaIaQFkvvaYwf1A==(Math.Max(#=zEEWAvZ84m_uL, #=zVOdBI6Ll_ZwD) / 15 * 15);
		if (this.#=zPUJG_NRAPCt4mNYkiA==() == 0)
		{
			return;
		}
		this.#=zDesWlpVehD3bGwKPHQ==(#=zEEWAvZ84m_uL / 15 * 15);
		this.#=zru0GRWKXYWO22zQR0A==(#=zVOdBI6Ll_ZwD / 15 * 15);
		if (Math.Abs(#=zEEWAvZ84m_uL) > Math.Abs(#=zVOdBI6Ll_ZwD))
		{
			if (#=zEEWAvZ84m_uL > 0)
			{
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)2);
				return;
			}
			this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)3);
			return;
		}
		else
		{
			if (#=zVOdBI6Ll_ZwD > 0)
			{
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)0);
				return;
			}
			this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)1);
			return;
		}
	}

	// Token: 0x06000330 RID: 816 RVA: 0x0001DE88 File Offset: 0x0001C088
	public void #=zrYsCATIY3Mmo()
	{
		switch (this.#=zfOlIk$YrVxebm2Uwjw==())
		{
		case (#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)0:
			this.#=zDesWlpVehD3bGwKPHQ==(this.#=zf0e9blCCGf6ut3r1Nw==() - 15);
			if (this.#=zf0e9blCCGf6ut3r1Nw==() < -this.#=zPUJG_NRAPCt4mNYkiA==())
			{
				this.#=zDesWlpVehD3bGwKPHQ==(-this.#=zPUJG_NRAPCt4mNYkiA==());
				this.#=zru0GRWKXYWO22zQR0A==(this.#=zPUJG_NRAPCt4mNYkiA==() - 15);
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)3);
				return;
			}
			break;
		case (#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)1:
			this.#=zDesWlpVehD3bGwKPHQ==(this.#=zf0e9blCCGf6ut3r1Nw==() + 15);
			if (this.#=zf0e9blCCGf6ut3r1Nw==() > this.#=zPUJG_NRAPCt4mNYkiA==())
			{
				this.#=zDesWlpVehD3bGwKPHQ==(this.#=zPUJG_NRAPCt4mNYkiA==());
				this.#=zru0GRWKXYWO22zQR0A==(-this.#=zPUJG_NRAPCt4mNYkiA==() + 15);
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)2);
				return;
			}
			break;
		case (#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)2:
			this.#=zru0GRWKXYWO22zQR0A==(this.#=zbRWovF5fxGmOqm7gAQ==() + 15);
			if (this.#=zbRWovF5fxGmOqm7gAQ==() > this.#=zPUJG_NRAPCt4mNYkiA==())
			{
				this.#=zDesWlpVehD3bGwKPHQ==(this.#=zPUJG_NRAPCt4mNYkiA==() - 15);
				this.#=zru0GRWKXYWO22zQR0A==(this.#=zPUJG_NRAPCt4mNYkiA==());
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)0);
				return;
			}
			break;
		case (#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)3:
			this.#=zru0GRWKXYWO22zQR0A==(this.#=zbRWovF5fxGmOqm7gAQ==() - 15);
			if (this.#=zbRWovF5fxGmOqm7gAQ==() < -this.#=zPUJG_NRAPCt4mNYkiA==())
			{
				this.#=zqgjkaIaQFkvvaYwf1A==(this.#=zPUJG_NRAPCt4mNYkiA==() + 15);
				this.#=zDesWlpVehD3bGwKPHQ==(-this.#=zPUJG_NRAPCt4mNYkiA==());
				this.#=zru0GRWKXYWO22zQR0A==(-this.#=zPUJG_NRAPCt4mNYkiA==());
				this.#=zGj4aqt7S5hC36RikRA==((#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw==)1);
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x06000331 RID: 817 RVA: 0x0001DFCC File Offset: 0x0001C1CC
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875604)] = this.#=zPUJG_NRAPCt4mNYkiA==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875587)] = (int)this.#=zfOlIk$YrVxebm2Uwjw==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)] = this.#=zf0e9blCCGf6ut3r1Nw==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)] = this.#=zbRWovF5fxGmOqm7gAQ==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875577)] = this.#=zWJC489bUrBis();
		return dictionary;
	}

	// Token: 0x04000121 RID: 289
	private int #=zwgXA7k$2vK20k4e4stbEha8=;

	// Token: 0x04000122 RID: 290
	private #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zPn237Z4pzQ_yHfVinw== #=zCFtF1I5UA3XLtQCzprzbU6o=;

	// Token: 0x04000123 RID: 291
	private int #=zpkHL4PgWgr$lxVGexqyDGos=;

	// Token: 0x04000124 RID: 292
	private int #=zR26hSZXOXcBvtj5ueEmAkB8=;

	// Token: 0x04000125 RID: 293
	private int #=z7mRUNZyq7p23Ll_lSEXVNDk=;

	// Token: 0x02000071 RID: 113
	private enum #=zPn237Z4pzQ_yHfVinw==
	{

	}
}
