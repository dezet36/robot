﻿using System;
using System.Collections;
using common;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x02000169 RID: 361
internal sealed class #=zNJqtOCOz2WZ$2o6EOq1JR7Y= : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x06000993 RID: 2451 RVA: 0x0004EB04 File Offset: 0x0004CD04
	public #=zNJqtOCOz2WZ$2o6EOq1JR7Y=(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=z5eAuhwM= = this.Instance;
		this.#=zHqSYXl0=();
	}

	// Token: 0x06000994 RID: 2452 RVA: 0x0004EB20 File Offset: 0x0004CD20
	public #=zNJqtOCOz2WZ$2o6EOq1JR7Y=() : base(EscherRecordType.OPT)
	{
		this.#=zJ_TSQFI= = new ArrayList();
		this.Version = 3;
	}

	// Token: 0x06000996 RID: 2454 RVA: 0x0004EB58 File Offset: 0x0004CD58
	private void #=zHqSYXl0=()
	{
		this.#=zJ_TSQFI= = new ArrayList();
		int num = 0;
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		for (int i = 0; i < this.#=z5eAuhwM=; i++)
		{
			int @int = IntegerHelper.getInt(array[num], array[num + 1]);
			int #=zH2f5zJg= = @int & 16383;
			int int2 = IntegerHelper.getInt(array[num + 2], array[num + 3], array[num + 4], array[num + 5]);
			#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= value = new #=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=(#=zH2f5zJg=, (@int & 16384) != 0, (@int & 32768) != 0, int2);
			num += 6;
			this.#=zJ_TSQFI=.Add(value);
		}
		foreach (object obj in this.#=zJ_TSQFI=)
		{
			#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= #=zD6_dias= = (#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=)obj;
			if (#=zD6_dias=.#=z14ZgOWc=)
			{
				#=zD6_dias=.#=zmLWjFA0= = StringHelper.getUnicodeString(array, #=zD6_dias=.#=zziO1gvU= / 2, num);
				num += #=zD6_dias=.#=zziO1gvU=;
			}
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000997 RID: 2455 RVA: 0x0004EC60 File Offset: 0x0004CE60
	public override sbyte[] Data
	{
		get
		{
			this.#=z5eAuhwM= = this.#=zJ_TSQFI=.Count;
			this.Instance = this.#=z5eAuhwM=;
			this.#=zJ5GWysk= = new sbyte[this.#=z5eAuhwM= * 6];
			int num = 0;
			foreach (object obj in this.#=zJ_TSQFI=)
			{
				#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= #=zD6_dias= = (#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=)obj;
				int num2 = #=zD6_dias=.#=zAk8mKBk= & 16383;
				if (#=zD6_dias=.#=zYwjiaPOMfJF_)
				{
					num2 |= 16384;
				}
				if (#=zD6_dias=.#=z14ZgOWc=)
				{
					num2 |= 32768;
				}
				IntegerHelper.getTwoBytes(num2, this.#=zJ5GWysk=, num);
				IntegerHelper.getFourBytes(#=zD6_dias=.#=zziO1gvU=, this.#=zJ5GWysk=, num + 2);
				num += 6;
			}
			foreach (object obj2 in this.#=zJ_TSQFI=)
			{
				#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= #=zD6_dias=2 = (#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=)obj2;
				if (#=zD6_dias=2.#=z14ZgOWc= && #=zD6_dias=2.#=zmLWjFA0= != null)
				{
					sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length + #=zD6_dias=2.#=zmLWjFA0=.Length * 2];
					Array.Copy(this.#=zJ5GWysk=, 0, array, 0, this.#=zJ5GWysk=.Length);
					StringHelper.getUnicodeBytes(#=zD6_dias=2.#=zmLWjFA0=, array, this.#=zJ5GWysk=.Length);
					this.#=zJ5GWysk= = array;
				}
			}
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x06000998 RID: 2456 RVA: 0x0004EDE8 File Offset: 0x0004CFE8
	internal void #=zae2yNSs=(int #=zAk8mKBk=, bool #=z5Kn3pfOKxN9E, bool #=z14ZgOWc=, int #=ze7ZtytQ=)
	{
		#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= value = new #=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=(#=zAk8mKBk=, #=z5Kn3pfOKxN9E, #=z14ZgOWc=, #=ze7ZtytQ=);
		this.#=zJ_TSQFI=.Add(value);
	}

	// Token: 0x06000999 RID: 2457 RVA: 0x0004EE10 File Offset: 0x0004D010
	internal void #=zae2yNSs=(int #=zAk8mKBk=, bool #=z5Kn3pfOKxN9E, bool #=z14ZgOWc=, int #=ze7ZtytQ=, string #=zWj7xLq8=)
	{
		#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= value = new #=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=(#=zAk8mKBk=, #=z5Kn3pfOKxN9E, #=z14ZgOWc=, #=ze7ZtytQ=, #=zWj7xLq8=);
		this.#=zJ_TSQFI=.Add(value);
	}

	// Token: 0x0600099A RID: 2458 RVA: 0x0004EE38 File Offset: 0x0004D038
	internal #=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= #=z$WdPt6w=(int #=zAk8mKBk=)
	{
		#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= result = null;
		foreach (object obj in this.#=zJ_TSQFI=)
		{
			#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias= #=zD6_dias= = (#=zNJqtOCOz2WZ$2o6EOq1JR7Y=.#=zD6_dias=)obj;
			if (#=zD6_dias=.#=zAk8mKBk= == #=zAk8mKBk=)
			{
				result = #=zD6_dias=;
				break;
			}
		}
		return result;
	}

	// Token: 0x04000584 RID: 1412
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zNJqtOCOz2WZ$2o6EOq1JR7Y=));

	// Token: 0x04000585 RID: 1413
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x04000586 RID: 1414
	private int #=z5eAuhwM=;

	// Token: 0x04000587 RID: 1415
	private ArrayList #=zJ_TSQFI=;

	// Token: 0x0200016A RID: 362
	internal sealed class #=zD6_dias=
	{
		// Token: 0x0600099B RID: 2459 RVA: 0x0004EE9C File Offset: 0x0004D09C
		public #=zD6_dias=(int #=zH2f5zJg=, bool #=zjjrbH1U=, bool #=zf5QVU7c=, int #=z3GDTqqw=)
		{
			this.#=zAk8mKBk= = #=zH2f5zJg=;
			this.#=zYwjiaPOMfJF_ = #=zjjrbH1U=;
			this.#=z14ZgOWc= = #=zf5QVU7c=;
			this.#=zziO1gvU= = #=z3GDTqqw=;
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x0004EEC4 File Offset: 0x0004D0C4
		public #=zD6_dias=(int #=zH2f5zJg=, bool #=zjjrbH1U=, bool #=zf5QVU7c=, int #=z3GDTqqw=, string #=zWj7xLq8=)
		{
			this.#=zAk8mKBk= = #=zH2f5zJg=;
			this.#=zYwjiaPOMfJF_ = #=zjjrbH1U=;
			this.#=z14ZgOWc= = #=zf5QVU7c=;
			this.#=zziO1gvU= = #=z3GDTqqw=;
			this.#=zmLWjFA0= = #=zWj7xLq8=;
		}

		// Token: 0x04000588 RID: 1416
		internal int #=zAk8mKBk=;

		// Token: 0x04000589 RID: 1417
		internal bool #=zYwjiaPOMfJF_;

		// Token: 0x0400058A RID: 1418
		internal bool #=z14ZgOWc=;

		// Token: 0x0400058B RID: 1419
		internal int #=zziO1gvU=;

		// Token: 0x0400058C RID: 1420
		internal string #=zmLWjFA0=;
	}
}
