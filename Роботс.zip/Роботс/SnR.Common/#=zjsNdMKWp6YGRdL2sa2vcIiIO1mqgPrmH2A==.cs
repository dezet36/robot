﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

// Token: 0x0200026E RID: 622
internal sealed class #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==
{
	// Token: 0x060012D1 RID: 4817 RVA: 0x000922AC File Offset: 0x000904AC
	public static void #=zqmx6FcA8x_j0(Form #=zL6pG0RQ=)
	{
		#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zi1hFJwI=();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(#=zL6pG0RQ=, #=zGR3UNcM=);
	}

	// Token: 0x060012D2 RID: 4818 RVA: 0x000922C8 File Offset: 0x000904C8
	public static void #=z0zcGDLojNORT(Form #=zL6pG0RQ=, int #=zljxJvv8=)
	{
		#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zi1hFJwI=(#=zljxJvv8=);
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(#=zL6pG0RQ=, #=zGR3UNcM=);
	}

	// Token: 0x060012D3 RID: 4819 RVA: 0x000922E4 File Offset: 0x000904E4
	private static void #=zqmx6FcA8x_j0(Form #=zL6pG0RQ=, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM=)
	{
		try
		{
			#=zL6pG0RQ=.Text = #=zGR3UNcM=.#=zt5hOKIs=(#=zL6pG0RQ=.Text);
			foreach (Control control in #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zsHy2CIek14mI(#=zL6pG0RQ=, new Type[]
			{
				typeof(Label),
				typeof(CheckBox),
				typeof(RadioButton),
				typeof(TabPage),
				typeof(Button),
				typeof(LinkLabel)
			}))
			{
				control.Text = #=zGR3UNcM=.#=zt5hOKIs=(control.Text);
			}
			foreach (Control control2 in #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zsHy2CIek14mI(#=zL6pG0RQ=, new Type[]
			{
				typeof(DataGridView)
			}))
			{
				if (control2 is DataGridView)
				{
					bool flag = false;
					foreach (object obj in (control2 as DataGridView).Columns)
					{
						DataGridViewColumn dataGridViewColumn = (DataGridViewColumn)obj;
						dataGridViewColumn.HeaderText = #=zGR3UNcM=.#=zt5hOKIs=(dataGridViewColumn.HeaderText);
						dataGridViewColumn.ToolTipText = #=zGR3UNcM=.#=zt5hOKIs=(dataGridViewColumn.ToolTipText);
						if (dataGridViewColumn is DataGridViewButtonColumn)
						{
							(dataGridViewColumn as DataGridViewButtonColumn).Text = #=zGR3UNcM=.#=zt5hOKIs=((dataGridViewColumn as DataGridViewButtonColumn).Text);
						}
						if (dataGridViewColumn is DataGridViewCheckBoxColumn)
						{
							flag = true;
						}
					}
					if (flag)
					{
						#=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos=.#=zcBW$PBE=(control2 as DataGridView, null);
					}
				}
			}
			foreach (Control control3 in #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zsHy2CIek14mI(#=zL6pG0RQ=, new Type[]
			{
				typeof(ComboBox)
			}))
			{
				ComboBox comboBox = (ComboBox)control3;
				for (int i = 0; i < comboBox.Items.Count; i++)
				{
					if (comboBox.Items[i] is string)
					{
						comboBox.Items[i] = #=zGR3UNcM=.#=zt5hOKIs=(Convert.ToString(comboBox.Items[i]));
					}
				}
				if (!#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zjJAGY4m921th(comboBox, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106062)))
				{
					comboBox.MouseWheel += #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zjdkATK2gYvBD;
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x060012D4 RID: 4820 RVA: 0x000925D0 File Offset: 0x000907D0
	private static bool #=zjJAGY4m921th(Control #=z1WDRhe4=, string #=zacQ7dfc=)
	{
		return #=z1WDRhe4=.Tag != null && #=z1WDRhe4=.Tag.ToString().Contains(#=zacQ7dfc=);
	}

	// Token: 0x060012D5 RID: 4821 RVA: 0x000925F0 File Offset: 0x000907F0
	private static void #=zjdkATK2gYvBD(object #=zP95I7AY=, MouseEventArgs #=z4Q$h3mE=)
	{
		((HandledMouseEventArgs)#=z4Q$h3mE=).Handled = true;
	}

	// Token: 0x060012D6 RID: 4822 RVA: 0x00092600 File Offset: 0x00090800
	private static IEnumerable<Control> #=zsHy2CIek14mI(Control #=z1WDRhe4=, Type[] #=zC7NDbDM=)
	{
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zAzqsXKU9G9G$qkIMsw== #=zAzqsXKU9G9G$qkIMsw== = new #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zAzqsXKU9G9G$qkIMsw==();
		#=zAzqsXKU9G9G$qkIMsw==.#=zC7NDbDM= = #=zC7NDbDM=;
		IEnumerable<Control> enumerable = Enumerable.Cast<Control>(#=z1WDRhe4=.Controls);
		return Enumerable.Where<Control>(Enumerable.Concat<Control>(Enumerable.SelectMany<Control, Control>(enumerable, new Func<Control, IEnumerable<Control>>(#=zAzqsXKU9G9G$qkIMsw==.#=z0QaGrV4X76$_ri7k6A==)), enumerable), new Func<Control, bool>(#=zAzqsXKU9G9G$qkIMsw==.#=zOGb7EdxWZ1zadNB59g==));
	}

	// Token: 0x060012D7 RID: 4823 RVA: 0x00092650 File Offset: 0x00090850
	private static bool #=z9OL2MsQzlERk(Type #=zvRLj9WQ=, Type[] #=zC7NDbDM=)
	{
		for (int i = 0; i < #=zC7NDbDM=.Length; i++)
		{
			if (#=zvRLj9WQ= == #=zC7NDbDM=[i])
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060012D8 RID: 4824 RVA: 0x0009267C File Offset: 0x0009087C
	public static bool #=z04cTN7eaC4h7(Control #=zMnli6is=)
	{
		if (!#=zMnli6is=.Visible)
		{
			return false;
		}
		for (Control control = #=zMnli6is=; control != null; control = control.Parent)
		{
			if (!control.Visible)
			{
				return false;
			}
			TabPage tabPage = control as TabPage;
			if (tabPage != null)
			{
				TabControl tabControl = tabPage.Parent as TabControl;
				if (tabControl != null && tabControl.SelectedTab != tabPage)
				{
					return false;
				}
			}
		}
		return true;
	}

	// Token: 0x0200026F RID: 623
	private sealed class #=zAzqsXKU9G9G$qkIMsw==
	{
		// Token: 0x060012DA RID: 4826 RVA: 0x000926D8 File Offset: 0x000908D8
		internal IEnumerable<Control> #=z0QaGrV4X76$_ri7k6A==(Control #=zMnli6is=)
		{
			return #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zsHy2CIek14mI(#=zMnli6is=, this.#=zC7NDbDM=);
		}

		// Token: 0x060012DB RID: 4827 RVA: 0x000926E8 File Offset: 0x000908E8
		internal bool #=zOGb7EdxWZ1zadNB59g==(Control #=zQUn_5_A=)
		{
			return #=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=z9OL2MsQzlERk(#=zQUn_5_A=.GetType(), this.#=zC7NDbDM=);
		}

		// Token: 0x04000AD0 RID: 2768
		public Type[] #=zC7NDbDM=;
	}
}
