﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;
using Skink.SnR.Common.UserMeta;

// Token: 0x0200014A RID: 330
internal sealed class #=zLJMcwUm04UPUxz1kDvdwxcsTN6Ibaw$AB31zEXz_rj$Lj9gU6A== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060008AF RID: 2223 RVA: 0x00044560 File Offset: 0x00042760
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zkCv9LVofr6Y6FfiMZJuU87jjlDie = #=zuJjQ1XU=.#=zp2mzms2YUjsUGxf5Ve03JIcq0mgU();
		this.#=zwn5aCwWTvPV4 = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
	}

	// Token: 0x060008B0 RID: 2224 RVA: 0x000445C4 File Offset: 0x000427C4
	protected override void #=zvb5bnug=()
	{
		UnitSquadCollection unitSquadCollection = this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;
		UnitSquadCollection unitSquadCollection2 = this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		bool flag = false;
		UnitSquadCollection unitSquadCollection3 = null;
		#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= = null;
		bool flag2 = false;
		if (unitSquadCollection.Count > 0)
		{
			UnitSquadCollection unitSquadCollection4 = new UnitSquadCollection();
			int num = 0;
			foreach (UnitSquad unitSquad in unitSquadCollection)
			{
				int num2 = unitSquad.Number;
				switch (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolTroopType)
				{
				case ActionSettings.SentToAcropolType.OnlyAttackers:
				case ActionSettings.SentToAcropolType.GarrisonDefendersAndScouts:
					if (unitSquad.Type.Function == UnitType.Functions.Defence || unitSquad.Type.Function == UnitType.Functions.Scouting)
					{
						num2 = 0;
					}
					break;
				case ActionSettings.SentToAcropolType.AllExceptSelectedTroops:
					if (#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zzfuUJztcOt9$(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolGarrison))
					{
						if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= == null)
						{
							#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zRNqnDZfnmn0P(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolGarrison);
						}
						if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(unitSquad))
						{
							if (unitSquadCollection3 == null)
							{
								unitSquadCollection3 = new UnitSquadCollection();
							}
							dictionary[unitSquad.Type.Id] = -1000000;
							flag = true;
							num2 = 0;
						}
					}
					else
					{
						if (unitSquadCollection3 == null)
						{
							unitSquadCollection3 = UnitSquadCollection.FromString(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolGarrison, null);
						}
						UnitSquad unitSquad2 = unitSquadCollection3.Find(unitSquad.Type.Id);
						if (unitSquad2 != null)
						{
							num2 -= unitSquad2.Number;
							if (num2 < 0)
							{
								dictionary[unitSquad.Type.Id] = -num2;
								flag = true;
								num2 = 0;
							}
							else
							{
								dictionary[unitSquad.Type.Id] = 0;
							}
						}
					}
					break;
				case ActionSettings.SentToAcropolType.GarrisonDefenders:
					if (unitSquad.Type.Function == UnitType.Functions.Defence)
					{
						num2 = 0;
					}
					break;
				}
				if (num2 > 0)
				{
					if (num2 > num)
					{
						num = num2;
					}
					unitSquadCollection4.Add(new UnitSquad
					{
						Type = unitSquad.Type,
						Number = num2
					});
				}
			}
			if (unitSquadCollection4.Count > 0)
			{
				string text = this.#=zBsXSanI=.#=zj6mJJFZU84bVSPLgcS8vCmc=(unitSquadCollection4);
				if (text.Length > 10000)
				{
					if (num > 5)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878900), new object[]
						{
							unitSquadCollection4.ToStringLabels()
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878900), new object[]
						{
							unitSquadCollection4.ToStringLabels()
						});
					}
					this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.RemoveUnits(unitSquadCollection4);
					this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==.RemoveUnits(unitSquadCollection4);
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878871), new object[]
					{
						unitSquadCollection4.ToStringLabels(),
						JSONManager.Cut(text)
					});
				}
				flag2 = true;
			}
		}
		UnitSquadCollection unitSquadCollection5 = this.#=zkCv9LVofr6Y6FfiMZJuU87jjlDie;
		if (unitSquadCollection5.Count > 0)
		{
			string text2 = this.#=zBsXSanI=.#=zj6mJJFZU84bVSPLgcS8vCmc=(unitSquadCollection5);
			if (text2.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878900), new object[]
				{
					unitSquadCollection5.ToStringLabels()
				});
				this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.RemoveUnits(unitSquadCollection5);
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878871), new object[]
				{
					unitSquadCollection5.ToStringLabels(),
					JSONManager.Cut(text2)
				});
			}
			flag2 = true;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolTroopType == ActionSettings.SentToAcropolType.AllExceptSelectedTroops && (unitSquadCollection3 != null || #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= != null))
		{
			if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= != null)
			{
				using (List<UnitSquad>.Enumerator enumerator = unitSquadCollection2.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						UnitSquad unitSquad3 = enumerator.Current;
						if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(unitSquad3))
						{
							dictionary[unitSquad3.Type.Id] = unitSquad3.Number;
							flag = true;
						}
					}
					goto IL_543;
				}
			}
			if (unitSquadCollection3 == null)
			{
				goto IL_543;
			}
			using (List<UnitSquad>.Enumerator enumerator = unitSquadCollection3.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					UnitSquad unitSquad4 = enumerator.Current;
					if (!dictionary.ContainsKey(unitSquad4.Type.Id))
					{
						dictionary[unitSquad4.Type.Id] = unitSquad4.Number;
						flag = true;
					}
				}
				goto IL_543;
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolTroopType == ActionSettings.SentToAcropolType.GarrisonDefendersAndScouts)
		{
			using (List<UnitSquad>.Enumerator enumerator = unitSquadCollection2.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					UnitSquad unitSquad5 = enumerator.Current;
					if (unitSquad5.Type.Function == UnitType.Functions.Defence || unitSquad5.Type.Function == UnitType.Functions.Scouting)
					{
						dictionary[unitSquad5.Type.Id] = unitSquad5.Number;
						flag = true;
					}
				}
				goto IL_543;
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolTroopType == ActionSettings.SentToAcropolType.GarrisonDefenders)
		{
			foreach (UnitSquad unitSquad6 in unitSquadCollection2)
			{
				if (unitSquad6.Type.Function == UnitType.Functions.Defence)
				{
					dictionary[unitSquad6.Type.Id] = unitSquad6.Number;
					flag = true;
				}
			}
		}
		IL_543:
		if (flag)
		{
			UnitSquadCollection unitSquadCollection6 = new UnitSquadCollection();
			foreach (UnitSquad unitSquad7 in unitSquadCollection2)
			{
				if (dictionary.ContainsKey(unitSquad7.Type.Id) && dictionary[unitSquad7.Type.Id] > 0)
				{
					int num3 = dictionary[unitSquad7.Type.Id];
					int number = unitSquad7.Number;
					if (number < num3)
					{
						num3 = number;
					}
					unitSquadCollection6.Add(new UnitSquad(unitSquad7.Type, num3));
				}
			}
			if (unitSquadCollection6.Count > 0)
			{
				string text3 = this.#=zBsXSanI=.#=zf6Rj4tTeYocpS$xPAy8PT6s=(unitSquadCollection6);
				if (text3.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879078), new object[]
					{
						unitSquadCollection6.ToStringLabels()
					});
					this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection6);
					this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection6);
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879031), new object[]
					{
						unitSquadCollection6.ToStringLabels(),
						JSONManager.Cut(text3)
					});
				}
				flag2 = true;
			}
		}
		if (!flag2)
		{
			UnitType unitType = null;
			int num4 = 100000;
			foreach (UnitSquad unitSquad8 in unitSquadCollection2)
			{
				int id = unitSquad8.Type.Id;
				int num5;
				switch (id)
				{
				case 1:
					num5 = 3;
					break;
				case 2:
					num5 = 0;
					break;
				case 3:
					num5 = 1;
					break;
				case 4:
					num5 = 4;
					break;
				default:
					if (id != 33)
					{
						num5 = unitSquad8.Type.Id;
					}
					else
					{
						num5 = 2;
					}
					break;
				}
				if (num5 < num4)
				{
					unitType = unitSquad8.Type;
					num4 = num5;
				}
			}
			if (unitType != null)
			{
				UnitSquadCollection unitSquadCollection7 = new UnitSquadCollection();
				unitSquadCollection7.Add(new UnitSquad(unitType, 1));
				string text4 = this.#=zBsXSanI=.#=zf6Rj4tTeYocpS$xPAy8PT6s=(unitSquadCollection7);
				if (text4.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908880758), new object[]
					{
						unitType.Name
					});
					this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection7);
					this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection7);
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072156), new object[]
					{
						unitType.Name,
						JSONManager.Cut(text4)
					});
				}
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908880697), Array.Empty<object>());
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRemoveReinforcements)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908880655), Array.Empty<object>());
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() != this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5)
				{
					UnitSquadCollection unitSquadCollection8 = new UnitSquadCollection();
					foreach (UnitSquad unitSquad9 in #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD())
					{
						if (unitSquad9.Type.Function == UnitType.Functions.Undefined || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().RemoveReinforcementsFunctions.Contains((int)unitSquad9.Type.Function))
						{
							unitSquadCollection8.Add(new UnitSquad(unitSquad9.Type, unitSquad9.Number));
						}
					}
					int num6 = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT() != null) ? #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT().Count : 0;
					if (unitSquadCollection8.Count > 0 || (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Count == 0 && num6 > 0))
					{
						object[] array = null;
						if (unitSquadCollection8.Count == #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Count)
						{
							array = new object[num6];
							for (int i = 0; i < array.Length; i++)
							{
								array[i] = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT()[i];
							}
						}
						this.#=zBsXSanI=.#=zWicondYgaCG3plz5xLOBBmOFiSAU(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L(), unitSquadCollection8, array);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908880853), new object[]
						{
							unitSquadCollection8.ToStringLabels()
						});
					}
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908880810), Array.Empty<object>());
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsQuickSendToAcropolReturning)
		{
			#=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zNrsrq6kkMTvgTNVx_j_LZu4=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zVG1EPv1OUDdyLeGHGQ==, this.#=zwn5aCwWTvPV4);
			DateTime dateTime = DateTime.MaxValue;
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zVVorJLug3m2L() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_() != this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1 && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)1 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5) && dateTime > #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==())
				{
					dateTime = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==();
				}
			}
			if (dateTime < DateTime.Now + this.#=zcDRV51Ut$7oP.RepeatDelayMin - TimeSpan.FromSeconds(30.0))
			{
				this.#=zcDRV51Ut$7oP.NextExecutionTime = dateTime + TimeSpan.FromSeconds(15.0);
			}
		}
	}

	// Token: 0x040004ED RID: 1261
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x040004EE RID: 1262
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x040004EF RID: 1263
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x040004F0 RID: 1264
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x040004F1 RID: 1265
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x040004F2 RID: 1266
	private UnitSquadCollection #=zkCv9LVofr6Y6FfiMZJuU87jjlDie;

	// Token: 0x040004F3 RID: 1267
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4;
}
