﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000264 RID: 612
internal sealed class #=zioyJqCzIpuexwMlEpsfRemyKul_GDQlRN8yjQktMWwrAISIBz76Yas8= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001291 RID: 4753 RVA: 0x000915FC File Offset: 0x0008F7FC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zfwwssB5nM2Roeddk8doixMZAn$Qa = #=zuJjQ1XU=.#=zBnIJzUc1DkPSZ7$ymfBtn86ykUhA8cj6fg==();
	}

	// Token: 0x06001292 RID: 4754 RVA: 0x0009160C File Offset: 0x0008F80C
	protected override void #=zvb5bnug=()
	{
		for (int i = 0; i < this.#=zfwwssB5nM2Roeddk8doixMZAn$Qa.Count; i++)
		{
			int #=zvPiOyGQ= = this.#=zfwwssB5nM2Roeddk8doixMZAn$Qa[i];
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(this.#=z8StzeqE=, #=zvPiOyGQ=.ToString(), true, this.#=zBsXSanI=);
			string text = (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null) ? #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=() : #=zvPiOyGQ=.ToString();
			string text2 = this.#=zBsXSanI=.#=zRM9HIk7pc5abAsmYSCgFenpedBmq(#=zvPiOyGQ=);
			if (text2.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978124), new object[]
				{
					text
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978072), new object[]
				{
					text,
					JSONManager.Cut(text2)
				});
			}
		}
	}

	// Token: 0x04000AB2 RID: 2738
	private List<int> #=zfwwssB5nM2Roeddk8doixMZAn$Qa;
}
