﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020000EC RID: 236
internal sealed class #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==
{
	// Token: 0x06000626 RID: 1574 RVA: 0x00031D3C File Offset: 0x0002FF3C
	public #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==(int #=zAk8mKBk=)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zwXKUV2c=(#=zAk8mKBk=.ToString());
		this.#=z_PEN4Dg=(UnitType.Classes.Undefined);
		this.#=z8RUD$1mtl5at(UnitType.Functions.Undefined);
		this.#=zgnkJYDRzf3SP(Worlds.Default);
	}

	// Token: 0x06000627 RID: 1575 RVA: 0x00031D70 File Offset: 0x0002FF70
	public #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==(Dictionary<string, object> #=zExftZzJZSiNU, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zExftZzJZSiNU, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zwXKUV2c=(JSONManager.GetString(#=zExftZzJZSiNU, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zExftZzJZSiNU, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059742));
		this.#=z_PEN4Dg=(UnitType.Classes.Undefined);
		foreach (int id in JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)))
		{
			UnitType unitType = #=zlhLE8UQVU0AG.Find(id);
			if (unitType != null && unitType.Class >= UnitType.Classes.LightInfantry && unitType.Class <= UnitType.Classes.Cavalry)
			{
				this.#=z_PEN4Dg=(unitType.Class);
				break;
			}
		}
		double @double = JSONManager.GetDouble(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059735), 0.0);
		this.#=z8RUD$1mtl5at((@double > 0.0) ? UnitType.Functions.Offence : UnitType.Functions.Defence);
		this.#=zgnkJYDRzf3SP((Worlds)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), 0));
	}

	// Token: 0x06000628 RID: 1576 RVA: 0x00031E68 File Offset: 0x00030068
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000629 RID: 1577 RVA: 0x00031E70 File Offset: 0x00030070
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600062A RID: 1578 RVA: 0x00031E7C File Offset: 0x0003007C
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x00031E84 File Offset: 0x00030084
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x00031E90 File Offset: 0x00030090
	public UnitType.Classes #=z9gSOax4=()
	{
		return this.#=zOPBAYSIdpaoKtoM9Ug==;
	}

	// Token: 0x0600062D RID: 1581 RVA: 0x00031E98 File Offset: 0x00030098
	public void #=z_PEN4Dg=(UnitType.Classes #=z$Ib9gYQ=)
	{
		this.#=zOPBAYSIdpaoKtoM9Ug== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00031EA4 File Offset: 0x000300A4
	public UnitType.Functions #=zZOFUOewkm7ea()
	{
		return this.#=zxxpCOnxCUYo104orQw==;
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00031EAC File Offset: 0x000300AC
	public void #=z8RUD$1mtl5at(UnitType.Functions #=z$Ib9gYQ=)
	{
		this.#=zxxpCOnxCUYo104orQw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000630 RID: 1584 RVA: 0x00031EB8 File Offset: 0x000300B8
	public Worlds #=zWxFFEucRtmR7()
	{
		return this.#=zkaYDApIDgg7EmYnzrQ==;
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00031EC0 File Offset: 0x000300C0
	public void #=zgnkJYDRzf3SP(Worlds #=z$Ib9gYQ=)
	{
		this.#=zkaYDApIDgg7EmYnzrQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00031ECC File Offset: 0x000300CC
	public string #=zTbtwDpWhYGtF()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059718), this.#=zkfqcY3I=(), UnitType.GetName(this.#=z9gSOax4=()), UnitType.GetName(this.#=zZOFUOewkm7ea()));
	}

	// Token: 0x06000633 RID: 1587 RVA: 0x00031EFC File Offset: 0x000300FC
	public override string ToString()
	{
		return this.#=zTbtwDpWhYGtF();
	}

	// Token: 0x0400028A RID: 650
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400028B RID: 651
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x0400028C RID: 652
	private UnitType.Classes #=zOPBAYSIdpaoKtoM9Ug==;

	// Token: 0x0400028D RID: 653
	private UnitType.Functions #=zxxpCOnxCUYo104orQw==;

	// Token: 0x0400028E RID: 654
	private Worlds #=zkaYDApIDgg7EmYnzrQ==;
}
