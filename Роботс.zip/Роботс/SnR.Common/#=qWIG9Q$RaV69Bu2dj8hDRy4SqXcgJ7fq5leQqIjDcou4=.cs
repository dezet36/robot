﻿using System;

// Token: 0x0200000E RID: 14
internal interface #=qWIG9Q$RaV69Bu2dj8hDRy4SqXcgJ7fq5leQqIjDcou4=
{
	// Token: 0x06000034 RID: 52
	#=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc= #=z6YrlOjPNpyDx5Hx00O6hn2KzbOkV4hSRvJ4TvrOR26XahpVdvbJjlzPlMeAznrYud2eDs$uok0ru();
}
