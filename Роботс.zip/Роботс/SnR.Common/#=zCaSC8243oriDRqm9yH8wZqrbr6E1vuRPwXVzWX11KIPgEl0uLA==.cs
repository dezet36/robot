﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000D3 RID: 211
internal sealed class #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==
{
	// Token: 0x060005AA RID: 1450 RVA: 0x0002F7C8 File Offset: 0x0002D9C8
	public #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==(Dictionary<string, object> #=zMjXrdCadDOhD, int #=zJTk4iEA=, int #=zeFkjISA=)
	{
		this.#=z5s7dqgppXfql(#=zJTk4iEA=);
		this.#=z8tNNZ5MpdBDu(#=zeFkjISA=);
		object[] array = JSONManager.ExtractArray(#=zMjXrdCadDOhD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
		this.#=zPGclfTr1_ysemCpLew==(new int[array.Length]);
		for (int i = 0; i < array.Length; i++)
		{
			int num = JSONManager.ExtractInt((Dictionary<string, object>)array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0);
			this.#=zzBrGWDHiU0qLGetyaA==()[i] = num;
		}
		this.#=zMfbH6DPvS3E53ORQHw==(JSONManager.ExtractInt(#=zMjXrdCadDOhD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), 0));
		object[] array2 = JSONManager.ExtractArray(#=zMjXrdCadDOhD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
		this.#=z_NY_wVRST06i5VTlkEeNi4RFRtxP(new List<int>());
		if (array2 != null)
		{
			foreach (int item in array2)
			{
				this.#=zkC6ZpKb4sZtQYz2NHZb9oTnLoFAD().Add(item);
			}
		}
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x0002F89C File Offset: 0x0002DA9C
	public int #=z7k8I7thUvsEP()
	{
		return this.#=zJYbslh91JJpedpnZXQ==;
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x0002F8A4 File Offset: 0x0002DAA4
	public void #=z5s7dqgppXfql(int #=z$Ib9gYQ=)
	{
		this.#=zJYbslh91JJpedpnZXQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x0002F8B0 File Offset: 0x0002DAB0
	public int #=z6GHEmJnDqJOM()
	{
		return this.#=zlQ$qfBnIPUjP1H780w==;
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x0002F8B8 File Offset: 0x0002DAB8
	public void #=z8tNNZ5MpdBDu(int #=z$Ib9gYQ=)
	{
		this.#=zlQ$qfBnIPUjP1H780w== = #=z$Ib9gYQ=;
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x0002F8C4 File Offset: 0x0002DAC4
	public int[] #=zzBrGWDHiU0qLGetyaA==()
	{
		return this.#=zflcVLexAwefLFVRXkSmMipE=;
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x0002F8CC File Offset: 0x0002DACC
	public void #=zPGclfTr1_ysemCpLew==(int[] #=z$Ib9gYQ=)
	{
		this.#=zflcVLexAwefLFVRXkSmMipE= = #=z$Ib9gYQ=;
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x0002F8D8 File Offset: 0x0002DAD8
	public int #=z0Uzl8ZetHWLkQjzo1g==()
	{
		return this.#=z43GxmvR_8Y8Xu04KoobuOPsB_Drd;
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x0002F8E0 File Offset: 0x0002DAE0
	public void #=zMfbH6DPvS3E53ORQHw==(int #=z$Ib9gYQ=)
	{
		this.#=z43GxmvR_8Y8Xu04KoobuOPsB_Drd = #=z$Ib9gYQ=;
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x0002F8EC File Offset: 0x0002DAEC
	public List<int> #=zkC6ZpKb4sZtQYz2NHZb9oTnLoFAD()
	{
		return this.#=zQuhT5A1oNb38KcO1UWFRRy1R6uStef8HIA==;
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x0002F8F4 File Offset: 0x0002DAF4
	public void #=z_NY_wVRST06i5VTlkEeNi4RFRtxP(List<int> #=z$Ib9gYQ=)
	{
		this.#=zQuhT5A1oNb38KcO1UWFRRy1R6uStef8HIA== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000259 RID: 601
	private int #=zJYbslh91JJpedpnZXQ==;

	// Token: 0x0400025A RID: 602
	private int #=zlQ$qfBnIPUjP1H780w==;

	// Token: 0x0400025B RID: 603
	private int[] #=zflcVLexAwefLFVRXkSmMipE=;

	// Token: 0x0400025C RID: 604
	private int #=z43GxmvR_8Y8Xu04KoobuOPsB_Drd;

	// Token: 0x0400025D RID: 605
	private List<int> #=zQuhT5A1oNb38KcO1UWFRRy1R6uStef8HIA==;
}
