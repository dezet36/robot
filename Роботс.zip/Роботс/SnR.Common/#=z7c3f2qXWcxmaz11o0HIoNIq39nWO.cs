﻿using System;

// Token: 0x02000092 RID: 146
internal sealed class #=z7c3f2qXWcxmaz11o0HIoNIq39nWO
{
	// Token: 0x06000400 RID: 1024 RVA: 0x00023EB8 File Offset: 0x000220B8
	public #=z7c3f2qXWcxmaz11o0HIoNIq39nWO(#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zvRLj9WQ=, int #=zKJA8IWQ=, double #=ze7ZtytQ=)
	{
		this.#=zzQwUIEs=(#=zvRLj9WQ=);
		this.#=zIaGGDzQ=(#=zKJA8IWQ=);
		this.#=zKTAVzhk=(#=ze7ZtytQ=);
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x00023ED8 File Offset: 0x000220D8
	public #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x00023EE0 File Offset: 0x000220E0
	public void #=zzQwUIEs=(#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x00023EEC File Offset: 0x000220EC
	public int #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x00023EF4 File Offset: 0x000220F4
	public void #=zIaGGDzQ=(int #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x00023F00 File Offset: 0x00022100
	public double #=zVcIxe_4=()
	{
		return this.#=ztQqooRHjQH3h6k4JJg==;
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x00023F08 File Offset: 0x00022108
	public void #=zKTAVzhk=(double #=z$Ib9gYQ=)
	{
		this.#=ztQqooRHjQH3h6k4JJg== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000177 RID: 375
	private #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x04000178 RID: 376
	private int #=z7Xrwc11cWxGe$3RbFQ==;

	// Token: 0x04000179 RID: 377
	private double #=ztQqooRHjQH3h6k4JJg==;

	// Token: 0x02000093 RID: 147
	public enum #=zArez$Gs=
	{

	}
}
