﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000004 RID: 4
internal static class #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=
{
	// Token: 0x0600000A RID: 10 RVA: 0x0000219C File Offset: 0x0000039C
	[MethodImpl(MethodImplOptions.NoInlining)]
	static #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=()
	{
		int num = -882104937;
		int num2 = -1182168140 - num;
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO = new ConcurrentDictionary<int, string>();
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zykaXBLzatylFjOd56lGvjZNSOoX$ += ~(-(-(~(~(-(~(-(-(~(~(-813694007 + num + num2)))))))))));
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zlbMOdL1VKb8BqgWxV8P6YH5aQtix = ((#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMQiaYnqoai3D4S_1lxoW9WmWyS2Z)16 | #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zlbMOdL1VKb8BqgWxV8P6YH5aQtix);
	}

	// Token: 0x0600000B RID: 11 RVA: 0x000021F0 File Offset: 0x000003F0
	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static string #=ze04twNQ=(int #=zoc8jn7vCeskyE6roZYEbKaybMghw)
	{
		string result;
		if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO.TryGetValue(#=zoc8jn7vCeskyE6roZYEbKaybMghw, ref result))
		{
			return result;
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zlaNfPl88yqDo2cOpyg82h$Pq9g7i(#=zoc8jn7vCeskyE6roZYEbKaybMghw, true);
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00002218 File Offset: 0x00000418
	[MethodImpl(MethodImplOptions.NoInlining)]
	private static string #=zlaNfPl88yqDo2cOpyg82h$Pq9g7i(int #=zoc8jn7vCeskyE6roZYEbKaybMghw, bool #=zIfkVB5s19Zd6IUswXIDiDTpH3KED)
	{
		int num = -1461620465;
		int num2 = num ^ 202929261;
		string text = null;
		byte[] array;
		int num18;
		int num19;
		int num20;
		int num21;
		int num22;
		byte[] array4;
		byte[] array5;
		do
		{
			ConcurrentDictionary<int, string> obj = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO;
			lock (obj)
			{
				int num5;
				if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM == null)
				{
					Assembly executingAssembly = Assembly.GetExecutingAssembly();
					Assembly #=zJeWj$8YN0cYTwGYJR4DcN2TZay9w = Assembly.GetCallingAssembly();
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE |= (1304627439 - num ^ num2);
					Assembly assembly = executingAssembly;
					StringBuilder stringBuilder = new StringBuilder();
					int num3 = -769021553 + num + num2;
					stringBuilder.Append((char)(num3 >> 16)).Append((char)num3);
					num3 = (768775799 - num ^ num2);
					stringBuilder.Append((char)(num3 >> 16)).Append((char)num3);
					num3 = num + 471708761 - num2;
					stringBuilder.Append((char)(num3 >> 16)).Append((char)num3);
					num3 = 602966966 - num + num2;
					stringBuilder.Append((char)num3).Append((char)(num3 >> 16));
					num3 = num + 471970909 - num2;
					stringBuilder.Append((char)num3).Append((char)(num3 >> 16));
					num3 = (-739349589 ^ num) + num2;
					stringBuilder.Append((char)(num3 >> 16)).Append((char)num3);
					Stream manifestResourceStream = assembly.GetManifestResourceStream(stringBuilder.ToString());
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM = new #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=za_LJuruqV98atmcurjY0kbZ61Rhw(manifestResourceStream);
					short num4 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zC5UaNWiPGXZtqpgzGKTojdQkOjYA() ^ (short)(-(short)(~(short)(-(short)(~(short)(~(short)(-(short)(-(short)(~(short)(~(short)(1306148690 - num - num2))))))))));
					if (num4 == 0)
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zZlMzI6g$_jQm8s2CDMupE1V6$oqL = (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zC5UaNWiPGXZtqpgzGKTojdQkOjYA() ^ (short)(-(short)(~(short)(~(short)(-(short)(-(short)(~(short)(-(short)(~(short)(~(short)(num ^ 202917459 ^ num2)))))))))));
					}
					else
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zubQVQgO$93QVk37540yKRzJMKBJH = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zkYDUkiCRVOxXJ_Yycexwsi20DukG((int)num4);
					}
					#=zJeWj$8YN0cYTwGYJR4DcN2TZay9w = executingAssembly;
					AssemblyName #=znH4IyjlchgTtOFiCDC6A4RE= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zElbscuQDtTzK8qJDcxfB4NT1Fxmr(#=zJeWj$8YN0cYTwGYJR4DcN2TZay9w);
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zk3iMZApVwz_S6iUMGE7H0JoTYy2B = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=z5a3n3ADHCPoJTy9cz2JbSawy5mYX(#=znH4IyjlchgTtOFiCDC6A4RE=);
					num5 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zykaXBLzatylFjOd56lGvjZNSOoX$;
					num5 ^= 2061424542 - num + num2;
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zykaXBLzatylFjOd56lGvjZNSOoX$ = 0;
					long num6 = #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=ze04twNQ=();
					num5 ^= (int)((uint)num6);
					num5 ^= (239804473 + num ^ num2);
					num5 ^= 520781742 - num + num2;
					int num7 = num5;
					int num8 = num7;
					int num9 = ((202926848 ^ num) - num2) * num8 % (1312799134 - num ^ num2);
					int num10 = 0;
					int num11 = num9 - (num + -1589710810 - num2) ^ (-1698281918 ^ num ^ num2);
					int #=z4Q$h3mE= = num11;
					#=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<int> enumerator = ((#=q_j6iJL0eUaGbqSd8hGx54PQjL$61MKS93NuyOv07xBg=<int>)new #=qPk4l39wK$oGOW0yMMFUnLDysK5PRD_sH3rL0idDWQ6g=.#=zm8PpuDU=(65563563 - num | num2)
					{
						#=z4Q$h3mE= = #=z4Q$h3mE=
					}).GetEnumerator();
					try
					{
						while (enumerator.#=z5od3PV4HEEHLXRWOfZO6P1VrIQHbl1oBd8Cp_FowZoG3mzdKBhQQCq7rP3hB8qKv88UWk0MgM_LM())
						{
							int num12 = enumerator.#=zRGzvFRPn8bJ9t1Tvjk6L$29zAc8YPrcXV_qXA_O5PDBquk65wTwHU61yY9$vh4FPEQ==();
							num11 ^= num10 - num12 << 2;
							num10 += num11 >> 3;
						}
					}
					finally
					{
						if (enumerator != null)
						{
							enumerator.#=zXVKTZd7T7qKoxpenUPk6ayEmbY9Om$Ec7B0m5cxARitAbwiE$vtsuXxtRawok0wSkgFZdAWmmx0E0NaW5WbdhqXhg0lr();
						}
					}
					int num13 = num11;
					num5 ^= -(~(-(~(-(~(~(-(~(890163014 + num + num2)))))))));
					num5 = num13 + num5;
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE = ((#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE & (num ^ 65506079 ^ num2)) ^ 65570353 - num + num2);
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zzs$e0narQCZNuLwxdWwuQMvbA6Yb = num5;
					if ((#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zlbMOdL1VKb8BqgWxV8P6YH5aQtix & ~(-(~(-(~(-(-(~(~(-(~((#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMQiaYnqoai3D4S_1lxoW9WmWyS2Z)(-65563585) + num - num2)))))))))))) == (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMQiaYnqoai3D4S_1lxoW9WmWyS2Z)0)
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE = (num ^ 202956759 ^ num2);
					}
				}
				else
				{
					num5 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zzs$e0narQCZNuLwxdWwuQMvbA6Yb;
				}
				if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE == 1306206763 - num - num2)
				{
					text = new string(new char[]
					{
						(char)(-65563605 + num ^ num2),
						'0',
						(char)((-202929159 ^ num) + num2)
					});
					return text;
				}
				int num14 = #=zoc8jn7vCeskyE6roZYEbKaybMghw ^ num + 1945434691 - num2 ^ num5;
				num14 ^= 284214940 - num + num2;
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zPRLm5luuUzqnthNPBSHzNE5leyfy().Position = (long)num14;
				if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zubQVQgO$93QVk37540yKRzJMKBJH != null)
				{
					array = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zubQVQgO$93QVk37540yKRzJMKBJH;
				}
				else
				{
					short num15;
					if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zZlMzI6g$_jQm8s2CDMupE1V6$oqL == -1)
					{
						num15 = (short)((int)#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zC5UaNWiPGXZtqpgzGKTojdQkOjYA() ^ (202913918 ^ num) - num2 ^ num14);
					}
					else
					{
						num15 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zZlMzI6g$_jQm8s2CDMupE1V6$oqL;
					}
					if (num15 == 0)
					{
						array = null;
					}
					else
					{
						array = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zkYDUkiCRVOxXJ_Yycexwsi20DukG((int)num15);
						for (int num16 = 0; num16 != array.Length; num16++)
						{
							byte[] array2 = array;
							int num17 = num16;
							array2[num17] ^= (byte)(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zzs$e0narQCZNuLwxdWwuQMvbA6Yb >> ((num16 & 3) << 3));
						}
					}
				}
				num18 = (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=z8YXWYfjlrygSzjfTOEjn2FwWrAhG() ^ num14 ^ -(~(~(-(~(-(~(-(~(-(~(1291944660 - num ^ num2))))))))))) ^ num5);
				if (num18 == ((-202929261 ^ num) | num2))
				{
					byte[] array3 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zkYDUkiCRVOxXJ_Yycexwsi20DukG(4);
					#=zoc8jn7vCeskyE6roZYEbKaybMghw = (1291936198 - num - num2 ^ num5);
					#=zoc8jn7vCeskyE6roZYEbKaybMghw = (((int)array3[2] | (int)array3[3] << 16 | (int)array3[0] << 8 | (int)array3[1] << 24) ^ -#=zoc8jn7vCeskyE6roZYEbKaybMghw);
					goto IL_13;
				}
				num19 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE;
				num20 = (201391339 ^ num ^ num2);
				num21 = num18;
				num22 = num19 - 12;
				num18 &= num + -1037727346 + num2;
				array4 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zkYDUkiCRVOxXJ_Yycexwsi20DukG(num18);
				array5 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zk3iMZApVwz_S6iUMGE7H0JoTYy2B;
			}
			goto IL_4B3;
			IL_13:;
		}
		while (!#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO.TryGetValue(#=zoc8jn7vCeskyE6roZYEbKaybMghw, ref text));
		return text;
		IL_4B3:
		bool flag2 = (num21 & (769291889 - num ^ num2)) != 0;
		bool flag3 = (num21 & (num ^ 1276671085) - num2) != 0;
		bool flag4 = (num21 & -2081920083 - num + num2) != 0;
		byte[] array6 = array;
		byte[] array7 = array4;
		byte[] array8 = array6;
		byte b = array8[1];
		int num23 = array7.Length;
		byte b2 = (byte)(num23 + 11 ^ (int)(b + 7));
		uint num24 = (uint)(((int)array8[0] | (int)array8[2] << 8) + ((int)b2 << 3));
		ushort num25 = 0;
		int i = 0;
		while (i < num23)
		{
			if ((1 & i) == 0)
			{
				num24 = num24 * (uint)(num + -65349552 - num2) + (uint)((-204674962 ^ num) + num2);
				num25 = (ushort)(num24 >> 16);
			}
			byte b3 = (byte)num25;
			num25 = (ushort)(num25 >> 8);
			byte b4 = array7[i];
			array7[i] = (b4 ^ b ^ b2 + 3 ^ b3);
			i++;
			b2 = b4;
		}
		array4 = array7;
		if (array5 != null != (num19 != num20))
		{
			for (int j = 0; j < num18; j = 1 + j)
			{
				byte b5 = array5[7 & j];
				b5 = (byte)((int)b5 << 3 | b5 >> 5);
				array4[j] ^= b5;
			}
		}
		byte[] array9;
		int num26;
		if (!flag3)
		{
			array9 = array4;
			num26 = num18;
		}
		else
		{
			num26 = ((int)array4[2] | (int)array4[0] << 16 | (int)array4[3] << 8 | (int)array4[1] << 24);
			array9 = new byte[num26];
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zfunBKOYm$g4XGT6JZoz$Q8K9uVTD(array4, 4, array9);
		}
		if (flag2 && num22 == num20 - 12)
		{
			char[] array10 = new char[num26];
			for (int k = 0; k < num26; k++)
			{
				array10[k] = (char)array9[k];
			}
			text = new string(array10);
		}
		else
		{
			text = Encoding.Unicode.GetString(array9, 0, array9.Length);
		}
		num22 += (1306162732 - num ^ num2) + (3 & num22) << 5;
		if (num22 != num20 - 12 + ((202929390 ^ num) - num2 + (num20 - 12 & 3) << 5))
		{
			int num27 = #=zoc8jn7vCeskyE6roZYEbKaybMghw + num18 ^ -1305226233 + num + num2 ^ (num22 & (num ^ 202928480 ^ num2));
			StringBuilder stringBuilder = new StringBuilder();
			int num3 = num + -1306162713 + num2;
			stringBuilder.Append((char)((byte)num3));
			text = num27.ToString(stringBuilder.ToString());
		}
		if (false == flag4 && #=zIfkVB5s19Zd6IUswXIDiDTpH3KED)
		{
			text = string.Intern(text);
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO[#=zoc8jn7vCeskyE6roZYEbKaybMghw] = text;
			if (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO.Count == (num ^ 202927813) - num2)
			{
				ConcurrentDictionary<int, string> obj2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMtGUut7KKRGQEQHmYLfB1YVKu_SO;
				lock (obj2)
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM.#=zfa_fD8W6gSWsPXxbmbGSSrtLhury();
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zNCAwwDg6d99kaYak_2C8ctwXDcWM = null;
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zubQVQgO$93QVk37540yKRzJMKBJH = null;
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zk3iMZApVwz_S6iUMGE7H0JoTYy2B = null;
				}
			}
		}
		return text;
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000029B4 File Offset: 0x00000BB4
	private static AssemblyName #=zElbscuQDtTzK8qJDcxfB4NT1Fxmr(Assembly #=zJeWj$8YN0cYTwGYJR4DcN2TZay9w)
	{
		AssemblyName result;
		try
		{
			result = #=zJeWj$8YN0cYTwGYJR4DcN2TZay9w.GetName();
		}
		catch
		{
			result = new AssemblyName(#=zJeWj$8YN0cYTwGYJR4DcN2TZay9w.FullName);
		}
		return result;
	}

	// Token: 0x0600000E RID: 14 RVA: 0x000029EC File Offset: 0x00000BEC
	private static byte[] #=z5a3n3ADHCPoJTy9cz2JbSawy5mYX(AssemblyName #=znH4IyjlchgTtOFiCDC6A4RE=)
	{
		byte[] array = #=znH4IyjlchgTtOFiCDC6A4RE=.GetPublicKeyToken();
		if (array != null && array.Length == 0)
		{
			array = null;
		}
		return array;
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002A0C File Offset: 0x00000C0C
	private static void #=zfunBKOYm$g4XGT6JZoz$Q8K9uVTD(byte[] #=zYkvzUnaiPK78EYW2nD6ER1R1Auzo, int #=zOFl1QE2zi7NgaxGXPUbUtqs=, byte[] #=zlvFO4Z5zrupHQwC9ngUoHFwcNBzH)
	{
		int i = 0;
		int num = 0;
		int num2 = 128;
		int num3 = #=zlvFO4Z5zrupHQwC9ngUoHFwcNBzH.Length;
		while (i < num3)
		{
			if ((num2 <<= 1) == 256)
			{
				num2 = 1;
				num = (int)#=zYkvzUnaiPK78EYW2nD6ER1R1Auzo[#=zOFl1QE2zi7NgaxGXPUbUtqs=++];
			}
			if ((num & num2) != 0)
			{
				int num4 = (#=zYkvzUnaiPK78EYW2nD6ER1R1Auzo[#=zOFl1QE2zi7NgaxGXPUbUtqs=] >> 2) + 3;
				int num5 = ((int)#=zYkvzUnaiPK78EYW2nD6ER1R1Auzo[#=zOFl1QE2zi7NgaxGXPUbUtqs=] << 8 | (int)#=zYkvzUnaiPK78EYW2nD6ER1R1Auzo[#=zOFl1QE2zi7NgaxGXPUbUtqs= + 1]) & 1023;
				#=zOFl1QE2zi7NgaxGXPUbUtqs= += 2;
				int num6 = i - num5;
				if (num6 < 0)
				{
					return;
				}
				while (--num4 >= 0)
				{
					if (i >= num3)
					{
						break;
					}
					#=zlvFO4Z5zrupHQwC9ngUoHFwcNBzH[i++] = #=zlvFO4Z5zrupHQwC9ngUoHFwcNBzH[num6++];
				}
			}
			else
			{
				#=zlvFO4Z5zrupHQwC9ngUoHFwcNBzH[i++] = #=zYkvzUnaiPK78EYW2nD6ER1R1Auzo[#=zOFl1QE2zi7NgaxGXPUbUtqs=++];
			}
		}
	}

	// Token: 0x04000001 RID: 1
	private static #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=za_LJuruqV98atmcurjY0kbZ61Rhw #=zNCAwwDg6d99kaYak_2C8ctwXDcWM;

	// Token: 0x04000002 RID: 2
	private static int #=zqGGrseUmF8$oW5ttnv6IlzHjJ9SE;

	// Token: 0x04000003 RID: 3
	private static short #=zZlMzI6g$_jQm8s2CDMupE1V6$oqL;

	// Token: 0x04000004 RID: 4
	private static byte[] #=zubQVQgO$93QVk37540yKRzJMKBJH;

	// Token: 0x04000005 RID: 5
	private static int #=zzs$e0narQCZNuLwxdWwuQMvbA6Yb;

	// Token: 0x04000006 RID: 6
	private static byte[] #=zk3iMZApVwz_S6iUMGE7H0JoTYy2B;

	// Token: 0x04000007 RID: 7
	private static ConcurrentDictionary<int, string> #=zMtGUut7KKRGQEQHmYLfB1YVKu_SO;

	// Token: 0x04000008 RID: 8
	private static int #=zykaXBLzatylFjOd56lGvjZNSOoX$;

	// Token: 0x04000009 RID: 9
	private static #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=zMQiaYnqoai3D4S_1lxoW9WmWyS2Z #=zlbMOdL1VKb8BqgWxV8P6YH5aQtix;

	// Token: 0x02000005 RID: 5
	private enum #=zMQiaYnqoai3D4S_1lxoW9WmWyS2Z
	{

	}

	// Token: 0x02000006 RID: 6
	private sealed class #=za_LJuruqV98atmcurjY0kbZ61Rhw
	{
		// Token: 0x06000010 RID: 16 RVA: 0x00002AB0 File Offset: 0x00000CB0
		public #=za_LJuruqV98atmcurjY0kbZ61Rhw(Stream #=zd_jfmZN79X8j9Vd$d2xmW1bWtFCE)
		{
			this.#=z9uhDISnobytKYyYF8iSN3VhJccw0 = #=zd_jfmZN79X8j9Vd$d2xmW1bWtFCE;
			this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ = new byte[4];
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002ACC File Offset: 0x00000CCC
		public Stream #=zPRLm5luuUzqnthNPBSHzNE5leyfy()
		{
			return this.#=z9uhDISnobytKYyYF8iSN3VhJccw0;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002AD4 File Offset: 0x00000CD4
		public short #=zC5UaNWiPGXZtqpgzGKTojdQkOjYA()
		{
			this.#=zQdvARrE6kabiQUuqSeCQKKI=(2);
			return (short)((int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[0] | (int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[1] << 8);
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002AF4 File Offset: 0x00000CF4
		public int #=z8YXWYfjlrygSzjfTOEjn2FwWrAhG()
		{
			this.#=zQdvARrE6kabiQUuqSeCQKKI=(4);
			return (int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[0] | (int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[1] << 8 | (int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[2] << 16 | (int)this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[3] << 24;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002B28 File Offset: 0x00000D28
		private static void #=zhLQ1nwkCgNlPUW3JVxfE0BjqlDd2()
		{
			throw new EndOfStreamException();
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00002B30 File Offset: 0x00000D30
		private void #=zQdvARrE6kabiQUuqSeCQKKI=(int #=zdxsHtrunZTFUkJa_WlKaSoMNh7m4)
		{
			int num = 0;
			if (#=zdxsHtrunZTFUkJa_WlKaSoMNh7m4 == 1)
			{
				int num2 = this.#=z9uhDISnobytKYyYF8iSN3VhJccw0.ReadByte();
				if (num2 == -1)
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=za_LJuruqV98atmcurjY0kbZ61Rhw.#=zhLQ1nwkCgNlPUW3JVxfE0BjqlDd2();
				}
				this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ[0] = (byte)num2;
				return;
			}
			do
			{
				int num2 = this.#=z9uhDISnobytKYyYF8iSN3VhJccw0.Read(this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ, num, #=zdxsHtrunZTFUkJa_WlKaSoMNh7m4 - num);
				if (num2 == 0)
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=za_LJuruqV98atmcurjY0kbZ61Rhw.#=zhLQ1nwkCgNlPUW3JVxfE0BjqlDd2();
				}
				num += num2;
			}
			while (num < #=zdxsHtrunZTFUkJa_WlKaSoMNh7m4);
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002B8C File Offset: 0x00000D8C
		public void #=zfa_fD8W6gSWsPXxbmbGSSrtLhury()
		{
			Stream stream = this.#=z9uhDISnobytKYyYF8iSN3VhJccw0;
			this.#=z9uhDISnobytKYyYF8iSN3VhJccw0 = null;
			if (stream != null)
			{
				stream.Close();
			}
			this.#=zIgHjEkS7yOXoVaMj_vaWknx000CQ = null;
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002BB8 File Offset: 0x00000DB8
		public byte[] #=zkYDUkiCRVOxXJ_Yycexwsi20DukG(int #=zRqfIgwiWlhAGeFYGe2xlOx88gS1w)
		{
			if (#=zRqfIgwiWlhAGeFYGe2xlOx88gS1w < 0)
			{
				throw new ArgumentOutOfRangeException();
			}
			byte[] array = new byte[#=zRqfIgwiWlhAGeFYGe2xlOx88gS1w];
			int num = 0;
			do
			{
				int num2 = this.#=z9uhDISnobytKYyYF8iSN3VhJccw0.Read(array, num, #=zRqfIgwiWlhAGeFYGe2xlOx88gS1w);
				if (num2 == 0)
				{
					break;
				}
				num += num2;
				#=zRqfIgwiWlhAGeFYGe2xlOx88gS1w -= num2;
			}
			while (#=zRqfIgwiWlhAGeFYGe2xlOx88gS1w > 0);
			if (num != array.Length)
			{
				byte[] array2 = new byte[num];
				Buffer.BlockCopy(array, 0, array2, 0, num);
				array = array2;
			}
			return array;
		}

		// Token: 0x0400000B RID: 11
		private Stream #=z9uhDISnobytKYyYF8iSN3VhJccw0;

		// Token: 0x0400000C RID: 12
		private byte[] #=zIgHjEkS7yOXoVaMj_vaWknx000CQ;
	}
}
