﻿using System;
using System.Text;
using NExcel;
using NExcel.Biff;

// Token: 0x020000D1 RID: 209
internal sealed class #=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600059A RID: 1434 RVA: 0x0002ECB4 File Offset: 0x0002CEB4
	public #=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C(Cell #=zLWZxLVM=)
	{
		this.#=zq07FqDs= = #=zLWZxLVM=;
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x0002ECC4 File Offset: 0x0002CEC4
	internal int #=zas6WF9Y7vCuz()
	{
		return this.#=zDec2DjUIpVoA;
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x0002ECCC File Offset: 0x0002CECC
	internal int #=zEEViUu7KfNd$()
	{
		return this.#=zkVbotU1onZOR;
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x0002ECD4 File Offset: 0x0002CED4
	internal int #=zf4bYulRRFW0C()
	{
		return this.#=zh1vaBWFzORUr;
	}

	// Token: 0x0600059E RID: 1438 RVA: 0x0002ECDC File Offset: 0x0002CEDC
	internal int #=zW5QkwOB5a$bC()
	{
		return this.#=znnJ2FmckCK2R;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x0002ECE4 File Offset: 0x0002CEE4
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[9];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQ_CaaLVcHjOz.#=zd$BbM3Y=();
		IntegerHelper.getTwoBytes(this.#=zkVbotU1onZOR, array, 1);
		IntegerHelper.getTwoBytes(this.#=znnJ2FmckCK2R, array, 3);
		IntegerHelper.getTwoBytes(this.#=zDec2DjUIpVoA, array, 5);
		IntegerHelper.getTwoBytes(this.#=zh1vaBWFzORUr, array, 7);
		return array;
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x0002ED3C File Offset: 0x0002CF3C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zkVbotU1onZOR = (int)IntegerHelper.getShort(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		this.#=znnJ2FmckCK2R = (int)IntegerHelper.getShort(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 4], #=zJ5GWysk=[#=z4J_G3VM= + 5]);
		this.#=zDec2DjUIpVoA = (@int & 255);
		this.#=z3EZeT1Eq9S9C = ((@int & 16384) != 0);
		this.#=zcCic2xXY931G = ((@int & 32768) != 0);
		if (this.#=z3EZeT1Eq9S9C)
		{
			this.#=zDec2DjUIpVoA = this.#=zq07FqDs=.Column + this.#=zDec2DjUIpVoA;
		}
		if (this.#=zcCic2xXY931G)
		{
			this.#=zkVbotU1onZOR = this.#=zq07FqDs=.Row + this.#=zkVbotU1onZOR;
		}
		@int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 6], #=zJ5GWysk=[#=z4J_G3VM= + 7]);
		this.#=zh1vaBWFzORUr = (@int & 255);
		this.#=z0ObI7fN0V9z1 = ((@int & 16384) != 0);
		this.#=zDW3g0K7EfcSm = ((@int & 32768) != 0);
		if (this.#=z0ObI7fN0V9z1)
		{
			this.#=zh1vaBWFzORUr = this.#=zq07FqDs=.Column + this.#=zh1vaBWFzORUr;
		}
		if (this.#=zDW3g0K7EfcSm)
		{
			this.#=znnJ2FmckCK2R = this.#=zq07FqDs=.Row + this.#=znnJ2FmckCK2R;
		}
		return 8;
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x0002EE6C File Offset: 0x0002D06C
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		NExcel.Biff.CellReferenceHelper.getCellReference(this.#=zDec2DjUIpVoA, this.#=zkVbotU1onZOR, #=zXvwCnz8=);
		#=zXvwCnz8=.Append(':');
		NExcel.Biff.CellReferenceHelper.getCellReference(this.#=zh1vaBWFzORUr, this.#=znnJ2FmckCK2R, #=zXvwCnz8=);
	}

	// Token: 0x04000242 RID: 578
	private int #=zDec2DjUIpVoA;

	// Token: 0x04000243 RID: 579
	private int #=zkVbotU1onZOR;

	// Token: 0x04000244 RID: 580
	private int #=zh1vaBWFzORUr;

	// Token: 0x04000245 RID: 581
	private int #=znnJ2FmckCK2R;

	// Token: 0x04000246 RID: 582
	private bool #=z3EZeT1Eq9S9C;

	// Token: 0x04000247 RID: 583
	private bool #=zcCic2xXY931G;

	// Token: 0x04000248 RID: 584
	private bool #=z0ObI7fN0V9z1;

	// Token: 0x04000249 RID: 585
	private bool #=zDW3g0K7EfcSm;

	// Token: 0x0400024A RID: 586
	private Cell #=zq07FqDs=;
}
