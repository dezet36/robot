﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Interface.Information;
using Skink.SnR.Common.Units;

// Token: 0x02000197 RID: 407
internal sealed partial class #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR : Form
{
	// Token: 0x06000BB9 RID: 3001 RVA: 0x00058710 File Offset: 0x00056910
	public #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zIKomTz3YEM2Q)
	{
		this.#=zZx2UAHg= = false;
		this.#=zgpzgXirqPT5_();
		try
		{
			#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC();
			if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zoB_PPwnFbKCa())
			{
				for (int i = this.#=z074tbnUPlILR.TabPages.Count - 1; i > 0; i--)
				{
					this.#=z074tbnUPlILR.TabPages.RemoveAt(i);
				}
			}
			else
			{
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zOfJCiJK$ZVVkuth4jDES0lb35dZpcHbrSQ==())
				{
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031210));
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031197));
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031171));
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zQmMP6wt1RftoX0jGx5VWOLw=())
				{
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105101));
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031400));
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zKatp2kKFbWctd3l7feJusRE=())
				{
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031370));
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zK0Bl_aLmVIcfjen9YvGM2N2U4PVP7Hbgng==())
				{
					this.#=zetBl5gA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031347));
				}
			}
			this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.SelectedIndex = 1;
			#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
			this.#=z1AIzG94Rzno$51$e1A==.Items.Clear();
			this.#=z1AIzG94Rzno$51$e1A==.Items.Add(new #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG(0, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031334)), false, 4, #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=z28jSeKWn3BZi()));
			this.#=z1AIzG94Rzno$51$e1A==.SelectedIndex = 0;
			for (int j = 0; j < #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Count; j++)
			{
				this.#=z1AIzG94Rzno$51$e1A==.Items.Add(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==[j]);
			}
			this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndex = 2;
			this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndex = 2;
			this.#=zmDPs7p4mTcjFcawRjw==.SelectedIndex = 0;
			this.#=zCiVeqWIJriv1MyNqkw==.SelectedIndex = 0;
			this.#=z9aLgRmkb$ZtNM2KERA==.SelectedIndex = 0;
			this.#=zOH2Q5_Bwr9tCScY_nA==.Items.Clear();
			this.#=zOH2Q5_Bwr9tCScY_nA==.Items.Add(new #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==(0, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031316))));
			this.#=zOH2Q5_Bwr9tCScY_nA==.SelectedIndex = 0;
			if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zpCmQXZTzH4U2() || !#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zgS33aA7O0JjP5mZqsY2xXXg=())
			{
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zZNsIgSiN3rcd);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zeGmBBtRdzwQaDMyyzg==);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zFRKNWHxx__RQ8mqoeA==);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=z0jG8S8AqVomr);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zjleUOmzfvS7SPY6G2g==);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=z7SD$2jXVMnwApQc26A==);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zabHK6Uca$1UUcGW9hapqX4s=);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=znLGOdTN1PIm8);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zcvJaRrlyndEr);
				#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zHzCuLQPmytVw(this.#=zc_YfxSsyTlXw_bP01SgjrF0=);
			}
			if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zgPkXqnTbuiTDilNJGQ==())
			{
				this.#=zZNsIgSiN3rcd.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zeGmBBtRdzwQaDMyyzg==.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zFRKNWHxx__RQ8mqoeA==.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=z0jG8S8AqVomr.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zjleUOmzfvS7SPY6G2g==.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=z7SD$2jXVMnwApQc26A==.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zabHK6Uca$1UUcGW9hapqX4s=.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=znLGOdTN1PIm8.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zcvJaRrlyndEr.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
				this.#=zc_YfxSsyTlXw_bP01SgjrF0=.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
			}
			this.#=zshVEGQI= = #=z8S9_Kvw=;
			this.#=zGR3UNcM= = #=zIKomTz3YEM2Q;
			#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
			this.#=zMrEyt5sczn6Y();
			this.#=zZx2UAHg= = true;
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
			base.Close();
		}
	}

	// Token: 0x06000BBA RID: 3002 RVA: 0x00058A68 File Offset: 0x00056C68
	private static void #=zHzCuLQPmytVw(DataGridView #=zXaGKXo8=)
	{
		for (int i = 0; i < #=zXaGKXo8=.Columns.Count; i++)
		{
			if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zpCmQXZTzH4U2() && #=zXaGKXo8=.Columns[i].Name.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031032)))
			{
				#=zXaGKXo8=.Columns[i].Visible = false;
			}
			if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zgS33aA7O0JjP5mZqsY2xXXg=() && #=zXaGKXo8=.Columns[i].Name.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085715)))
			{
				#=zXaGKXo8=.Columns[i].Visible = false;
			}
		}
	}

	// Token: 0x06000BBB RID: 3003 RVA: 0x00058B14 File Offset: 0x00056D14
	public void #=zMrEyt5sczn6Y()
	{
		string name = this.#=z074tbnUPlILR.SelectedTab.Name;
		if (name != null)
		{
			switch (name.Length)
			{
			case 11:
				if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031197)))
				{
					return;
				}
				this.#=zRyNylgc7oiNYzrswmQ==();
				return;
			case 12:
				if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031347)))
				{
					return;
				}
				this.#=zVMWB3rm4Q2viWZj8A9et3QBUx59n();
				return;
			case 13:
				if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030982)))
				{
					return;
				}
				this.#=zOSKdvnszP1OMe8AHVQ==();
				return;
			case 14:
			case 17:
			case 19:
			case 20:
			case 21:
			case 22:
				break;
			case 15:
			{
				char c = name[0];
				if (c != 'g')
				{
					if (c != 'o')
					{
						return;
					}
					if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031029)))
					{
						return;
					}
					this.#=zkJvlJ7sggVmh();
					return;
				}
				else
				{
					if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105101)))
					{
						return;
					}
					this.#=z38A4mEihQDY7JVP$kzHgGmQ=();
					return;
				}
				break;
			}
			case 16:
			{
				char c = name[0];
				if (c != 'b')
				{
					if (c != 'r')
					{
						return;
					}
					if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031007)))
					{
						return;
					}
					this.#=zDas9r4cU9hf8();
					return;
				}
				else
				{
					if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031210)))
					{
						return;
					}
					this.#=zEumjekUyhndLqe8paaZJKa8=();
					return;
				}
				break;
			}
			case 18:
			{
				char c = name[2];
				if (c != 'c')
				{
					if (c != 'm')
					{
						if (c != 'v')
						{
							return;
						}
						if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025829)))
						{
							return;
						}
						this.#=zi62ZO36JCrR5();
					}
					else
					{
						if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031370)))
						{
							return;
						}
						this.#=z0ovTDV3$sfe8tb04rw==();
						return;
					}
				}
				else
				{
					if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031171)))
					{
						return;
					}
					this.#=zWTSSH5nWVxSb1Yw6Vw==();
					return;
				}
				break;
			}
			case 23:
				if (!(name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031400)))
				{
					return;
				}
				this.#=zsJYkkXT6k6hdv1KcJiki4yY=();
				return;
			default:
				return;
			}
		}
	}

	// Token: 0x06000BBC RID: 3004 RVA: 0x00058CF0 File Offset: 0x00056EF0
	private void #=zetBl5gA=(string #=z9K_wH7g=)
	{
		for (int i = this.#=z074tbnUPlILR.TabPages.Count - 1; i > 0; i--)
		{
			if (this.#=z074tbnUPlILR.TabPages[i].Name == #=z9K_wH7g=)
			{
				this.#=z074tbnUPlILR.TabPages.RemoveAt(i);
				return;
			}
		}
	}

	// Token: 0x06000BBD RID: 3005 RVA: 0x00058D4C File Offset: 0x00056F4C
	public void #=zkJvlJ7sggVmh()
	{
		if (this.#=zpYdc9wLbs4vzwsVEDQ==.Rows.Count > 0)
		{
			return;
		}
		string text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086054));
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
			{
				try
				{
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i)
					{
						if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue)
						{
							#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU();
							this.#=zpYdc9wLbs4vzwsVEDQ==.Rows.Add(new object[]
							{
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zvnZc$RhG_1Du(),
								string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070446), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==()),
								#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zNIn_Syjo_kgd().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030954)),
								#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zQL4EHGcDV4pf7jtVF80gtmE=(),
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zf5hgLnrBUoZV(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==),
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zY97bVazonjpwn3gNOQ==(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==, this.#=zGR3UNcM=)
							});
						}
						else
						{
							this.#=zpYdc9wLbs4vzwsVEDQ==.Rows.Add(new object[]
							{
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
								#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(),
								text,
								null,
								text,
								null,
								null,
								null,
								text
							});
						}
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
		}
	}

	// Token: 0x06000BBE RID: 3006 RVA: 0x00058F50 File Offset: 0x00057150
	public void #=zDas9r4cU9hf8()
	{
		if (this.#=zZNsIgSiN3rcd.Rows.Count > 0)
		{
			return;
		}
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
			{
				try
				{
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
					{
						#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=();
						this.#=zZNsIgSiN3rcd.Rows.Add(new object[]
						{
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zbOV22x0=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Lumber], #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zVgFk2IFQEXit()[ResourceTypes.Lumber]),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zbOV22x0=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Bronze], #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zVgFk2IFQEXit()[ResourceTypes.Bronze]),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zbOV22x0=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Grain], #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zVgFk2IFQEXit()[ResourceTypes.Grain]),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zS933gw03tLyr(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.FutureCurrency],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Glory],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Schemas],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.Gold],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.AllianceSilver],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=z_tcU3ov4mZ9V()[ResourceTypes.AllianceGold]
						});
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
		}
		this.#=zlh24mltNZqb7();
	}

	// Token: 0x06000BBF RID: 3007 RVA: 0x00059178 File Offset: 0x00057378
	public void #=zOSKdvnszP1OMe8AHVQ==()
	{
		if (this.#=zeGmBBtRdzwQaDMyyzg==.Rows.Count == 0)
		{
			this.#=z5bmBcMzlLJ5ozcpneQ==(false);
		}
	}

	// Token: 0x06000BC0 RID: 3008 RVA: 0x00059194 File Offset: 0x00057394
	private void #=z5bmBcMzlLJ5ozcpneQ==(bool #=zXJ7KFxF8weVu)
	{
		try
		{
			if (#=zXJ7KFxF8weVu)
			{
				this.#=zeGmBBtRdzwQaDMyyzg==.Rows.Clear();
			}
			for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
			{
				#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = null;
				foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
				{
					try
					{
						if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
						{
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zNhLzguI= = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=();
							this.#=zANiWB86IZuM0pdoh7g==(#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==), #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(), #=zNhLzguI=);
							if (#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== == null)
							{
								#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = new #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==();
							}
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zLikmsNA=(#=zNhLzguI=);
						}
					}
					catch (Exception #=zN_s5Z5A=)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
					}
				}
				if (#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== != null)
				{
					#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zNhLzguI=2 = #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==;
					string #=z6QPrZ_4= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030950));
					string #=zdkyd448= = GameApplicationData.#=zq64$9ho=(i);
					this.#=zANiWB86IZuM0pdoh7g==(null, #=z6QPrZ_4=, #=zdkyd448=, null, #=zNhLzguI=2);
				}
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
		}
	}

	// Token: 0x06000BC1 RID: 3009 RVA: 0x00059310 File Offset: 0x00057510
	private void #=zANiWB86IZuM0pdoh7g==(string #=zeNX3UtMqnoHk, string #=z6QPrZ_4=, string #=zdkyd448=, string #=z39WpvgDrY2U1QQIPUw==, #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zNhLzguI=)
	{
		this.#=zeGmBBtRdzwQaDMyyzg==.Rows.Add(new object[]
		{
			#=zeNX3UtMqnoHk,
			#=z6QPrZ_4=,
			#=zdkyd448=,
			#=z39WpvgDrY2U1QQIPUw==,
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Cavalry, UnitType.Functions.Offence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Phalanx, UnitType.Functions.Offence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.HeavyInfantry, UnitType.Functions.Offence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.LightInfantry, UnitType.Functions.Offence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Cavalry, UnitType.Functions.Defence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Phalanx, UnitType.Functions.Defence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.HeavyInfantry, UnitType.Functions.Defence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.LightInfantry, UnitType.Functions.Defence)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Cavalry, UnitType.Functions.OffenseAndDefense)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Phalanx, UnitType.Functions.OffenseAndDefense)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.HeavyInfantry, UnitType.Functions.OffenseAndDefense)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.LightInfantry, UnitType.Functions.OffenseAndDefense)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Cavalry, UnitType.Functions.Scouting)),
			this.#=zjcsPGpaWSatu4uzCrg==(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Rocket, UnitType.Functions.Offence))
		});
	}

	// Token: 0x06000BC2 RID: 3010 RVA: 0x000594D8 File Offset: 0x000576D8
	private #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=z7hJ6i1zzJqTTtc4VGQ== #=zjcsPGpaWSatu4uzCrg==(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=zxHIOVSaavkpE)
	{
		return new #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=z7hJ6i1zzJqTTtc4VGQ==(#=zxHIOVSaavkpE, this.#=zivg1eompdcozp3S8Zv303Kvr5P17.Checked);
	}

	// Token: 0x06000BC3 RID: 3011 RVA: 0x000594EC File Offset: 0x000576EC
	public void #=zEumjekUyhndLqe8paaZJKa8=()
	{
		try
		{
			if (this.#=zFRKNWHxx__RQ8mqoeA==.Rows.Count > 0)
			{
				return;
			}
			this.#=z1ngIMhSVPcYMncEZmQ== = new DataTable();
			this.#=z1ngIMhSVPcYMncEZmQ==.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030932));
			this.#=z1ngIMhSVPcYMncEZmQ==.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031160));
			this.#=z1ngIMhSVPcYMncEZmQ==.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031150));
			this.#=z1ngIMhSVPcYMncEZmQ==.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031122));
			#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
			this.#=zFRKNWHxx__RQ8mqoeA==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
			this.#=zFRKNWHxx__RQ8mqoeA==.ColumnHeadersHeight = 150;
			for (int i = 0; i < this.#=zFRKNWHxx__RQ8mqoeA==.Columns.Count; i++)
			{
				this.#=zFRKNWHxx__RQ8mqoeA==.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
			}
			for (int j = 0; j < #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.Count; j++)
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==[j];
				if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1 || #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4)
				{
					DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
					dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031108) + #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Id.ToString();
					dataGridViewTextBoxColumn.HeaderText = #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zNn0PpoXIcD55();
					dataGridViewTextBoxColumn.Width = 40;
					dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
					this.#=zFRKNWHxx__RQ8mqoeA==.Columns.Add(dataGridViewTextBoxColumn);
					this.#=z1ngIMhSVPcYMncEZmQ==.Columns.Add(dataGridViewTextBoxColumn.Name);
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
		}
		this.#=zlC8RWGDjedLMfQJN9W1EuPw=();
	}

	// Token: 0x06000BC4 RID: 3012 RVA: 0x000596CC File Offset: 0x000578CC
	private void #=zlC8RWGDjedLMfQJN9W1EuPw=()
	{
		try
		{
			if (this.#=z1ngIMhSVPcYMncEZmQ== != null)
			{
				this.#=z1ngIMhSVPcYMncEZmQ==.Rows.Clear();
				List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
				List<Dictionary<string, string>> list2 = new List<Dictionary<string, string>>();
				for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
				{
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						try
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
							{
								Dictionary<string, string> dictionary = new Dictionary<string, string>();
								foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zNnx4xxtx9xYwefJwdg==())
								{
									if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() != null && (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1 || #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4))
									{
										string key = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031108) + #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Id.ToString();
										string text = #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du().ToString();
										if (dictionary.ContainsKey(key))
										{
											text = dictionary[key] + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002) + text;
										}
										if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z5kpAZQpjT2b7() && !text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082)))
										{
											text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082) + text;
										}
										dictionary[key] = text;
									}
								}
								list.Add(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								list2.Add(dictionary);
							}
						}
						catch (Exception #=zN_s5Z5A=)
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						}
					}
				}
				for (int j = 0; j < list.Count; j++)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 = list[j];
					try
					{
						Dictionary<string, string> dictionary2 = list2[j];
						DataRow dataRow = this.#=z1ngIMhSVPcYMncEZmQ==.NewRow();
						this.#=z1ngIMhSVPcYMncEZmQ==.Rows.Add(dataRow);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030932)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031160)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031150)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zVTXNaO2wZJzQ();
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031122)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
						foreach (string text2 in dictionary2.Keys)
						{
							string text3 = dictionary2[text2];
							bool flag;
							if (text3.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082)))
							{
								flag = true;
								text3 = text3.Substring(1);
							}
							else
							{
								flag = false;
							}
							string text4;
							if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002)))
							{
								string[] array = text3.Split(new char[]
								{
									','
								});
								int num = 0;
								int num2 = 0;
								string[] array2 = array;
								for (int k = 0; k < array2.Length; k++)
								{
									int num3 = Convert.ToInt32(array2[k]);
									num += num3;
									if (num3 > num2)
									{
										num2 = num3;
									}
								}
								if (num == Convert.ToInt32(array[0]) * array.Length)
								{
									text4 = array[0];
								}
								else
								{
									int num4;
									if (this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.SelectedIndex == 0)
									{
										num4 = num2;
									}
									else
									{
										num4 = Convert.ToInt32(Math.Round((double)num / (double)array.Length));
									}
									text4 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051837) + num4.ToString();
								}
							}
							else
							{
								text4 = text3;
							}
							if (flag)
							{
								text4 += #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082);
							}
							dataRow[text2] = text4;
						}
					}
					catch (Exception #=zN_s5Z5A=2)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
					}
				}
				this.#=zFRKNWHxx__RQ8mqoeA==.DataSource = this.#=z1ngIMhSVPcYMncEZmQ==;
			}
		}
		catch (Exception #=zN_s5Z5A=3)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=3);
		}
	}

	// Token: 0x06000BC5 RID: 3013 RVA: 0x00059B7C File Offset: 0x00057D7C
	public void #=zRyNylgc7oiNYzrswmQ==()
	{
		try
		{
			if (this.#=z0jG8S8AqVomr.Rows.Count <= 0)
			{
				DataTable dataTable = new DataTable();
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031101));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031079));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031051));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030781));
				#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
				this.#=z0jG8S8AqVomr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
				this.#=z0jG8S8AqVomr.ColumnHeadersHeight = 200;
				for (int i = 0; i < this.#=z0jG8S8AqVomr.Columns.Count; i++)
				{
					this.#=z0jG8S8AqVomr.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
				}
				for (int j = 0; j < #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Count; j++)
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[j];
					if (!#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.IsHidden)
					{
						DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
						dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030757) + #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id.ToString();
						dataGridViewTextBoxColumn.HeaderText = #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name;
						dataGridViewTextBoxColumn.Width = 30;
						dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
						this.#=z0jG8S8AqVomr.Columns.Add(dataGridViewTextBoxColumn);
						dataTable.Columns.Add(dataGridViewTextBoxColumn.Name);
					}
				}
				for (int k = 1; k <= GameApplicationData.#=zMD9IS3VDVH4f(); k++)
				{
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						try
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == k && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
							{
								DataRow dataRow = dataTable.NewRow();
								dataTable.Rows.Add(dataRow);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031101)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031079)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031051)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ();
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030781)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
								foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== in #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zS96aE1JwlopY1ifRovTglSw=())
								{
									if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=() != null && !#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().IsHidden)
									{
										string columnName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030757) + #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().Id.ToString();
										string text = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du().ToString();
										if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7())
										{
											text += #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082);
										}
										dataRow[columnName] = text;
									}
								}
							}
						}
						catch (Exception #=zN_s5Z5A=)
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						}
					}
				}
				this.#=z0jG8S8AqVomr.DataSource = dataTable;
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
		}
	}

	// Token: 0x06000BC6 RID: 3014 RVA: 0x00059F4C File Offset: 0x0005814C
	public void #=zWTSSH5nWVxSb1Yw6Vw==()
	{
		try
		{
			#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
			if (this.#=zBNF4Yh3wT7O770UcmA==.Items.Count == 0)
			{
				this.#=zBNF4Yh3wT7O770UcmA==.Items.Add(new #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==
				{
					Id = 0,
					Name = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031334))
				});
				for (int i = 0; i < #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Count; i++)
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[i];
					if (!#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.IsHidden && #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=z6ZIr13K_h_d4() > 0 && !#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zsQC8qhbaqVU5q6hkHg==())
					{
						this.#=zBNF4Yh3wT7O770UcmA==.Items.Add(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
					}
				}
				this.#=zBNF4Yh3wT7O770UcmA==.Items.Add(new #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==
				{
					Id = -1,
					Name = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030738))
				});
				this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex = 0;
				this.#=zBNF4Yh3wT7O770UcmA==.FormatString = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264);
			}
			if (this.#=zY7eYiIm0C5XnEsSGag== != this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex)
			{
				DataTable dataTable = new DataTable();
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030715));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030700));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030675));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030660));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030895));
				this.#=zjleUOmzfvS7SPY6G2g==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
				if (this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex == 0)
				{
					this.#=zjleUOmzfvS7SPY6G2g==.ColumnHeadersHeight = 200;
				}
				else
				{
					this.#=zjleUOmzfvS7SPY6G2g==.ColumnHeadersHeight = 25;
				}
				for (int j = 0; j < dataTable.Columns.Count; j++)
				{
					this.#=zjleUOmzfvS7SPY6G2g==.Columns[j].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
				}
				int num = this.#=zjleUOmzfvS7SPY6G2g==.Columns.Count - 1;
				while (num > 0 && !this.#=zjleUOmzfvS7SPY6G2g==.Columns[num].Name.EndsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030867)))
				{
					this.#=zjleUOmzfvS7SPY6G2g==.Columns.RemoveAt(num);
					num--;
				}
				if (this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex == 0)
				{
					for (int k = 0; k < #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Count; k++)
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2 = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[k];
						if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.#=z6ZIr13K_h_d4() > 0 && !#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.#=zsQC8qhbaqVU5q6hkHg==())
						{
							DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
							dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030860) + #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Id.ToString();
							dataGridViewTextBoxColumn.HeaderText = #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name;
							dataGridViewTextBoxColumn.Width = 30;
							dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
							this.#=zjleUOmzfvS7SPY6G2g==.Columns.Add(dataGridViewTextBoxColumn);
							dataTable.Columns.Add(dataGridViewTextBoxColumn.Name);
						}
					}
				}
				else
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==3 = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==)this.#=zBNF4Yh3wT7O770UcmA==.SelectedItem;
					int num2;
					if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==3.Id == -1)
					{
						num2 = 5;
					}
					else
					{
						num2 = #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==3.#=z6ZIr13K_h_d4();
					}
					for (int l = 0; l < num2; l++)
					{
						DataGridViewTextBoxColumn dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
						dataGridViewTextBoxColumn2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030842) + l.ToString();
						dataGridViewTextBoxColumn2.HeaderText = (l + 1).ToString();
						dataGridViewTextBoxColumn2.Width = 30;
						dataGridViewTextBoxColumn2.DataPropertyName = dataGridViewTextBoxColumn2.Name;
						this.#=zjleUOmzfvS7SPY6G2g==.Columns.Add(dataGridViewTextBoxColumn2);
						dataTable.Columns.Add(dataGridViewTextBoxColumn2.Name);
					}
				}
				for (int m = 1; m <= GameApplicationData.#=zMD9IS3VDVH4f(); m++)
				{
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						try
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == m && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
							{
								DataRow dataRow = dataTable.NewRow();
								dataTable.Rows.Add(dataRow);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030715)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030700)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030675)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ();
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030660)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030895)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070446), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==());
								#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zS96aE1JwlopY1ifRovTglSw=();
								#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zTbkv095gWozyg_xVnw==();
								if (this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex == 0)
								{
									for (int n = 0; n < #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Count; n++)
									{
										if (#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[n].#=z6ZIr13K_h_d4() > 0 && !#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[n].#=zsQC8qhbaqVU5q6hkHg==() && !#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[n].IsHidden)
										{
											int id = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[n].Id;
											#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==.#=zk$6QZNA=(id);
											#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=.#=zk$6QZNA=(id);
											string columnName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030860) + id.ToString();
											string text = string.Empty;
											int num3 = 0;
											if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== != null)
											{
												foreach (int num4 in #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().Values)
												{
													num3 += num4;
												}
											}
											if (num3 > 0)
											{
												text = num3.ToString();
											}
											if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null)
											{
												text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030832) + text;
											}
											else if (text.Length > 0)
											{
												text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030825) + text;
											}
											if (text.Length > 0)
											{
												dataRow[columnName] = text;
											}
										}
									}
								}
								else
								{
									#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4 = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==)this.#=zBNF4Yh3wT7O770UcmA==.SelectedItem;
									#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2;
									#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3;
									if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4.Id == -1)
									{
										#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 = null;
										#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 = new #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==();
										#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=zzQwUIEs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4);
										#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=z9cbTL9Fte7ios6efTw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zc4t_BNE$BmXcFL6b6tKvb_sJsoUj());
										#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3 = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2;
									}
									else
									{
										#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 = #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==.#=zk$6QZNA=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4.Id);
										#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3 = #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=.#=zk$6QZNA=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4.Id);
									}
									for (int num5 = 0; num5 < #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==4.#=z6ZIr13K_h_d4(); num5++)
									{
										string columnName2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030842) + num5.ToString();
										string text2;
										if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3 != null && #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(num5))
										{
											text2 = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3.#=zo4gR$B4ZVFdYTDxEaw==()[num5].ToString();
											if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 != null)
											{
												text2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030832) + text2;
											}
											else
											{
												text2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030825) + text2;
											}
										}
										else if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 != null)
										{
											text2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030832);
										}
										else
										{
											text2 = string.Empty;
										}
										if (text2.Length > 0)
										{
											dataRow[columnName2] = text2;
										}
									}
								}
							}
						}
						catch (Exception #=zN_s5Z5A=)
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						}
					}
				}
				this.#=zjleUOmzfvS7SPY6G2g==.DataSource = dataTable;
				this.#=zY7eYiIm0C5XnEsSGag== = this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex;
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
		}
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x0005A784 File Offset: 0x00058984
	public void #=z38A4mEihQDY7JVP$kzHgGmQ=()
	{
		if (this.#=z7SD$2jXVMnwApQc26A==.Rows.Count > 0)
		{
			return;
		}
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
			{
				try
				{
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
					{
						#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=();
						this.#=z7SD$2jXVMnwApQc26A==.Rows.Add(new object[]
						{
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
							Enumerable.Sum(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[4],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[3],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[2],
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zsdEnlvQfBDeIOQc4bg==(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zIqugR6QOaNTtJEgBGqfk3xYb1PMe(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zz0nG8agAb6T9FBYEQpohzzc=(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zeCfnpts4KBpp$nmnTfjEMlsCFfxFuVoDIA==(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zN$_0ciN4j1M9Es9_zg==(),
							string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030822), #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zRjoD_ziLkooIuukNQn3Lf7c=(), #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zOTZUAC36s8y1ftdX7c1JuLQ=()),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zGWs2fahGtxAO3NnMGVZSK7g=(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zvlRkNe7UV2qeDYRtI8PSHhE=()
						});
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
		}
	}

	// Token: 0x06000BC8 RID: 3016 RVA: 0x0005A98C File Offset: 0x00058B8C
	public void #=zsJYkkXT6k6hdv1KcJiki4yY=()
	{
		if (this.#=zabHK6Uca$1UUcGW9hapqX4s=.Rows.Count > 0)
		{
			return;
		}
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
		for (int i = 0; i < this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns.Count; i++)
		{
			this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
		}
		this.#=zYrmGztSbKa7g5DTR1Qy4cT8=();
	}

	// Token: 0x06000BC9 RID: 3017 RVA: 0x0005AA00 File Offset: 0x00058C00
	public void #=zYrmGztSbKa7g5DTR1Qy4cT8=()
	{
		List<GeneralActionRule> list = new List<GeneralActionRule>();
		DataTable dataTable = new DataTable();
		dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030800));
		dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030521));
		dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030496));
		dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030473));
		for (int i = this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns.Count - 1; i >= dataTable.Columns.Count; i--)
		{
			this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns.RemoveAt(i);
		}
		this.#=zUEsmnEVA7MJn(list, dataTable.Columns);
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.AutoResizeColumnHeadersHeight();
		for (int j = 1; j <= GameApplicationData.#=zMD9IS3VDVH4f(); j++)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
			{
				try
				{
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == j && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
					{
						DataRow dataRow = dataTable.NewRow();
						dataTable.Rows.Add(dataRow);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030800)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030521)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030496)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ();
						dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030473)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
						for (int k = 0; k < list.Count; k++)
						{
							GeneralActionRule generalActionRule = list[k];
							#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T = null;
							int num = 0;
							for (int l = 0; l < #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zdz_5DLjhAG09Q78wOA==().Count; l++)
							{
								#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2 = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zdz_5DLjhAG09Q78wOA==()[l];
								if (generalActionRule.#=zQLl7KKs=(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2))
								{
									if (#=zo0xM9Yh84PPUvmstyPOlAl83hN9T == null)
									{
										#=zo0xM9Yh84PPUvmstyPOlAl83hN9T = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2;
									}
									else if (this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndex == 2 && #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zaKAy47_E$9SRuF6oiw==() > #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zaKAy47_E$9SRuF6oiw==())
									{
										#=zo0xM9Yh84PPUvmstyPOlAl83hN9T = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2;
									}
									else if (this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndex == 2 && #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=ztj93y6niVpCR() > #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=ztj93y6niVpCR())
									{
										#=zo0xM9Yh84PPUvmstyPOlAl83hN9T = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2;
									}
									else if (this.#=zmDPs7p4mTcjFcawRjw==.SelectedIndex == 1 && #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zjw43QGFcPyHH() > #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zjw43QGFcPyHH())
									{
										#=zo0xM9Yh84PPUvmstyPOlAl83hN9T = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2;
									}
									num++;
								}
							}
							if (#=zo0xM9Yh84PPUvmstyPOlAl83hN9T != null)
							{
								string columnName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030452) + k.ToString();
								StringBuilder stringBuilder = new StringBuilder();
								if (this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndex == 2)
								{
									stringBuilder.Append(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zaKAy47_E$9SRuF6oiw==());
								}
								if (this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndex == 2)
								{
									if (stringBuilder.Length > 0)
									{
										stringBuilder.Append('/');
									}
									stringBuilder.Append(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=ztj93y6niVpCR());
								}
								if (this.#=zmDPs7p4mTcjFcawRjw==.SelectedIndex == 1)
								{
									if (stringBuilder.Length > 0)
									{
										stringBuilder.Append('/');
									}
									string text = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zjw43QGFcPyHH().ToString();
									text = text.Insert(text.Length - 2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067993));
									stringBuilder.Append(text);
								}
								if (this.#=zCiVeqWIJriv1MyNqkw==.SelectedIndex == 1)
								{
									if (stringBuilder.Length > 0)
									{
										stringBuilder.Append(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zNTEClmggtyu4());
									}
									else
									{
										stringBuilder.Append(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zPEhDdtHVGNHR());
									}
								}
								if (this.#=z9aLgRmkb$ZtNM2KERA==.SelectedIndex == 1)
								{
									if (stringBuilder.Length > 0)
									{
										stringBuilder.Append('/');
									}
									stringBuilder.Append(num);
								}
								if (stringBuilder.Length == 0)
								{
									stringBuilder.Append('v');
								}
								dataRow[columnName] = stringBuilder.ToString();
							}
						}
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
		}
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.DataSource = dataTable;
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x0005AE3C File Offset: 0x0005903C
	private void #=zUEsmnEVA7MJn(List<GeneralActionRule> #=zSkJqOoLvmsE7, DataColumnCollection #=zUAWTo_Q=)
	{
		if (this.#=z1AIzG94Rzno$51$e1A==.SelectedIndex == 0)
		{
			#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
			for (int i = 0; i < #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Count; i++)
			{
				this.#=zt6zXk0WbehFwTi$5ZA==(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==[i]);
			}
			return;
		}
		int id = (this.#=z1AIzG94Rzno$51$e1A==.SelectedItem as #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG).Id;
		#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=().#=zk$6QZNA=(id);
		if (#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG == null)
		{
			throw new Exception(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030434), new object[]
			{
				id
			}).ToString());
		}
		this.#=zt6zXk0WbehFwTi$5ZA==(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG);
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x0005AED4 File Offset: 0x000590D4
	private void #=zt6zXk0WbehFwTi$5ZA==(List<GeneralActionRule> #=zSkJqOoLvmsE7, DataColumnCollection #=zUAWTo_Q=, #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zvRLj9WQ=)
	{
		if (this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndex == 1)
		{
			for (int i = 5; i >= 1; i--)
			{
				this.#=z_87W6UqwOtZ4(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, i);
			}
			return;
		}
		if (this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndex == 3)
		{
			this.#=z_87W6UqwOtZ4(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, 5);
			return;
		}
		this.#=z_87W6UqwOtZ4(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, 0);
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x0005AF2C File Offset: 0x0005912C
	private void #=z_87W6UqwOtZ4(List<GeneralActionRule> #=zSkJqOoLvmsE7, DataColumnCollection #=zUAWTo_Q=, #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zvRLj9WQ=, int #=zUTW72M70Fvrc)
	{
		if (this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndex == 1)
		{
			for (int i = #=zvRLj9WQ=.#=zBhjHkv0$tplT().#=z$SLcm8wly5I$(); i >= 1; i--)
			{
				this.#=z6rFXsOIKF5tn(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, #=zUTW72M70Fvrc, i);
			}
			return;
		}
		if (this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndex == 3)
		{
			this.#=z6rFXsOIKF5tn(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, #=zUTW72M70Fvrc, #=zvRLj9WQ=.#=zBhjHkv0$tplT().#=z$SLcm8wly5I$());
			return;
		}
		this.#=z6rFXsOIKF5tn(#=zSkJqOoLvmsE7, #=zUAWTo_Q=, #=zvRLj9WQ=, #=zUTW72M70Fvrc, 0);
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x0005AF9C File Offset: 0x0005919C
	private void #=z6rFXsOIKF5tn(List<GeneralActionRule> #=zSkJqOoLvmsE7, DataColumnCollection #=zUAWTo_Q=, #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zvRLj9WQ=, int #=zUTW72M70Fvrc, int #=z0i3iSog=)
	{
		#=zSkJqOoLvmsE7.Add(new GeneralActionRule
		{
			GenTypes = new List<int>
			{
				#=zvRLj9WQ=.Id
			},
			RarityFrom = #=zUTW72M70Fvrc,
			RarityTo = #=zUTW72M70Fvrc,
			RankFrom = #=z0i3iSog=,
			RankTo = #=z0i3iSog=
		});
		StringBuilder stringBuilder = new StringBuilder(#=zvRLj9WQ=.Name);
		if (#=zUTW72M70Fvrc > 0)
		{
			stringBuilder.Append(' ');
			stringBuilder.Append(#=zUTW72M70Fvrc);
			if (#=z0i3iSog= > 0)
			{
				stringBuilder.Append('/');
				stringBuilder.Append(#=z0i3iSog=);
			}
		}
		else if (#=z0i3iSog= > 0)
		{
			stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030407));
			stringBuilder.Append(#=z0i3iSog=);
		}
		DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
		dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030452) + (#=zSkJqOoLvmsE7.Count - 1).ToString();
		dataGridViewTextBoxColumn.HeaderText = stringBuilder.ToString();
		dataGridViewTextBoxColumn.Width = 100;
		dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns.Add(dataGridViewTextBoxColumn);
		#=zUAWTo_Q=.Add(dataGridViewTextBoxColumn.Name);
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x0005B0B4 File Offset: 0x000592B4
	public void #=z0ovTDV3$sfe8tb04rw==()
	{
		try
		{
			if (this.#=znLGOdTN1PIm8.Rows.Count <= 0)
			{
				DataTable dataTable = new DataTable();
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030653));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030619));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030595));
				dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030569));
				#=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.#=zi1hFJwI=();
				this.#=znLGOdTN1PIm8.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
				for (int i = 0; i < dataTable.Columns.Count; i++)
				{
					this.#=znLGOdTN1PIm8.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
				}
				for (int j = 0; j < #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.Count; j++)
				{
					#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U[j];
					DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
					dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030549) + #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zMuFMjGQ=().ToString();
					dataGridViewTextBoxColumn.HeaderText = #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zkfqcY3I=();
					dataGridViewTextBoxColumn.Width = 100;
					dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
					this.#=znLGOdTN1PIm8.Columns.Add(dataGridViewTextBoxColumn);
					dataTable.Columns.Add(dataGridViewTextBoxColumn.Name);
				}
				this.#=znLGOdTN1PIm8.AutoResizeColumnHeadersHeight();
				for (int k = 1; k <= GameApplicationData.#=zMD9IS3VDVH4f(); k++)
				{
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						try
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == k && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
							{
								DataRow dataRow = dataTable.NewRow();
								dataTable.Rows.Add(dataRow);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030653)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030619)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030595)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ();
								dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030569)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
								for (int l = 0; l < #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.Count; l++)
								{
									#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zojkgZZIGc9OEdN9KMb5Uryw= #=zojkgZZIGc9OEdN9KMb5Uryw= = new #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zojkgZZIGc9OEdN9KMb5Uryw=();
									#=zojkgZZIGc9OEdN9KMb5Uryw=.#=zTVuos6ESv9WY = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U[l];
									#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zqOzsq_ebYcIC().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zojkgZZIGc9OEdN9KMb5Uryw=.#=zymSLvx2HQlIqX_vXDVS5iuA=));
									if (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== != null)
									{
										TimeSpan t = #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=z71_rggORFKZ5() - DateTime.Now;
										if (t > TimeSpan.Zero)
										{
											string columnName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030549) + #=zojkgZZIGc9OEdN9KMb5Uryw=.#=zTVuos6ESv9WY.#=zMuFMjGQ=().ToString();
											string value = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030531), (int)t.TotalHours, t.Minutes);
											dataRow[columnName] = value;
										}
									}
								}
							}
						}
						catch (Exception #=zN_s5Z5A=)
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						}
					}
				}
				this.#=znLGOdTN1PIm8.DataSource = dataTable;
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
		}
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x0005B47C File Offset: 0x0005967C
	public void #=zVMWB3rm4Q2viWZj8A9et3QBUx59n()
	{
		if (this.#=zcvJaRrlyndEr.Rows.Count > 0)
		{
			return;
		}
		this.#=zcvJaRrlyndEr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
		this.#=zcvJaRrlyndEr.ColumnHeadersHeight = 200;
		for (int i = 0; i < this.#=zcvJaRrlyndEr.Columns.Count; i++)
		{
			this.#=zcvJaRrlyndEr.Columns[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.BottomCenter;
		}
		this.#=zarIb2gmUor4u2tqCzMuTaSMVmbHo();
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x0005B500 File Offset: 0x00059700
	public void #=zarIb2gmUor4u2tqCzMuTaSMVmbHo()
	{
		try
		{
			DataTable dataTable = new DataTable();
			dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032304));
			dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032293));
			dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032264));
			dataTable.Columns.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032253));
			for (int i = this.#=zcvJaRrlyndEr.Columns.Count - 1; i > dataTable.Columns.Count - 1; i--)
			{
				this.#=zcvJaRrlyndEr.Columns.RemoveAt(i);
			}
			Dictionary<int, #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==> dictionary = new Dictionary<int, #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==>();
			for (int j = 1; j <= GameApplicationData.#=zMD9IS3VDVH4f(); j++)
			{
				int id = (this.#=zOH2Q5_Bwr9tCScY_nA==.SelectedItem as #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==).Id;
				if (id <= 0 || id == j)
				{
					#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== = null;
					Dictionary<int, int> dictionary2 = new Dictionary<int, int>();
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						try
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == j && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
							{
								#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=();
								if (#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== == null)
								{
									#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== = new #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==();
								}
								#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==.#=zLikmsNA=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zG95DTZntR2nRriTBdb76SEs=());
								if (!this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Checked)
								{
									foreach (int key in #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zG95DTZntR2nRriTBdb76SEs=().Keys)
									{
										if (dictionary2.ContainsKey(key))
										{
											dictionary2[key]++;
										}
										else
										{
											dictionary2[key] = 1;
										}
									}
								}
							}
						}
						catch (Exception #=zN_s5Z5A=)
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						}
					}
					if (#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== != null)
					{
						if (!this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Checked)
						{
							foreach (int key2 in dictionary2.Keys)
							{
								if (dictionary2[key2] <= 1)
								{
									#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==.Remove(key2);
								}
							}
						}
						dictionary[j] = #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==;
						List<#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==> list = new List<#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==>();
						foreach (#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== item in #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==.Values)
						{
							list.Add(item);
						}
						list.Sort(new Comparison<#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==>(#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zyDNvciU=.#=zLkw0NRU=.#=zkqK33Qp06VC$ZKGvpN1C1zePlxaJ7u9qLDQbxvl$WWQz));
						for (int k = 0; k < list.Count; k++)
						{
							#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== = list[k];
							DataGridViewTextBoxColumn dataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
							dataGridViewTextBoxColumn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032228) + #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_().ToString().Replace('-', '_');
							dataGridViewTextBoxColumn.HeaderText = #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zuFPZLKs=().#=zkfqcY3I=();
							dataGridViewTextBoxColumn.Width = 60;
							dataGridViewTextBoxColumn.DataPropertyName = dataGridViewTextBoxColumn.Name;
							this.#=zcvJaRrlyndEr.Columns.Add(dataGridViewTextBoxColumn);
							dataTable.Columns.Add(dataGridViewTextBoxColumn.Name);
						}
					}
				}
			}
			bool flag = this.#=zOH2Q5_Bwr9tCScY_nA==.Items.Count == 1;
			for (int l = 1; l <= GameApplicationData.#=zMD9IS3VDVH4f(); l++)
			{
				if (dictionary.ContainsKey(l))
				{
					#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==2 = dictionary[l];
					string text = null;
					foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in this.#=zshVEGQI=.#=zol80P7TKoihZ())
					{
						if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zYgvZuBwR$a1C() == l && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zDZReNK0=() != null)
						{
							DataRow dataRow = dataTable.NewRow();
							dataTable.Rows.Add(dataRow);
							dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032304)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
							dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032293)] = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
							dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032264)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zVTXNaO2wZJzQ();
							dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032253)] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==();
							foreach (#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2 in #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zDZReNK0=().#=zG95DTZntR2nRriTBdb76SEs=().Values)
							{
								if (#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==2.ContainsKey(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2.#=zK5gF1KeGk_H_()))
								{
									dataRow[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032228) + #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2.#=zK5gF1KeGk_H_().ToString().Replace('-', '_')] = #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2.#=zlIXJ9$NfUZc_();
								}
							}
							if (text == null)
							{
								text = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zVTXNaO2wZJzQ();
							}
						}
					}
					DataRow dataRow2 = dataTable.NewRow();
					dataTable.Rows.Add(dataRow2);
					dataRow2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032293)] = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030950));
					dataRow2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032264)] = text;
					dataRow2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032253)] = null;
					foreach (#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==3 in #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==2.Values)
					{
						dataRow2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032228) + #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==3.#=zK5gF1KeGk_H_().ToString().Replace('-', '_')] = #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==3.#=zlIXJ9$NfUZc_();
					}
					if (flag)
					{
						this.#=zOH2Q5_Bwr9tCScY_nA==.Items.Add(new #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==(l, text));
					}
				}
			}
			this.#=zcvJaRrlyndEr.DataSource = dataTable;
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
		}
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x0005BC24 File Offset: 0x00059E24
	public void #=zi62ZO36JCrR5()
	{
		if (this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Rows.Count > 0)
		{
			return;
		}
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
			{
				try
				{
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == i && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zNIn_Syjo_kgd() > DateTime.MinValue && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
					{
						#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=();
						this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Rows.Add(new object[]
						{
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==(),
							#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zyiOd40BScdn01uJKRA==(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zHVllBBIHynsrMuvepQ==(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=zGh87EDc1C$LIh14MJDCD1Pw=(),
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=znUIObFoF49PcXO7XFHzcPag=(),
							#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zjyePyJA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU())
						});
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
		}
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x0005BD90 File Offset: 0x00059F90
	private static string #=zGt43OB_aiux4(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zh5Q$jgycqA15().#=z2ZE0cltcIoE3IY7EAQ==().ToString();
	}

	// Token: 0x06000BD3 RID: 3027 RVA: 0x0005BDB0 File Offset: 0x00059FB0
	private static string #=zqhvZunA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zh5Q$jgycqA15().#=zSByqmFV12x0z();
	}

	// Token: 0x06000BD4 RID: 3028 RVA: 0x0005BDC0 File Offset: 0x00059FC0
	private static string #=zbOV22x0=(int #=zNvCMwussKumm, int #=zbed85kI6rCEd)
	{
		if (#=zbed85kI6rCEd > 1000)
		{
			return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032221), #=zNvCMwussKumm, #=zbed85kI6rCEd / 1000);
		}
		return #=zNvCMwussKumm.ToString();
	}

	// Token: 0x06000BD5 RID: 3029 RVA: 0x0005BDF4 File Offset: 0x00059FF4
	private static string #=zY97bVazonjpwn3gNOQ==(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zNhLzguI=, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM=)
	{
		string result;
		try
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031));
			if (#=zNhLzguI=.#=z4sXt66V1ZksHjpTHIZIhgos=() != null && #=zNhLzguI=.#=z4sXt66V1ZksHjpTHIZIhgos=().Count > 0)
			{
				#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== #=zcvzmwA_SR1dxtNktUQ== = #=zNhLzguI=.#=z4sXt66V1ZksHjpTHIZIhgos=()[0];
				switch (#=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR())
				{
				case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)0:
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032195), new object[]
					{
						#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==()
					});
					break;
				case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)1:
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032432), new object[]
					{
						#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==()
					});
					break;
				case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2:
					if ((DateTime.Now - #=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==()).TotalMinutes <= (double)#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zWX$wxDSpl8I34r377OFpICFEu4zI)
					{
						#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032400), new object[]
						{
							#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==()
						});
					}
					break;
				}
				if (#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zKh04cf8=() > 0)
				{
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070458), new object[]
					{
						#=zcvzmwA_SR1dxtNktUQ==.#=zuq_UHDkYFBLsH2rvOw==().#=zkfqcY3I=(),
						#=zcvzmwA_SR1dxtNktUQ==.#=zuq_UHDkYFBLsH2rvOw==().#=zfTB62qendhk_VEy8rw==(),
						#=zcvzmwA_SR1dxtNktUQ==.#=zuq_UHDkYFBLsH2rvOw==().#=zY0soxphmGIACbOHy6A==()
					});
					if (!string.IsNullOrEmpty(#=zcvzmwA_SR1dxtNktUQ==.#=zuq_UHDkYFBLsH2rvOw==().#=zj661vGqZTMsoJ4JrPg==()))
					{
						#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=zcvzmwA_SR1dxtNktUQ==.#=zuq_UHDkYFBLsH2rvOw==().#=zj661vGqZTMsoJ4JrPg==(), Array.Empty<object>());
					}
				}
			}
			result = #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString();
		}
		catch (Exception #=zN_s5Z5A=)
		{
			result = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
		}
		return result;
	}

	// Token: 0x06000BD6 RID: 3030 RVA: 0x0005BF94 File Offset: 0x0005A194
	private static string #=zjyePyJA=(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zNhLzguI=)
	{
		if (#=zNhLzguI=.#=zbMJWMku61G$Q()[2] > 0)
		{
			return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030822), #=zNhLzguI=.#=zbMJWMku61G$Q()[0], #=zNhLzguI=.#=zbMJWMku61G$Q()[2]);
		}
		return #=zNhLzguI=.#=zbMJWMku61G$Q()[0].ToString();
	}

	// Token: 0x06000BD7 RID: 3031 RVA: 0x0005BFE8 File Offset: 0x0005A1E8
	private static string #=zf5hgLnrBUoZV(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zNhLzguI=)
	{
		if (#=zNhLzguI=.#=zbMJWMku61G$Q()[0] == #=zNhLzguI=.#=zbMJWMku61G$Q()[1])
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871);
		}
		if (#=zNhLzguI=.#=zbMJWMku61G$Q()[2] > 0)
		{
			return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030822), #=zNhLzguI=.#=zbMJWMku61G$Q()[0] - #=zNhLzguI=.#=zbMJWMku61G$Q()[1], #=zNhLzguI=.#=zbMJWMku61G$Q()[2] - #=zNhLzguI=.#=zbMJWMku61G$Q()[3]);
		}
		return (#=zNhLzguI=.#=zbMJWMku61G$Q()[0] - #=zNhLzguI=.#=zbMJWMku61G$Q()[1]).ToString();
	}

	// Token: 0x06000BD8 RID: 3032 RVA: 0x0005C074 File Offset: 0x0005A274
	private void #=zeQEwSK$9jLimx4mYRA==(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=zZNsIgSiN3rcd, #=z4Q$h3mE=.RowIndex);
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
		{
			return;
		}
		ResourceTypes resourceTypes;
		switch (#=z4Q$h3mE=.ColumnIndex)
		{
		case 3:
			resourceTypes = ResourceTypes.Lumber;
			break;
		case 4:
			resourceTypes = ResourceTypes.Bronze;
			break;
		case 5:
			resourceTypes = ResourceTypes.Grain;
			break;
		default:
			return;
		}
		if (this.#=zIS1JRBk= == null)
		{
			this.#=zIS1JRBk= = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==;
			this.#=zUBu0jHej6Kyf = resourceTypes;
		}
		else
		{
			this.#=zcR$4j7Y= = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==;
			this.#=zjTxEhgo$UtS0 = resourceTypes;
		}
		this.#=zlh24mltNZqb7();
	}

	// Token: 0x06000BD9 RID: 3033 RVA: 0x0005C0EC File Offset: 0x0005A2EC
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zy12SXA0=(DataGridView #=zXaGKXo8=, int #=zfuEy5kM=)
	{
		if (#=zfuEy5kM= < 0 || #=zfuEy5kM= >= #=zXaGKXo8=.Rows.Count)
		{
			return null;
		}
		object value = #=zXaGKXo8=.Rows[#=zfuEy5kM=].Cells[0].Value;
		if (value == null || value == DBNull.Value)
		{
			return null;
		}
		int num = Convert.ToInt32(value) - 1;
		string b = Convert.ToString(#=zXaGKXo8=.Rows[#=zfuEy5kM=].Cells[2].Value);
		int num2 = 0;
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			if (GameApplicationData.#=zq64$9ho=(i) == b)
			{
				num2 = i;
				break;
			}
		}
		if (num2 == 0)
		{
			return null;
		}
		for (int j = 0; j < this.#=zshVEGQI=.#=zol80P7TKoihZ().Count; j++)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[j];
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU() == num && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == num2)
			{
				return #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==;
			}
		}
		return null;
	}

	// Token: 0x06000BDA RID: 3034 RVA: 0x0005C1DC File Offset: 0x0005A3DC
	private void #=zlh24mltNZqb7()
	{
		this.#=zyG48KQl_i7vDV3BlrQ==.Text = ((this.#=zIS1JRBk= != null) ? this.#=zIS1JRBk=.#=zdEt_WRHpdEMmGTK_3Q==() : string.Empty);
		this.#=zre8RMFZgteCGIV_PKw==.Text = ((this.#=zUBu0jHej6Kyf > ResourceTypes.Unknown) ? this.#=zUBu0jHej6Kyf.ToString() : string.Empty);
		this.#=zxsXrETI$Iw8TbR37eA==.Text = ((this.#=zcR$4j7Y= != null) ? this.#=zcR$4j7Y=.#=zdEt_WRHpdEMmGTK_3Q==() : string.Empty);
		this.#=zpR0Be317xdaMSSA7Iw==.Text = ((this.#=zjTxEhgo$UtS0 > ResourceTypes.Unknown) ? this.#=zjTxEhgo$UtS0.ToString() : string.Empty);
	}

	// Token: 0x06000BDB RID: 3035 RVA: 0x0005C28C File Offset: 0x0005A48C
	private void #=zHZkZ0H81F_ZXV_$kZw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zUBu0jHej6Kyf == ResourceTypes.Unknown || this.#=zjTxEhgo$UtS0 == ResourceTypes.Unknown)
		{
			return;
		}
		int #=zNvCMwussKumm;
		int.TryParse(this.#=z1WgtJYpDe9uYCCReRg==.Text, out #=zNvCMwussKumm);
		int #=zNvCMwussKumm2;
		int.TryParse(this.#=z5DnnYSvFhFxafulviw==.Text, out #=zNvCMwussKumm2);
		#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== = #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zthvkIF8wHpgs(this.#=zIS1JRBk=, new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(this.#=zUBu0jHej6Kyf, #=zNvCMwussKumm), this.#=zcR$4j7Y=, new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(this.#=zjTxEhgo$UtS0, #=zNvCMwussKumm2));
		if (#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== != null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
			return;
		}
		this.#=zIS1JRBk= = null;
		this.#=zUBu0jHej6Kyf = ResourceTypes.Unknown;
		this.#=zcR$4j7Y= = null;
		this.#=zjTxEhgo$UtS0 = ResourceTypes.Unknown;
		this.#=zlh24mltNZqb7();
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032380));
	}

	// Token: 0x06000BDC RID: 3036 RVA: 0x0005C338 File Offset: 0x0005A538
	private static #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zthvkIF8wHpgs(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zIS1JRBk=, #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zmiJUXno=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zcR$4j7Y=, #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zuHvtP38=)
	{
		if (#=zIS1JRBk=.#=zYgvZuBwR$a1C() != #=zcR$4j7Y=.#=zYgvZuBwR$a1C())
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032340), Array.Empty<object>());
		}
		if (#=zmiJUXno=.#=zq2bPTdY=() == #=zuHvtP38=.#=zq2bPTdY=())
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031981), Array.Empty<object>());
		}
		if (#=zmiJUXno=.#=zlIXJ9$NfUZc_() <= 0 || #=zuHvtP38=.#=zlIXJ9$NfUZc_() <= 0)
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909011221), Array.Empty<object>());
		}
		if (#=zmiJUXno=.#=zlIXJ9$NfUZc_() > #=zuHvtP38=.#=zlIXJ9$NfUZc_() * 2 || #=zuHvtP38=.#=zlIXJ9$NfUZc_() > #=zmiJUXno=.#=zlIXJ9$NfUZc_() * 2)
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032171), Array.Empty<object>());
		}
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(null, true, #=zIS1JRBk=), #=zIS1JRBk=, null, null);
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zFgabd6AP3NvQ(false);
		List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> list = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zC6pCNPvHlvvsjFd3wuxtDlE=();
		List<int> list2 = new List<int>();
		if (list != null)
		{
			foreach (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= in list)
			{
				list2.Add(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=zMuFMjGQ=());
			}
		}
		string text = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z$2ijYGRf0FB5().#=zJsknLhumcn07(#=zmiJUXno=, #=zuHvtP38=);
		text = text.Trim();
		if (text.Length < 1000)
		{
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032151)))
			{
				return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032125), new object[]
				{
					#=zIS1JRBk=.#=zdEt_WRHpdEMmGTK_3Q==()
				});
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032084)))
			{
				return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031795), new object[]
				{
					#=zIS1JRBk=.#=zdEt_WRHpdEMmGTK_3Q==()
				});
			}
		}
		#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2 = null;
		List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> list3 = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zC6pCNPvHlvvsjFd3wuxtDlE=();
		if (list3 != null)
		{
			foreach (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=3 in list3)
			{
				if (!list2.Contains(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=3.#=zMuFMjGQ=()))
				{
					#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2 = #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=3;
					break;
				}
			}
		}
		if (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2 == null)
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031755), new object[]
			{
				#=zIS1JRBk=.#=zdEt_WRHpdEMmGTK_3Q==(),
				(text.Length > 100) ? text.Substring(0, 100) : text
			});
		}
		text = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zcR$4j7Y=).#=ze1SOcCGAlsijvaxxkw==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2);
		text = text.Trim();
		if (text.Length < 1000)
		{
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032151)))
			{
				#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z$2ijYGRf0FB5().#=ztNr$6f$4jFpqECtQlA==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zMuFMjGQ=());
				return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031716), new object[]
				{
					#=zcR$4j7Y=.#=zdEt_WRHpdEMmGTK_3Q==()
				});
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032084)))
			{
				#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z$2ijYGRf0FB5().#=ztNr$6f$4jFpqECtQlA==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zMuFMjGQ=());
				return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031795), new object[]
				{
					#=zcR$4j7Y=.#=zdEt_WRHpdEMmGTK_3Q==()
				});
			}
		}
		using (List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=>.Enumerator enumerator = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zC6pCNPvHlvvsjFd3wuxtDlE=().GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.#=zMuFMjGQ=() == #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zMuFMjGQ=())
				{
					#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z$2ijYGRf0FB5().#=ztNr$6f$4jFpqECtQlA==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zMuFMjGQ=());
					return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031929), new object[]
					{
						#=zcR$4j7Y=.#=zdEt_WRHpdEMmGTK_3Q==(),
						(text.Length > 100) ? text.Substring(0, 100) : text
					});
				}
			}
		}
		return null;
	}

	// Token: 0x06000BDD RID: 3037 RVA: 0x0005C6B8 File Offset: 0x0005A8B8
	private void #=zdM5EOW3bT9Spb1GAAg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zIS1JRBk= = null;
		this.#=zUBu0jHej6Kyf = ResourceTypes.Unknown;
		this.#=zcR$4j7Y= = null;
		this.#=zjTxEhgo$UtS0 = ResourceTypes.Unknown;
		this.#=zlh24mltNZqb7();
	}

	// Token: 0x06000BDE RID: 3038 RVA: 0x0005C6DC File Offset: 0x0005A8DC
	private void #=zHqRo_0Ga3kxH3hv2OOMlYRk=(object #=zP95I7AY=, DataGridViewCellPaintingEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.RowIndex == -1 && #=z4Q$h3mE=.ColumnIndex > 3)
		{
			if (#=z4Q$h3mE=.ColumnIndex <= 5 && (#=zP95I7AY= as DataGridView).Columns[#=z4Q$h3mE=.ColumnIndex].Name.EndsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030867)))
			{
				return;
			}
			string text = Convert.ToString(#=z4Q$h3mE=.FormattedValue);
			if (text != null && text.Length > 3)
			{
				#=z4Q$h3mE=.PaintBackground(#=z4Q$h3mE=.CellBounds, true);
				#=z4Q$h3mE=.Graphics.TranslateTransform((float)#=z4Q$h3mE=.CellBounds.Left, (float)#=z4Q$h3mE=.CellBounds.Bottom);
				#=z4Q$h3mE=.Graphics.RotateTransform(270f);
				#=z4Q$h3mE=.Graphics.DrawString(text, #=z4Q$h3mE=.CellStyle.Font, Brushes.Black, 5f, 5f);
				#=z4Q$h3mE=.Graphics.ResetTransform();
				#=z4Q$h3mE=.Handled = true;
				return;
			}
		}
		else if (Convert.ToString(#=z4Q$h3mE=.FormattedValue).StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031883)) && #=z4Q$h3mE=.RowIndex >= 0)
		{
			(#=zP95I7AY= as DataGridView).Rows[#=z4Q$h3mE=.RowIndex].Cells[#=z4Q$h3mE=.ColumnIndex].Style.BackColor = Color.Red;
		}
	}

	// Token: 0x06000BDF RID: 3039 RVA: 0x0005C830 File Offset: 0x0005AA30
	private void #=z$XQ3SN52orxvu8e_mIf8JKg=(object #=zP95I7AY=, DataGridViewCellFormattingEventArgs #=z4Q$h3mE=)
	{
		string text = #=z4Q$h3mE=.Value.ToString();
		if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031883)))
		{
			char c = text[1];
			if (c != 'g')
			{
				if (c == 'o')
				{
					(#=zP95I7AY= as DataGridView).Rows[#=z4Q$h3mE=.RowIndex].Cells[#=z4Q$h3mE=.ColumnIndex].Style.BackColor = Color.Orange;
				}
			}
			else
			{
				(#=zP95I7AY= as DataGridView).Rows[#=z4Q$h3mE=.RowIndex].Cells[#=z4Q$h3mE=.ColumnIndex].Style.BackColor = Color.LightGreen;
			}
			#=z4Q$h3mE=.Value = text.Substring(2);
		}
	}

	// Token: 0x06000BE0 RID: 3040 RVA: 0x0005C8EC File Offset: 0x0005AAEC
	private void #=z3yqY2w4c5ddZ$RXcwAIDlQI=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex <= 2)
		{
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=zjleUOmzfvS7SPY6G2g==, #=z4Q$h3mE=.RowIndex);
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031875));
			return;
		}
		int num = -1;
		int num2;
		if (this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndex == 0)
		{
			num2 = Convert.ToInt32(this.#=zjleUOmzfvS7SPY6G2g==.Columns[#=z4Q$h3mE=.ColumnIndex].Name.Substring(3));
		}
		else
		{
			num2 = ((#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==)this.#=zBNF4Yh3wT7O770UcmA==.SelectedItem).Id;
			num = Convert.ToInt32(this.#=zjleUOmzfvS7SPY6G2g==.Columns[#=z4Q$h3mE=.ColumnIndex].Name.Substring(3));
		}
		#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = null;
		if (num2 == -1)
		{
			#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 = new #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==();
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = new #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==();
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id = -1;
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030738));
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zVDDXlYr$$Az_(5);
			#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=zzQwUIEs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
			#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=z9cbTL9Fte7ios6efTw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zc4t_BNE$BmXcFL6b6tKvb_sJsoUj());
			#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2;
		}
		else if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null)
		{
			for (int i = 0; i < #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zTbkv095gWozyg_xVnw==().Count; i++)
			{
				if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zTbkv095gWozyg_xVnw==()[i].#=zq2bPTdY=().Id == num2)
				{
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zTbkv095gWozyg_xVnw==()[i];
				}
			}
		}
		if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zELdlHynwcS2l(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031840), new object[]
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==()
			});
			return;
		}
		if (num >= 0 && !#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(num))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zELdlHynwcS2l(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031526), new object[]
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==()
			});
			return;
		}
		#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8= #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8= = new #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==, num);
		try
		{
			#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.ShowDialog();
		}
		finally
		{
			((IDisposable)#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=).Dispose();
		}
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x0005CAC4 File Offset: 0x0005ACC4
	private void #=zbdnGfpNfm4ZCDROvpg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zMrEyt5sczn6Y();
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x0005CACC File Offset: 0x0005ACCC
	private void #=zevqWjCagagfBdPYugoDXM7mFXNNz(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zWTSSH5nWVxSb1Yw6Vw==();
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x0005CAD4 File Offset: 0x0005ACD4
	private void #=zoCBfxcQ5e28zvuX9s0vD1Jg=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zZx2UAHg=)
		{
			this.#=zYrmGztSbKa7g5DTR1Qy4cT8=();
		}
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x0005CAE4 File Offset: 0x0005ACE4
	private void #=zXghGq2SQm4769X59Eg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zZx2UAHg=)
		{
			this.#=zarIb2gmUor4u2tqCzMuTaSMVmbHo();
		}
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x0005CAF4 File Offset: 0x0005ACF4
	private void #=zYt2J_hTAtsblJt2bumFV5IsEJjry(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex <= 2)
		{
			return;
		}
		try
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=zcvJaRrlyndEr, #=z4Q$h3mE=.RowIndex);
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031875));
			}
			else
			{
				int num = Convert.ToInt32(this.#=zcvJaRrlyndEr.Columns[#=z4Q$h3mE=.ColumnIndex].Name.Substring(2).Replace('_', '-'));
				if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zG95DTZntR2nRriTBdb76SEs=().ContainsKey(num))
				{
					#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=z40sk5mc= = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zG95DTZntR2nRriTBdb76SEs=()[num].#=zuFPZLKs=();
					#=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw== #=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw== = new #=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw==(this.#=zshVEGQI=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, num, #=z40sk5mc=);
					try
					{
						#=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw==.ShowDialog();
					}
					finally
					{
						((IDisposable)#=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw==).Dispose();
					}
				}
			}
		}
		catch (Exception ex)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, ex);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x0005CBF4 File Offset: 0x0005ADF4
	private void #=z9wDC5hfN$9P6aPTEF0Oz1bhT4d2vF9pLIA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z5bmBcMzlLJ5ozcpneQ==(true);
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x0005CC00 File Offset: 0x0005AE00
	private void #=zGgGS0H0mLAx0MtcRXAjGBG3AzqFE(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex <= 2)
		{
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=zFRKNWHxx__RQ8mqoeA==, #=z4Q$h3mE=.RowIndex);
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031875));
			return;
		}
		int #=zoGfO13mmpn7_yKY6nw== = Convert.ToInt32(this.#=zFRKNWHxx__RQ8mqoeA==.Columns[#=z4Q$h3mE=.ColumnIndex].Name.Substring(2));
		#=ztW1xWiWHhkYAoF1iKFI6idM2F_i8gOsH65O2hlYhBNsg #=ztW1xWiWHhkYAoF1iKFI6idM2F_i8gOsH65O2hlYhBNsg = new #=ztW1xWiWHhkYAoF1iKFI6idM2F_i8gOsH65O2hlYhBNsg(this.#=zshVEGQI=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zoGfO13mmpn7_yKY6nw==);
		try
		{
			#=ztW1xWiWHhkYAoF1iKFI6idM2F_i8gOsH65O2hlYhBNsg.ShowDialog();
		}
		finally
		{
			((IDisposable)#=ztW1xWiWHhkYAoF1iKFI6idM2F_i8gOsH65O2hlYhBNsg).Dispose();
		}
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x0005CC94 File Offset: 0x0005AE94
	private void #=zTvPCfPA_culAXblu8A0dJ60=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex <= 2)
		{
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=z0jG8S8AqVomr, #=z4Q$h3mE=.RowIndex);
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031875));
			return;
		}
		int #=ziRgVK8VC9ABL = Convert.ToInt32(this.#=z0jG8S8AqVomr.Columns[#=z4Q$h3mE=.ColumnIndex].Name.Substring(2));
		#=zstCrSbc6VhhAGh4PcKf7MlixKt4vojDJtAfh4aK8JSPo #=zstCrSbc6VhhAGh4PcKf7MlixKt4vojDJtAfh4aK8JSPo = new #=zstCrSbc6VhhAGh4PcKf7MlixKt4vojDJtAfh4aK8JSPo(this.#=zshVEGQI=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=ziRgVK8VC9ABL);
		try
		{
			#=zstCrSbc6VhhAGh4PcKf7MlixKt4vojDJtAfh4aK8JSPo.ShowDialog();
		}
		finally
		{
			((IDisposable)#=zstCrSbc6VhhAGh4PcKf7MlixKt4vojDJtAfh4aK8JSPo).Dispose();
		}
	}

	// Token: 0x06000BE9 RID: 3049 RVA: 0x0005CD28 File Offset: 0x0005AF28
	private void #=zAklP0VuLhTvcMKQPCOgD7EX5Ws_x(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex <= 2)
		{
			return;
		}
		string dataPropertyName = this.#=z7SD$2jXVMnwApQc26A==.Columns[#=z4Q$h3mE=.ColumnIndex].DataPropertyName;
		int #=zxro48GWsse8U;
		if (!(dataPropertyName == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031478)))
		{
			if (!(dataPropertyName == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031441)))
			{
				if (!(dataPropertyName == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031676)))
				{
					return;
				}
				#=zxro48GWsse8U = 0;
			}
			else
			{
				#=zxro48GWsse8U = 1;
			}
		}
		else
		{
			#=zxro48GWsse8U = 2;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zy12SXA0=(this.#=z7SD$2jXVMnwApQc26A==, #=z4Q$h3mE=.RowIndex);
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031875));
			return;
		}
		#=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY= #=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY= = new #=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY=(this.#=zshVEGQI=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zxro48GWsse8U);
		try
		{
			#=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY=.ShowDialog();
		}
		finally
		{
			((IDisposable)#=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY=).Dispose();
		}
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x0005CDF4 File Offset: 0x0005AFF4
	private void #=zV_GJP1KfXnyNOxvJX4$kc67quTc9nkIEuA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zlC8RWGDjedLMfQJN9W1EuPw=();
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x0005CDFC File Offset: 0x0005AFFC
	private void #=zn6PVeV2y9goG1HzkFR06Eag=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		GridColumnsVisibilityForm gridColumnsVisibilityForm = new GridColumnsVisibilityForm(this.#=zeGmBBtRdzwQaDMyyzg==, 4);
		try
		{
			gridColumnsVisibilityForm.ShowDialog();
		}
		finally
		{
			((IDisposable)gridColumnsVisibilityForm).Dispose();
		}
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x0005CE58 File Offset: 0x0005B058
	private void #=zgpzgXirqPT5_()
	{
		DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
		this.#=zZNsIgSiN3rcd = new DataGridView();
		this.#=zY_YlM1_$tbCL = new DataGridViewTextBoxColumn();
		this.#=zQiUI8p4= = new DataGridViewTextBoxColumn();
		this.#=z81RDCEQ= = new DataGridViewTextBoxColumn();
		this.#=zYDCaWosdbwDQ0aLQEw== = new DataGridViewTextBoxColumn();
		this.#=z3XZyQeAJ4jSu9Mc71A== = new DataGridViewTextBoxColumn();
		this.#=zv3ObmmggvhcJlvMZaw== = new DataGridViewTextBoxColumn();
		this.#=zF$4fV_rTrQYB = new DataGridViewTextBoxColumn();
		this.#=zVQUY6XTRzcI3 = new DataGridViewTextBoxColumn();
		this.#=zZzjQFMCtaf1jABaeJA== = new DataGridViewTextBoxColumn();
		this.#=zcSflGDqZPj8L = new DataGridViewTextBoxColumn();
		this.#=zgcppYQE= = new DataGridViewTextBoxColumn();
		this.#=zK_vWxukBpkp$ = new DataGridViewTextBoxColumn();
		this.#=z2WNGtpR1pO98idpJAlxUfAI= = new DataGridViewTextBoxColumn();
		this.#=zt3$CI$BUuE4vPNg6Yg== = new DataGridViewTextBoxColumn();
		this.#=z074tbnUPlILR = new TabControl();
		this.#=z3wmUNWT30hY_eFuZEQ== = new TabPage();
		this.#=zpYdc9wLbs4vzwsVEDQ== = new DataGridView();
		this.#=zkFAIzI4= = new DataGridViewTextBoxColumn();
		this.#=zAjlrwOg= = new DataGridViewTextBoxColumn();
		this.#=zw0Xi_Go= = new DataGridViewTextBoxColumn();
		this.#=zCSlSIsKj0QW$Sespfg== = new DataGridViewTextBoxColumn();
		this.#=zvSPDEo7nIHc$ = new DataGridViewTextBoxColumn();
		this.#=zu$LCDtxy$9Cf = new DataGridViewTextBoxColumn();
		this.#=zLVJhvveSDV4_ = new DataGridViewTextBoxColumn();
		this.#=zzPiHySBDD7xVAl5_Qw== = new DataGridViewTextBoxColumn();
		this.#=z_63SqbMJ9d2OF$F4RA== = new DataGridViewTextBoxColumn();
		this.#=z$ck8H6_eLjWKM3dhRg== = new DataGridViewTextBoxColumn();
		this.#=zxddb4khjvuUB = new TabPage();
		this.#=zvwloAD8ACqS7XeuSJQ== = new SplitContainer();
		this.#=znfKxsCP9nS_q = new Button();
		this.#=zAyB_OD9fpzbJ = new Button();
		this.#=z5DnnYSvFhFxafulviw== = new TextBox();
		this.#=z1WgtJYpDe9uYCCReRg== = new TextBox();
		this.#=zxsXrETI$Iw8TbR37eA== = new Label();
		this.#=zpR0Be317xdaMSSA7Iw== = new Label();
		this.#=zre8RMFZgteCGIV_PKw== = new Label();
		this.#=zyG48KQl_i7vDV3BlrQ== = new Label();
		this.#=zw$bU$0WaERNWkpebLA== = new TabPage();
		this.#=zicfg3xF9LLrdl98Mew== = new SplitContainer();
		this.#=zT8IjvlxB8Vy$vWiSIw== = new Button();
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17 = new CheckBox();
		this.#=zeGmBBtRdzwQaDMyyzg== = new DataGridView();
		this.#=zVawsfpBkPs_L = new DataGridViewTextBoxColumn();
		this.#=zWk_lQs4= = new DataGridViewTextBoxColumn();
		this.#=zLbIWwH4= = new DataGridViewTextBoxColumn();
		this.#=z2FtN3UBCZGsJEp9lZA== = new DataGridViewTextBoxColumn();
		this.#=zHGuwrLNOLipu = new DataGridViewTextBoxColumn();
		this.#=zkO5rA6YVFV2r = new DataGridViewTextBoxColumn();
		this.#=zFWJIoBGaiBBR = new DataGridViewTextBoxColumn();
		this.#=zISjl5WvgZGhL = new DataGridViewTextBoxColumn();
		this.#=zhNan9QwoGcVT = new DataGridViewTextBoxColumn();
		this.#=zC4zlobQWKp5T = new DataGridViewTextBoxColumn();
		this.#=ztvY90dYlKK1D = new DataGridViewTextBoxColumn();
		this.#=z1Y48OG54qP$d = new DataGridViewTextBoxColumn();
		this.#=zhZ2XWLWVQYmU = new DataGridViewTextBoxColumn();
		this.#=zSGL_BdxXkYpd = new DataGridViewTextBoxColumn();
		this.#=z2KNMLHVb35f8 = new DataGridViewTextBoxColumn();
		this.#=zu1paaFeRfNdw = new DataGridViewTextBoxColumn();
		this.#=zFuq_0ht20kLo = new DataGridViewTextBoxColumn();
		this.#=zGuIAs3Szl2Jy = new DataGridViewTextBoxColumn();
		this.#=zj8wAhu9Tmo1akbETvy6fbv4= = new TabPage();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM= = new SplitContainer();
		this.#=zgcPWZro7CgNxk6h6C9gb4g0= = new Label();
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx = new ComboBox();
		this.#=zFRKNWHxx__RQ8mqoeA== = new DataGridView();
		this.#=z$Xw6g9ZO7YXI = new DataGridViewTextBoxColumn();
		this.#=zQaTBSjQ= = new DataGridViewTextBoxColumn();
		this.#=z5LRkrWs= = new DataGridViewTextBoxColumn();
		this.#=z9c11xNatBnFF5N2g6A== = new DataGridViewTextBoxColumn();
		this.#=z16Jel6PtQHtF = new TabPage();
		this.#=z0jG8S8AqVomr = new DataGridView();
		this.#=z_OTaSW88t7Pc = new DataGridViewTextBoxColumn();
		this.#=zR7GVwIuUs8aL = new DataGridViewTextBoxColumn();
		this.#=zjTaI5$CYaqUA = new DataGridViewTextBoxColumn();
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g= = new DataGridViewTextBoxColumn();
		this.#=z7o3v4I4gp1dBtVNYqw== = new TabPage();
		this.#=znHvi4qIC7e$zupRfOQ== = new SplitContainer();
		this.#=zpj8mPFS3y42jM$LUstbOm$w= = new Label();
		this.#=zBNF4Yh3wT7O770UcmA== = new ComboBox();
		this.#=zjleUOmzfvS7SPY6G2g== = new DataGridView();
		this.#=z$VAevF7aSj_f = new DataGridViewTextBoxColumn();
		this.#=z5uFjnaLK2awf = new DataGridViewTextBoxColumn();
		this.#=z6tEBDyT8gBRW = new DataGridViewTextBoxColumn();
		this.#=z2KYFUEwPIWbtyMnw0A== = new DataGridViewTextBoxColumn();
		this.#=zQ$PxeQwfwlmvGe63cA== = new DataGridViewTextBoxColumn();
		this.#=zVBsL45$iFGnJcXxMAQ== = new TabPage();
		this.#=z7SD$2jXVMnwApQc26A== = new DataGridView();
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s= = new TabPage();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k= = new SplitContainer();
		this.#=z1AIzG94Rzno$51$e1A== = new ComboBox();
		this.#=z9aLgRmkb$ZtNM2KERA== = new ComboBox();
		this.#=zCiVeqWIJriv1MyNqkw== = new ComboBox();
		this.#=zmDPs7p4mTcjFcawRjw== = new ComboBox();
		this.#=zQatKJhqXRdBGb5pLfw== = new ComboBox();
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI= = new ComboBox();
		this.#=z6$cJklOc7Ns_NUTypg== = new Label();
		this.#=zurFiyy7v5_pWPGGq9w== = new Label();
		this.#=zLYSDjsc7OI1dNpspVQ== = new Label();
		this.#=zkQnB$JIroO_xWtOXeA== = new Label();
		this.#=zaCK$hOurVhT$IjLR$w== = new Label();
		this.#=zfYBXYLciZnoZYBNZlHVJdNE= = new Label();
		this.#=zabHK6Uca$1UUcGW9hapqX4s= = new DataGridView();
		this.#=zlJY1CjBaS9I45VHeEw== = new DataGridViewTextBoxColumn();
		this.#=z9Km6khT5YwHU = new DataGridViewTextBoxColumn();
		this.#=zFst9mcVFtZSr = new DataGridViewTextBoxColumn();
		this.#=zshgTbuzO4Tw$En8rjTrod80= = new DataGridViewTextBoxColumn();
		this.#=z7lM5Gvg64nk$ = new TabPage();
		this.#=znLGOdTN1PIm8 = new DataGridView();
		this.#=z581WG3yJjd$QcSWS9w== = new DataGridViewTextBoxColumn();
		this.#=zgi$iMShcWE_Y = new DataGridViewTextBoxColumn();
		this.#=zlb$cWh5$LwiE = new DataGridViewTextBoxColumn();
		this.#=z6zXY6kfjcCJmvTG7UwudJKw= = new DataGridViewTextBoxColumn();
		this.#=zJhDIJAu2fP_03Udvig== = new TabPage();
		this.#=zRFIiZqS7tNfDxRt53Q== = new SplitContainer();
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc= = new CheckBox();
		this.#=zOH2Q5_Bwr9tCScY_nA== = new ComboBox();
		this.#=zcvJaRrlyndEr = new DataGridView();
		this.#=z1aNpETwxCzx$ = new DataGridViewTextBoxColumn();
		this.#=zxekUdrhhPbq2 = new DataGridViewTextBoxColumn();
		this.#=zlm5acezLlv8_ = new DataGridViewTextBoxColumn();
		this.#=zWKSlVIRP5LeFaFdZrg== = new DataGridViewTextBoxColumn();
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM= = new TabPage();
		this.#=zc_YfxSsyTlXw_bP01SgjrF0= = new DataGridView();
		this.#=z7pX3KXxTMInJ = new DataGridViewTextBoxColumn();
		this.#=zFuqfpbGz8dRz = new DataGridViewTextBoxColumn();
		this.#=zDkLUtVh1qB4b = new DataGridViewTextBoxColumn();
		this.#=zZf3dOY$xxFlnL_66QQ== = new DataGridViewTextBoxColumn();
		this.#=zr_3P75ukRfH0gsIZrQ== = new DataGridViewTextBoxColumn();
		this.#=zKsN_mbN1j9T42HDbLA== = new DataGridViewTextBoxColumn();
		this.#=zcyFQ4smxtuOneGXmB5oKOh0= = new DataGridViewTextBoxColumn();
		this.#=zLBZriPAeVVDaWep773dlu7M= = new DataGridViewTextBoxColumn();
		this.#=zMSmpLjPI8aJP = new DataGridViewTextBoxColumn();
		this.#=ztvHmhoLLKIWa = new DataGridViewTextBoxColumn();
		this.#=z0TW5kwrfqT1H = new DataGridViewTextBoxColumn();
		this.#=zrfB9HXw$QaSq = new DataGridViewTextBoxColumn();
		this.#=zwYVd_aXsKJC$vBvo5U2Fth0= = new DataGridViewTextBoxColumn();
		this.#=zu7w4BToxW1MS = new DataGridViewTextBoxColumn();
		this.#=zHQ0bnhpKobIvd676NQ== = new DataGridViewTextBoxColumn();
		this.#=z1ITlnOFPxQQEbBwUCw== = new DataGridViewTextBoxColumn();
		this.#=zZ81N2hjpWhqBO4iIsw== = new DataGridViewTextBoxColumn();
		this.#=zs5So49DTwQJT = new DataGridViewTextBoxColumn();
		this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL = new DataGridViewTextBoxColumn();
		this.#=zKTFqqsoKUwHXXLRCVYHEuJQ= = new DataGridViewTextBoxColumn();
		this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw = new DataGridViewTextBoxColumn();
		this.#=zLIaWnglcqclD = new DataGridViewTextBoxColumn();
		this.#=zVBQK0e$6kjGWgMFjnw== = new DataGridViewTextBoxColumn();
		this.#=zf7$sVpi0Frvb$uyDNaovV8g= = new DataGridViewTextBoxColumn();
		this.#=zpcR1__GYhrNeiDD2JA== = new DataGridViewTextBoxColumn();
		((ISupportInitialize)this.#=zZNsIgSiN3rcd).BeginInit();
		this.#=z074tbnUPlILR.SuspendLayout();
		this.#=z3wmUNWT30hY_eFuZEQ==.SuspendLayout();
		((ISupportInitialize)this.#=zpYdc9wLbs4vzwsVEDQ==).BeginInit();
		this.#=zxddb4khjvuUB.SuspendLayout();
		((ISupportInitialize)this.#=zvwloAD8ACqS7XeuSJQ==).BeginInit();
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel1.SuspendLayout();
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.SuspendLayout();
		this.#=zvwloAD8ACqS7XeuSJQ==.SuspendLayout();
		this.#=zw$bU$0WaERNWkpebLA==.SuspendLayout();
		((ISupportInitialize)this.#=zicfg3xF9LLrdl98Mew==).BeginInit();
		this.#=zicfg3xF9LLrdl98Mew==.Panel1.SuspendLayout();
		this.#=zicfg3xF9LLrdl98Mew==.Panel2.SuspendLayout();
		this.#=zicfg3xF9LLrdl98Mew==.SuspendLayout();
		((ISupportInitialize)this.#=zeGmBBtRdzwQaDMyyzg==).BeginInit();
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.SuspendLayout();
		((ISupportInitialize)this.#=zQ0oWyQww6uUo8ksUJVH0scM=).BeginInit();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel1.SuspendLayout();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel2.SuspendLayout();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.SuspendLayout();
		((ISupportInitialize)this.#=zFRKNWHxx__RQ8mqoeA==).BeginInit();
		this.#=z16Jel6PtQHtF.SuspendLayout();
		((ISupportInitialize)this.#=z0jG8S8AqVomr).BeginInit();
		this.#=z7o3v4I4gp1dBtVNYqw==.SuspendLayout();
		((ISupportInitialize)this.#=znHvi4qIC7e$zupRfOQ==).BeginInit();
		this.#=znHvi4qIC7e$zupRfOQ==.Panel1.SuspendLayout();
		this.#=znHvi4qIC7e$zupRfOQ==.Panel2.SuspendLayout();
		this.#=znHvi4qIC7e$zupRfOQ==.SuspendLayout();
		((ISupportInitialize)this.#=zjleUOmzfvS7SPY6G2g==).BeginInit();
		this.#=zVBsL45$iFGnJcXxMAQ==.SuspendLayout();
		((ISupportInitialize)this.#=z7SD$2jXVMnwApQc26A==).BeginInit();
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.SuspendLayout();
		((ISupportInitialize)this.#=zNsR6nuPhYpLSssQsuMQHu3k=).BeginInit();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.SuspendLayout();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel2.SuspendLayout();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.SuspendLayout();
		((ISupportInitialize)this.#=zabHK6Uca$1UUcGW9hapqX4s=).BeginInit();
		this.#=z7lM5Gvg64nk$.SuspendLayout();
		((ISupportInitialize)this.#=znLGOdTN1PIm8).BeginInit();
		this.#=zJhDIJAu2fP_03Udvig==.SuspendLayout();
		((ISupportInitialize)this.#=zRFIiZqS7tNfDxRt53Q==).BeginInit();
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel1.SuspendLayout();
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel2.SuspendLayout();
		this.#=zRFIiZqS7tNfDxRt53Q==.SuspendLayout();
		((ISupportInitialize)this.#=zcvJaRrlyndEr).BeginInit();
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.SuspendLayout();
		((ISupportInitialize)this.#=zc_YfxSsyTlXw_bP01SgjrF0=).BeginInit();
		base.SuspendLayout();
		this.#=zZNsIgSiN3rcd.AllowUserToAddRows = false;
		this.#=zZNsIgSiN3rcd.AllowUserToDeleteRows = false;
		this.#=zZNsIgSiN3rcd.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zZNsIgSiN3rcd.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zY_YlM1_$tbCL,
			this.#=zQiUI8p4=,
			this.#=z81RDCEQ=,
			this.#=zYDCaWosdbwDQ0aLQEw==,
			this.#=z3XZyQeAJ4jSu9Mc71A==,
			this.#=zv3ObmmggvhcJlvMZaw==,
			this.#=zF$4fV_rTrQYB,
			this.#=zVQUY6XTRzcI3,
			this.#=zZzjQFMCtaf1jABaeJA==,
			this.#=zcSflGDqZPj8L,
			this.#=zgcppYQE=,
			this.#=zK_vWxukBpkp$,
			this.#=z2WNGtpR1pO98idpJAlxUfAI=,
			this.#=zt3$CI$BUuE4vPNg6Yg==
		});
		this.#=zZNsIgSiN3rcd.Dock = DockStyle.Fill;
		this.#=zZNsIgSiN3rcd.Location = new Point(0, 0);
		this.#=zZNsIgSiN3rcd.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031644);
		this.#=zZNsIgSiN3rcd.ReadOnly = true;
		this.#=zZNsIgSiN3rcd.Size = new Size(970, 541);
		this.#=zZNsIgSiN3rcd.TabIndex = 0;
		this.#=zZNsIgSiN3rcd.CellClick += this.#=zeQEwSK$9jLimx4mYRA==;
		this.#=zY_YlM1_$tbCL.Frozen = true;
		this.#=zY_YlM1_$tbCL.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zY_YlM1_$tbCL.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031617);
		this.#=zY_YlM1_$tbCL.ReadOnly = true;
		this.#=zY_YlM1_$tbCL.Width = 40;
		this.#=zQiUI8p4=.Frozen = true;
		this.#=zQiUI8p4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zQiUI8p4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031605);
		this.#=zQiUI8p4=.ReadOnly = true;
		this.#=zQiUI8p4=.Width = 150;
		this.#=z81RDCEQ=.Frozen = true;
		this.#=z81RDCEQ=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=z81RDCEQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031579);
		this.#=z81RDCEQ=.ReadOnly = true;
		this.#=zYDCaWosdbwDQ0aLQEw==.Frozen = true;
		this.#=zYDCaWosdbwDQ0aLQEw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zYDCaWosdbwDQ0aLQEw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031567);
		this.#=zYDCaWosdbwDQ0aLQEw==.ReadOnly = true;
		dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033329), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle.Format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033319);
		dataGridViewCellStyle.NullValue = null;
		this.#=z3XZyQeAJ4jSu9Mc71A==.DefaultCellStyle = dataGridViewCellStyle;
		this.#=z3XZyQeAJ4jSu9Mc71A==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908989677);
		this.#=z3XZyQeAJ4jSu9Mc71A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033308);
		this.#=z3XZyQeAJ4jSu9Mc71A==.ReadOnly = true;
		dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle2.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033329), 8.25f);
		dataGridViewCellStyle2.Format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033319);
		this.#=zv3ObmmggvhcJlvMZaw==.DefaultCellStyle = dataGridViewCellStyle2;
		this.#=zv3ObmmggvhcJlvMZaw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908989461);
		this.#=zv3ObmmggvhcJlvMZaw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033285);
		this.#=zv3ObmmggvhcJlvMZaw==.ReadOnly = true;
		dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle3.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033329), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle3.Format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033319);
		this.#=zF$4fV_rTrQYB.DefaultCellStyle = dataGridViewCellStyle3;
		this.#=zF$4fV_rTrQYB.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908989490);
		this.#=zF$4fV_rTrQYB.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033250);
		this.#=zF$4fV_rTrQYB.ReadOnly = true;
		this.#=zVQUY6XTRzcI3.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033246);
		this.#=zVQUY6XTRzcI3.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033229);
		this.#=zVQUY6XTRzcI3.ReadOnly = true;
		this.#=zZzjQFMCtaf1jABaeJA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033458);
		this.#=zZzjQFMCtaf1jABaeJA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033440);
		this.#=zZzjQFMCtaf1jABaeJA==.ReadOnly = true;
		dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle4.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033329), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle4.Format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033319);
		this.#=zcSflGDqZPj8L.DefaultCellStyle = dataGridViewCellStyle4;
		this.#=zcSflGDqZPj8L.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033424);
		this.#=zcSflGDqZPj8L.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033420);
		this.#=zcSflGDqZPj8L.ReadOnly = true;
		this.#=zgcppYQE=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033400);
		this.#=zgcppYQE=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033385);
		this.#=zgcppYQE=.ReadOnly = true;
		dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleRight;
		dataGridViewCellStyle5.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033329), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle5.Format = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033319);
		this.#=zK_vWxukBpkp$.DefaultCellStyle = dataGridViewCellStyle5;
		this.#=zK_vWxukBpkp$.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033371);
		this.#=zK_vWxukBpkp$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066768);
		this.#=zK_vWxukBpkp$.ReadOnly = true;
		this.#=z2WNGtpR1pO98idpJAlxUfAI=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033352);
		this.#=z2WNGtpR1pO98idpJAlxUfAI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033073);
		this.#=z2WNGtpR1pO98idpJAlxUfAI=.ReadOnly = true;
		this.#=zt3$CI$BUuE4vPNg6Yg==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033051);
		this.#=zt3$CI$BUuE4vPNg6Yg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033026);
		this.#=zt3$CI$BUuE4vPNg6Yg==.ReadOnly = true;
		this.#=z074tbnUPlILR.Controls.Add(this.#=z3wmUNWT30hY_eFuZEQ==);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zxddb4khjvuUB);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zw$bU$0WaERNWkpebLA==);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zj8wAhu9Tmo1akbETvy6fbv4=);
		this.#=z074tbnUPlILR.Controls.Add(this.#=z16Jel6PtQHtF);
		this.#=z074tbnUPlILR.Controls.Add(this.#=z7o3v4I4gp1dBtVNYqw==);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zVBsL45$iFGnJcXxMAQ==);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zL9kGPbGMHSkEM95Dx$0$N4s=);
		this.#=z074tbnUPlILR.Controls.Add(this.#=z7lM5Gvg64nk$);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zJhDIJAu2fP_03Udvig==);
		this.#=z074tbnUPlILR.Controls.Add(this.#=zfR73Ff_xOTcSYEdwnSPrAEM=);
		this.#=z074tbnUPlILR.Dock = DockStyle.Fill;
		this.#=z074tbnUPlILR.Location = new Point(0, 0);
		this.#=z074tbnUPlILR.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033014);
		this.#=z074tbnUPlILR.SelectedIndex = 0;
		this.#=z074tbnUPlILR.Size = new Size(984, 661);
		this.#=z074tbnUPlILR.TabIndex = 1;
		this.#=z074tbnUPlILR.SelectedIndexChanged += this.#=zbdnGfpNfm4ZCDROvpg==;
		this.#=z3wmUNWT30hY_eFuZEQ==.Controls.Add(this.#=zpYdc9wLbs4vzwsVEDQ==);
		this.#=z3wmUNWT30hY_eFuZEQ==.Location = new Point(4, 22);
		this.#=z3wmUNWT30hY_eFuZEQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031029);
		this.#=z3wmUNWT30hY_eFuZEQ==.Size = new Size(976, 635);
		this.#=z3wmUNWT30hY_eFuZEQ==.TabIndex = 3;
		this.#=z3wmUNWT30hY_eFuZEQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032988);
		this.#=z3wmUNWT30hY_eFuZEQ==.UseVisualStyleBackColor = true;
		this.#=zpYdc9wLbs4vzwsVEDQ==.AllowUserToAddRows = false;
		this.#=zpYdc9wLbs4vzwsVEDQ==.AllowUserToDeleteRows = false;
		this.#=zpYdc9wLbs4vzwsVEDQ==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zpYdc9wLbs4vzwsVEDQ==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zkFAIzI4=,
			this.#=zAjlrwOg=,
			this.#=zw0Xi_Go=,
			this.#=zCSlSIsKj0QW$Sespfg==,
			this.#=zvSPDEo7nIHc$,
			this.#=zu$LCDtxy$9Cf,
			this.#=zLVJhvveSDV4_,
			this.#=zzPiHySBDD7xVAl5_Qw==,
			this.#=z_63SqbMJ9d2OF$F4RA==,
			this.#=z$ck8H6_eLjWKM3dhRg==
		});
		this.#=zpYdc9wLbs4vzwsVEDQ==.Dock = DockStyle.Fill;
		this.#=zpYdc9wLbs4vzwsVEDQ==.Location = new Point(0, 0);
		this.#=zpYdc9wLbs4vzwsVEDQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032963);
		this.#=zpYdc9wLbs4vzwsVEDQ==.ReadOnly = true;
		this.#=zpYdc9wLbs4vzwsVEDQ==.Size = new Size(976, 635);
		this.#=zpYdc9wLbs4vzwsVEDQ==.TabIndex = 1;
		this.#=zkFAIzI4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zkFAIzI4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033206);
		this.#=zkFAIzI4=.ReadOnly = true;
		this.#=zkFAIzI4=.Width = 40;
		this.#=zAjlrwOg=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zAjlrwOg=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033185);
		this.#=zAjlrwOg=.ReadOnly = true;
		this.#=zAjlrwOg=.Width = 200;
		this.#=zw0Xi_Go=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zw0Xi_Go=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033175);
		this.#=zw0Xi_Go=.ReadOnly = true;
		this.#=zCSlSIsKj0QW$Sespfg==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zCSlSIsKj0QW$Sespfg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033147);
		this.#=zCSlSIsKj0QW$Sespfg==.ReadOnly = true;
		this.#=zvSPDEo7nIHc$.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909003070);
		this.#=zvSPDEo7nIHc$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033133);
		this.#=zvSPDEo7nIHc$.ReadOnly = true;
		this.#=zvSPDEo7nIHc$.Width = 50;
		this.#=zu$LCDtxy$9Cf.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033104);
		this.#=zu$LCDtxy$9Cf.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033091);
		this.#=zu$LCDtxy$9Cf.ReadOnly = true;
		this.#=zu$LCDtxy$9Cf.Width = 70;
		this.#=zLVJhvveSDV4_.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105987);
		this.#=zLVJhvveSDV4_.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032822);
		this.#=zLVJhvveSDV4_.ReadOnly = true;
		this.#=zLVJhvveSDV4_.Width = 70;
		this.#=zzPiHySBDD7xVAl5_Qw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032795);
		this.#=zzPiHySBDD7xVAl5_Qw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032789);
		this.#=zzPiHySBDD7xVAl5_Qw==.ReadOnly = true;
		this.#=zzPiHySBDD7xVAl5_Qw==.Width = 50;
		this.#=z_63SqbMJ9d2OF$F4RA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032764);
		this.#=z_63SqbMJ9d2OF$F4RA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032738);
		this.#=z_63SqbMJ9d2OF$F4RA==.ReadOnly = true;
		this.#=z_63SqbMJ9d2OF$F4RA==.Width = 50;
		this.#=z$ck8H6_eLjWKM3dhRg==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032715);
		this.#=z$ck8H6_eLjWKM3dhRg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032954);
		this.#=z$ck8H6_eLjWKM3dhRg==.ReadOnly = true;
		this.#=z$ck8H6_eLjWKM3dhRg==.Width = 300;
		this.#=zxddb4khjvuUB.Controls.Add(this.#=zvwloAD8ACqS7XeuSJQ==);
		this.#=zxddb4khjvuUB.Location = new Point(4, 22);
		this.#=zxddb4khjvuUB.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031007);
		this.#=zxddb4khjvuUB.Padding = new Padding(3);
		this.#=zxddb4khjvuUB.Size = new Size(976, 635);
		this.#=zxddb4khjvuUB.TabIndex = 0;
		this.#=zxddb4khjvuUB.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909015185);
		this.#=zxddb4khjvuUB.UseVisualStyleBackColor = true;
		this.#=zvwloAD8ACqS7XeuSJQ==.Dock = DockStyle.Fill;
		this.#=zvwloAD8ACqS7XeuSJQ==.FixedPanel = FixedPanel.Panel2;
		this.#=zvwloAD8ACqS7XeuSJQ==.Location = new Point(3, 3);
		this.#=zvwloAD8ACqS7XeuSJQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032942);
		this.#=zvwloAD8ACqS7XeuSJQ==.Orientation = Orientation.Horizontal;
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel1.Controls.Add(this.#=zZNsIgSiN3rcd);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=znfKxsCP9nS_q);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=zAyB_OD9fpzbJ);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=z5DnnYSvFhFxafulviw==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=z1WgtJYpDe9uYCCReRg==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=zxsXrETI$Iw8TbR37eA==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=zpR0Be317xdaMSSA7Iw==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=zre8RMFZgteCGIV_PKw==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.Controls.Add(this.#=zyG48KQl_i7vDV3BlrQ==);
		this.#=zvwloAD8ACqS7XeuSJQ==.Size = new Size(970, 629);
		this.#=zvwloAD8ACqS7XeuSJQ==.SplitterDistance = 541;
		this.#=zvwloAD8ACqS7XeuSJQ==.TabIndex = 1;
		this.#=znfKxsCP9nS_q.Location = new Point(574, 21);
		this.#=znfKxsCP9nS_q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032907);
		this.#=znfKxsCP9nS_q.Size = new Size(75, 23);
		this.#=znfKxsCP9nS_q.TabIndex = 3;
		this.#=znfKxsCP9nS_q.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032873);
		this.#=znfKxsCP9nS_q.UseVisualStyleBackColor = true;
		this.#=znfKxsCP9nS_q.Click += this.#=zdM5EOW3bT9Spb1GAAg==;
		this.#=zAyB_OD9fpzbJ.Location = new Point(441, 12);
		this.#=zAyB_OD9fpzbJ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032859);
		this.#=zAyB_OD9fpzbJ.Size = new Size(85, 42);
		this.#=zAyB_OD9fpzbJ.TabIndex = 2;
		this.#=zAyB_OD9fpzbJ.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032571);
		this.#=zAyB_OD9fpzbJ.UseVisualStyleBackColor = true;
		this.#=zAyB_OD9fpzbJ.Click += this.#=zHZkZ0H81F_ZXV_$kZw==;
		this.#=z5DnnYSvFhFxafulviw==.Location = new Point(317, 38);
		this.#=z5DnnYSvFhFxafulviw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032552);
		this.#=z5DnnYSvFhFxafulviw==.Size = new Size(100, 20);
		this.#=z5DnnYSvFhFxafulviw==.TabIndex = 1;
		this.#=z1WgtJYpDe9uYCCReRg==.Location = new Point(317, 9);
		this.#=z1WgtJYpDe9uYCCReRg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032525);
		this.#=z1WgtJYpDe9uYCCReRg==.Size = new Size(100, 20);
		this.#=z1WgtJYpDe9uYCCReRg==.TabIndex = 1;
		this.#=zxsXrETI$Iw8TbR37eA==.AutoSize = true;
		this.#=zxsXrETI$Iw8TbR37eA==.Location = new Point(5, 41);
		this.#=zxsXrETI$Iw8TbR37eA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032486);
		this.#=zxsXrETI$Iw8TbR37eA==.Size = new Size(35, 13);
		this.#=zxsXrETI$Iw8TbR37eA==.TabIndex = 0;
		this.#=zxsXrETI$Iw8TbR37eA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		this.#=zpR0Be317xdaMSSA7Iw==.AutoSize = true;
		this.#=zpR0Be317xdaMSSA7Iw==.Location = new Point(240, 41);
		this.#=zpR0Be317xdaMSSA7Iw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032455);
		this.#=zpR0Be317xdaMSSA7Iw==.Size = new Size(37, 13);
		this.#=zpR0Be317xdaMSSA7Iw==.TabIndex = 0;
		this.#=zpR0Be317xdaMSSA7Iw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032664);
		this.#=zre8RMFZgteCGIV_PKw==.AutoSize = true;
		this.#=zre8RMFZgteCGIV_PKw==.Location = new Point(240, 12);
		this.#=zre8RMFZgteCGIV_PKw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032649);
		this.#=zre8RMFZgteCGIV_PKw==.Size = new Size(35, 13);
		this.#=zre8RMFZgteCGIV_PKw==.TabIndex = 0;
		this.#=zre8RMFZgteCGIV_PKw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		this.#=zyG48KQl_i7vDV3BlrQ==.AutoSize = true;
		this.#=zyG48KQl_i7vDV3BlrQ==.Location = new Point(5, 12);
		this.#=zyG48KQl_i7vDV3BlrQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032610);
		this.#=zyG48KQl_i7vDV3BlrQ==.Size = new Size(35, 13);
		this.#=zyG48KQl_i7vDV3BlrQ==.TabIndex = 0;
		this.#=zyG48KQl_i7vDV3BlrQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		this.#=zw$bU$0WaERNWkpebLA==.Controls.Add(this.#=zicfg3xF9LLrdl98Mew==);
		this.#=zw$bU$0WaERNWkpebLA==.Location = new Point(4, 22);
		this.#=zw$bU$0WaERNWkpebLA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030982);
		this.#=zw$bU$0WaERNWkpebLA==.Size = new Size(976, 635);
		this.#=zw$bU$0WaERNWkpebLA==.TabIndex = 1;
		this.#=zw$bU$0WaERNWkpebLA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909015232);
		this.#=zw$bU$0WaERNWkpebLA==.UseVisualStyleBackColor = true;
		this.#=zicfg3xF9LLrdl98Mew==.Dock = DockStyle.Fill;
		this.#=zicfg3xF9LLrdl98Mew==.FixedPanel = FixedPanel.Panel1;
		this.#=zicfg3xF9LLrdl98Mew==.Location = new Point(0, 0);
		this.#=zicfg3xF9LLrdl98Mew==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032579);
		this.#=zicfg3xF9LLrdl98Mew==.Orientation = Orientation.Horizontal;
		this.#=zicfg3xF9LLrdl98Mew==.Panel1.Controls.Add(this.#=zT8IjvlxB8Vy$vWiSIw==);
		this.#=zicfg3xF9LLrdl98Mew==.Panel1.Controls.Add(this.#=zivg1eompdcozp3S8Zv303Kvr5P17);
		this.#=zicfg3xF9LLrdl98Mew==.Panel2.Controls.Add(this.#=zeGmBBtRdzwQaDMyyzg==);
		this.#=zicfg3xF9LLrdl98Mew==.Size = new Size(976, 635);
		this.#=zicfg3xF9LLrdl98Mew==.SplitterDistance = 32;
		this.#=zicfg3xF9LLrdl98Mew==.TabIndex = 0;
		this.#=zT8IjvlxB8Vy$vWiSIw==.Location = new Point(269, 6);
		this.#=zT8IjvlxB8Vy$vWiSIw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017966);
		this.#=zT8IjvlxB8Vy$vWiSIw==.Size = new Size(163, 23);
		this.#=zT8IjvlxB8Vy$vWiSIw==.TabIndex = 1;
		this.#=zT8IjvlxB8Vy$vWiSIw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017935);
		this.#=zT8IjvlxB8Vy$vWiSIw==.UseVisualStyleBackColor = true;
		this.#=zT8IjvlxB8Vy$vWiSIw==.Click += this.#=zn6PVeV2y9goG1HzkFR06Eag=;
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.AutoSize = true;
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.Location = new Point(8, 12);
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017911);
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.Size = new Size(163, 17);
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.TabIndex = 0;
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017878);
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.UseVisualStyleBackColor = true;
		this.#=zivg1eompdcozp3S8Zv303Kvr5P17.CheckedChanged += this.#=z9wDC5hfN$9P6aPTEF0Oz1bhT4d2vF9pLIA==;
		this.#=zeGmBBtRdzwQaDMyyzg==.AllowUserToAddRows = false;
		this.#=zeGmBBtRdzwQaDMyyzg==.AllowUserToDeleteRows = false;
		this.#=zeGmBBtRdzwQaDMyyzg==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zeGmBBtRdzwQaDMyyzg==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zVawsfpBkPs_L,
			this.#=zWk_lQs4=,
			this.#=zLbIWwH4=,
			this.#=z2FtN3UBCZGsJEp9lZA==,
			this.#=zHGuwrLNOLipu,
			this.#=zkO5rA6YVFV2r,
			this.#=zFWJIoBGaiBBR,
			this.#=zISjl5WvgZGhL,
			this.#=zhNan9QwoGcVT,
			this.#=zC4zlobQWKp5T,
			this.#=ztvY90dYlKK1D,
			this.#=z1Y48OG54qP$d,
			this.#=zhZ2XWLWVQYmU,
			this.#=zSGL_BdxXkYpd,
			this.#=z2KNMLHVb35f8,
			this.#=zu1paaFeRfNdw,
			this.#=zFuq_0ht20kLo,
			this.#=zGuIAs3Szl2Jy
		});
		this.#=zeGmBBtRdzwQaDMyyzg==.Dock = DockStyle.Fill;
		this.#=zeGmBBtRdzwQaDMyyzg==.Location = new Point(0, 0);
		this.#=zeGmBBtRdzwQaDMyyzg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018090);
		this.#=zeGmBBtRdzwQaDMyyzg==.ReadOnly = true;
		this.#=zeGmBBtRdzwQaDMyyzg==.Size = new Size(976, 599);
		this.#=zeGmBBtRdzwQaDMyyzg==.TabIndex = 0;
		this.#=zVawsfpBkPs_L.Frozen = true;
		this.#=zVawsfpBkPs_L.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zVawsfpBkPs_L.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018075);
		this.#=zVawsfpBkPs_L.ReadOnly = true;
		this.#=zVawsfpBkPs_L.Width = 40;
		this.#=zWk_lQs4=.Frozen = true;
		this.#=zWk_lQs4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zWk_lQs4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018063);
		this.#=zWk_lQs4=.ReadOnly = true;
		this.#=zWk_lQs4=.Width = 150;
		this.#=zLbIWwH4=.Frozen = true;
		this.#=zLbIWwH4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zLbIWwH4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018045);
		this.#=zLbIWwH4=.ReadOnly = true;
		this.#=z2FtN3UBCZGsJEp9lZA==.Frozen = true;
		this.#=z2FtN3UBCZGsJEp9lZA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=z2FtN3UBCZGsJEp9lZA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018017);
		this.#=z2FtN3UBCZGsJEp9lZA==.ReadOnly = true;
		this.#=zHGuwrLNOLipu.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017995);
		this.#=zHGuwrLNOLipu.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017721);
		this.#=zHGuwrLNOLipu.ReadOnly = true;
		this.#=zkO5rA6YVFV2r.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017717);
		this.#=zkO5rA6YVFV2r.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017691);
		this.#=zkO5rA6YVFV2r.ReadOnly = true;
		this.#=zFWJIoBGaiBBR.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017687);
		this.#=zFWJIoBGaiBBR.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017668);
		this.#=zFWJIoBGaiBBR.ReadOnly = true;
		this.#=zISjl5WvgZGhL.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017648);
		this.#=zISjl5WvgZGhL.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017633);
		this.#=zISjl5WvgZGhL.ReadOnly = true;
		this.#=zhNan9QwoGcVT.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017629);
		this.#=zhNan9QwoGcVT.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017603);
		this.#=zhNan9QwoGcVT.ReadOnly = true;
		this.#=zC4zlobQWKp5T.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017855);
		this.#=zC4zlobQWKp5T.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017837);
		this.#=zC4zlobQWKp5T.ReadOnly = true;
		this.#=ztvY90dYlKK1D.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017817);
		this.#=ztvY90dYlKK1D.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017806);
		this.#=ztvY90dYlKK1D.ReadOnly = true;
		this.#=z1Y48OG54qP$d.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017786);
		this.#=z1Y48OG54qP$d.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017771);
		this.#=z1Y48OG54qP$d.ReadOnly = true;
		this.#=zhZ2XWLWVQYmU.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017767);
		this.#=zhZ2XWLWVQYmU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017738);
		this.#=zhZ2XWLWVQYmU.ReadOnly = true;
		this.#=zSGL_BdxXkYpd.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017734);
		this.#=zSGL_BdxXkYpd.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017461);
		this.#=zSGL_BdxXkYpd.ReadOnly = true;
		this.#=z2KNMLHVb35f8.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017441);
		this.#=z2KNMLHVb35f8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017431);
		this.#=z2KNMLHVb35f8.ReadOnly = true;
		this.#=zu1paaFeRfNdw.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017411);
		this.#=zu1paaFeRfNdw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017393);
		this.#=zu1paaFeRfNdw.ReadOnly = true;
		this.#=zFuq_0ht20kLo.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090432);
		this.#=zFuq_0ht20kLo.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017389);
		this.#=zFuq_0ht20kLo.ReadOnly = true;
		this.#=zGuIAs3Szl2Jy.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017369);
		this.#=zGuIAs3Szl2Jy.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017358);
		this.#=zGuIAs3Szl2Jy.ReadOnly = true;
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.Controls.Add(this.#=zQ0oWyQww6uUo8ksUJVH0scM=);
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.Location = new Point(4, 22);
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031210);
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.Size = new Size(976, 635);
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.TabIndex = 4;
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909001097);
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.UseVisualStyleBackColor = true;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Dock = DockStyle.Fill;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.FixedPanel = FixedPanel.Panel1;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.IsSplitterFixed = true;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Location = new Point(0, 0);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017349);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Orientation = Orientation.Horizontal;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel1.Controls.Add(this.#=zgcPWZro7CgNxk6h6C9gb4g0=);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel1.Controls.Add(this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel2.Controls.Add(this.#=zFRKNWHxx__RQ8mqoeA==);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Size = new Size(976, 635);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.SplitterDistance = 34;
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.TabIndex = 1;
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.AutoSize = true;
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.Location = new Point(8, 11);
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017575);
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.Size = new Size(166, 13);
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.TabIndex = 1;
		this.#=zgcPWZro7CgNxk6h6C9gb4g0=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017537);
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.FormattingEnabled = true;
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017500),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017478)
		});
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.Location = new Point(232, 8);
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017192);
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.Size = new Size(188, 21);
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.TabIndex = 0;
		this.#=zq7P0VUHHSH9KPcgblP9TnpwZXOmx.SelectedIndexChanged += this.#=zV_GJP1KfXnyNOxvJX4$kc67quTc9nkIEuA==;
		this.#=zFRKNWHxx__RQ8mqoeA==.AllowUserToAddRows = false;
		this.#=zFRKNWHxx__RQ8mqoeA==.AllowUserToDeleteRows = false;
		this.#=zFRKNWHxx__RQ8mqoeA==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zFRKNWHxx__RQ8mqoeA==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z$Xw6g9ZO7YXI,
			this.#=zQaTBSjQ=,
			this.#=z5LRkrWs=,
			this.#=z9c11xNatBnFF5N2g6A==
		});
		this.#=zFRKNWHxx__RQ8mqoeA==.Dock = DockStyle.Fill;
		this.#=zFRKNWHxx__RQ8mqoeA==.Location = new Point(0, 0);
		this.#=zFRKNWHxx__RQ8mqoeA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017161);
		this.#=zFRKNWHxx__RQ8mqoeA==.ReadOnly = true;
		this.#=zFRKNWHxx__RQ8mqoeA==.Size = new Size(976, 597);
		this.#=zFRKNWHxx__RQ8mqoeA==.TabIndex = 0;
		this.#=zFRKNWHxx__RQ8mqoeA==.CellDoubleClick += this.#=zGgGS0H0mLAx0MtcRXAjGBG3AzqFE;
		this.#=zFRKNWHxx__RQ8mqoeA==.CellPainting += this.#=zHqRo_0Ga3kxH3hv2OOMlYRk=;
		this.#=z$Xw6g9ZO7YXI.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030932);
		this.#=z$Xw6g9ZO7YXI.Frozen = true;
		this.#=z$Xw6g9ZO7YXI.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z$Xw6g9ZO7YXI.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030932);
		this.#=z$Xw6g9ZO7YXI.ReadOnly = true;
		this.#=z$Xw6g9ZO7YXI.Width = 40;
		this.#=zQaTBSjQ=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031160);
		this.#=zQaTBSjQ=.Frozen = true;
		this.#=zQaTBSjQ=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zQaTBSjQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031160);
		this.#=zQaTBSjQ=.ReadOnly = true;
		this.#=zQaTBSjQ=.Width = 200;
		this.#=z5LRkrWs=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031150);
		this.#=z5LRkrWs=.Frozen = true;
		this.#=z5LRkrWs=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=z5LRkrWs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031150);
		this.#=z5LRkrWs=.ReadOnly = true;
		this.#=z9c11xNatBnFF5N2g6A==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031122);
		this.#=z9c11xNatBnFF5N2g6A==.Frozen = true;
		this.#=z9c11xNatBnFF5N2g6A==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=z9c11xNatBnFF5N2g6A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031122);
		this.#=z9c11xNatBnFF5N2g6A==.ReadOnly = true;
		this.#=z16Jel6PtQHtF.Controls.Add(this.#=z0jG8S8AqVomr);
		this.#=z16Jel6PtQHtF.Location = new Point(4, 22);
		this.#=z16Jel6PtQHtF.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031197);
		this.#=z16Jel6PtQHtF.Size = new Size(976, 635);
		this.#=z16Jel6PtQHtF.TabIndex = 5;
		this.#=z16Jel6PtQHtF.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909003331);
		this.#=z16Jel6PtQHtF.UseVisualStyleBackColor = true;
		this.#=z0jG8S8AqVomr.AllowUserToAddRows = false;
		this.#=z0jG8S8AqVomr.AllowUserToDeleteRows = false;
		this.#=z0jG8S8AqVomr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z0jG8S8AqVomr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z_OTaSW88t7Pc,
			this.#=zR7GVwIuUs8aL,
			this.#=zjTaI5$CYaqUA,
			this.#=zrjVm6P_TPO33G5OXBC6Zo4g=
		});
		this.#=z0jG8S8AqVomr.Dock = DockStyle.Fill;
		this.#=z0jG8S8AqVomr.Location = new Point(0, 0);
		this.#=z0jG8S8AqVomr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017149);
		this.#=z0jG8S8AqVomr.ReadOnly = true;
		this.#=z0jG8S8AqVomr.Size = new Size(976, 635);
		this.#=z0jG8S8AqVomr.TabIndex = 0;
		this.#=z0jG8S8AqVomr.CellDoubleClick += this.#=zTvPCfPA_culAXblu8A0dJ60=;
		this.#=z0jG8S8AqVomr.CellPainting += this.#=zHqRo_0Ga3kxH3hv2OOMlYRk=;
		this.#=z_OTaSW88t7Pc.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031101);
		this.#=z_OTaSW88t7Pc.Frozen = true;
		this.#=z_OTaSW88t7Pc.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z_OTaSW88t7Pc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031101);
		this.#=z_OTaSW88t7Pc.ReadOnly = true;
		this.#=z_OTaSW88t7Pc.Width = 40;
		this.#=zR7GVwIuUs8aL.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031079);
		this.#=zR7GVwIuUs8aL.Frozen = true;
		this.#=zR7GVwIuUs8aL.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zR7GVwIuUs8aL.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031079);
		this.#=zR7GVwIuUs8aL.ReadOnly = true;
		this.#=zR7GVwIuUs8aL.Width = 200;
		this.#=zjTaI5$CYaqUA.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031051);
		this.#=zjTaI5$CYaqUA.Frozen = true;
		this.#=zjTaI5$CYaqUA.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zjTaI5$CYaqUA.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031051);
		this.#=zjTaI5$CYaqUA.ReadOnly = true;
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030781);
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g=.Frozen = true;
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030781);
		this.#=zrjVm6P_TPO33G5OXBC6Zo4g=.ReadOnly = true;
		this.#=z7o3v4I4gp1dBtVNYqw==.Controls.Add(this.#=znHvi4qIC7e$zupRfOQ==);
		this.#=z7o3v4I4gp1dBtVNYqw==.Location = new Point(4, 22);
		this.#=z7o3v4I4gp1dBtVNYqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031171);
		this.#=z7o3v4I4gp1dBtVNYqw==.Size = new Size(976, 635);
		this.#=z7o3v4I4gp1dBtVNYqw==.TabIndex = 6;
		this.#=z7o3v4I4gp1dBtVNYqw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017132);
		this.#=z7o3v4I4gp1dBtVNYqw==.UseVisualStyleBackColor = true;
		this.#=znHvi4qIC7e$zupRfOQ==.Dock = DockStyle.Fill;
		this.#=znHvi4qIC7e$zupRfOQ==.FixedPanel = FixedPanel.Panel1;
		this.#=znHvi4qIC7e$zupRfOQ==.IsSplitterFixed = true;
		this.#=znHvi4qIC7e$zupRfOQ==.Location = new Point(0, 0);
		this.#=znHvi4qIC7e$zupRfOQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017099);
		this.#=znHvi4qIC7e$zupRfOQ==.Orientation = Orientation.Horizontal;
		this.#=znHvi4qIC7e$zupRfOQ==.Panel1.Controls.Add(this.#=zpj8mPFS3y42jM$LUstbOm$w=);
		this.#=znHvi4qIC7e$zupRfOQ==.Panel1.Controls.Add(this.#=zBNF4Yh3wT7O770UcmA==);
		this.#=znHvi4qIC7e$zupRfOQ==.Panel2.Controls.Add(this.#=zjleUOmzfvS7SPY6G2g==);
		this.#=znHvi4qIC7e$zupRfOQ==.Size = new Size(976, 635);
		this.#=znHvi4qIC7e$zupRfOQ==.SplitterDistance = 28;
		this.#=znHvi4qIC7e$zupRfOQ==.TabIndex = 2;
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.AutoSize = true;
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.Location = new Point(3, 6);
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017323);
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.Size = new Size(67, 13);
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.TabIndex = 1;
		this.#=zpj8mPFS3y42jM$LUstbOm$w=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909048041);
		this.#=zBNF4Yh3wT7O770UcmA==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zBNF4Yh3wT7O770UcmA==.FormattingEnabled = true;
		this.#=zBNF4Yh3wT7O770UcmA==.Location = new Point(121, 3);
		this.#=zBNF4Yh3wT7O770UcmA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017302);
		this.#=zBNF4Yh3wT7O770UcmA==.Size = new Size(245, 21);
		this.#=zBNF4Yh3wT7O770UcmA==.TabIndex = 0;
		this.#=zBNF4Yh3wT7O770UcmA==.SelectedIndexChanged += this.#=zevqWjCagagfBdPYugoDXM7mFXNNz;
		this.#=zjleUOmzfvS7SPY6G2g==.AllowUserToAddRows = false;
		this.#=zjleUOmzfvS7SPY6G2g==.AllowUserToDeleteRows = false;
		this.#=zjleUOmzfvS7SPY6G2g==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zjleUOmzfvS7SPY6G2g==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z$VAevF7aSj_f,
			this.#=z5uFjnaLK2awf,
			this.#=z6tEBDyT8gBRW,
			this.#=z2KYFUEwPIWbtyMnw0A==,
			this.#=zQ$PxeQwfwlmvGe63cA==
		});
		this.#=zjleUOmzfvS7SPY6G2g==.Dock = DockStyle.Fill;
		this.#=zjleUOmzfvS7SPY6G2g==.Location = new Point(0, 0);
		this.#=zjleUOmzfvS7SPY6G2g==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017276);
		this.#=zjleUOmzfvS7SPY6G2g==.ReadOnly = true;
		this.#=zjleUOmzfvS7SPY6G2g==.Size = new Size(976, 603);
		this.#=zjleUOmzfvS7SPY6G2g==.TabIndex = 1;
		this.#=zjleUOmzfvS7SPY6G2g==.CellDoubleClick += this.#=z3yqY2w4c5ddZ$RXcwAIDlQI=;
		this.#=zjleUOmzfvS7SPY6G2g==.CellFormatting += this.#=z$XQ3SN52orxvu8e_mIf8JKg=;
		this.#=zjleUOmzfvS7SPY6G2g==.CellPainting += this.#=zHqRo_0Ga3kxH3hv2OOMlYRk=;
		this.#=z$VAevF7aSj_f.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030715);
		this.#=z$VAevF7aSj_f.Frozen = true;
		this.#=z$VAevF7aSj_f.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z$VAevF7aSj_f.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030715);
		this.#=z$VAevF7aSj_f.ReadOnly = true;
		this.#=z$VAevF7aSj_f.Width = 40;
		this.#=z5uFjnaLK2awf.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030700);
		this.#=z5uFjnaLK2awf.Frozen = true;
		this.#=z5uFjnaLK2awf.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=z5uFjnaLK2awf.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030700);
		this.#=z5uFjnaLK2awf.ReadOnly = true;
		this.#=z5uFjnaLK2awf.Width = 200;
		this.#=z6tEBDyT8gBRW.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030675);
		this.#=z6tEBDyT8gBRW.Frozen = true;
		this.#=z6tEBDyT8gBRW.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=z6tEBDyT8gBRW.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030675);
		this.#=z6tEBDyT8gBRW.ReadOnly = true;
		this.#=z2KYFUEwPIWbtyMnw0A==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030660);
		this.#=z2KYFUEwPIWbtyMnw0A==.Frozen = true;
		this.#=z2KYFUEwPIWbtyMnw0A==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=z2KYFUEwPIWbtyMnw0A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030660);
		this.#=z2KYFUEwPIWbtyMnw0A==.ReadOnly = true;
		this.#=zQ$PxeQwfwlmvGe63cA==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030895);
		this.#=zQ$PxeQwfwlmvGe63cA==.Frozen = true;
		this.#=zQ$PxeQwfwlmvGe63cA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909033104);
		this.#=zQ$PxeQwfwlmvGe63cA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030895);
		this.#=zQ$PxeQwfwlmvGe63cA==.ReadOnly = true;
		this.#=zQ$PxeQwfwlmvGe63cA==.Width = 70;
		this.#=zVBsL45$iFGnJcXxMAQ==.Controls.Add(this.#=z7SD$2jXVMnwApQc26A==);
		this.#=zVBsL45$iFGnJcXxMAQ==.Location = new Point(4, 22);
		this.#=zVBsL45$iFGnJcXxMAQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105101);
		this.#=zVBsL45$iFGnJcXxMAQ==.Size = new Size(976, 635);
		this.#=zVBsL45$iFGnJcXxMAQ==.TabIndex = 7;
		this.#=zVBsL45$iFGnJcXxMAQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017254);
		this.#=zVBsL45$iFGnJcXxMAQ==.UseVisualStyleBackColor = true;
		this.#=z7SD$2jXVMnwApQc26A==.AllowUserToAddRows = false;
		this.#=z7SD$2jXVMnwApQc26A==.AllowUserToDeleteRows = false;
		this.#=z7SD$2jXVMnwApQc26A==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z7SD$2jXVMnwApQc26A==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=ztvHmhoLLKIWa,
			this.#=z0TW5kwrfqT1H,
			this.#=zrfB9HXw$QaSq,
			this.#=zwYVd_aXsKJC$vBvo5U2Fth0=,
			this.#=zu7w4BToxW1MS,
			this.#=zHQ0bnhpKobIvd676NQ==,
			this.#=z1ITlnOFPxQQEbBwUCw==,
			this.#=zZ81N2hjpWhqBO4iIsw==,
			this.#=zs5So49DTwQJT,
			this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL,
			this.#=zKTFqqsoKUwHXXLRCVYHEuJQ=,
			this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw,
			this.#=zLIaWnglcqclD,
			this.#=zVBQK0e$6kjGWgMFjnw==,
			this.#=zf7$sVpi0Frvb$uyDNaovV8g=,
			this.#=zpcR1__GYhrNeiDD2JA==
		});
		this.#=z7SD$2jXVMnwApQc26A==.Dock = DockStyle.Fill;
		this.#=z7SD$2jXVMnwApQc26A==.Location = new Point(0, 0);
		this.#=z7SD$2jXVMnwApQc26A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909017230);
		this.#=z7SD$2jXVMnwApQc26A==.ReadOnly = true;
		this.#=z7SD$2jXVMnwApQc26A==.Size = new Size(976, 635);
		this.#=z7SD$2jXVMnwApQc26A==.TabIndex = 1;
		this.#=z7SD$2jXVMnwApQc26A==.CellDoubleClick += this.#=zAklP0VuLhTvcMKQPCOgD7EX5Ws_x;
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.Controls.Add(this.#=zNsR6nuPhYpLSssQsuMQHu3k=);
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.Location = new Point(4, 22);
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031400);
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.Size = new Size(976, 635);
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.TabIndex = 9;
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018993);
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.UseVisualStyleBackColor = true;
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Dock = DockStyle.Fill;
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.FixedPanel = FixedPanel.Panel1;
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Location = new Point(0, 0);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018972);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Orientation = Orientation.Horizontal;
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=z1AIzG94Rzno$51$e1A==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=z9aLgRmkb$ZtNM2KERA==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zCiVeqWIJriv1MyNqkw==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zmDPs7p4mTcjFcawRjw==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zQatKJhqXRdBGb5pLfw==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zaOVj7NUXHVXa_lsnS_x3IgI=);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=z6$cJklOc7Ns_NUTypg==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zurFiyy7v5_pWPGGq9w==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zLYSDjsc7OI1dNpspVQ==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zkQnB$JIroO_xWtOXeA==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zaCK$hOurVhT$IjLR$w==);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.Controls.Add(this.#=zfYBXYLciZnoZYBNZlHVJdNE=);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel2.Controls.Add(this.#=zabHK6Uca$1UUcGW9hapqX4s=);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Size = new Size(976, 635);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.SplitterDistance = 28;
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.TabIndex = 0;
		this.#=z1AIzG94Rzno$51$e1A==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=z1AIzG94Rzno$51$e1A==.FormattingEnabled = true;
		this.#=z1AIzG94Rzno$51$e1A==.Location = new Point(43, 3);
		this.#=z1AIzG94Rzno$51$e1A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018928);
		this.#=z1AIzG94Rzno$51$e1A==.Size = new Size(121, 21);
		this.#=z1AIzG94Rzno$51$e1A==.TabIndex = 0;
		this.#=z1AIzG94Rzno$51$e1A==.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=z9aLgRmkb$ZtNM2KERA==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=z9aLgRmkb$ZtNM2KERA==.FormattingEnabled = true;
		this.#=z9aLgRmkb$ZtNM2KERA==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909034450),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018905)
		});
		this.#=z9aLgRmkb$ZtNM2KERA==.Location = new Point(779, 3);
		this.#=z9aLgRmkb$ZtNM2KERA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018891);
		this.#=z9aLgRmkb$ZtNM2KERA==.Size = new Size(71, 21);
		this.#=z9aLgRmkb$ZtNM2KERA==.TabIndex = 0;
		this.#=z9aLgRmkb$ZtNM2KERA==.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=zCiVeqWIJriv1MyNqkw==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zCiVeqWIJriv1MyNqkw==.FormattingEnabled = true;
		this.#=zCiVeqWIJriv1MyNqkw==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909034450),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018905)
		});
		this.#=zCiVeqWIJriv1MyNqkw==.Location = new Point(652, 3);
		this.#=zCiVeqWIJriv1MyNqkw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019126);
		this.#=zCiVeqWIJriv1MyNqkw==.Size = new Size(71, 21);
		this.#=zCiVeqWIJriv1MyNqkw==.TabIndex = 0;
		this.#=zCiVeqWIJriv1MyNqkw==.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=zmDPs7p4mTcjFcawRjw==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zmDPs7p4mTcjFcawRjw==.FormattingEnabled = true;
		this.#=zmDPs7p4mTcjFcawRjw==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909034450),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018905)
		});
		this.#=zmDPs7p4mTcjFcawRjw==.Location = new Point(524, 3);
		this.#=zmDPs7p4mTcjFcawRjw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019103);
		this.#=zmDPs7p4mTcjFcawRjw==.Size = new Size(71, 21);
		this.#=zmDPs7p4mTcjFcawRjw==.TabIndex = 0;
		this.#=zmDPs7p4mTcjFcawRjw==.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=zQatKJhqXRdBGb5pLfw==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zQatKJhqXRdBGb5pLfw==.FormattingEnabled = true;
		this.#=zQatKJhqXRdBGb5pLfw==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909034450),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019066),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018905),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019050)
		});
		this.#=zQatKJhqXRdBGb5pLfw==.Location = new Point(371, 3);
		this.#=zQatKJhqXRdBGb5pLfw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019035);
		this.#=zQatKJhqXRdBGb5pLfw==.Size = new Size(91, 21);
		this.#=zQatKJhqXRdBGb5pLfw==.TabIndex = 0;
		this.#=zQatKJhqXRdBGb5pLfw==.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.FormattingEnabled = true;
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909034450),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019066),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018905),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019050)
		});
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.Location = new Point(234, 3);
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019008);
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.Size = new Size(91, 21);
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.TabIndex = 0;
		this.#=zaOVj7NUXHVXa_lsnS_x3IgI=.SelectedIndexChanged += this.#=zoCBfxcQ5e28zvuX9s0vD1Jg=;
		this.#=z6$cJklOc7Ns_NUTypg==.AutoSize = true;
		this.#=z6$cJklOc7Ns_NUTypg==.Location = new Point(8, 6);
		this.#=z6$cJklOc7Ns_NUTypg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018735);
		this.#=z6$cJklOc7Ns_NUTypg==.Size = new Size(40, 13);
		this.#=z6$cJklOc7Ns_NUTypg==.TabIndex = 1;
		this.#=z6$cJklOc7Ns_NUTypg==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107026);
		this.#=zurFiyy7v5_pWPGGq9w==.AutoSize = true;
		this.#=zurFiyy7v5_pWPGGq9w==.Location = new Point(729, 6);
		this.#=zurFiyy7v5_pWPGGq9w==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018705);
		this.#=zurFiyy7v5_pWPGGq9w==.Size = new Size(53, 13);
		this.#=zurFiyy7v5_pWPGGq9w==.TabIndex = 1;
		this.#=zurFiyy7v5_pWPGGq9w==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114688);
		this.#=zLYSDjsc7OI1dNpspVQ==.AutoSize = true;
		this.#=zLYSDjsc7OI1dNpspVQ==.Location = new Point(601, 6);
		this.#=zLYSDjsc7OI1dNpspVQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018681);
		this.#=zLYSDjsc7OI1dNpspVQ==.Size = new Size(47, 13);
		this.#=zLYSDjsc7OI1dNpspVQ==.TabIndex = 1;
		this.#=zLYSDjsc7OI1dNpspVQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018659);
		this.#=zkQnB$JIroO_xWtOXeA==.AutoSize = true;
		this.#=zkQnB$JIroO_xWtOXeA==.Location = new Point(468, 6);
		this.#=zkQnB$JIroO_xWtOXeA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018641);
		this.#=zkQnB$JIroO_xWtOXeA==.Size = new Size(44, 13);
		this.#=zkQnB$JIroO_xWtOXeA==.TabIndex = 1;
		this.#=zkQnB$JIroO_xWtOXeA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018873);
		this.#=zaCK$hOurVhT$IjLR$w==.AutoSize = true;
		this.#=zaCK$hOurVhT$IjLR$w==.Location = new Point(331, 6);
		this.#=zaCK$hOurVhT$IjLR$w==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018857);
		this.#=zaCK$hOurVhT$IjLR$w==.Size = new Size(42, 13);
		this.#=zaCK$hOurVhT$IjLR$w==.TabIndex = 1;
		this.#=zaCK$hOurVhT$IjLR$w==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018835);
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.AutoSize = true;
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.Location = new Point(170, 6);
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018829);
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.Size = new Size(43, 13);
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.TabIndex = 1;
		this.#=zfYBXYLciZnoZYBNZlHVJdNE=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018805);
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.AllowUserToAddRows = false;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.AllowUserToDeleteRows = false;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zlJY1CjBaS9I45VHeEw==,
			this.#=z9Km6khT5YwHU,
			this.#=zFst9mcVFtZSr,
			this.#=zshgTbuzO4Tw$En8rjTrod80=
		});
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Dock = DockStyle.Fill;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Location = new Point(0, 0);
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018789);
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.ReadOnly = true;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.RowHeadersVisible = false;
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.Size = new Size(976, 603);
		this.#=zabHK6Uca$1UUcGW9hapqX4s=.TabIndex = 2;
		this.#=zlJY1CjBaS9I45VHeEw==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030800);
		this.#=zlJY1CjBaS9I45VHeEw==.Frozen = true;
		this.#=zlJY1CjBaS9I45VHeEw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zlJY1CjBaS9I45VHeEw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030800);
		this.#=zlJY1CjBaS9I45VHeEw==.ReadOnly = true;
		this.#=zlJY1CjBaS9I45VHeEw==.Width = 40;
		this.#=z9Km6khT5YwHU.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030521);
		this.#=z9Km6khT5YwHU.Frozen = true;
		this.#=z9Km6khT5YwHU.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=z9Km6khT5YwHU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030521);
		this.#=z9Km6khT5YwHU.ReadOnly = true;
		this.#=z9Km6khT5YwHU.Width = 200;
		this.#=zFst9mcVFtZSr.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030496);
		this.#=zFst9mcVFtZSr.Frozen = true;
		this.#=zFst9mcVFtZSr.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zFst9mcVFtZSr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030496);
		this.#=zFst9mcVFtZSr.ReadOnly = true;
		this.#=zshgTbuzO4Tw$En8rjTrod80=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030473);
		this.#=zshgTbuzO4Tw$En8rjTrod80=.Frozen = true;
		this.#=zshgTbuzO4Tw$En8rjTrod80=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zshgTbuzO4Tw$En8rjTrod80=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030473);
		this.#=zshgTbuzO4Tw$En8rjTrod80=.ReadOnly = true;
		this.#=z7lM5Gvg64nk$.Controls.Add(this.#=znLGOdTN1PIm8);
		this.#=z7lM5Gvg64nk$.Location = new Point(4, 22);
		this.#=z7lM5Gvg64nk$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031370);
		this.#=z7lM5Gvg64nk$.Size = new Size(976, 635);
		this.#=z7lM5Gvg64nk$.TabIndex = 8;
		this.#=z7lM5Gvg64nk$.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018755);
		this.#=z7lM5Gvg64nk$.UseVisualStyleBackColor = true;
		this.#=znLGOdTN1PIm8.AllowUserToAddRows = false;
		this.#=znLGOdTN1PIm8.AllowUserToDeleteRows = false;
		this.#=znLGOdTN1PIm8.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=znLGOdTN1PIm8.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z581WG3yJjd$QcSWS9w==,
			this.#=zgi$iMShcWE_Y,
			this.#=zlb$cWh5$LwiE,
			this.#=z6zXY6kfjcCJmvTG7UwudJKw=
		});
		this.#=znLGOdTN1PIm8.Dock = DockStyle.Fill;
		this.#=znLGOdTN1PIm8.Location = new Point(0, 0);
		this.#=znLGOdTN1PIm8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018478);
		this.#=znLGOdTN1PIm8.ReadOnly = true;
		this.#=znLGOdTN1PIm8.RowHeadersVisible = false;
		this.#=znLGOdTN1PIm8.Size = new Size(976, 635);
		this.#=znLGOdTN1PIm8.TabIndex = 1;
		this.#=z581WG3yJjd$QcSWS9w==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030653);
		this.#=z581WG3yJjd$QcSWS9w==.Frozen = true;
		this.#=z581WG3yJjd$QcSWS9w==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z581WG3yJjd$QcSWS9w==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030653);
		this.#=z581WG3yJjd$QcSWS9w==.ReadOnly = true;
		this.#=z581WG3yJjd$QcSWS9w==.Width = 40;
		this.#=zgi$iMShcWE_Y.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030619);
		this.#=zgi$iMShcWE_Y.Frozen = true;
		this.#=zgi$iMShcWE_Y.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zgi$iMShcWE_Y.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030619);
		this.#=zgi$iMShcWE_Y.ReadOnly = true;
		this.#=zgi$iMShcWE_Y.Width = 200;
		this.#=zlb$cWh5$LwiE.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030595);
		this.#=zlb$cWh5$LwiE.Frozen = true;
		this.#=zlb$cWh5$LwiE.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zlb$cWh5$LwiE.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030595);
		this.#=zlb$cWh5$LwiE.ReadOnly = true;
		this.#=z6zXY6kfjcCJmvTG7UwudJKw=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030569);
		this.#=z6zXY6kfjcCJmvTG7UwudJKw=.Frozen = true;
		this.#=z6zXY6kfjcCJmvTG7UwudJKw=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=z6zXY6kfjcCJmvTG7UwudJKw=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030569);
		this.#=z6zXY6kfjcCJmvTG7UwudJKw=.ReadOnly = true;
		this.#=zJhDIJAu2fP_03Udvig==.Controls.Add(this.#=zRFIiZqS7tNfDxRt53Q==);
		this.#=zJhDIJAu2fP_03Udvig==.Location = new Point(4, 22);
		this.#=zJhDIJAu2fP_03Udvig==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031347);
		this.#=zJhDIJAu2fP_03Udvig==.Size = new Size(976, 635);
		this.#=zJhDIJAu2fP_03Udvig==.TabIndex = 10;
		this.#=zJhDIJAu2fP_03Udvig==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000401);
		this.#=zJhDIJAu2fP_03Udvig==.UseVisualStyleBackColor = true;
		this.#=zRFIiZqS7tNfDxRt53Q==.Dock = DockStyle.Fill;
		this.#=zRFIiZqS7tNfDxRt53Q==.FixedPanel = FixedPanel.Panel1;
		this.#=zRFIiZqS7tNfDxRt53Q==.Location = new Point(0, 0);
		this.#=zRFIiZqS7tNfDxRt53Q==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018452);
		this.#=zRFIiZqS7tNfDxRt53Q==.Orientation = Orientation.Horizontal;
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel1.Controls.Add(this.#=zIJQSf2M2bZ0NXacBaeu2tEc=);
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel1.Controls.Add(this.#=zOH2Q5_Bwr9tCScY_nA==);
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel2.Controls.Add(this.#=zcvJaRrlyndEr);
		this.#=zRFIiZqS7tNfDxRt53Q==.Size = new Size(976, 635);
		this.#=zRFIiZqS7tNfDxRt53Q==.SplitterDistance = 25;
		this.#=zRFIiZqS7tNfDxRt53Q==.TabIndex = 0;
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.AutoSize = true;
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Location = new Point(194, 5);
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018418);
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Size = new Size(300, 17);
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.TabIndex = 1;
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018396);
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.UseVisualStyleBackColor = true;
		this.#=zIJQSf2M2bZ0NXacBaeu2tEc=.CheckedChanged += this.#=zXghGq2SQm4769X59Eg==;
		this.#=zOH2Q5_Bwr9tCScY_nA==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zOH2Q5_Bwr9tCScY_nA==.FormattingEnabled = true;
		this.#=zOH2Q5_Bwr9tCScY_nA==.Location = new Point(3, 3);
		this.#=zOH2Q5_Bwr9tCScY_nA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018588);
		this.#=zOH2Q5_Bwr9tCScY_nA==.Size = new Size(185, 21);
		this.#=zOH2Q5_Bwr9tCScY_nA==.TabIndex = 0;
		this.#=zOH2Q5_Bwr9tCScY_nA==.SelectedIndexChanged += this.#=zXghGq2SQm4769X59Eg==;
		this.#=zcvJaRrlyndEr.AllowUserToAddRows = false;
		this.#=zcvJaRrlyndEr.AllowUserToDeleteRows = false;
		this.#=zcvJaRrlyndEr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zcvJaRrlyndEr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z1aNpETwxCzx$,
			this.#=zxekUdrhhPbq2,
			this.#=zlm5acezLlv8_,
			this.#=zWKSlVIRP5LeFaFdZrg==
		});
		this.#=zcvJaRrlyndEr.Dock = DockStyle.Fill;
		this.#=zcvJaRrlyndEr.Location = new Point(0, 0);
		this.#=zcvJaRrlyndEr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018554);
		this.#=zcvJaRrlyndEr.ReadOnly = true;
		this.#=zcvJaRrlyndEr.Size = new Size(976, 606);
		this.#=zcvJaRrlyndEr.TabIndex = 1;
		this.#=zcvJaRrlyndEr.CellContentDoubleClick += this.#=zYt2J_hTAtsblJt2bumFV5IsEJjry;
		this.#=zcvJaRrlyndEr.CellPainting += this.#=zHqRo_0Ga3kxH3hv2OOMlYRk=;
		this.#=z1aNpETwxCzx$.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032304);
		this.#=z1aNpETwxCzx$.Frozen = true;
		this.#=z1aNpETwxCzx$.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z1aNpETwxCzx$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032304);
		this.#=z1aNpETwxCzx$.ReadOnly = true;
		this.#=z1aNpETwxCzx$.Width = 40;
		this.#=zxekUdrhhPbq2.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032293);
		this.#=zxekUdrhhPbq2.Frozen = true;
		this.#=zxekUdrhhPbq2.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zxekUdrhhPbq2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032293);
		this.#=zxekUdrhhPbq2.ReadOnly = true;
		this.#=zxekUdrhhPbq2.Width = 150;
		this.#=zlm5acezLlv8_.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032264);
		this.#=zlm5acezLlv8_.Frozen = true;
		this.#=zlm5acezLlv8_.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zlm5acezLlv8_.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032264);
		this.#=zlm5acezLlv8_.ReadOnly = true;
		this.#=zWKSlVIRP5LeFaFdZrg==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032253);
		this.#=zWKSlVIRP5LeFaFdZrg==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zWKSlVIRP5LeFaFdZrg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032253);
		this.#=zWKSlVIRP5LeFaFdZrg==.ReadOnly = true;
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.Controls.Add(this.#=zc_YfxSsyTlXw_bP01SgjrF0=);
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.Location = new Point(4, 22);
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025829);
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.Size = new Size(976, 635);
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.TabIndex = 2;
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018538);
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.UseVisualStyleBackColor = true;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.AllowUserToAddRows = false;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.AllowUserToDeleteRows = false;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z7pX3KXxTMInJ,
			this.#=zFuqfpbGz8dRz,
			this.#=zDkLUtVh1qB4b,
			this.#=zZf3dOY$xxFlnL_66QQ==,
			this.#=zr_3P75ukRfH0gsIZrQ==,
			this.#=zKsN_mbN1j9T42HDbLA==,
			this.#=zcyFQ4smxtuOneGXmB5oKOh0=,
			this.#=zLBZriPAeVVDaWep773dlu7M=,
			this.#=zMSmpLjPI8aJP
		});
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Dock = DockStyle.Fill;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Location = new Point(0, 0);
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018526);
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.ReadOnly = true;
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.Size = new Size(976, 635);
		this.#=zc_YfxSsyTlXw_bP01SgjrF0=.TabIndex = 0;
		this.#=z7pX3KXxTMInJ.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=z7pX3KXxTMInJ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018496);
		this.#=z7pX3KXxTMInJ.ReadOnly = true;
		this.#=z7pX3KXxTMInJ.Width = 40;
		this.#=zFuqfpbGz8dRz.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zFuqfpbGz8dRz.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018229);
		this.#=zFuqfpbGz8dRz.ReadOnly = true;
		this.#=zFuqfpbGz8dRz.Width = 200;
		this.#=zDkLUtVh1qB4b.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zDkLUtVh1qB4b.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018200);
		this.#=zDkLUtVh1qB4b.ReadOnly = true;
		this.#=zZf3dOY$xxFlnL_66QQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zZf3dOY$xxFlnL_66QQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018189);
		this.#=zZf3dOY$xxFlnL_66QQ==.ReadOnly = true;
		this.#=zr_3P75ukRfH0gsIZrQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018164);
		this.#=zr_3P75ukRfH0gsIZrQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018148);
		this.#=zr_3P75ukRfH0gsIZrQ==.ReadOnly = true;
		this.#=zKsN_mbN1j9T42HDbLA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018121);
		this.#=zKsN_mbN1j9T42HDbLA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018358);
		this.#=zKsN_mbN1j9T42HDbLA==.ReadOnly = true;
		this.#=zcyFQ4smxtuOneGXmB5oKOh0=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018331);
		this.#=zcyFQ4smxtuOneGXmB5oKOh0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018296);
		this.#=zcyFQ4smxtuOneGXmB5oKOh0=.ReadOnly = true;
		this.#=zLBZriPAeVVDaWep773dlu7M=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018279);
		this.#=zLBZriPAeVVDaWep773dlu7M=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909018241);
		this.#=zLBZriPAeVVDaWep773dlu7M=.ReadOnly = true;
		this.#=zMSmpLjPI8aJP.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020014);
		this.#=zMSmpLjPI8aJP.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019999);
		this.#=zMSmpLjPI8aJP.ReadOnly = true;
		this.#=zMSmpLjPI8aJP.Width = 70;
		this.#=ztvHmhoLLKIWa.Frozen = true;
		this.#=ztvHmhoLLKIWa.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=ztvHmhoLLKIWa.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019980);
		this.#=ztvHmhoLLKIWa.ReadOnly = true;
		this.#=ztvHmhoLLKIWa.Width = 40;
		this.#=z0TW5kwrfqT1H.Frozen = true;
		this.#=z0TW5kwrfqT1H.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=z0TW5kwrfqT1H.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019957);
		this.#=z0TW5kwrfqT1H.ReadOnly = true;
		this.#=z0TW5kwrfqT1H.Width = 200;
		this.#=zrfB9HXw$QaSq.Frozen = true;
		this.#=zrfB9HXw$QaSq.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000189);
		this.#=zrfB9HXw$QaSq.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019932);
		this.#=zrfB9HXw$QaSq.ReadOnly = true;
		this.#=zwYVd_aXsKJC$vBvo5U2Fth0=.Frozen = true;
		this.#=zwYVd_aXsKJC$vBvo5U2Fth0=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zwYVd_aXsKJC$vBvo5U2Fth0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019909);
		this.#=zwYVd_aXsKJC$vBvo5U2Fth0=.ReadOnly = true;
		this.#=zu7w4BToxW1MS.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020128);
		this.#=zu7w4BToxW1MS.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020114);
		this.#=zu7w4BToxW1MS.ReadOnly = true;
		this.#=zu7w4BToxW1MS.Width = 60;
		this.#=zHQ0bnhpKobIvd676NQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020101);
		this.#=zHQ0bnhpKobIvd676NQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020084);
		this.#=zHQ0bnhpKobIvd676NQ==.ReadOnly = true;
		this.#=zHQ0bnhpKobIvd676NQ==.Width = 45;
		this.#=z1ITlnOFPxQQEbBwUCw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020062);
		this.#=z1ITlnOFPxQQEbBwUCw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020041);
		this.#=z1ITlnOFPxQQEbBwUCw==.ReadOnly = true;
		this.#=z1ITlnOFPxQQEbBwUCw==.Width = 45;
		this.#=zZ81N2hjpWhqBO4iIsw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019763);
		this.#=zZ81N2hjpWhqBO4iIsw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019746);
		this.#=zZ81N2hjpWhqBO4iIsw==.ReadOnly = true;
		this.#=zZ81N2hjpWhqBO4iIsw==.Width = 45;
		this.#=zs5So49DTwQJT.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019732);
		this.#=zs5So49DTwQJT.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019718);
		this.#=zs5So49DTwQJT.ReadOnly = true;
		this.#=zs5So49DTwQJT.Width = 60;
		this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031478);
		this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019689);
		this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031478);
		this.#=zy2ovpMIVO3oDK4PrcazoCWVOFeqL.ReadOnly = true;
		this.#=zKTFqqsoKUwHXXLRCVYHEuJQ=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031441);
		this.#=zKTFqqsoKUwHXXLRCVYHEuJQ=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019677);
		this.#=zKTFqqsoKUwHXXLRCVYHEuJQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031441);
		this.#=zKTFqqsoKUwHXXLRCVYHEuJQ=.ReadOnly = true;
		this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031676);
		this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019648);
		this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031676);
		this.#=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw.ReadOnly = true;
		this.#=zLIaWnglcqclD.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019895);
		this.#=zLIaWnglcqclD.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019877);
		this.#=zLIaWnglcqclD.ReadOnly = true;
		this.#=zVBQK0e$6kjGWgMFjnw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019844);
		this.#=zVBQK0e$6kjGWgMFjnw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019821);
		this.#=zVBQK0e$6kjGWgMFjnw==.ReadOnly = true;
		this.#=zf7$sVpi0Frvb$uyDNaovV8g=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019799);
		this.#=zf7$sVpi0Frvb$uyDNaovV8g=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019518);
		this.#=zf7$sVpi0Frvb$uyDNaovV8g=.ReadOnly = true;
		this.#=zpcR1__GYhrNeiDD2JA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019493);
		this.#=zpcR1__GYhrNeiDD2JA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019466);
		this.#=zpcR1__GYhrNeiDD2JA==.ReadOnly = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(984, 661);
		base.Controls.Add(this.#=z074tbnUPlILR);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019442);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909019426);
		((ISupportInitialize)this.#=zZNsIgSiN3rcd).EndInit();
		this.#=z074tbnUPlILR.ResumeLayout(false);
		this.#=z3wmUNWT30hY_eFuZEQ==.ResumeLayout(false);
		((ISupportInitialize)this.#=zpYdc9wLbs4vzwsVEDQ==).EndInit();
		this.#=zxddb4khjvuUB.ResumeLayout(false);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel1.ResumeLayout(false);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.ResumeLayout(false);
		this.#=zvwloAD8ACqS7XeuSJQ==.Panel2.PerformLayout();
		((ISupportInitialize)this.#=zvwloAD8ACqS7XeuSJQ==).EndInit();
		this.#=zvwloAD8ACqS7XeuSJQ==.ResumeLayout(false);
		this.#=zw$bU$0WaERNWkpebLA==.ResumeLayout(false);
		this.#=zicfg3xF9LLrdl98Mew==.Panel1.ResumeLayout(false);
		this.#=zicfg3xF9LLrdl98Mew==.Panel1.PerformLayout();
		this.#=zicfg3xF9LLrdl98Mew==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zicfg3xF9LLrdl98Mew==).EndInit();
		this.#=zicfg3xF9LLrdl98Mew==.ResumeLayout(false);
		((ISupportInitialize)this.#=zeGmBBtRdzwQaDMyyzg==).EndInit();
		this.#=zj8wAhu9Tmo1akbETvy6fbv4=.ResumeLayout(false);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel1.ResumeLayout(false);
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel1.PerformLayout();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zQ0oWyQww6uUo8ksUJVH0scM=).EndInit();
		this.#=zQ0oWyQww6uUo8ksUJVH0scM=.ResumeLayout(false);
		((ISupportInitialize)this.#=zFRKNWHxx__RQ8mqoeA==).EndInit();
		this.#=z16Jel6PtQHtF.ResumeLayout(false);
		((ISupportInitialize)this.#=z0jG8S8AqVomr).EndInit();
		this.#=z7o3v4I4gp1dBtVNYqw==.ResumeLayout(false);
		this.#=znHvi4qIC7e$zupRfOQ==.Panel1.ResumeLayout(false);
		this.#=znHvi4qIC7e$zupRfOQ==.Panel1.PerformLayout();
		this.#=znHvi4qIC7e$zupRfOQ==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=znHvi4qIC7e$zupRfOQ==).EndInit();
		this.#=znHvi4qIC7e$zupRfOQ==.ResumeLayout(false);
		((ISupportInitialize)this.#=zjleUOmzfvS7SPY6G2g==).EndInit();
		this.#=zVBsL45$iFGnJcXxMAQ==.ResumeLayout(false);
		((ISupportInitialize)this.#=z7SD$2jXVMnwApQc26A==).EndInit();
		this.#=zL9kGPbGMHSkEM95Dx$0$N4s=.ResumeLayout(false);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.ResumeLayout(false);
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel1.PerformLayout();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zNsR6nuPhYpLSssQsuMQHu3k=).EndInit();
		this.#=zNsR6nuPhYpLSssQsuMQHu3k=.ResumeLayout(false);
		((ISupportInitialize)this.#=zabHK6Uca$1UUcGW9hapqX4s=).EndInit();
		this.#=z7lM5Gvg64nk$.ResumeLayout(false);
		((ISupportInitialize)this.#=znLGOdTN1PIm8).EndInit();
		this.#=zJhDIJAu2fP_03Udvig==.ResumeLayout(false);
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel1.ResumeLayout(false);
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel1.PerformLayout();
		this.#=zRFIiZqS7tNfDxRt53Q==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zRFIiZqS7tNfDxRt53Q==).EndInit();
		this.#=zRFIiZqS7tNfDxRt53Q==.ResumeLayout(false);
		((ISupportInitialize)this.#=zcvJaRrlyndEr).EndInit();
		this.#=zfR73Ff_xOTcSYEdwnSPrAEM=.ResumeLayout(false);
		((ISupportInitialize)this.#=zc_YfxSsyTlXw_bP01SgjrF0=).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x04000645 RID: 1605
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000646 RID: 1606
	private #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM=;

	// Token: 0x04000647 RID: 1607
	private bool #=zZx2UAHg=;

	// Token: 0x04000648 RID: 1608
	private DataTable #=z1ngIMhSVPcYMncEZmQ==;

	// Token: 0x04000649 RID: 1609
	private int #=zY7eYiIm0C5XnEsSGag== = -1;

	// Token: 0x0400064A RID: 1610
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zIS1JRBk=;

	// Token: 0x0400064B RID: 1611
	private ResourceTypes #=zUBu0jHej6Kyf;

	// Token: 0x0400064C RID: 1612
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zcR$4j7Y=;

	// Token: 0x0400064D RID: 1613
	private ResourceTypes #=zjTxEhgo$UtS0;

	// Token: 0x0400064F RID: 1615
	private DataGridView #=zZNsIgSiN3rcd;

	// Token: 0x04000650 RID: 1616
	private TabControl #=z074tbnUPlILR;

	// Token: 0x04000651 RID: 1617
	private TabPage #=zxddb4khjvuUB;

	// Token: 0x04000652 RID: 1618
	private SplitContainer #=zvwloAD8ACqS7XeuSJQ==;

	// Token: 0x04000653 RID: 1619
	private Button #=zAyB_OD9fpzbJ;

	// Token: 0x04000654 RID: 1620
	private TextBox #=z5DnnYSvFhFxafulviw==;

	// Token: 0x04000655 RID: 1621
	private TextBox #=z1WgtJYpDe9uYCCReRg==;

	// Token: 0x04000656 RID: 1622
	private Label #=zxsXrETI$Iw8TbR37eA==;

	// Token: 0x04000657 RID: 1623
	private Label #=zpR0Be317xdaMSSA7Iw==;

	// Token: 0x04000658 RID: 1624
	private Label #=zre8RMFZgteCGIV_PKw==;

	// Token: 0x04000659 RID: 1625
	private Label #=zyG48KQl_i7vDV3BlrQ==;

	// Token: 0x0400065A RID: 1626
	private Button #=znfKxsCP9nS_q;

	// Token: 0x0400065B RID: 1627
	private TabPage #=zw$bU$0WaERNWkpebLA==;

	// Token: 0x0400065C RID: 1628
	private SplitContainer #=zicfg3xF9LLrdl98Mew==;

	// Token: 0x0400065D RID: 1629
	private DataGridView #=zeGmBBtRdzwQaDMyyzg==;

	// Token: 0x0400065E RID: 1630
	private TabPage #=zfR73Ff_xOTcSYEdwnSPrAEM=;

	// Token: 0x0400065F RID: 1631
	private DataGridView #=zc_YfxSsyTlXw_bP01SgjrF0=;

	// Token: 0x04000660 RID: 1632
	private TabPage #=z3wmUNWT30hY_eFuZEQ==;

	// Token: 0x04000661 RID: 1633
	private DataGridView #=zpYdc9wLbs4vzwsVEDQ==;

	// Token: 0x04000662 RID: 1634
	private DataGridViewTextBoxColumn #=zkFAIzI4=;

	// Token: 0x04000663 RID: 1635
	private DataGridViewTextBoxColumn #=zAjlrwOg=;

	// Token: 0x04000664 RID: 1636
	private DataGridViewTextBoxColumn #=zw0Xi_Go=;

	// Token: 0x04000665 RID: 1637
	private DataGridViewTextBoxColumn #=zCSlSIsKj0QW$Sespfg==;

	// Token: 0x04000666 RID: 1638
	private DataGridViewTextBoxColumn #=zvSPDEo7nIHc$;

	// Token: 0x04000667 RID: 1639
	private DataGridViewTextBoxColumn #=zu$LCDtxy$9Cf;

	// Token: 0x04000668 RID: 1640
	private DataGridViewTextBoxColumn #=zLVJhvveSDV4_;

	// Token: 0x04000669 RID: 1641
	private DataGridViewTextBoxColumn #=zzPiHySBDD7xVAl5_Qw==;

	// Token: 0x0400066A RID: 1642
	private DataGridViewTextBoxColumn #=z_63SqbMJ9d2OF$F4RA==;

	// Token: 0x0400066B RID: 1643
	private DataGridViewTextBoxColumn #=z$ck8H6_eLjWKM3dhRg==;

	// Token: 0x0400066C RID: 1644
	private TabPage #=zj8wAhu9Tmo1akbETvy6fbv4=;

	// Token: 0x0400066D RID: 1645
	private DataGridView #=zFRKNWHxx__RQ8mqoeA==;

	// Token: 0x0400066E RID: 1646
	private TabPage #=z16Jel6PtQHtF;

	// Token: 0x0400066F RID: 1647
	private DataGridView #=z0jG8S8AqVomr;

	// Token: 0x04000670 RID: 1648
	private TabPage #=z7o3v4I4gp1dBtVNYqw==;

	// Token: 0x04000671 RID: 1649
	private DataGridView #=zjleUOmzfvS7SPY6G2g==;

	// Token: 0x04000672 RID: 1650
	private SplitContainer #=znHvi4qIC7e$zupRfOQ==;

	// Token: 0x04000673 RID: 1651
	private Label #=zpj8mPFS3y42jM$LUstbOm$w=;

	// Token: 0x04000674 RID: 1652
	private ComboBox #=zBNF4Yh3wT7O770UcmA==;

	// Token: 0x04000675 RID: 1653
	private TabPage #=zVBsL45$iFGnJcXxMAQ==;

	// Token: 0x04000676 RID: 1654
	private DataGridView #=z7SD$2jXVMnwApQc26A==;

	// Token: 0x04000677 RID: 1655
	private TabPage #=z7lM5Gvg64nk$;

	// Token: 0x04000678 RID: 1656
	private DataGridView #=znLGOdTN1PIm8;

	// Token: 0x04000679 RID: 1657
	private TabPage #=zL9kGPbGMHSkEM95Dx$0$N4s=;

	// Token: 0x0400067A RID: 1658
	private SplitContainer #=zNsR6nuPhYpLSssQsuMQHu3k=;

	// Token: 0x0400067B RID: 1659
	private Label #=zfYBXYLciZnoZYBNZlHVJdNE=;

	// Token: 0x0400067C RID: 1660
	private ComboBox #=zaOVj7NUXHVXa_lsnS_x3IgI=;

	// Token: 0x0400067D RID: 1661
	private Label #=z6$cJklOc7Ns_NUTypg==;

	// Token: 0x0400067E RID: 1662
	private ComboBox #=z1AIzG94Rzno$51$e1A==;

	// Token: 0x0400067F RID: 1663
	private Label #=zaCK$hOurVhT$IjLR$w==;

	// Token: 0x04000680 RID: 1664
	private ComboBox #=zQatKJhqXRdBGb5pLfw==;

	// Token: 0x04000681 RID: 1665
	private Label #=zkQnB$JIroO_xWtOXeA==;

	// Token: 0x04000682 RID: 1666
	private ComboBox #=zmDPs7p4mTcjFcawRjw==;

	// Token: 0x04000683 RID: 1667
	private Label #=zurFiyy7v5_pWPGGq9w==;

	// Token: 0x04000684 RID: 1668
	private ComboBox #=z9aLgRmkb$ZtNM2KERA==;

	// Token: 0x04000685 RID: 1669
	private DataGridView #=zabHK6Uca$1UUcGW9hapqX4s=;

	// Token: 0x04000686 RID: 1670
	private TabPage #=zJhDIJAu2fP_03Udvig==;

	// Token: 0x04000687 RID: 1671
	private SplitContainer #=zRFIiZqS7tNfDxRt53Q==;

	// Token: 0x04000688 RID: 1672
	private DataGridView #=zcvJaRrlyndEr;

	// Token: 0x04000689 RID: 1673
	private ComboBox #=zOH2Q5_Bwr9tCScY_nA==;

	// Token: 0x0400068A RID: 1674
	private CheckBox #=zIJQSf2M2bZ0NXacBaeu2tEc=;

	// Token: 0x0400068B RID: 1675
	private CheckBox #=zivg1eompdcozp3S8Zv303Kvr5P17;

	// Token: 0x0400068C RID: 1676
	private ComboBox #=zCiVeqWIJriv1MyNqkw==;

	// Token: 0x0400068D RID: 1677
	private Label #=zLYSDjsc7OI1dNpspVQ==;

	// Token: 0x0400068E RID: 1678
	private DataGridViewTextBoxColumn #=z$Xw6g9ZO7YXI;

	// Token: 0x0400068F RID: 1679
	private DataGridViewTextBoxColumn #=zQaTBSjQ=;

	// Token: 0x04000690 RID: 1680
	private DataGridViewTextBoxColumn #=z5LRkrWs=;

	// Token: 0x04000691 RID: 1681
	private DataGridViewTextBoxColumn #=z9c11xNatBnFF5N2g6A==;

	// Token: 0x04000692 RID: 1682
	private DataGridViewTextBoxColumn #=z_OTaSW88t7Pc;

	// Token: 0x04000693 RID: 1683
	private DataGridViewTextBoxColumn #=zR7GVwIuUs8aL;

	// Token: 0x04000694 RID: 1684
	private DataGridViewTextBoxColumn #=zjTaI5$CYaqUA;

	// Token: 0x04000695 RID: 1685
	private DataGridViewTextBoxColumn #=zrjVm6P_TPO33G5OXBC6Zo4g=;

	// Token: 0x04000696 RID: 1686
	private DataGridViewTextBoxColumn #=z$VAevF7aSj_f;

	// Token: 0x04000697 RID: 1687
	private DataGridViewTextBoxColumn #=z5uFjnaLK2awf;

	// Token: 0x04000698 RID: 1688
	private DataGridViewTextBoxColumn #=z6tEBDyT8gBRW;

	// Token: 0x04000699 RID: 1689
	private DataGridViewTextBoxColumn #=z2KYFUEwPIWbtyMnw0A==;

	// Token: 0x0400069A RID: 1690
	private DataGridViewTextBoxColumn #=zQ$PxeQwfwlmvGe63cA==;

	// Token: 0x0400069B RID: 1691
	private DataGridViewTextBoxColumn #=zlJY1CjBaS9I45VHeEw==;

	// Token: 0x0400069C RID: 1692
	private DataGridViewTextBoxColumn #=z9Km6khT5YwHU;

	// Token: 0x0400069D RID: 1693
	private DataGridViewTextBoxColumn #=zFst9mcVFtZSr;

	// Token: 0x0400069E RID: 1694
	private DataGridViewTextBoxColumn #=zshgTbuzO4Tw$En8rjTrod80=;

	// Token: 0x0400069F RID: 1695
	private DataGridViewTextBoxColumn #=z581WG3yJjd$QcSWS9w==;

	// Token: 0x040006A0 RID: 1696
	private DataGridViewTextBoxColumn #=zgi$iMShcWE_Y;

	// Token: 0x040006A1 RID: 1697
	private DataGridViewTextBoxColumn #=zlb$cWh5$LwiE;

	// Token: 0x040006A2 RID: 1698
	private DataGridViewTextBoxColumn #=z6zXY6kfjcCJmvTG7UwudJKw=;

	// Token: 0x040006A3 RID: 1699
	private DataGridViewTextBoxColumn #=z1aNpETwxCzx$;

	// Token: 0x040006A4 RID: 1700
	private DataGridViewTextBoxColumn #=zxekUdrhhPbq2;

	// Token: 0x040006A5 RID: 1701
	private DataGridViewTextBoxColumn #=zlm5acezLlv8_;

	// Token: 0x040006A6 RID: 1702
	private DataGridViewTextBoxColumn #=zWKSlVIRP5LeFaFdZrg==;

	// Token: 0x040006A7 RID: 1703
	private DataGridViewTextBoxColumn #=zY_YlM1_$tbCL;

	// Token: 0x040006A8 RID: 1704
	private DataGridViewTextBoxColumn #=zQiUI8p4=;

	// Token: 0x040006A9 RID: 1705
	private DataGridViewTextBoxColumn #=z81RDCEQ=;

	// Token: 0x040006AA RID: 1706
	private DataGridViewTextBoxColumn #=zYDCaWosdbwDQ0aLQEw==;

	// Token: 0x040006AB RID: 1707
	private DataGridViewTextBoxColumn #=z3XZyQeAJ4jSu9Mc71A==;

	// Token: 0x040006AC RID: 1708
	private DataGridViewTextBoxColumn #=zv3ObmmggvhcJlvMZaw==;

	// Token: 0x040006AD RID: 1709
	private DataGridViewTextBoxColumn #=zF$4fV_rTrQYB;

	// Token: 0x040006AE RID: 1710
	private DataGridViewTextBoxColumn #=zVQUY6XTRzcI3;

	// Token: 0x040006AF RID: 1711
	private DataGridViewTextBoxColumn #=zZzjQFMCtaf1jABaeJA==;

	// Token: 0x040006B0 RID: 1712
	private DataGridViewTextBoxColumn #=zcSflGDqZPj8L;

	// Token: 0x040006B1 RID: 1713
	private DataGridViewTextBoxColumn #=zgcppYQE=;

	// Token: 0x040006B2 RID: 1714
	private DataGridViewTextBoxColumn #=zK_vWxukBpkp$;

	// Token: 0x040006B3 RID: 1715
	private DataGridViewTextBoxColumn #=z2WNGtpR1pO98idpJAlxUfAI=;

	// Token: 0x040006B4 RID: 1716
	private DataGridViewTextBoxColumn #=zt3$CI$BUuE4vPNg6Yg==;

	// Token: 0x040006B5 RID: 1717
	private DataGridViewTextBoxColumn #=z7pX3KXxTMInJ;

	// Token: 0x040006B6 RID: 1718
	private DataGridViewTextBoxColumn #=zFuqfpbGz8dRz;

	// Token: 0x040006B7 RID: 1719
	private DataGridViewTextBoxColumn #=zDkLUtVh1qB4b;

	// Token: 0x040006B8 RID: 1720
	private DataGridViewTextBoxColumn #=zZf3dOY$xxFlnL_66QQ==;

	// Token: 0x040006B9 RID: 1721
	private DataGridViewTextBoxColumn #=zr_3P75ukRfH0gsIZrQ==;

	// Token: 0x040006BA RID: 1722
	private DataGridViewTextBoxColumn #=zKsN_mbN1j9T42HDbLA==;

	// Token: 0x040006BB RID: 1723
	private DataGridViewTextBoxColumn #=zcyFQ4smxtuOneGXmB5oKOh0=;

	// Token: 0x040006BC RID: 1724
	private DataGridViewTextBoxColumn #=zLBZriPAeVVDaWep773dlu7M=;

	// Token: 0x040006BD RID: 1725
	private DataGridViewTextBoxColumn #=zMSmpLjPI8aJP;

	// Token: 0x040006BE RID: 1726
	private SplitContainer #=zQ0oWyQww6uUo8ksUJVH0scM=;

	// Token: 0x040006BF RID: 1727
	private ComboBox #=zq7P0VUHHSH9KPcgblP9TnpwZXOmx;

	// Token: 0x040006C0 RID: 1728
	private Label #=zgcPWZro7CgNxk6h6C9gb4g0=;

	// Token: 0x040006C1 RID: 1729
	private DataGridViewTextBoxColumn #=zVawsfpBkPs_L;

	// Token: 0x040006C2 RID: 1730
	private DataGridViewTextBoxColumn #=zWk_lQs4=;

	// Token: 0x040006C3 RID: 1731
	private DataGridViewTextBoxColumn #=zLbIWwH4=;

	// Token: 0x040006C4 RID: 1732
	private DataGridViewTextBoxColumn #=z2FtN3UBCZGsJEp9lZA==;

	// Token: 0x040006C5 RID: 1733
	private DataGridViewTextBoxColumn #=zHGuwrLNOLipu;

	// Token: 0x040006C6 RID: 1734
	private DataGridViewTextBoxColumn #=zkO5rA6YVFV2r;

	// Token: 0x040006C7 RID: 1735
	private DataGridViewTextBoxColumn #=zFWJIoBGaiBBR;

	// Token: 0x040006C8 RID: 1736
	private DataGridViewTextBoxColumn #=zISjl5WvgZGhL;

	// Token: 0x040006C9 RID: 1737
	private DataGridViewTextBoxColumn #=zhNan9QwoGcVT;

	// Token: 0x040006CA RID: 1738
	private DataGridViewTextBoxColumn #=zC4zlobQWKp5T;

	// Token: 0x040006CB RID: 1739
	private DataGridViewTextBoxColumn #=ztvY90dYlKK1D;

	// Token: 0x040006CC RID: 1740
	private DataGridViewTextBoxColumn #=z1Y48OG54qP$d;

	// Token: 0x040006CD RID: 1741
	private DataGridViewTextBoxColumn #=zhZ2XWLWVQYmU;

	// Token: 0x040006CE RID: 1742
	private DataGridViewTextBoxColumn #=zSGL_BdxXkYpd;

	// Token: 0x040006CF RID: 1743
	private DataGridViewTextBoxColumn #=z2KNMLHVb35f8;

	// Token: 0x040006D0 RID: 1744
	private DataGridViewTextBoxColumn #=zu1paaFeRfNdw;

	// Token: 0x040006D1 RID: 1745
	private DataGridViewTextBoxColumn #=zFuq_0ht20kLo;

	// Token: 0x040006D2 RID: 1746
	private DataGridViewTextBoxColumn #=zGuIAs3Szl2Jy;

	// Token: 0x040006D3 RID: 1747
	private Button #=zT8IjvlxB8Vy$vWiSIw==;

	// Token: 0x040006D4 RID: 1748
	private DataGridViewTextBoxColumn #=ztvHmhoLLKIWa;

	// Token: 0x040006D5 RID: 1749
	private DataGridViewTextBoxColumn #=z0TW5kwrfqT1H;

	// Token: 0x040006D6 RID: 1750
	private DataGridViewTextBoxColumn #=zrfB9HXw$QaSq;

	// Token: 0x040006D7 RID: 1751
	private DataGridViewTextBoxColumn #=zwYVd_aXsKJC$vBvo5U2Fth0=;

	// Token: 0x040006D8 RID: 1752
	private DataGridViewTextBoxColumn #=zu7w4BToxW1MS;

	// Token: 0x040006D9 RID: 1753
	private DataGridViewTextBoxColumn #=zHQ0bnhpKobIvd676NQ==;

	// Token: 0x040006DA RID: 1754
	private DataGridViewTextBoxColumn #=z1ITlnOFPxQQEbBwUCw==;

	// Token: 0x040006DB RID: 1755
	private DataGridViewTextBoxColumn #=zZ81N2hjpWhqBO4iIsw==;

	// Token: 0x040006DC RID: 1756
	private DataGridViewTextBoxColumn #=zs5So49DTwQJT;

	// Token: 0x040006DD RID: 1757
	private DataGridViewTextBoxColumn #=zy2ovpMIVO3oDK4PrcazoCWVOFeqL;

	// Token: 0x040006DE RID: 1758
	private DataGridViewTextBoxColumn #=zKTFqqsoKUwHXXLRCVYHEuJQ=;

	// Token: 0x040006DF RID: 1759
	private DataGridViewTextBoxColumn #=zjaso$ZeuFOeBHmrdhR3MpNyM7Flw;

	// Token: 0x040006E0 RID: 1760
	private DataGridViewTextBoxColumn #=zLIaWnglcqclD;

	// Token: 0x040006E1 RID: 1761
	private DataGridViewTextBoxColumn #=zVBQK0e$6kjGWgMFjnw==;

	// Token: 0x040006E2 RID: 1762
	private DataGridViewTextBoxColumn #=zf7$sVpi0Frvb$uyDNaovV8g=;

	// Token: 0x040006E3 RID: 1763
	private DataGridViewTextBoxColumn #=zpcR1__GYhrNeiDD2JA==;

	// Token: 0x02000198 RID: 408
	public struct #=z7hJ6i1zzJqTTtc4VGQ== : IComparable
	{
		// Token: 0x06000BEE RID: 3054 RVA: 0x00061C0C File Offset: 0x0005FE0C
		public #=z7hJ6i1zzJqTTtc4VGQ==(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=zxHIOVSaavkpE, bool #=zjnRuGUguqRffvIaYMQ==)
		{
			this.#=zDGA38Z8= = #=zxHIOVSaavkpE.#=zXnLDg7kAwVWx();
			this.#=zm$$6GcTgGbEA = #=zxHIOVSaavkpE.#=zmo5ghO3ieFGdSjD7kA==();
			this.#=zRmNm1IYgbdoYbDVahg== = #=zjnRuGUguqRffvIaYMQ==;
		}

		// Token: 0x06000BEF RID: 3055 RVA: 0x00061C30 File Offset: 0x0005FE30
		public int CompareTo(object #=zhB0nV3k=)
		{
			if (#=zhB0nV3k= is #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=z7hJ6i1zzJqTTtc4VGQ==)
			{
				return this.#=zDGA38Z8=.CompareTo(((#=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=z7hJ6i1zzJqTTtc4VGQ==)#=zhB0nV3k=).#=zDGA38Z8=);
			}
			return 0;
		}

		// Token: 0x06000BF0 RID: 3056 RVA: 0x00061C54 File Offset: 0x0005FE54
		public override string ToString()
		{
			if (this.#=zRmNm1IYgbdoYbDVahg== && this.#=zm$$6GcTgGbEA > 0)
			{
				return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909031224), this.#=zDGA38Z8=, this.#=zm$$6GcTgGbEA);
			}
			return this.#=zDGA38Z8=.ToString();
		}

		// Token: 0x040006E4 RID: 1764
		public int #=zDGA38Z8=;

		// Token: 0x040006E5 RID: 1765
		public int #=zm$$6GcTgGbEA;

		// Token: 0x040006E6 RID: 1766
		public bool #=zRmNm1IYgbdoYbDVahg==;
	}

	// Token: 0x02000199 RID: 409
	private sealed class #=zojkgZZIGc9OEdN9KMb5Uryw=
	{
		// Token: 0x06000BF2 RID: 3058 RVA: 0x00061CAC File Offset: 0x0005FEAC
		internal bool #=zymSLvx2HQlIqX_vXDVS5iuA=(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return this.#=zTVuos6ESv9WY.#=z0gRgrrIGr5L_().Contains(#=zQrqFdos=.#=zMuFMjGQ=());
		}

		// Token: 0x040006E7 RID: 1767
		public #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zTVuos6ESv9WY;
	}

	// Token: 0x0200019A RID: 410
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000BF5 RID: 3061 RVA: 0x00061CD8 File Offset: 0x0005FED8
		internal int #=zkqK33Qp06VC$ZKGvpN1C1zePlxaJ7u9qLDQbxvl$WWQz(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=zm8PpuDU=, #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=zcltuPyw=)
		{
			return #=zcltuPyw=.#=zlIXJ9$NfUZc_().CompareTo(#=zm8PpuDU=.#=zlIXJ9$NfUZc_());
		}

		// Token: 0x040006E8 RID: 1768
		public static readonly #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zyDNvciU= #=zLkw0NRU= = new #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR.#=zyDNvciU=();

		// Token: 0x040006E9 RID: 1769
		public static Comparison<#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==> #=z_hWAzCY8HFeEOSSZgg==;
	}
}
