﻿using System;

// Token: 0x020000F0 RID: 240
internal sealed class #=zFHWlB3$fq6BNH8yTMAvTKsscE8r3lkLecn9KINQ= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000644 RID: 1604 RVA: 0x000325B8 File Offset: 0x000307B8
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zWmtYEqo= = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=z0l3cFRQ=(this.#=z8StzeqE=);
		this.#=zWmtYEqo=.#=z20ohAjI=(this.#=z8StzeqE=, #=zuJjQ1XU=);
	}

	// Token: 0x06000645 RID: 1605 RVA: 0x000325E0 File Offset: 0x000307E0
	protected override void #=zvb5bnug=()
	{
		bool flag;
		this.#=zWmtYEqo=.#=zPp7Q6VI=(out flag);
		if (flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973389), Array.Empty<object>());
			#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=z1Wntp_4=(this.#=z8StzeqE=);
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsPerformInitiation = false;
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
		}
	}

	// Token: 0x04000294 RID: 660
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=zWmtYEqo=;
}
