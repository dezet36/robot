﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001C7 RID: 455
internal sealed class #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== : List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=>
{
	// Token: 0x06000D73 RID: 3443 RVA: 0x00068FD0 File Offset: 0x000671D0
	public #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==(string #=z$TdW2M0rjcG2blHRaA==)
	{
		this.#=zL2Ho5VsPDIrVRuCSzw==(#=z$TdW2M0rjcG2blHRaA==);
	}

	// Token: 0x06000D74 RID: 3444 RVA: 0x00068FE0 File Offset: 0x000671E0
	public #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==(string #=z$TdW2M0rjcG2blHRaA==, string #=zXvnc_Gc=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		if (!string.IsNullOrEmpty(#=zXvnc_Gc=))
		{
			try
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zXvnc_Gc=);
				Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873349));
				string a = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873072), string.Empty);
				this.#=zL2Ho5VsPDIrVRuCSzw==(#=z$TdW2M0rjcG2blHRaA==);
				this.#=zODlZZHvR90va(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873058), 0));
				this.#=zXD1iEriRZj5W(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873049), 0));
				this.#=zEXxx_c0yushxlv6t9w==((a == this.#=zgHLyH4jfK0lrG8NoLA==()) ? JSONManager.UserStringToDate(JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873044), string.Empty)) : DateTime.MinValue);
				this.#=z70541YBK1YJMhjNxqjvtBLY=(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873028), 0));
				this.#=zSiEqujcwstLt50qjDCEAnqU=(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873009), 0));
				if (this.#=zm$eV_xKe0$husB8mphQFSSA=() == 0 && this.#=zTbIA4C5CygIVRWnmzW7mz0Y=() == 0 && #=z8StzeqE=.#=zjV_wsuvJ0R_B() != null)
				{
					this.#=z70541YBK1YJMhjNxqjvtBLY=(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==());
					this.#=zSiEqujcwstLt50qjDCEAnqU=(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==());
				}
				object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872994));
				List<int> list = new List<int>();
				for (int i = 0; i < array.Length; i++)
				{
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = new #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=((Dictionary<string, object>)array[i], #=z8StzeqE=, #=zSJY$s3o=);
					if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=() > 0 && !list.Contains(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()))
					{
						base.Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
						list.Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=());
					}
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				string text = (#=z8StzeqE= != null) ? #=z8StzeqE=.#=zdEt_WRHpdEMmGTK_3Q==() : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066527);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872988), new object[]
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873193),
					text
				}));
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
		}
	}

	// Token: 0x06000D75 RID: 3445 RVA: 0x000691D4 File Offset: 0x000673D4
	public string #=zgHLyH4jfK0lrG8NoLA==()
	{
		return this.#=zFm$MkdjbV4i2g69rV5xCFON9qw4g;
	}

	// Token: 0x06000D76 RID: 3446 RVA: 0x000691DC File Offset: 0x000673DC
	private void #=zL2Ho5VsPDIrVRuCSzw==(string #=z$Ib9gYQ=)
	{
		this.#=zFm$MkdjbV4i2g69rV5xCFON9qw4g = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D77 RID: 3447 RVA: 0x000691E8 File Offset: 0x000673E8
	public int #=zItiY1kgj0ZFJ()
	{
		return this.#=zNNhrZ2RGPFTFPshTBFRrB68=;
	}

	// Token: 0x06000D78 RID: 3448 RVA: 0x000691F0 File Offset: 0x000673F0
	public void #=zODlZZHvR90va(int #=z$Ib9gYQ=)
	{
		this.#=zNNhrZ2RGPFTFPshTBFRrB68= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D79 RID: 3449 RVA: 0x000691FC File Offset: 0x000673FC
	public int #=zRo77rEs$ZyU6()
	{
		return this.#=zRq6k9kTGxd395AcxXf6cgHo=;
	}

	// Token: 0x06000D7A RID: 3450 RVA: 0x00069204 File Offset: 0x00067404
	public void #=zXD1iEriRZj5W(int #=z$Ib9gYQ=)
	{
		this.#=zRq6k9kTGxd395AcxXf6cgHo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D7B RID: 3451 RVA: 0x00069210 File Offset: 0x00067410
	public DateTime #=zLtwfFiMhuJDkTP6cew==()
	{
		return this.#=z7g59ritwcQ0SoZuWpFi5KJ8=;
	}

	// Token: 0x06000D7C RID: 3452 RVA: 0x00069218 File Offset: 0x00067418
	private void #=zEXxx_c0yushxlv6t9w==(DateTime #=z$Ib9gYQ=)
	{
		this.#=z7g59ritwcQ0SoZuWpFi5KJ8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D7D RID: 3453 RVA: 0x00069224 File Offset: 0x00067424
	public int #=zm$eV_xKe0$husB8mphQFSSA=()
	{
		return this.#=zj_Kaw0SY2vn1jKzCw1Aj0vu39Zj_;
	}

	// Token: 0x06000D7E RID: 3454 RVA: 0x0006922C File Offset: 0x0006742C
	public void #=z70541YBK1YJMhjNxqjvtBLY=(int #=z$Ib9gYQ=)
	{
		this.#=zj_Kaw0SY2vn1jKzCw1Aj0vu39Zj_ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D7F RID: 3455 RVA: 0x00069238 File Offset: 0x00067438
	public int #=zTbIA4C5CygIVRWnmzW7mz0Y=()
	{
		return this.#=zARQ_JVgJFdK0oja$hcgPwowa$cUk;
	}

	// Token: 0x06000D80 RID: 3456 RVA: 0x00069240 File Offset: 0x00067440
	public void #=zSiEqujcwstLt50qjDCEAnqU=(int #=z$Ib9gYQ=)
	{
		this.#=zARQ_JVgJFdK0oja$hcgPwowa$cUk = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D81 RID: 3457 RVA: 0x0006924C File Offset: 0x0006744C
	public bool #=zNXUG8XbJFWN8mht01A==()
	{
		return this.#=zgVNvpTttGJFl2SkfFF_ACUk=;
	}

	// Token: 0x06000D82 RID: 3458 RVA: 0x00069254 File Offset: 0x00067454
	public void #=zsobh2arZ__ufEqVOvA==(bool #=z$Ib9gYQ=)
	{
		this.#=zgVNvpTttGJFl2SkfFF_ACUk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D83 RID: 3459 RVA: 0x00069260 File Offset: 0x00067460
	public Dictionary<string, object> #=zh4f6s4TyRiwr()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873072)] = this.#=zgHLyH4jfK0lrG8NoLA==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873058)] = this.#=zItiY1kgj0ZFJ();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873049)] = this.#=zRo77rEs$ZyU6();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873044)] = JSONManager.DateToUserString(this.#=zLtwfFiMhuJDkTP6cew==());
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873028)] = this.#=zm$eV_xKe0$husB8mphQFSSA=();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873009)] = this.#=zTbIA4C5CygIVRWnmzW7mz0Y=();
		return dictionary;
	}

	// Token: 0x06000D84 RID: 3460 RVA: 0x00069310 File Offset: 0x00067510
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		Dictionary<string, object> value = this.#=zh4f6s4TyRiwr();
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873349), value);
		object[] array = new object[base.Count];
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872994), array);
		for (int i = 0; i < base.Count; i++)
		{
			array[i] = base[i].#=zhv7OhlM=();
		}
		return dictionary;
	}

	// Token: 0x06000D85 RID: 3461 RVA: 0x0006937C File Offset: 0x0006757C
	public override string ToString()
	{
		return JSONManager.SerializeData(this.#=zhv7OhlM=());
	}

	// Token: 0x06000D86 RID: 3462 RVA: 0x0006938C File Offset: 0x0006758C
	public #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x06000D87 RID: 3463 RVA: 0x000693C4 File Offset: 0x000675C4
	public void #=zW3vXs9Q=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zODlZZHvR90va(0);
		this.#=zXD1iEriRZj5W(0);
		this.#=zEXxx_c0yushxlv6t9w==(DateTime.Now);
		this.#=z70541YBK1YJMhjNxqjvtBLY=(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==());
		this.#=zSiEqujcwstLt50qjDCEAnqU=(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==());
		this.#=zsobh2arZ__ufEqVOvA==(true);
		#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873162), Array.Empty<object>());
	}

	// Token: 0x06000D88 RID: 3464 RVA: 0x00069430 File Offset: 0x00067630
	public void #=z4jMUBqOjoL$2(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, bool #=z6HbTWYF1cpty)
	{
		if (#=z6HbTWYF1cpty)
		{
			base.Clear();
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873117), Array.Empty<object>());
		}
		else
		{
			for (int i = base.Count - 1; i >= 0; i--)
			{
				if (!base[i].#=zu_rEcX_K9l9O())
				{
					base.RemoveAt(i);
				}
			}
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872813), Array.Empty<object>());
		}
		this.#=zW3vXs9Q=(#=z8StzeqE=);
	}

	// Token: 0x040007B7 RID: 1975
	private string #=zFm$MkdjbV4i2g69rV5xCFON9qw4g;

	// Token: 0x040007B8 RID: 1976
	private int #=zNNhrZ2RGPFTFPshTBFRrB68=;

	// Token: 0x040007B9 RID: 1977
	private int #=zRq6k9kTGxd395AcxXf6cgHo=;

	// Token: 0x040007BA RID: 1978
	private DateTime #=z7g59ritwcQ0SoZuWpFi5KJ8=;

	// Token: 0x040007BB RID: 1979
	private int #=zj_Kaw0SY2vn1jKzCw1Aj0vu39Zj_;

	// Token: 0x040007BC RID: 1980
	private int #=zARQ_JVgJFdK0oja$hcgPwowa$cUk;

	// Token: 0x040007BD RID: 1981
	private bool #=zgVNvpTttGJFl2SkfFF_ACUk=;
}
