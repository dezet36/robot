﻿// Token: 0x02000277 RID: 631
internal sealed partial class #=zkoPM2trZEqBA6NpuZYtG_oD_66_1amKM9Q== : global::System.Windows.Forms.Form
{
	// Token: 0x06001318 RID: 4888 RVA: 0x00094398 File Offset: 0x00092598
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000B02 RID: 2818
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
