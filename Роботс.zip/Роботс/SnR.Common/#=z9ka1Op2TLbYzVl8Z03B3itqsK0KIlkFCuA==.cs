﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x020000B7 RID: 183
internal sealed class #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== : IComparable
{
	// Token: 0x060004C9 RID: 1225 RVA: 0x00027BA0 File Offset: 0x00025DA0
	private #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==()
	{
	}

	// Token: 0x060004CA RID: 1226 RVA: 0x00027BA8 File Offset: 0x00025DA8
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x00027BB0 File Offset: 0x00025DB0
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x00027BBC File Offset: 0x00025DBC
	public EmporiaTypes #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x00027BC4 File Offset: 0x00025DC4
	public void #=zzQwUIEs=(EmporiaTypes #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x00027BD0 File Offset: 0x00025DD0
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x00027BD8 File Offset: 0x00025DD8
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x00027BE4 File Offset: 0x00025DE4
	public int #=zfTB62qendhk_VEy8rw==()
	{
		return this.#=zuCoBS22$SHwioNCsSm1KoiA=;
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x00027BEC File Offset: 0x00025DEC
	public void #=zHD9M6IxBLboIezSsHQ==(int #=z$Ib9gYQ=)
	{
		this.#=zuCoBS22$SHwioNCsSm1KoiA= = #=z$Ib9gYQ=;
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x00027BF8 File Offset: 0x00025DF8
	public int #=zY0soxphmGIACbOHy6A==()
	{
		return this.#=zAZaEN2rHjtRHI7RjIU6YTJk=;
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x00027C00 File Offset: 0x00025E00
	public void #=z2WdNm_CMtqBR6ukyUw==(int #=z$Ib9gYQ=)
	{
		this.#=zAZaEN2rHjtRHI7RjIU6YTJk= = #=z$Ib9gYQ=;
	}

	// Token: 0x060004D4 RID: 1236 RVA: 0x00027C0C File Offset: 0x00025E0C
	public int #=zjfs8R6GBNpnXKfCf$w==()
	{
		return this.#=zAU3AIQxjRUAbZSLk9bLO0wAThWF7;
	}

	// Token: 0x060004D5 RID: 1237 RVA: 0x00027C14 File Offset: 0x00025E14
	public void #=zLQodyCzWWOU90IubNg==(int #=z$Ib9gYQ=)
	{
		this.#=zAU3AIQxjRUAbZSLk9bLO0wAThWF7 = #=z$Ib9gYQ=;
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x00027C20 File Offset: 0x00025E20
	public double #=zOLm8URDKXOUZ()
	{
		return this.#=zGlxGl0c9m2DzUFbijw==;
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x00027C28 File Offset: 0x00025E28
	public void #=zS_NrfNGJyGZG(double #=z$Ib9gYQ=)
	{
		this.#=zGlxGl0c9m2DzUFbijw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004D8 RID: 1240 RVA: 0x00027C34 File Offset: 0x00025E34
	public bool #=z$NyihN71ouQU()
	{
		return this.#=zq2bPTdY=() == EmporiaTypes.FutureCurrency;
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x00027C44 File Offset: 0x00025E44
	public static #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== #=zi1hFJwI=(Dictionary<string, object> #=zk656SlQ=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== result;
		try
		{
			if (!#=zk656SlQ=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)))
			{
				result = null;
			}
			else if (!(#=zk656SlQ=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)] is Dictionary<string, object>))
			{
				result = null;
			}
			else
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)#=zk656SlQ=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)];
				if (!dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)))
				{
					result = null;
				}
				else
				{
					if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)) && dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)) && #=z8StzeqE= != null)
					{
						if (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)]) > #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zvnZc$RhG_1Du())
						{
							return null;
						}
						if (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]) < #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zvnZc$RhG_1Du())
						{
							return null;
						}
					}
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== = new #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==();
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zbsxKkj4=(Convert.ToInt32(#=zk656SlQ=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zzQwUIEs=((EmporiaTypes)Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zwXKUV2c=(JSONManager.ExtractString(#=zk656SlQ=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), string.Empty));
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)#=zk656SlQ=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)];
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zHD9M6IxBLboIezSsHQ==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]));
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=z2WdNm_CMtqBR6ukyUw==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]));
					if (#=zk656SlQ=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)))
					{
						#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zLQodyCzWWOU90IubNg==(Convert.ToInt32(#=zk656SlQ=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)]));
					}
					else
					{
						#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zLQodyCzWWOU90IubNg==(0);
					}
					if (#=z8StzeqE= != null)
					{
						#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zS_NrfNGJyGZG(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOnM0lrc=((double)#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zfTB62qendhk_VEy8rw==(), (double)#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zY0soxphmGIACbOHy6A==(), (double)#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), (double)#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==()));
					}
					else
					{
						#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zS_NrfNGJyGZG(0.0);
					}
					result = #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==;
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			if (#=z8StzeqE= == null)
			{
				throw;
			}
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			result = null;
		}
		return result;
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x00027E88 File Offset: 0x00026088
	public static ResourceTypes #=zDAYSHyA=(EmporiaTypes #=z1BOZKmyDOR$eTt8jJQ==)
	{
		switch (#=z1BOZKmyDOR$eTt8jJQ==)
		{
		case EmporiaTypes.Grain:
			return ResourceTypes.Grain;
		case EmporiaTypes.Bronze:
			return ResourceTypes.Bronze;
		case EmporiaTypes.Lumber:
			return ResourceTypes.Lumber;
		case EmporiaTypes.Gold:
			return ResourceTypes.Gold;
		case EmporiaTypes.Denaries:
			return ResourceTypes.Denaries;
		case EmporiaTypes.FutureCurrency:
			return ResourceTypes.FutureCurrency;
		case EmporiaTypes.Glory:
			return ResourceTypes.Glory;
		}
		return ResourceTypes.Unknown;
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x00027EC8 File Offset: 0x000260C8
	public int CompareTo(object #=ze8bSiug=)
	{
		if (#=ze8bSiug= != null && #=ze8bSiug= is #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==)
		{
			if ((#=ze8bSiug= as #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==).#=zOLm8URDKXOUZ() > this.#=zOLm8URDKXOUZ())
			{
				return -1;
			}
			if ((#=ze8bSiug= as #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==).#=zOLm8URDKXOUZ() < this.#=zOLm8URDKXOUZ())
			{
				return 1;
			}
		}
		return 0;
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x00027F00 File Offset: 0x00026100
	public override string ToString()
	{
		if (string.IsNullOrEmpty(this.#=zkfqcY3I=()))
		{
			return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070458), this.#=zq2bPTdY=(), this.#=zfTB62qendhk_VEy8rw==(), this.#=zY0soxphmGIACbOHy6A==());
		}
		return this.#=zkfqcY3I=();
	}

	// Token: 0x040001D6 RID: 470
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040001D7 RID: 471
	private EmporiaTypes #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040001D8 RID: 472
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040001D9 RID: 473
	private int #=zuCoBS22$SHwioNCsSm1KoiA=;

	// Token: 0x040001DA RID: 474
	private int #=zAZaEN2rHjtRHI7RjIU6YTJk=;

	// Token: 0x040001DB RID: 475
	private int #=zAU3AIQxjRUAbZSLk9bLO0wAThWF7;

	// Token: 0x040001DC RID: 476
	private double #=zGlxGl0c9m2DzUFbijw==;
}
