﻿using System;
using System.Text;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000106 RID: 262
internal sealed class #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA== : RecordData
{
	// Token: 0x060006D5 RID: 1749 RVA: 0x00039A84 File Offset: 0x00037C84
	public #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA==(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zcTvfij8= = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
		this.#=zkrqqXYw= = data[5];
		this.#=zbE6cQTcn9vzu = data[4];
		this.#=z7HqoPh0= = (int)data[6];
		if (data[7] == 0)
		{
			sbyte[] array = new sbyte[this.#=z7HqoPh0=];
			Array.Copy(data, 8, array, 0, this.#=z7HqoPh0=);
			this.#=z6QPrZ_4= = new string(#=zRl61TBSNfLrgIyYfRA==.#=zhYXm8L7UMnjW(#=zRl61TBSNfLrgIyYfRA==.#=zhg1f_CEyF7Jk(array)));
			return;
		}
		sbyte[] array2 = new sbyte[this.#=z7HqoPh0= * 2];
		Array.Copy(data, 8, array2, 0, this.#=z7HqoPh0= * 2);
		try
		{
			byte[] bytes = #=zRl61TBSNfLrgIyYfRA==.#=zhg1f_CEyF7Jk(array2);
			Encoding unicode = Encoding.Unicode;
			this.#=z6QPrZ_4= = unicode.GetString(bytes);
		}
		catch (Exception)
		{
			this.#=z6QPrZ_4= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075221);
		}
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x00039B70 File Offset: 0x00037D70
	public #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA==(Record #=zJce$Sys=, #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA==.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zcTvfij8= = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
		this.#=zkrqqXYw= = data[5];
		this.#=zbE6cQTcn9vzu = data[4];
		this.#=z7HqoPh0= = (int)data[6];
		sbyte[] array = new sbyte[this.#=z7HqoPh0=];
		Array.Copy(data, 7, array, 0, this.#=z7HqoPh0=);
		this.#=z6QPrZ_4= = new string(#=zRl61TBSNfLrgIyYfRA==.#=zhYXm8L7UMnjW(#=zRl61TBSNfLrgIyYfRA==.#=zhg1f_CEyF7Jk(array)));
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x00039C00 File Offset: 0x00037E00
	public string #=zkfqcY3I=()
	{
		return this.#=z6QPrZ_4=;
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x00039C08 File Offset: 0x00037E08
	public bool #=zs65y49g=()
	{
		return this.#=zbE6cQTcn9vzu != 0;
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x00039C14 File Offset: 0x00037E14
	public bool #=zH_VC72g=()
	{
		return this.#=zkrqqXYw= == 0;
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x00039C20 File Offset: 0x00037E20
	public bool #=zIb7E1Ji9WPvU()
	{
		return this.#=zkrqqXYw= == 2;
	}

	// Token: 0x040003F5 RID: 1013
	private int #=zcTvfij8=;

	// Token: 0x040003F6 RID: 1014
	private sbyte #=zkrqqXYw=;

	// Token: 0x040003F7 RID: 1015
	private sbyte #=zbE6cQTcn9vzu;

	// Token: 0x040003F8 RID: 1016
	private int #=z7HqoPh0=;

	// Token: 0x040003F9 RID: 1017
	private string #=z6QPrZ_4=;

	// Token: 0x040003FA RID: 1018
	public static #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA==.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz = new #=zI8G84AH0YnEjlrPAB0Io_Y_cX4oJ1ZpSvA==.#=zlfjpmgW14u47();

	// Token: 0x02000107 RID: 263
	public sealed class #=zlfjpmgW14u47
	{
	}
}
