﻿using System;
using System.Runtime.InteropServices;
using Skink.SnR.Common.GZip;

// Token: 0x0200011E RID: 286
[Guid("ebc25cf6-9120-4283-b972-0e5520d0000D")]
[ComVisible(true)]
[ClassInterface(ClassInterfaceType.AutoDispatch)]
internal sealed class #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=
{
	// Token: 0x060006EE RID: 1774 RVA: 0x00039EC4 File Offset: 0x000380C4
	public #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=()
	{
	}

	// Token: 0x060006EF RID: 1775 RVA: 0x00039EDC File Offset: 0x000380DC
	public #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=(CompressionMode #=zZ6hesjQ=)
	{
		if (#=zZ6hesjQ= == CompressionMode.Compress)
		{
			if (this.#=zXgM3SNq1Zylk() != 0)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065079));
			}
		}
		else
		{
			if (#=zZ6hesjQ= != CompressionMode.Decompress)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065005));
			}
			if (this.#=zdtZWlb0YWO6XjySgaw==() != 0)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065032));
			}
		}
	}

	// Token: 0x060006F0 RID: 1776 RVA: 0x00039F48 File Offset: 0x00038148
	public int #=zAm8NrMyoWbnSbFDPqw==()
	{
		return (int)this.#=z4A2fn4O2tDlTs77BiA==;
	}

	// Token: 0x060006F1 RID: 1777 RVA: 0x00039F50 File Offset: 0x00038150
	public int #=zdtZWlb0YWO6XjySgaw==()
	{
		return this.#=zdtZWlb0YWO6XjySgaw==(this.#=zRv1qFrE=);
	}

	// Token: 0x060006F2 RID: 1778 RVA: 0x00039F60 File Offset: 0x00038160
	public int #=zdtZWlb0YWO6XjySgaw==(bool #=zxabLXUXZxmaxW0KIsQ==)
	{
		return this.#=zdtZWlb0YWO6XjySgaw==(this.#=zRv1qFrE=, #=zxabLXUXZxmaxW0KIsQ==);
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x00039F70 File Offset: 0x00038170
	public int #=zdtZWlb0YWO6XjySgaw==(int #=zGRpGdBZE2aZz)
	{
		this.#=zRv1qFrE= = #=zGRpGdBZE2aZz;
		return this.#=zdtZWlb0YWO6XjySgaw==(#=zGRpGdBZE2aZz, true);
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x00039F84 File Offset: 0x00038184
	public int #=zdtZWlb0YWO6XjySgaw==(int #=zGRpGdBZE2aZz, bool #=zxabLXUXZxmaxW0KIsQ==)
	{
		this.#=zRv1qFrE= = #=zGRpGdBZE2aZz;
		if (this.#=zlUgwGfK7z66f != null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064973));
		}
		this.#=z$QjciwI= = new #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=(#=zxabLXUXZxmaxW0KIsQ==);
		return this.#=z$QjciwI=.#=z1jlGMrg=(this, #=zGRpGdBZE2aZz);
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x00039FC0 File Offset: 0x000381C0
	public int #=zlJv54NpQwKIa(FlushType #=zmhpr6mQ=)
	{
		if (this.#=z$QjciwI= == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065151));
		}
		return this.#=z$QjciwI=.#=zlJv54NpQwKIa(#=zmhpr6mQ=);
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x00039FE8 File Offset: 0x000381E8
	public int #=zQ70TW76HUgSSd3E9pg==()
	{
		if (this.#=z$QjciwI= == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065151));
		}
		int result = this.#=z$QjciwI=.#=zhjKhhfc=();
		this.#=z$QjciwI= = null;
		return result;
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x0003A014 File Offset: 0x00038214
	public int #=zVluTzitphKIvy3yjVQ==()
	{
		if (this.#=z$QjciwI= == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065151));
		}
		return this.#=z$QjciwI=.#=zz2dSKkA=();
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x0003A03C File Offset: 0x0003823C
	public int #=zXgM3SNq1Zylk()
	{
		return this.#=zu1Go5N5GNIvW(true);
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x0003A048 File Offset: 0x00038248
	public int #=zXgM3SNq1Zylk(CompressionLevel #=z5w6HcG4=)
	{
		this.#=zN2ceq6ml8P5E = #=z5w6HcG4=;
		return this.#=zu1Go5N5GNIvW(true);
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x0003A058 File Offset: 0x00038258
	public int #=zXgM3SNq1Zylk(CompressionLevel #=z5w6HcG4=, bool #=zD9RhjlTnZ10PZZ2ZHw==)
	{
		this.#=zN2ceq6ml8P5E = #=z5w6HcG4=;
		return this.#=zu1Go5N5GNIvW(#=zD9RhjlTnZ10PZZ2ZHw==);
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x0003A068 File Offset: 0x00038268
	public int #=zXgM3SNq1Zylk(CompressionLevel #=z5w6HcG4=, int #=zGyL$Taw=)
	{
		this.#=zN2ceq6ml8P5E = #=z5w6HcG4=;
		this.#=zRv1qFrE= = #=zGyL$Taw=;
		return this.#=zu1Go5N5GNIvW(true);
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x0003A080 File Offset: 0x00038280
	public int #=zXgM3SNq1Zylk(CompressionLevel #=z5w6HcG4=, int #=zGyL$Taw=, bool #=zD9RhjlTnZ10PZZ2ZHw==)
	{
		this.#=zN2ceq6ml8P5E = #=z5w6HcG4=;
		this.#=zRv1qFrE= = #=zGyL$Taw=;
		return this.#=zu1Go5N5GNIvW(#=zD9RhjlTnZ10PZZ2ZHw==);
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x0003A098 File Offset: 0x00038298
	private int #=zu1Go5N5GNIvW(bool #=zD9RhjlTnZ10PZZ2ZHw==)
	{
		if (this.#=z$QjciwI= != null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065127));
		}
		this.#=zlUgwGfK7z66f = new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==();
		this.#=zlUgwGfK7z66f.#=zCNkYni0Ubaaxpcnd2wEb0eQ=(#=zD9RhjlTnZ10PZZ2ZHw==);
		return this.#=zlUgwGfK7z66f.#=z1jlGMrg=(this, this.#=zN2ceq6ml8P5E, this.#=zRv1qFrE=, this.#=zmVI4x4w=);
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x0003A0F4 File Offset: 0x000382F4
	public int #=zYdo2_SU=(FlushType #=zmhpr6mQ=)
	{
		if (this.#=zlUgwGfK7z66f == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064785));
		}
		return this.#=zlUgwGfK7z66f.#=zYdo2_SU=(#=zmhpr6mQ=);
	}

	// Token: 0x060006FF RID: 1791 RVA: 0x0003A11C File Offset: 0x0003831C
	public int #=zgC46X9w=()
	{
		if (this.#=zlUgwGfK7z66f == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064785));
		}
		this.#=zlUgwGfK7z66f = null;
		return 0;
	}

	// Token: 0x06000700 RID: 1792 RVA: 0x0003A140 File Offset: 0x00038340
	public void #=zBBBodkJm6iyQ()
	{
		if (this.#=zlUgwGfK7z66f == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064785));
		}
		this.#=zlUgwGfK7z66f.#=zW3vXs9Q=();
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x0003A168 File Offset: 0x00038368
	public int #=zGoAdK4ibPNmO(CompressionLevel #=z5w6HcG4=, CompressionStrategy #=zDz_4k2s=)
	{
		if (this.#=zlUgwGfK7z66f == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064785));
		}
		return this.#=zlUgwGfK7z66f.#=zg$5DrSs=(#=z5w6HcG4=, #=zDz_4k2s=);
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x0003A190 File Offset: 0x00038390
	public int #=zv4DxgDs=(byte[] #=zrnw7iZQ=)
	{
		if (this.#=z$QjciwI= != null)
		{
			return this.#=z$QjciwI=.#=zv4DxgDs=(#=zrnw7iZQ=);
		}
		if (this.#=zlUgwGfK7z66f != null)
		{
			return this.#=zlUgwGfK7z66f.#=zv4DxgDs=(#=zrnw7iZQ=);
		}
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064761));
	}

	// Token: 0x06000703 RID: 1795 RVA: 0x0003A1CC File Offset: 0x000383CC
	internal void #=zRTRWkVe6uyyf()
	{
		int #=zr2hx6oQ= = this.#=zlUgwGfK7z66f.#=zr2hx6oQ=;
		if (#=zr2hx6oQ= > this.#=zRQNIMvX_JmPR)
		{
			#=zr2hx6oQ= = this.#=zRQNIMvX_JmPR;
		}
		if (#=zr2hx6oQ= == 0)
		{
			return;
		}
		if (this.#=zlUgwGfK7z66f.#=zgG3ckmc=.Length <= this.#=zlUgwGfK7z66f.#=zElex9Ew9marJ || this.#=zTkQEpCPgqFwZ.Length <= this.#=z6v5OUYo= || this.#=zlUgwGfK7z66f.#=zgG3ckmc=.Length < this.#=zlUgwGfK7z66f.#=zElex9Ew9marJ + #=zr2hx6oQ= || this.#=zTkQEpCPgqFwZ.Length < this.#=z6v5OUYo= + #=zr2hx6oQ=)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064732), this.#=zlUgwGfK7z66f.#=zgG3ckmc=.Length, this.#=zlUgwGfK7z66f.#=zr2hx6oQ=));
		}
		Array.Copy(this.#=zlUgwGfK7z66f.#=zgG3ckmc=, this.#=zlUgwGfK7z66f.#=zElex9Ew9marJ, this.#=zTkQEpCPgqFwZ, this.#=z6v5OUYo=, #=zr2hx6oQ=);
		this.#=z6v5OUYo= += #=zr2hx6oQ=;
		this.#=zlUgwGfK7z66f.#=zElex9Ew9marJ += #=zr2hx6oQ=;
		this.#=z0KaacqESNJ$P += (long)#=zr2hx6oQ=;
		this.#=zRQNIMvX_JmPR -= #=zr2hx6oQ=;
		this.#=zlUgwGfK7z66f.#=zr2hx6oQ= -= #=zr2hx6oQ=;
		if (this.#=zlUgwGfK7z66f.#=zr2hx6oQ= == 0)
		{
			this.#=zlUgwGfK7z66f.#=zElex9Ew9marJ = 0;
		}
	}

	// Token: 0x06000704 RID: 1796 RVA: 0x0003A31C File Offset: 0x0003851C
	internal int #=zaMVRYPCY4H95(byte[] #=zXvwCnz8=, int #=z1qaC5B0=, int #=zOrpuKXA=)
	{
		int num = this.#=zEVNP$$evg7c3;
		if (num > #=zOrpuKXA=)
		{
			num = #=zOrpuKXA=;
		}
		if (num == 0)
		{
			return 0;
		}
		this.#=zEVNP$$evg7c3 -= num;
		if (this.#=zlUgwGfK7z66f.#=zt6$Qbs5KfMCNZF2kvCnMhQs=())
		{
			this.#=z4A2fn4O2tDlTs77BiA== = Adler.Adler32(this.#=z4A2fn4O2tDlTs77BiA==, this.#=zJtQJROi1bLs0, this.#=z_f$vhX8=, num);
		}
		Array.Copy(this.#=zJtQJROi1bLs0, this.#=z_f$vhX8=, #=zXvwCnz8=, #=z1qaC5B0=, num);
		this.#=z_f$vhX8= += num;
		this.#=zX85$ivfbdo86 += (long)num;
		return num;
	}

	// Token: 0x0400041E RID: 1054
	public byte[] #=zJtQJROi1bLs0;

	// Token: 0x0400041F RID: 1055
	public int #=z_f$vhX8=;

	// Token: 0x04000420 RID: 1056
	public int #=zEVNP$$evg7c3;

	// Token: 0x04000421 RID: 1057
	public long #=zX85$ivfbdo86;

	// Token: 0x04000422 RID: 1058
	public byte[] #=zTkQEpCPgqFwZ;

	// Token: 0x04000423 RID: 1059
	public int #=z6v5OUYo=;

	// Token: 0x04000424 RID: 1060
	public int #=zRQNIMvX_JmPR;

	// Token: 0x04000425 RID: 1061
	public long #=z0KaacqESNJ$P;

	// Token: 0x04000426 RID: 1062
	public string #=znwxGN8g=;

	// Token: 0x04000427 RID: 1063
	internal #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA== #=zlUgwGfK7z66f;

	// Token: 0x04000428 RID: 1064
	internal #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ= #=z$QjciwI=;

	// Token: 0x04000429 RID: 1065
	internal uint #=z4A2fn4O2tDlTs77BiA==;

	// Token: 0x0400042A RID: 1066
	public CompressionLevel #=zN2ceq6ml8P5E = CompressionLevel.Default;

	// Token: 0x0400042B RID: 1067
	public int #=zRv1qFrE= = 15;

	// Token: 0x0400042C RID: 1068
	public CompressionStrategy #=zmVI4x4w=;
}
