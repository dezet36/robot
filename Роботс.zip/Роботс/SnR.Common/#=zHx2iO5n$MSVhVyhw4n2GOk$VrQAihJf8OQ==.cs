﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000105 RID: 261
internal sealed class #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==
{
	// Token: 0x060006D0 RID: 1744 RVA: 0x000399FC File Offset: 0x00037BFC
	public #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==(Dictionary<string, object> #=z8o_NL1M=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=z8o_NL1M=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zsgA3OSuTiUzU(JSONManager.ExtractDate(#=z8o_NL1M=, #=z8o_NL1M=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), false));
	}

	// Token: 0x060006D1 RID: 1745 RVA: 0x00039A5C File Offset: 0x00037C5C
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060006D2 RID: 1746 RVA: 0x00039A64 File Offset: 0x00037C64
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060006D3 RID: 1747 RVA: 0x00039A70 File Offset: 0x00037C70
	public DateTime #=z0qIeBNbFCDl6()
	{
		return this.#=z9OBgZaClLR6aBEcXVTv3vKw=;
	}

	// Token: 0x060006D4 RID: 1748 RVA: 0x00039A78 File Offset: 0x00037C78
	public void #=zsgA3OSuTiUzU(DateTime #=z$Ib9gYQ=)
	{
		this.#=z9OBgZaClLR6aBEcXVTv3vKw= = #=z$Ib9gYQ=;
	}

	// Token: 0x040003F3 RID: 1011
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040003F4 RID: 1012
	private DateTime #=z9OBgZaClLR6aBEcXVTv3vKw=;
}
