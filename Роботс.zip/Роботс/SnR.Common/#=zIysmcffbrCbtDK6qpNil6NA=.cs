﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000123 RID: 291
internal abstract class #=zIysmcffbrCbtDK6qpNil6NA= : RecordData
{
	// Token: 0x06000731 RID: 1841 RVA: 0x0003C850 File Offset: 0x0003AA50
	protected internal #=zIysmcffbrCbtDK6qpNil6NA=(Type #=zJce$Sys=, Record #=zihyUFzs=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zihyUFzs=.Data;
		this.#=zTeRQh78= = DoubleHelper.getIEEEDouble(data, 0);
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x0003C878 File Offset: 0x0003AA78
	internal virtual double #=ze8CeOJ6eHljC()
	{
		return this.#=zTeRQh78=;
	}

	// Token: 0x04000458 RID: 1112
	private double #=zTeRQh78=;
}
