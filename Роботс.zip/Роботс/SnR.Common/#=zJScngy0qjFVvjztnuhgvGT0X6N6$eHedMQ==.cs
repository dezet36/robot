﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.City;

// Token: 0x0200012C RID: 300
internal sealed class #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== : Dictionary<ResourceTypes, int>
{
	// Token: 0x06000765 RID: 1893 RVA: 0x0003D0A8 File Offset: 0x0003B2A8
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==()
	{
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x0003D0B0 File Offset: 0x0003B2B0
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==(object #=z3I$mcTTQXW9z)
	{
		if (#=z3I$mcTTQXW9z != null && #=z3I$mcTTQXW9z is Dictionary<string, object>)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)#=z3I$mcTTQXW9z;
			foreach (string text in dictionary.Keys)
			{
				int num = Convert.ToInt32(dictionary[text]);
				if (num > 0)
				{
					this[#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zsJJ$G_g=(text)] = num;
				}
			}
		}
	}

	// Token: 0x17000020 RID: 32
	[IndexerName("#=zx6APBRk=")]
	public int this[ResourceTypes #=zvRLj9WQ=]
	{
		get
		{
			if (!base.ContainsKey(#=zvRLj9WQ=))
			{
				return 0;
			}
			return base[#=zvRLj9WQ=];
		}
		set
		{
			base[#=zvRLj9WQ=] = value;
		}
	}

	// Token: 0x06000769 RID: 1897 RVA: 0x0003D154 File Offset: 0x0003B354
	public void #=z48rEd0A=(ResourceTypes #=zvRLj9WQ=, int #=zNvCMwussKumm)
	{
		if (base.ContainsKey(#=zvRLj9WQ=))
		{
			base[#=zvRLj9WQ=] += #=zNvCMwussKumm;
			return;
		}
		base[#=zvRLj9WQ=] = #=zNvCMwussKumm;
	}

	// Token: 0x0600076A RID: 1898 RVA: 0x0003D178 File Offset: 0x0003B378
	public void #=z48rEd0A=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zhVK$tWjWY1YVgZsIRQ==)
	{
		foreach (ResourceTypes #=zvRLj9WQ= in #=zhVK$tWjWY1YVgZsIRQ==.Keys)
		{
			this.#=z48rEd0A=(#=zvRLj9WQ=, #=zhVK$tWjWY1YVgZsIRQ==[#=zvRLj9WQ=]);
		}
	}

	// Token: 0x0600076B RID: 1899 RVA: 0x0003D1D4 File Offset: 0x0003B3D4
	public void #=zWyy2M2Q=(ResourceTypes #=zvRLj9WQ=, int #=zNvCMwussKumm)
	{
		if (base.ContainsKey(#=zvRLj9WQ=))
		{
			int num = base[#=zvRLj9WQ=];
			if (num > #=zNvCMwussKumm)
			{
				base[#=zvRLj9WQ=] = num - #=zNvCMwussKumm;
				return;
			}
			base.Remove(#=zvRLj9WQ=);
		}
	}

	// Token: 0x0600076C RID: 1900 RVA: 0x0003D20C File Offset: 0x0003B40C
	public bool #=znxdqlEM=(ResourceTypes #=zvRLj9WQ=, int #=zNvCMwussKumm)
	{
		if (!base.ContainsKey(#=zvRLj9WQ=))
		{
			return false;
		}
		int num = base[#=zvRLj9WQ=];
		if (num > #=zNvCMwussKumm)
		{
			base[#=zvRLj9WQ=] = num - #=zNvCMwussKumm;
			return true;
		}
		if (num == #=zNvCMwussKumm)
		{
			base.Remove(#=zvRLj9WQ=);
			return true;
		}
		return false;
	}

	// Token: 0x0600076D RID: 1901 RVA: 0x0003D24C File Offset: 0x0003B44C
	public bool #=znxdqlEM=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z$qwv5Z285_NAhqObtA==, int #=zfgHlV2dubgWU6FX2FA==)
	{
		bool flag = true;
		foreach (KeyValuePair<ResourceTypes, int> keyValuePair in #=z$qwv5Z285_NAhqObtA==)
		{
			if (!base.ContainsKey(keyValuePair.Key))
			{
				flag = false;
				break;
			}
			if (base[keyValuePair.Key] < keyValuePair.Value * #=zfgHlV2dubgWU6FX2FA==)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			foreach (KeyValuePair<ResourceTypes, int> keyValuePair2 in #=z$qwv5Z285_NAhqObtA==)
			{
				int num = base[keyValuePair2.Key];
				int num2 = keyValuePair2.Value * #=zfgHlV2dubgWU6FX2FA==;
				if (num > num2)
				{
					base[keyValuePair2.Key] = num - num2;
				}
				else
				{
					base.Remove(keyValuePair2.Key);
				}
			}
			return true;
		}
		return false;
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x0003D340 File Offset: 0x0003B540
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zTnMGkyA=()
	{
		#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== = new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==();
		foreach (KeyValuePair<ResourceTypes, int> keyValuePair in this)
		{
			#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==.#=z48rEd0A=(keyValuePair.Key, keyValuePair.Value);
		}
		return #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==;
	}
}
