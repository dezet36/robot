﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Managers;

// Token: 0x0200008C RID: 140
internal sealed partial class #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8= : Form
{
	// Token: 0x060003CC RID: 972 RVA: 0x00021344 File Offset: 0x0001F544
	public #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zgcppYQE=, int #=zmBX8ZT6bd4eL)
	{
		this.#=zeJZsbgM= = #=z8StzeqE=;
		this.#=z3v_Pt336Xf0A = #=zgcppYQE=.#=zq2bPTdY=();
		this.#=zgpzgXirqPT5_();
		this.#=zGER_vWeqA5vi.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113420), new object[]
		{
			#=z8StzeqE=.#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(),
			#=z8StzeqE=.#=zh5Q$jgycqA15().#=zjWBl268nvo9O(),
			#=z8StzeqE=.#=zVTXNaO2wZJzQ(),
			#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(),
			#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==()
		});
		if (#=z8StzeqE=.#=zDZReNK0=() != null)
		{
			this.#=z4y0UK7NtFqpNFZSyDQ==.Text = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(this.#=z4y0UK7NtFqpNFZSyDQ==.Text, new object[]
			{
				#=z8StzeqE=.#=zDZReNK0=().#=z9Jm$ne_kr_H5D_R8UQ==()
			});
		}
		this.#=zywGkQuBCNjNo.Text = #=zgcppYQE=.#=zq2bPTdY=().Name;
		foreach (int num in #=zgcppYQE=.#=zo4gR$B4ZVFdYTDxEaw==().Keys)
		{
			ComboBox.ObjectCollection items = this.#=zvNvG1bNjn5C8.Items;
			#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.#=z$s$aDWLznsXN #=z$s$aDWLznsXN = new #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.#=z$s$aDWLznsXN();
			#=z$s$aDWLznsXN.#=zXuvLc5D4IVr_(num);
			#=z$s$aDWLznsXN.#=zqoCq5j01dD5w(#=zgcppYQE=.#=zo4gR$B4ZVFdYTDxEaw==()[num]);
			items.Add(#=z$s$aDWLznsXN);
		}
		if (#=zmBX8ZT6bd4eL >= 0)
		{
			for (int i = 0; i < this.#=zvNvG1bNjn5C8.Items.Count; i++)
			{
				if (((#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.#=z$s$aDWLznsXN)this.#=zvNvG1bNjn5C8.Items[i]).#=znXmKdhHhazpF() == #=zmBX8ZT6bd4eL)
				{
					this.#=zvNvG1bNjn5C8.SelectedIndex = i;
					break;
				}
			}
		}
		else
		{
			this.#=zvNvG1bNjn5C8.SelectedIndex = -1;
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060003CD RID: 973 RVA: 0x00021500 File Offset: 0x0001F700
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zvNvG1bNjn5C8.SelectedItem == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909021169));
			return;
		}
		if (string.IsNullOrEmpty(this.#=zxJvtlwh5fFDqYUcC3Q==.Text))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909021143));
			return;
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = this.#=zk55d778IdJE5fRurDw==(this.#=zxJvtlwh5fFDqYUcC3Q==.Text);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			return;
		}
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zeJZsbgM=);
		if (!#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zq76JuU9WPIZn())
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
		}
		int num = ((#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.#=z$s$aDWLznsXN)this.#=zvNvG1bNjn5C8.SelectedItem).#=znXmKdhHhazpF();
		string text;
		if (this.#=z3v_Pt336Xf0A.Id == -1)
		{
			text = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zM0a73Ky1Wph_OsGGRtca10obKG17(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=(), num);
		}
		else
		{
			text = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zjvkC2AJLgQ7VwVU_2A==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=(), this.#=z3v_Pt336Xf0A, num);
		}
		string text2;
		if (text.Length > 10000)
		{
			text2 = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909021093), new object[]
			{
				#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
				this.#=z3v_Pt336Xf0A.Name,
				num + 1
			});
		}
		else
		{
			text2 = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020763), new object[]
			{
				#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
				this.#=z3v_Pt336Xf0A.Name,
				num + 1,
				JSONManager.Cut(text)
			});
		}
		this.#=zeJZsbgM=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), text2, Array.Empty<object>());
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(text2);
		base.Close();
	}

	// Token: 0x060003CE RID: 974 RVA: 0x0002167C File Offset: 0x0001F87C
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060003CF RID: 975 RVA: 0x00021684 File Offset: 0x0001F884
	private static bool #=zpFuBGU_pbGgs(string #=zcpJ6bUA=, out int #=zQrqFdos=, out int #=zKFlJyLE=)
	{
		#=zQrqFdos= = 0;
		#=zKFlJyLE= = 0;
		bool result;
		try
		{
			string[] array = #=zcpJ6bUA=.Split(new char[]
			{
				' ',
				',',
				';',
				'\t'
			}, StringSplitOptions.RemoveEmptyEntries);
			if (array.Length != 2)
			{
				result = false;
			}
			else if (!int.TryParse(array[0], out #=zQrqFdos=))
			{
				result = false;
			}
			else if (!int.TryParse(array[1], out #=zKFlJyLE=))
			{
				result = false;
			}
			else
			{
				result = true;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x000216F4 File Offset: 0x0001F8F4
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zk55d778IdJE5fRurDw==(string #=znUBh3vsamsjU)
	{
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = this.#=zLr18QKpzilxyiDNuaw==(#=znUBh3vsamsjU);
		if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)
		{
			return #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== as #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
		}
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026883));
		return null;
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x0002172C File Offset: 0x0001F92C
	private #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zLr18QKpzilxyiDNuaw==(string #=znUBh3vsamsjU)
	{
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (!#=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8=.#=zpFuBGU_pbGgs(#=znUBh3vsamsjU, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088151));
			return null;
		}
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zLr18QKpzilxyiDNuaw==(this.#=zeJZsbgM=, #=zhfS69jI=, #=zmWD8vxE=, true);
		if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026883));
			return null;
		}
		return #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==;
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x000217A0 File Offset: 0x0001F9A0
	private void #=zgpzgXirqPT5_()
	{
		this.#=z8o6jPFQUclea = new Label();
		this.#=zDYQrKQF32UKH = new Label();
		this.#=z0OBtofH97HEOdbU9eQ== = new Label();
		this.#=zvNvG1bNjn5C8 = new ComboBox();
		this.#=zxJvtlwh5fFDqYUcC3Q== = new TextBox();
		this.#=zSO2Y805H3SMIL35mhA== = new Label();
		this.#=zuCaP$Fc= = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=zGER_vWeqA5vi = new Label();
		this.#=zywGkQuBCNjNo = new Label();
		this.#=z4y0UK7NtFqpNFZSyDQ== = new Label();
		base.SuspendLayout();
		this.#=z8o6jPFQUclea.AutoSize = true;
		this.#=z8o6jPFQUclea.Location = new Point(12, 9);
		this.#=z8o6jPFQUclea.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020692);
		this.#=z8o6jPFQUclea.Size = new Size(106, 13);
		this.#=z8o6jPFQUclea.TabIndex = 0;
		this.#=z8o6jPFQUclea.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020920);
		this.#=zDYQrKQF32UKH.AutoSize = true;
		this.#=zDYQrKQF32UKH.Location = new Point(12, 69);
		this.#=zDYQrKQF32UKH.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020903);
		this.#=zDYQrKQF32UKH.Size = new Size(67, 13);
		this.#=zDYQrKQF32UKH.TabIndex = 1;
		this.#=zDYQrKQF32UKH.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909048041);
		this.#=z0OBtofH97HEOdbU9eQ==.AutoSize = true;
		this.#=z0OBtofH97HEOdbU9eQ==.Location = new Point(12, 99);
		this.#=z0OBtofH97HEOdbU9eQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020875);
		this.#=z0OBtofH97HEOdbU9eQ==.Size = new Size(45, 13);
		this.#=z0OBtofH97HEOdbU9eQ==.TabIndex = 2;
		this.#=z0OBtofH97HEOdbU9eQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020860);
		this.#=zvNvG1bNjn5C8.DisplayMember = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020845);
		this.#=zvNvG1bNjn5C8.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zvNvG1bNjn5C8.FormattingEnabled = true;
		this.#=zvNvG1bNjn5C8.Location = new Point(180, 96);
		this.#=zvNvG1bNjn5C8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020824);
		this.#=zvNvG1bNjn5C8.Size = new Size(215, 21);
		this.#=zvNvG1bNjn5C8.TabIndex = 3;
		this.#=zvNvG1bNjn5C8.Tag = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106062);
		this.#=zvNvG1bNjn5C8.ValueMember = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020813);
		this.#=zxJvtlwh5fFDqYUcC3Q==.Location = new Point(180, 126);
		this.#=zxJvtlwh5fFDqYUcC3Q==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020530);
		this.#=zxJvtlwh5fFDqYUcC3Q==.Size = new Size(142, 20);
		this.#=zxJvtlwh5fFDqYUcC3Q==.TabIndex = 5;
		this.#=zSO2Y805H3SMIL35mhA==.AutoSize = true;
		this.#=zSO2Y805H3SMIL35mhA==.Location = new Point(12, 129);
		this.#=zSO2Y805H3SMIL35mhA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020512);
		this.#=zSO2Y805H3SMIL35mhA==.Size = new Size(88, 13);
		this.#=zSO2Y805H3SMIL35mhA==.TabIndex = 6;
		this.#=zSO2Y805H3SMIL35mhA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020503);
		this.#=zuCaP$Fc=.Location = new Point(107, 177);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(114, 23);
		this.#=zuCaP$Fc=.TabIndex = 7;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102611);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		this.#=zHeAVXAs=.Location = new Point(329, 177);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(114, 23);
		this.#=zHeAVXAs=.TabIndex = 8;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zGER_vWeqA5vi.AutoSize = true;
		this.#=zGER_vWeqA5vi.Location = new Point(179, 9);
		this.#=zGER_vWeqA5vi.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020479);
		this.#=zGER_vWeqA5vi.Size = new Size(16, 13);
		this.#=zGER_vWeqA5vi.TabIndex = 9;
		this.#=zGER_vWeqA5vi.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114954);
		this.#=zywGkQuBCNjNo.AutoSize = true;
		this.#=zywGkQuBCNjNo.Location = new Point(177, 69);
		this.#=zywGkQuBCNjNo.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020450);
		this.#=zywGkQuBCNjNo.Size = new Size(16, 13);
		this.#=zywGkQuBCNjNo.TabIndex = 10;
		this.#=zywGkQuBCNjNo.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114954);
		this.#=z4y0UK7NtFqpNFZSyDQ==.AutoSize = true;
		this.#=z4y0UK7NtFqpNFZSyDQ==.Location = new Point(12, 39);
		this.#=z4y0UK7NtFqpNFZSyDQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020433);
		this.#=z4y0UK7NtFqpNFZSyDQ==.Size = new Size(211, 13);
		this.#=z4y0UK7NtFqpNFZSyDQ==.TabIndex = 12;
		this.#=z4y0UK7NtFqpNFZSyDQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020669);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(573, 241);
		base.Controls.Add(this.#=z4y0UK7NtFqpNFZSyDQ==);
		base.Controls.Add(this.#=zywGkQuBCNjNo);
		base.Controls.Add(this.#=zGER_vWeqA5vi);
		base.Controls.Add(this.#=zHeAVXAs=);
		base.Controls.Add(this.#=zuCaP$Fc=);
		base.Controls.Add(this.#=zSO2Y805H3SMIL35mhA==);
		base.Controls.Add(this.#=zxJvtlwh5fFDqYUcC3Q==);
		base.Controls.Add(this.#=zvNvG1bNjn5C8);
		base.Controls.Add(this.#=z0OBtofH97HEOdbU9eQ==);
		base.Controls.Add(this.#=zDYQrKQF32UKH);
		base.Controls.Add(this.#=z8o6jPFQUclea);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020614);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020591);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000156 RID: 342
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zeJZsbgM=;

	// Token: 0x04000157 RID: 343
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A;

	// Token: 0x04000159 RID: 345
	private Label #=z8o6jPFQUclea;

	// Token: 0x0400015A RID: 346
	private Label #=zDYQrKQF32UKH;

	// Token: 0x0400015B RID: 347
	private Label #=z0OBtofH97HEOdbU9eQ==;

	// Token: 0x0400015C RID: 348
	private ComboBox #=zvNvG1bNjn5C8;

	// Token: 0x0400015D RID: 349
	private TextBox #=zxJvtlwh5fFDqYUcC3Q==;

	// Token: 0x0400015E RID: 350
	private Label #=zSO2Y805H3SMIL35mhA==;

	// Token: 0x0400015F RID: 351
	private Button #=zuCaP$Fc=;

	// Token: 0x04000160 RID: 352
	private Button #=zHeAVXAs=;

	// Token: 0x04000161 RID: 353
	private Label #=zGER_vWeqA5vi;

	// Token: 0x04000162 RID: 354
	private Label #=zywGkQuBCNjNo;

	// Token: 0x04000163 RID: 355
	private Label #=z4y0UK7NtFqpNFZSyDQ==;

	// Token: 0x0200008D RID: 141
	public sealed class #=z$s$aDWLznsXN
	{
		// Token: 0x060003D5 RID: 981 RVA: 0x00021E44 File Offset: 0x00020044
		public int #=znXmKdhHhazpF()
		{
			return this.#=z7AYNzt9AIo3BsL9bvPU0$CU=;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00021E4C File Offset: 0x0002004C
		public void #=zXuvLc5D4IVr_(int #=z$Ib9gYQ=)
		{
			this.#=z7AYNzt9AIo3BsL9bvPU0$CU= = #=z$Ib9gYQ=;
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00021E58 File Offset: 0x00020058
		public int #=zlIXJ9$NfUZc_()
		{
			return this.#=zxojFZYWVfXhu329mAA==;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00021E60 File Offset: 0x00020060
		public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
		{
			this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00021E6C File Offset: 0x0002006C
		public string #=z6BiGypBimJpU()
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020956), new object[]
			{
				this.#=znXmKdhHhazpF() + 1,
				this.#=zlIXJ9$NfUZc_()
			}).ToString();
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00021EA8 File Offset: 0x000200A8
		public override string ToString()
		{
			return this.#=z6BiGypBimJpU();
		}

		// Token: 0x04000164 RID: 356
		private int #=z7AYNzt9AIo3BsL9bvPU0$CU=;

		// Token: 0x04000165 RID: 357
		private int #=zxojFZYWVfXhu329mAA==;
	}
}
