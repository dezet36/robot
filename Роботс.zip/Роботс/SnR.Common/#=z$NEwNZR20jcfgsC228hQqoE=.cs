﻿using System;

// Token: 0x0200001F RID: 31
internal sealed class #=z$NEwNZR20jcfgsC228hQqoE= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600005F RID: 95 RVA: 0x00003C68 File Offset: 0x00001E68
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zV9NILhXukjVlJQslzg==;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003C70 File Offset: 0x00001E70
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003C74 File Offset: 0x00001E74
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080211);
	}
}
