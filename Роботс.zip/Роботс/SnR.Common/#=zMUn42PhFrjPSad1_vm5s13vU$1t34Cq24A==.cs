﻿using System;
using System.Collections.Generic;

// Token: 0x02000163 RID: 355
internal sealed class #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==
{
	// Token: 0x06000975 RID: 2421 RVA: 0x0004C958 File Offset: 0x0004AB58
	public #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==()
	{
		this.#=zaRZk5Gg= = new Dictionary<int, Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>>();
		this.#=zhdFHN$8uc7GFF0FwrQ== = new List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==>();
	}

	// Token: 0x06000977 RID: 2423 RVA: 0x0004C98C File Offset: 0x0004AB8C
	private int #=zjgOzN7SM62_reLdNig==(List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> #=z_R_0mSc=)
	{
		int num = 0;
		for (int i = #=z_R_0mSc=.Count - 1; i >= 0; i--)
		{
			num += (#=z_R_0mSc=[i].#=zpZQhzm3O9fac() ? 1 : #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zvQM7hTETWDsDiXZCaw==());
		}
		return num;
	}

	// Token: 0x06000978 RID: 2424 RVA: 0x0004C9D0 File Offset: 0x0004ABD0
	private #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=zxdHeCv23jTVV6OOiijrJ6fw=(List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> #=z_R_0mSc=, int #=zShL45qY=)
	{
		int num = 0;
		for (int i = #=z_R_0mSc=.Count - 1; i >= 0; i--)
		{
			#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== = #=z_R_0mSc=[i];
			num += (#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==.#=zpZQhzm3O9fac() ? 1 : #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zvQM7hTETWDsDiXZCaw==());
			if (num >= #=zShL45qY=)
			{
				return #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==;
			}
		}
		return null;
	}

	// Token: 0x06000979 RID: 2425 RVA: 0x0004CA1C File Offset: 0x0004AC1C
	public #=zLdas1G0kAAODvaqZgJo9xEujgDGZ #=z48rEd0A=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, string #=z0idSdYs=, string #=zrhvCoyA=)
	{
		if (#=z8StzeqE= == null)
		{
			return null;
		}
		#=zLdas1G0kAAODvaqZgJo9xEujgDGZ result;
		lock (this)
		{
			DateTime now = DateTime.Now;
			#=zLdas1G0kAAODvaqZgJo9xEujgDGZ #=zLdas1G0kAAODvaqZgJo9xEujgDGZ = #=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zOBwwFP4=(#=zrhvCoyA=);
			try
			{
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zsJ3LVoBnMJ5KlcKlZw==())
				{
					int num = #=z8StzeqE=.#=zYgvZuBwR$a1C();
					if (!this.#=zaRZk5Gg=.ContainsKey(num))
					{
						this.#=zaRZk5Gg=.Add(num, new Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>
						{
							{
								#=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL,
								new List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>()
							}
						});
					}
					Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>> dictionary = this.#=zaRZk5Gg=[num];
					if (!dictionary.ContainsKey(#=z0idSdYs=))
					{
						dictionary.Add(#=z0idSdYs=, new List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>());
					}
					List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> list = dictionary[#=z0idSdYs=];
					List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> list2 = dictionary[#=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL];
					DateTime t = now - TimeSpan.FromSeconds((double)#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==());
					while (list.Count > 0)
					{
						if (!(list[0].#=zPHMvvJ8=() < t))
						{
							IL_172:
							while (list2.Count > 0 && list2[0].#=zPHMvvJ8=() < t)
							{
								list2.RemoveAt(0);
							}
							if (#=zLdas1G0kAAODvaqZgJo9xEujgDGZ != null)
							{
								string key = num.ToString() + #=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=();
								if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zD4i5XsuB4tQfZEBJSw==() || !#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE().ContainsKey(key))
								{
									int num2;
									if (#=z0idSdYs= == #=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=())
									{
										num2 = this.#=zjgOzN7SM62_reLdNig==(list);
									}
									else if (#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=() != #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL)
									{
										num2 = (dictionary.ContainsKey(#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=()) ? (this.#=zjgOzN7SM62_reLdNig==(dictionary[#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=()]) - 1) : 0);
									}
									else
									{
										num2 = this.#=zjgOzN7SM62_reLdNig==(list2);
									}
									if (num2 <= 0)
									{
										num2 = 1;
									}
									int num3 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE().ContainsKey(key) ? #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE()[key] : int.MaxValue;
									if (num2 < num3 && list2.Count > 1)
									{
										#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE()[key] = num2;
										if (num3 < 2147483647)
										{
											#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051340), new object[]
											{
												#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=(),
												num2,
												num3
											});
										}
										else
										{
											#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051274), new object[]
											{
												#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=(),
												num2
											});
										}
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=z2cVYJJw=(this.#=zaRZk5Gg=, this.#=zhdFHN$8uc7GFF0FwrQ==, num), Array.Empty<object>());
										#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zcGgkwprFf4jMm6zoww==(true);
										#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zz151EFo35TnJ(now + TimeSpan.FromSeconds((double)#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==()));
									}
									else
									{
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050980), new object[]
										{
											#=zLdas1G0kAAODvaqZgJo9xEujgDGZ.#=zz_zA9A3cg$dy3_yotwWFDqU=(),
											num2,
											num3
										});
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=z2cVYJJw=(this.#=zaRZk5Gg=, this.#=zhdFHN$8uc7GFF0FwrQ==, num), Array.Empty<object>());
									}
								}
							}
							bool #=zwKNSAUQ= = !string.IsNullOrEmpty(#=zrhvCoyA=) && #=zrhvCoyA=[0] != 'e';
							#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== item = new #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==(now, #=zwKNSAUQ=, #=z8StzeqE=.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU());
							list.Add(item);
							list2.Add(item);
							goto IL_3E2;
						}
						this.#=zhdFHN$8uc7GFF0FwrQ==.Add(new #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(num, #=z0idSdYs=, list[0], false));
						while (this.#=zhdFHN$8uc7GFF0FwrQ==.Count > 0 && this.#=zhdFHN$8uc7GFF0FwrQ==[0].#=zPHMvvJ8=() < now - TimeSpan.FromMinutes(60.0))
						{
							this.#=zhdFHN$8uc7GFF0FwrQ==.RemoveAt(0);
						}
						list.RemoveAt(0);
					}
					goto IL_172;
				}
				IL_3E2:;
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=ztKQl$eySJFhkysxruA==();
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			}
			result = #=zLdas1G0kAAODvaqZgJo9xEujgDGZ;
		}
		return result;
	}

	// Token: 0x0600097A RID: 2426 RVA: 0x0004CE70 File Offset: 0x0004B070
	public DateTime #=zfDLoU$fv2a3A(int #=zLeeSKrg=, string #=z0idSdYs=)
	{
		DateTime result;
		try
		{
			DateTime dateTime = DateTime.MinValue;
			if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zsJ3LVoBnMJ5KlcKlZw==() && this.#=zaRZk5Gg=.ContainsKey(#=zLeeSKrg=))
			{
				if (this.#=zaRZk5Gg=[#=zLeeSKrg=].ContainsKey(#=z0idSdYs=))
				{
					List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> #=z_R_0mSc= = this.#=zaRZk5Gg=[#=zLeeSKrg=][#=z0idSdYs=];
					int #=zShL45qY= = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE().ContainsKey(#=zLeeSKrg=.ToString() + #=z0idSdYs=) ? #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE()[#=zLeeSKrg=.ToString() + #=z0idSdYs=] : int.MaxValue;
					#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== = this.#=zxdHeCv23jTVV6OOiijrJ6fw=(#=z_R_0mSc=, #=zShL45qY=);
					if (#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== != null)
					{
						dateTime = #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==.#=zPHMvvJ8=() + TimeSpan.FromSeconds((double)(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==() + 1));
					}
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE().ContainsKey(#=zLeeSKrg=.ToString() + #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL))
				{
					List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> #=z_R_0mSc=2 = this.#=zaRZk5Gg=[#=zLeeSKrg=][#=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL];
					int #=zShL45qY=2 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE()[#=zLeeSKrg=.ToString() + #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL];
					#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==2 = this.#=zxdHeCv23jTVV6OOiijrJ6fw=(#=z_R_0mSc=2, #=zShL45qY=2);
					if (#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==2 != null)
					{
						DateTime dateTime2 = #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==2.#=zPHMvvJ8=() + TimeSpan.FromSeconds((double)(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==() + 1));
						if (dateTime2 > dateTime)
						{
							dateTime = dateTime2;
						}
					}
				}
			}
			result = dateTime;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=ztKQl$eySJFhkysxruA==();
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			result = DateTime.Now + TimeSpan.FromSeconds((double)(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==() + 1));
		}
		return result;
	}

	// Token: 0x0600097B RID: 2427 RVA: 0x0004D030 File Offset: 0x0004B230
	private void #=ztKQl$eySJFhkysxruA==()
	{
		foreach (KeyValuePair<int, Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>> keyValuePair in this.#=zaRZk5Gg=)
		{
			foreach (KeyValuePair<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>> keyValuePair2 in keyValuePair.Value)
			{
				for (int i = keyValuePair2.Value.Count - 1; i >= 0; i--)
				{
					if (keyValuePair2.Value[i] == null)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050896), new object[]
						{
							keyValuePair.Key,
							keyValuePair2.Key,
							(i > 0) ? keyValuePair2.Value[i - 1].ToString() : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081897),
							(i < keyValuePair2.Value.Count - 1) ? keyValuePair2.Value[i + 1].ToString() : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081897)
						});
						keyValuePair2.Value.RemoveAt(i);
					}
				}
			}
		}
		for (int j = this.#=zhdFHN$8uc7GFF0FwrQ==.Count - 1; j >= 0; j--)
		{
			if (this.#=zhdFHN$8uc7GFF0FwrQ==[j] == null)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051089), new object[]
				{
					(j > 0) ? this.#=zhdFHN$8uc7GFF0FwrQ==[j - 1].ToString() : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081897),
					(j < this.#=zhdFHN$8uc7GFF0FwrQ==.Count - 1) ? this.#=zhdFHN$8uc7GFF0FwrQ==[j + 1].ToString() : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081897)
				});
				this.#=zhdFHN$8uc7GFF0FwrQ==.RemoveAt(j);
			}
		}
	}

	// Token: 0x0400056A RID: 1386
	public static string #=zM8IB4GHgekmL = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051350);

	// Token: 0x0400056B RID: 1387
	private Dictionary<int, Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>> #=zaRZk5Gg=;

	// Token: 0x0400056C RID: 1388
	private List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==> #=zhdFHN$8uc7GFF0FwrQ==;
}
