﻿// Token: 0x02000122 RID: 290
internal sealed partial class #=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw== : global::System.Windows.Forms.Form
{
	// Token: 0x0600072F RID: 1839 RVA: 0x0003C1FC File Offset: 0x0003A3FC
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400044C RID: 1100
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
