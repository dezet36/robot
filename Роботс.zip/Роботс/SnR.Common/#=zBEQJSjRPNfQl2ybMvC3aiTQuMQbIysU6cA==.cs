﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020000C3 RID: 195
internal sealed class #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== : #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==
{
	// Token: 0x06000520 RID: 1312 RVA: 0x0002CB8C File Offset: 0x0002AD8C
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==() : base(Entities.Technology)
	{
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x0002CB98 File Offset: 0x0002AD98
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==(Dictionary<string, object> #=z1YNp7IY=) : base(#=z1YNp7IY=, Entities.Technology)
	{
		this.#=zsQyHwHl2GzEU(new List<int>());
		this.#=zOuTRnup0JcL3izBHFqWQeys=(null);
		object[] array = JSONManager.GetArray(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061820));
		if (array != null && array.Length != 0)
		{
			Dictionary<string, object> dictionary = JSONManager.GetDictionary(array[0], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061800));
			if (dictionary != null)
			{
				using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary.Keys.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						int item;
						if (int.TryParse(enumerator.Current, out item))
						{
							this.#=zmZTlfruS$qcN().Add(item);
						}
					}
					goto IL_18A;
				}
			}
			string text = null;
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI= #=z$Ib9gYQ= = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI=)0;
			if (((Dictionary<string, object>)array[0]).ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061793)))
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061793);
				#=z$Ib9gYQ= = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI=)1;
			}
			else if (((Dictionary<string, object>)array[0]).ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060487)))
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060487);
				#=z$Ib9gYQ= = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI=)2;
			}
			if (text != null)
			{
				#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs= #=zO46jrzfZ_$eMJwxZT80Yfqs= = new #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=();
				#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpmbhfimGMj3U(#=z$Ib9gYQ=);
				#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=z57lBe_Q1k9_xjJbgcg==(new int[array.Length]);
				this.#=zOuTRnup0JcL3izBHFqWQeys=(#=zO46jrzfZ_$eMJwxZT80Yfqs=);
				for (int i = 0; i < array.Length; i++)
				{
					Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary((Dictionary<string, object>)array[i], text);
					foreach (string text2 in dictionary2.Keys)
					{
						this.#=zsWzBQdkf_CIsUJr7$Ln2aos=().#=zM_tYMjXvmqJR(Convert.ToInt32(text2));
						this.#=zsWzBQdkf_CIsUJr7$Ln2aos=().#=z2oIM6JEk6QZGsx83FQ==()[i] = JSONManager.ExtractInt(dictionary2, text2, 0);
					}
				}
			}
		}
		IL_18A:
		this.#=zVDDXlYr$$Az_(0);
		this.#=zfK3b5S4h7Nt9$nEaOw==(false);
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x0002CD5C File Offset: 0x0002AF5C
	public List<int> #=zmZTlfruS$qcN()
	{
		return this.#=zgPP3SlMnbaUSCLXnFrVLxEY=;
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x0002CD64 File Offset: 0x0002AF64
	public void #=zsQyHwHl2GzEU(List<int> #=z$Ib9gYQ=)
	{
		this.#=zgPP3SlMnbaUSCLXnFrVLxEY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x0002CD70 File Offset: 0x0002AF70
	public int #=ziV0Qa4zwZEC4()
	{
		return base.Id + 100;
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x0002CD7C File Offset: 0x0002AF7C
	public int #=z6ZIr13K_h_d4()
	{
		return this.#=zBAIyxjI84cdP54xSiw==;
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x0002CD84 File Offset: 0x0002AF84
	public void #=zVDDXlYr$$Az_(int #=z$Ib9gYQ=)
	{
		this.#=zBAIyxjI84cdP54xSiw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x0002CD90 File Offset: 0x0002AF90
	public bool #=zsQC8qhbaqVU5q6hkHg==()
	{
		return this.#=z05kBshORH_zfSbJbKXZByYaBNVbO;
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x0002CD98 File Offset: 0x0002AF98
	public void #=zfK3b5S4h7Nt9$nEaOw==(bool #=z$Ib9gYQ=)
	{
		this.#=z05kBshORH_zfSbJbKXZByYaBNVbO = #=z$Ib9gYQ=;
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x0002CDA4 File Offset: 0x0002AFA4
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs= #=zsWzBQdkf_CIsUJr7$Ln2aos=()
	{
		return this.#=z9zRbQ1SN4i9DUZqKpfCrZGRNAee3;
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x0002CDAC File Offset: 0x0002AFAC
	public void #=zOuTRnup0JcL3izBHFqWQeys=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs= #=z$Ib9gYQ=)
	{
		this.#=z9zRbQ1SN4i9DUZqKpfCrZGRNAee3 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600052B RID: 1323 RVA: 0x0002CDB8 File Offset: 0x0002AFB8
	public new int #=zaDKBEnk8Vsod()
	{
		if (base.#=z2fOvUeiaHzR6().Count <= 0)
		{
			return this.#=zLf2_OT9Fik$u;
		}
		return base.#=z2fOvUeiaHzR6().Count;
	}

	// Token: 0x0600052C RID: 1324 RVA: 0x0002CDDC File Offset: 0x0002AFDC
	public void #=zN$ZzBOHbXzEf(int #=z$Ib9gYQ=)
	{
		this.#=zLf2_OT9Fik$u = #=z$Ib9gYQ=;
	}

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x0600052D RID: 1325 RVA: 0x0002CDE8 File Offset: 0x0002AFE8
	public override bool IsHidden
	{
		get
		{
			return base.IsHidden;
		}
	}

	// Token: 0x0600052E RID: 1326 RVA: 0x0002CDF0 File Offset: 0x0002AFF0
	public void #=zceLS5g8CKZ6t(Dictionary<string, object> #=zX5cFTdg=)
	{
		this.#=zVDDXlYr$$Az_(JSONManager.ExtractInt(#=zX5cFTdg=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0));
		this.#=zfK3b5S4h7Nt9$nEaOw==(JSONManager.GetInt(#=zX5cFTdg=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061790), 0) > 0);
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x0002CE24 File Offset: 0x0002B024
	public override string ToString()
	{
		return base.Name;
	}

	// Token: 0x04000206 RID: 518
	private List<int> #=zgPP3SlMnbaUSCLXnFrVLxEY=;

	// Token: 0x04000207 RID: 519
	private int #=zBAIyxjI84cdP54xSiw==;

	// Token: 0x04000208 RID: 520
	private bool #=z05kBshORH_zfSbJbKXZByYaBNVbO;

	// Token: 0x04000209 RID: 521
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs= #=z9zRbQ1SN4i9DUZqKpfCrZGRNAee3;

	// Token: 0x0400020A RID: 522
	private int #=zLf2_OT9Fik$u;

	// Token: 0x020000C4 RID: 196
	internal sealed class #=zO46jrzfZ_$eMJwxZT80Yfqs=
	{
		// Token: 0x06000531 RID: 1329 RVA: 0x0002CE34 File Offset: 0x0002B034
		public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI= #=zjw43QGFcPyHH()
		{
			return this.#=z$cjfMsOUZJUVVe7pGQ==;
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0002CE3C File Offset: 0x0002B03C
		public void #=zpmbhfimGMj3U(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI= #=z$Ib9gYQ=)
		{
			this.#=z$cjfMsOUZJUVVe7pGQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x0002CE48 File Offset: 0x0002B048
		public int #=z9$XFwTaUKMJD()
		{
			return this.#=zKlNoO_yqqS_jEHSr$WYFu$4=;
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x0002CE50 File Offset: 0x0002B050
		public void #=zM_tYMjXvmqJR(int #=z$Ib9gYQ=)
		{
			this.#=zKlNoO_yqqS_jEHSr$WYFu$4= = #=z$Ib9gYQ=;
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0002CE5C File Offset: 0x0002B05C
		public int[] #=z2oIM6JEk6QZGsx83FQ==()
		{
			return this.#=zPgz$2Ho6y7DYomWH04hT97JicUnR;
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x0002CE64 File Offset: 0x0002B064
		public void #=z57lBe_Q1k9_xjJbgcg==(int[] #=z$Ib9gYQ=)
		{
			this.#=zPgz$2Ho6y7DYomWH04hT97JicUnR = #=z$Ib9gYQ=;
		}

		// Token: 0x0400020B RID: 523
		private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zO46jrzfZ_$eMJwxZT80Yfqs=.#=zpA3w8wI= #=z$cjfMsOUZJUVVe7pGQ==;

		// Token: 0x0400020C RID: 524
		private int #=zKlNoO_yqqS_jEHSr$WYFu$4=;

		// Token: 0x0400020D RID: 525
		private int[] #=zPgz$2Ho6y7DYomWH04hT97JicUnR;

		// Token: 0x020000C5 RID: 197
		public enum #=zpA3w8wI=
		{

		}
	}
}
