﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x0200023D RID: 573
internal sealed class #=zfrCQv8cDlxR3zcqzqa1Tqv3SbDH9E8JwLBS6S9LaNo$RUUgg3nSMhibQ6Ki2 : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001190 RID: 4496 RVA: 0x000883D4 File Offset: 0x000865D4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zMEwuTGAUgTDD = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
	}

	// Token: 0x06001191 RID: 4497 RVA: 0x000883E4 File Offset: 0x000865E4
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		this.#=zpQZmgBmaEGNcB$bUd8A4QNY=(#=zcTyyNys=);
	}

	// Token: 0x06001192 RID: 4498 RVA: 0x00088414 File Offset: 0x00086614
	private void #=zpQZmgBmaEGNcB$bUd8A4QNY=(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys=)
	{
		#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = null;
		for (int i = 0; i < this.#=zMEwuTGAUgTDD.Count; i++)
		{
			if (this.#=zMEwuTGAUgTDD[i].#=zq2bPTdY=().Id == #=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId)
			{
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = this.#=zMEwuTGAUgTDD[i];
				break;
			}
		}
		if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== == null)
		{
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=().#=zk$6QZNA=(#=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId);
			if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== == null)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976551), new object[]
				{
					#=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId
				});
				return;
			}
			string text = this.#=zBsXSanI=.#=z20Op8NOLzKmH5WBHiP4ZLPs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==, true);
			if (text.Length > 10000)
			{
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 = new #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==();
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zzQwUIEs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zFzGvi_S6jJhE(1);
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zdU1a9B$ueh_3(DateTime.MinValue);
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2;
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976249), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976199), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
					JSONManager.Cut(text)
				});
			}
		}
		if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null)
		{
			int amount = #=zcTyyNys=.#=zXFnsTSimqiPo().Amount;
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() < amount)
			{
				for (int j = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du(); j < amount; j++)
				{
					string text2 = this.#=zBsXSanI=.#=zqf$ER4kgqRjhLlVT9Q==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, true);
					if (text2.Length <= 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976320), new object[]
						{
							#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
							#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du(),
							JSONManager.Cut(text2)
						});
						return;
					}
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3 = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==;
					int num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zvnZc$RhG_1Du();
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zFzGvi_S6jJhE(num + 1);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976136), new object[]
					{
						#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
						#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du()
					});
				}
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978027), new object[]
			{
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
				amount
			});
		}
	}

	// Token: 0x040009CF RID: 2511
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD;
}
