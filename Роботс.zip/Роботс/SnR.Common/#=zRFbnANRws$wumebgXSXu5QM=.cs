﻿using System;
using System.Text;
using common;
using NExcel.Biff;

// Token: 0x02000191 RID: 401
internal sealed class #=zRFbnANRws$wumebgXSXu5QM= : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000B77 RID: 2935 RVA: 0x00057C88 File Offset: 0x00055E88
	internal #=zRFbnANRws$wumebgXSXu5QM=()
	{
	}

	// Token: 0x06000B78 RID: 2936 RVA: 0x00057C90 File Offset: 0x00055E90
	internal #=zRFbnANRws$wumebgXSXu5QM=(string #=zWj7xLq8=)
	{
		int num = #=zWj7xLq8=.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074));
		Assert.verify(num != -1);
		string s = #=zWj7xLq8=.Substring(0, num);
		string s2 = #=zWj7xLq8=.Substring(num + 1);
		this.#=zDec2DjUIpVoA = CellReferenceHelper.getColumn(s);
		this.#=zkVbotU1onZOR = CellReferenceHelper.getRow(s);
		this.#=zh1vaBWFzORUr = CellReferenceHelper.getColumn(s2);
		this.#=znnJ2FmckCK2R = CellReferenceHelper.getRow(s2);
		this.#=z3EZeT1Eq9S9C = CellReferenceHelper.isColumnRelative(s);
		this.#=zcCic2xXY931G = CellReferenceHelper.isRowRelative(s);
		this.#=z0ObI7fN0V9z1 = CellReferenceHelper.isColumnRelative(s2);
		this.#=zDW3g0K7EfcSm = CellReferenceHelper.isRowRelative(s2);
	}

	// Token: 0x06000B7A RID: 2938 RVA: 0x00057D4C File Offset: 0x00055F4C
	internal int #=zas6WF9Y7vCuz()
	{
		return this.#=zDec2DjUIpVoA;
	}

	// Token: 0x06000B7B RID: 2939 RVA: 0x00057D54 File Offset: 0x00055F54
	internal int #=zEEViUu7KfNd$()
	{
		return this.#=zkVbotU1onZOR;
	}

	// Token: 0x06000B7C RID: 2940 RVA: 0x00057D5C File Offset: 0x00055F5C
	internal int #=zf4bYulRRFW0C()
	{
		return this.#=zh1vaBWFzORUr;
	}

	// Token: 0x06000B7D RID: 2941 RVA: 0x00057D64 File Offset: 0x00055F64
	internal int #=zW5QkwOB5a$bC()
	{
		return this.#=znnJ2FmckCK2R;
	}

	// Token: 0x06000B7E RID: 2942 RVA: 0x00057D6C File Offset: 0x00055F6C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[9];
		array[0] = ((!base.#=zt$EpC6LMXeRk()) ? #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQ_CaaLVcHjOz.#=zd$BbM3Y=() : #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQ_CaaLVcHjOz.#=znvQc3vboYqbA());
		IntegerHelper.getTwoBytes(this.#=zkVbotU1onZOR, array, 1);
		IntegerHelper.getTwoBytes(this.#=znnJ2FmckCK2R, array, 3);
		int num = this.#=zDec2DjUIpVoA;
		if (this.#=zcCic2xXY931G)
		{
			num |= 32768;
		}
		if (this.#=z3EZeT1Eq9S9C)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 5);
		num = this.#=zh1vaBWFzORUr;
		if (this.#=zDW3g0K7EfcSm)
		{
			num |= 32768;
		}
		if (this.#=z0ObI7fN0V9z1)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 7);
		return array;
	}

	// Token: 0x06000B7F RID: 2943 RVA: 0x00057E1C File Offset: 0x0005601C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zkVbotU1onZOR = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		this.#=znnJ2FmckCK2R = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 4], #=zJ5GWysk=[#=z4J_G3VM= + 5]);
		this.#=zDec2DjUIpVoA = (@int & 255);
		this.#=z3EZeT1Eq9S9C = ((@int & 16384) != 0);
		this.#=zcCic2xXY931G = ((@int & 32768) != 0);
		@int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 6], #=zJ5GWysk=[#=z4J_G3VM= + 7]);
		this.#=zh1vaBWFzORUr = (@int & 255);
		this.#=z0ObI7fN0V9z1 = ((@int & 16384) != 0);
		this.#=zDW3g0K7EfcSm = ((@int & 32768) != 0);
		return 8;
	}

	// Token: 0x06000B80 RID: 2944 RVA: 0x00057ECC File Offset: 0x000560CC
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		CellReferenceHelper.getCellReference(this.#=zDec2DjUIpVoA, this.#=zkVbotU1onZOR, #=zXvwCnz8=);
		#=zXvwCnz8=.Append(':');
		CellReferenceHelper.getCellReference(this.#=zh1vaBWFzORUr, this.#=znnJ2FmckCK2R, #=zXvwCnz8=);
	}

	// Token: 0x06000B81 RID: 2945 RVA: 0x00057EFC File Offset: 0x000560FC
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		if (this.#=z3EZeT1Eq9S9C)
		{
			this.#=zDec2DjUIpVoA += #=zUFUpoGQeXcCf;
		}
		if (this.#=z0ObI7fN0V9z1)
		{
			this.#=zh1vaBWFzORUr += #=zUFUpoGQeXcCf;
		}
		if (this.#=zcCic2xXY931G)
		{
			this.#=zkVbotU1onZOR += #=zJhSli$dVSPlw;
		}
		if (this.#=zDW3g0K7EfcSm)
		{
			this.#=znnJ2FmckCK2R += #=zJhSli$dVSPlw;
		}
	}

	// Token: 0x06000B82 RID: 2946 RVA: 0x00057F64 File Offset: 0x00056164
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (#=zMYEXL$w= <= this.#=zDec2DjUIpVoA)
		{
			this.#=zDec2DjUIpVoA++;
		}
		if (#=zMYEXL$w= <= this.#=zh1vaBWFzORUr)
		{
			this.#=zh1vaBWFzORUr++;
		}
	}

	// Token: 0x06000B83 RID: 2947 RVA: 0x00057F98 File Offset: 0x00056198
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (#=zMYEXL$w= < this.#=zDec2DjUIpVoA)
		{
			this.#=zDec2DjUIpVoA--;
		}
		if (#=zMYEXL$w= <= this.#=zh1vaBWFzORUr)
		{
			this.#=zh1vaBWFzORUr--;
		}
	}

	// Token: 0x06000B84 RID: 2948 RVA: 0x00057FCC File Offset: 0x000561CC
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (#=zg9A8_dw= <= this.#=zkVbotU1onZOR)
		{
			this.#=zkVbotU1onZOR++;
		}
		if (#=zg9A8_dw= <= this.#=znnJ2FmckCK2R)
		{
			this.#=znnJ2FmckCK2R++;
		}
	}

	// Token: 0x06000B85 RID: 2949 RVA: 0x00058000 File Offset: 0x00056200
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (#=zg9A8_dw= < this.#=zkVbotU1onZOR)
		{
			this.#=zkVbotU1onZOR--;
		}
		if (#=zg9A8_dw= <= this.#=znnJ2FmckCK2R)
		{
			this.#=znnJ2FmckCK2R--;
		}
	}

	// Token: 0x04000631 RID: 1585
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zRFbnANRws$wumebgXSXu5QM=));

	// Token: 0x04000632 RID: 1586
	private int #=zDec2DjUIpVoA;

	// Token: 0x04000633 RID: 1587
	private int #=zkVbotU1onZOR;

	// Token: 0x04000634 RID: 1588
	private int #=zh1vaBWFzORUr;

	// Token: 0x04000635 RID: 1589
	private int #=znnJ2FmckCK2R;

	// Token: 0x04000636 RID: 1590
	private bool #=z3EZeT1Eq9S9C;

	// Token: 0x04000637 RID: 1591
	private bool #=zcCic2xXY931G;

	// Token: 0x04000638 RID: 1592
	private bool #=z0ObI7fN0V9z1;

	// Token: 0x04000639 RID: 1593
	private bool #=zDW3g0K7EfcSm;
}
