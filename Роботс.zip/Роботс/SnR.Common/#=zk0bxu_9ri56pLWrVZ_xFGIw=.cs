﻿using System;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Format;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x02000270 RID: 624
internal class #=zk0bxu_9ri56pLWrVZ_xFGIw= : DateCell, Cell
{
	// Token: 0x060012DC RID: 4828 RVA: 0x000926FC File Offset: 0x000908FC
	public #=zk0bxu_9ri56pLWrVZ_xFGIw=(NumberCell #=zKq_Ym6U=, int #=zPZu1Eq8=, FormattingRecords #=zrRXQAB8=, bool #=z1xdZb6s=, SheetImpl #=z99eVqbg=)
	{
		this.#=zg9A8_dw= = #=zKq_Ym6U=.Row;
		this.#=zEh1wLVk= = #=zKq_Ym6U=.Column;
		this.#=zJqpM8PY= = #=zPZu1Eq8=;
		this.#=zwKQa9tCrbbw$ = #=zrRXQAB8=;
		this.#=zNEZ0SGey$A9J = #=z99eVqbg=;
		this.#=zQqR9G48= = false;
		this.#=zL0TJcHA= = this.#=zwKQa9tCrbbw$.getDateFormat(this.#=zJqpM8PY=);
		double num = #=zKq_Ym6U=.DoubleValue;
		if (!#=z1xdZb6s= && num < 61.0)
		{
			num += 1.0;
		}
		if (Math.Abs(num) < 1.0)
		{
			if (this.#=zL0TJcHA= == null)
			{
				this.#=zL0TJcHA= = #=zk0bxu_9ri56pLWrVZ_xFGIw=.#=zITpzCXA=;
			}
			this.#=z9iiP2tA= = true;
		}
		else
		{
			if (this.#=zL0TJcHA= == null)
			{
				this.#=zL0TJcHA= = #=zk0bxu_9ri56pLWrVZ_xFGIw=.#=z0oLLIV0=;
			}
			this.#=z9iiP2tA= = false;
		}
		int num2 = #=z1xdZb6s= ? 24107 : 25569;
		long num3 = (long)Math.Round((num - (double)num2) * 86400000.0 * 10000.0);
		DateTime dateTime = new DateTime(1970, 1, 1);
		num3 += dateTime.Ticks;
		this.#=zaiKvawI= = new DateTime(num3);
	}

	// Token: 0x17000065 RID: 101
	// (get) Token: 0x060012DE RID: 4830 RVA: 0x00092848 File Offset: 0x00090A48
	public virtual int Row
	{
		get
		{
			return this.#=zg9A8_dw=;
		}
	}

	// Token: 0x17000066 RID: 102
	// (get) Token: 0x060012DF RID: 4831 RVA: 0x00092850 File Offset: 0x00090A50
	public virtual int Column
	{
		get
		{
			return this.#=zEh1wLVk=;
		}
	}

	// Token: 0x17000067 RID: 103
	// (get) Token: 0x060012E0 RID: 4832 RVA: 0x00092858 File Offset: 0x00090A58
	public virtual DateTime DateValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000068 RID: 104
	// (get) Token: 0x060012E1 RID: 4833 RVA: 0x00092860 File Offset: 0x00090A60
	public virtual string Contents
	{
		get
		{
			return string.Format(this.#=zL0TJcHA=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zaiKvawI=);
		}
	}

	// Token: 0x17000069 RID: 105
	// (get) Token: 0x060012E2 RID: 4834 RVA: 0x00092884 File Offset: 0x00090A84
	public virtual object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060012E3 RID: 4835 RVA: 0x00092894 File Offset: 0x00090A94
	public virtual CellType Type
	{
		get
		{
			return CellType.DATE;
		}
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060012E4 RID: 4836 RVA: 0x0009289C File Offset: 0x00090A9C
	public virtual bool Time
	{
		get
		{
			return this.#=z9iiP2tA=;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060012E5 RID: 4837 RVA: 0x000928A4 File Offset: 0x00090AA4
	public virtual DateTimeFormatInfo DateFormat
	{
		get
		{
			Assert.verify(this.#=zL0TJcHA= != null);
			return this.#=zL0TJcHA=;
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060012E6 RID: 4838 RVA: 0x000928BC File Offset: 0x00090ABC
	public virtual NExcel.Format.CellFormat CellFormat
	{
		get
		{
			if (!this.#=zQqR9G48=)
			{
				this.#=zz4pSDjg= = this.#=zwKQa9tCrbbw$.getXFRecord(this.#=zJqpM8PY=);
				this.#=zQqR9G48= = true;
			}
			return this.#=zz4pSDjg=;
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060012E7 RID: 4839 RVA: 0x000928EC File Offset: 0x00090AEC
	public virtual bool Hidden
	{
		get
		{
			ColumnInfoRecord columnInfo = this.#=zNEZ0SGey$A9J.getColumnInfo(this.#=zEh1wLVk=);
			if (columnInfo != null && columnInfo.Width == 0)
			{
				return true;
			}
			RowRecord rowRecord = this.#=zNEZ0SGey$A9J.#=zSzfF9oQ=(this.#=zg9A8_dw=);
			return rowRecord != null && (rowRecord.RowHeight == 0 || rowRecord.isCollapsed());
		}
	}

	// Token: 0x060012E8 RID: 4840 RVA: 0x00092940 File Offset: 0x00090B40
	protected internal virtual SheetImpl #=zP5HMqyyjoirP()
	{
		return this.#=zNEZ0SGey$A9J;
	}

	// Token: 0x04000AD1 RID: 2769
	private DateTime #=zaiKvawI=;

	// Token: 0x04000AD2 RID: 2770
	private int #=zg9A8_dw=;

	// Token: 0x04000AD3 RID: 2771
	private int #=zEh1wLVk=;

	// Token: 0x04000AD4 RID: 2772
	private bool #=z9iiP2tA=;

	// Token: 0x04000AD5 RID: 2773
	private DateTimeFormatInfo #=zL0TJcHA=;

	// Token: 0x04000AD6 RID: 2774
	private NExcel.Format.CellFormat #=zz4pSDjg=;

	// Token: 0x04000AD7 RID: 2775
	private int #=zJqpM8PY=;

	// Token: 0x04000AD8 RID: 2776
	private FormattingRecords #=zwKQa9tCrbbw$;

	// Token: 0x04000AD9 RID: 2777
	private SheetImpl #=zNEZ0SGey$A9J;

	// Token: 0x04000ADA RID: 2778
	private bool #=zQqR9G48=;

	// Token: 0x04000ADB RID: 2779
	private static readonly DateTimeFormatInfo #=z0oLLIV0= = new DateTimeFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068043));

	// Token: 0x04000ADC RID: 2780
	private static readonly DateTimeFormatInfo #=zITpzCXA= = new DateTimeFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068281));
}
