﻿using System;
using System.IO.MemoryMappedFiles;
using System.Text;

// Token: 0x02000275 RID: 629
internal sealed class #=zkSElDvsxnb24bWNTH6c4VSM63ktV : IDisposable
{
	// Token: 0x06001301 RID: 4865 RVA: 0x00092CE4 File Offset: 0x00090EE4
	public #=zkSElDvsxnb24bWNTH6c4VSM63ktV(string #=z6QPrZ_4=, int #=z3Q8Rfx0=)
	{
		this.#=zf$TeaQ0= = #=z3Q8Rfx0=;
		this.#=zkSbg3HI= = MemoryMappedFile.CreateOrOpen(#=z6QPrZ_4=, (long)(this.#=zf$TeaQ0= + 2));
		this.#=z5jn9mD9$vVAy = this.#=zkSbg3HI=.CreateViewAccessor();
	}

	// Token: 0x06001302 RID: 4866 RVA: 0x00092D1C File Offset: 0x00090F1C
	public bool #=zx6_3fikxuuSt()
	{
		return this.#=z5jn9mD9$vVAy.ReadInt16(0L) == 0;
	}

	// Token: 0x06001303 RID: 4867 RVA: 0x00092D30 File Offset: 0x00090F30
	public string #=ztPgEKAM=()
	{
		short num = this.#=z5jn9mD9$vVAy.ReadInt16(0L);
		if (num == 0)
		{
			return string.Empty;
		}
		byte[] array = new byte[(int)num];
		this.#=z5jn9mD9$vVAy.ReadArray<byte>(2L, array, 0, (int)num);
		return Encoding.UTF8.GetString(array);
	}

	// Token: 0x06001304 RID: 4868 RVA: 0x00092D78 File Offset: 0x00090F78
	public void #=zzRmfSs0=(string #=zNt13QGc=)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(#=zNt13QGc=);
		this.#=z5jn9mD9$vVAy.Write(0L, (short)bytes.Length);
		this.#=z5jn9mD9$vVAy.WriteArray<byte>(2L, bytes, 0, bytes.Length);
	}

	// Token: 0x06001305 RID: 4869 RVA: 0x00092DB4 File Offset: 0x00090FB4
	public void Dispose()
	{
		this.#=z5jn9mD9$vVAy.Dispose();
		this.#=zkSbg3HI=.Dispose();
	}

	// Token: 0x04000AE7 RID: 2791
	private int #=zf$TeaQ0=;

	// Token: 0x04000AE8 RID: 2792
	private MemoryMappedFile #=zkSbg3HI=;

	// Token: 0x04000AE9 RID: 2793
	private MemoryMappedViewAccessor #=z5jn9mD9$vVAy;
}
