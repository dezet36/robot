﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Skink.SnR.Common;
using Skink.SnR.Common.Interface;

// Token: 0x0200019C RID: 412
internal sealed partial class #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg== : Form
{
	// Token: 0x06000BFC RID: 3068 RVA: 0x00061D84 File Offset: 0x0005FF84
	public #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=)
	{
		this.#=zgpzgXirqPT5_();
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=z87n$QYHiz3$vOoJLjA== = new List<AccountRegisterInfo>
		{
			new AccountRegisterInfo()
		};
		this.#=z8rrb$Ert8l5kBH8Cbg==.AutoGenerateColumns = false;
		DataGridViewComboBoxColumn dataGridViewComboBoxColumn = this.#=z8rrb$Ert8l5kBH8Cbg==.Columns[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302)] as DataGridViewComboBoxColumn;
		dataGridViewComboBoxColumn.ValueMember = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112775);
		dataGridViewComboBoxColumn.DisplayMember = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112765);
		dataGridViewComboBoxColumn.DataSource = new List<KeyValuePair<AccountRegisterStatuses, string>>
		{
			new KeyValuePair<AccountRegisterStatuses, string>(AccountRegisterStatuses.Unknown, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112745))),
			new KeyValuePair<AccountRegisterStatuses, string>(AccountRegisterStatuses.Registered, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112735))),
			new KeyValuePair<AccountRegisterStatuses, string>(AccountRegisterStatuses.NotRegistered, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112706)))
		};
		this.#=z8rrb$Ert8l5kBH8Cbg==.DataSource = this.#=z87n$QYHiz3$vOoJLjA==;
		#=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos=.#=zcBW$PBE=(this.#=z8rrb$Ert8l5kBH8Cbg==, null);
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x00061E84 File Offset: 0x00060084
	private void #=z4G5Q_5d4fqSm(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zClQIqe2_LWiE.Enabled = false;
		if (this.#=zkKJigFQ= >= this.#=z87n$QYHiz3$vOoJLjA==.Count)
		{
			this.#=zT$Fkk8hIiKCv.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112437));
			return;
		}
		AccountRegisterInfo accountRegisterInfo = this.#=z87n$QYHiz3$vOoJLjA==[this.#=zkKJigFQ=];
		bool flag = true;
		if (accountRegisterInfo.IsSelected && accountRegisterInfo.Status != AccountRegisterStatuses.Registered)
		{
			flag = this.#=znGA9oB0r3doT4YNozXImIB8=(accountRegisterInfo);
			this.#=zcBSiDOgQqUjT();
		}
		if (flag)
		{
			this.#=zkKJigFQ=++;
			this.#=zClQIqe2_LWiE.Enabled = true;
			return;
		}
		this.#=zT$Fkk8hIiKCv.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112437));
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x00061F38 File Offset: 0x00060138
	private bool #=znGA9oB0r3doT4YNozXImIB8=(AccountRegisterInfo #=zwdSW3gY=)
	{
		int result = 1;
		if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zzVO7jsiozzIu(#=zwdSW3gY=.#=zh5Q$jgycqA15()))
		{
			#=zwdSW3gY=.Status = AccountRegisterStatuses.Registered;
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zZCnf9GRArmR4(this.#=zshVEGQI=.#=zOdy_aU_tk1aY(), #=zwdSW3gY=.#=zh5Q$jgycqA15().#=zh5Q$jgycqA15().#=zCCvotbi$42tS(), #=zwdSW3gY=.#=zh5Q$jgycqA15().#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7(), #=zwdSW3gY=.#=zh5Q$jgycqA15().#=z$V9uwJPAniCv());
			return result != 0;
		}
		#=zwdSW3gY=.Status = AccountRegisterStatuses.NotRegistered;
		return result != 0;
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x00061FA0 File Offset: 0x000601A0
	private void #=zcBSiDOgQqUjT()
	{
		this.#=z8rrb$Ert8l5kBH8Cbg==.DataSource = null;
		this.#=z8rrb$Ert8l5kBH8Cbg==.DataSource = this.#=z87n$QYHiz3$vOoJLjA==;
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x00061FC0 File Offset: 0x000601C0
	private void #=zGhmFqCCgPJDBfFcT9A0ga6s=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex >= 0 && #=z4Q$h3mE=.ColumnIndex < this.#=z8rrb$Ert8l5kBH8Cbg==.Columns.Count && #=z4Q$h3mE=.RowIndex >= 0 && #=z4Q$h3mE=.RowIndex < this.#=z8rrb$Ert8l5kBH8Cbg==.Rows.Count)
		{
			string name = this.#=z8rrb$Ert8l5kBH8Cbg==.Columns[#=z4Q$h3mE=.ColumnIndex].Name;
			if (name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112403))
			{
				this.#=znGA9oB0r3doT4YNozXImIB8=(this.#=z8rrb$Ert8l5kBH8Cbg==.Rows[#=z4Q$h3mE=.RowIndex].DataBoundItem as AccountRegisterInfo);
				this.#=zcBSiDOgQqUjT();
				return;
			}
			if (name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112388))
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = (this.#=z8rrb$Ert8l5kBH8Cbg==.Rows[#=z4Q$h3mE=.RowIndex].DataBoundItem as AccountRegisterInfo).#=zh5Q$jgycqA15();
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ().Count > 0)
				{
					#=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=ze$wRqZvk4IFxxkyZrijhYK$eX_La = #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ()[0].#=z3YtB02S6CjKY();
					StringBuilder stringBuilder = new StringBuilder();
					#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM= = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zi1hFJwI=();
					for (int i = 0; i < #=ze$wRqZvk4IFxxkyZrijhYK$eX_La.Count; i++)
					{
						#=zDSiRXECNe4Awos25aECUKlmR8FRd #=zDSiRXECNe4Awos25aECUKlmR8FRd = #=ze$wRqZvk4IFxxkyZrijhYK$eX_La[i];
						if (#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zq2bPTdY=() <= LogTypes.Tracing)
						{
							if (stringBuilder.Length > 0)
							{
								stringBuilder.Append(Environment.NewLine);
							}
							stringBuilder.Append(#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=znwxGN8g=(#=zGR3UNcM=));
						}
					}
					if (stringBuilder.Length > 0)
					{
						#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(stringBuilder.ToString());
						return;
					}
				}
				else
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112364));
				}
			}
		}
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x00062154 File Offset: 0x00060354
	private void #=zJfXxKG9VnBTJ(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z87n$QYHiz3$vOoJLjA==.Add(new AccountRegisterInfo());
		this.#=zcBSiDOgQqUjT();
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x0006216C File Offset: 0x0006036C
	private void #=z4VX6O$_i9cAGqBcrxw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<AccountRegisterInfo> list = this.#=z87n$QYHiz3$vOoJLjA==.FindAll(new Predicate<AccountRegisterInfo>(#=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==.#=zyDNvciU=.#=zLkw0NRU=.#=zwzxfXNIVBDETdRcyMs7UXJYl6ep7));
		if (list.Count == 0)
		{
			foreach (object obj in this.#=z8rrb$Ert8l5kBH8Cbg==.SelectedRows)
			{
				DataGridViewRow dataGridViewRow = (DataGridViewRow)obj;
				list.Add(dataGridViewRow.DataBoundItem as AccountRegisterInfo);
			}
		}
		if (list.Count > 0)
		{
			foreach (AccountRegisterInfo item in list)
			{
				this.#=z87n$QYHiz3$vOoJLjA==.Remove(item);
			}
			this.#=zcBSiDOgQqUjT();
		}
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x0006225C File Offset: 0x0006045C
	private void #=zKqxwPI99W3ocv2XRdQ==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		bool isSelected = this.#=z87n$QYHiz3$vOoJLjA==.FindAll(new Predicate<AccountRegisterInfo>(#=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==.#=zyDNvciU=.#=zLkw0NRU=.#=zCKprs9pG3YLP7tn6WrNbXsgDw0Do)).Count > 0;
		foreach (AccountRegisterInfo accountRegisterInfo in this.#=z87n$QYHiz3$vOoJLjA==)
		{
			accountRegisterInfo.IsSelected = isSelected;
		}
		this.#=zcBSiDOgQqUjT();
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x000622E8 File Offset: 0x000604E8
	private void #=z9VHP1vKFUISuxD80fw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (!this.#=zClQIqe2_LWiE.Enabled)
		{
			this.#=zkKJigFQ= = 0;
			this.#=zClQIqe2_LWiE.Enabled = true;
			this.#=zT$Fkk8hIiKCv.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112343));
			return;
		}
		this.#=zClQIqe2_LWiE.Enabled = false;
		this.#=zT$Fkk8hIiKCv.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112437));
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x00062358 File Offset: 0x00060558
	private void #=zmktfc2uUe0ln(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (AccountRegisterInfo accountRegisterInfo in this.#=z87n$QYHiz3$vOoJLjA==)
		{
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112561), new object[]
			{
				Environment.NewLine,
				accountRegisterInfo.Login,
				accountRegisterInfo.Password,
				accountRegisterInfo.UserName
			});
		}
		Clipboard.SetText(stringBuilder.ToString());
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112538));
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x00062400 File Offset: 0x00060600
	private void #=zG2PMbSRZYcAZ(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (Clipboard.ContainsText())
			{
				string text = Clipboard.GetText();
				if (!string.IsNullOrWhiteSpace(text))
				{
					string[] array = text.Split(new string[]
					{
						Environment.NewLine
					}, StringSplitOptions.RemoveEmptyEntries);
					List<AccountRegisterInfo> list = new List<AccountRegisterInfo>();
					foreach (string text2 in array)
					{
						if (!string.IsNullOrWhiteSpace(text2))
						{
							string[] array3 = text2.Split(new char[]
							{
								'\t'
							});
							if (array3.Length < 3)
							{
								list.Clear();
								break;
							}
							string text3 = array3[0];
							string text4 = array3[1];
							string text5 = array3[2];
							if (string.IsNullOrWhiteSpace(text3) || string.IsNullOrWhiteSpace(text4) || string.IsNullOrWhiteSpace(text5))
							{
								list.Clear();
								break;
							}
							list.Add(new AccountRegisterInfo(text3.Trim(), text4.Trim(), text5.Trim()));
						}
					}
					if (list.Count > 0)
					{
						this.#=z87n$QYHiz3$vOoJLjA==.Clear();
						this.#=z87n$QYHiz3$vOoJLjA==.AddRange(list);
						this.#=zcBSiDOgQqUjT();
						#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112533));
					}
				}
			}
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x00062560 File Offset: 0x00060760
	private void #=zgpzgXirqPT5_()
	{
		this.#=zRWEHIqY= = new Container();
		this.#=zClQIqe2_LWiE = new Timer(this.#=zRWEHIqY=);
		this.#=z8rrb$Ert8l5kBH8Cbg== = new DataGridView();
		this.#=zT$Fkk8hIiKCv = new Button();
		this.#=zMGND58EADYqc = new Button();
		this.#=zJtq2fNA= = new Button();
		this.#=zG4U4acHyB8YS = new Button();
		this.#=z8bcpLWm$DpFw = new SplitContainer();
		this.#=zGDK_Uh0= = new Button();
		this.#=zz7L_8T4= = new Button();
		this.#=zLjL0Bis= = new DataGridViewCheckBoxColumn();
		this.#=zAfDv7ow= = new DataGridViewTextBoxColumn();
		this.#=zrAvVh3s= = new DataGridViewTextBoxColumn();
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=z4MyWf6o= = new DataGridViewButtonColumn();
		this.#=zF$GpR2Q= = new DataGridViewComboBoxColumn();
		this.#=znfxe28YtDWl5 = new DataGridViewButtonColumn();
		((ISupportInitialize)this.#=z8rrb$Ert8l5kBH8Cbg==).BeginInit();
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).BeginInit();
		this.#=z8bcpLWm$DpFw.Panel1.SuspendLayout();
		this.#=z8bcpLWm$DpFw.Panel2.SuspendLayout();
		this.#=z8bcpLWm$DpFw.SuspendLayout();
		base.SuspendLayout();
		this.#=zClQIqe2_LWiE.Tick += this.#=z4G5Q_5d4fqSm;
		this.#=z8rrb$Ert8l5kBH8Cbg==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z8rrb$Ert8l5kBH8Cbg==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zLjL0Bis=,
			this.#=zAfDv7ow=,
			this.#=zrAvVh3s=,
			this.#=zO0jJkos=,
			this.#=z4MyWf6o=,
			this.#=zF$GpR2Q=,
			this.#=znfxe28YtDWl5
		});
		this.#=z8rrb$Ert8l5kBH8Cbg==.Dock = DockStyle.Fill;
		this.#=z8rrb$Ert8l5kBH8Cbg==.EditMode = DataGridViewEditMode.EditOnEnter;
		this.#=z8rrb$Ert8l5kBH8Cbg==.Location = new Point(0, 0);
		this.#=z8rrb$Ert8l5kBH8Cbg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112516);
		this.#=z8rrb$Ert8l5kBH8Cbg==.Size = new Size(943, 503);
		this.#=z8rrb$Ert8l5kBH8Cbg==.TabIndex = 1;
		this.#=z8rrb$Ert8l5kBH8Cbg==.CellClick += this.#=zGhmFqCCgPJDBfFcT9A0ga6s=;
		this.#=zT$Fkk8hIiKCv.Location = new Point(419, 3);
		this.#=zT$Fkk8hIiKCv.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112493);
		this.#=zT$Fkk8hIiKCv.Size = new Size(202, 23);
		this.#=zT$Fkk8hIiKCv.TabIndex = 2;
		this.#=zT$Fkk8hIiKCv.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112437);
		this.#=zT$Fkk8hIiKCv.UseVisualStyleBackColor = true;
		this.#=zT$Fkk8hIiKCv.Click += this.#=z9VHP1vKFUISuxD80fw==;
		this.#=zMGND58EADYqc.Location = new Point(302, 3);
		this.#=zMGND58EADYqc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112462);
		this.#=zMGND58EADYqc.Size = new Size(111, 23);
		this.#=zMGND58EADYqc.TabIndex = 3;
		this.#=zMGND58EADYqc.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114224);
		this.#=zMGND58EADYqc.UseVisualStyleBackColor = true;
		this.#=zMGND58EADYqc.Click += this.#=zKqxwPI99W3ocv2XRdQ==;
		this.#=zJtq2fNA=.Location = new Point(12, 3);
		this.#=zJtq2fNA=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114215);
		this.#=zJtq2fNA=.Size = new Size(139, 23);
		this.#=zJtq2fNA=.TabIndex = 4;
		this.#=zJtq2fNA=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114186);
		this.#=zJtq2fNA=.UseVisualStyleBackColor = true;
		this.#=zJtq2fNA=.Click += this.#=zJfXxKG9VnBTJ;
		this.#=zG4U4acHyB8YS.Location = new Point(157, 3);
		this.#=zG4U4acHyB8YS.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114170);
		this.#=zG4U4acHyB8YS.Size = new Size(139, 23);
		this.#=zG4U4acHyB8YS.TabIndex = 5;
		this.#=zG4U4acHyB8YS.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114145);
		this.#=zG4U4acHyB8YS.UseVisualStyleBackColor = true;
		this.#=zG4U4acHyB8YS.Click += this.#=z4VX6O$_i9cAGqBcrxw==;
		this.#=z8bcpLWm$DpFw.Dock = DockStyle.Fill;
		this.#=z8bcpLWm$DpFw.FixedPanel = FixedPanel.Panel2;
		this.#=z8bcpLWm$DpFw.IsSplitterFixed = true;
		this.#=z8bcpLWm$DpFw.Location = new Point(0, 0);
		this.#=z8bcpLWm$DpFw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114121);
		this.#=z8bcpLWm$DpFw.Orientation = Orientation.Horizontal;
		this.#=z8bcpLWm$DpFw.Panel1.Controls.Add(this.#=z8rrb$Ert8l5kBH8Cbg==);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zGDK_Uh0=);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zz7L_8T4=);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zG4U4acHyB8YS);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zT$Fkk8hIiKCv);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zMGND58EADYqc);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zJtq2fNA=);
		this.#=z8bcpLWm$DpFw.Size = new Size(943, 540);
		this.#=z8bcpLWm$DpFw.SplitterDistance = 503;
		this.#=z8bcpLWm$DpFw.TabIndex = 6;
		this.#=zGDK_Uh0=.Location = new Point(772, 3);
		this.#=zGDK_Uh0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113272);
		this.#=zGDK_Uh0=.Size = new Size(139, 23);
		this.#=zGDK_Uh0=.TabIndex = 7;
		this.#=zGDK_Uh0=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114358);
		this.#=zGDK_Uh0=.UseVisualStyleBackColor = true;
		this.#=zGDK_Uh0=.Click += this.#=zG2PMbSRZYcAZ;
		this.#=zz7L_8T4=.Location = new Point(627, 3);
		this.#=zz7L_8T4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110865);
		this.#=zz7L_8T4=.Size = new Size(139, 23);
		this.#=zz7L_8T4=.TabIndex = 6;
		this.#=zz7L_8T4=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114323);
		this.#=zz7L_8T4=.UseVisualStyleBackColor = true;
		this.#=zz7L_8T4=.Click += this.#=zmktfc2uUe0ln;
		this.#=zLjL0Bis=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113211);
		this.#=zLjL0Bis=.HeaderText = string.Empty;
		this.#=zLjL0Bis=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109696);
		this.#=zLjL0Bis=.Width = 30;
		this.#=zAfDv7ow=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168);
		this.#=zAfDv7ow=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111277);
		this.#=zAfDv7ow=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312);
		this.#=zAfDv7ow=.Width = 150;
		this.#=zrAvVh3s=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111208);
		this.#=zrAvVh3s=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111195);
		this.#=zrAvVh3s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111176);
		this.#=zO0jJkos=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111263);
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.Width = 150;
		this.#=z4MyWf6o=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114297);
		this.#=z4MyWf6o=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114274);
		this.#=z4MyWf6o=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112403);
		this.#=z4MyWf6o=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114263);
		this.#=z4MyWf6o=.Width = 120;
		this.#=zF$GpR2Q=.AutoComplete = false;
		this.#=zF$GpR2Q=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113982);
		this.#=zF$GpR2Q=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110886);
		this.#=zF$GpR2Q=.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112745),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112735),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112706)
		});
		this.#=zF$GpR2Q=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109302);
		this.#=zF$GpR2Q=.Width = 120;
		this.#=znfxe28YtDWl5.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113963);
		this.#=znfxe28YtDWl5.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109712);
		this.#=znfxe28YtDWl5.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112388);
		this.#=znfxe28YtDWl5.Resizable = DataGridViewTriState.True;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(943, 540);
		base.Controls.Add(this.#=z8bcpLWm$DpFw);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113940);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113907);
		((ISupportInitialize)this.#=z8rrb$Ert8l5kBH8Cbg==).EndInit();
		this.#=z8bcpLWm$DpFw.Panel1.ResumeLayout(false);
		this.#=z8bcpLWm$DpFw.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).EndInit();
		this.#=z8bcpLWm$DpFw.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040006EF RID: 1775
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x040006F0 RID: 1776
	private List<AccountRegisterInfo> #=z87n$QYHiz3$vOoJLjA==;

	// Token: 0x040006F1 RID: 1777
	private int #=zkKJigFQ=;

	// Token: 0x040006F3 RID: 1779
	private Timer #=zClQIqe2_LWiE;

	// Token: 0x040006F4 RID: 1780
	private DataGridView #=z8rrb$Ert8l5kBH8Cbg==;

	// Token: 0x040006F5 RID: 1781
	private Button #=zT$Fkk8hIiKCv;

	// Token: 0x040006F6 RID: 1782
	private Button #=zMGND58EADYqc;

	// Token: 0x040006F7 RID: 1783
	private Button #=zJtq2fNA=;

	// Token: 0x040006F8 RID: 1784
	private Button #=zG4U4acHyB8YS;

	// Token: 0x040006F9 RID: 1785
	private SplitContainer #=z8bcpLWm$DpFw;

	// Token: 0x040006FA RID: 1786
	private Button #=zGDK_Uh0=;

	// Token: 0x040006FB RID: 1787
	private Button #=zz7L_8T4=;

	// Token: 0x040006FC RID: 1788
	private DataGridViewCheckBoxColumn #=zLjL0Bis=;

	// Token: 0x040006FD RID: 1789
	private DataGridViewTextBoxColumn #=zAfDv7ow=;

	// Token: 0x040006FE RID: 1790
	private DataGridViewTextBoxColumn #=zrAvVh3s=;

	// Token: 0x040006FF RID: 1791
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x04000700 RID: 1792
	private DataGridViewButtonColumn #=z4MyWf6o=;

	// Token: 0x04000701 RID: 1793
	private DataGridViewComboBoxColumn #=zF$GpR2Q=;

	// Token: 0x04000702 RID: 1794
	private DataGridViewButtonColumn #=znfxe28YtDWl5;

	// Token: 0x0200019D RID: 413
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000C0B RID: 3083 RVA: 0x00062EF8 File Offset: 0x000610F8
		internal bool #=zwzxfXNIVBDETdRcyMs7UXJYl6ep7(AccountRegisterInfo #=zQrqFdos=)
		{
			return #=zQrqFdos=.IsSelected;
		}

		// Token: 0x06000C0C RID: 3084 RVA: 0x00062F00 File Offset: 0x00061100
		internal bool #=zCKprs9pG3YLP7tn6WrNbXsgDw0Do(AccountRegisterInfo #=zQrqFdos=)
		{
			return !#=zQrqFdos=.IsSelected;
		}

		// Token: 0x04000703 RID: 1795
		public static readonly #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==.#=zyDNvciU= #=zLkw0NRU= = new #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==.#=zyDNvciU=();

		// Token: 0x04000704 RID: 1796
		public static Predicate<AccountRegisterInfo> #=zLLcqwWqPPIJnz60lVA==;

		// Token: 0x04000705 RID: 1797
		public static Predicate<AccountRegisterInfo> #=zQMgwRPHblNnKBhJcMQ==;
	}
}
