﻿using System;
using System.IO;
using System.Text;

// Token: 0x020000F5 RID: 245
internal sealed class #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ
{
	// Token: 0x0600065D RID: 1629 RVA: 0x000332BC File Offset: 0x000314BC
	public static bool #=zTUmbCKI=(string #=z0ONi4Bk=)
	{
		return File.Exists(#=z0ONi4Bk=);
	}

	// Token: 0x0600065E RID: 1630 RVA: 0x000332C4 File Offset: 0x000314C4
	public static string #=zE6GjVX8zbW5W(string #=z0ONi4Bk=)
	{
		return File.ReadAllText(#=z0ONi4Bk=);
	}

	// Token: 0x0600065F RID: 1631 RVA: 0x000332CC File Offset: 0x000314CC
	public static string[] #=zy1H78pXHw7bQ(string #=z0ONi4Bk=)
	{
		return File.ReadAllLines(#=z0ONi4Bk=);
	}

	// Token: 0x06000660 RID: 1632 RVA: 0x000332D4 File Offset: 0x000314D4
	public static DateTime #=zFC3B_hWy9GfK(string #=z0ONi4Bk=)
	{
		return File.GetLastWriteTime(#=z0ONi4Bk=);
	}

	// Token: 0x06000661 RID: 1633 RVA: 0x000332DC File Offset: 0x000314DC
	public static void #=z49OzGHBofb6l(string #=z0ONi4Bk=, string #=zNt13QGc=, Encoding #=zy94iCdA=, bool #=zFYgUgoL73FKQ)
	{
		object obj = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zSV4$mlFB34WM;
		lock (obj)
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z5dJ5$XONi5d1YLtKvA==(#=z0ONi4Bk=);
			if (#=zy94iCdA= != null)
			{
				File.WriteAllText(#=z0ONi4Bk=, #=zNt13QGc=, #=zy94iCdA=);
			}
			else
			{
				File.WriteAllText(#=z0ONi4Bk=, #=zNt13QGc=);
			}
			if (#=zFYgUgoL73FKQ)
			{
				string text = #=z0ONi4Bk= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859);
				string text2 = #=z0ONi4Bk= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064854);
				bool flag2 = false;
				if (!File.Exists(text))
				{
					flag2 = true;
				}
				else if (File.GetLastWriteTime(text) < DateTime.Now - TimeSpan.FromHours(1.0))
				{
					flag2 = true;
				}
				if (flag2)
				{
					try
					{
						if (File.ReadAllText(#=z0ONi4Bk=) != #=zNt13QGc=)
						{
							flag2 = false;
						}
					}
					catch
					{
						flag2 = false;
					}
				}
				if (flag2)
				{
					if (File.Exists(text))
					{
						if (File.Exists(text2))
						{
							File.Delete(text2);
						}
						File.Move(text, text2);
					}
					File.Copy(#=z0ONi4Bk=, text, true);
				}
			}
		}
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x000333E0 File Offset: 0x000315E0
	public static void #=zxyAQIs1RlUuf(string #=z0ONi4Bk=, string #=zNt13QGc=, Encoding #=zy94iCdA=)
	{
		object obj = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zSV4$mlFB34WM;
		lock (obj)
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z5dJ5$XONi5d1YLtKvA==(#=z0ONi4Bk=);
			if (#=zy94iCdA= != null)
			{
				File.AppendAllText(#=z0ONi4Bk=, #=zNt13QGc=, #=zy94iCdA=);
			}
			else
			{
				File.AppendAllText(#=z0ONi4Bk=, #=zNt13QGc=);
			}
		}
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00033434 File Offset: 0x00031634
	public static void #=zorxJD84=(string #=z0ONi4Bk=)
	{
		object obj = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zSV4$mlFB34WM;
		lock (obj)
		{
			File.Delete(#=z0ONi4Bk=);
		}
	}

	// Token: 0x06000664 RID: 1636 RVA: 0x00033474 File Offset: 0x00031674
	public static void #=zz5WrUWQ=(string #=za_tT7VQ=, string #=z7bZtJ$s=, bool #=zdhlhVfs=)
	{
		object obj = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zSV4$mlFB34WM;
		lock (obj)
		{
			File.Copy(#=za_tT7VQ=, #=z7bZtJ$s=, #=zdhlhVfs=);
		}
	}

	// Token: 0x06000665 RID: 1637 RVA: 0x000334B8 File Offset: 0x000316B8
	public static void #=z5CNc4A0=(string #=za_tT7VQ=, string #=z7bZtJ$s=)
	{
		object obj = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zSV4$mlFB34WM;
		lock (obj)
		{
			File.Move(#=za_tT7VQ=, #=z7bZtJ$s=);
		}
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x000334F8 File Offset: 0x000316F8
	private static void #=z5dJ5$XONi5d1YLtKvA==(string #=z0ONi4Bk=)
	{
		if (!Directory.Exists(Path.GetDirectoryName(#=z0ONi4Bk=)))
		{
			Directory.CreateDirectory(Path.GetDirectoryName(#=z0ONi4Bk=));
		}
	}

	// Token: 0x040002A8 RID: 680
	private static object #=zSV4$mlFB34WM = new object();
}
