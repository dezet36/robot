﻿using System;
using System.Collections.Generic;

// Token: 0x020000B0 RID: 176
internal sealed class #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=
{
	// Token: 0x06000492 RID: 1170 RVA: 0x00026B10 File Offset: 0x00024D10
	private #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=()
	{
		this.#=zLTo2lT7OuIbAmn1oMg==(new #=zUnqMHgYcw4kzYQNkai6lKUHUuT3C0iujZaTS8M4u0NiMCjwlvpvhWO48ecu2CoYkv6q3v6YdeSKU());
		this.#=zgFyIYOikphtcWq87YO0czoI=(new Dictionary<string, DateTime>());
		this.#=zigFaCaydDoAd8IYgqAQXKtk=(new Dictionary<string, DateTime>());
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x00026B50 File Offset: 0x00024D50
	public #=zUnqMHgYcw4kzYQNkai6lKUHUuT3C0iujZaTS8M4u0NiMCjwlvpvhWO48ecu2CoYkv6q3v6YdeSKU #=zr3WItDTdDNjwEqvBUQ==()
	{
		return this.#=zwfhBV3cvy9Mw84joW367TP4=;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x00026B58 File Offset: 0x00024D58
	public void #=zLTo2lT7OuIbAmn1oMg==(#=zUnqMHgYcw4kzYQNkai6lKUHUuT3C0iujZaTS8M4u0NiMCjwlvpvhWO48ecu2CoYkv6q3v6YdeSKU #=z$Ib9gYQ=)
	{
		this.#=zwfhBV3cvy9Mw84joW367TP4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000496 RID: 1174 RVA: 0x00026B64 File Offset: 0x00024D64
	public Dictionary<string, DateTime> #=z3771NxvEw$qP1UmtrrUKJCs=()
	{
		return this.#=z6ZdYWHc1W3XtGeoInweCH_QgV0RE;
	}

	// Token: 0x06000497 RID: 1175 RVA: 0x00026B6C File Offset: 0x00024D6C
	public void #=zgFyIYOikphtcWq87YO0czoI=(Dictionary<string, DateTime> #=z$Ib9gYQ=)
	{
		this.#=z6ZdYWHc1W3XtGeoInweCH_QgV0RE = #=z$Ib9gYQ=;
	}

	// Token: 0x06000498 RID: 1176 RVA: 0x00026B78 File Offset: 0x00024D78
	public Dictionary<string, DateTime> #=zwV9F4I7KWp8fIQLMe5qHMYs=()
	{
		return this.#=zRJ8r8ZJkg8qI_KIqVzXSkD6v_GnczAdE6A==;
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x00026B80 File Offset: 0x00024D80
	public void #=zigFaCaydDoAd8IYgqAQXKtk=(Dictionary<string, DateTime> #=z$Ib9gYQ=)
	{
		this.#=zRJ8r8ZJkg8qI_KIqVzXSkD6v_GnczAdE6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x00026B8C File Offset: 0x00024D8C
	public static #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs= #=zKVN4CRU=()
	{
		if (#=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=.#=zOAzeRO$HqsMN == null)
		{
			object obj = #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=.#=zOAzeRO$HqsMN == null)
				{
					#=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=.#=zOAzeRO$HqsMN = new #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=();
				}
			}
		}
		return #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs=.#=zOAzeRO$HqsMN;
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x00026BE8 File Offset: 0x00024DE8
	public bool #=zx4QXcijnkQL_(string #=zKQqxdOSR3lie, double #=zACnd4gneUPf$)
	{
		bool result = false;
		if ((this.#=z3771NxvEw$qP1UmtrrUKJCs=().ContainsKey(#=zKQqxdOSR3lie) ? this.#=z3771NxvEw$qP1UmtrrUKJCs=()[#=zKQqxdOSR3lie] : DateTime.MinValue) < DateTime.Now)
		{
			lock (this)
			{
				if ((this.#=z3771NxvEw$qP1UmtrrUKJCs=().ContainsKey(#=zKQqxdOSR3lie) ? this.#=z3771NxvEw$qP1UmtrrUKJCs=()[#=zKQqxdOSR3lie] : DateTime.MinValue) < DateTime.Now)
				{
					result = true;
					this.#=z3771NxvEw$qP1UmtrrUKJCs=()[#=zKQqxdOSR3lie] = DateTime.Now + TimeSpan.FromMinutes(#=zACnd4gneUPf$);
				}
			}
		}
		return result;
	}

	// Token: 0x040001B8 RID: 440
	private #=zUnqMHgYcw4kzYQNkai6lKUHUuT3C0iujZaTS8M4u0NiMCjwlvpvhWO48ecu2CoYkv6q3v6YdeSKU #=zwfhBV3cvy9Mw84joW367TP4=;

	// Token: 0x040001B9 RID: 441
	private Dictionary<string, DateTime> #=z6ZdYWHc1W3XtGeoInweCH_QgV0RE;

	// Token: 0x040001BA RID: 442
	private Dictionary<string, DateTime> #=zRJ8r8ZJkg8qI_KIqVzXSkD6v_GnczAdE6A==;

	// Token: 0x040001BB RID: 443
	private static #=z98S495Ycx8_TLs3OhHhk7SPW9ERMeikJBrm2bgiN3FZ0iXhq13ndWzCsgYXwPlkafOgqBBs= #=zOAzeRO$HqsMN = null;

	// Token: 0x040001BC RID: 444
	private static object #=zSV4$mlFB34WM = new object();
}
