﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000180 RID: 384
internal sealed class #=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4 : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000AF7 RID: 2807 RVA: 0x00054C44 File Offset: 0x00052E44
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zoYQQ_3O001Btu8K$T5aOwrw= = #=zuJjQ1XU=.#=zYubRv_IdFXo9HaY2Cyq8ABQsCryc();
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zawloLR4AQAF_32q7rQ== = #=zuJjQ1XU=.#=zXzBC$aJalrr0Db$QLCfSwSA=();
		this.#=znmyDeS0OacNZwPmJ6YZ$l6Y= = #=zuJjQ1XU=.#=zIQDLqtJxqgZWX88MoNdeTR0k5rMf();
	}

	// Token: 0x06000AF8 RID: 2808 RVA: 0x00054C84 File Offset: 0x00052E84
	protected override void #=zvb5bnug=()
	{
		this.#=zXlivMJZ9nF$9uJvglcFCZPOZRAINUQvj_w==();
		#=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4.#=zAJFRSgr_hfdThPi0GVYGg5k=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=znmyDeS0OacNZwPmJ6YZ$l6Y=, new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>());
		#=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4.#=z1aXVLyRMmESZ6v4hVvaUy0I=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=znmyDeS0OacNZwPmJ6YZ$l6Y=);
		#=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4.#=z05F3emkKaoDT5SYjp7toXRc=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zawloLR4AQAF_32q7rQ==, this.#=znmyDeS0OacNZwPmJ6YZ$l6Y=);
	}

	// Token: 0x06000AF9 RID: 2809 RVA: 0x00054CF4 File Offset: 0x00052EF4
	private void #=zXlivMJZ9nF$9uJvglcFCZPOZRAINUQvj_w==()
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding)
		{
			return;
		}
		List<int> list = new List<int>
		{
			1,
			8,
			7
		};
		int num = this.#=zoYQQ_3O001Btu8K$T5aOwrw=;
		if (num >= 100)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932224), new object[]
			{
				num
			});
		}
		object[] array = JSONManager.GetArray(JSONManager.GetData(this.#=zBsXSanI=.#=z25ZMSNzHGIdZYvzzQw==()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933926));
		if (array == null)
		{
			return;
		}
		bool flag = false;
		foreach (Dictionary<string, object> dictionary in array)
		{
			int item = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]);
			if (list.Contains(item) && Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]) != this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
			{
				bool flag2 = false;
				object[] array2 = JSONManager.GetArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966));
				if (array2 != null)
				{
					for (int j = 0; j < array2.Length; j++)
					{
						if (Convert.ToInt32(array2[j]) == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
						{
							flag2 = true;
							break;
						}
					}
				}
				if (!flag2)
				{
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934069), Array.Empty<object>());
			return;
		}
		string text = this.#=zBsXSanI=.#=zHqy4LJE9kQMrV6mkZEE9d$ImV5TRj7cdDQ==(list);
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933906), Array.Empty<object>());
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934105), new object[]
		{
			JSONManager.Cut(text)
		});
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x00054EEC File Offset: 0x000530EC
	public static void #=zAJFRSgr_hfdThPi0GVYGg5k=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==, List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=z_x2otZPIYLyq, List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=zb2AOmKLGF1WIvmLdXQ==)
	{
		if (!#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding)
		{
			return;
		}
		#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = null;
		int num = 0;
		if (#=zb2AOmKLGF1WIvmLdXQ==.Count > 0)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zb2AOmKLGF1WIvmLdXQ==[0];
			if (num < 2)
			{
				num = 2;
			}
		}
		else
		{
			for (int i = 0; i < #=zatMRdFUxBCRS1oul8g==.Count; i++)
			{
				if (#=zatMRdFUxBCRS1oul8g==[i].#=z5kpAZQpjT2b7())
				{
					if (num < 1)
					{
						num = 1;
					}
					#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 = #=zatMRdFUxBCRS1oul8g==[i];
					bool flag = false;
					int j = 0;
					while (j < #=z_x2otZPIYLyq.Count)
					{
						#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl = #=z_x2otZPIYLyq[j];
						if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zq2bPTdY=() == (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zArez$Gs=)0 && #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zK5gF1KeGk_H_() == #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zMuFMjGQ=())
						{
							if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=z8t$FeXGfLTQN() == #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zvnZc$RhG_1Du())
							{
								flag = true;
								break;
							}
							break;
						}
						else
						{
							j++;
						}
					}
					if (!flag)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zO6457TajDDxDJIsKqS1bbzDMLckn2;
						if (num < 2)
						{
							num = 2;
							break;
						}
						break;
					}
				}
			}
		}
		if (#=zO6457TajDDxDJIsKqS1bbzDMLckn != null)
		{
			try
			{
				if (num < 3)
				{
					num = 3;
				}
				string text = #=zBsXSanI=.#=zutWyipbKPQEafObbDw0Ln2j4Kbf_(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zMuFMjGQ=());
				if (text.Length > 10000)
				{
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933755), new object[]
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=(),
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du()
					});
				}
				else
				{
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933665), new object[]
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=(),
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du(),
						JSONManager.Cut(text)
					});
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
			}
		}
		switch (num)
		{
		case 0:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933821), Array.Empty<object>());
			return;
		case 1:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933500), Array.Empty<object>());
			return;
		case 2:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933402), Array.Empty<object>());
			return;
		default:
			return;
		}
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x000550FC File Offset: 0x000532FC
	public static void #=z1aXVLyRMmESZ6v4hVvaUy0I=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zZ61w3rgvgY1YOZ4EoCDelTU=, List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=z_x2otZPIYLyq)
	{
		if (!#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding)
		{
			return;
		}
		#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = null;
		int num = 0;
		for (int i = 0; i < #=zZ61w3rgvgY1YOZ4EoCDelTU=.Count; i++)
		{
			if (#=zZ61w3rgvgY1YOZ4EoCDelTU=[i].#=z5kpAZQpjT2b7())
			{
				if (num < 1)
				{
					num = 1;
				}
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 = #=zZ61w3rgvgY1YOZ4EoCDelTU=[i];
				bool flag = false;
				int j = 0;
				while (j < #=z_x2otZPIYLyq.Count)
				{
					#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl = #=z_x2otZPIYLyq[j];
					if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zq2bPTdY=() == (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zArez$Gs=)1 && #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zK5gF1KeGk_H_() == #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zMuFMjGQ=())
					{
						if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=z8t$FeXGfLTQN() == #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zvnZc$RhG_1Du())
						{
							flag = true;
							break;
						}
						break;
					}
					else
					{
						j++;
					}
				}
				if (!flag)
				{
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2;
					if (num < 2)
					{
						num = 2;
						break;
					}
					break;
				}
			}
		}
		if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null)
		{
			if (num < 3)
			{
				num = 3;
			}
			string text = #=zBsXSanI=.#=zkL0DRKZzpfXQzDW0CFREuEP$MASM(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zMuFMjGQ=());
			if (text.Length > 10000)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933601), new object[]
				{
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du()
				});
			}
			else
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933521), new object[]
				{
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du(),
					JSONManager.Cut(text)
				});
			}
		}
		switch (num)
		{
		case 0:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933173), Array.Empty<object>());
			return;
		case 1:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933134), Array.Empty<object>());
			return;
		case 2:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933402), Array.Empty<object>());
			return;
		default:
			return;
		}
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x000552C0 File Offset: 0x000534C0
	public static void #=z05F3emkKaoDT5SYjp7toXRc=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zc1y0_hs=, List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=z_x2otZPIYLyq)
	{
		if (!#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding)
		{
			return;
		}
		#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = null;
		int num = 0;
		for (int i = 0; i < #=zc1y0_hs=.Count; i++)
		{
			if (#=zc1y0_hs=[i].#=zdln9Op$NubUKpgj1nPP6ujU=())
			{
				if (num < 1)
				{
					num = 1;
				}
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = #=zc1y0_hs=[i];
				bool flag = false;
				int j = 0;
				while (j < #=z_x2otZPIYLyq.Count)
				{
					#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl = #=z_x2otZPIYLyq[j];
					if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zq2bPTdY=() == (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zArez$Gs=)5 && #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zK5gF1KeGk_H_() == #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.Id)
					{
						if (#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl.#=zdln9Op$NubUKpgj1nPP6ujU=())
						{
							flag = true;
							break;
						}
						break;
					}
					else
					{
						j++;
					}
				}
				if (!flag)
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2;
					if (num < 2)
					{
						num = 2;
						break;
					}
					break;
				}
			}
		}
		if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= != null)
		{
			if (num < 3)
			{
				num = 3;
			}
			string text = #=zBsXSanI=.#=z9o2Xc2CHIVqQ539$4ruwoXK54hif(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id);
			if (text.Length > 10000)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933308), new object[]
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=(),
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==()
				});
			}
			else
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934994), new object[]
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=(),
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==(),
					JSONManager.Cut(text)
				});
			}
		}
		switch (num)
		{
		case 0:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935139), Array.Empty<object>());
			return;
		case 1:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935093), Array.Empty<object>());
			return;
		case 2:
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908933402), Array.Empty<object>());
			return;
		default:
			return;
		}
	}

	// Token: 0x040005DC RID: 1500
	private int #=zoYQQ_3O001Btu8K$T5aOwrw=;

	// Token: 0x040005DD RID: 1501
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x040005DE RID: 1502
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x040005DF RID: 1503
	private List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zawloLR4AQAF_32q7rQ==;

	// Token: 0x040005E0 RID: 1504
	private List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=znmyDeS0OacNZwPmJ6YZ$l6Y=;
}
