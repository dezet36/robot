﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000138 RID: 312
internal sealed class #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a
{
	// Token: 0x06000835 RID: 2101 RVA: 0x00041E2C File Offset: 0x0004002C
	public #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a(Dictionary<string, object> #=zJRUhY$qtX$O2)
	{
		this.#=zxiT_RLav2aLvEz97sQ==(0);
		this.#=zicca_RxFidy9chhs3Q==(0);
		this.#=zz9CDbzCCkmzxwMRUhA==(0);
		this.#=zOnGTRK7FfJkrmLddqw==(0);
		foreach (object obj in #=zJRUhY$qtX$O2.Values)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)obj;
			int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
			if (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=z_NSZBCNyokeQ(num) == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
			{
				int num2 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0);
				if (num2 == 0)
				{
					int num3 = this.#=zlgiJcK9NKBvv9ufWeQ==();
					this.#=zxiT_RLav2aLvEz97sQ==(num3 + 1);
					if (this.#=zTRW$aE$gba$c$ScVqw==() == 0 || num < this.#=zTRW$aE$gba$c$ScVqw==())
					{
						this.#=zz9CDbzCCkmzxwMRUhA==(num);
					}
					if (this.#=zyq3US4V39TsN3oKSrA==() == 0 || num > this.#=zyq3US4V39TsN3oKSrA==())
					{
						this.#=zOnGTRK7FfJkrmLddqw==(num);
					}
				}
				else if (num2 == 1)
				{
					int num3 = this.#=zOCBHgkyzUdifcaSWcA==();
					this.#=zicca_RxFidy9chhs3Q==(num3 + 1);
				}
			}
		}
	}

	// Token: 0x06000836 RID: 2102 RVA: 0x00041F2C File Offset: 0x0004012C
	public int #=zlgiJcK9NKBvv9ufWeQ==()
	{
		return this.#=zWBK$O8WKzA95IjNfmrWDqt0=;
	}

	// Token: 0x06000837 RID: 2103 RVA: 0x00041F34 File Offset: 0x00040134
	public void #=zxiT_RLav2aLvEz97sQ==(int #=z$Ib9gYQ=)
	{
		this.#=zWBK$O8WKzA95IjNfmrWDqt0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000838 RID: 2104 RVA: 0x00041F40 File Offset: 0x00040140
	public int #=zOCBHgkyzUdifcaSWcA==()
	{
		return this.#=zKpcHCO3iRdx7VjUndXZtMCM=;
	}

	// Token: 0x06000839 RID: 2105 RVA: 0x00041F48 File Offset: 0x00040148
	public void #=zicca_RxFidy9chhs3Q==(int #=z$Ib9gYQ=)
	{
		this.#=zKpcHCO3iRdx7VjUndXZtMCM= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600083A RID: 2106 RVA: 0x00041F54 File Offset: 0x00040154
	public int #=zTRW$aE$gba$c$ScVqw==()
	{
		return this.#=zTK8k7_3PefkSS8kBC5Jq_F0=;
	}

	// Token: 0x0600083B RID: 2107 RVA: 0x00041F5C File Offset: 0x0004015C
	public void #=zz9CDbzCCkmzxwMRUhA==(int #=z$Ib9gYQ=)
	{
		this.#=zTK8k7_3PefkSS8kBC5Jq_F0= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600083C RID: 2108 RVA: 0x00041F68 File Offset: 0x00040168
	public int #=zyq3US4V39TsN3oKSrA==()
	{
		return this.#=zdTYglK99HIURE5WNR6$L7ao=;
	}

	// Token: 0x0600083D RID: 2109 RVA: 0x00041F70 File Offset: 0x00040170
	public void #=zOnGTRK7FfJkrmLddqw==(int #=z$Ib9gYQ=)
	{
		this.#=zdTYglK99HIURE5WNR6$L7ao= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600083E RID: 2110 RVA: 0x00041F7C File Offset: 0x0004017C
	public static #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q== #=z_NSZBCNyokeQ(int #=zuYY$1pg=)
	{
		if (#=zuYY$1pg= >= 1 && #=zuYY$1pg= <= 10)
		{
			return (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)1;
		}
		if (#=zuYY$1pg= >= 100 && #=zuYY$1pg= <= 199)
		{
			return (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)2;
		}
		if (#=zuYY$1pg= >= 1000 && #=zuYY$1pg= <= 1999)
		{
			return (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3;
		}
		return (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)0;
	}

	// Token: 0x040004B0 RID: 1200
	private int #=zWBK$O8WKzA95IjNfmrWDqt0=;

	// Token: 0x040004B1 RID: 1201
	private int #=zKpcHCO3iRdx7VjUndXZtMCM=;

	// Token: 0x040004B2 RID: 1202
	private int #=zTK8k7_3PefkSS8kBC5Jq_F0=;

	// Token: 0x040004B3 RID: 1203
	private int #=zdTYglK99HIURE5WNR6$L7ao=;

	// Token: 0x02000139 RID: 313
	public enum #=zpym8P$oCmghwvUlJ3Q==
	{

	}
}
