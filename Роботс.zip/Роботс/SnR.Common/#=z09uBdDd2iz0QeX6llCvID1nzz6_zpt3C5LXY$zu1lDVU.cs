﻿using System;

// Token: 0x0200002A RID: 42
internal sealed class #=z09uBdDd2iz0QeX6llCvID1nzz6_zpt3C5LXY$zu1lDVU : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000095 RID: 149 RVA: 0x00004E08 File Offset: 0x00003008
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zWhxmN$m5Fz5D = #=zuJjQ1XU=.#=zzDosIddISk1$();
	}

	// Token: 0x06000096 RID: 150 RVA: 0x00004E18 File Offset: 0x00003018
	protected override void #=zvb5bnug=()
	{
		#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zi1hFJwI=();
		#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = null;
		foreach (int #=zAk8mKBk= in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().NanosToUpgradeIds)
		{
			#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==2 = this.#=zWhxmN$m5Fz5D.#=zk$6QZNA=(#=zAk8mKBk=);
			if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==2 != null)
			{
				if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==2.#=zvnZc$RhG_1Du() < #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==2.#=zq2bPTdY=().#=zaDKBEnk8Vsod())
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==2;
					break;
				}
			}
			else
			{
				#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zk$6QZNA=(#=zAk8mKBk=);
				if (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== != null)
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==3 = new #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==();
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==3.#=zzQwUIEs=(#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==);
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==3.#=zFzGvi_S6jJhE(0);
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==3;
					break;
				}
			}
		}
		if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== != null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962283), new object[]
			{
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=()
			});
			while (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zq2bPTdY=().#=zYzmhGhVKHiNP().Count > 0)
			{
				bool flag = false;
				foreach (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== in #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zq2bPTdY=().#=zYzmhGhVKHiNP())
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==4 = this.#=zWhxmN$m5Fz5D.#=zk$6QZNA=(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zFMDiymuLQ7_4());
					if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==4 != null)
					{
						if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==4.#=zvnZc$RhG_1Du() < #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zvnZc$RhG_1Du())
						{
							#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==4;
							flag = true;
							break;
						}
					}
					else
					{
						#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==2 = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zk$6QZNA=(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zFMDiymuLQ7_4());
						if (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==2 != null)
						{
							#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==5 = new #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==();
							#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==5.#=zzQwUIEs=(#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==2);
							#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==5.#=zFzGvi_S6jJhE(0);
							#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==5;
							flag = true;
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962234), new object[]
						{
							#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zFMDiymuLQ7_4()
						});
						return;
					}
				}
				if (!flag)
				{
					break;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961909), new object[]
			{
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=()
			});
			string text = this.#=zBsXSanI=.#=zUrWP6WtFzA3_fYlCeQ==(#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==);
			text = text.Trim();
			if (text.Length >= 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982252), new object[]
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=(),
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zvnZc$RhG_1Du() + 1
				});
				return;
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980453)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980415), new object[]
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=(),
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zvnZc$RhG_1Du() + 1
				});
				return;
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976435)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961862), new object[]
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=(),
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zvnZc$RhG_1Du() + 1
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961792), new object[]
			{
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zkfqcY3I=(),
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zvnZc$RhG_1Du() + 1,
				text
			});
			return;
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961994), Array.Empty<object>());
		}
	}

	// Token: 0x04000031 RID: 49
	private #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=zWhxmN$m5Fz5D;
}
