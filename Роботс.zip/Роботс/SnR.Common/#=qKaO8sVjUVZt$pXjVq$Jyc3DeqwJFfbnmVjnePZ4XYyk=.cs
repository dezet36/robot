﻿using System;
using System.Runtime.InteropServices;
using System.Text;

// Token: 0x02000008 RID: 8
[StructLayout(LayoutKind.Auto, CharSet = CharSet.Auto)]
internal static class #=qKaO8sVjUVZt$pXjVq$Jyc3DeqwJFfbnmVjnePZ4XYyk=
{
	// Token: 0x0600001F RID: 31 RVA: 0x00002E78 File Offset: 0x00001078
	internal static StringBuilder #=z8EhZmdfmgCSv(StringBuilder #=zkzkYSXg=, string #=zyShZ9QI=, int #=zMjBZKTU=)
	{
		return #=zkzkYSXg=.Append(#=zyShZ9QI=, #=zMjBZKTU=, #=zyShZ9QI=.Length - #=zMjBZKTU=);
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002E8C File Offset: 0x0000108C
	internal static bool #=zpRU7t58lATzJ(byte[] #=zkzkYSXg=, byte[] #=zyShZ9QI=)
	{
		if (#=zkzkYSXg= == null || #=zyShZ9QI= == null)
		{
			throw new ArgumentNullException();
		}
		if (#=zkzkYSXg= == #=zyShZ9QI=)
		{
			return true;
		}
		if (#=zkzkYSXg=.Length != #=zyShZ9QI=.Length)
		{
			return false;
		}
		for (int i = 0; i < #=zkzkYSXg=.Length; i++)
		{
			if (#=zkzkYSXg=[i] != #=zyShZ9QI=[i])
			{
				return false;
			}
		}
		return true;
	}
}
