﻿using System;

// Token: 0x0200007C RID: 124
internal sealed class #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=
{
	// Token: 0x06000380 RID: 896 RVA: 0x0001F948 File Offset: 0x0001DB48
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000381 RID: 897 RVA: 0x0001F950 File Offset: 0x0001DB50
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000382 RID: 898 RVA: 0x0001F95C File Offset: 0x0001DB5C
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x06000383 RID: 899 RVA: 0x0001F964 File Offset: 0x0001DB64
	public void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000384 RID: 900 RVA: 0x0001F970 File Offset: 0x0001DB70
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0001F978 File Offset: 0x0001DB78
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0001F984 File Offset: 0x0001DB84
	public int #=z8Nl16CPh9dN5()
	{
		return this.#=zNgo9sLPBSkVeTNAHtw==;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x0001F98C File Offset: 0x0001DB8C
	public void #=zg8A$A1dlfoa2(int #=z$Ib9gYQ=)
	{
		this.#=zNgo9sLPBSkVeTNAHtw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400013A RID: 314
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400013B RID: 315
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x0400013C RID: 316
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400013D RID: 317
	private int #=zNgo9sLPBSkVeTNAHtw==;
}
