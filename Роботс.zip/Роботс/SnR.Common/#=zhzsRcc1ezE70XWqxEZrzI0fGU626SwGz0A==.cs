﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Global;

// Token: 0x02000258 RID: 600
internal sealed partial class #=zhzsRcc1ezE70XWqxEZrzI0fGU626SwGz0A== : Form
{
	// Token: 0x06001230 RID: 4656 RVA: 0x0008B820 File Offset: 0x00089A20
	public #=zhzsRcc1ezE70XWqxEZrzI0fGU626SwGz0A==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zgpzgXirqPT5_();
		this.#=z_uAN7dRTLotu.SelectedIndex = 0;
		base.DialogResult = DialogResult.Cancel;
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001231 RID: 4657 RVA: 0x0008B850 File Offset: 0x00089A50
	private void #=zQ3iU0IZAcNN6(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zshVEGQI=.#=zmj_BPos=(this.#=zB$E_mCaQGmHMc1hR0Q==.Text, (ProxyFormats)this.#=z_uAN7dRTLotu.SelectedIndex, true);
		base.DialogResult = DialogResult.OK;
	}

	// Token: 0x06001233 RID: 4659 RVA: 0x0008B89C File Offset: 0x00089A9C
	private void #=zgpzgXirqPT5_()
	{
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(#=zhzsRcc1ezE70XWqxEZrzI0fGU626SwGz0A==));
		this.#=zH9QrHK4wEgcOsyE0rw== = new Label();
		this.#=zB$E_mCaQGmHMc1hR0Q== = new TextBox();
		this.#=z3HbHjlVYHX6u = new Button();
		this.#=z_uAN7dRTLotu = new ComboBox();
		this.#=z3bbLr2HZuAOx = new Label();
		this.#=zImkvA6lPr1h384q9dQ== = new Label();
		base.SuspendLayout();
		this.#=zH9QrHK4wEgcOsyE0rw==.AutoSize = true;
		this.#=zH9QrHK4wEgcOsyE0rw==.Location = new Point(12, 22);
		this.#=zH9QrHK4wEgcOsyE0rw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087062);
		this.#=zH9QrHK4wEgcOsyE0rw==.Size = new Size(485, 39);
		this.#=zH9QrHK4wEgcOsyE0rw==.TabIndex = 0;
		this.#=zH9QrHK4wEgcOsyE0rw==.Text = componentResourceManager.GetString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087039));
		this.#=zB$E_mCaQGmHMc1hR0Q==.Location = new Point(15, 101);
		this.#=zB$E_mCaQGmHMc1hR0Q==.Multiline = true;
		this.#=zB$E_mCaQGmHMc1hR0Q==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087001);
		this.#=zB$E_mCaQGmHMc1hR0Q==.Size = new Size(505, 243);
		this.#=zB$E_mCaQGmHMc1hR0Q==.TabIndex = 1;
		this.#=z3HbHjlVYHX6u.Location = new Point(30, 350);
		this.#=z3HbHjlVYHX6u.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087224);
		this.#=z3HbHjlVYHX6u.Size = new Size(75, 23);
		this.#=z3HbHjlVYHX6u.TabIndex = 2;
		this.#=z3HbHjlVYHX6u.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087213);
		this.#=z3HbHjlVYHX6u.UseVisualStyleBackColor = true;
		this.#=z3HbHjlVYHX6u.Click += this.#=zQ3iU0IZAcNN6;
		this.#=z_uAN7dRTLotu.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=z_uAN7dRTLotu.FormattingEnabled = true;
		this.#=z_uAN7dRTLotu.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087193),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087160)
		});
		this.#=z_uAN7dRTLotu.Location = new Point(97, 74);
		this.#=z_uAN7dRTLotu.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087131);
		this.#=z_uAN7dRTLotu.Size = new Size(261, 21);
		this.#=z_uAN7dRTLotu.TabIndex = 3;
		this.#=z3bbLr2HZuAOx.AutoSize = true;
		this.#=z3bbLr2HZuAOx.Location = new Point(12, 77);
		this.#=z3bbLr2HZuAOx.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087105);
		this.#=z3bbLr2HZuAOx.Size = new Size(48, 13);
		this.#=z3bbLr2HZuAOx.TabIndex = 4;
		this.#=z3bbLr2HZuAOx.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086824);
		this.#=zImkvA6lPr1h384q9dQ==.AutoSize = true;
		this.#=zImkvA6lPr1h384q9dQ==.Location = new Point(12, 9);
		this.#=zImkvA6lPr1h384q9dQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086808);
		this.#=zImkvA6lPr1h384q9dQ==.Size = new Size(198, 13);
		this.#=zImkvA6lPr1h384q9dQ==.TabIndex = 4;
		this.#=zImkvA6lPr1h384q9dQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086785);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(767, 385);
		base.Controls.Add(this.#=zImkvA6lPr1h384q9dQ==);
		base.Controls.Add(this.#=z3bbLr2HZuAOx);
		base.Controls.Add(this.#=z_uAN7dRTLotu);
		base.Controls.Add(this.#=z3HbHjlVYHX6u);
		base.Controls.Add(this.#=zB$E_mCaQGmHMc1hR0Q==);
		base.Controls.Add(this.#=zH9QrHK4wEgcOsyE0rw==);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086742);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086742);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000A29 RID: 2601
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000A2B RID: 2603
	private Label #=zH9QrHK4wEgcOsyE0rw==;

	// Token: 0x04000A2C RID: 2604
	private TextBox #=zB$E_mCaQGmHMc1hR0Q==;

	// Token: 0x04000A2D RID: 2605
	private Button #=z3HbHjlVYHX6u;

	// Token: 0x04000A2E RID: 2606
	private ComboBox #=z_uAN7dRTLotu;

	// Token: 0x04000A2F RID: 2607
	private Label #=z3bbLr2HZuAOx;

	// Token: 0x04000A30 RID: 2608
	private Label #=zImkvA6lPr1h384q9dQ==;
}
