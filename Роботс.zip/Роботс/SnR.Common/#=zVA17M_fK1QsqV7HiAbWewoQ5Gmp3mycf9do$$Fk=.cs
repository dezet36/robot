﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x020001BB RID: 443
internal sealed class #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=
{
	// Token: 0x06000D3D RID: 3389 RVA: 0x0006843C File Offset: 0x0006663C
	public #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=(int #=zp13pRNQ=)
	{
		this.#=zedb$WwBQsoJF(#=zp13pRNQ=);
		this.#=zaIGo8ZtWk3sG(0);
		this.#=z4s1J_BTngVeY(new Dictionary<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=>());
	}

	// Token: 0x06000D3E RID: 3390 RVA: 0x00068460 File Offset: 0x00066660
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x06000D3F RID: 3391 RVA: 0x00068468 File Offset: 0x00066668
	private void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D40 RID: 3392 RVA: 0x00068474 File Offset: 0x00066674
	public int #=zBHuoQg9JVxim()
	{
		return this.#=zdlxzHhdbC$_ZJZjysvi4w0Q=;
	}

	// Token: 0x06000D41 RID: 3393 RVA: 0x0006847C File Offset: 0x0006667C
	private void #=zaIGo8ZtWk3sG(int #=z$Ib9gYQ=)
	{
		this.#=zdlxzHhdbC$_ZJZjysvi4w0Q= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D42 RID: 3394 RVA: 0x00068488 File Offset: 0x00066688
	public Dictionary<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=> #=zw9C6B_6NSRtu()
	{
		return this.#=zMnHH$$rDNKf9IWyXag==;
	}

	// Token: 0x06000D43 RID: 3395 RVA: 0x00068490 File Offset: 0x00066690
	public void #=z4s1J_BTngVeY(Dictionary<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=> #=z$Ib9gYQ=)
	{
		this.#=zMnHH$$rDNKf9IWyXag== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D44 RID: 3396 RVA: 0x0006849C File Offset: 0x0006669C
	public void #=z48rEd0A=(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=, int #=zE0Kwkt2hWS4FO0Namg==)
	{
		if (!this.#=zw9C6B_6NSRtu().ContainsKey(#=zZnwdOIE=))
		{
			#=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ= #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ= = new #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=(#=zZnwdOIE=, #=zE0Kwkt2hWS4FO0Namg==);
			this.#=zw9C6B_6NSRtu().Add(#=zZnwdOIE=, #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=);
		}
		else
		{
			#=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ= #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ= = this.#=zw9C6B_6NSRtu()[#=zZnwdOIE=];
			#=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=.#=z48rEd0A=(#=zE0Kwkt2hWS4FO0Namg==);
		}
		this.#=zaIGo8ZtWk3sG(this.#=zBHuoQg9JVxim() + #=zE0Kwkt2hWS4FO0Namg==);
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x000684F0 File Offset: 0x000666F0
	public int #=z8bPgQdHrr2WZ(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=)
	{
		if (this.#=zw9C6B_6NSRtu().ContainsKey(#=zZnwdOIE=))
		{
			return this.#=zw9C6B_6NSRtu()[#=zZnwdOIE=].#=z2UCBrfce7z8r();
		}
		return 0;
	}

	// Token: 0x06000D46 RID: 3398 RVA: 0x00068514 File Offset: 0x00066714
	public static bool #=z1G2yq220nKu$(Worlds #=z4bTgQI8RY7Z2, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=)
	{
		if (#=z4bTgQI8RY7Z2 == Worlds.Veor)
		{
			return #=zZnwdOIE= == (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0;
		}
		return #=zZnwdOIE= - (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)3 <= 4;
	}

	// Token: 0x06000D47 RID: 3399 RVA: 0x0006852C File Offset: 0x0006672C
	public static bool #=zX35dz$Dz2oVq(Worlds #=z4bTgQI8RY7Z2, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=)
	{
		if (#=z4bTgQI8RY7Z2 == Worlds.Veor)
		{
			return #=zZnwdOIE= == (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)8;
		}
		return #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=z1G2yq220nKu$(#=z4bTgQI8RY7Z2, #=zZnwdOIE=);
	}

	// Token: 0x040007A4 RID: 1956
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x040007A5 RID: 1957
	private int #=zdlxzHhdbC$_ZJZjysvi4w0Q=;

	// Token: 0x040007A6 RID: 1958
	private Dictionary<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=> #=zMnHH$$rDNKf9IWyXag==;
}
