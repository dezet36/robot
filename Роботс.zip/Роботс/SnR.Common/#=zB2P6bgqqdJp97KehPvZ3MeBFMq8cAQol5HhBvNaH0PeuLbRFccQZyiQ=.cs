﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x020000C1 RID: 193
internal sealed class #=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600050B RID: 1291 RVA: 0x00028E64 File Offset: 0x00027064
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zkdGdpYZ7Wpxf = #=zuJjQ1XU=.#=zoSyVTLOhKIN4();
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=zJr4GDlRh4CkxysOnQzRTvIs= = #=zuJjQ1XU=.#=ztY2Wai5zsO_u1Ct5WFVJPR0=();
		this.#=zJgBKL1dWlurwuFRt1A== = #=zuJjQ1XU=.#=z6IODMVzrU6HMa5LZg021HYs=();
		this.#=zJP6f31LM7O6pfu2pU5oCGB0= = #=zuJjQ1XU=.#=z_zzDSQCAp84Wuuup9dIcR2c=();
		this.#=zxZjYVP2XT8qmcT9c2Q== = #=zuJjQ1XU=.#=zdz_5DLjhAG09Q78wOA==();
		this.#=zlhLE8UQVU0AG = UnitTypeCollection.Get();
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x00028F00 File Offset: 0x00027100
	protected override void #=zvb5bnug=()
	{
		this.#=zpzrSpck= = this.#=z8StzeqE=;
		this.#=zcTyyNys= = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=zcDRV51Ut$7oP;
		if (this.#=zbRsLRm4=())
		{
			object #=zBCxv0_Eazs = this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zBCxv0_Eazs01;
			lock (#=zBCxv0_Eazs)
			{
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod != this.#=zcTyyNys=.#=znfPjOezUI9V6FOMG_g7VWK8=())
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod = this.#=zcTyyNys=.#=znfPjOezUI9V6FOMG_g7VWK8=();
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
					if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoAutoRobbery)
					{
						Task task = this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobberyStart);
						if (task != null)
						{
							task.RepeatDelayMin = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod;
							task.RepeatDelayMax = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod;
							task.ExecutionTime = DateTime.Now + task.RepeatDelay();
						}
					}
				}
				this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Remove(this.#=zcDRV51Ut$7oP);
			}
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z_JR3E3WhnnqK(this.#=z8StzeqE=, DateTime.Now + this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod);
		}
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x00029074 File Offset: 0x00027274
	public bool #=zbRsLRm4=()
	{
		if (!this.#=zpzrSpck=.#=zv2Kyu17YrGOC().IsDoAutoRobbery)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934160), Array.Empty<object>());
			return true;
		}
		if (this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zm$eV_xKe0$husB8mphQFSSA=() == 0 && this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zTbIA4C5CygIVRWnmzW7mz0Y=() == 0)
		{
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=z70541YBK1YJMhjNxqjvtBLY=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==());
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zSiEqujcwstLt50qjDCEAnqU=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==());
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
		}
		else if ((this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zm$eV_xKe0$husB8mphQFSSA=() != this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() || this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zTbIA4C5CygIVRWnmzW7mz0Y=() != this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==()) && this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsFullResetOnCoordChange)
		{
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=z4jMUBqOjoL$2(this.#=zpzrSpck=, false);
			this.#=zcTyyNys=.#=zGSYXNAWR258T(0);
		}
		else if (this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zLtwfFiMhuJDkTP6cew==() < DateTime.Now - TimeSpan.FromDays((double)this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobTargetSearchResetPeriodDays))
		{
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zW3vXs9Q=(this.#=zpzrSpck=);
			this.#=zcTyyNys=.#=zGSYXNAWR258T(0);
		}
		if (this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zNXUG8XbJFWN8mht01A==())
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGncKSH4oJhxW9OLT6A==(this.#=zcTyyNys=.#=z5_3JqsL118hV(), this.#=zpzrSpck=);
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(false);
		}
		if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==() == null)
		{
			if (this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==() != null || this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() >= this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - 1)
			{
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsNoTargetSearch)
				{
					if (this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==() != null)
					{
						this.#=za1WthWno9ZYxIURZtw==();
					}
					if (this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() >= this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - 1)
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934390), Array.Empty<object>());
						return true;
					}
				}
				else
				{
					this.#=zcEouH60$zS6tOTo72zPKys8=();
					if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance > 0 && (Math.Abs(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zf0e9blCCGf6ut3r1Nw==()) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance || Math.Abs(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zbRWovF5fxGmOqm7gAQ==()) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance))
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919657), Array.Empty<object>());
						#=z6WGF48kImHdKxLII90Za03kTJT$Rkt3QzFO_G5ewawyrVmLbGg== comparer = new #=z6WGF48kImHdKxLII90Za03kTJT$Rkt3QzFO_G5ewawyrVmLbGg==(this.#=z3yL5bKs=);
						int num;
						if (this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==() != null)
						{
							this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==().Sort(comparer);
							num = this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==().Count;
						}
						else
						{
							num = 0;
						}
						int num2 = (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==() != null) ? this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count : 0;
						while (num2 > 0 && num > 0)
						{
							if (this.#=zCBtsnmpJpM3bkhIGDQ==())
							{
								this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919776), Array.Empty<object>());
								return true;
							}
							bool flag;
							this.#=zw6lYBLabNiAvAHiIDw==(this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==()[0], out flag);
							this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==().RemoveAt(0);
						}
						if (num2 > 0)
						{
							this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919729), new object[]
							{
								num2
							});
						}
						else
						{
							this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919393), Array.Empty<object>());
						}
						return true;
					}
					this.#=ztIGX6sohEjKR();
					this.#=za1WthWno9ZYxIURZtw==();
				}
			}
			else
			{
				if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==() == null)
				{
					if (this.#=zCBtsnmpJpM3bkhIGDQ==())
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919352), Array.Empty<object>());
						return true;
					}
					this.#=zCCK0rDd9X_BLPt_kiXZImKs=(this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, this.#=zJr4GDlRh4CkxysOnQzRTvIs=, false);
					if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count == 0)
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919297), Array.Empty<object>());
						return true;
					}
				}
				else
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919496), new object[]
					{
						this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count
					});
				}
				this.#=zl9VTq9iV9KAL3H7FoQ==();
				this.#=zD5fQkZQiCx$Sr8VTcg==();
				if (this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() >= this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - 1)
				{
					if (this.#=zcTyyNys=.#=znRSpoHRxOsWr().#=zR75Bpho=(ProblemType.NotEnoughScouts))
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919443), new object[]
						{
							this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count
						});
						if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count == 0)
						{
							this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919124), Array.Empty<object>());
							return true;
						}
					}
					else
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919087), new object[]
						{
							this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count
						});
					}
				}
			}
		}
		else
		{
			int num3 = this.#=zD5fQkZQiCx$Sr8VTcg==();
			if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count > 0)
			{
				List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zVG1EPv1OUDdyLeGHGQ==;
				bool flag2;
				if (num3 > 0)
				{
					flag2 = true;
				}
				else
				{
					DateTime dateTime = DateTime.MaxValue;
					foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in list)
					{
						if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Contains(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()) && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() < dateTime)
						{
							dateTime = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==();
						}
					}
					flag2 = (dateTime != DateTime.MaxValue);
					if (flag2)
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919256), new object[]
						{
							dateTime
						});
					}
				}
				if (!flag2)
				{
					if (this.#=zcTyyNys=.#=zXk8s4ULAsIXsAvv01hkXUGs=() == DateTime.MaxValue)
					{
						this.#=zcTyyNys=.#=zWF8G8qD8vQtGjS8Y8lpaTFM=(DateTime.Now + TimeSpan.FromMinutes(5.0));
					}
					else if (!(this.#=zcTyyNys=.#=zXk8s4ULAsIXsAvv01hkXUGs=() > DateTime.Now) && this.#=z$UxbXr2jOqJKa4D4m_0IY$4=())
					{
						this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Clear();
						#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(this.#=zpzrSpck=.#=zYgvZuBwR$a1C()).#=zywN9YWzCtruB(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
					}
				}
				else if (this.#=zcTyyNys=.#=zXk8s4ULAsIXsAvv01hkXUGs=() < DateTime.MaxValue)
				{
					this.#=zcTyyNys=.#=zWF8G8qD8vQtGjS8Y8lpaTFM=(DateTime.MaxValue);
				}
			}
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count > 0)
			{
				if (this.#=zCBtsnmpJpM3bkhIGDQ==())
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919180), Array.Empty<object>());
					return true;
				}
				object[] #=z63V0q6sQrHWbgfWzdQ== = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
				this.#=zsaohgri9rELL7KghQw==(#=z63V0q6sQrHWbgfWzdQ==);
			}
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count > 0)
			{
				if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count <= 0)
				{
					this.#=zcTyyNys=.#=zfJg0zSfdHKGW$fTQAQ==(null);
					this.#=zcTyyNys=.#=zf2xpHQyExsx20x0Byg==(null);
					this.#=zcTyyNys=.#=zWF8G8qD8vQtGjS8Y8lpaTFM=(DateTime.MaxValue);
					this.#=zcTyyNys=.#=zP9nJD5fkPIBZftsclxGxPg3GZMBgzgzLAeCdBvBpvqMk(this.#=zcTyyNys=.#=zCb4PsTBNolywZCYiu4flce3$chIhEQ$MmeYpKxqXplA1() + 1);
				}
			}
			else
			{
				if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count <= 0)
				{
					#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(this.#=zpzrSpck=.#=zYgvZuBwR$a1C()).#=zywN9YWzCtruB(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908918877), Array.Empty<object>());
					return true;
				}
				this.#=zFz33vlVXFLbd_holDl61glOZzd3Y();
			}
		}
		return false;
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x00029964 File Offset: 0x00027B64
	private void #=zcEouH60$zS6tOTo72zPKys8=()
	{
		if (this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==() == null)
		{
			this.#=zcTyyNys=.#=zaG9Dgn2hcyzWaAUsNA==(new #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==(TaskTypes.AutoRobbery));
			this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=z1jlGMrg=(this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zItiY1kgj0ZFJ(), this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zRo77rEs$ZyU6());
			this.#=zcTyyNys=.#=ziKpRrk$lWVCJhGJRcA==(new List<int>());
		}
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x000299D0 File Offset: 0x00027BD0
	private void #=ztIGX6sohEjKR()
	{
		DateTime t = DateTime.Now + TimeSpan.FromMinutes(5.0);
		for (int i = 0; i < 25; i++)
		{
			int num = this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zf0e9blCCGf6ut3r1Nw==() + this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==();
			int num2 = this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zbRWovF5fxGmOqm7gAQ==() + this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==();
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908918838), new object[]
			{
				num,
				num2,
				this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - this.#=zcTyyNys=.#=zRsQ5gV$zlUjk()
			});
			foreach (Dictionary<string, object> dictionary in (object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=zpeSgyDU=(num, num2)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)])
			{
				int num3 = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)))
				{
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)];
					int num4 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]);
					int num5 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]);
					if (Math.Abs(num4 - num) <= 50 && Math.Abs(num5 - num2) <= 50 && !this.#=zcTyyNys=.#=zpbz203I90pe6jeaNNQ==().Contains(num3))
					{
						#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
						#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ== #=z6SVOTqeHwoPJYYYMAQ== = this.#=znez0p$RosubzyQHHTg==(dictionary, null, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
						if ((#=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1 || #=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)2) && this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zk$6QZNA=(num3) == null)
						{
							string #=z6QPrZ_4= = dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)) ? dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)].ToString() : (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919036) + num4.ToString() + num5.ToString()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871), string.Empty);
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = new #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(num3, #=z6QPrZ_4=, num4, num5);
							#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=zvS9NMPa5Yz5Vbpjs0ICBHLE=(this.#=zpzrSpck=, this.#=zBsXSanI=, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=, JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
							this.#=zcTyyNys=.#=z5_3JqsL118hV().Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
							this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919019), new object[]
							{
								#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
								#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
							});
						}
						this.#=zcTyyNys=.#=zpbz203I90pe6jeaNNQ==().Add(num3);
					}
				}
			}
			this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zrYsCATIY3Mmo();
			if (this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() > 33 * this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutingsPerRobbery || DateTime.Now >= t)
			{
				break;
			}
		}
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x00029D08 File Offset: 0x00027F08
	private void #=za1WthWno9ZYxIURZtw==()
	{
		if (this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() > 33 * this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutingsPerRobbery || (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance > 0 && (Math.Abs(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zf0e9blCCGf6ut3r1Nw==()) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance || Math.Abs(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zbRWovF5fxGmOqm7gAQ==()) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance)) || this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsNoTargetSearch)
		{
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zODlZZHvR90va(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zf0e9blCCGf6ut3r1Nw==());
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zXD1iEriRZj5W(this.#=zcTyyNys=.#=znz2cmfctRYJnk8_ikA==().#=zbRWovF5fxGmOqm7gAQ==());
			#=z6fxFsMgelAshh1EluoE6HqR$dUG7qNBPcGtHgdA= comparer = new #=z6fxFsMgelAshh1EluoE6HqR$dUG7qNBPcGtHgdA=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B());
			this.#=zcTyyNys=.#=z5_3JqsL118hV().Sort(comparer);
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
			this.#=zcTyyNys=.#=zaG9Dgn2hcyzWaAUsNA==(null);
			this.#=zcTyyNys=.#=ziKpRrk$lWVCJhGJRcA==(null);
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908918968), new object[]
			{
				this.#=zcTyyNys=.#=z5_3JqsL118hV().Count,
				this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - this.#=zcTyyNys=.#=zRsQ5gV$zlUjk()
			});
		}
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x00029EAC File Offset: 0x000280AC
	private bool #=zCBtsnmpJpM3bkhIGDQ==()
	{
		if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDontRobStoresLevel > 0 && this.#=zkdGdpYZ7Wpxf[ResourceTypes.Bronze] > 2000)
		{
			bool flag = true;
			if (this.#=z3yL5bKs=[ResourceTypes.Lumber] * 100 / this.#=zkdGdpYZ7Wpxf[ResourceTypes.Lumber] < this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDontRobStoresLevel)
			{
				flag = false;
			}
			else if (this.#=z3yL5bKs=[ResourceTypes.Bronze] * 100 / this.#=zkdGdpYZ7Wpxf[ResourceTypes.Bronze] < this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDontRobStoresLevel)
			{
				flag = false;
			}
			else if (this.#=z3yL5bKs=[ResourceTypes.Grain] * 100 / this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] < this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDontRobStoresLevel)
			{
				flag = false;
			}
			if (flag)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920674), Array.Empty<object>());
				return true;
			}
			if (this.#=zJr4GDlRh4CkxysOnQzRTvIs= <= 0)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920628), Array.Empty<object>());
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x00029FD8 File Offset: 0x000281D8
	private void #=zCCK0rDd9X_BLPt_kiXZImKs=(UnitSquadCollection #=zf9PMeWxL61cDJoHmAQ==, int #=zo9PC_ImlqQSYpFQm4g==, bool #=zFqrqolhNA3T3XyYEzw==)
	{
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920584), Array.Empty<object>());
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		UnitType unitType = this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsUseSpecificTroops ? this.#=zlhLE8UQVU0AG.GetRobberySpecializedType() : null;
		UnitSquad unitSquad = null;
		foreach (UnitSquad unitSquad2 in #=zf9PMeWxL61cDJoHmAQ==)
		{
			if (unitSquad2.Type.Function == UnitType.Functions.Offence)
			{
				if (unitType != null && unitSquad2.Type.Id == unitType.Id)
				{
					unitSquad = unitSquad2;
				}
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsUseImprovedTroops)
				{
					if (unitSquad2.Type.Categories_HasNoneBut(new UnitType.Categories[]
					{
						UnitType.Categories.m_Elite,
						UnitType.Categories.m_Imperial,
						UnitType.Categories.m_Mutated,
						UnitType.Categories.m_Noble,
						UnitType.Categories.r_Denaries
					}))
					{
						unitSquadCollection.Add(new UnitSquad(unitSquad2.Type, unitSquad2.Number));
					}
				}
				else if (unitSquad2.Type.Categories_HasNoneBut(new UnitType.Categories[]
				{
					UnitType.Categories.m_Elite
				}))
				{
					unitSquadCollection.Add(new UnitSquad(unitSquad2.Type, unitSquad2.Number));
				}
			}
		}
		unitSquadCollection.Sort(new #=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=((#=zini7jsI7YQozrxkSuioGhimyOxqMYqff7FVnUII=.#=zArez$Gs=)1));
		if (unitSquad != null)
		{
			unitSquadCollection.Insert(0, unitSquad);
		}
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920798), new object[]
		{
			unitSquadCollection.ToStringLabels()
		});
		int num = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zqGZod7DuP$m614qxIj6v4lE=();
		if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsCaravansRob)
		{
			num += Math.Min(this.#=zJgBKL1dWlurwuFRt1A==.#=zunVWVnmqJuqR(), #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zDDkQ_RdZgdNGO6OtyQ==());
		}
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy = this.#=zkdGdpYZ7Wpxf;
		int num2 = #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Bronze] + #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Lumber] + #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Grain];
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920753), new object[]
		{
			num,
			num2,
			#=zo9PC_ImlqQSYpFQm4g==
		});
		if (#=zo9PC_ImlqQSYpFQm4g== == 0)
		{
			this.#=zcTyyNys=.#=zyUXiBfaJ5g4UiO5trA==(new List<UnitSquadCollection>());
		}
		else
		{
			if (num > num2)
			{
				num = num2;
			}
			num = (int)((double)num / 0.95) + 1;
			this.#=zcTyyNys=.#=zyUXiBfaJ5g4UiO5trA==(new List<UnitSquadCollection>());
			UnitSquadCollection unitSquadCollection2 = new UnitSquadCollection();
			int num3 = 0;
			while (unitSquadCollection.Count > 0)
			{
				UnitType type = unitSquadCollection[0].Type;
				int number = unitSquadCollection[0].Number;
				int num4;
				if (number * type.Cargo > num - num3)
				{
					num4 = (num - num3) / type.Cargo + 1;
					unitSquadCollection[0].Number = number - num4;
				}
				else
				{
					num4 = number;
					unitSquadCollection.RemoveAt(0);
				}
				unitSquadCollection2.AddUnits(type, num4);
				num3 += num4 * type.Cargo;
				if (num3 >= num)
				{
					this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Add(unitSquadCollection2);
					if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count >= #=zo9PC_ImlqQSYpFQm4g==)
					{
						break;
					}
					unitSquadCollection2 = new UnitSquadCollection();
					num3 = 0;
				}
			}
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count == 0 && unitSquadCollection2.Count > 0)
			{
				this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Add(unitSquadCollection2);
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920401), Array.Empty<object>());
			}
		}
		if (!#=zFqrqolhNA3T3XyYEzw==)
		{
			double num5;
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count >= this.#=zJr4GDlRh4CkxysOnQzRTvIs=)
			{
				num5 = 22.0;
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920351), Array.Empty<object>());
			}
			else if (this.#=zJr4GDlRh4CkxysOnQzRTvIs= >= 10 || this.#=zJr4GDlRh4CkxysOnQzRTvIs= > this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count)
			{
				num5 = 2.0;
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920533), Array.Empty<object>());
			}
			else
			{
				num5 = (double)(2 * this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count);
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920460), new object[]
				{
					num5
				});
			}
			if (num5 > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxPeriodHours)
			{
				num5 = this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxPeriodHours;
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920134), new object[]
				{
					num5
				});
			}
			this.#=zcTyyNys=.#=zORTAr0PYVZMAmxSIft1lGlQ=(TimeSpan.FromHours(num5));
		}
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920065), new object[]
		{
			this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count
		});
		for (int i = 0; i < this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count; i++)
		{
			UnitSquadCollection unitSquadCollection3 = this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[i];
			int num6 = 0;
			for (int j = 0; j < unitSquadCollection3.Count; j++)
			{
				num6 += unitSquadCollection3[j].Type.Cargo * unitSquadCollection3[j].Number;
			}
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920282), new object[]
			{
				i + 1,
				unitSquadCollection3.ToStringLabels(),
				num6
			});
		}
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x0002A5A0 File Offset: 0x000287A0
	private UnitSquadCollection #=z8iIPpq1jktw5nlIDVMbDdDu1L$lE(UnitSquadCollection #=zf9PMeWxL61cDJoHmAQ==)
	{
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		List<int> list = new List<int>();
		for (int i = 0; i < #=zf9PMeWxL61cDJoHmAQ==.Count; i++)
		{
			UnitType type = #=zf9PMeWxL61cDJoHmAQ==[i].Type;
			if (type.Function == UnitType.Functions.Scouting && type.Category == UnitType.Categories.None && !list.Contains(type.Id))
			{
				unitSquadCollection.Add(new UnitSquad(type, #=zf9PMeWxL61cDJoHmAQ==[i].Number));
				list.Add(type.Id);
			}
		}
		for (int j = 0; j < #=zf9PMeWxL61cDJoHmAQ==.Count; j++)
		{
			UnitType type2 = #=zf9PMeWxL61cDJoHmAQ==[j].Type;
			if (type2.Function == UnitType.Functions.Scouting && type2.Categories_NotHasAny(new UnitType.Categories[]
			{
				UnitType.Categories.p_Strategic
			}) && !list.Contains(type2.Id))
			{
				unitSquadCollection.Add(new UnitSquad(type2, #=zf9PMeWxL61cDJoHmAQ==[j].Number));
				list.Add(type2.Id);
			}
		}
		return unitSquadCollection;
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x0002A694 File Offset: 0x00028894
	private void #=zl9VTq9iV9KAL3H7FoQ==()
	{
		this.#=zcTyyNys=.#=zfJg0zSfdHKGW$fTQAQ==(new List<int>());
		this.#=zcTyyNys=.#=zf2xpHQyExsx20x0Byg==(new List<int>());
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(this.#=zpzrSpck=.#=zYgvZuBwR$a1C());
		int num = this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count * this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutingsPerRobbery * this.#=zcTyyNys=.#=zCb4PsTBNolywZCYiu4flce3$chIhEQ$MmeYpKxqXplA1();
		if (num > 100)
		{
			num = 100;
		}
		DateTime t = DateTime.Now + TimeSpan.FromMinutes(5.0);
		while (this.#=zcTyyNys=.#=zRsQ5gV$zlUjk() < this.#=zcTyyNys=.#=z5_3JqsL118hV().Count - 1)
		{
			if (t < DateTime.Now)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920255), Array.Empty<object>());
				return;
			}
			#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = this.#=zcTyyNys=.#=z5_3JqsL118hV()[this.#=zcTyyNys=.#=zRsQ5gV$zlUjk()];
			if (!this.#=zJP6f31LM7O6pfu2pU5oCGB0=.Contains(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()) && (!#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zSL$CHR_zajMs() || !(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zmj4J_vTRu57u() > DateTime.Now - TimeSpan.FromDays((double)this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDangerTargetRecheckPeriodDays))) && !#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zsVa4US_DOpbi() && !#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zfKZKx18=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()))
			{
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
				#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ== #=z6SVOTqeHwoPJYYYMAQ== = this.#=zovB$NjL8uCRsV7R_AA==(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
				if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z5nwSpHr8_MMZ(this.#=zpzrSpck=.#=zYgvZuBwR$a1C(), #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()))
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920215), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
					});
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=z5ktH1NpFood7(true);
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zp0wcrTDVPUwj(DateTime.Now);
					this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
				}
				else if (#=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0)
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919887), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
					});
					this.#=zcTyyNys=.#=z5_3JqsL118hV().RemoveAt(this.#=zcTyyNys=.#=zRsQ5gV$zlUjk());
					this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
				}
				else if (#=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)2)
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920027), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
					});
				}
				else if (#=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)3)
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919946), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
					});
				}
				else if (#=z6SVOTqeHwoPJYYYMAQ== == (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1)
				{
					if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zBBWgm0Q=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()))
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921701), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
							#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
						});
						this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=());
						if (this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().Count >= num)
						{
							this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921661), new object[]
							{
								this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().Count
							});
							return;
						}
					}
					else
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921616), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
							#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
						});
					}
				}
				else
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921806), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
					});
				}
			}
			#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = this.#=zcTyyNys=;
			int num2 = #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zRsQ5gV$zlUjk();
			#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zGSYXNAWR258T(num2 + 1);
		}
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x0002AAB0 File Offset: 0x00028CB0
	private int #=zD5fQkZQiCx$Sr8VTcg==()
	{
		if (this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().Count == 0)
		{
			return 0;
		}
		int num = 0;
		UnitSquadCollection unitSquadCollection = this.#=z8iIPpq1jktw5nlIDVMbDdDu1L$lE(this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==);
		UnitSquadCollection unitSquadCollection2 = this.#=z8iIPpq1jktw5nlIDVMbDdDu1L$lE(this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo);
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031));
		if (unitSquadCollection.Count > 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921460), new object[]
			{
				unitSquadCollection.ToStringLabels()
			});
		}
		if (unitSquadCollection2.Count > 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921439), new object[]
			{
				unitSquadCollection2.ToStringLabels()
			});
		}
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921403), new object[]
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==
		});
		int num2 = 0;
		while (num2 < 10 && this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().Count != 0)
		{
			#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zk$6QZNA=(this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==()[0]);
			this.#=zcTyyNys=.#=zwao59F9WTZ4llri_3A==().RemoveAt(0);
			if (unitSquadCollection.Count > 0 || unitSquadCollection2.Count > 0)
			{
				int num3 = 1;
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutsNo > 1 && this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutsNo <= 10)
				{
					num3 = this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobScoutsNo;
				}
				UnitSquadCollection unitSquadCollection3;
				UnitSquadCollection unitSquadCollection4;
				string text;
				if (unitSquadCollection.Count > 0)
				{
					if (unitSquadCollection[0].Number < num3)
					{
						num3 = unitSquadCollection[0].Number;
					}
					unitSquadCollection3 = new UnitSquadCollection
					{
						new UnitSquad(unitSquadCollection[0].Type, num3)
					};
					unitSquadCollection4 = null;
					unitSquadCollection.RemoveUnits(unitSquadCollection3);
					text = unitSquadCollection3.ToStringLabels();
				}
				else
				{
					unitSquadCollection3 = null;
					if (unitSquadCollection2[0].Number < num3)
					{
						num3 = unitSquadCollection2[0].Number;
					}
					unitSquadCollection4 = new UnitSquadCollection
					{
						new UnitSquad(unitSquadCollection2[0].Type, num3)
					};
					unitSquadCollection2.RemoveUnits(unitSquadCollection4);
					text = unitSquadCollection4.ToStringLabels();
				}
				string text2 = this.#=zBsXSanI=.#=zs39vp3mWzzdw(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=(), unitSquadCollection3, unitSquadCollection4, 0);
				if (text2.Length > 10000)
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921380), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						text
					});
					this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=());
					num++;
					this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.RemoveUnits(unitSquadCollection3);
					this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==.RemoveUnits(unitSquadCollection3);
					this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection4);
					this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection4);
				}
				else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921587)))
				{
					this.#=zcTyyNys=.#=z5_3JqsL118hV().Remove(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921556), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
					});
				}
				else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921209)))
				{
					if (unitSquadCollection3 != null)
					{
						unitSquadCollection.RemoveUnits(new UnitSquadCollection
						{
							new UnitSquad(unitSquadCollection3[0].Type, 1000000)
						});
					}
					else
					{
						unitSquadCollection2.RemoveUnits(new UnitSquadCollection
						{
							new UnitSquad(unitSquadCollection4[0].Type, 1000000)
						});
					}
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921160), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						text
					});
				}
				else
				{
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921089), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
						text,
						text2
					});
				}
			}
			else
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921294), Array.Empty<object>());
				this.#=zcTyyNys=.#=znRSpoHRxOsWr().#=z48rEd0A=(ProblemType.NotEnoughScouts);
			}
			num2++;
		}
		return num;
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x0002AEF4 File Offset: 0x000290F4
	private void #=zsaohgri9rELL7KghQw==(object[] #=z63V0q6sQrHWbgfWzdQ==)
	{
		if (#=z63V0q6sQrHWbgfWzdQ== == null)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934751), Array.Empty<object>());
		}
		List<int> list = new List<int>();
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(this.#=zpzrSpck=.#=zYgvZuBwR$a1C());
		int i = 0;
		while (i < #=z63V0q6sQrHWbgfWzdQ==.Length)
		{
			Dictionary<string, object> obj = (Dictionary<string, object>)#=z63V0q6sQrHWbgfWzdQ==[i];
			bool flag = false;
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==() == null)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921248), Array.Empty<object>());
			}
			if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count == 0)
			{
				break;
			}
			Dictionary<string, object> obj2 = (Dictionary<string, object>)JSONManager.GetObject(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
			if (JSONManager.GetInt(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0) != 4)
			{
				goto IL_3F9;
			}
			int @int = JSONManager.GetInt(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
			DateTime t = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(JSONManager.GetDateTime(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false));
			if (!this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Contains(@int) || !(this.#=zcTyyNys=.#=zwfXQmA03imo05bRmQw==() < t))
			{
				goto IL_3F9;
			}
			bool flag2 = false;
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921229));
			if (dictionary != null)
			{
				if (dictionary.Count >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDangerDefUnitsMin)
				{
					flag2 = true;
				}
				else if (dictionary.Count > 0)
				{
					int num = 0;
					foreach (object value in dictionary.Values)
					{
						num += Convert.ToInt32(value);
						if (num >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDangerDefUnitsMin)
						{
							flag2 = true;
							break;
						}
					}
				}
			}
			Dictionary<string, object> dictionary2 = (Dictionary<string, object>)JSONManager.GetObject(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920953));
			if (dictionary2 == null)
			{
				flag2 = true;
			}
			#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zk$6QZNA=(@int);
			if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= != null)
			{
				if (!flag2)
				{
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd = new #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1();
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd.#=z2QfEz18=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd.#=z5orudSfDy4LNHEoQIA==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]));
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd.#=zfyXaQpV5Bsw7FHPLkQ==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd.#=zWvoMErZxim4Z9kYMcA==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)]));
					#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2 = #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd;
					if (this.#=zgBdQwcf2nQsBGbI3_G_e0Ss=(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2))
					{
						bool flag3;
						this.#=zw6lYBLabNiAvAHiIDw==(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2, out flag3);
						if (flag3)
						{
							flag = true;
						}
					}
					else
					{
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920913), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF(),
							null,
							#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2.#=zCF7_RpkTiHMeBeLmww==(),
							#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2.#=zIDq8g$CbFZo_EGdo3A==(),
							#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2.#=zlOl3uc8MyINDqgsIig==()
						});
						if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance > 0)
						{
							this.#=zcTyyNys=.#=zsBGQTpOIxxCe6$2KLA==().Add(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd2);
						}
					}
					if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zSL$CHR_zajMs())
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=z5ktH1NpFood7(false);
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zp0wcrTDVPUwj(DateTime.Now);
						this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
					}
				}
				else
				{
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=z5ktH1NpFood7(true);
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zp0wcrTDVPUwj(DateTime.Now);
					this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
					this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921051), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
					});
				}
				this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Remove(@int);
				#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zv1sSxaY=(@int);
				list.Add(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943005), 0));
				goto IL_3F9;
			}
			this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Remove(@int);
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920951), new object[]
			{
				@int.ToString()
			});
			IL_3FD:
			i++;
			continue;
			IL_3F9:
			if (!flag)
			{
				goto IL_3FD;
			}
			break;
		}
		if (list.Count > 0)
		{
			this.#=zBsXSanI=.#=zzrC2GSZBc9MG(list);
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921012), new object[]
			{
				list.Count
			});
		}
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x0002B36C File Offset: 0x0002956C
	private void #=zw6lYBLabNiAvAHiIDw==(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=zfN6NveI=, out bool #=zCTvxZyU_iEBy3FL9l8c45wI=)
	{
		#=zCTvxZyU_iEBy3FL9l8c45wI= = false;
		if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z5nwSpHr8_MMZ(this.#=zpzrSpck=.#=zYgvZuBwR$a1C(), #=zfN6NveI=.#=zuFPZLKs=().#=zMuFMjGQ=()))
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908920961), new object[]
			{
				#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF()
			});
			#=zfN6NveI=.#=zuFPZLKs=().#=z5ktH1NpFood7(true);
			#=zfN6NveI=.#=zuFPZLKs=().#=zp0wcrTDVPUwj(DateTime.Now);
			this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
			return;
		}
		if (this.#=zJP6f31LM7O6pfu2pU5oCGB0=.Contains(#=zfN6NveI=.#=zuFPZLKs=().#=zMuFMjGQ=()))
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922671), new object[]
			{
				#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF()
			});
			#=zfN6NveI=.#=zuFPZLKs=().#=zp0wcrTDVPUwj(DateTime.Now);
			return;
		}
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == #=zfN6NveI=.#=zuFPZLKs=().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922865), new object[]
				{
					#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF()
				});
				#=zfN6NveI=.#=zuFPZLKs=().#=zp0wcrTDVPUwj(DateTime.Now);
				return;
			}
		}
		#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
		if (this.#=zovB$NjL8uCRsV7R_AA==(#=zfN6NveI=.#=zuFPZLKs=(), out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==) != (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919946), new object[]
			{
				#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF(),
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
			});
			return;
		}
		int #=zTH01DjU= = 0;
		if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsUseRobGeneral)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zxZjYVP2XT8qmcT9c2Q==.#=zIIyQciJSnOoKi3wyQA==(this.#=z8StzeqE=, 15000, this.#=zVG1EPv1OUDdyLeGHGQ==, null);
			if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null)
			{
				#=zTH01DjU= = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=();
				this.#=zxZjYVP2XT8qmcT9c2Q==.Remove(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			}
		}
		if (!this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.IsExistUnits(this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0]))
		{
			this.#=zCCK0rDd9X_BLPt_kiXZImKs=(this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count, true);
		}
		if (this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().Count > 0)
		{
			string text = this.#=zBsXSanI=.#=zow1rctFaF6MDmvemZw==(#=zfN6NveI=.#=zuFPZLKs=().#=zMuFMjGQ=(), null, this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0], #=zTH01DjU=);
			if (text.Length > 10000)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922812), new object[]
				{
					#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF(),
					this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0].ToStringLabels(),
					#=zfN6NveI=.#=zCF7_RpkTiHMeBeLmww==(),
					#=zfN6NveI=.#=zIDq8g$CbFZo_EGdo3A==(),
					#=zfN6NveI=.#=zlOl3uc8MyINDqgsIig==()
				});
				#=zfN6NveI=.#=zuFPZLKs=().#=zp0wcrTDVPUwj(DateTime.Now);
				this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zsobh2arZ__ufEqVOvA==(true);
				this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0]);
				this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0]);
				DateTime #=z7iJcLPfMecrfYDQL0w==;
				DateTime #=z49DxGPw=;
				this.#=zPI_vJW9fJ7bKPHMQZA==(text, #=zfN6NveI=.#=zuFPZLKs=(), out #=z7iJcLPfMecrfYDQL0w==, out #=z49DxGPw=);
				this.#=zjD7yuWFTVadmVlMyYswSudg=(#=zfN6NveI=.#=zuFPZLKs=(), #=zfN6NveI=.#=zCF7_RpkTiHMeBeLmww==() + #=zfN6NveI=.#=zIDq8g$CbFZo_EGdo3A==() + #=zfN6NveI=.#=zlOl3uc8MyINDqgsIig==(), #=z7iJcLPfMecrfYDQL0w==, #=z49DxGPw=);
				#=zCTvxZyU_iEBy3FL9l8c45wI= = true;
			}
			else
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922466), new object[]
				{
					#=zfN6NveI=.#=zuFPZLKs=().#=zTbtwDpWhYGtF(),
					this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==()[0].ToStringLabels(),
					text
				});
			}
			this.#=zcTyyNys=.#=zonHNsEoZn7AAb2smew==().RemoveAt(0);
		}
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x0002B788 File Offset: 0x00029988
	private bool #=z$UxbXr2jOqJKa4D4m_0IY$4=()
	{
		if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==() != null && this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count > 0)
		{
			object[] array = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
			this.#=zsaohgri9rELL7KghQw==(array);
			if (array == null)
			{
				return false;
			}
			foreach (int #=zAk8mKBk= in this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==())
			{
				#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = this.#=zcTyyNys=.#=z5_3JqsL118hV().#=zk$6QZNA=(#=zAk8mKBk=);
				string text = (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= != null) ? #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF() : (#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922420)) + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + #=zAk8mKBk=.ToString());
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922407), new object[]
				{
					text
				});
			}
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922615), new object[]
			{
				this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Count
			});
		}
		return true;
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x0002B8C8 File Offset: 0x00029AC8
	private void #=zFz33vlVXFLbd_holDl61glOZzd3Y()
	{
		object[] array = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
		List<int> list = new List<int>();
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(this.#=zpzrSpck=.#=zYgvZuBwR$a1C());
		foreach (Dictionary<string, object> obj in array)
		{
			Dictionary<string, object> obj2 = (Dictionary<string, object>)JSONManager.GetObject(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
			if (JSONManager.GetInt(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0) == 4)
			{
				int @int = JSONManager.GetInt(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
				DateTime t = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(JSONManager.GetDateTime(obj2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false));
				if (this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Contains(@int) && this.#=zcTyyNys=.#=zwfXQmA03imo05bRmQw==() < t)
				{
					this.#=zcTyyNys=.#=zfZLfjNugUHq7lHwxyg==().Remove(@int);
					#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zv1sSxaY=(@int);
					list.Add(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943005), 0));
				}
			}
		}
		if (list.Count > 0)
		{
			this.#=zBsXSanI=.#=zzrC2GSZBc9MG(list);
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921012), new object[]
			{
				list.Count
			});
		}
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0002BA18 File Offset: 0x00029C18
	public static void #=zvS9NMPa5Yz5Vbpjs0ICBHLE=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z40sk5mc=, int #=zuip2jhc6oeXCWxswzQ==)
	{
		if (#=zuip2jhc6oeXCWxswzQ== != #=z40sk5mc=.#=zO1FX6YkNZlqlvFZqJg==())
		{
			if (#=zuip2jhc6oeXCWxswzQ== == 0)
			{
				#=z40sk5mc=.#=zAsCgbAN02olKpq2GjA==(0);
				#=z40sk5mc=.#=z6AhOmwNDely78tSumg==(null);
				return;
			}
			string @string = JSONManager.GetString(JSONManager.GetData(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zYAdaM0gb6Gux4qLnpQ==(#=zSJY$s3o=, #=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zuip2jhc6oeXCWxswzQ==, null)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), null);
			if (!string.IsNullOrEmpty(@string))
			{
				#=z40sk5mc=.#=zAsCgbAN02olKpq2GjA==(#=zuip2jhc6oeXCWxswzQ==);
				#=z40sk5mc=.#=z6AhOmwNDely78tSumg==(@string);
			}
		}
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x0002BA7C File Offset: 0x00029C7C
	private #=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ== #=znez0p$RosubzyQHHTg==(Dictionary<string, object> #=zJdyVF9A=, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z6KI$o$s=, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zye7amwI=)
	{
		try
		{
			if (!#=zJdyVF9A=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)))
			{
				#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922570), Array.Empty<object>());
				return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0;
			}
			if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsRobYourOwnCities)
			{
				string b = JSONManager.ExtractString(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), string.Empty).Replace(GameApplicationData.#=z0Jq5DpdI2gB$(), string.Empty);
				GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
				GameApplicationData.Games games = GameApplicationData.#=zZ2dsDUeWDYAN();
				List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY();
				for (int i = 0; i < list.Count; i++)
				{
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = list[i];
					if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == gameHosters && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN() == games && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zsmHAU_GQ9ylR() == b)
					{
						#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922517), Array.Empty<object>());
						return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0;
					}
				}
			}
			if (#=zJdyVF9A=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)))
			{
				int num = JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0);
				bool flag = false;
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobAlliances.Contains(num))
				{
					flag = true;
				}
				else if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsRobAllianceCities && !this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobDontAlliances.Contains(num))
				{
					flag = true;
				}
				else if (#=z6KI$o$s= != null)
				{
					if (#=z6KI$o$s=.#=zG2Z_XuNYkfx2nMs5QRPfY68=())
					{
						flag = true;
					}
					#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=zvS9NMPa5Yz5Vbpjs0ICBHLE=(this.#=zpzrSpck=, this.#=zBsXSanI=, #=z6KI$o$s=, num);
				}
				if (!flag)
				{
					#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922213), Array.Empty<object>());
					return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0;
				}
			}
			int num2 = Convert.ToInt32(#=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]);
			if (#=zJdyVF9A=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)) && #=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)].ToString() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922165) && num2 >= 15)
			{
				#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922112), Array.Empty<object>());
				return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
			}
			int num3 = JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == num3 && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5))
				{
					#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922335), new object[]
					{
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().ToStringLabels()
					});
					return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)2;
				}
			}
			Dictionary<string, object> dictionary = (Dictionary<string, object>)#=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)];
			int num4 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0);
			int num5 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0);
			if (#=z6KI$o$s= == null || !#=z6KI$o$s=.#=zfoY4YQm8_Ygr())
			{
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance > 0 && (Math.Abs(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() - num4) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance || Math.Abs(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() - num5) > this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetDistance))
				{
					#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922281), Array.Empty<object>());
					return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)3;
				}
				if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetDistance > 0 && (Math.Abs(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() - num4) < this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetDistance || Math.Abs(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() - num5) < this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetDistance))
				{
					#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921969), Array.Empty<object>());
					return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)3;
				}
			}
			bool flag2 = #=z6KI$o$s= != null && #=z6KI$o$s=.#=zxWEtbaIh9mLk();
			int num6 = 0;
			int num7 = 999;
			if (!flag2)
			{
				num6 = ((this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetLevel <= 0) ? 21 : this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetLevel);
				num7 = 59;
			}
			if (num2 >= num6 && num2 <= num7)
			{
				#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw== #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw== = new #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==(this.#=zBsXSanI=.#=zOpP1dT8=(Convert.ToInt32(#=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)])));
				if (#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==.#=zfBt$fipohITJELd1KQUdRGFOof7U().Count == 0)
				{
					if (!#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==.#=zNnx4xxtx9xYwefJwdg==().#=zefHMDAN40dlccrzuRg==())
					{
						#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922072), Array.Empty<object>());
						return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
					}
					int num8 = #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==.#=zNnx4xxtx9xYwefJwdg==().#=zxZCerbvcGABMaw4jNA==() - #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==.#=zNnx4xxtx9xYwefJwdg==().#=z5HP2qqqcT7UpKkfKeQ==();
					if (num8 >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobCriteriaRarestResMin && num8 * 3 >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobCriteriaTotalResMin)
					{
						#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921906), Array.Empty<object>());
						return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
					}
				}
			}
			if (!flag2)
			{
				num6 = ((this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetLevel <= 0) ? 45 : this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinTargetLevel);
				num7 = ((this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetLevel <= 0) ? 999 : this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMaxTargetLevel);
			}
			if (num6 >= num7)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922036), new object[]
				{
					num6,
					num7
				});
			}
			if (num2 >= num6 && num2 <= num7)
			{
				#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw== #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2 = new #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==(this.#=zBsXSanI=.#=zOpP1dT8=(Convert.ToInt32(#=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)])));
				bool flag3 = false;
				if (#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2.#=zNnx4xxtx9xYwefJwdg==().#=zefHMDAN40dlccrzuRg==())
				{
					int num9 = #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2.#=zNnx4xxtx9xYwefJwdg==().#=zxZCerbvcGABMaw4jNA==() - #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2.#=zNnx4xxtx9xYwefJwdg==().#=z5HP2qqqcT7UpKkfKeQ==();
					if (num9 >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobCriteriaRarestResMin && num9 * 3 >= this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobCriteriaTotalResMin)
					{
						flag3 = true;
					}
				}
				else
				{
					flag3 = true;
				}
				if (flag3)
				{
					for (int j = 0; j < #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2.#=zNnx4xxtx9xYwefJwdg==().Count; j++)
					{
						if (#=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==2.#=zNnx4xxtx9xYwefJwdg==()[j].#=zH9V7bObvvn_m())
						{
							#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923719), Array.Empty<object>());
							return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
						}
					}
					int num10;
					string text;
					DateTime d;
					if (#=z6KI$o$s= == null || !#=z6KI$o$s=.#=zosa3YqZaOFWz8xhtVw==())
					{
						d = this.#=zBsXSanI=.#=zi6E$PtAmGSYg(#=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)].ToString(), out num10, out text);
					}
					else
					{
						d = DateTime.MinValue;
						num10 = 0;
						text = null;
					}
					if (string.IsNullOrEmpty(text))
					{
						if ((DateTime.Now - d).TotalDays > (double)this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinAbsenceTimeDays)
						{
							#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923658), new object[]
							{
								this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobMinAbsenceTimeDays
							});
							return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
						}
					}
					else
					{
						string text2 = #=zJdyVF9A=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)) ? #=zJdyVF9A=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)].ToString() : (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919036) + num4.ToString() + num5.ToString()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871), string.Empty);
						if (num10 == 2)
						{
							#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923842), new object[]
							{
								text2,
								num4,
								num5,
								text
							});
							return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)1;
						}
						this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923784), new object[]
						{
							text2,
							num4,
							num5,
							text
						});
					}
				}
			}
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
			if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6)
			{
				throw;
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
		}
		#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923449), Array.Empty<object>());
		return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0;
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x0002C34C File Offset: 0x0002A54C
	private #=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ== #=zovB$NjL8uCRsV7R_AA==(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z40sk5mc=, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zye7amwI=)
	{
		object[] array = (object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=z$F1M_0mTucCE(#=z40sk5mc=.#=zMuFMjGQ=().ToString())))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976)];
		int i = 0;
		while (i < array.Length)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)array[i];
			if (dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)].ToString() == #=z40sk5mc=.#=zMuFMjGQ=().ToString())
			{
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)) && this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsDontRobOccupied && !#=z40sk5mc=.#=zAQ1RVL2qRBaU())
				{
					#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923633), Array.Empty<object>());
					return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)2;
				}
				return this.#=znez0p$RosubzyQHHTg==(dictionary, #=z40sk5mc=, out #=zye7amwI=);
			}
			else
			{
				i++;
			}
		}
		#=zye7amwI= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026883), Array.Empty<object>());
		return (#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=z6SVOTqeHwoPJYYYMAQ==)0;
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x0002C440 File Offset: 0x0002A640
	private bool #=zgBdQwcf2nQsBGbI3_G_e0Ss=(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=zfN6NveI=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zpzrSpck=;
		int num = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zqGZod7DuP$m614qxIj6v4lE=();
		if (this.#=zpzrSpck=.#=zv2Kyu17YrGOC().AutoRobIsCaravansRob)
		{
			num += Math.Min(this.#=zJgBKL1dWlurwuFRt1A==.#=zMbI49ITzPNVB(), #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zDDkQ_RdZgdNGO6OtyQ==());
		}
		int num2 = #=zfN6NveI=.#=zCF7_RpkTiHMeBeLmww==() + #=zfN6NveI=.#=zIDq8g$CbFZo_EGdo3A==() + #=zfN6NveI=.#=zlOl3uc8MyINDqgsIig==();
		if (num2 < #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoRobCriteriaTotalResMin)
		{
			return false;
		}
		if (num2 > num)
		{
			#=zfN6NveI=.#=z5orudSfDy4LNHEoQIA==((int)((long)#=zfN6NveI=.#=zCF7_RpkTiHMeBeLmww==() * (long)num / (long)num2));
			#=zfN6NveI=.#=zfyXaQpV5Bsw7FHPLkQ==((int)((long)#=zfN6NveI=.#=zIDq8g$CbFZo_EGdo3A==() * (long)num / (long)num2));
			#=zfN6NveI=.#=zWvoMErZxim4Z9kYMcA==((int)((long)#=zfN6NveI=.#=zlOl3uc8MyINDqgsIig==() * (long)num / (long)num2));
		}
		int num3 = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoRobCriteriaRarestResMin;
		int num4 = this.#=z3yL5bKs=[ResourceTypes.Lumber];
		int num5 = this.#=z3yL5bKs=[ResourceTypes.Bronze];
		int num6 = this.#=z3yL5bKs=[ResourceTypes.Grain];
		if (num4 <= num5 && num4 <= num6)
		{
			if (this.#=zkdGdpYZ7Wpxf[ResourceTypes.Lumber] > 2000 && this.#=zkdGdpYZ7Wpxf[ResourceTypes.Lumber] - num4 < num3)
			{
				num3 = this.#=zkdGdpYZ7Wpxf[ResourceTypes.Lumber] - num4;
			}
			if (#=zfN6NveI=.#=zCF7_RpkTiHMeBeLmww==() >= num3)
			{
				return true;
			}
		}
		else if (num5 <= num4 && num5 <= num6)
		{
			if (this.#=zkdGdpYZ7Wpxf[ResourceTypes.Bronze] > 2000 && this.#=zkdGdpYZ7Wpxf[ResourceTypes.Bronze] - num5 < num3)
			{
				num3 = this.#=zkdGdpYZ7Wpxf[ResourceTypes.Bronze] - num5;
			}
			if (#=zfN6NveI=.#=zIDq8g$CbFZo_EGdo3A==() >= num3)
			{
				return true;
			}
		}
		else if (num6 <= num4 && num6 <= num5)
		{
			if (this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] > 2000 && this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] - num6 < num3)
			{
				num3 = this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] - num6;
			}
			if (#=zfN6NveI=.#=zlOl3uc8MyINDqgsIig==() >= num3)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x0002C60C File Offset: 0x0002A80C
	private void #=zPI_vJW9fJ7bKPHMQZA==(string #=zLZ_cmd4W3HoX, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z40sk5mc=, out DateTime #=z7iJcLPfMecrfYDQL0w==, out DateTime #=z49DxGPw=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zpzrSpck=;
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zMHi_CEsJyeAs(JSONManager.GetArray(JSONManager.GetData(#=zLZ_cmd4W3HoX), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618)), null);
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = null;
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in list)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_() == #=z40sk5mc=.#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2)
			{
				#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2;
				break;
			}
		}
		if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== == null)
		{
			base.#=zgtwWGFUm$USb54cn9g==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3 in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3.#=zK5gF1KeGk_H_() == #=z40sk5mc=.#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2)
				{
					#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==3;
					break;
				}
			}
		}
		if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== != null)
		{
			#=z7iJcLPfMecrfYDQL0w== = DateTime.MinValue;
			#=z49DxGPw= = DateTime.MinValue;
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)2)
			{
				#=z49DxGPw= = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==());
			}
			else if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1)
			{
				#=z7iJcLPfMecrfYDQL0w== = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==());
				#=z49DxGPw= = #=z7iJcLPfMecrfYDQL0w== + (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() - #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lxfpxFY0_uNuyAfuiAkDv4=());
			}
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923584), new object[]
			{
				#=z40sk5mc=.#=zMuFMjGQ=(),
				#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=(),
				#=z7iJcLPfMecrfYDQL0w==,
				#=z49DxGPw=
			});
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923231), new object[]
		{
			#=z40sk5mc=.#=zTbtwDpWhYGtF()
		});
		#=z7iJcLPfMecrfYDQL0w== = DateTime.MinValue;
		#=z49DxGPw= = DateTime.MinValue;
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0002C810 File Offset: 0x0002AA10
	private void #=zjD7yuWFTVadmVlMyYswSudg=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z40sk5mc=, int #=zfrvlLLm6$f4m, DateTime #=z7iJcLPfMecrfYDQL0w==, DateTime #=z49DxGPw=)
	{
		if (#=z49DxGPw= != DateTime.MinValue)
		{
			object #=zBCxv0_Eazs = this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zBCxv0_Eazs01;
			lock (#=zBCxv0_Eazs)
			{
				DateTime #=zxSBcx18= = (#=z7iJcLPfMecrfYDQL0w== != DateTime.MinValue) ? (#=z7iJcLPfMecrfYDQL0w== + TimeSpan.FromMinutes(2.0)) : DateTime.Now;
				#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== item = new #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==(#=z40sk5mc=.#=zMuFMjGQ=(), TaskSources.Manual, TaskSeverities.UrgentNoRelogin, TaskTypes.AutoRobberyCheckResult, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
				this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Add(item);
				if (#=z7iJcLPfMecrfYDQL0w== != DateTime.MinValue && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsCaravansRob && #=zfrvlLLm6$f4m > #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zqGZod7DuP$m614qxIj6v4lE=())
				{
					#=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM item2 = new #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM(#=z40sk5mc=.#=zMuFMjGQ=(), #=z40sk5mc=.#=zTbtwDpWhYGtF(), #=z7iJcLPfMecrfYDQL0w==, this.#=z3yL5bKs=, this.#=zJgBKL1dWlurwuFRt1A==);
					this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item2);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923183), new object[]
					{
						#=z40sk5mc=.#=zTbtwDpWhYGtF(),
						#=z7iJcLPfMecrfYDQL0w==
					});
				}
				#=z49DxGPw= += TimeSpan.FromMinutes(1.0);
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsQuickSendToAcropolReturning)
				{
					if (#=z7iJcLPfMecrfYDQL0w== != DateTime.MinValue)
					{
						Task item3 = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.SendToAcropol, #=z7iJcLPfMecrfYDQL0w== + TimeSpan.FromSeconds(1.0), TimeSpan.FromMinutes(10.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false);
						this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item3);
					}
				}
				else
				{
					Task item4 = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.SendToAcropol, #=z49DxGPw=, TimeSpan.FromMinutes(10.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false);
					this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item4);
					Task item5 = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.SendToAcropol, #=z49DxGPw= + TimeSpan.FromMinutes(0.2), TimeSpan.FromMinutes(10.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false);
					this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item5);
				}
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsBuildAfterRob)
				{
					Task item6 = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.BuildBuildings, #=z49DxGPw=, TimeSpan.FromMinutes(30.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false);
					this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item6);
					#=z49DxGPw= += TimeSpan.FromMinutes(1.0);
					Task item7 = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.ResearchTechs, #=z49DxGPw=, TimeSpan.FromMinutes(30.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MinValue, false);
					this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(item7);
					#=z49DxGPw= += TimeSpan.FromMinutes(1.0);
				}
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsBuyTroopsAfterRob)
				{
					#=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zx6mAD3WBJ$C1JPgizQctvRQ=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zVG1EPv1OUDdyLeGHGQ==);
				}
				this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Sort();
				this.#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Sort();
			}
		}
	}

	// Token: 0x040001F7 RID: 503
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zpzrSpck=;

	// Token: 0x040001F8 RID: 504
	private #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zcTyyNys=;

	// Token: 0x040001F9 RID: 505
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x040001FA RID: 506
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zkdGdpYZ7Wpxf;

	// Token: 0x040001FB RID: 507
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x040001FC RID: 508
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x040001FD RID: 509
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x040001FE RID: 510
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x040001FF RID: 511
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x04000200 RID: 512
	private int #=zJr4GDlRh4CkxysOnQzRTvIs=;

	// Token: 0x04000201 RID: 513
	private #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=zJgBKL1dWlurwuFRt1A==;

	// Token: 0x04000202 RID: 514
	private List<int> #=zJP6f31LM7O6pfu2pU5oCGB0=;

	// Token: 0x04000203 RID: 515
	private #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zxZjYVP2XT8qmcT9c2Q==;

	// Token: 0x04000204 RID: 516
	private UnitTypeCollection #=zlhLE8UQVU0AG;

	// Token: 0x020000C2 RID: 194
	private enum #=z6SVOTqeHwoPJYYYMAQ==
	{

	}
}
