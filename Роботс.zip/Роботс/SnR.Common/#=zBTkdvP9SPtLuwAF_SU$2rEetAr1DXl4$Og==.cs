﻿using System;
using Skink.SnR.Common.Units;

// Token: 0x020000C9 RID: 201
internal sealed class #=zBTkdvP9SPtLuwAF_SU$2rEetAr1DXl4$Og==
{
	// Token: 0x06000550 RID: 1360 RVA: 0x0002E0C4 File Offset: 0x0002C2C4
	public UnitType #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000551 RID: 1361 RVA: 0x0002E0CC File Offset: 0x0002C2CC
	public void #=zzQwUIEs=(UnitType #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000552 RID: 1362 RVA: 0x0002E0D8 File Offset: 0x0002C2D8
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x0002E0E0 File Offset: 0x0002C2E0
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x0002E0EC File Offset: 0x0002C2EC
	public int #=zLYM$_iu7NZc_()
	{
		return this.#=zbCFovRgm5pQQfvHcqw==;
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x0002E0F4 File Offset: 0x0002C2F4
	public void #=zR_v5$VjDx30e(int #=z$Ib9gYQ=)
	{
		this.#=zbCFovRgm5pQQfvHcqw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x0002E100 File Offset: 0x0002C300
	public bool #=z5kpAZQpjT2b7()
	{
		return this.#=zIaE6rQrLmv89N0PjeA==;
	}

	// Token: 0x06000557 RID: 1367 RVA: 0x0002E108 File Offset: 0x0002C308
	public void #=z7opAbNyz4VIn(bool #=z$Ib9gYQ=)
	{
		this.#=zIaE6rQrLmv89N0PjeA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000558 RID: 1368 RVA: 0x0002E114 File Offset: 0x0002C314
	public int #=zffaTbL8JZPiQ()
	{
		return this.#=zUyarFEMkmDy9YLTaB3_VKvU=;
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x0002E11C File Offset: 0x0002C31C
	public void #=zLvueclvqIUaP(int #=z$Ib9gYQ=)
	{
		this.#=zUyarFEMkmDy9YLTaB3_VKvU= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x0002E128 File Offset: 0x0002C328
	public int #=zqsHzB9lp40lxoApLJA==()
	{
		return this.#=ziFwwKIHmfT_Rzu8ZhPU3lwbDt1M2;
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x0002E130 File Offset: 0x0002C330
	public void #=zkWuPFifkU94SVX_rQQ==(int #=z$Ib9gYQ=)
	{
		this.#=ziFwwKIHmfT_Rzu8ZhPU3lwbDt1M2 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x0002E13C File Offset: 0x0002C33C
	public int #=zmrmDExe7tjF7rw2diA==()
	{
		return this.#=zfOPQYNdl94JLzwIDLUi53JFUcuoj;
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0002E144 File Offset: 0x0002C344
	public void #=zwGtAoqkRFjvl8EOarA==(int #=z$Ib9gYQ=)
	{
		this.#=zfOPQYNdl94JLzwIDLUi53JFUcuoj = #=z$Ib9gYQ=;
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x0002E150 File Offset: 0x0002C350
	public int #=zwN0dE5NTV$Su()
	{
		return this.#=zYvj$wy_xQP8G_3pl3WBB6ug=;
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x0002E158 File Offset: 0x0002C358
	public void #=z6kvrMxWt8j$O(int #=z$Ib9gYQ=)
	{
		this.#=zYvj$wy_xQP8G_3pl3WBB6ug= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0002E164 File Offset: 0x0002C364
	public int #=zno$PrwUc9Y0vmXmReA==()
	{
		return this.#=zdvpYgL3UWCr0hnVSO1ir0ZA=;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0002E16C File Offset: 0x0002C36C
	public void #=zEh0PcTqf4z7jbjrhUw==(int #=z$Ib9gYQ=)
	{
		this.#=zdvpYgL3UWCr0hnVSO1ir0ZA= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000219 RID: 537
	private UnitType #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400021A RID: 538
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400021B RID: 539
	private int #=zbCFovRgm5pQQfvHcqw==;

	// Token: 0x0400021C RID: 540
	private bool #=zIaE6rQrLmv89N0PjeA==;

	// Token: 0x0400021D RID: 541
	private int #=zUyarFEMkmDy9YLTaB3_VKvU=;

	// Token: 0x0400021E RID: 542
	private int #=ziFwwKIHmfT_Rzu8ZhPU3lwbDt1M2;

	// Token: 0x0400021F RID: 543
	private int #=zfOPQYNdl94JLzwIDLUi53JFUcuoj;

	// Token: 0x04000220 RID: 544
	private int #=zYvj$wy_xQP8G_3pl3WBB6ug=;

	// Token: 0x04000221 RID: 545
	private int #=zdvpYgL3UWCr0hnVSO1ir0ZA=;
}
