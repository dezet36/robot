﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000200 RID: 512
internal sealed class #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw== : UserControl
{
	// Token: 0x06000FB3 RID: 4019 RVA: 0x0007AE34 File Offset: 0x00079034
	public #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==()
	{
		this.#=zjpew5v4= = string.Empty;
		this.#=zCBgDXbg9hbH0 = true;
		this.#=zgpzgXirqPT5_();
	}

	// Token: 0x06000FB4 RID: 4020 RVA: 0x0007AE54 File Offset: 0x00079054
	public string #=zVcIxe_4=()
	{
		return this.#=zjpew5v4=;
	}

	// Token: 0x06000FB5 RID: 4021 RVA: 0x0007AE5C File Offset: 0x0007905C
	public void #=zKTAVzhk=(string #=z$Ib9gYQ=)
	{
		if (this.#=zjpew5v4= != #=z$Ib9gYQ=)
		{
			this.#=zjpew5v4= = #=z$Ib9gYQ=;
			if (#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=z04cTN7eaC4h7(this))
			{
				this.#=z8q3l$LQ=();
				return;
			}
			this.#=zCBgDXbg9hbH0 = false;
		}
	}

	// Token: 0x06000FB6 RID: 4022 RVA: 0x0007AE8C File Offset: 0x0007908C
	public bool #=zd_pPup6jnpSliO2I$x67Xis=()
	{
		return this.#=zrJgHn_RV22YYcw1t5T3xDj4PDK$qrQhmAA==;
	}

	// Token: 0x06000FB7 RID: 4023 RVA: 0x0007AE94 File Offset: 0x00079094
	public void #=zt7xfAW98hsnE5q54fZ6ajJ8=(bool #=z$Ib9gYQ=)
	{
		this.#=zrJgHn_RV22YYcw1t5T3xDj4PDK$qrQhmAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FB8 RID: 4024 RVA: 0x0007AEA0 File Offset: 0x000790A0
	public void #=z344XsWQYMat396PoI6FAmY7RMaLc(#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=z$Ib9gYQ=)
	{
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=zaumhGRq9de4GOz9MQw== = this.#=z2XU$lzWRF6XuU8aeoftNUtE=;
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=zaumhGRq9de4GOz9MQw==2;
		do
		{
			#=zaumhGRq9de4GOz9MQw==2 = #=zaumhGRq9de4GOz9MQw==;
			#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== value = (#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw==)Delegate.Combine(#=zaumhGRq9de4GOz9MQw==2, #=z$Ib9gYQ=);
			#=zaumhGRq9de4GOz9MQw== = Interlocked.CompareExchange<#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw==>(ref this.#=z2XU$lzWRF6XuU8aeoftNUtE=, value, #=zaumhGRq9de4GOz9MQw==2);
		}
		while (#=zaumhGRq9de4GOz9MQw== != #=zaumhGRq9de4GOz9MQw==2);
	}

	// Token: 0x06000FB9 RID: 4025 RVA: 0x0007AED8 File Offset: 0x000790D8
	public void #=zK9CJ5yUbsM2NfAIT5ycVAmancleP(#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=z$Ib9gYQ=)
	{
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=zaumhGRq9de4GOz9MQw== = this.#=z2XU$lzWRF6XuU8aeoftNUtE=;
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=zaumhGRq9de4GOz9MQw==2;
		do
		{
			#=zaumhGRq9de4GOz9MQw==2 = #=zaumhGRq9de4GOz9MQw==;
			#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== value = (#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw==)Delegate.Remove(#=zaumhGRq9de4GOz9MQw==2, #=z$Ib9gYQ=);
			#=zaumhGRq9de4GOz9MQw== = Interlocked.CompareExchange<#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw==>(ref this.#=z2XU$lzWRF6XuU8aeoftNUtE=, value, #=zaumhGRq9de4GOz9MQw==2);
		}
		while (#=zaumhGRq9de4GOz9MQw== != #=zaumhGRq9de4GOz9MQw==2);
	}

	// Token: 0x06000FBA RID: 4026 RVA: 0x0007AF10 File Offset: 0x00079110
	public void #=zug4zSYskVwSzt_eROw==(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=z_K02suJs8NvDjDxlnw==;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Combine(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=z_K02suJs8NvDjDxlnw==, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x06000FBB RID: 4027 RVA: 0x0007AF48 File Offset: 0x00079148
	public void #=zXF_5cCfCAQ7PzeQ$yQ==(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=z_K02suJs8NvDjDxlnw==;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Remove(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=z_K02suJs8NvDjDxlnw==, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x06000FBC RID: 4028 RVA: 0x0007AF80 File Offset: 0x00079180
	public void #=zvEOFp7j9ovbo(#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=z$Ib9gYQ=)
	{
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=zeN_jT4XPbwKo = this.#=zU6XsrKSZ3Uys;
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=zeN_jT4XPbwKo2;
		do
		{
			#=zeN_jT4XPbwKo2 = #=zeN_jT4XPbwKo;
			#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo value = (#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo)Delegate.Combine(#=zeN_jT4XPbwKo2, #=z$Ib9gYQ=);
			#=zeN_jT4XPbwKo = Interlocked.CompareExchange<#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo>(ref this.#=zU6XsrKSZ3Uys, value, #=zeN_jT4XPbwKo2);
		}
		while (#=zeN_jT4XPbwKo != #=zeN_jT4XPbwKo2);
	}

	// Token: 0x06000FBD RID: 4029 RVA: 0x0007AFB8 File Offset: 0x000791B8
	public void #=zM99MdObdHvU7(#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=z$Ib9gYQ=)
	{
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=zeN_jT4XPbwKo = this.#=zU6XsrKSZ3Uys;
		#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=zeN_jT4XPbwKo2;
		do
		{
			#=zeN_jT4XPbwKo2 = #=zeN_jT4XPbwKo;
			#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo value = (#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo)Delegate.Remove(#=zeN_jT4XPbwKo2, #=z$Ib9gYQ=);
			#=zeN_jT4XPbwKo = Interlocked.CompareExchange<#=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo>(ref this.#=zU6XsrKSZ3Uys, value, #=zeN_jT4XPbwKo2);
		}
		while (#=zeN_jT4XPbwKo != #=zeN_jT4XPbwKo2);
	}

	// Token: 0x06000FBE RID: 4030 RVA: 0x0007AFF0 File Offset: 0x000791F0
	private void #=zWI4aQ1w9sR6CBXv29o7o4Bk=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw= = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE= = this.#=zU6XsrKSZ3Uys();
		#=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk= #=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk= = new #=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=(#=z8S9_Kvw=, #=z8StzeqE=, this.#=zjpew5v4=, this.#=zd_pPup6jnpSliO2I$x67Xis=());
		try
		{
			if (#=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=.ShowDialog() == DialogResult.OK)
			{
				bool flag = true;
				if (this.#=z2XU$lzWRF6XuU8aeoftNUtE= != null)
				{
					flag = this.#=z2XU$lzWRF6XuU8aeoftNUtE=(#=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=.#=z8MLrXqpSC$z2kv75$A==());
				}
				if (flag)
				{
					this.#=zjpew5v4= = #=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=.#=z8MLrXqpSC$z2kv75$A==().ToString();
					this.#=zosMYQx8wOLX6$NhaQA==.Text = #=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=.#=z8MLrXqpSC$z2kv75$A==().ToStringLabels();
					this.#=zCBgDXbg9hbH0 = true;
				}
			}
		}
		finally
		{
			((IDisposable)#=zuuHSkABuPtyvat9_fAvdXcJWx_dalAgxr7Sb0Xk=).Dispose();
		}
		if (this.#=z_K02suJs8NvDjDxlnw== != null)
		{
			this.#=z_K02suJs8NvDjDxlnw==(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000FBF RID: 4031 RVA: 0x0007B0AC File Offset: 0x000792AC
	private void #=z8q3l$LQ=()
	{
		if (string.IsNullOrEmpty(this.#=zjpew5v4=))
		{
			this.#=zosMYQx8wOLX6$NhaQA==.Text = string.Empty;
		}
		else
		{
			#=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8= #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=;
			if (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=z84ZpbGPv0D55(this.#=zjpew5v4=))
			{
				#=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8= = new #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=(this.#=zjpew5v4=);
			}
			else if (#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z9HJwcKInmGpn(this.#=zjpew5v4=))
			{
				#=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8= = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zcEIrFP4=(this.#=zjpew5v4=);
			}
			else
			{
				#=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8= = UnitSquadCollection.FromString(this.#=zjpew5v4=, null);
			}
			this.#=zosMYQx8wOLX6$NhaQA==.Text = #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=.ToStringLabels();
		}
		this.#=zCBgDXbg9hbH0 = true;
	}

	// Token: 0x06000FC0 RID: 4032 RVA: 0x0007B134 File Offset: 0x00079334
	private void #=zpY3prEdMOQGPqHCqrA==(object #=zP95I7AY=, PaintEventArgs #=z4Q$h3mE=)
	{
		if (!this.#=zCBgDXbg9hbH0)
		{
			this.#=z8q3l$LQ=();
		}
	}

	// Token: 0x06000FC1 RID: 4033 RVA: 0x0007B144 File Offset: 0x00079344
	private void #=zmA0v3o9FRCgzhAvkivaeD60=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (string.IsNullOrEmpty(this.#=zjpew5v4=))
		{
			Clipboard.Clear();
			return;
		}
		Clipboard.SetText(this.#=zjpew5v4=);
	}

	// Token: 0x06000FC2 RID: 4034 RVA: 0x0007B164 File Offset: 0x00079364
	private void #=z3J3ykCEgGEZcuAS8LtDdmDg=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		bool flag = false;
		try
		{
			this.#=zjpew5v4= = Clipboard.GetText();
			this.#=z8q3l$LQ=();
			if (!string.IsNullOrWhiteSpace(this.#=zjpew5v4=) && string.IsNullOrWhiteSpace(this.#=zosMYQx8wOLX6$NhaQA==.Text))
			{
				flag = true;
			}
		}
		catch
		{
			flag = true;
		}
		if (flag)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020544), new object[]
			{
				JSONManager.Cut(this.#=zjpew5v4=, 100)
			}));
			this.#=zjpew5v4= = string.Empty;
			this.#=z8q3l$LQ=();
		}
		if (this.#=z_K02suJs8NvDjDxlnw== != null)
		{
			this.#=z_K02suJs8NvDjDxlnw==(this, EventArgs.Empty);
		}
	}

	// Token: 0x06000FC3 RID: 4035 RVA: 0x0007B218 File Offset: 0x00079418
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x06000FC4 RID: 4036 RVA: 0x0007B238 File Offset: 0x00079438
	private void #=zgpzgXirqPT5_()
	{
		this.#=zgcvZCbvhfu$SX3clrQ== = new Button();
		this.#=zosMYQx8wOLX6$NhaQA== = new TextBox();
		this.#=zucm8UPoydUbz0GA_GQ== = new Button();
		this.#=zswt3HQbiJtGOWTJXUw== = new Button();
		base.SuspendLayout();
		this.#=zgcvZCbvhfu$SX3clrQ==.Location = new Point(386, 0);
		this.#=zgcvZCbvhfu$SX3clrQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020260);
		this.#=zgcvZCbvhfu$SX3clrQ==.Size = new Size(119, 23);
		this.#=zgcvZCbvhfu$SX3clrQ==.TabIndex = 11;
		this.#=zgcvZCbvhfu$SX3clrQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908986102);
		this.#=zgcvZCbvhfu$SX3clrQ==.UseVisualStyleBackColor = true;
		this.#=zgcvZCbvhfu$SX3clrQ==.Click += this.#=zWI4aQ1w9sR6CBXv29o7o4Bk=;
		this.#=zosMYQx8wOLX6$NhaQA==.Location = new Point(3, 3);
		this.#=zosMYQx8wOLX6$NhaQA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020237);
		this.#=zosMYQx8wOLX6$NhaQA==.ReadOnly = true;
		this.#=zosMYQx8wOLX6$NhaQA==.Size = new Size(377, 20);
		this.#=zosMYQx8wOLX6$NhaQA==.TabIndex = 9;
		this.#=zucm8UPoydUbz0GA_GQ==.Location = new Point(511, 0);
		this.#=zucm8UPoydUbz0GA_GQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020203);
		this.#=zucm8UPoydUbz0GA_GQ==.Size = new Size(81, 23);
		this.#=zucm8UPoydUbz0GA_GQ==.TabIndex = 12;
		this.#=zucm8UPoydUbz0GA_GQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909084464);
		this.#=zucm8UPoydUbz0GA_GQ==.UseVisualStyleBackColor = true;
		this.#=zucm8UPoydUbz0GA_GQ==.Click += this.#=zmA0v3o9FRCgzhAvkivaeD60=;
		this.#=zswt3HQbiJtGOWTJXUw==.Location = new Point(598, 0);
		this.#=zswt3HQbiJtGOWTJXUw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020178);
		this.#=zswt3HQbiJtGOWTJXUw==.Size = new Size(81, 23);
		this.#=zswt3HQbiJtGOWTJXUw==.TabIndex = 13;
		this.#=zswt3HQbiJtGOWTJXUw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020410);
		this.#=zswt3HQbiJtGOWTJXUw==.UseVisualStyleBackColor = true;
		this.#=zswt3HQbiJtGOWTJXUw==.Click += this.#=z3J3ykCEgGEZcuAS8LtDdmDg=;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.#=zswt3HQbiJtGOWTJXUw==);
		base.Controls.Add(this.#=zucm8UPoydUbz0GA_GQ==);
		base.Controls.Add(this.#=zgcvZCbvhfu$SX3clrQ==);
		base.Controls.Add(this.#=zosMYQx8wOLX6$NhaQA==);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909020404);
		base.Size = new Size(696, 30);
		base.Paint += this.#=zpY3prEdMOQGPqHCqrA==;
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040008B7 RID: 2231
	private string #=zjpew5v4=;

	// Token: 0x040008B8 RID: 2232
	private bool #=zCBgDXbg9hbH0;

	// Token: 0x040008B9 RID: 2233
	private bool #=zrJgHn_RV22YYcw1t5T3xDj4PDK$qrQhmAA==;

	// Token: 0x040008BA RID: 2234
	private #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zaumhGRq9de4GOz9MQw== #=z2XU$lzWRF6XuU8aeoftNUtE=;

	// Token: 0x040008BB RID: 2235
	private EventHandler #=z_K02suJs8NvDjDxlnw==;

	// Token: 0x040008BC RID: 2236
	private #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo #=zU6XsrKSZ3Uys;

	// Token: 0x040008BD RID: 2237
	private IContainer #=zRWEHIqY=;

	// Token: 0x040008BE RID: 2238
	private Button #=zgcvZCbvhfu$SX3clrQ==;

	// Token: 0x040008BF RID: 2239
	private TextBox #=zosMYQx8wOLX6$NhaQA==;

	// Token: 0x040008C0 RID: 2240
	private Button #=zucm8UPoydUbz0GA_GQ==;

	// Token: 0x040008C1 RID: 2241
	private Button #=zswt3HQbiJtGOWTJXUw==;

	// Token: 0x02000201 RID: 513
	// (Invoke) Token: 0x06000FC6 RID: 4038
	internal delegate bool #=zaumhGRq9de4GOz9MQw==(#=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8= #=zxHIOVSaavkpE);

	// Token: 0x02000202 RID: 514
	// (Invoke) Token: 0x06000FCA RID: 4042
	internal delegate #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zeN_jT4XPbwKo();
}
