﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000282 RID: 642
internal sealed class #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==
{
	// Token: 0x0600135F RID: 4959 RVA: 0x000962B8 File Offset: 0x000944B8
	public #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==(Dictionary<string, object> #=zpJs9CjviTpRi, object[] #=z3VqT7vR5O_Cbq89EXQ==)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		this.#=zIaGGDzQ=(JSONManager.ExtractInt(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		int i = this.#=zMuFMjGQ=();
		this.#=zwXKUV2c=(i.ToString());
		this.#=zeIQ12_vYtW9$(JSONManager.ExtractInt(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		this.#=zTyGV9Sm$rwQHw7TLOw==(ProphecyTypes.NotProphecy);
		this.#=zeLdu5OWgWfri(JSONManager.ExtractDate(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false));
		this.#=zS5uus3Bg_NuG(JSONManager.ExtractDate(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), false) != DateTime.MinValue);
		this.#=zUPSHR4Zqppk3(0L);
		this.#=zwSmAJ1VkaZuHcZJIsVPh4Hs=(0L);
		this.#=z9j0XbQ320sIb(#=zpJs9CjviTpRi.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)));
		this.#=zfFo1ZHcBW0DT(new List<#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=>());
		if (this.#=zN0c_qE6yJTk7())
		{
			object[] array = JSONManager.ExtractArray(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
			if (array != null)
			{
				foreach (Dictionary<string, object> dictionary in array)
				{
					if (dictionary != null)
					{
						this.#=zRTKkIHydRtAD().Add(new #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=(dictionary));
					}
				}
			}
		}
		this.#=z7qNdaLMNedGDJKZ0eQ==(new List<int[]>());
		this.#=zrfMnF8JOjXWKXhxzUfV7kmupzSBX(new List<int[]>());
		if (this.#=zN0c_qE6yJTk7())
		{
			object[] array2 = JSONManager.ExtractArray(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
			for (i = 0; i < array2.Length; i++)
			{
				Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary((Dictionary<string, object>)array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759));
				if (dictionary2 != null)
				{
					long num = 0L;
					object[] array3 = JSONManager.ExtractArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061922));
					if (array3 != null)
					{
						foreach (Dictionary<string, object> dictionary3 in array3)
						{
							if (dictionary3.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)))
							{
								num += Convert.ToInt64(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)]);
							}
						}
					}
					if (num == 0L)
					{
						num = JSONManager.ExtractLong(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061915), 0L);
					}
					this.#=zUPSHR4Zqppk3(this.#=zKa2XiiZl7goe() + num);
					this.#=zwSmAJ1VkaZuHcZJIsVPh4Hs=(this.#=zuCvgEb_H$DFbBGNJwMU4czc=() + JSONManager.ExtractLong(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061904), 0L));
				}
			}
		}
		this.#=zf6Kf_GiFmUKTyGZ1sGn6IiH2oi4wI1oTBg==(0);
		this.#=zoU6VjqHZj0WD7v41GsxywIO0Hzqi8iqdPl0GKIrCu7hu(null);
		Dictionary<string, object> dictionaryInArrayByValue = JSONManager.GetDictionaryInArrayByValue(#=z3VqT7vR5O_Cbq89EXQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), this.#=zMuFMjGQ=());
		if (dictionaryInArrayByValue != null)
		{
			this.#=zwXKUV2c=(JSONManager.GetString(dictionaryInArrayByValue, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
			this.#=zTyGV9Sm$rwQHw7TLOw==((ProphecyTypes)JSONManager.ExtractInt(dictionaryInArrayByValue, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061897), 0));
			this.#=zHCtIGcFRChmNvwQXK4XN8Ks=(dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)) || dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)));
			this.#=zmBSIKq3q0MyRbTBzeB96Rnk=(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zh5Incl7GerXGyMXQ3pU005k=(dictionaryInArrayByValue));
			this.#=zL2A7aHgGt3fiwu1VnEo$BJGukqkS(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=z4F7pzUnOpIZd9WL5Y5hHrMgBAq7o$fjoOw==(dictionaryInArrayByValue));
			this.#=zMPGw4ygbGMktqwcAhiD856Y=(false);
			this.#=zCS3R3X18bjDJrm_H6AEgZVrcECQJC4AnEw==(false);
			if (dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)))
			{
				this.#=zMPGw4ygbGMktqwcAhiD856Y=(true);
				if (dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062140)))
				{
					this.#=zCS3R3X18bjDJrm_H6AEgZVrcECQJC4AnEw==(true);
				}
			}
			else if (dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)))
			{
				this.#=zCS3R3X18bjDJrm_H6AEgZVrcECQJC4AnEw==(true);
			}
			if (this.#=zKa2XiiZl7goe() > 0L || this.#=zuCvgEb_H$DFbBGNJwMU4czc=() > 0L)
			{
				if (this.#=zsGegpFIDm4HnM1ZwbMKrm1OyKO$D())
				{
					Dictionary<string, object> dictionary4 = JSONManager.GetDictionary(#=zpJs9CjviTpRi, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062122));
					if (dictionary4 != null)
					{
						int num2 = JSONManager.ExtractInt(dictionary4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062118), 0);
						int num3 = JSONManager.ExtractInt(dictionary4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061904), 0);
						object[] array5 = JSONManager.ExtractArray(dictionary4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062111));
						int num4 = (array5 != null) ? array5.Length : 0;
						this.#=zoU6VjqHZj0WD7v41GsxywIO0Hzqi8iqdPl0GKIrCu7hu(new int[num4]);
						for (int l = 0; l < num4; l++)
						{
							this.#=zs4VItRnK8RHCsmBP1UyCU4NH2aiPL5bfuGvC00TmOQZJ()[l] = Convert.ToInt32(array5[l]);
						}
						using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = JSONManager.ExtractDictionary((Dictionary<string, object>)JSONManager.ExtractArray(dictionaryInArrayByValue, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549))[num2 - 1], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)).Keys.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (Convert.ToInt32(enumerator.Current) <= num3)
								{
									i = this.#=zuDNrgEn6avv5JV0$utd1XIH$Fx8Rf0nEkA==();
									this.#=zf6Kf_GiFmUKTyGZ1sGn6IiH2oi4wI1oTBg==(i + 1);
								}
							}
							goto IL_45C;
						}
					}
					this.#=zL2A7aHgGt3fiwu1VnEo$BJGukqkS(false);
				}
				IL_45C:
				object[] array6;
				if (dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)))
				{
					array6 = (dictionaryInArrayByValue[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)] as object[]);
				}
				else if (dictionaryInArrayByValue.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)))
				{
					array6 = (dictionaryInArrayByValue[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)] as object[]);
				}
				else
				{
					array6 = new object[0];
				}
				foreach (Dictionary<string, object> dictionary5 in array6)
				{
					if (dictionary5.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)))
					{
						List<long> list = new List<long>();
						object[] array7 = JSONManager.GetArray(dictionary5, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086));
						if (array7 != null)
						{
							foreach (Dictionary<string, object> dictionary6 in array7)
							{
								long num5 = JSONManager.ExtractLong(dictionary6, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0L);
								if (num5 > 0L && JSONManager.ExtractInt(dictionary6, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0) == 1)
								{
									list.Add(num5);
								}
							}
						}
						Dictionary<string, object> dictionary7 = (Dictionary<string, object>)dictionary5[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)];
						long num6 = 0L;
						long num7 = 0L;
						using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary7.Keys.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								long num8;
								if (long.TryParse(enumerator.Current, out num8) && !list.Contains(num8))
								{
									if (num8 > num6 && num8 <= this.#=zKa2XiiZl7goe())
									{
										num6 = num8;
									}
									if (num8 > num7 && num8 <= this.#=zuCvgEb_H$DFbBGNJwMU4czc=())
									{
										num7 = num8;
									}
								}
							}
						}
						if (dictionary7.ContainsKey(num6.ToString()))
						{
							object[] array8 = (object[])dictionary7[num6.ToString()];
							int[] array9 = new int[array8.Length];
							for (int m = 0; m < array8.Length; m++)
							{
								array9[m] = JSONManager.GetInt(array8[m], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), -1);
							}
							this.#=zmwrfSHHI86R4$A6xvA==().Add(array9);
						}
						if (dictionary7.ContainsKey(num7.ToString()))
						{
							object[] array10 = (object[])dictionary7[num7.ToString()];
							int[] array11 = new int[array10.Length];
							for (int n = 0; n < array10.Length; n++)
							{
								array11[n] = JSONManager.GetInt(array10[n], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), -1);
							}
							this.#=zdNyHlR6WcSxIgrGCoPjPDmc3An1R().Add(array11);
						}
					}
				}
			}
		}
	}

	// Token: 0x06001360 RID: 4960 RVA: 0x000969A4 File Offset: 0x00094BA4
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001361 RID: 4961 RVA: 0x000969AC File Offset: 0x00094BAC
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001362 RID: 4962 RVA: 0x000969B8 File Offset: 0x00094BB8
	public int #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x06001363 RID: 4963 RVA: 0x000969C0 File Offset: 0x00094BC0
	public void #=zIaGGDzQ=(int #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001364 RID: 4964 RVA: 0x000969CC File Offset: 0x00094BCC
	public int #=zLg_4gHQfENBn()
	{
		return this.#=zTDrKbYfHO3TocBFUIA==;
	}

	// Token: 0x06001365 RID: 4965 RVA: 0x000969D4 File Offset: 0x00094BD4
	public void #=zeIQ12_vYtW9$(int #=z$Ib9gYQ=)
	{
		this.#=zTDrKbYfHO3TocBFUIA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001366 RID: 4966 RVA: 0x000969E0 File Offset: 0x00094BE0
	public ProphecyTypes #=znqqYiI0yKfELaxv8MQ==()
	{
		return this.#=zFeO99GO1wAZ8Wf_65SaanksCmrbW;
	}

	// Token: 0x06001367 RID: 4967 RVA: 0x000969E8 File Offset: 0x00094BE8
	public void #=zTyGV9Sm$rwQHw7TLOw==(ProphecyTypes #=z$Ib9gYQ=)
	{
		this.#=zFeO99GO1wAZ8Wf_65SaanksCmrbW = #=z$Ib9gYQ=;
	}

	// Token: 0x06001368 RID: 4968 RVA: 0x000969F4 File Offset: 0x00094BF4
	public DateTime #=zXuw1agBmq5jc()
	{
		return this.#=zOhAsirmpTPZPYgYpsw==;
	}

	// Token: 0x06001369 RID: 4969 RVA: 0x000969FC File Offset: 0x00094BFC
	public void #=zeLdu5OWgWfri(DateTime #=z$Ib9gYQ=)
	{
		this.#=zOhAsirmpTPZPYgYpsw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600136A RID: 4970 RVA: 0x00096A08 File Offset: 0x00094C08
	public bool #=zosN4hoVyBAOs()
	{
		return this.#=zaFZUECPzOjLIRd12Tg==;
	}

	// Token: 0x0600136B RID: 4971 RVA: 0x00096A10 File Offset: 0x00094C10
	public void #=zS5uus3Bg_NuG(bool #=z$Ib9gYQ=)
	{
		this.#=zaFZUECPzOjLIRd12Tg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600136C RID: 4972 RVA: 0x00096A1C File Offset: 0x00094C1C
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x0600136D RID: 4973 RVA: 0x00096A24 File Offset: 0x00094C24
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600136E RID: 4974 RVA: 0x00096A30 File Offset: 0x00094C30
	public List<#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=> #=zRTKkIHydRtAD()
	{
		return this.#=zr_v_qRXJl9ZD5cs7LA==;
	}

	// Token: 0x0600136F RID: 4975 RVA: 0x00096A38 File Offset: 0x00094C38
	public void #=zfFo1ZHcBW0DT(List<#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=> #=z$Ib9gYQ=)
	{
		this.#=zr_v_qRXJl9ZD5cs7LA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001370 RID: 4976 RVA: 0x00096A44 File Offset: 0x00094C44
	public bool #=zzO1Tc28mhiyKO1MslOQ8t9E=()
	{
		return this.#=zFkaHPtdJoP26VgKPXyofH8O0LjID;
	}

	// Token: 0x06001371 RID: 4977 RVA: 0x00096A4C File Offset: 0x00094C4C
	public void #=zHCtIGcFRChmNvwQXK4XN8Ks=(bool #=z$Ib9gYQ=)
	{
		this.#=zFkaHPtdJoP26VgKPXyofH8O0LjID = #=z$Ib9gYQ=;
	}

	// Token: 0x06001372 RID: 4978 RVA: 0x00096A58 File Offset: 0x00094C58
	public bool #=ztHG2xIVtnVuUuCv$xQRGrWc=()
	{
		return this.#=zlgJc0AHr3fpJJYJYTfJeUZ3p$rFT;
	}

	// Token: 0x06001373 RID: 4979 RVA: 0x00096A60 File Offset: 0x00094C60
	public void #=zmBSIKq3q0MyRbTBzeB96Rnk=(bool #=z$Ib9gYQ=)
	{
		this.#=zlgJc0AHr3fpJJYJYTfJeUZ3p$rFT = #=z$Ib9gYQ=;
	}

	// Token: 0x06001374 RID: 4980 RVA: 0x00096A6C File Offset: 0x00094C6C
	public bool #=zsGegpFIDm4HnM1ZwbMKrm1OyKO$D()
	{
		return this.#=zuxxsrjm_8cjLsnVMu$VA8o6GrPEn1bjAlJtDXDs=;
	}

	// Token: 0x06001375 RID: 4981 RVA: 0x00096A74 File Offset: 0x00094C74
	public void #=zL2A7aHgGt3fiwu1VnEo$BJGukqkS(bool #=z$Ib9gYQ=)
	{
		this.#=zuxxsrjm_8cjLsnVMu$VA8o6GrPEn1bjAlJtDXDs= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001376 RID: 4982 RVA: 0x00096A80 File Offset: 0x00094C80
	public bool #=zL_AjLx6G9w6sr8eOlj6hZ3k=()
	{
		return this.#=zUW03cHx97$JJiO8Cnquvehw8ZjH5cvPzAg==;
	}

	// Token: 0x06001377 RID: 4983 RVA: 0x00096A88 File Offset: 0x00094C88
	public void #=zMPGw4ygbGMktqwcAhiD856Y=(bool #=z$Ib9gYQ=)
	{
		this.#=zUW03cHx97$JJiO8Cnquvehw8ZjH5cvPzAg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001378 RID: 4984 RVA: 0x00096A94 File Offset: 0x00094C94
	public bool #=zuMDUwezH0nzaovu4ou0ba4x_JDN2b6S2ZA==()
	{
		return this.#=zE6icwuZF82Ubf8SWwowBBfNY_VkgdBzHrsPZLIQ=;
	}

	// Token: 0x06001379 RID: 4985 RVA: 0x00096A9C File Offset: 0x00094C9C
	public void #=zCS3R3X18bjDJrm_H6AEgZVrcECQJC4AnEw==(bool #=z$Ib9gYQ=)
	{
		this.#=zE6icwuZF82Ubf8SWwowBBfNY_VkgdBzHrsPZLIQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600137A RID: 4986 RVA: 0x00096AA8 File Offset: 0x00094CA8
	public long #=zKa2XiiZl7goe()
	{
		return this.#=zhDBbVnM6mEfbV8Xw17biqVM=;
	}

	// Token: 0x0600137B RID: 4987 RVA: 0x00096AB0 File Offset: 0x00094CB0
	public void #=zUPSHR4Zqppk3(long #=z$Ib9gYQ=)
	{
		this.#=zhDBbVnM6mEfbV8Xw17biqVM= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600137C RID: 4988 RVA: 0x00096ABC File Offset: 0x00094CBC
	public long #=zuCvgEb_H$DFbBGNJwMU4czc=()
	{
		return this.#=z4WRz6lVS0efrGKc0xJGYDmgWuiMU;
	}

	// Token: 0x0600137D RID: 4989 RVA: 0x00096AC4 File Offset: 0x00094CC4
	public void #=zwSmAJ1VkaZuHcZJIsVPh4Hs=(long #=z$Ib9gYQ=)
	{
		this.#=z4WRz6lVS0efrGKc0xJGYDmgWuiMU = #=z$Ib9gYQ=;
	}

	// Token: 0x0600137E RID: 4990 RVA: 0x00096AD0 File Offset: 0x00094CD0
	public bool #=zN0c_qE6yJTk7()
	{
		return this.#=zLwpDjafCflG19NJUhCgu1uI=;
	}

	// Token: 0x0600137F RID: 4991 RVA: 0x00096AD8 File Offset: 0x00094CD8
	public void #=z9j0XbQ320sIb(bool #=z$Ib9gYQ=)
	{
		this.#=zLwpDjafCflG19NJUhCgu1uI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001380 RID: 4992 RVA: 0x00096AE4 File Offset: 0x00094CE4
	public List<int[]> #=zmwrfSHHI86R4$A6xvA==()
	{
		return this.#=ziejaI35Ahj05SoeMK1RIXHMDUvSC;
	}

	// Token: 0x06001381 RID: 4993 RVA: 0x00096AEC File Offset: 0x00094CEC
	public void #=z7qNdaLMNedGDJKZ0eQ==(List<int[]> #=z$Ib9gYQ=)
	{
		this.#=ziejaI35Ahj05SoeMK1RIXHMDUvSC = #=z$Ib9gYQ=;
	}

	// Token: 0x06001382 RID: 4994 RVA: 0x00096AF8 File Offset: 0x00094CF8
	public List<int[]> #=zdNyHlR6WcSxIgrGCoPjPDmc3An1R()
	{
		return this.#=zZh6ANO8iw3LG5AXD1VA2K55dmIHO5jJyEc7rAMg=;
	}

	// Token: 0x06001383 RID: 4995 RVA: 0x00096B00 File Offset: 0x00094D00
	public void #=zrfMnF8JOjXWKXhxzUfV7kmupzSBX(List<int[]> #=z$Ib9gYQ=)
	{
		this.#=zZh6ANO8iw3LG5AXD1VA2K55dmIHO5jJyEc7rAMg= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001384 RID: 4996 RVA: 0x00096B0C File Offset: 0x00094D0C
	public int #=zuDNrgEn6avv5JV0$utd1XIH$Fx8Rf0nEkA==()
	{
		return this.#=z0wYP7UwWEctQJCzPosbjAjPfk_ns9m2RhRGqMMo=;
	}

	// Token: 0x06001385 RID: 4997 RVA: 0x00096B14 File Offset: 0x00094D14
	public void #=zf6Kf_GiFmUKTyGZ1sGn6IiH2oi4wI1oTBg==(int #=z$Ib9gYQ=)
	{
		this.#=z0wYP7UwWEctQJCzPosbjAjPfk_ns9m2RhRGqMMo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x00096B20 File Offset: 0x00094D20
	public int[] #=zs4VItRnK8RHCsmBP1UyCU4NH2aiPL5bfuGvC00TmOQZJ()
	{
		return this.#=zenkpI0UFgNKoWA4xT$yNHbNbQn6dYTugFL8q3Z69Syw049w5Qw==;
	}

	// Token: 0x06001387 RID: 4999 RVA: 0x00096B28 File Offset: 0x00094D28
	public void #=zoU6VjqHZj0WD7v41GsxywIO0Hzqi8iqdPl0GKIrCu7hu(int[] #=z$Ib9gYQ=)
	{
		this.#=zenkpI0UFgNKoWA4xT$yNHbNbQn6dYTugFL8q3Z69Syw049w5Qw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001388 RID: 5000 RVA: 0x00096B34 File Offset: 0x00094D34
	private static bool #=zh5Incl7GerXGyMXQ3pU005k=(Dictionary<string, object> #=zTQUALZ5jEuLU)
	{
		if (#=zTQUALZ5jEuLU.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)) || #=zTQUALZ5jEuLU.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)))
		{
			object[] array;
			if (#=zTQUALZ5jEuLU.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)))
			{
				array = (#=zTQUALZ5jEuLU[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061894)] as object[]);
			}
			else
			{
				array = (#=zTQUALZ5jEuLU[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076549)] as object[]);
			}
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)))
				{
					using (Dictionary<string, object>.ValueCollection.Enumerator enumerator = ((Dictionary<string, object>)dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)]).Values.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							if (((object[])enumerator.Current).Length > 1)
							{
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}

	// Token: 0x06001389 RID: 5001 RVA: 0x00096C3C File Offset: 0x00094E3C
	private static bool #=z4F7pzUnOpIZd9WL5Y5hHrMgBAq7o$fjoOw==(Dictionary<string, object> #=zTQUALZ5jEuLU)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zTQUALZ5jEuLU, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062100));
		return dictionary != null && dictionary.Count > 0;
	}

	// Token: 0x04000B33 RID: 2867
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000B34 RID: 2868
	private int #=z7Xrwc11cWxGe$3RbFQ==;

	// Token: 0x04000B35 RID: 2869
	private int #=zTDrKbYfHO3TocBFUIA==;

	// Token: 0x04000B36 RID: 2870
	private ProphecyTypes #=zFeO99GO1wAZ8Wf_65SaanksCmrbW;

	// Token: 0x04000B37 RID: 2871
	private DateTime #=zOhAsirmpTPZPYgYpsw==;

	// Token: 0x04000B38 RID: 2872
	private bool #=zaFZUECPzOjLIRd12Tg==;

	// Token: 0x04000B39 RID: 2873
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000B3A RID: 2874
	private List<#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=> #=zr_v_qRXJl9ZD5cs7LA==;

	// Token: 0x04000B3B RID: 2875
	private bool #=zFkaHPtdJoP26VgKPXyofH8O0LjID;

	// Token: 0x04000B3C RID: 2876
	private bool #=zlgJc0AHr3fpJJYJYTfJeUZ3p$rFT;

	// Token: 0x04000B3D RID: 2877
	private bool #=zuxxsrjm_8cjLsnVMu$VA8o6GrPEn1bjAlJtDXDs=;

	// Token: 0x04000B3E RID: 2878
	private bool #=zUW03cHx97$JJiO8Cnquvehw8ZjH5cvPzAg==;

	// Token: 0x04000B3F RID: 2879
	private bool #=zE6icwuZF82Ubf8SWwowBBfNY_VkgdBzHrsPZLIQ=;

	// Token: 0x04000B40 RID: 2880
	private long #=zhDBbVnM6mEfbV8Xw17biqVM=;

	// Token: 0x04000B41 RID: 2881
	private long #=z4WRz6lVS0efrGKc0xJGYDmgWuiMU;

	// Token: 0x04000B42 RID: 2882
	private bool #=zLwpDjafCflG19NJUhCgu1uI=;

	// Token: 0x04000B43 RID: 2883
	private List<int[]> #=ziejaI35Ahj05SoeMK1RIXHMDUvSC;

	// Token: 0x04000B44 RID: 2884
	private List<int[]> #=zZh6ANO8iw3LG5AXD1VA2K55dmIHO5jJyEc7rAMg=;

	// Token: 0x04000B45 RID: 2885
	private int #=z0wYP7UwWEctQJCzPosbjAjPfk_ns9m2RhRGqMMo=;

	// Token: 0x04000B46 RID: 2886
	private int[] #=zenkpI0UFgNKoWA4xT$yNHbNbQn6dYTugFL8q3Z69Syw049w5Qw==;
}
