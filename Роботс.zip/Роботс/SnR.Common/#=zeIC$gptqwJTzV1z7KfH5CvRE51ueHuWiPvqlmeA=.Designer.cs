﻿// Token: 0x02000227 RID: 551
internal sealed partial class #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA= : global::System.Windows.Forms.Form
{
	// Token: 0x060010E3 RID: 4323 RVA: 0x00081EA8 File Offset: 0x000800A8
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400091A RID: 2330
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
