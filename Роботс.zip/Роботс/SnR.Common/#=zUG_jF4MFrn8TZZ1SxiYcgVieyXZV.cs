﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001AF RID: 431
internal sealed class #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV
{
	// Token: 0x06000CFF RID: 3327 RVA: 0x0006782C File Offset: 0x00065A2C
	public #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV(Dictionary<string, object> #=z9yO47Nw=, Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=> #=zBIFu03PsP74P)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zedb$WwBQsoJF(JSONManager.ExtractInt(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
		this.#=zFzGvi_S6jJhE(JSONManager.ExtractInt(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		this.#=zBk1NzmA_vjCr(JSONManager.ExtractInt(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), 0) == 1);
		this.#=zc$iFYJxIrcBr(JSONManager.ExtractDate(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), false));
		this.#=zg8A$A1dlfoa2((#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=z$1SDmnS4D2xw)JSONManager.ExtractInt(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		if (#=zBIFu03PsP74P != null)
		{
			if (#=zBIFu03PsP74P.ContainsKey(this.#=zFMDiymuLQ7_4()))
			{
				this.#=zzQwUIEs=(#=zBIFu03PsP74P[this.#=zFMDiymuLQ7_4()]);
			}
			else
			{
				this.#=zzQwUIEs=((#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=)(-1));
			}
		}
		else
		{
			this.#=zzQwUIEs=(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zatx6MLw=(this.#=zFMDiymuLQ7_4()));
		}
		this.#=zYLmCOgDSaw0kiDTnDZu7mB8=(null);
		object[] array = JSONManager.ExtractArray(#=z9yO47Nw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060495));
		if (array != null && array.Length != 0)
		{
			this.#=zYLmCOgDSaw0kiDTnDZu7mB8=(new int[array.Length]);
			for (int i = 0; i < array.Length; i++)
			{
				this.#=zS7kcg6b8uXh$0NvnBDcz6Ys=()[i] = Convert.ToInt32(array[i]);
			}
		}
	}

	// Token: 0x06000D00 RID: 3328 RVA: 0x00067958 File Offset: 0x00065B58
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000D01 RID: 3329 RVA: 0x00067960 File Offset: 0x00065B60
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D02 RID: 3330 RVA: 0x0006796C File Offset: 0x00065B6C
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x06000D03 RID: 3331 RVA: 0x00067974 File Offset: 0x00065B74
	public void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D04 RID: 3332 RVA: 0x00067980 File Offset: 0x00065B80
	public #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000D05 RID: 3333 RVA: 0x00067988 File Offset: 0x00065B88
	public void #=zzQwUIEs=(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D06 RID: 3334 RVA: 0x00067994 File Offset: 0x00065B94
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000D07 RID: 3335 RVA: 0x0006799C File Offset: 0x00065B9C
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D08 RID: 3336 RVA: 0x000679A8 File Offset: 0x00065BA8
	public bool #=zi2a1Q$EWsrif()
	{
		return this.#=zoSQ9RNUaVBE8KIR9rQ==;
	}

	// Token: 0x06000D09 RID: 3337 RVA: 0x000679B0 File Offset: 0x00065BB0
	public void #=zBk1NzmA_vjCr(bool #=z$Ib9gYQ=)
	{
		this.#=zoSQ9RNUaVBE8KIR9rQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D0A RID: 3338 RVA: 0x000679BC File Offset: 0x00065BBC
	public DateTime #=zTC2S$D65wv_r()
	{
		return this.#=zl8v0dqfoiQQmM5XW_GUyIcA=;
	}

	// Token: 0x06000D0B RID: 3339 RVA: 0x000679C4 File Offset: 0x00065BC4
	public void #=zc$iFYJxIrcBr(DateTime #=z$Ib9gYQ=)
	{
		this.#=zl8v0dqfoiQQmM5XW_GUyIcA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D0C RID: 3340 RVA: 0x000679D0 File Offset: 0x00065BD0
	public #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=z$1SDmnS4D2xw #=z8Nl16CPh9dN5()
	{
		return this.#=zNgo9sLPBSkVeTNAHtw==;
	}

	// Token: 0x06000D0D RID: 3341 RVA: 0x000679D8 File Offset: 0x00065BD8
	public void #=zg8A$A1dlfoa2(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=z$1SDmnS4D2xw #=z$Ib9gYQ=)
	{
		this.#=zNgo9sLPBSkVeTNAHtw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D0E RID: 3342 RVA: 0x000679E4 File Offset: 0x00065BE4
	public int[] #=zS7kcg6b8uXh$0NvnBDcz6Ys=()
	{
		return this.#=zHPsccgYxR6AwEv3gJWMaBR4K3l6E;
	}

	// Token: 0x06000D0F RID: 3343 RVA: 0x000679EC File Offset: 0x00065BEC
	public void #=zYLmCOgDSaw0kiDTnDZu7mB8=(int[] #=z$Ib9gYQ=)
	{
		this.#=zHPsccgYxR6AwEv3gJWMaBR4K3l6E = #=z$Ib9gYQ=;
	}

	// Token: 0x06000D10 RID: 3344 RVA: 0x000679F8 File Offset: 0x00065BF8
	public bool #=zzuDU5U9dTvAm()
	{
		return !this.#=zi2a1Q$EWsrif() || this.#=zS7kcg6b8uXh$0NvnBDcz6Ys=() != null || this.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackTeam || this.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseTeam;
	}

	// Token: 0x06000D11 RID: 3345 RVA: 0x00067A20 File Offset: 0x00065C20
	private static #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= #=zatx6MLw=(int #=ztmbqrmc=)
	{
		if (#=ztmbqrmc= < 9)
		{
			return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Attack;
		}
		if (#=ztmbqrmc= < 13)
		{
			return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Defense;
		}
		if (#=ztmbqrmc= < 500)
		{
			if (#=ztmbqrmc= % 2 == 1)
			{
				return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackStory;
			}
			return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseStory;
		}
		else if (#=ztmbqrmc= < 600)
		{
			if (#=ztmbqrmc= % 2 == 0)
			{
				return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackFuture;
			}
			return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseFuture;
		}
		else
		{
			if (#=ztmbqrmc= % 2 == 0)
			{
				return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackFutureStory;
			}
			return #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseFutureStory;
		}
	}

	// Token: 0x04000779 RID: 1913
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400077A RID: 1914
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x0400077B RID: 1915
	private #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400077C RID: 1916
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400077D RID: 1917
	private bool #=zoSQ9RNUaVBE8KIR9rQ==;

	// Token: 0x0400077E RID: 1918
	private DateTime #=zl8v0dqfoiQQmM5XW_GUyIcA=;

	// Token: 0x0400077F RID: 1919
	private #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=z$1SDmnS4D2xw #=zNgo9sLPBSkVeTNAHtw==;

	// Token: 0x04000780 RID: 1920
	private int[] #=zHPsccgYxR6AwEv3gJWMaBR4K3l6E;

	// Token: 0x020001B0 RID: 432
	public enum #=z$1SDmnS4D2xw
	{

	}

	// Token: 0x020001B1 RID: 433
	public enum #=zArez$Gs=
	{
		// Token: 0x04000783 RID: 1923
		Attack,
		// Token: 0x04000784 RID: 1924
		Defense,
		// Token: 0x04000785 RID: 1925
		AttackStory,
		// Token: 0x04000786 RID: 1926
		DefenseStory,
		// Token: 0x04000787 RID: 1927
		AttackFuture,
		// Token: 0x04000788 RID: 1928
		DefenseFuture,
		// Token: 0x04000789 RID: 1929
		AttackFutureStory,
		// Token: 0x0400078A RID: 1930
		DefenseFutureStory,
		// Token: 0x0400078B RID: 1931
		AttackVeoraStory,
		// Token: 0x0400078C RID: 1932
		DefenseVeoraStory,
		// Token: 0x0400078D RID: 1933
		AttackTeam,
		// Token: 0x0400078E RID: 1934
		DefenseTeam,
		// Token: 0x0400078F RID: 1935
		AttackStronghold,
		// Token: 0x04000790 RID: 1936
		DefenseStronghold
	}
}
