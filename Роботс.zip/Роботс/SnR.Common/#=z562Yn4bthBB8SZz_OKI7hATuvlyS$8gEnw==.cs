﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common;
using Skink.SnR.Common.Managers;

// Token: 0x0200006E RID: 110
internal sealed class #=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==
{
	// Token: 0x0600031F RID: 799 RVA: 0x0001D6CC File Offset: 0x0001B8CC
	public static void #=z6i3mHuw=()
	{
		new Thread(new ThreadStart(#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zA2vjLIs=)).Start();
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0001D6E4 File Offset: 0x0001B8E4
	public static bool #=zJO5XMrsPugGq()
	{
		if (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=z$kkAC8YSPjrH && DateTime.Now >= #=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zwiAqM3aNHwss)
		{
			#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=z$kkAC8YSPjrH = false;
		}
		return #=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=z$kkAC8YSPjrH;
	}

	// Token: 0x06000321 RID: 801 RVA: 0x0001D70C File Offset: 0x0001B90C
	private static void #=zRgURr0PDCRpk(bool #=z$Ib9gYQ=)
	{
		#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=z$kkAC8YSPjrH = #=z$Ib9gYQ=;
		if (#=z$Ib9gYQ=)
		{
			#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zwiAqM3aNHwss = DateTime.Now + TimeSpan.FromMinutes(60.0);
		}
	}

	// Token: 0x06000322 RID: 802 RVA: 0x0001D734 File Offset: 0x0001B934
	private static void #=zA2vjLIs=()
	{
		object obj = #=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zSV4$mlFB34WM;
		lock (obj)
		{
			if (!#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zJO5XMrsPugGq())
			{
				try
				{
					#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zRgURr0PDCRpk(true);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
					List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list = new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>();
					foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY())
					{
						if (!#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zObGzldk_Y5$c() && !#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zJO5XMrsPugGq())
						{
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zRgURr0PDCRpk(true);
							list.Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
						}
					}
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110048), new object[]
					{
						list.Count
					});
					int num = 0;
					int num2 = 0;
					foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2 in list)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110233), new object[]
						{
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z2ZE0cltcIoE3IY7EAQ==(),
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe()
						});
						Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zB2UH099PEmWB(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zh5Q$jgycqA15().#=zCCvotbi$42tS(), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7()));
						#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$ #=zG4GdawKHNR1$ = (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077329), 0);
						if (#=zG4GdawKHNR1$ == (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$)1)
						{
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zZJbepNH_IDuQ(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110166), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zpeAmYAKx8nem(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110159), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9l$gimR8dkJhDCQJAw==(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110148), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zpVBlD$IJ4abR(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109885), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zVOkdnwLzxOWf(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109866), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zPzFoe9Yoa4Jh(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062075), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zchs2LGrZFGl4(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109859), string.Empty));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zhWr8WM11sNyG(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109848), string.Empty));
						}
						foreach (Dictionary<string, object> dictionary2 in JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109841)))
						{
							LogTypes #=zvRLj9WQ= = (LogTypes)JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
							string #=zx9NCziM= = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), string.Empty);
							object[] #=zlP66l7Q4Pzmc = JSONManager.ExtractArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237));
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, #=zvRLj9WQ=, #=zx9NCziM=, #=zlP66l7Q4Pzmc);
						}
						if (#=zG4GdawKHNR1$ == (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$)1)
						{
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(false);
							foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zol80P7TKoihZ())
							{
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
							}
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055148), Array.Empty<object>());
							#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109838), new object[]
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z2ZE0cltcIoE3IY7EAQ==(),
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe()
							});
							num++;
						}
						else if (#=zG4GdawKHNR1$ == (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$)2)
						{
							if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z97Z7CxekCb4f())
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(true);
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056000), Array.Empty<object>());
								#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110001), new object[]
								{
									#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z2ZE0cltcIoE3IY7EAQ==(),
									#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe()
								});
							}
							else if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zzVO7jsiozzIu(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2))
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(false);
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109928), new object[]
								{
									#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zh5Q$jgycqA15().#=zCCvotbi$42tS()
								});
							}
							else
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(true);
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109625), new object[]
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051964)
								});
							}
							num2++;
						}
						else
						{
							if (#=zG4GdawKHNR1$ != (#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zG4GdawKHNR1$)3)
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(true);
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055104), Array.Empty<object>());
								#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110001), new object[]
								{
									#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z2ZE0cltcIoE3IY7EAQ==(),
									#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe()
								});
								num2++;
								break;
							}
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zJz$BeuY2bs5T(true);
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055104), Array.Empty<object>());
							#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110001), new object[]
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z2ZE0cltcIoE3IY7EAQ==(),
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe()
							});
							num2++;
						}
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zRgURr0PDCRpk(false);
					}
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109584), new object[]
					{
						num,
						num2
					});
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
				}
				finally
				{
					#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=zRgURr0PDCRpk(false);
				}
			}
		}
	}

	// Token: 0x0400011D RID: 285
	private static bool #=z$kkAC8YSPjrH = false;

	// Token: 0x0400011E RID: 286
	private static DateTime #=zwiAqM3aNHwss;

	// Token: 0x0400011F RID: 287
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x0200006F RID: 111
	private enum #=zG4GdawKHNR1$
	{

	}
}
