﻿using System;
using System.Runtime.InteropServices;

// Token: 0x0200006D RID: 109
[Guid("ebc25cf6-9120-4283-b972-0e5520d0000E")]
internal sealed class #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw== : Exception
{
	// Token: 0x0600031B RID: 795 RVA: 0x0001D69C File Offset: 0x0001B89C
	public #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==()
	{
	}

	// Token: 0x0600031C RID: 796 RVA: 0x0001D6A4 File Offset: 0x0001B8A4
	public #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string #=zWj7xLq8=) : base(#=zWj7xLq8=)
	{
	}
}
