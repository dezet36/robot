﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x020000E8 RID: 232
internal sealed class #=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=>
{
	// Token: 0x06000617 RID: 1559 RVA: 0x000319C4 File Offset: 0x0002FBC4
	public #=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=(TimeSpan #=zj0TYbdY=, bool #=zOaTyd2l4wNme = false, #=zQSoxQMk= #=z01CGwd2vEoD_ = default(#=zQSoxQMk=))
	{
		this.#=z9HdGFQI= = new Dictionary<string, #=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=, #=zQSoxQMk=>.#=z3JIII_A8kcpSHjh$OA==>();
		this.#=zeKHKOqE= = #=zj0TYbdY=;
		this.#=z3mRw5touiqOf = #=z01CGwd2vEoD_;
		this.#=zSV4$mlFB34WM = (#=zOaTyd2l4wNme ? new object() : null);
	}

	// Token: 0x1700001B RID: 27
	[IndexerName("#=zx6APBRk=")]
	public #=zQSoxQMk= this[string #=zNraCe1Y=]
	{
		get
		{
			if (this.#=z9HdGFQI=.ContainsKey(#=zNraCe1Y=))
			{
				#=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=, #=zQSoxQMk=>.#=z3JIII_A8kcpSHjh$OA== #=z3JIII_A8kcpSHjh$OA== = this.#=z9HdGFQI=[#=zNraCe1Y=];
				if (!(#=z3JIII_A8kcpSHjh$OA==.#=zbK2hBFM1$8vd() < DateTime.Now))
				{
					return #=z3JIII_A8kcpSHjh$OA==.#=zIbbwDpgk_dxB();
				}
				if (this.#=zSV4$mlFB34WM != null)
				{
					object obj = this.#=zSV4$mlFB34WM;
					lock (obj)
					{
						this.#=z9HdGFQI=.Remove(#=zNraCe1Y=);
						goto IL_75;
					}
				}
				this.#=z9HdGFQI=.Remove(#=zNraCe1Y=);
			}
			IL_75:
			return this.#=z3mRw5touiqOf;
		}
		set
		{
			if (this.#=zSV4$mlFB34WM != null)
			{
				object obj = this.#=zSV4$mlFB34WM;
				lock (obj)
				{
					this.#=ziL6XPwI=(#=zNraCe1Y=, value);
					return;
				}
			}
			this.#=ziL6XPwI=(#=zNraCe1Y=, value);
		}
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x00031AE4 File Offset: 0x0002FCE4
	private void #=ziL6XPwI=(string #=zNraCe1Y=, #=zQSoxQMk= #=z$Ib9gYQ=)
	{
		#=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=, #=zQSoxQMk=>.#=z3JIII_A8kcpSHjh$OA== #=z3JIII_A8kcpSHjh$OA==;
		if (this.#=z9HdGFQI=.ContainsKey(#=zNraCe1Y=))
		{
			#=z3JIII_A8kcpSHjh$OA== = this.#=z9HdGFQI=[#=zNraCe1Y=];
		}
		else
		{
			#=z3JIII_A8kcpSHjh$OA== = new #=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=, #=zQSoxQMk=>.#=z3JIII_A8kcpSHjh$OA==();
			this.#=z9HdGFQI=[#=zNraCe1Y=] = #=z3JIII_A8kcpSHjh$OA==;
		}
		#=z3JIII_A8kcpSHjh$OA==.#=zNJA8j3lHNJYy(#=z$Ib9gYQ=);
		#=z3JIII_A8kcpSHjh$OA==.#=z$iMfIGmiGOXW(DateTime.Now + this.#=zeKHKOqE=);
	}

	// Token: 0x04000283 RID: 643
	private Dictionary<string, #=zEise3$GtCJbrmkjJBAhc44gd1Xbd6eyjSp2KPJo=<#=zQSoxQMk=, #=zQSoxQMk=>.#=z3JIII_A8kcpSHjh$OA==> #=z9HdGFQI=;

	// Token: 0x04000284 RID: 644
	private TimeSpan #=zeKHKOqE=;

	// Token: 0x04000285 RID: 645
	private #=zQSoxQMk= #=z3mRw5touiqOf;

	// Token: 0x04000286 RID: 646
	private object #=zSV4$mlFB34WM;

	// Token: 0x020000E9 RID: 233
	internal sealed class #=z3JIII_A8kcpSHjh$OA==<#=zBBxQYDs=>
	{
		// Token: 0x0600061C RID: 1564 RVA: 0x00031B48 File Offset: 0x0002FD48
		public DateTime #=zbK2hBFM1$8vd()
		{
			return this.#=zhnwN1sPFxZqWFkYnrw==;
		}

		// Token: 0x0600061D RID: 1565 RVA: 0x00031B50 File Offset: 0x0002FD50
		public void #=z$iMfIGmiGOXW(DateTime #=z$Ib9gYQ=)
		{
			this.#=zhnwN1sPFxZqWFkYnrw== = #=z$Ib9gYQ=;
		}

		// Token: 0x0600061E RID: 1566 RVA: 0x00031B5C File Offset: 0x0002FD5C
		public #=zBBxQYDs= #=zIbbwDpgk_dxB()
		{
			return this.#=znEWIeYV0aB8MZzY3Kw==;
		}

		// Token: 0x0600061F RID: 1567 RVA: 0x00031B64 File Offset: 0x0002FD64
		public void #=zNJA8j3lHNJYy(#=zBBxQYDs= #=z$Ib9gYQ=)
		{
			this.#=znEWIeYV0aB8MZzY3Kw== = #=z$Ib9gYQ=;
		}

		// Token: 0x04000287 RID: 647
		private DateTime #=zhnwN1sPFxZqWFkYnrw==;

		// Token: 0x04000288 RID: 648
		private #=zBBxQYDs= #=znEWIeYV0aB8MZzY3Kw==;
	}
}
