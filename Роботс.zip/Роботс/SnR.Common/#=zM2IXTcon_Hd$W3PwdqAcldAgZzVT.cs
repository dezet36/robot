﻿using System;

// Token: 0x0200015D RID: 349
internal interface #=zM2IXTcon_Hd$W3PwdqAcldAgZzVT
{
	// Token: 0x06000943 RID: 2371
	int #=zMuFMjGQ=();

	// Token: 0x06000944 RID: 2372
	int #=zFMDiymuLQ7_4();

	// Token: 0x06000945 RID: 2373
	int #=zaKAy47_E$9SRuF6oiw==();

	// Token: 0x06000946 RID: 2374
	int #=ztj93y6niVpCR();

	// Token: 0x06000947 RID: 2375
	int #=zvnZc$RhG_1Du();

	// Token: 0x06000948 RID: 2376
	int #=zVm_gjb4pLtQN();

	// Token: 0x06000949 RID: 2377
	string #=zPEhDdtHVGNHR();

	// Token: 0x0600094A RID: 2378
	string #=zNTEClmggtyu4();
}
