﻿using System;
using System.Collections.Generic;
using System.Linq;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200025B RID: 603
internal sealed class #=ziBmi3s639WqpYN2JCWztK$ZKBDsrMTYIuSv_7bNZaZqspzmaIvLnbHfSEJzI : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001253 RID: 4691 RVA: 0x0008FF9C File Offset: 0x0008E19C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06001254 RID: 4692 RVA: 0x0008FFA0 File Offset: 0x0008E1A0
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=))
		{
			return;
		}
		#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= = (#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=)this.#=zcDRV51Ut$7oP;
		#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobbery);
		#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null) ? #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=z5_3JqsL118hV() : #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGV9CLmCENINvspF3MQ==(this.#=z8StzeqE=, this.#=zBsXSanI=);
		if (#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zJeSQPOW6HtWntjFp2g==().Count > 0)
		{
			Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>();
			for (int i = 0; i < #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zJeSQPOW6HtWntjFp2g==().Count; i++)
			{
				int[] array = #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zJeSQPOW6HtWntjFp2g==()[i];
				int key = array[0];
				int item = array[1];
				List<int> list;
				if (dictionary.ContainsKey(key))
				{
					list = dictionary[key];
				}
				else
				{
					list = new List<int>();
					dictionary.Add(key, list);
				}
				if (!list.Contains(item))
				{
					list.Add(item);
				}
			}
			while (dictionary.Count > 0)
			{
				int num = Enumerable.ElementAt<int>(dictionary.Keys, 0);
				List<int> list2 = dictionary[num];
				if (list2.Count == 0)
				{
					dictionary.Remove(num);
				}
				else
				{
					int num2 = list2[0];
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922891), new object[]
					{
						num,
						num2
					});
					foreach (Dictionary<string, object> dictionary2 in (object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=zpeSgyDU=(num, num2)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)])
					{
						Dictionary<string, object> dictionary3 = (Dictionary<string, object>)dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)];
						int num3 = Convert.ToInt32(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]);
						int num4 = Convert.ToInt32(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]);
						if (dictionary.ContainsKey(num3))
						{
							List<int> list3 = dictionary[num3];
							if (list3.Contains(num4))
							{
								int #=zAk8mKBk= = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
								#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zk$6QZNA=(#=zAk8mKBk=);
								if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= == null)
								{
									string #=z6QPrZ_4= = dictionary2.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)) ? dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)].ToString() : (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919036) + num3.ToString() + num4.ToString()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871), string.Empty);
									#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = new #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(#=zAk8mKBk=, #=z6QPrZ_4=, num3, num4);
									#=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=.#=zvS9NMPa5Yz5Vbpjs0ICBHLE=(this.#=z8StzeqE=, this.#=zBsXSanI=, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=, JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
									#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zGHLCYJmbc1Pd(true);
									#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923104), new object[]
									{
										#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zTbtwDpWhYGtF()
									});
								}
								else
								{
									#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zGHLCYJmbc1Pd(true);
								}
								list3.Remove(num4);
								if (list3.Count == 0)
								{
									dictionary.Remove(num3);
								}
							}
						}
					}
					list2.Remove(num2);
					if (list2.Count == 0)
					{
						dictionary.Remove(num);
					}
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923071), Array.Empty<object>());
		}
		if (#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=znu1Q2M7dE$X2().Count > 0)
		{
			int num5 = 0;
			for (int k = 0; k < #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=znu1Q2M7dE$X2().Count; k++)
			{
				#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=2 = #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=znu1Q2M7dE$X2()[k];
				#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3 = #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zk$6QZNA=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=2.#=zMuFMjGQ=());
				if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3 == null)
				{
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3 = new #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=2.#=zhv7OhlM=(), this.#=z8StzeqE=, this.#=zBsXSanI=);
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3.#=zGHLCYJmbc1Pd(true);
					#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.Add(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923104), new object[]
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3.#=zTbtwDpWhYGtF()
					});
					num5++;
				}
				else
				{
					#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=3.#=zGHLCYJmbc1Pd(true);
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924795), new object[]
			{
				num5
			});
		}
		if (#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zoCWPowk7whj_().Count > 0)
		{
			int num6 = 0;
			for (int l = 0; l < #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zoCWPowk7whj_().Count; l++)
			{
				#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4 = #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zk$6QZNA=(#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zoCWPowk7whj_()[l]);
				if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4 != null)
				{
					if (#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4.#=zu_rEcX_K9l9O())
					{
						#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.Remove(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924759), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4.#=zTbtwDpWhYGtF()
						});
					}
					else
					{
						#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4.#=zu2gIox_y5kvk(true);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924724), new object[]
						{
							#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=4.#=zTbtwDpWhYGtF()
						});
					}
					num6++;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924675), new object[]
			{
				num6
			});
		}
		if (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null)
		{
			#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=zsobh2arZ__ufEqVOvA==(true);
			return;
		}
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGncKSH4oJhxW9OLT6A==(#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==, this.#=z8StzeqE=);
	}
}
