﻿using System;
using System.Collections;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;

// Token: 0x0200022A RID: 554
internal sealed class #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_ : #=zrACqpkJvpkMu2ypmK4UXXdQ=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x060010F9 RID: 4345 RVA: 0x00082D78 File Offset: 0x00080F78
	public #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_(WorkbookSettings #=z4JisLog=)
	{
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x060010FA RID: 4346 RVA: 0x00082D88 File Offset: 0x00080F88
	public #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_(#=zGjUKOJRgFhfLTz4NT1WbagM= #=zTRA8u0c=, WorkbookSettings #=z4JisLog=)
	{
		this.#=z3lUqbh8= = #=zTRA8u0c=;
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x060010FC RID: 4348 RVA: 0x00082DB8 File Offset: 0x00080FB8
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		sbyte[] array2 = new sbyte[0];
		for (int i = 0; i < array.Length; i++)
		{
			sbyte[] array3 = array[i].#=ztbIWLuVjfGLU();
			sbyte[] array4 = new sbyte[array2.Length + array3.Length];
			Array.Copy(array2, 0, array4, 0, array2.Length);
			Array.Copy(array3, 0, array4, array2.Length, array3.Length);
			array2 = array4;
		}
		sbyte[] array5 = new sbyte[array2.Length + 3];
		Array.Copy(array2, 0, array5, 0, array2.Length);
		array5[array2.Length] = ((!base.#=zt$EpC6LMXeRk()) ? #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zWIdvAhk=.#=zd$BbM3Y=() : #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zWIdvAhk=.#=znvQc3vboYqbA());
		IntegerHelper.getTwoBytes(this.#=z3lUqbh8=.#=zd$BbM3Y=(), array5, array2.Length + 1);
		return array5;
	}

	// Token: 0x060010FD RID: 4349 RVA: 0x00082E6C File Offset: 0x0008106C
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x060010FE RID: 4350 RVA: 0x00082E70 File Offset: 0x00081070
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		this.#=z3lUqbh8= = #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zWTaLiHU=(@int);
		Assert.verify(this.#=z3lUqbh8= != #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zNUFwPq0=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077066) + @int.ToString());
		return 2;
	}

	// Token: 0x060010FF RID: 4351 RVA: 0x00082EC4 File Offset: 0x000810C4
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		for (int i = 0; i < this.#=z3lUqbh8=.#=z7z0EEAB0rXFG(); i++)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4= = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
			this.#=zdJYbEvQ=(#=zpvGJrv4=);
		}
	}

	// Token: 0x06001100 RID: 4352 RVA: 0x00082EFC File Offset: 0x000810FC
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zXvwCnz8=.Append(this.#=z3lUqbh8=.#=zLCn5oL8=(this.#=z6bRJXNQ=));
		#=zXvwCnz8=.Append('(');
		int num = this.#=z3lUqbh8=.#=z7z0EEAB0rXFG();
		if (num > 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
			array[num - 1].#=zSpOkW5A=(#=zXvwCnz8=);
			for (int i = num - 2; i >= 0; i--)
			{
				#=zXvwCnz8=.Append(',');
				array[i].#=zSpOkW5A=(#=zXvwCnz8=);
			}
		}
		#=zXvwCnz8=.Append(')');
	}

	// Token: 0x06001101 RID: 4353 RVA: 0x00082F78 File Offset: 0x00081178
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
		}
	}

	// Token: 0x06001102 RID: 4354 RVA: 0x00082FA4 File Offset: 0x000811A4
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001103 RID: 4355 RVA: 0x00082FD4 File Offset: 0x000811D4
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001104 RID: 4356 RVA: 0x00083004 File Offset: 0x00081204
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001105 RID: 4357 RVA: 0x00083034 File Offset: 0x00081234
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x04000937 RID: 2359
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_));

	// Token: 0x04000938 RID: 2360
	private #=zGjUKOJRgFhfLTz4NT1WbagM= #=z3lUqbh8=;

	// Token: 0x04000939 RID: 2361
	private WorkbookSettings #=z6bRJXNQ=;
}
