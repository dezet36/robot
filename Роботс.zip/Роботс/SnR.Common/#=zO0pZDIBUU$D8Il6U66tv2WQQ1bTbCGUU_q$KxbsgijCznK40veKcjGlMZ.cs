﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200016E RID: 366
internal sealed class #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw=
{
	// Token: 0x060009AD RID: 2477 RVA: 0x0004FA7C File Offset: 0x0004DC7C
	public #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw=()
	{
		this.#=zWmxuWiOCG1UewkLi32up7nU=(false);
		this.#=zfN8EDW6sRPbqlWPbGmcSZZg=(new List<string>());
		this.#=zGe3AVOgg_sTuGQJpVBtdy_4=(null);
		this.#=z5_EIUs_W$GlUKgUecw==(false);
		this.#=zHL2ODY6M9f6oMD4ba$$8Kn8=(null);
		this.#=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==(1.0);
		this.#=zrYWRQUVedQLe1UPFog==(new #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k=());
	}

	// Token: 0x060009AE RID: 2478 RVA: 0x0004FAD0 File Offset: 0x0004DCD0
	public #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw=(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zWmxuWiOCG1UewkLi32up7nU=(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108004), 0) == 1);
		this.#=zfN8EDW6sRPbqlWPbGmcSZZg=(new List<string>());
		foreach (string item in JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981)))
		{
			this.#=zqA0_oagr6Vv2qNqwEkcOpe4=().Add(item);
		}
		this.#=zGe3AVOgg_sTuGQJpVBtdy_4=(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927226), string.Empty));
		this.#=z5_EIUs_W$GlUKgUecw==(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927216), 0) == 1);
		this.#=zHL2ODY6M9f6oMD4ba$$8Kn8=(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927209), string.Empty));
		this.#=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==(JSONManager.ExtractDouble(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065743), 0.0));
		this.#=zrYWRQUVedQLe1UPFog==(new #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k=(JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927207))));
	}

	// Token: 0x060009AF RID: 2479 RVA: 0x0004FBC8 File Offset: 0x0004DDC8
	public bool #=zXMCL4WkJhi0RMg21OR12cVE=()
	{
		return this.#=zkeNvlzcHCe38TpetOm7Py2R6MSsX;
	}

	// Token: 0x060009B0 RID: 2480 RVA: 0x0004FBD0 File Offset: 0x0004DDD0
	public void #=zWmxuWiOCG1UewkLi32up7nU=(bool #=z$Ib9gYQ=)
	{
		this.#=zkeNvlzcHCe38TpetOm7Py2R6MSsX = #=z$Ib9gYQ=;
	}

	// Token: 0x060009B1 RID: 2481 RVA: 0x0004FBDC File Offset: 0x0004DDDC
	public List<string> #=zqA0_oagr6Vv2qNqwEkcOpe4=()
	{
		return this.#=zC07FRHCV$v2rY9M73C9t4Tk2q$m2;
	}

	// Token: 0x060009B2 RID: 2482 RVA: 0x0004FBE4 File Offset: 0x0004DDE4
	public void #=zfN8EDW6sRPbqlWPbGmcSZZg=(List<string> #=z$Ib9gYQ=)
	{
		this.#=zC07FRHCV$v2rY9M73C9t4Tk2q$m2 = #=z$Ib9gYQ=;
	}

	// Token: 0x060009B3 RID: 2483 RVA: 0x0004FBF0 File Offset: 0x0004DDF0
	public string #=zFNvWMWV7X1qBJxRWn2TCmJ8=()
	{
		return this.#=zMl4G0BMIUeg5xHXAtwlQFiT8I5hxTTi5sQ==;
	}

	// Token: 0x060009B4 RID: 2484 RVA: 0x0004FBF8 File Offset: 0x0004DDF8
	public void #=zGe3AVOgg_sTuGQJpVBtdy_4=(string #=z$Ib9gYQ=)
	{
		this.#=zMl4G0BMIUeg5xHXAtwlQFiT8I5hxTTi5sQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009B5 RID: 2485 RVA: 0x0004FC04 File Offset: 0x0004DE04
	public bool #=zJCnhg5aiYC1jYmN42A==()
	{
		return this.#=zis_y8zI4SNa53xCOOHdqBhYnM_Gr;
	}

	// Token: 0x060009B6 RID: 2486 RVA: 0x0004FC0C File Offset: 0x0004DE0C
	public void #=z5_EIUs_W$GlUKgUecw==(bool #=z$Ib9gYQ=)
	{
		this.#=zis_y8zI4SNa53xCOOHdqBhYnM_Gr = #=z$Ib9gYQ=;
	}

	// Token: 0x060009B7 RID: 2487 RVA: 0x0004FC18 File Offset: 0x0004DE18
	public string #=z5PSRkzC6teVxYkOPokgNWCM=()
	{
		return this.#=z89HcgohtOq5c5O_UEkpKuBZNOoY7;
	}

	// Token: 0x060009B8 RID: 2488 RVA: 0x0004FC20 File Offset: 0x0004DE20
	public void #=zHL2ODY6M9f6oMD4ba$$8Kn8=(string #=z$Ib9gYQ=)
	{
		this.#=z89HcgohtOq5c5O_UEkpKuBZNOoY7 = #=z$Ib9gYQ=;
	}

	// Token: 0x060009B9 RID: 2489 RVA: 0x0004FC2C File Offset: 0x0004DE2C
	public double #=zBv8Fq3XNR01xFJNdQB6DJ8bti$IXOGJyNQ==()
	{
		return this.#=zME_Ej44u3_$JZMM8HqVmNdxyvmcqWnv3IMx8Q9k=;
	}

	// Token: 0x060009BA RID: 2490 RVA: 0x0004FC34 File Offset: 0x0004DE34
	public void #=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==(double #=z$Ib9gYQ=)
	{
		this.#=zME_Ej44u3_$JZMM8HqVmNdxyvmcqWnv3IMx8Q9k= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009BB RID: 2491 RVA: 0x0004FC40 File Offset: 0x0004DE40
	public #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k= #=zNiPb5cUCKc8ts45ARg==()
	{
		return this.#=zbZMdB4NQ$7qMkih5g2D5a60j7MbP;
	}

	// Token: 0x060009BC RID: 2492 RVA: 0x0004FC48 File Offset: 0x0004DE48
	public void #=zrYWRQUVedQLe1UPFog==(#=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k= #=z$Ib9gYQ=)
	{
		this.#=zbZMdB4NQ$7qMkih5g2D5a60j7MbP = #=z$Ib9gYQ=;
	}

	// Token: 0x060009BD RID: 2493 RVA: 0x0004FC54 File Offset: 0x0004DE54
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108004),
				(this.#=zXMCL4WkJhi0RMg21OR12cVE=() > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
				JSONManager.ListToArr(this.#=zqA0_oagr6Vv2qNqwEkcOpe4=())
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927226),
				this.#=zFNvWMWV7X1qBJxRWn2TCmJ8=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927216),
				(this.#=zJCnhg5aiYC1jYmN42A==() > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927209),
				this.#=z5PSRkzC6teVxYkOPokgNWCM=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065743),
				this.#=zBv8Fq3XNR01xFJNdQB6DJ8bti$IXOGJyNQ==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927207),
				this.#=zNiPb5cUCKc8ts45ARg==().#=zhv7OhlM=()
			}
		};
	}

	// Token: 0x060009BE RID: 2494 RVA: 0x0004FD20 File Offset: 0x0004DF20
	public static #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw= #=zi1hFJwI=(int #=zLeeSKrg=)
	{
		#=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zORZWLqrH$ZFy5cmRJncJGtg=();
		if (#=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= != null)
		{
			return #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04=[#=zLeeSKrg=];
		}
		return null;
	}

	// Token: 0x04000599 RID: 1433
	private bool #=zkeNvlzcHCe38TpetOm7Py2R6MSsX;

	// Token: 0x0400059A RID: 1434
	private List<string> #=zC07FRHCV$v2rY9M73C9t4Tk2q$m2;

	// Token: 0x0400059B RID: 1435
	private string #=zMl4G0BMIUeg5xHXAtwlQFiT8I5hxTTi5sQ==;

	// Token: 0x0400059C RID: 1436
	private bool #=zis_y8zI4SNa53xCOOHdqBhYnM_Gr;

	// Token: 0x0400059D RID: 1437
	private string #=z89HcgohtOq5c5O_UEkpKuBZNOoY7;

	// Token: 0x0400059E RID: 1438
	private double #=zME_Ej44u3_$JZMM8HqVmNdxyvmcqWnv3IMx8Q9k=;

	// Token: 0x0400059F RID: 1439
	private #=zYF802cjLzqxcspnkodIhhODFIKhlF0aRy2JFdO_ahyBw6Up07IOTfZB4vry5t5FucKCeU8k= #=zbZMdB4NQ$7qMkih5g2D5a60j7MbP;
}
