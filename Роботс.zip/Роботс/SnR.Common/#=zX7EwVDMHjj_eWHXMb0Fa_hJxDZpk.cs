﻿using System;
using System.Text;

// Token: 0x020001D0 RID: 464
internal sealed class #=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000E05 RID: 3589 RVA: 0x00070BF4 File Offset: 0x0006EDF4
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		return new sbyte[]
		{
			#=zwUe4tm5XLL76xe$ToMjBTwE=.#=zfHGMuN402kM5.#=zd$BbM3Y=()
		};
	}

	// Token: 0x06000E06 RID: 3590 RVA: 0x00070C0C File Offset: 0x0006EE0C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		return 0;
	}

	// Token: 0x06000E07 RID: 3591 RVA: 0x00070C10 File Offset: 0x0006EE10
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
	}
}
