﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Units;

// Token: 0x02000056 RID: 86
internal sealed class #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==
{
	// Token: 0x0600028F RID: 655 RVA: 0x00016768 File Offset: 0x00014968
	public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==(object #=zk656SlQ=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zCTWkrJEAvBD7)
	{
		this.#=z38KKbU8=(#=zk656SlQ=);
		this.#=zD9CpW2A4Chaf = #=zCTWkrJEAvBD7;
		this.#=z0th9G3TTrmFP(null);
		this.#=zP4oM5G$XLlhDYD0crBVk690=(null);
	}

	// Token: 0x06000290 RID: 656 RVA: 0x0001678C File Offset: 0x0001498C
	public int #=z$lI_VTM=()
	{
		return this.#=z__DXavI$Z0nzP36F4g==;
	}

	// Token: 0x06000291 RID: 657 RVA: 0x00016794 File Offset: 0x00014994
	public void #=zSXBstP4=(int #=z$Ib9gYQ=)
	{
		this.#=z__DXavI$Z0nzP36F4g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000292 RID: 658 RVA: 0x000167A0 File Offset: 0x000149A0
	public int #=zVVorJLug3m2L()
	{
		return this.#=zfA6$cc8wPlWau8OwIw==;
	}

	// Token: 0x06000293 RID: 659 RVA: 0x000167A8 File Offset: 0x000149A8
	public void #=zM5z33liKcNKa(int #=z$Ib9gYQ=)
	{
		this.#=zfA6$cc8wPlWau8OwIw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000294 RID: 660 RVA: 0x000167B4 File Offset: 0x000149B4
	public int #=zK5gF1KeGk_H_()
	{
		return this.#=z$PjuEd9p6uF7ftQ3QA==;
	}

	// Token: 0x06000295 RID: 661 RVA: 0x000167BC File Offset: 0x000149BC
	public void #=zWIeOkE0$UPjN(int #=z$Ib9gYQ=)
	{
		this.#=z$PjuEd9p6uF7ftQ3QA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000296 RID: 662 RVA: 0x000167C8 File Offset: 0x000149C8
	public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zzasQXAPWhOif()
	{
		return this.#=zkanVdU4qSKZQX0s_fw==;
	}

	// Token: 0x06000297 RID: 663 RVA: 0x000167D0 File Offset: 0x000149D0
	public void #=z3y$Jd2Y9Ey5E(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=z$Ib9gYQ=)
	{
		this.#=zkanVdU4qSKZQX0s_fw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000298 RID: 664 RVA: 0x000167DC File Offset: 0x000149DC
	public UnitSquadCollection #=zDy8wm$yKq8XD()
	{
		return this.#=zH68$xslqIYbV8rfxLg==;
	}

	// Token: 0x06000299 RID: 665 RVA: 0x000167E4 File Offset: 0x000149E4
	public void #=zLNM6_FpNs$Ws(UnitSquadCollection #=z$Ib9gYQ=)
	{
		this.#=zH68$xslqIYbV8rfxLg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600029A RID: 666 RVA: 0x000167F0 File Offset: 0x000149F0
	public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx #=z8waQMcfHThTd()
	{
		return this.#=z5jpUkj31htj6CscYAw==;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x000167F8 File Offset: 0x000149F8
	public void #=zgnto1O9DaXEn(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx #=z$Ib9gYQ=)
	{
		this.#=z5jpUkj31htj6CscYAw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x00016804 File Offset: 0x00014A04
	public DateTime #=z$lxfpxFY0_uNuyAfuiAkDv4=()
	{
		return this.#=ztt_n5A$W7l_bmIGd26swcwZKWAEV;
	}

	// Token: 0x0600029D RID: 669 RVA: 0x0001680C File Offset: 0x00014A0C
	public void #=zW0BrC5xly8C6DW_5$sNAqBc=(DateTime #=z$Ib9gYQ=)
	{
		this.#=ztt_n5A$W7l_bmIGd26swcwZKWAEV = #=z$Ib9gYQ=;
	}

	// Token: 0x0600029E RID: 670 RVA: 0x00016818 File Offset: 0x00014A18
	public DateTime #=zL4D9WC8RTH921DofgQ==()
	{
		return this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;
	}

	// Token: 0x0600029F RID: 671 RVA: 0x00016820 File Offset: 0x00014A20
	public void #=zLkO3VEKrN2mHIZiieQ==(DateTime #=z$Ib9gYQ=)
	{
		this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD = #=z$Ib9gYQ=;
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x0001682C File Offset: 0x00014A2C
	public List<int> #=zjWdm34YCajRT()
	{
		return this.#=zMET$EHRJjkLKikIsc8DpRDs=;
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x00016834 File Offset: 0x00014A34
	public void #=z0th9G3TTrmFP(List<int> #=z$Ib9gYQ=)
	{
		this.#=zMET$EHRJjkLKikIsc8DpRDs= = #=z$Ib9gYQ=;
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x00016840 File Offset: 0x00014A40
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z70nxNNOsj8r_VDWUf_jWQh8=()
	{
		return this.#=zjcYl4HNRjP2aQyRjQmwiF$LJTAcN;
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x00016848 File Offset: 0x00014A48
	public void #=zP4oM5G$XLlhDYD0crBVk690=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z$Ib9gYQ=)
	{
		this.#=zjcYl4HNRjP2aQyRjQmwiF$LJTAcN = #=z$Ib9gYQ=;
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x00016854 File Offset: 0x00014A54
	public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zM_$fq$IfjkuY()
	{
		if (this.#=zA35nK5WqmJsZ == null)
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zD9CpW2A4Chaf);
			this.#=zA35nK5WqmJsZ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(this.#=zD9CpW2A4Chaf.#=zQ4wZnctPyyRO(), this.#=zVVorJLug3m2L().ToString(), false, #=zSJY$s3o=);
		}
		return this.#=zA35nK5WqmJsZ;
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x000168A4 File Offset: 0x00014AA4
	public #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zuFPZLKs=()
	{
		if (this.#=zt7KvG0k= == null)
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zD9CpW2A4Chaf);
			this.#=zt7KvG0k= = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zUCIeSv7ynlYy(this.#=zD9CpW2A4Chaf.#=zQ4wZnctPyyRO(), this.#=zK5gF1KeGk_H_(), false, #=zSJY$s3o=);
		}
		return this.#=zt7KvG0k=;
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x000168EC File Offset: 0x00014AEC
	public object #=z4l00L2Q=()
	{
		return this.#=zgStvS3YVjliiw1Wwjg==;
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x000168F4 File Offset: 0x00014AF4
	public void #=z38KKbU8=(object #=z$Ib9gYQ=)
	{
		this.#=zgStvS3YVjliiw1Wwjg== = #=z$Ib9gYQ=;
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x00016900 File Offset: 0x00014B00
	public static void #=zXmgq7Yr_4ykr(List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zZ5kJVzhNAUVG)
	{
		if (#=zZ5kJVzhNAUVG.Count > 0)
		{
			List<int> list = new List<int>();
			for (int i = 0; i < #=zZ5kJVzhNAUVG.Count; i++)
			{
				#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=zZ5kJVzhNAUVG[i];
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zt7KvG0k= == null)
				{
					list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_());
				}
			}
			#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zZ5kJVzhNAUVG[0].#=zD9CpW2A4Chaf);
			Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> dictionary = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zH9Mroh$wsz82(#=zZ5kJVzhNAUVG[0].#=zD9CpW2A4Chaf.#=zQ4wZnctPyyRO(), list, false, #=zSJY$s3o=);
			for (int j = 0; j < #=zZ5kJVzhNAUVG.Count; j++)
			{
				#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 = #=zZ5kJVzhNAUVG[j];
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zt7KvG0k= == null)
				{
					#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zt7KvG0k= = dictionary[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_()];
				}
			}
		}
	}

	// Token: 0x040000CB RID: 203
	private int #=z__DXavI$Z0nzP36F4g==;

	// Token: 0x040000CC RID: 204
	private int #=zfA6$cc8wPlWau8OwIw==;

	// Token: 0x040000CD RID: 205
	private int #=z$PjuEd9p6uF7ftQ3QA==;

	// Token: 0x040000CE RID: 206
	private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zkanVdU4qSKZQX0s_fw==;

	// Token: 0x040000CF RID: 207
	private UnitSquadCollection #=zH68$xslqIYbV8rfxLg==;

	// Token: 0x040000D0 RID: 208
	private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx #=z5jpUkj31htj6CscYAw==;

	// Token: 0x040000D1 RID: 209
	private DateTime #=ztt_n5A$W7l_bmIGd26swcwZKWAEV;

	// Token: 0x040000D2 RID: 210
	private DateTime #=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;

	// Token: 0x040000D3 RID: 211
	private List<int> #=zMET$EHRJjkLKikIsc8DpRDs=;

	// Token: 0x040000D4 RID: 212
	private #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zjcYl4HNRjP2aQyRjQmwiF$LJTAcN;

	// Token: 0x040000D5 RID: 213
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zA35nK5WqmJsZ;

	// Token: 0x040000D6 RID: 214
	private #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zt7KvG0k=;

	// Token: 0x040000D7 RID: 215
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zD9CpW2A4Chaf;

	// Token: 0x040000D8 RID: 216
	private object #=zgStvS3YVjliiw1Wwjg==;

	// Token: 0x02000057 RID: 87
	public enum #=z58gkp7O0WOEx
	{

	}

	// Token: 0x02000058 RID: 88
	public enum #=zjSSQZRrQ8d_l
	{

	}
}
