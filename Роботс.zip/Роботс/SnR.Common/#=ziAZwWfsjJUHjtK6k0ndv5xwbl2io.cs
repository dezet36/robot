﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200025A RID: 602
internal sealed class #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io : RecordData
{
	// Token: 0x0600124B RID: 4683 RVA: 0x0008FE64 File Offset: 0x0008E064
	public #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		int length = this.getRecord().Length;
		this.#=zg9A8_dw= = IntegerHelper.getInt(data[0], data[1]);
		this.#=zN18H2DjHsrkb = IntegerHelper.getInt(data[2], data[3]);
		this.#=zFbfpcug5CC78 = IntegerHelper.getInt(data[length - 2], data[length - 1]);
		this.#=zK_hSj1p_exHP = this.#=zFbfpcug5CC78 - this.#=zN18H2DjHsrkb + 1;
		this.#=zIFmpvLQ9TmjXhYENKw== = new int[this.#=zK_hSj1p_exHP];
		this.#=z890y8dLqEnm$ = new int[this.#=zK_hSj1p_exHP];
		this.#=zkRlI42sZnS0e(data);
	}

	// Token: 0x0600124C RID: 4684 RVA: 0x0008FF08 File Offset: 0x0008E108
	public int #=zNMAKc1U=()
	{
		return this.#=zg9A8_dw=;
	}

	// Token: 0x0600124D RID: 4685 RVA: 0x0008FF10 File Offset: 0x0008E110
	public int #=zas6WF9Y7vCuz()
	{
		return this.#=zN18H2DjHsrkb;
	}

	// Token: 0x0600124E RID: 4686 RVA: 0x0008FF18 File Offset: 0x0008E118
	public int #=zhUfM2IzcS5zU()
	{
		return this.#=zK_hSj1p_exHP;
	}

	// Token: 0x0600124F RID: 4687 RVA: 0x0008FF20 File Offset: 0x0008E120
	private void #=zkRlI42sZnS0e(sbyte[] #=zJ5GWysk=)
	{
		int num = 4;
		for (int i = 0; i < this.#=zK_hSj1p_exHP; i++)
		{
			this.#=z890y8dLqEnm$[i] = IntegerHelper.getInt(#=zJ5GWysk=[num], #=zJ5GWysk=[num + 1]);
			int @int = IntegerHelper.getInt(#=zJ5GWysk=[num + 2], #=zJ5GWysk=[num + 3], #=zJ5GWysk=[num + 4], #=zJ5GWysk=[num + 5]);
			this.#=zIFmpvLQ9TmjXhYENKw==[i] = @int;
			num += 6;
		}
	}

	// Token: 0x06001250 RID: 4688 RVA: 0x0008FF7C File Offset: 0x0008E17C
	public int #=zzAx9picknfF$(int #=zSPLDPE4=)
	{
		return this.#=zIFmpvLQ9TmjXhYENKw==[#=zSPLDPE4=];
	}

	// Token: 0x06001251 RID: 4689 RVA: 0x0008FF88 File Offset: 0x0008E188
	public int #=zJVc2l$oPfOau(int #=zSPLDPE4=)
	{
		return this.#=z890y8dLqEnm$[#=zSPLDPE4=];
	}

	// Token: 0x04000A8F RID: 2703
	private int #=zg9A8_dw=;

	// Token: 0x04000A90 RID: 2704
	private int #=zN18H2DjHsrkb;

	// Token: 0x04000A91 RID: 2705
	private int #=zFbfpcug5CC78;

	// Token: 0x04000A92 RID: 2706
	private int #=zK_hSj1p_exHP;

	// Token: 0x04000A93 RID: 2707
	private int[] #=zIFmpvLQ9TmjXhYENKw==;

	// Token: 0x04000A94 RID: 2708
	private int[] #=z890y8dLqEnm$;
}
