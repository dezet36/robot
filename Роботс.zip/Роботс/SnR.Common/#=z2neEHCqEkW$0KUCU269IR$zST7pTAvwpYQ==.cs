﻿using System;

// Token: 0x0200004A RID: 74
internal sealed class #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==
{
	// Token: 0x06000240 RID: 576 RVA: 0x00015798 File Offset: 0x00013998
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000241 RID: 577 RVA: 0x000157A0 File Offset: 0x000139A0
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000242 RID: 578 RVA: 0x000157AC File Offset: 0x000139AC
	public DateTime #=z71_rggORFKZ5()
	{
		return this.#=zC8DPTZQ8732QOSYJUw==;
	}

	// Token: 0x06000243 RID: 579 RVA: 0x000157B4 File Offset: 0x000139B4
	public void #=zWtGpwQAJDMH_(DateTime #=z$Ib9gYQ=)
	{
		this.#=zC8DPTZQ8732QOSYJUw== = #=z$Ib9gYQ=;
	}

	// Token: 0x040000B1 RID: 177
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040000B2 RID: 178
	private DateTime #=zC8DPTZQ8732QOSYJUw==;
}
