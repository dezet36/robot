﻿using System;
using System.Diagnostics;
using System.Threading;

// Token: 0x02000009 RID: 9
internal static class #=qPk4l39wK$oGOW0yMMFUnLDysK5PRD_sH3rL0idDWQ6g=
{
	// Token: 0x0200000A RID: 10
	internal sealed class #=zm8PpuDU= : #=q_j6iJL0eUaGbqSd8hGx54PQjL$61MKS93NuyOv07xBg=<int>, #=qWIG9Q$RaV69Bu2dj8hDRy4SqXcgJ7fq5leQqIjDcou4=, #=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<int>, #=qjU9y2YbXKDX9w$auN09jycq094j3zHKdw8gUC1HOqY4=, #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=
	{
		// Token: 0x06000021 RID: 33 RVA: 0x00002ED0 File Offset: 0x000010D0
		[DebuggerHidden]
		public #=zm8PpuDU=(int #=zm8PpuDU=)
		{
			this.#=zm8PpuDU= = #=zm8PpuDU=;
			this.#=zQUn_5_A= = Thread.CurrentThread.ManagedThreadId;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00002EF0 File Offset: 0x000010F0
		[DebuggerHidden]
		void #=qjU9y2YbXKDX9w$auN09jycq094j3zHKdw8gUC1HOqY4=.#=zfwA2O$DJy7ROFs_Nye93ROOB$QxT()
		{
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002EF4 File Offset: 0x000010F4
		bool #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=.#=z5od3PV4HEEHLXRWOfZO6P1VrIQHbl1oBd8Cp_FowZoG3mzdKBhQQCq7rP3hB8qKv88UWk0MgM_LM()
		{
			switch (this.#=zm8PpuDU=)
			{
			case 0:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = 2131205764;
				this.#=zm8PpuDU= = 1;
				return true;
			case 1:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = (this.#=zdqSpY9Q= ^ -542957767);
				this.#=zm8PpuDU= = 2;
				return true;
			case 2:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = (this.#=zdqSpY9Q= ^ 1762467218);
				this.#=zm8PpuDU= = 3;
				return true;
			case 3:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = -300000115;
				this.#=zm8PpuDU= = 4;
				return true;
			case 4:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = -317073458;
				this.#=zm8PpuDU= = 5;
				return true;
			case 5:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = 1201411035;
				this.#=zm8PpuDU= = 6;
				return true;
			case 6:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = (this.#=zdqSpY9Q= ^ -542957767);
				this.#=zm8PpuDU= = 7;
				return true;
			case 7:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = 1183826435;
				this.#=zm8PpuDU= = 8;
				return true;
			case 8:
				this.#=zm8PpuDU= = -1;
				this.#=zcltuPyw= = (this.#=zdqSpY9Q= ^ -542957767);
				this.#=zm8PpuDU= = 9;
				return true;
			case 9:
				this.#=zm8PpuDU= = -1;
				return false;
			default:
				return false;
			}
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00003050 File Offset: 0x00001250
		[DebuggerHidden]
		int #=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<int>.#=zodUCr1F4Ufx9fx2wi1kJomJuyhzu()
		{
			return this.#=zcltuPyw=;
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00003058 File Offset: 0x00001258
		[DebuggerHidden]
		void #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=.#=zYIBYLblaZDzC20ta1x9WWATv9G7K()
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00003060 File Offset: 0x00001260
		[DebuggerHidden]
		object #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=.#=zHWrBMBndZ8EijqPqaogJrQG$7i02()
		{
			return this.#=zcltuPyw=;
		}

		// Token: 0x06000027 RID: 39 RVA: 0x00003070 File Offset: 0x00001270
		[DebuggerHidden]
		#=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<int> #=q_j6iJL0eUaGbqSd8hGx54PQjL$61MKS93NuyOv07xBg=<int>.#=zQj5vTMp_Quev6G0ZAWstRBB69Rwy2AU4calyZRq_UNWVbGz9jw==()
		{
			#=qPk4l39wK$oGOW0yMMFUnLDysK5PRD_sH3rL0idDWQ6g=.#=zm8PpuDU= #=zm8PpuDU=;
			if (this.#=zm8PpuDU= == -2 && this.#=zQUn_5_A= == Thread.CurrentThread.ManagedThreadId)
			{
				this.#=zm8PpuDU= = 0;
				#=zm8PpuDU= = this;
			}
			else
			{
				#=zm8PpuDU= = new #=qPk4l39wK$oGOW0yMMFUnLDysK5PRD_sH3rL0idDWQ6g=.#=zm8PpuDU=(0);
			}
			#=zm8PpuDU=.#=zdqSpY9Q= = this.#=z4Q$h3mE=;
			return #=zm8PpuDU=;
		}

		// Token: 0x06000028 RID: 40 RVA: 0x000030B8 File Offset: 0x000012B8
		[DebuggerHidden]
		#=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc= #=qWIG9Q$RaV69Bu2dj8hDRy4SqXcgJ7fq5leQqIjDcou4=.#=zH9moBJfCSCU1m4tb8YGgz4tWuMWakgb_Ru6EPP1VmENrE9rocw==()
		{
			return this.#=zQj5vTMp_Quev6G0ZAWstRBB69Rwy2AU4calyZRq_UNWVbGz9jw==();
		}

		// Token: 0x0400000D RID: 13
		private int #=zm8PpuDU=;

		// Token: 0x0400000E RID: 14
		private int #=zcltuPyw=;

		// Token: 0x0400000F RID: 15
		private int #=zQUn_5_A=;

		// Token: 0x04000010 RID: 16
		private int #=zdqSpY9Q=;

		// Token: 0x04000011 RID: 17
		public int #=z4Q$h3mE=;
	}
}
