﻿using System;
using System.Collections.Generic;

// Token: 0x020000CD RID: 205
internal sealed class #=zBlV0sBQdC88uTJgOosW7FZ0cX0Gr : List<#=zkO3OALYBGNilukMF5u7j7K3EsP5C>
{
	// Token: 0x0600057C RID: 1404 RVA: 0x0002E620 File Offset: 0x0002C820
	public #=zBlV0sBQdC88uTJgOosW7FZ0cX0Gr()
	{
		this.#=zavoApLBeoorD(new List<string>());
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x0002E634 File Offset: 0x0002C834
	public List<string> #=zavB3zWrtZYcs()
	{
		return this.#=zLiDMBqfSUjciX803roHyzV8=;
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x0002E63C File Offset: 0x0002C83C
	public void #=zavoApLBeoorD(List<string> #=z$Ib9gYQ=)
	{
		this.#=zLiDMBqfSUjciX803roHyzV8= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x0002E648 File Offset: 0x0002C848
	public void #=z48rEd0A=(#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zsbwXxuA=)
	{
		base.Add(#=zsbwXxuA=);
		if (!this.#=zavB3zWrtZYcs().Contains(#=zsbwXxuA=.#=z5VV8Oo_dYzMg()))
		{
			this.#=zavB3zWrtZYcs().Add(#=zsbwXxuA=.#=z5VV8Oo_dYzMg());
		}
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x0002E678 File Offset: 0x0002C878
	public #=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zyo0_tZ8=(string #=z7sMfGqU=)
	{
		if (!this.#=zavB3zWrtZYcs().Contains(#=z7sMfGqU=))
		{
			return null;
		}
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=z5VV8Oo_dYzMg() == #=z7sMfGqU=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x0400022F RID: 559
	private List<string> #=zLiDMBqfSUjciX803roHyzV8=;
}
