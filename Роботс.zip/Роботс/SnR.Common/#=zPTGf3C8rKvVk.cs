﻿using System;
using System.IO;

// Token: 0x02000181 RID: 385
internal sealed class #=zPTGf3C8rKvVk
{
	// Token: 0x06000AFD RID: 2813 RVA: 0x0005549C File Offset: 0x0005369C
	private #=zPTGf3C8rKvVk()
	{
	}

	// Token: 0x06000AFE RID: 2814 RVA: 0x000554A4 File Offset: 0x000536A4
	public static int #=z4qjVIng=(Stream #=zruNL45AAbYxS, ref sbyte[] #=z40sk5mc=, int #=z1qaC5B0=, int #=z4UDysxM=)
	{
		if (#=z40sk5mc=.Length == 0)
		{
			return 0;
		}
		byte[] array = new byte[#=z40sk5mc=.Length];
		int num = #=zruNL45AAbYxS.Read(array, #=z1qaC5B0=, #=z4UDysxM=);
		if (num == 0)
		{
			return -1;
		}
		for (int i = #=z1qaC5B0=; i < #=z1qaC5B0= + num; i++)
		{
			#=z40sk5mc=[i] = (sbyte)array[i];
		}
		return num;
	}
}
