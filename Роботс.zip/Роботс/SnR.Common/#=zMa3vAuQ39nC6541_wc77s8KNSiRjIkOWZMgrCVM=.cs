﻿using System;

// Token: 0x02000165 RID: 357
internal sealed class #=zMa3vAuQ39nC6541_wc77s8KNSiRjIkOWZMgrCVM=
{
	// Token: 0x06000985 RID: 2437 RVA: 0x0004D388 File Offset: 0x0004B588
	internal #=zMa3vAuQ39nC6541_wc77s8KNSiRjIkOWZMgrCVM=()
	{
	}

	// Token: 0x06000986 RID: 2438 RVA: 0x0004D390 File Offset: 0x0004B590
	internal void #=zC68QI$8=(int #=zjjrbH1U=, int #=zR4jxYlQ=, int[] #=z10LKVyw=, int #=zQL4OzCbogQn8, int[] #=zh6jV8AI=, int #=z5$wu5TvaMwyB)
	{
		this.#=zZ6hesjQ= = 0;
		this.#=zyPUVKPEsao42 = (byte)#=zjjrbH1U=;
		this.#=zyy8_2Zp7GPZE = (byte)#=zR4jxYlQ=;
		this.#=zn7WZLHmxufVR = #=z10LKVyw=;
		this.#=zQ9jTEnPbzLnR = #=zQL4OzCbogQn8;
		this.#=zQ5O21TQ= = #=zh6jV8AI=;
		this.#=zbo6_JmaE38VT = #=z5$wu5TvaMwyB;
		this.#=zZUWDhT4= = null;
	}

	// Token: 0x06000987 RID: 2439 RVA: 0x0004D3D0 File Offset: 0x0004B5D0
	internal int #=zvb5bnug=(#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI= #=zmI$ftM4=, int #=zihyUFzs=)
	{
		#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zcXgLydccbe5C = #=zmI$ftM4=.#=zcXgLydccbe5C;
		int num = #=zcXgLydccbe5C.#=z_f$vhX8=;
		int num2 = #=zcXgLydccbe5C.#=zEVNP$$evg7c3;
		int num3 = #=zmI$ftM4=.#=zEnIyXR3jdBvO;
		int i = #=zmI$ftM4=.#=zkLxzZ_J6u52Z;
		int num4 = #=zmI$ftM4=.#=z1jZkw8iLmhH0;
		int num5 = (num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4);
		for (;;)
		{
			int num6;
			switch (this.#=zZ6hesjQ=)
			{
			case 0:
				if (num5 >= 258 && num2 >= 10)
				{
					#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
					#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
					#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
					#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
					#=zcXgLydccbe5C.#=z_f$vhX8= = num;
					#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
					#=zihyUFzs= = this.#=zJWQtJdACOqlVkrPgvw==((int)this.#=zyPUVKPEsao42, (int)this.#=zyy8_2Zp7GPZE, this.#=zn7WZLHmxufVR, this.#=zQ9jTEnPbzLnR, this.#=zQ5O21TQ=, this.#=zbo6_JmaE38VT, #=zmI$ftM4=, #=zcXgLydccbe5C);
					num = #=zcXgLydccbe5C.#=z_f$vhX8=;
					num2 = #=zcXgLydccbe5C.#=zEVNP$$evg7c3;
					num3 = #=zmI$ftM4=.#=zEnIyXR3jdBvO;
					i = #=zmI$ftM4=.#=zkLxzZ_J6u52Z;
					num4 = #=zmI$ftM4=.#=z1jZkw8iLmhH0;
					num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
					if (#=zihyUFzs= != 0)
					{
						this.#=zZ6hesjQ= = ((#=zihyUFzs= == 1) ? 7 : 9);
						continue;
					}
				}
				this.#=zJKq2F54= = (int)this.#=zyPUVKPEsao42;
				this.#=zZUWDhT4= = this.#=zn7WZLHmxufVR;
				this.#=z5WqrmjZD2_Ji = this.#=zQ9jTEnPbzLnR;
				this.#=zZ6hesjQ= = 1;
				goto IL_192;
			case 1:
				goto IL_192;
			case 2:
				num6 = this.#=z919vRBvEvIlT;
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_354;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				this.#=zZBlusgI= += (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6]);
				num3 >>= num6;
				i -= num6;
				this.#=zJKq2F54= = (int)this.#=zyy8_2Zp7GPZE;
				this.#=zZUWDhT4= = this.#=zQ5O21TQ=;
				this.#=z5WqrmjZD2_Ji = this.#=zbo6_JmaE38VT;
				this.#=zZ6hesjQ= = 3;
				goto IL_414;
			case 3:
				goto IL_414;
			case 4:
				num6 = this.#=z919vRBvEvIlT;
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_5A2;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				this.#=z0id6pM2wr9jd += (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6]);
				num3 >>= num6;
				i -= num6;
				this.#=zZ6hesjQ= = 5;
				goto IL_63E;
			case 5:
				goto IL_63E;
			case 6:
				if (num5 == 0)
				{
					if (num4 == #=zmI$ftM4=.#=zf$NwTlE= && #=zmI$ftM4=.#=zWZqaeqGJDTn2 != 0)
					{
						num4 = 0;
						num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
					}
					if (num5 == 0)
					{
						#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
						#=zihyUFzs= = #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
						num4 = #=zmI$ftM4=.#=z1jZkw8iLmhH0;
						num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
						if (num4 == #=zmI$ftM4=.#=zf$NwTlE= && #=zmI$ftM4=.#=zWZqaeqGJDTn2 != 0)
						{
							num4 = 0;
							num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
						}
						if (num5 == 0)
						{
							goto Block_44;
						}
					}
				}
				#=zihyUFzs= = 0;
				#=zmI$ftM4=.#=zgcFyF1E=[num4++] = (byte)this.#=zStMp9sM=;
				num5--;
				this.#=zZ6hesjQ= = 0;
				continue;
			case 7:
				goto IL_8B7;
			case 8:
				goto IL_957;
			case 9:
				goto IL_99D;
			}
			break;
			IL_192:
			num6 = this.#=zJKq2F54=;
			while (i < num6)
			{
				if (num2 == 0)
				{
					goto IL_1A5;
				}
				#=zihyUFzs= = 0;
				num2--;
				num3 |= (int)(#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
				i += 8;
			}
			int num7 = (this.#=z5WqrmjZD2_Ji + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6])) * 3;
			num3 >>= this.#=zZUWDhT4=[num7 + 1];
			i -= this.#=zZUWDhT4=[num7 + 1];
			int num8 = this.#=zZUWDhT4=[num7];
			if (num8 == 0)
			{
				this.#=zStMp9sM= = this.#=zZUWDhT4=[num7 + 2];
				this.#=zZ6hesjQ= = 6;
				continue;
			}
			if ((num8 & 16) != 0)
			{
				this.#=z919vRBvEvIlT = (num8 & 15);
				this.#=zZBlusgI= = this.#=zZUWDhT4=[num7 + 2];
				this.#=zZ6hesjQ= = 2;
				continue;
			}
			if ((num8 & 64) == 0)
			{
				this.#=zJKq2F54= = num8;
				this.#=z5WqrmjZD2_Ji = num7 / 3 + this.#=zZUWDhT4=[num7 + 2];
				continue;
			}
			if ((num8 & 32) != 0)
			{
				this.#=zZ6hesjQ= = 7;
				continue;
			}
			goto IL_2E2;
			IL_414:
			num6 = this.#=zJKq2F54=;
			while (i < num6)
			{
				if (num2 == 0)
				{
					goto IL_427;
				}
				#=zihyUFzs= = 0;
				num2--;
				num3 |= (int)(#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
				i += 8;
			}
			num7 = (this.#=z5WqrmjZD2_Ji + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6])) * 3;
			num3 >>= this.#=zZUWDhT4=[num7 + 1];
			i -= this.#=zZUWDhT4=[num7 + 1];
			num8 = this.#=zZUWDhT4=[num7];
			if ((num8 & 16) != 0)
			{
				this.#=z919vRBvEvIlT = (num8 & 15);
				this.#=z0id6pM2wr9jd = this.#=zZUWDhT4=[num7 + 2];
				this.#=zZ6hesjQ= = 4;
				continue;
			}
			if ((num8 & 64) == 0)
			{
				this.#=zJKq2F54= = num8;
				this.#=z5WqrmjZD2_Ji = num7 / 3 + this.#=zZUWDhT4=[num7 + 2];
				continue;
			}
			goto IL_530;
			IL_63E:
			int j;
			for (j = num4 - this.#=z0id6pM2wr9jd; j < 0; j += #=zmI$ftM4=.#=zf$NwTlE=)
			{
			}
			while (this.#=zZBlusgI= != 0)
			{
				if (num5 == 0)
				{
					if (num4 == #=zmI$ftM4=.#=zf$NwTlE= && #=zmI$ftM4=.#=zWZqaeqGJDTn2 != 0)
					{
						num4 = 0;
						num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
					}
					if (num5 == 0)
					{
						#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
						#=zihyUFzs= = #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
						num4 = #=zmI$ftM4=.#=z1jZkw8iLmhH0;
						num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
						if (num4 == #=zmI$ftM4=.#=zf$NwTlE= && #=zmI$ftM4=.#=zWZqaeqGJDTn2 != 0)
						{
							num4 = 0;
							num5 = ((num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4));
						}
						if (num5 == 0)
						{
							goto Block_32;
						}
					}
				}
				#=zmI$ftM4=.#=zgcFyF1E=[num4++] = #=zmI$ftM4=.#=zgcFyF1E=[j++];
				num5--;
				if (j == #=zmI$ftM4=.#=zf$NwTlE=)
				{
					j = 0;
				}
				this.#=zZBlusgI=--;
			}
			this.#=zZ6hesjQ= = 0;
		}
		#=zihyUFzs= = -2;
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_1A5:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_2E2:
		this.#=zZ6hesjQ= = 9;
		#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064067);
		#=zihyUFzs= = -3;
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_354:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_427:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_530:
		this.#=zZ6hesjQ= = 9;
		#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063777);
		#=zihyUFzs= = -3;
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_5A2:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		Block_32:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		Block_44:
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_8B7:
		if (i > 7)
		{
			i -= 8;
			num2++;
			num--;
		}
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		#=zihyUFzs= = #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		num4 = #=zmI$ftM4=.#=z1jZkw8iLmhH0;
		int num9 = (num4 < #=zmI$ftM4=.#=zWZqaeqGJDTn2) ? (#=zmI$ftM4=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zmI$ftM4=.#=zf$NwTlE= - num4);
		if (#=zmI$ftM4=.#=zWZqaeqGJDTn2 != #=zmI$ftM4=.#=z1jZkw8iLmhH0)
		{
			#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
			#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
			#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
			#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
			#=zcXgLydccbe5C.#=z_f$vhX8= = num;
			#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
			return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		}
		this.#=zZ6hesjQ= = 8;
		IL_957:
		#=zihyUFzs= = 1;
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
		IL_99D:
		#=zihyUFzs= = -3;
		#=zmI$ftM4=.#=zEnIyXR3jdBvO = num3;
		#=zmI$ftM4=.#=zkLxzZ_J6u52Z = i;
		#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - #=zcXgLydccbe5C.#=z_f$vhX8=);
		#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		#=zmI$ftM4=.#=z1jZkw8iLmhH0 = num4;
		return #=zmI$ftM4=.#=z3N5BEfw=(#=zihyUFzs=);
	}

	// Token: 0x06000988 RID: 2440 RVA: 0x0004DE08 File Offset: 0x0004C008
	internal int #=zJWQtJdACOqlVkrPgvw==(int #=zjjrbH1U=, int #=zR4jxYlQ=, int[] #=z10LKVyw=, int #=zQL4OzCbogQn8, int[] #=zh6jV8AI=, int #=z5$wu5TvaMwyB, #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI= #=zWj7xLq8=, #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zDNCCbqs=)
	{
		int num = #=zDNCCbqs=.#=z_f$vhX8=;
		int num2 = #=zDNCCbqs=.#=zEVNP$$evg7c3;
		int num3 = #=zWj7xLq8=.#=zEnIyXR3jdBvO;
		int i = #=zWj7xLq8=.#=zkLxzZ_J6u52Z;
		int num4 = #=zWj7xLq8=.#=z1jZkw8iLmhH0;
		int num5 = (num4 < #=zWj7xLq8=.#=zWZqaeqGJDTn2) ? (#=zWj7xLq8=.#=zWZqaeqGJDTn2 - num4 - 1) : (#=zWj7xLq8=.#=zf$NwTlE= - num4);
		int num6 = #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[#=zjjrbH1U=];
		int num7 = #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[#=zR4jxYlQ=];
		int num10;
		int num11;
		for (;;)
		{
			if (i >= 20)
			{
				int num8 = num3 & num6;
				int num9 = (#=zQL4OzCbogQn8 + num8) * 3;
				if ((num10 = #=z10LKVyw=[num9]) == 0)
				{
					num3 >>= #=z10LKVyw=[num9 + 1];
					i -= #=z10LKVyw=[num9 + 1];
					#=zWj7xLq8=.#=zgcFyF1E=[num4++] = (byte)#=z10LKVyw=[num9 + 2];
					num5--;
				}
				else
				{
					for (;;)
					{
						num3 >>= #=z10LKVyw=[num9 + 1];
						i -= #=z10LKVyw=[num9 + 1];
						if ((num10 & 16) != 0)
						{
							break;
						}
						if ((num10 & 64) != 0)
						{
							goto IL_485;
						}
						num8 += #=z10LKVyw=[num9 + 2];
						num8 += (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num10]);
						num9 = (#=zQL4OzCbogQn8 + num8) * 3;
						if ((num10 = #=z10LKVyw=[num9]) == 0)
						{
							goto Block_20;
						}
					}
					num10 &= 15;
					num11 = #=z10LKVyw=[num9 + 2] + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num10]);
					num3 >>= num10;
					for (i -= num10; i < 15; i += 8)
					{
						num2--;
						num3 |= (int)(#=zDNCCbqs=.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					}
					num8 = (num3 & num7);
					num9 = (#=z5$wu5TvaMwyB + num8) * 3;
					num10 = #=zh6jV8AI=[num9];
					for (;;)
					{
						num3 >>= #=zh6jV8AI=[num9 + 1];
						i -= #=zh6jV8AI=[num9 + 1];
						if ((num10 & 16) != 0)
						{
							break;
						}
						if ((num10 & 64) != 0)
						{
							goto IL_394;
						}
						num8 += #=zh6jV8AI=[num9 + 2];
						num8 += (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num10]);
						num9 = (#=z5$wu5TvaMwyB + num8) * 3;
						num10 = #=zh6jV8AI=[num9];
					}
					num10 &= 15;
					while (i < num10)
					{
						num2--;
						num3 |= (int)(#=zDNCCbqs=.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
						i += 8;
					}
					int num12 = #=zh6jV8AI=[num9 + 2] + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num10]);
					num3 >>= num10;
					i -= num10;
					num5 -= num11;
					int num13;
					if (num4 >= num12)
					{
						num13 = num4 - num12;
						if (num4 - num13 > 0 && 2 > num4 - num13)
						{
							#=zWj7xLq8=.#=zgcFyF1E=[num4++] = #=zWj7xLq8=.#=zgcFyF1E=[num13++];
							#=zWj7xLq8=.#=zgcFyF1E=[num4++] = #=zWj7xLq8=.#=zgcFyF1E=[num13++];
							num11 -= 2;
						}
						else
						{
							Array.Copy(#=zWj7xLq8=.#=zgcFyF1E=, num13, #=zWj7xLq8=.#=zgcFyF1E=, num4, 2);
							num4 += 2;
							num13 += 2;
							num11 -= 2;
						}
					}
					else
					{
						num13 = num4 - num12;
						do
						{
							num13 += #=zWj7xLq8=.#=zf$NwTlE=;
						}
						while (num13 < 0);
						num10 = #=zWj7xLq8=.#=zf$NwTlE= - num13;
						if (num11 > num10)
						{
							num11 -= num10;
							if (num4 - num13 > 0 && num10 > num4 - num13)
							{
								do
								{
									#=zWj7xLq8=.#=zgcFyF1E=[num4++] = #=zWj7xLq8=.#=zgcFyF1E=[num13++];
								}
								while (--num10 != 0);
							}
							else
							{
								Array.Copy(#=zWj7xLq8=.#=zgcFyF1E=, num13, #=zWj7xLq8=.#=zgcFyF1E=, num4, num10);
								num4 += num10;
								num13 += num10;
							}
							num13 = 0;
						}
					}
					if (num4 - num13 > 0 && num11 > num4 - num13)
					{
						do
						{
							#=zWj7xLq8=.#=zgcFyF1E=[num4++] = #=zWj7xLq8=.#=zgcFyF1E=[num13++];
						}
						while (--num11 != 0);
						goto IL_57D;
					}
					Array.Copy(#=zWj7xLq8=.#=zgcFyF1E=, num13, #=zWj7xLq8=.#=zgcFyF1E=, num4, num11);
					num4 += num11;
					num13 += num11;
					goto IL_57D;
					Block_20:
					num3 >>= #=z10LKVyw=[num9 + 1];
					i -= #=z10LKVyw=[num9 + 1];
					#=zWj7xLq8=.#=zgcFyF1E=[num4++] = (byte)#=z10LKVyw=[num9 + 2];
					num5--;
				}
				IL_57D:
				if (num5 < 258 || num2 < 10)
				{
					goto IL_58F;
				}
			}
			else
			{
				num2--;
				num3 |= (int)(#=zDNCCbqs=.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
				i += 8;
			}
		}
		IL_394:
		#=zDNCCbqs=.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063777);
		num11 = #=zDNCCbqs=.#=zEVNP$$evg7c3 - num2;
		num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
		num2 += num11;
		num -= num11;
		i -= num11 << 3;
		#=zWj7xLq8=.#=zEnIyXR3jdBvO = num3;
		#=zWj7xLq8=.#=zkLxzZ_J6u52Z = i;
		#=zDNCCbqs=.#=zEVNP$$evg7c3 = num2;
		#=zDNCCbqs=.#=zX85$ivfbdo86 += (long)(num - #=zDNCCbqs=.#=z_f$vhX8=);
		#=zDNCCbqs=.#=z_f$vhX8= = num;
		#=zWj7xLq8=.#=z1jZkw8iLmhH0 = num4;
		return -3;
		IL_485:
		if ((num10 & 32) != 0)
		{
			num11 = #=zDNCCbqs=.#=zEVNP$$evg7c3 - num2;
			num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
			num2 += num11;
			num -= num11;
			i -= num11 << 3;
			#=zWj7xLq8=.#=zEnIyXR3jdBvO = num3;
			#=zWj7xLq8=.#=zkLxzZ_J6u52Z = i;
			#=zDNCCbqs=.#=zEVNP$$evg7c3 = num2;
			#=zDNCCbqs=.#=zX85$ivfbdo86 += (long)(num - #=zDNCCbqs=.#=z_f$vhX8=);
			#=zDNCCbqs=.#=z_f$vhX8= = num;
			#=zWj7xLq8=.#=z1jZkw8iLmhH0 = num4;
			return 1;
		}
		#=zDNCCbqs=.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064067);
		num11 = #=zDNCCbqs=.#=zEVNP$$evg7c3 - num2;
		num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
		num2 += num11;
		num -= num11;
		i -= num11 << 3;
		#=zWj7xLq8=.#=zEnIyXR3jdBvO = num3;
		#=zWj7xLq8=.#=zkLxzZ_J6u52Z = i;
		#=zDNCCbqs=.#=zEVNP$$evg7c3 = num2;
		#=zDNCCbqs=.#=zX85$ivfbdo86 += (long)(num - #=zDNCCbqs=.#=z_f$vhX8=);
		#=zDNCCbqs=.#=z_f$vhX8= = num;
		#=zWj7xLq8=.#=z1jZkw8iLmhH0 = num4;
		return -3;
		IL_58F:
		num11 = #=zDNCCbqs=.#=zEVNP$$evg7c3 - num2;
		num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
		num2 += num11;
		num -= num11;
		i -= num11 << 3;
		#=zWj7xLq8=.#=zEnIyXR3jdBvO = num3;
		#=zWj7xLq8=.#=zkLxzZ_J6u52Z = i;
		#=zDNCCbqs=.#=zEVNP$$evg7c3 = num2;
		#=zDNCCbqs=.#=zX85$ivfbdo86 += (long)(num - #=zDNCCbqs=.#=z_f$vhX8=);
		#=zDNCCbqs=.#=z_f$vhX8= = num;
		#=zWj7xLq8=.#=z1jZkw8iLmhH0 = num4;
		return 0;
	}

	// Token: 0x04000571 RID: 1393
	internal int #=zZ6hesjQ=;

	// Token: 0x04000572 RID: 1394
	internal int #=zZBlusgI=;

	// Token: 0x04000573 RID: 1395
	internal int[] #=zZUWDhT4=;

	// Token: 0x04000574 RID: 1396
	internal int #=z5WqrmjZD2_Ji;

	// Token: 0x04000575 RID: 1397
	internal int #=zJKq2F54=;

	// Token: 0x04000576 RID: 1398
	internal int #=zStMp9sM=;

	// Token: 0x04000577 RID: 1399
	internal int #=z919vRBvEvIlT;

	// Token: 0x04000578 RID: 1400
	internal int #=z0id6pM2wr9jd;

	// Token: 0x04000579 RID: 1401
	internal byte #=zyPUVKPEsao42;

	// Token: 0x0400057A RID: 1402
	internal byte #=zyy8_2Zp7GPZE;

	// Token: 0x0400057B RID: 1403
	internal int[] #=zn7WZLHmxufVR;

	// Token: 0x0400057C RID: 1404
	internal int #=zQ9jTEnPbzLnR;

	// Token: 0x0400057D RID: 1405
	internal int[] #=zQ5O21TQ=;

	// Token: 0x0400057E RID: 1406
	internal int #=zbo6_JmaE38VT;
}
