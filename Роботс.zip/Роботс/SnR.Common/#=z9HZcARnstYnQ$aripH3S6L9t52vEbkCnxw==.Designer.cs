﻿// Token: 0x020000B2 RID: 178
internal sealed partial class #=z9HZcARnstYnQ$aripH3S6L9t52vEbkCnxw== : global::System.Windows.Forms.Form
{
	// Token: 0x060004AF RID: 1199 RVA: 0x0002703C File Offset: 0x0002523C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040001C0 RID: 448
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
