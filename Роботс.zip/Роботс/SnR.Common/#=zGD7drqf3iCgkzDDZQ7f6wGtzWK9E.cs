﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020000FB RID: 251
internal sealed class #=zGD7drqf3iCgkzDDZQ7f6wGtzWK9E : #=zIysmcffbrCbtDK6qpNil6NA=
{
	// Token: 0x06000684 RID: 1668 RVA: 0x00033A0C File Offset: 0x00031C0C
	internal #=zGD7drqf3iCgkzDDZQ7f6wGtzWK9E(Record #=zihyUFzs=) : base(Type.BOTTOMMARGIN, #=zihyUFzs=)
	{
	}
}
