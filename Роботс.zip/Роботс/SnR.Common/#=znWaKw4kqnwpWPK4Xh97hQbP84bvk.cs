﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Format;
using NExcel.Read.Biff;

// Token: 0x02000293 RID: 659
internal sealed class #=znWaKw4kqnwpWPK4Xh97hQbP84bvk : Cell
{
	// Token: 0x06001415 RID: 5141 RVA: 0x00099BD0 File Offset: 0x00097DD0
	public #=znWaKw4kqnwpWPK4Xh97hQbP84bvk(int #=zihyUFzs=, int #=zQUn_5_A=, int #=zPZu1Eq8=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=)
	{
		this.#=zg9A8_dw= = #=zihyUFzs=;
		this.#=zEh1wLVk= = #=zQUn_5_A=;
		this.#=zJqpM8PY= = #=zPZu1Eq8=;
		this.#=zwKQa9tCrbbw$ = #=zrRXQAB8=;
		this.#=zNEZ0SGey$A9J = #=z99eVqbg=;
		this.#=zQqR9G48= = false;
	}

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x06001416 RID: 5142 RVA: 0x00099C04 File Offset: 0x00097E04
	public int Row
	{
		get
		{
			return this.#=zg9A8_dw=;
		}
	}

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x06001417 RID: 5143 RVA: 0x00099C0C File Offset: 0x00097E0C
	public int Column
	{
		get
		{
			return this.#=zEh1wLVk=;
		}
	}

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x06001418 RID: 5144 RVA: 0x00099C14 File Offset: 0x00097E14
	public string Contents
	{
		get
		{
			return string.Empty;
		}
	}

	// Token: 0x17000075 RID: 117
	// (get) Token: 0x06001419 RID: 5145 RVA: 0x00099C1C File Offset: 0x00097E1C
	public object Value
	{
		get
		{
			return string.Empty;
		}
	}

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x0600141A RID: 5146 RVA: 0x00099C24 File Offset: 0x00097E24
	public CellType Type
	{
		get
		{
			return CellType.EMPTY;
		}
	}

	// Token: 0x17000077 RID: 119
	// (get) Token: 0x0600141B RID: 5147 RVA: 0x00099C2C File Offset: 0x00097E2C
	public NExcel.Format.CellFormat CellFormat
	{
		get
		{
			if (!this.#=zQqR9G48=)
			{
				this.#=zz4pSDjg= = this.#=zwKQa9tCrbbw$.getXFRecord(this.#=zJqpM8PY=);
				this.#=zQqR9G48= = true;
			}
			return this.#=zz4pSDjg=;
		}
	}

	// Token: 0x17000078 RID: 120
	// (get) Token: 0x0600141C RID: 5148 RVA: 0x00099C5C File Offset: 0x00097E5C
	public bool Hidden
	{
		get
		{
			ColumnInfoRecord columnInfo = this.#=zNEZ0SGey$A9J.getColumnInfo(this.#=zEh1wLVk=);
			if (columnInfo != null && columnInfo.Width == 0)
			{
				return true;
			}
			RowRecord rowRecord = this.#=zNEZ0SGey$A9J.#=zSzfF9oQ=(this.#=zg9A8_dw=);
			return rowRecord != null && (rowRecord.RowHeight == 0 || rowRecord.isCollapsed());
		}
	}

	// Token: 0x04000B87 RID: 2951
	private int #=zg9A8_dw=;

	// Token: 0x04000B88 RID: 2952
	private int #=zEh1wLVk=;

	// Token: 0x04000B89 RID: 2953
	private NExcel.Format.CellFormat #=zz4pSDjg=;

	// Token: 0x04000B8A RID: 2954
	private int #=zJqpM8PY=;

	// Token: 0x04000B8B RID: 2955
	private FormattingRecords #=zwKQa9tCrbbw$;

	// Token: 0x04000B8C RID: 2956
	private bool #=zQqR9G48=;

	// Token: 0x04000B8D RID: 2957
	private SheetImpl #=zNEZ0SGey$A9J;
}
