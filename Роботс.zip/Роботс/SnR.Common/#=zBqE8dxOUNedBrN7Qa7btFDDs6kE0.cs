﻿using System;
using System.Threading;
using Skink.SnR.Common;

// Token: 0x020000CE RID: 206
internal sealed class #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0
{
	// Token: 0x06000581 RID: 1409 RVA: 0x0002E6C4 File Offset: 0x0002C8C4
	private #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0()
	{
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x0002E6E8 File Offset: 0x0002C8E8
	public static bool #=zJO5XMrsPugGq()
	{
		if (#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=z$kkAC8YSPjrH && DateTime.Now >= #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zwiAqM3aNHwss)
		{
			#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=z$kkAC8YSPjrH = false;
		}
		return #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=z$kkAC8YSPjrH;
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x0002E710 File Offset: 0x0002C910
	private static void #=zRgURr0PDCRpk(bool #=z$Ib9gYQ=)
	{
		#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=z$kkAC8YSPjrH = #=z$Ib9gYQ=;
		if (#=z$Ib9gYQ=)
		{
			#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zwiAqM3aNHwss = DateTime.Now + TimeSpan.FromMinutes(10.0);
		}
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x0002E738 File Offset: 0x0002C938
	public static bool #=zGVePL2L5qfAn()
	{
		return #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zIQzwcdqgxRbKt37Cww== > DateTime.Now;
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x0002E74C File Offset: 0x0002C94C
	public static bool #=zhltKJsaZJ5wf(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=)
	{
		if (#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zJO5XMrsPugGq() || #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zGVePL2L5qfAn())
		{
			return false;
		}
		if (#=zhoOF5s8=.#=zJO5XMrsPugGq())
		{
			return false;
		}
		if (#=zhoOF5s8=.#=zhOb_1T8Tx25V())
		{
			return false;
		}
		object obj = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zdDVWRLKtNQo0;
		lock (obj)
		{
			if (#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zJO5XMrsPugGq())
			{
				return false;
			}
			if (#=zhoOF5s8=.#=zJO5XMrsPugGq())
			{
				return false;
			}
			#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zRgURr0PDCRpk(true);
			#=zhoOF5s8=.#=zRgURr0PDCRpk(true);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054978), new object[]
			{
				#=zhoOF5s8=.#=z2ZE0cltcIoE3IY7EAQ==(),
				#=zhoOF5s8=.#=z9Yordw6ZFjQe()
			});
		}
		new Thread(new ParameterizedThreadStart(#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zgq16P84=)).Start(#=zhoOF5s8=);
		return true;
	}

	// Token: 0x06000587 RID: 1415 RVA: 0x0002E814 File Offset: 0x0002CA14
	private static void #=zgq16P84=(object #=zeoV$kMvxvpZT)
	{
		#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = null;
		#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zG4GdawKHNR1$ = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
		try
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==)#=zeoV$kMvxvpZT;
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055183), Array.Empty<object>());
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zgi8txbeKnNhG(null);
			}
			#=zG4GdawKHNR1$ = #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zOGyoZpE=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
			if (#=zG4GdawKHNR1$ == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zJz$BeuY2bs5T(false);
				foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
				}
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055148), Array.Empty<object>());
			}
			else
			{
				if (#=zG4GdawKHNR1$ == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedWrongPassword)
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zPTupsH$DyeN5(DateTime.Now + TimeSpan.FromHours(72.0));
				}
				else if (#=zG4GdawKHNR1$ == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedTooManyRequests)
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zPTupsH$DyeN5(DateTime.Now + TimeSpan.FromMinutes(5.0));
				}
				else if (#=zG4GdawKHNR1$ == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedNoProxyFound)
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zPTupsH$DyeN5(DateTime.Now + TimeSpan.FromMinutes(5.0));
					#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zIQzwcdqgxRbKt37Cww== = DateTime.Now + TimeSpan.FromMinutes(15.0);
				}
				else
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zJz$BeuY2bs5T(true);
				}
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055104), Array.Empty<object>());
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zCCvotbi$42tS().Trim() != #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zCCvotbi$42tS())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056865), Array.Empty<object>());
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7().Trim() != #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056953), Array.Empty<object>());
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== != null)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=), Array.Empty<object>());
			}
		}
		finally
		{
			if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== != null)
			{
				if (#=zG4GdawKHNR1$ == #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056520), new object[]
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z2ZE0cltcIoE3IY7EAQ==(),
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe()
					});
				}
				else
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056688), new object[]
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z2ZE0cltcIoE3IY7EAQ==(),
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe()
					});
				}
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zRgURr0PDCRpk(false);
			}
			#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zRgURr0PDCRpk(false);
		}
	}

	// Token: 0x04000230 RID: 560
	private static bool #=z$kkAC8YSPjrH = false;

	// Token: 0x04000231 RID: 561
	private static DateTime #=zwiAqM3aNHwss;

	// Token: 0x04000232 RID: 562
	private static DateTime #=zIQzwcdqgxRbKt37Cww== = DateTime.MinValue;

	// Token: 0x04000233 RID: 563
	private static object #=zdDVWRLKtNQo0 = new object();

	// Token: 0x020000CF RID: 207
	public enum #=zG4GdawKHNR1$
	{
		// Token: 0x04000235 RID: 565
		Successful,
		// Token: 0x04000236 RID: 566
		FailedReasonUnknown,
		// Token: 0x04000237 RID: 567
		FailedWrongPassword,
		// Token: 0x04000238 RID: 568
		FailedTooManyRequests,
		// Token: 0x04000239 RID: 569
		FailedNoProxyFound = 10
	}
}
