﻿using System;

// Token: 0x02000292 RID: 658
internal sealed class #=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06001412 RID: 5138 RVA: 0x00099BB8 File Offset: 0x00097DB8
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z9XNVesDtacWkkDWqMw==;
	}

	// Token: 0x06001413 RID: 5139 RVA: 0x00099BC0 File Offset: 0x00097DC0
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06001414 RID: 5140 RVA: 0x00099BC4 File Offset: 0x00097DC4
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080278);
	}
}
