﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x02000173 RID: 371
internal sealed class #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== : List<#=zZ4TczVhhqPd03VvEaufX1hUlE1pF>
{
	// Token: 0x060009F7 RID: 2551 RVA: 0x00050090 File Offset: 0x0004E290
	public static #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zi1hFJwI=()
	{
		#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zW89SjO80IPkN();
		if (#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== != null)
		{
			if (#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.Count > 0 && #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==[0].#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)0)
			{
				ReadFileManager readFileManager = new ReadFileManager(FileResources.BuildingTypes, true);
				while (readFileManager.NextLine())
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0));
					if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF != null)
					{
						string a = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070627), 1);
						if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070622)))
						{
							if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070614)))
							{
								if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070606)))
								{
									if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070598)))
									{
										if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070846)))
										{
											if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070838)))
											{
												#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)0);
											}
											else
											{
												#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)6);
											}
										}
										else
										{
											#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)5);
										}
									}
									else
									{
										#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4);
									}
								}
								else
								{
									#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)3);
								}
							}
							else
							{
								#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)2);
							}
						}
						else
						{
							#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1);
						}
					}
				}
			}
			return #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==;
		}
		if (#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zOHvkTyexIHpr == null)
		{
			#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zOHvkTyexIHpr = new #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==();
			ReadFileManager readFileManager2 = new ReadFileManager(FileResources.BuildingTypes, true);
			while (readFileManager2.NextLine())
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF2 = new #=zZ4TczVhhqPd03VvEaufX1hUlE1pF();
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Id = readFileManager2.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0);
				string a = readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070627), 1);
				if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070622)))
				{
					if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070614)))
					{
						if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070606)))
						{
							if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070598)))
							{
								if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070846)))
								{
									if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070838)))
									{
										#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)0);
									}
									else
									{
										#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)6);
									}
								}
								else
								{
									#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)5);
								}
							}
							else
							{
								#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4);
							}
						}
						else
						{
							#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)3);
						}
					}
					else
					{
						#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)2);
					}
				}
				else
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1);
				}
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=znayYIHY8nMCv(readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070830), 2) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071019));
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=z36uV8HmJaa1n(readFileManager2.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070820), 3));
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827) + readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315), 4);
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=z345iMHU0qIyv(readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070803), 5));
				if (string.IsNullOrWhiteSpace(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zNn0PpoXIcD55()))
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=z345iMHU0qIyv(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name);
				}
				string text = readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071310), 6);
				if (!string.IsNullOrWhiteSpace(text))
				{
					string[] array = text.Split(new char[]
					{
						','
					});
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zpmbhfimGMj3U(new int[array.Length]);
					for (int i = 0; i < array.Length; i++)
					{
						int num;
						if (!int.TryParse(array[i], out num))
						{
							#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zpmbhfimGMj3U(null);
							break;
						}
						#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zjw43QGFcPyHH()[i] = num;
					}
				}
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.World = ((readFileManager2.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070796), -1) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071019)) ? Worlds.Elisium : Worlds.Default);
				#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zOHvkTyexIHpr.Add(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2);
			}
		}
		return #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zOHvkTyexIHpr;
	}

	// Token: 0x060009F8 RID: 2552 RVA: 0x00050410 File Offset: 0x0004E610
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF in this)
		{
			if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Id == #=zAk8mKBk=)
			{
				return #=zZ4TczVhhqPd03VvEaufX1hUlE1pF;
			}
		}
		return null;
	}

	// Token: 0x060009F9 RID: 2553 RVA: 0x00050468 File Offset: 0x0004E668
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zk$6QZNA=(string #=zAk8mKBk=)
	{
		int #=zAk8mKBk=2;
		if (int.TryParse(#=zAk8mKBk=, out #=zAk8mKBk=2))
		{
			return this.#=zk$6QZNA=(#=zAk8mKBk=2);
		}
		return null;
	}

	// Token: 0x060009FA RID: 2554 RVA: 0x00050488 File Offset: 0x0004E688
	public string #=zC6JIMv4=(int #=zp13pRNQ=)
	{
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = this.#=zk$6QZNA=(#=zp13pRNQ=);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF != null)
		{
			return #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name;
		}
		return #=zp13pRNQ=.ToString();
	}

	// Token: 0x040005B6 RID: 1462
	private static #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOHvkTyexIHpr;
}
