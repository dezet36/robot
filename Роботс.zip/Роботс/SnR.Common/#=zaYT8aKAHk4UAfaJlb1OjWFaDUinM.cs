﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020001FD RID: 509
internal sealed class #=zaYT8aKAHk4UAfaJlb1OjWFaDUinM : RecordData
{
	// Token: 0x06000FA7 RID: 4007 RVA: 0x0007A4EC File Offset: 0x000786EC
	public #=zaYT8aKAHk4UAfaJlb1OjWFaDUinM(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		this.#=zVYxVBtM= = IntegerHelper.getInt(data[0], data[1]);
	}

	// Token: 0x06000FA8 RID: 4008 RVA: 0x0007A518 File Offset: 0x00078718
	public int #=z3wd31$FU6UNi()
	{
		return this.#=zVYxVBtM=;
	}

	// Token: 0x040008AA RID: 2218
	private int #=zVYxVBtM=;
}
