﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000124 RID: 292
internal sealed class #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA== : Task
{
	// Token: 0x06000733 RID: 1843 RVA: 0x0003C880 File Offset: 0x0003AA80
	public #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==(string #=zDkEAHr8=, TaskSources #=zk656SlQ=, TaskSeverities #=z_qaYpFQ=, TaskTypes #=zvRLj9WQ=, DateTime #=zxSBcx18=, TimeSpan #=zKMZQB_CxkF$Q, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo) : base(#=zk656SlQ=, #=z_qaYpFQ=, #=zvRLj9WQ=, #=zxSBcx18=, #=zKMZQB_CxkF$Q, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
		this.#=zZnRoml8BrRh7(#=zDkEAHr8=);
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x0003C8AC File Offset: 0x0003AAAC
	public #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x0003C8BC File Offset: 0x0003AABC
	public string #=zs6AfR9w58BN2()
	{
		return this.#=zFF02quCDrD$kTba0Ow==;
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x0003C8C4 File Offset: 0x0003AAC4
	public void #=zZnRoml8BrRh7(string #=z$Ib9gYQ=)
	{
		this.#=zFF02quCDrD$kTba0Ow== = #=z$Ib9gYQ=;
	}

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000737 RID: 1847 RVA: 0x0003C8D0 File Offset: 0x0003AAD0
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874001);
		}
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x0003C8DC File Offset: 0x0003AADC
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zZnRoml8BrRh7(JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875179), string.Empty));
	}

	// Token: 0x06000739 RID: 1849 RVA: 0x0003C8FC File Offset: 0x0003AAFC
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875179)] = this.#=zs6AfR9w58BN2();
		return dictionary;
	}

	// Token: 0x04000459 RID: 1113
	private string #=zFF02quCDrD$kTba0Ow==;
}
