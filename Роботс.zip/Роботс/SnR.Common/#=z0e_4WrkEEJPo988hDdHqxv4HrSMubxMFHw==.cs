﻿using System;
using System.Collections.Generic;

// Token: 0x02000032 RID: 50
internal sealed class #=z0e_4WrkEEJPo988hDdHqxv4HrSMubxMFHw==
{
	// Token: 0x060000CC RID: 204 RVA: 0x00007644 File Offset: 0x00005844
	public static void #=zKNSug6s=(#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=zvROW5s5vAkofJphccg==, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		List<#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==> list = #=zaMx8ko6bO$VKskpk3hkrQBbepuFJSOdvnaN32za0u7h6rpueXx3v52bNM$dhqFi4En413JE=.#=zKNSug6s=(#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO());
		for (int i = 0; i < list.Count; i++)
		{
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== = list[i];
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zC68QI$8=(#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zW3vCypudd9EC(), #=zG2wnL_q7IxpD, #=zuJjQ1XU=, false);
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=znhayI43rZGmx(new #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA(#=zvROW5s5vAkofJphccg==.#=z$ufXuqs=));
			#=zvROW5s5vAkofJphccg==.Insert(i, #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==);
		}
	}
}
