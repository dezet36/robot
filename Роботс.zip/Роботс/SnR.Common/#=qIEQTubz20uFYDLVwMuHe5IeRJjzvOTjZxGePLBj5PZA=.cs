﻿using System;
using System.Drawing;
using System.Windows.Forms;

// Token: 0x02000007 RID: 7
internal sealed partial class #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA= : Form
{
	// Token: 0x06000018 RID: 24 RVA: 0x00002C14 File Offset: 0x00000E14
	public #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=(string #=zm8PpuDU=, string #=zcltuPyw=) : this(#=zm8PpuDU=, #=zcltuPyw=, MessageBoxButtons.OK)
	{
	}

	// Token: 0x06000019 RID: 25 RVA: 0x00002C20 File Offset: 0x00000E20
	public #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=(string #=zm8PpuDU=, string #=zcltuPyw=, MessageBoxButtons #=zQUn_5_A=) : this(#=zm8PpuDU=, #=zcltuPyw=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075221), #=zQUn_5_A=)
	{
	}

	// Token: 0x0600001A RID: 26 RVA: 0x00002C38 File Offset: 0x00000E38
	public #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=(string #=zm8PpuDU=, string #=zcltuPyw=, string #=zQUn_5_A=, MessageBoxButtons #=zdqSpY9Q=)
	{
		Label label = new Label();
		PictureBox pictureBox = new PictureBox();
		base.SuspendLayout();
		pictureBox.Image = #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=.#=zXHnoab5mfg4bo3W12Njr1934WrZPMmAFLKwL6Zvj2N_v(#=zQUn_5_A=);
		pictureBox.Location = new Point(8, 8);
		pictureBox.Size = new Size(48, 48);
		pictureBox.TabStop = false;
		label.Location = new Point(64, 24);
		label.Size = new Size(310, 114);
		label.Text = #=zm8PpuDU=;
		if (#=zdqSpY9Q= != MessageBoxButtons.OK)
		{
			if (#=zdqSpY9Q= == MessageBoxButtons.YesNo)
			{
				this.#=z7a31eaXB$8DF0UZNap43NWE=();
			}
		}
		else
		{
			this.#=zWt0G8emFyqz8O1enxGea4ej3kyd4DFme0xqnoMiBEYXO();
		}
		this.AutoScaleBaseSize = new Size(5, 13);
		base.ClientSize = new Size(388, 197);
		base.Controls.AddRange(new Control[]
		{
			label,
			pictureBox
		});
		base.FormBorderStyle = FormBorderStyle.FixedDialog;
		base.MaximizeBox = false;
		base.MinimizeBox = false;
		this.Text = #=zcltuPyw=;
		base.StartPosition = FormStartPosition.CenterScreen;
		base.TopMost = true;
		base.ResumeLayout(false);
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002D3C File Offset: 0x00000F3C
	private void #=zWt0G8emFyqz8O1enxGea4ej3kyd4DFme0xqnoMiBEYXO()
	{
		Button button = new Button
		{
			FlatStyle = FlatStyle.System,
			Location = new Point(169, 162),
			TabIndex = 0,
			Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201),
			DialogResult = DialogResult.OK
		};
		button.Click += this.#=zFD1vo9_AUoQR$Z4uqw==;
		base.Controls.Add(button);
		base.AcceptButton = button;
		base.CancelButton = button;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002DB8 File Offset: 0x00000FB8
	private void #=zFD1vo9_AUoQR$Z4uqw==(object #=zm8PpuDU=, EventArgs #=zcltuPyw=)
	{
		base.Close();
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002DC0 File Offset: 0x00000FC0
	private void #=z7a31eaXB$8DF0UZNap43NWE=()
	{
		Button button = new Button
		{
			FlatStyle = FlatStyle.System,
			Location = new Point(124, 162),
			TabIndex = 1,
			Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075454),
			DialogResult = DialogResult.Yes
		};
		Button button2 = new Button
		{
			FlatStyle = FlatStyle.System,
			Location = new Point(214, 162),
			TabIndex = 0,
			Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075444),
			DialogResult = DialogResult.No
		};
		base.Controls.AddRange(new Control[]
		{
			button,
			button2
		});
		base.AcceptButton = button;
		base.CancelButton = button2;
	}

	// Token: 0x0600001E RID: 30 RVA: 0x00002E74 File Offset: 0x00001074
	private static Bitmap #=zXHnoab5mfg4bo3W12Njr1934WrZPMmAFLKwL6Zvj2N_v(string #=zm8PpuDU=)
	{
		return null;
	}
}
