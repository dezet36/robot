﻿using System;
using System.Net;

// Token: 0x020000BC RID: 188
internal sealed class #=zAjO7I84RW8RKI9PeCopgq9B$x73y
{
	// Token: 0x060004F8 RID: 1272 RVA: 0x00028C2C File Offset: 0x00026E2C
	public #=zAjO7I84RW8RKI9PeCopgq9B$x73y(HttpWebRequest #=zjZWhv$4=, string #=zWC15sHaiwX4N)
	{
		this.#=zmis$BhcHzJSQ(#=zjZWhv$4=);
		this.#=zkg7rlg_HyCGa(#=zWC15sHaiwX4N);
		this.#=zxTaXClKHgJkU(null);
	}

	// Token: 0x060004F9 RID: 1273 RVA: 0x00028C4C File Offset: 0x00026E4C
	public HttpWebRequest #=zJgvbqC5Kxvxk()
	{
		return this.#=zYwnGI9Cw0QKnbR4anw==;
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x00028C54 File Offset: 0x00026E54
	private void #=zmis$BhcHzJSQ(HttpWebRequest #=z$Ib9gYQ=)
	{
		this.#=zYwnGI9Cw0QKnbR4anw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x00028C60 File Offset: 0x00026E60
	public string #=ziywd55xwWd2r()
	{
		return this.#=zF5qEOM6TTvJSjYUnzSs3qkM=;
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x00028C68 File Offset: 0x00026E68
	private void #=zkg7rlg_HyCGa(string #=z$Ib9gYQ=)
	{
		this.#=zF5qEOM6TTvJSjYUnzSs3qkM= = #=z$Ib9gYQ=;
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x00028C74 File Offset: 0x00026E74
	public string #=zjPGMpWAlPPyY()
	{
		return this.#=z1siNMSjP9NrVzO_yZTw6j9o=;
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x00028C7C File Offset: 0x00026E7C
	private void #=zxTaXClKHgJkU(string #=z$Ib9gYQ=)
	{
		this.#=z1siNMSjP9NrVzO_yZTw6j9o= = #=z$Ib9gYQ=;
	}

	// Token: 0x040001ED RID: 493
	private HttpWebRequest #=zYwnGI9Cw0QKnbR4anw==;

	// Token: 0x040001EE RID: 494
	private string #=zF5qEOM6TTvJSjYUnzSs3qkM=;

	// Token: 0x040001EF RID: 495
	private string #=z1siNMSjP9NrVzO_yZTw6j9o=;
}
