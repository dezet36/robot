﻿using System;
using common;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x02000206 RID: 518
internal sealed class #=zbDBOJoWyAZpYgDWbF4lm0x5TAJVB9sm$RQ== : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x06000FF8 RID: 4088 RVA: 0x0007B9D4 File Offset: 0x00079BD4
	public #=zbDBOJoWyAZpYgDWbF4lm0x5TAJVB9sm$RQ==(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=zvRLj9WQ= = #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zJXisDTU=(this.Instance);
		this.#=z3_8rqJg= = false;
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		this.#=znn6fdP4= = IntegerHelper.getInt(array[24], array[25], array[26], array[27]);
	}

	// Token: 0x06000FF9 RID: 4089 RVA: 0x0007BA24 File Offset: 0x00079C24
	public #=zbDBOJoWyAZpYgDWbF4lm0x5TAJVB9sm$RQ==(Drawing #=zdqSpY9Q=) : base(EscherRecordType.BSE)
	{
		this.#=zvRLj9WQ= = #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zmTMJva0=;
		this.Version = 2;
		this.Instance = this.#=zvRLj9WQ=.#=zVcIxe_4=();
		sbyte[] array = #=zdqSpY9Q=.#=z_7YH_JJoVzm3();
		this.#=zo7kbnPBjWsZ7 = array.Length;
		this.#=zJ5GWysk= = new sbyte[this.#=zo7kbnPBjWsZ7 + 61];
		Array.Copy(array, 0, this.#=zJ5GWysk=, 61, this.#=zo7kbnPBjWsZ7);
		this.#=znn6fdP4= = #=zdqSpY9Q=.#=zIpM9xU1yZCLd();
		this.#=z3_8rqJg= = true;
	}

	// Token: 0x06000FFA RID: 4090 RVA: 0x0007BAAC File Offset: 0x00079CAC
	public #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zRXe7YOuroCFE()
	{
		return this.#=zvRLj9WQ=;
	}

	// Token: 0x06000FFB RID: 4091 RVA: 0x0007BAB4 File Offset: 0x00079CB4
	internal int #=zIpM9xU1yZCLd()
	{
		return this.#=znn6fdP4=;
	}

	// Token: 0x06000FFC RID: 4092 RVA: 0x0007BABC File Offset: 0x00079CBC
	internal sbyte[] #=znTcsyHAx0qQZ()
	{
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		sbyte[] array2 = new sbyte[array.Length - 61];
		Array.Copy(array, 61, array2, 0, array2.Length);
		return array2;
	}

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000FFD RID: 4093 RVA: 0x0007BAE8 File Offset: 0x00079CE8
	public override sbyte[] Data
	{
		get
		{
			if (this.#=z3_8rqJg=)
			{
				this.#=zJ5GWysk=[0] = (sbyte)this.#=zvRLj9WQ=.#=zVcIxe_4=();
				this.#=zJ5GWysk=[1] = (sbyte)this.#=zvRLj9WQ=.#=zVcIxe_4=();
				IntegerHelper.getFourBytes(this.#=zo7kbnPBjWsZ7 + 8 + 17, this.#=zJ5GWysk=, 20);
				IntegerHelper.getFourBytes(this.#=znn6fdP4=, this.#=zJ5GWysk=, 24);
				IntegerHelper.getFourBytes(0, this.#=zJ5GWysk=, 28);
				this.#=zJ5GWysk=[32] = 0;
				this.#=zJ5GWysk=[33] = 0;
				this.#=zJ5GWysk=[34] = 126;
				this.#=zJ5GWysk=[35] = 1;
				this.#=zJ5GWysk=[36] = 0;
				this.#=zJ5GWysk=[37] = 110;
				IntegerHelper.getTwoBytes(61470, this.#=zJ5GWysk=, 38);
				IntegerHelper.getFourBytes(this.#=zo7kbnPBjWsZ7 + 17, this.#=zJ5GWysk=, 40);
			}
			else
			{
				this.#=zJ5GWysk= = this.#=ztbIWLuVjfGLU();
			}
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x06000FFE RID: 4094 RVA: 0x0007BBE4 File Offset: 0x00079DE4
	internal void #=zIOFnV7HVamsxa_BJfg==()
	{
		this.#=znn6fdP4=--;
		Assert.verify(this.#=znn6fdP4= >= 0);
	}

	// Token: 0x040008D3 RID: 2259
	private #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zvRLj9WQ=;

	// Token: 0x040008D4 RID: 2260
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x040008D5 RID: 2261
	private int #=zo7kbnPBjWsZ7;

	// Token: 0x040008D6 RID: 2262
	private int #=znn6fdP4=;

	// Token: 0x040008D7 RID: 2263
	private bool #=z3_8rqJg=;
}
