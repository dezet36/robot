﻿using System;
using System.Collections.Generic;
using System.Text;

// Token: 0x020001AA RID: 426
internal sealed class #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==
{
	// Token: 0x06000CE0 RID: 3296 RVA: 0x00066C28 File Offset: 0x00064E28
	public #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==(int #=zLeeSKrg=)
	{
		this.#=z8hJHIKFp6jOv(#=zLeeSKrg=);
		this.#=zbogGEGO2$UT92YX8PZ$HSzE=(new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>());
		this.#=zoVBgQm5qZ_BynheMvc4ZJoY=(new List<int>());
		this.#=zp4NREfw4Xz2W4ksIyU82ejU=(new List<int>());
	}

	// Token: 0x06000CE1 RID: 3297 RVA: 0x00066C58 File Offset: 0x00064E58
	public int #=zYgvZuBwR$a1C()
	{
		return this.#=z$eM7GpXgW_KO8hkYHQ==;
	}

	// Token: 0x06000CE2 RID: 3298 RVA: 0x00066C60 File Offset: 0x00064E60
	private void #=z8hJHIKFp6jOv(int #=z$Ib9gYQ=)
	{
		this.#=z$eM7GpXgW_KO8hkYHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CE3 RID: 3299 RVA: 0x00066C6C File Offset: 0x00064E6C
	private List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zsGoD8ikYTbDqVCDLvJjo5yM=()
	{
		return this.#=zoPMMjjRG_AVSQIo8OGGKwtYHoGXN;
	}

	// Token: 0x06000CE4 RID: 3300 RVA: 0x00066C74 File Offset: 0x00064E74
	private void #=zbogGEGO2$UT92YX8PZ$HSzE=(List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z$Ib9gYQ=)
	{
		this.#=zoPMMjjRG_AVSQIo8OGGKwtYHoGXN = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CE5 RID: 3301 RVA: 0x00066C80 File Offset: 0x00064E80
	private List<int> #=zRXMJu8j6U5U5EaGhcblXK6s=()
	{
		return this.#=zNxx0b8Sxxm0NDIrLC2g4q7woZSeL;
	}

	// Token: 0x06000CE6 RID: 3302 RVA: 0x00066C88 File Offset: 0x00064E88
	private void #=zoVBgQm5qZ_BynheMvc4ZJoY=(List<int> #=z$Ib9gYQ=)
	{
		this.#=zNxx0b8Sxxm0NDIrLC2g4q7woZSeL = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CE7 RID: 3303 RVA: 0x00066C94 File Offset: 0x00064E94
	private List<int> #=zny3C2NVifSaq4qb1OWyOAh8=()
	{
		return this.#=zDORx_AAr5zApo2cJD6K6O4EavGNq;
	}

	// Token: 0x06000CE8 RID: 3304 RVA: 0x00066C9C File Offset: 0x00064E9C
	private void #=zp4NREfw4Xz2W4ksIyU82ejU=(List<int> #=z$Ib9gYQ=)
	{
		this.#=zDORx_AAr5zApo2cJD6K6O4EavGNq = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CE9 RID: 3305 RVA: 0x00066CA8 File Offset: 0x00064EA8
	public void #=zbPId9eg=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		if (#=z8StzeqE=.#=zjV_wsuvJ0R_B() == null)
		{
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = null;
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in this.#=zsGoD8ikYTbDqVCDLvJjo5yM=())
		{
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zjV_wsuvJ0R_B() != null && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2;
				break;
			}
		}
		if (#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=() != null)
		{
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== == null)
			{
				this.#=zsGoD8ikYTbDqVCDLvJjo5yM=().Add(#=z8StzeqE=);
				this.#=zsGoD8ikYTbDqVCDLvJjo5yM=().Sort(new #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==.#=zHvvnz6g54cE_());
			}
			for (int i = 0; i < #=z8StzeqE=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=().Count; i++)
			{
				#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== #=zcvzmwA_SR1dxtNktUQ== = #=z8StzeqE=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=()[i];
				if (!this.#=zRXMJu8j6U5U5EaGhcblXK6s=().Contains(#=zcvzmwA_SR1dxtNktUQ==.#=zMuFMjGQ=()))
				{
					this.#=zRXMJu8j6U5U5EaGhcblXK6s=().Add(#=zcvzmwA_SR1dxtNktUQ==.#=zMuFMjGQ=());
					this.#=zny3C2NVifSaq4qb1OWyOAh8=().Add(#=zcvzmwA_SR1dxtNktUQ==.#=zMuFMjGQ=());
				}
			}
			return;
		}
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
		{
			this.#=zsGoD8ikYTbDqVCDLvJjo5yM=().Remove(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
		}
	}

	// Token: 0x06000CEA RID: 3306 RVA: 0x00066DC8 File Offset: 0x00064FC8
	public void #=zYBbhgs8=(StringBuilder #=zrhvCoyA=)
	{
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zsGoD8ikYTbDqVCDLvJjo5yM=())
		{
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=() != null)
			{
				int num = 0;
				#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=zBp8AqDWk_wpz = (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)0;
				foreach (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== #=zcvzmwA_SR1dxtNktUQ== in #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=())
				{
					if (#=zBp8AqDWk_wpz == (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)1 && #=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR() == (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2)
					{
						break;
					}
					bool flag = false;
					switch (#=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR())
					{
					case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)0:
						flag = false;
						break;
					case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)1:
						flag = true;
						break;
					case (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2:
						flag = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zrXOjFBdb5lleq1hEe$0hzQ_8RWgEbT9mog==();
						break;
					}
					flag = (flag && this.#=zny3C2NVifSaq4qb1OWyOAh8=().Contains(#=zcvzmwA_SR1dxtNktUQ==.#=zMuFMjGQ=()));
					if (flag)
					{
						if (num == 0)
						{
							if (#=zrhvCoyA=.Length > 0)
							{
								#=zrhvCoyA=.Append(Environment.NewLine);
							}
							#=zrhvCoyA=.Append(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==());
							#=zrhvCoyA=.Append(' ');
							if (#=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR() == (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2)
							{
								#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zjSSQZRrQ8d_l = #=zcvzmwA_SR1dxtNktUQ==.#=zq2bPTdY=();
								if (#=zjSSQZRrQ8d_l != (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4)
								{
									if (#=zjSSQZRrQ8d_l != (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)6)
									{
										#=zrhvCoyA=.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862025)));
									}
									else
									{
										#=zrhvCoyA=.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862069)));
									}
								}
								else
								{
									#=zrhvCoyA=.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862338)));
								}
							}
							else
							{
								#=zrhvCoyA=.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862001)));
							}
							#=zrhvCoyA=.Append(' ');
							#=zBp8AqDWk_wpz = #=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR();
						}
						else
						{
							if (num >= 5)
							{
								#=zrhvCoyA=.AppendFormat(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908861969)), num);
								break;
							}
							#=zrhvCoyA=.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
						}
						#=zrhvCoyA=.Append(#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==().ToLongTimeString());
						num++;
						this.#=zny3C2NVifSaq4qb1OWyOAh8=().Remove(#=zcvzmwA_SR1dxtNktUQ==.#=zMuFMjGQ=());
					}
				}
			}
		}
	}

	// Token: 0x0400076F RID: 1903
	private int #=z$eM7GpXgW_KO8hkYHQ==;

	// Token: 0x04000770 RID: 1904
	private List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zoPMMjjRG_AVSQIo8OGGKwtYHoGXN;

	// Token: 0x04000771 RID: 1905
	private List<int> #=zNxx0b8Sxxm0NDIrLC2g4q7woZSeL;

	// Token: 0x04000772 RID: 1906
	private List<int> #=zDORx_AAr5zApo2cJD6K6O4EavGNq;

	// Token: 0x020001AB RID: 427
	internal sealed class #=zHvvnz6g54cE_ : IComparer<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>
	{
		// Token: 0x06000CEC RID: 3308 RVA: 0x00067018 File Offset: 0x00065218
		public int Compare(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJxMSUas=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zVnDyQrg=)
		{
			if (#=zJxMSUas=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=().Count * #=zVnDyQrg=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=().Count == 0)
			{
				return #=zJxMSUas=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=().Count.CompareTo(#=zVnDyQrg=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=().Count);
			}
			return #=zJxMSUas=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=()[0].#=zL4D9WC8RTH921DofgQ==().CompareTo(#=zVnDyQrg=.#=z5Fxa9o9ygZWU().#=z4sXt66V1ZksHjpTHIZIhgos=()[0].#=zL4D9WC8RTH921DofgQ==());
		}
	}
}
