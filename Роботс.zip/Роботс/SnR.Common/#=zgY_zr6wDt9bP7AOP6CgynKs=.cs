﻿using System;

// Token: 0x02000245 RID: 581
internal sealed class #=zgY_zr6wDt9bP7AOP6CgynKs= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x060011B8 RID: 4536 RVA: 0x00089F74 File Offset: 0x00088174
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zCh3653M=;
	}

	// Token: 0x060011B9 RID: 4537 RVA: 0x00089F7C File Offset: 0x0008817C
	internal override int #=zXiDCyaHY58$0()
	{
		return 1;
	}

	// Token: 0x060011BA RID: 4538 RVA: 0x00089F80 File Offset: 0x00088180
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080192);
	}
}
