﻿using System;

// Token: 0x02000249 RID: 585
internal sealed class #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<#=zQSoxQMk=>
{
	// Token: 0x060011D6 RID: 4566 RVA: 0x0008A210 File Offset: 0x00088410
	public #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=(TimeSpan #=zj0TYbdY=, bool #=zOaTyd2l4wNme = false, #=zQSoxQMk= #=z01CGwd2vEoD_ = default(#=zQSoxQMk=))
	{
		this.#=zVkNsMz4= = #=z01CGwd2vEoD_;
		this.#=zeKHKOqE= = #=zj0TYbdY=;
		this.#=z3mRw5touiqOf = #=z01CGwd2vEoD_;
		this.#=zSV4$mlFB34WM = (#=zOaTyd2l4wNme ? new object() : null);
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x0008A240 File Offset: 0x00088440
	public #=zQSoxQMk= #=zVcIxe_4=()
	{
		if (this.#=zOyHcCzI= < DateTime.Now)
		{
			if (this.#=zSV4$mlFB34WM != null)
			{
				object obj = this.#=zSV4$mlFB34WM;
				lock (obj)
				{
					this.#=ziL6XPwI=(this.#=z3mRw5touiqOf);
					goto IL_4F;
				}
			}
			this.#=ziL6XPwI=(this.#=z3mRw5touiqOf);
		}
		IL_4F:
		return this.#=zVkNsMz4=;
	}

	// Token: 0x060011D8 RID: 4568 RVA: 0x0008A2B4 File Offset: 0x000884B4
	public void #=zKTAVzhk=(#=zQSoxQMk= #=z$Ib9gYQ=)
	{
		if (this.#=zSV4$mlFB34WM != null)
		{
			object obj = this.#=zSV4$mlFB34WM;
			lock (obj)
			{
				this.#=ziL6XPwI=(#=z$Ib9gYQ=);
				return;
			}
		}
		this.#=ziL6XPwI=(#=z$Ib9gYQ=);
	}

	// Token: 0x060011D9 RID: 4569 RVA: 0x0008A304 File Offset: 0x00088504
	private void #=ziL6XPwI=(#=zQSoxQMk= #=z$Ib9gYQ=)
	{
		this.#=zVkNsMz4= = #=z$Ib9gYQ=;
		this.#=zOyHcCzI= = DateTime.Now + this.#=zeKHKOqE=;
	}

	// Token: 0x040009F5 RID: 2549
	private DateTime #=zOyHcCzI=;

	// Token: 0x040009F6 RID: 2550
	private #=zQSoxQMk= #=zVkNsMz4=;

	// Token: 0x040009F7 RID: 2551
	private TimeSpan #=zeKHKOqE=;

	// Token: 0x040009F8 RID: 2552
	private #=zQSoxQMk= #=z3mRw5touiqOf;

	// Token: 0x040009F9 RID: 2553
	private object #=zSV4$mlFB34WM;
}
