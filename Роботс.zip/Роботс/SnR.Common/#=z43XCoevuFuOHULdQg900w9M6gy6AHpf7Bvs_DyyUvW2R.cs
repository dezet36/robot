﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200005C RID: 92
internal sealed class #=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R
{
	// Token: 0x060002B5 RID: 693 RVA: 0x00016BD8 File Offset: 0x00014DD8
	public #=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zlpCxHhBc2SEtFclFAg==(new Dictionary<int, int>());
		for (int i = 1; i <= 5; i++)
		{
			this.#=zluiMMMrmz25htA87Ew==().Add(i, 0);
		}
		if (#=zJ5GWysk= == null)
		{
			this.#=zqeN9$4CbThNh(false);
			return;
		}
		this.#=zqeN9$4CbThNh(true);
		this.#=zFzGvi_S6jJhE(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		this.#=ztwMepwq8WPzg(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0) > 0);
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
		if (dictionary != null)
		{
			foreach (string text in dictionary.Keys)
			{
				this.#=zluiMMMrmz25htA87Ew==()[Convert.ToInt32(text)] = Convert.ToInt32(dictionary[text]);
			}
		}
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x00016CC4 File Offset: 0x00014EC4
	public bool #=zky5MXqBjSGa2()
	{
		return this.#=zob7teMTIPbhAea2o$A==;
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x00016CCC File Offset: 0x00014ECC
	public void #=zqeN9$4CbThNh(bool #=z$Ib9gYQ=)
	{
		this.#=zob7teMTIPbhAea2o$A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00016CD8 File Offset: 0x00014ED8
	public Dictionary<int, int> #=zluiMMMrmz25htA87Ew==()
	{
		return this.#=zl$obg$U_tkXdZSOpIhJxmB0=;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00016CE0 File Offset: 0x00014EE0
	public void #=zlpCxHhBc2SEtFclFAg==(Dictionary<int, int> #=z$Ib9gYQ=)
	{
		this.#=zl$obg$U_tkXdZSOpIhJxmB0= = #=z$Ib9gYQ=;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x00016CEC File Offset: 0x00014EEC
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x060002BB RID: 699 RVA: 0x00016CF4 File Offset: 0x00014EF4
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00016D00 File Offset: 0x00014F00
	public bool #=zwA$pC4$kvy0a()
	{
		return this.#=z1wK7nt5h0hdyG164SQ==;
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00016D08 File Offset: 0x00014F08
	public void #=ztwMepwq8WPzg(bool #=z$Ib9gYQ=)
	{
		this.#=z1wK7nt5h0hdyG164SQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00016D14 File Offset: 0x00014F14
	public bool #=z17cdY2f2opttAnK$AA==()
	{
		for (int i = 1; i <= 5; i++)
		{
			if (!this.#=zluiMMMrmz25htA87Ew==().ContainsKey(i))
			{
				return false;
			}
			if (this.#=zluiMMMrmz25htA87Ew==()[i] <= 0)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x040000DB RID: 219
	private bool #=zob7teMTIPbhAea2o$A==;

	// Token: 0x040000DC RID: 220
	private Dictionary<int, int> #=zl$obg$U_tkXdZSOpIhJxmB0=;

	// Token: 0x040000DD RID: 221
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x040000DE RID: 222
	private bool #=z1wK7nt5h0hdyG164SQ==;
}
