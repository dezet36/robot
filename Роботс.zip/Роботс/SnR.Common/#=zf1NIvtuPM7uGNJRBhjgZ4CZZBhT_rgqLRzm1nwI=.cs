﻿using System;
using Skink.SnR.Common.GZip;

// Token: 0x02000236 RID: 566
internal sealed class #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=
{
	// Token: 0x06001152 RID: 4434 RVA: 0x00084934 File Offset: 0x00082B34
	internal #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, object #=z5CKW$CoP8LEf, int #=zgLaCy2g=)
	{
		this.#=zcXgLydccbe5C = #=zuuFHPjILnjRT;
		this.#=z45dkCDqdjPYU = new int[4320];
		this.#=zgcFyF1E= = new byte[#=zgLaCy2g=];
		this.#=zf$NwTlE= = #=zgLaCy2g=;
		this.#=z5CKW$CoP8LEf = #=z5CKW$CoP8LEf;
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0;
		this.#=zW3vXs9Q=();
	}

	// Token: 0x06001154 RID: 4436 RVA: 0x000849D0 File Offset: 0x00082BD0
	internal uint #=zW3vXs9Q=()
	{
		uint result = this.#=zGpJYnQM=;
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0;
		this.#=zkLxzZ_J6u52Z = 0;
		this.#=zEnIyXR3jdBvO = 0;
		this.#=zWZqaeqGJDTn2 = (this.#=z1jZkw8iLmhH0 = 0);
		if (this.#=z5CKW$CoP8LEf != null)
		{
			this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = (this.#=zGpJYnQM= = Adler.Adler32(0U, null, 0, 0));
		}
		return result;
	}

	// Token: 0x06001155 RID: 4437 RVA: 0x00084A30 File Offset: 0x00082C30
	internal int #=zvb5bnug=(int #=zihyUFzs=)
	{
		int num = this.#=zcXgLydccbe5C.#=z_f$vhX8=;
		int num2 = this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3;
		int num3 = this.#=zEnIyXR3jdBvO;
		int i = this.#=zkLxzZ_J6u52Z;
		int num4 = this.#=z1jZkw8iLmhH0;
		int num5 = (num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4);
		int num6;
		for (;;)
		{
			switch (this.#=zZ6hesjQ=)
			{
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0:
				while (i < 3)
				{
					if (num2 == 0)
					{
						goto IL_96;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = (num3 & 7);
				this.#=zmdDksvY= = (num6 & 1);
				switch ((uint)num6 >> 1)
				{
				case 0U:
					num3 >>= 3;
					i -= 3;
					num6 = (i & 7);
					num3 >>= num6;
					i -= num6;
					this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)1;
					continue;
				case 1U:
				{
					int[] array = new int[1];
					int[] array2 = new int[1];
					int[][] array3 = new int[1][];
					int[][] array4 = new int[1][];
					#=zvLw0Fe1dnuJ8g8DTw8CNbKoDNIR5beknqw==.#=zBERO7t5Tfm23TvsCSQ==(array, array2, array3, array4, this.#=zcXgLydccbe5C);
					this.#=zVikGZBQEusdV.#=zC68QI$8=(array[0], array2[0], array3[0], 0, array4[0], 0);
					num3 >>= 3;
					i -= 3;
					this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)6;
					continue;
				}
				case 2U:
					num3 >>= 3;
					i -= 3;
					this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)3;
					continue;
				case 3U:
					goto IL_1E7;
				default:
					continue;
				}
				break;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)1:
				while (i < 32)
				{
					if (num2 == 0)
					{
						goto IL_270;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				if ((~num3 >> 16 & 65535) != (num3 & 65535))
				{
					goto Block_8;
				}
				this.#=zDXQeWp8= = (num3 & 65535);
				i = (num3 = 0);
				this.#=zZ6hesjQ= = ((this.#=zDXQeWp8= != 0) ? ((#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)2) : ((this.#=zmdDksvY= != 0) ? ((#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)7) : ((#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0)));
				continue;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)2:
				if (num2 == 0)
				{
					goto Block_11;
				}
				if (num5 == 0)
				{
					if (num4 == this.#=zf$NwTlE= && this.#=zWZqaeqGJDTn2 != 0)
					{
						num4 = 0;
						num5 = ((num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4));
					}
					if (num5 == 0)
					{
						this.#=z1jZkw8iLmhH0 = num4;
						#=zihyUFzs= = this.#=z3N5BEfw=(#=zihyUFzs=);
						num4 = this.#=z1jZkw8iLmhH0;
						num5 = ((num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4));
						if (num4 == this.#=zf$NwTlE= && this.#=zWZqaeqGJDTn2 != 0)
						{
							num4 = 0;
							num5 = ((num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4));
						}
						if (num5 == 0)
						{
							goto Block_21;
						}
					}
				}
				#=zihyUFzs= = 0;
				num6 = this.#=zDXQeWp8=;
				if (num6 > num2)
				{
					num6 = num2;
				}
				if (num6 > num5)
				{
					num6 = num5;
				}
				Array.Copy(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0, num, this.#=zgcFyF1E=, num4, num6);
				num += num6;
				num2 -= num6;
				num4 += num6;
				num5 -= num6;
				if ((this.#=zDXQeWp8= -= num6) == 0)
				{
					this.#=zZ6hesjQ= = ((this.#=zmdDksvY= != 0) ? ((#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)7) : ((#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0));
					continue;
				}
				continue;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)3:
				while (i < 14)
				{
					if (num2 == 0)
					{
						goto IL_5A6;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = (this.#=zMRcAaeg= = (num3 & 16383));
				if ((num6 & 31) > 29 || (num6 >> 5 & 31) > 29)
				{
					goto IL_64F;
				}
				num6 = 258 + (num6 & 31) + (num6 >> 5 & 31);
				if (this.#=zrx0fr4_bH8bJ == null || this.#=zrx0fr4_bH8bJ.Length < num6)
				{
					this.#=zrx0fr4_bH8bJ = new int[num6];
				}
				else
				{
					Array.Clear(this.#=zrx0fr4_bH8bJ, 0, num6);
				}
				num3 >>= 14;
				i -= 14;
				this.#=zSPLDPE4= = 0;
				this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)4;
				goto IL_7E0;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)4:
				goto IL_7E0;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)5:
				goto IL_8D3;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)6:
				goto IL_CE0;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)7:
				goto IL_DB9;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)8:
				goto IL_E60;
			case (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9:
				goto IL_EBA;
			}
			break;
			IL_7E0:
			while (this.#=zSPLDPE4= < 4 + (this.#=zMRcAaeg= >> 10))
			{
				while (i < 3)
				{
					if (num2 == 0)
					{
						goto IL_72D;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				int[] array5 = this.#=zrx0fr4_bH8bJ;
				int[] array6 = #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=zLKvP43s=;
				int num7 = this.#=zSPLDPE4=;
				this.#=zSPLDPE4= = num7 + 1;
				array5[array6[num7]] = (num3 & 7);
				num3 >>= 3;
				i -= 3;
			}
			while (this.#=zSPLDPE4= < 19)
			{
				int[] array7 = this.#=zrx0fr4_bH8bJ;
				int[] array8 = #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=zLKvP43s=;
				int num7 = this.#=zSPLDPE4=;
				this.#=zSPLDPE4= = num7 + 1;
				array7[array8[num7]] = 0;
			}
			this.#=zishJPx0=[0] = 7;
			num6 = this.#=z$BVlc5Igb6xk.#=z2JVfgIekHQ389O4byg==(this.#=zrx0fr4_bH8bJ, this.#=zishJPx0=, this.#=zLzHDLDM=, this.#=z45dkCDqdjPYU, this.#=zcXgLydccbe5C);
			if (num6 != 0)
			{
				goto Block_34;
			}
			this.#=zSPLDPE4= = 0;
			this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)5;
			for (;;)
			{
				IL_8D3:
				num6 = this.#=zMRcAaeg=;
				if (this.#=zSPLDPE4= >= 258 + (num6 & 31) + (num6 >> 5 & 31))
				{
					break;
				}
				num6 = this.#=zishJPx0=[0];
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_90D;
					}
					#=zihyUFzs= = 0;
					num2--;
					num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = this.#=z45dkCDqdjPYU[(this.#=zLzHDLDM=[0] + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6])) * 3 + 1];
				int num8 = this.#=z45dkCDqdjPYU[(this.#=zLzHDLDM=[0] + (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num6])) * 3 + 2];
				if (num8 < 16)
				{
					num3 >>= num6;
					i -= num6;
					int[] array9 = this.#=zrx0fr4_bH8bJ;
					int num7 = this.#=zSPLDPE4=;
					this.#=zSPLDPE4= = num7 + 1;
					array9[num7] = num8;
				}
				else
				{
					int num9 = (num8 == 18) ? 7 : (num8 - 14);
					int num10 = (num8 == 18) ? 11 : 3;
					while (i < num6 + num9)
					{
						if (num2 == 0)
						{
							goto IL_A2F;
						}
						#=zihyUFzs= = 0;
						num2--;
						num3 |= (int)(this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num++] & byte.MaxValue) << i;
						i += 8;
					}
					num3 >>= num6;
					i -= num6;
					num10 += (num3 & #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD.#=zmWx_sTaa2o8wgxHBZw==[num9]);
					num3 >>= num9;
					i -= num9;
					num9 = this.#=zSPLDPE4=;
					num6 = this.#=zMRcAaeg=;
					if (num9 + num10 > 258 + (num6 & 31) + (num6 >> 5 & 31) || (num8 == 16 && num9 < 1))
					{
						goto IL_B15;
					}
					num8 = ((num8 == 16) ? this.#=zrx0fr4_bH8bJ[num9 - 1] : 0);
					do
					{
						this.#=zrx0fr4_bH8bJ[num9++] = num8;
					}
					while (--num10 != 0);
					this.#=zSPLDPE4= = num9;
				}
			}
			this.#=zLzHDLDM=[0] = -1;
			int[] array10 = new int[]
			{
				9
			};
			int[] array11 = new int[]
			{
				6
			};
			int[] array12 = new int[1];
			int[] array13 = new int[1];
			num6 = this.#=zMRcAaeg=;
			num6 = this.#=z$BVlc5Igb6xk.#=zVokhE7oWTSuVAYL6bg==(257 + (num6 & 31), 1 + (num6 >> 5 & 31), this.#=zrx0fr4_bH8bJ, array10, array11, array12, array13, this.#=z45dkCDqdjPYU, this.#=zcXgLydccbe5C);
			if (num6 != 0)
			{
				goto Block_48;
			}
			this.#=zVikGZBQEusdV.#=zC68QI$8=(array10[0], array11[0], this.#=z45dkCDqdjPYU, array12[0], this.#=z45dkCDqdjPYU, array13[0]);
			this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)6;
			IL_CE0:
			this.#=zEnIyXR3jdBvO = num3;
			this.#=zkLxzZ_J6u52Z = i;
			this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
			this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
			this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
			this.#=z1jZkw8iLmhH0 = num4;
			#=zihyUFzs= = this.#=zVikGZBQEusdV.#=zvb5bnug=(this, #=zihyUFzs=);
			if (#=zihyUFzs= != 1)
			{
				goto Block_50;
			}
			#=zihyUFzs= = 0;
			num = this.#=zcXgLydccbe5C.#=z_f$vhX8=;
			num2 = this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3;
			num3 = this.#=zEnIyXR3jdBvO;
			i = this.#=zkLxzZ_J6u52Z;
			num4 = this.#=z1jZkw8iLmhH0;
			num5 = ((num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4));
			if (this.#=zmdDksvY= != 0)
			{
				goto IL_DB2;
			}
			this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)0;
		}
		#=zihyUFzs= = -2;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_96:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_1E7:
		num3 >>= 3;
		i -= 3;
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063945);
		#=zihyUFzs= = -3;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_270:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_8:
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064182);
		#=zihyUFzs= = -3;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_11:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_21:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_5A6:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_64F:
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064149);
		#=zihyUFzs= = -3;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_72D:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_34:
		#=zihyUFzs= = num6;
		if (#=zihyUFzs= == -3)
		{
			this.#=zrx0fr4_bH8bJ = null;
			this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		}
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_90D:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_A2F:
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_B15:
		this.#=zrx0fr4_bH8bJ = null;
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064099);
		#=zihyUFzs= = -3;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_48:
		if (num6 == -3)
		{
			this.#=zrx0fr4_bH8bJ = null;
			this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)9;
		}
		#=zihyUFzs= = num6;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		Block_50:
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_DB2:
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)7;
		IL_DB9:
		this.#=z1jZkw8iLmhH0 = num4;
		#=zihyUFzs= = this.#=z3N5BEfw=(#=zihyUFzs=);
		num4 = this.#=z1jZkw8iLmhH0;
		int num11 = (num4 < this.#=zWZqaeqGJDTn2) ? (this.#=zWZqaeqGJDTn2 - num4 - 1) : (this.#=zf$NwTlE= - num4);
		if (this.#=zWZqaeqGJDTn2 != this.#=z1jZkw8iLmhH0)
		{
			this.#=zEnIyXR3jdBvO = num3;
			this.#=zkLxzZ_J6u52Z = i;
			this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
			this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
			this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
			this.#=z1jZkw8iLmhH0 = num4;
			return this.#=z3N5BEfw=(#=zihyUFzs=);
		}
		this.#=zZ6hesjQ= = (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)8;
		IL_E60:
		#=zihyUFzs= = 1;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
		IL_EBA:
		#=zihyUFzs= = -3;
		this.#=zEnIyXR3jdBvO = num3;
		this.#=zkLxzZ_J6u52Z = i;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num2;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num;
		this.#=z1jZkw8iLmhH0 = num4;
		return this.#=z3N5BEfw=(#=zihyUFzs=);
	}

	// Token: 0x06001156 RID: 4438 RVA: 0x000859AC File Offset: 0x00083BAC
	internal void #=zuHP7ulY=()
	{
		this.#=zW3vXs9Q=();
		this.#=zgcFyF1E= = null;
		this.#=z45dkCDqdjPYU = null;
	}

	// Token: 0x06001157 RID: 4439 RVA: 0x000859C4 File Offset: 0x00083BC4
	internal void #=zv4DxgDs=(byte[] #=zdqSpY9Q=, int #=z1qaC5B0=, int #=zpvGJrv4=)
	{
		Array.Copy(#=zdqSpY9Q=, #=z1qaC5B0=, this.#=zgcFyF1E=, 0, #=zpvGJrv4=);
		this.#=z1jZkw8iLmhH0 = #=zpvGJrv4=;
		this.#=zWZqaeqGJDTn2 = #=zpvGJrv4=;
	}

	// Token: 0x06001158 RID: 4440 RVA: 0x000859F0 File Offset: 0x00083BF0
	internal int #=zutJ2D_gir2nk()
	{
		return (this.#=zZ6hesjQ= == (#=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw==)1) ? 1 : 0;
	}

	// Token: 0x06001159 RID: 4441 RVA: 0x000859FC File Offset: 0x00083BFC
	internal int #=z3N5BEfw=(int #=zihyUFzs=)
	{
		for (int i = 0; i < 2; i++)
		{
			int num;
			if (i == 0)
			{
				num = ((this.#=zWZqaeqGJDTn2 <= this.#=z1jZkw8iLmhH0) ? this.#=z1jZkw8iLmhH0 : this.#=zf$NwTlE=) - this.#=zWZqaeqGJDTn2;
			}
			else
			{
				num = this.#=z1jZkw8iLmhH0 - this.#=zWZqaeqGJDTn2;
			}
			if (num == 0)
			{
				if (#=zihyUFzs= == -5)
				{
					#=zihyUFzs= = 0;
				}
				return #=zihyUFzs=;
			}
			if (num > this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR)
			{
				num = this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR;
			}
			if (num != 0 && #=zihyUFzs= == -5)
			{
				#=zihyUFzs= = 0;
			}
			this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR -= num;
			this.#=zcXgLydccbe5C.#=z0KaacqESNJ$P += (long)num;
			if (this.#=z5CKW$CoP8LEf != null)
			{
				this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = (this.#=zGpJYnQM= = Adler.Adler32(this.#=zGpJYnQM=, this.#=zgcFyF1E=, this.#=zWZqaeqGJDTn2, num));
			}
			Array.Copy(this.#=zgcFyF1E=, this.#=zWZqaeqGJDTn2, this.#=zcXgLydccbe5C.#=zTkQEpCPgqFwZ, this.#=zcXgLydccbe5C.#=z6v5OUYo=, num);
			this.#=zcXgLydccbe5C.#=z6v5OUYo= += num;
			this.#=zWZqaeqGJDTn2 += num;
			if (this.#=zWZqaeqGJDTn2 == this.#=zf$NwTlE= && i == 0)
			{
				this.#=zWZqaeqGJDTn2 = 0;
				if (this.#=z1jZkw8iLmhH0 == this.#=zf$NwTlE=)
				{
					this.#=z1jZkw8iLmhH0 = 0;
				}
			}
			else
			{
				i++;
			}
		}
		return #=zihyUFzs=;
	}

	// Token: 0x0400095E RID: 2398
	internal static readonly int[] #=zLKvP43s= = new int[]
	{
		16,
		17,
		18,
		0,
		8,
		7,
		9,
		6,
		10,
		5,
		11,
		4,
		12,
		3,
		13,
		2,
		14,
		1,
		15
	};

	// Token: 0x0400095F RID: 2399
	private #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=.#=ztcG07LzmHuSTACvbQw== #=zZ6hesjQ=;

	// Token: 0x04000960 RID: 2400
	internal int #=zDXQeWp8=;

	// Token: 0x04000961 RID: 2401
	internal int #=zMRcAaeg=;

	// Token: 0x04000962 RID: 2402
	internal int #=zSPLDPE4=;

	// Token: 0x04000963 RID: 2403
	internal int[] #=zrx0fr4_bH8bJ;

	// Token: 0x04000964 RID: 2404
	internal int[] #=zishJPx0= = new int[1];

	// Token: 0x04000965 RID: 2405
	internal int[] #=zLzHDLDM= = new int[1];

	// Token: 0x04000966 RID: 2406
	internal #=zMa3vAuQ39nC6541_wc77s8KNSiRjIkOWZMgrCVM= #=zVikGZBQEusdV = new #=zMa3vAuQ39nC6541_wc77s8KNSiRjIkOWZMgrCVM=();

	// Token: 0x04000967 RID: 2407
	internal int #=zmdDksvY=;

	// Token: 0x04000968 RID: 2408
	internal #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zcXgLydccbe5C;

	// Token: 0x04000969 RID: 2409
	internal int #=zkLxzZ_J6u52Z;

	// Token: 0x0400096A RID: 2410
	internal int #=zEnIyXR3jdBvO;

	// Token: 0x0400096B RID: 2411
	internal int[] #=z45dkCDqdjPYU;

	// Token: 0x0400096C RID: 2412
	internal byte[] #=zgcFyF1E=;

	// Token: 0x0400096D RID: 2413
	internal int #=zf$NwTlE=;

	// Token: 0x0400096E RID: 2414
	internal int #=zWZqaeqGJDTn2;

	// Token: 0x0400096F RID: 2415
	internal int #=z1jZkw8iLmhH0;

	// Token: 0x04000970 RID: 2416
	internal object #=z5CKW$CoP8LEf;

	// Token: 0x04000971 RID: 2417
	internal uint #=zGpJYnQM=;

	// Token: 0x04000972 RID: 2418
	internal #=zvLw0Fe1dnuJ8g8DTw8CNbKoDNIR5beknqw== #=z$BVlc5Igb6xk = new #=zvLw0Fe1dnuJ8g8DTw8CNbKoDNIR5beknqw==();

	// Token: 0x02000237 RID: 567
	private enum #=ztcG07LzmHuSTACvbQw==
	{

	}
}
