﻿using System;
using System.Text;
using NExcel;
using NExcel.Biff;

// Token: 0x0200015C RID: 348
internal sealed class #=zM0skyyV8WafUvIlFnkIs4er6wYjP : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600093D RID: 2365 RVA: 0x0004B96C File Offset: 0x00049B6C
	public #=zM0skyyV8WafUvIlFnkIs4er6wYjP(Cell #=zLWZxLVM=)
	{
		this.#=zq07FqDs= = #=zLWZxLVM=;
	}

	// Token: 0x0600093E RID: 2366 RVA: 0x0004B97C File Offset: 0x00049B7C
	public int #=z85RU4eQ=()
	{
		return this.#=zEh1wLVk=;
	}

	// Token: 0x0600093F RID: 2367 RVA: 0x0004B984 File Offset: 0x00049B84
	public int #=zNMAKc1U=()
	{
		return this.#=zg9A8_dw=;
	}

	// Token: 0x06000940 RID: 2368 RVA: 0x0004B98C File Offset: 0x00049B8C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[5];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=ztzoFLYo=.#=zd$BbM3Y=();
		IntegerHelper.getTwoBytes(this.#=zg9A8_dw=, array, 1);
		int num = this.#=zEh1wLVk=;
		if (this.#=zEKQLhRCOdkGm)
		{
			num |= 16384;
		}
		if (this.#=zXY7Hgaj_6YSr)
		{
			num |= 32768;
		}
		IntegerHelper.getTwoBytes(num, array, 3);
		return array;
	}

	// Token: 0x06000941 RID: 2369 RVA: 0x0004B9EC File Offset: 0x00049BEC
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zg9A8_dw= = (int)IntegerHelper.getShort(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		this.#=zEh1wLVk= = (int)((sbyte)@int);
		this.#=zEKQLhRCOdkGm = ((@int & 16384) != 0);
		this.#=zXY7Hgaj_6YSr = ((@int & 32768) != 0);
		if (this.#=zEKQLhRCOdkGm)
		{
			this.#=zEh1wLVk= = this.#=zq07FqDs=.Column + this.#=zEh1wLVk=;
		}
		if (this.#=zXY7Hgaj_6YSr)
		{
			this.#=zg9A8_dw= = this.#=zq07FqDs=.Row + this.#=zg9A8_dw=;
		}
		return 4;
	}

	// Token: 0x06000942 RID: 2370 RVA: 0x0004BA88 File Offset: 0x00049C88
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		NExcel.Biff.CellReferenceHelper.getCellReference(this.#=zEh1wLVk=, this.#=zg9A8_dw=, #=zXvwCnz8=);
	}

	// Token: 0x04000551 RID: 1361
	private bool #=zEKQLhRCOdkGm;

	// Token: 0x04000552 RID: 1362
	private bool #=zXY7Hgaj_6YSr;

	// Token: 0x04000553 RID: 1363
	private int #=zEh1wLVk=;

	// Token: 0x04000554 RID: 1364
	private int #=zg9A8_dw=;

	// Token: 0x04000555 RID: 1365
	private Cell #=zq07FqDs=;
}
