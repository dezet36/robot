﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000233 RID: 563
internal sealed class #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg==
{
	// Token: 0x0600113D RID: 4413 RVA: 0x000846F8 File Offset: 0x000828F8
	public #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg==()
	{
		this.#=zdFvFX7WJ2dLoekhK_s_unCQ=(null);
	}

	// Token: 0x0600113E RID: 4414 RVA: 0x00084708 File Offset: 0x00082908
	public #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg==(string #=ztmMqdSCDyC5i)
	{
		this.#=zdFvFX7WJ2dLoekhK_s_unCQ=(null);
		if (!string.IsNullOrEmpty(#=ztmMqdSCDyC5i))
		{
			try
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=ztmMqdSCDyC5i);
				this.#=zdFvFX7WJ2dLoekhK_s_unCQ=(new #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04=(JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094288))));
			}
			catch
			{
			}
		}
	}

	// Token: 0x0600113F RID: 4415 RVA: 0x00084768 File Offset: 0x00082968
	public #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= #=zORZWLqrH$ZFy5cmRJncJGtg=()
	{
		return this.#=zkx9hcgAM7GDRlPumgAnfapkQoMIPhCvyJA==;
	}

	// Token: 0x06001140 RID: 4416 RVA: 0x00084770 File Offset: 0x00082970
	public void #=zdFvFX7WJ2dLoekhK_s_unCQ=(#=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= #=z$Ib9gYQ=)
	{
		this.#=zkx9hcgAM7GDRlPumgAnfapkQoMIPhCvyJA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001141 RID: 4417 RVA: 0x0008477C File Offset: 0x0008297C
	public string #=zhv7OhlM=()
	{
		if (this.#=zORZWLqrH$ZFy5cmRJncJGtg=() != null)
		{
			return JSONManager.SerializeData(new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094288),
					this.#=zORZWLqrH$ZFy5cmRJncJGtg=().#=zhv7OhlM=()
				}
			});
		}
		return null;
	}

	// Token: 0x04000955 RID: 2389
	private #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04= #=zkx9hcgAM7GDRlPumgAnfapkQoMIPhCvyJA==;
}
