﻿using System;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;

// Token: 0x02000287 RID: 647
internal sealed class #=zmIoOMk5gpONjUdFBWMzEoSA= : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600139E RID: 5022 RVA: 0x00097770 File Offset: 0x00095970
	public #=zmIoOMk5gpONjUdFBWMzEoSA=(Cell #=zLWZxLVM=)
	{
		this.#=zq07FqDs= = #=zLWZxLVM=;
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x00097780 File Offset: 0x00095980
	public #=zmIoOMk5gpONjUdFBWMzEoSA=()
	{
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x00097788 File Offset: 0x00095988
	public #=zmIoOMk5gpONjUdFBWMzEoSA=(string #=zWj7xLq8=)
	{
		this.#=zEh1wLVk= = NExcel.Biff.CellReferenceHelper.getColumn(#=zWj7xLq8=);
		this.#=zg9A8_dw= = NExcel.Biff.CellReferenceHelper.getRow(#=zWj7xLq8=);
		this.#=zEKQLhRCOdkGm = NExcel.Biff.CellReferenceHelper.isColumnRelative(#=zWj7xLq8=);
		this.#=zXY7Hgaj_6YSr = NExcel.Biff.CellReferenceHelper.isRowRelative(#=zWj7xLq8=);
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x000977D8 File Offset: 0x000959D8
	public int #=z85RU4eQ=()
	{
		return this.#=zEh1wLVk=;
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x000977E0 File Offset: 0x000959E0
	public int #=zNMAKc1U=()
	{
		return this.#=zg9A8_dw=;
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x000977E8 File Offset: 0x000959E8
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[5];
		array[0] = ((!base.#=zt$EpC6LMXeRk()) ? #=zwUe4tm5XLL76xe$ToMjBTwE=.#=ztzoFLYo=.#=zd$BbM3Y=() : #=zwUe4tm5XLL76xe$ToMjBTwE=.#=ztzoFLYo=.#=znvQc3vboYqbA());
		IntegerHelper.getTwoBytes(this.#=zg9A8_dw=, array, 1);
		int num = this.#=zEh1wLVk=;
		if (this.#=zXY7Hgaj_6YSr)
		{
			num |= 32768;
		}
		if (this.#=zEKQLhRCOdkGm)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 3);
		return array;
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x0009785C File Offset: 0x00095A5C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zg9A8_dw= = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		this.#=zEh1wLVk= = (@int & 255);
		this.#=zEKQLhRCOdkGm = ((@int & 16384) != 0);
		this.#=zXY7Hgaj_6YSr = ((@int & 32768) != 0);
		return 4;
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x000978BC File Offset: 0x00095ABC
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		NExcel.Biff.CellReferenceHelper.getCellReference(this.#=zEh1wLVk=, !this.#=zEKQLhRCOdkGm, this.#=zg9A8_dw=, !this.#=zXY7Hgaj_6YSr, #=zXvwCnz8=);
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x000978E4 File Offset: 0x00095AE4
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		if (this.#=zEKQLhRCOdkGm)
		{
			this.#=zEh1wLVk= += #=zUFUpoGQeXcCf;
		}
		if (this.#=zXY7Hgaj_6YSr)
		{
			this.#=zg9A8_dw= += #=zJhSli$dVSPlw;
		}
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x00097914 File Offset: 0x00095B14
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (this.#=zEh1wLVk= >= #=zMYEXL$w=)
		{
			this.#=zEh1wLVk=++;
		}
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x00097934 File Offset: 0x00095B34
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (this.#=zEh1wLVk= >= #=zMYEXL$w=)
		{
			this.#=zEh1wLVk=--;
		}
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x00097954 File Offset: 0x00095B54
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zihyUFzs=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (this.#=zg9A8_dw= >= #=zihyUFzs=)
		{
			this.#=zg9A8_dw=++;
		}
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x00097974 File Offset: 0x00095B74
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zihyUFzs=, bool #=z8f56V5lpWtIC)
	{
		if (!#=z8f56V5lpWtIC)
		{
			return;
		}
		if (this.#=zg9A8_dw= >= #=zihyUFzs=)
		{
			this.#=zg9A8_dw=--;
		}
	}

	// Token: 0x04000B56 RID: 2902
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zmIoOMk5gpONjUdFBWMzEoSA=));

	// Token: 0x04000B57 RID: 2903
	private bool #=zEKQLhRCOdkGm;

	// Token: 0x04000B58 RID: 2904
	private bool #=zXY7Hgaj_6YSr;

	// Token: 0x04000B59 RID: 2905
	private int #=zEh1wLVk=;

	// Token: 0x04000B5A RID: 2906
	private int #=zg9A8_dw=;

	// Token: 0x04000B5B RID: 2907
	private Cell #=zq07FqDs=;
}
