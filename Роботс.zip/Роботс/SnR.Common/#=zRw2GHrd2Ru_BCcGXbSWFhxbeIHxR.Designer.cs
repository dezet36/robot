﻿// Token: 0x02000197 RID: 407
internal sealed partial class #=zRw2GHrd2Ru_BCcGXbSWFhxbeIHxR : global::System.Windows.Forms.Form
{
	// Token: 0x06000BEC RID: 3052 RVA: 0x0005CE38 File Offset: 0x0005B038
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400064E RID: 1614
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
