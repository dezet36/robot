﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x020001A2 RID: 418
internal sealed class #=zSpFD6rFEYRcNWdSPpl9nij_K54HaEnnz5cv3cTJoptMC0ydIMg== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000C53 RID: 3155 RVA: 0x00063A60 File Offset: 0x00061C60
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06000C54 RID: 3156 RVA: 0x00063A64 File Offset: 0x00061C64
	protected override void #=zvb5bnug=()
	{
		if (this.#=zcDRV51Ut$7oP is #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==)
		{
			#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA== #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA== = this.#=zcDRV51Ut$7oP as #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==;
			string text = this.#=zBsXSanI=.#=z5g42B6QiMvfs(#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==.#=zs6AfR9w58BN2());
			if (text.Length > 1000)
			{
				object obj = null;
				try
				{
					obj = JSONManager.GetData(text);
				}
				catch
				{
				}
				if (JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966090)) != null)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966080), new object[]
					{
						#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==.#=zs6AfR9w58BN2()
					});
					return;
				}
				if (JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966046), 0) == 23001)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966036), new object[]
					{
						#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==.#=zs6AfR9w58BN2()
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967766), new object[]
				{
					#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==.#=zs6AfR9w58BN2(),
					JSONManager.Cut(text)
				});
				return;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967766), new object[]
				{
					#=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==.#=zs6AfR9w58BN2(),
					JSONManager.Cut(text)
				});
			}
		}
	}
}
