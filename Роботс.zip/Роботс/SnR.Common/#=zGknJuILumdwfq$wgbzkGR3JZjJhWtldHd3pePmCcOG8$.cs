﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000103 RID: 259
internal sealed class #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ : List<#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh>
{
	// Token: 0x060006CA RID: 1738 RVA: 0x000396F0 File Offset: 0x000378F0
	public void #=z20ohAjI=(object[] #=zDFu0lEJ47NBk, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		if (#=zDFu0lEJ47NBk == null)
		{
			return;
		}
		foreach (Dictionary<string, object> dictionary in #=zDFu0lEJ47NBk)
		{
			Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070751));
			if (dictionary2 != null)
			{
				using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary2.Keys.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						string text = enumerator.Current;
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh = new #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh();
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zbsxKkj4=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zogj37CiIebAN(#=zlhLE8UQVU0AG.FindOrCreate(text));
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zqoCq5j01dD5w(JSONManager.ExtractInt(dictionary2, text, 0));
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=z2a_u_nRabC8z(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0));
						#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zFVqZEtnUxmwZ(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0));
						base.Add(#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh);
					}
				}
			}
		}
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x000397EC File Offset: 0x000379EC
	public #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh #=zMCBxPjMHuu3i(int #=zAk8mKBk=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x00039824 File Offset: 0x00037A24
	public List<#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh> #=z6Ka1WhruaSC0(List<int> #=zAIGESyY=)
	{
		List<#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh> list = new List<#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < #=zAIGESyY=.Count; i++)
		{
			int num = #=zAIGESyY=[i];
			for (int j = 0; j < base.Count; j++)
			{
				if (base[j].#=zMuFMjGQ=() == num)
				{
					list.Add(base[j]);
					list2.Add(j);
					break;
				}
			}
		}
		if (list2.Count < base.Count)
		{
			for (int k = 0; k < base.Count; k++)
			{
				if (!list2.Contains(k))
				{
					list.Add(base[k]);
				}
			}
		}
		return list;
	}
}
