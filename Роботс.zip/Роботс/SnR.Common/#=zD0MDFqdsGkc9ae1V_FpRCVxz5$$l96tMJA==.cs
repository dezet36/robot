﻿using System;
using System.Collections.Generic;

// Token: 0x020000D8 RID: 216
internal sealed class #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== : List<#=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==>
{
}
