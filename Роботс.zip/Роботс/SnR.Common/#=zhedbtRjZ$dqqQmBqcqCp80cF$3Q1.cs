﻿using System;
using System.Collections;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x02000254 RID: 596
internal sealed class #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 : #=zrACqpkJvpkMu2ypmK4UXXdQ=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06001205 RID: 4613 RVA: 0x0008A8CC File Offset: 0x00088ACC
	public #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(WorkbookSettings #=z4JisLog=)
	{
		this.#=zFxE_bLJ4E74f = true;
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x0008A8E4 File Offset: 0x00088AE4
	public #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(#=zGjUKOJRgFhfLTz4NT1WbagM= #=zTRA8u0c=, int #=zm8PpuDU=, WorkbookSettings #=z4JisLog=)
	{
		this.#=z3lUqbh8= = #=zTRA8u0c=;
		this.#=zXd8eE_4= = #=zm8PpuDU=;
		this.#=zFxE_bLJ4E74f = false;
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x06001208 RID: 4616 RVA: 0x0008A920 File Offset: 0x00088B20
	internal #=zGjUKOJRgFhfLTz4NT1WbagM= #=zZOFUOewkm7ea()
	{
		return this.#=z3lUqbh8=;
	}

	// Token: 0x06001209 RID: 4617 RVA: 0x0008A928 File Offset: 0x00088B28
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		this.#=zPvcpN1hhM9H8();
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		sbyte[] array2 = new sbyte[0];
		for (int i = array.Length - 1; i >= 0; i--)
		{
			sbyte[] array3 = array[i].#=ztbIWLuVjfGLU();
			sbyte[] array4 = new sbyte[array2.Length + array3.Length];
			Array.Copy(array2, 0, array4, 0, array2.Length);
			Array.Copy(array3, 0, array4, array2.Length, array3.Length);
			array2 = array4;
		}
		sbyte[] array5 = new sbyte[array2.Length + 4];
		Array.Copy(array2, 0, array5, 0, array2.Length);
		array5[array2.Length] = ((!base.#=zt$EpC6LMXeRk()) ? #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zgIROC21YZTQqCTzn6i884to=.#=zd$BbM3Y=() : #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zgIROC21YZTQqCTzn6i884to=.#=znvQc3vboYqbA());
		array5[array2.Length + 1] = (sbyte)this.#=zXd8eE_4=;
		IntegerHelper.getTwoBytes(this.#=z3lUqbh8=.#=zd$BbM3Y=(), array5, array2.Length + 2);
		return array5;
	}

	// Token: 0x0600120A RID: 4618 RVA: 0x0008A9F4 File Offset: 0x00088BF4
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x0600120B RID: 4619 RVA: 0x0008A9F8 File Offset: 0x00088BF8
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zXd8eE_4= = (int)#=zJ5GWysk=[#=z4J_G3VM=];
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 1], #=zJ5GWysk=[#=z4J_G3VM= + 2]);
		this.#=z3lUqbh8= = #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zWTaLiHU=(@int);
		if (this.#=z3lUqbh8= == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zNUFwPq0=)
		{
			throw new FormulaException(FormulaException.#=zAy$UZry2YS1XUZrXrCUyOXk=, @int);
		}
		return 3;
	}

	// Token: 0x0600120C RID: 4620 RVA: 0x0008AA44 File Offset: 0x00088C44
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = new #=zoImewjUBfkPyF1oU_G4atTk=[this.#=zXd8eE_4=];
		for (int i = this.#=zXd8eE_4= - 1; i >= 0; i--)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zoImewjUBfkPyF1oU_G4atTk= = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
			array[i] = #=zoImewjUBfkPyF1oU_G4atTk=;
		}
		for (int j = 0; j < this.#=zXd8eE_4=; j++)
		{
			this.#=zdJYbEvQ=(array[j]);
		}
	}

	// Token: 0x0600120D RID: 4621 RVA: 0x0008AA9C File Offset: 0x00088C9C
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zXvwCnz8=.Append(this.#=z3lUqbh8=.#=zLCn5oL8=(this.#=z6bRJXNQ=));
		#=zXvwCnz8=.Append('(');
		if (this.#=zXd8eE_4= > 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
			if (this.#=zFxE_bLJ4E74f)
			{
				array[0].#=zSpOkW5A=(#=zXvwCnz8=);
				for (int i = 1; i < this.#=zXd8eE_4=; i++)
				{
					#=zXvwCnz8=.Append(',');
					array[i].#=zSpOkW5A=(#=zXvwCnz8=);
				}
			}
			else
			{
				array[this.#=zXd8eE_4= - 1].#=zSpOkW5A=(#=zXvwCnz8=);
				for (int j = this.#=zXd8eE_4= - 2; j >= 0; j--)
				{
					#=zXvwCnz8=.Append(',');
					array[j].#=zSpOkW5A=(#=zXvwCnz8=);
				}
			}
		}
		#=zXvwCnz8=.Append(')');
	}

	// Token: 0x0600120E RID: 4622 RVA: 0x0008AB50 File Offset: 0x00088D50
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
		}
	}

	// Token: 0x0600120F RID: 4623 RVA: 0x0008AB7C File Offset: 0x00088D7C
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001210 RID: 4624 RVA: 0x0008ABAC File Offset: 0x00088DAC
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001211 RID: 4625 RVA: 0x0008ABDC File Offset: 0x00088DDC
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001212 RID: 4626 RVA: 0x0008AC0C File Offset: 0x00088E0C
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06001213 RID: 4627 RVA: 0x0008AC3C File Offset: 0x00088E3C
	private void #=zPvcpN1hhM9H8()
	{
		if (this.#=z3lUqbh8= == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zQpuRhXtcjmOvRTRwrw==)
		{
			#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
			for (int i = array.Length - 1; i >= 0; i--)
			{
				if (array[i] is #=zRFbnANRws$wumebgXSXu5QM=)
				{
					array[i].#=zN73BToKeZLgg();
				}
			}
		}
	}

	// Token: 0x04000A10 RID: 2576
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1));

	// Token: 0x04000A11 RID: 2577
	private #=zGjUKOJRgFhfLTz4NT1WbagM= #=z3lUqbh8=;

	// Token: 0x04000A12 RID: 2578
	private int #=zXd8eE_4=;

	// Token: 0x04000A13 RID: 2579
	private bool #=zFxE_bLJ4E74f;

	// Token: 0x04000A14 RID: 2580
	private WorkbookSettings #=z6bRJXNQ=;
}
