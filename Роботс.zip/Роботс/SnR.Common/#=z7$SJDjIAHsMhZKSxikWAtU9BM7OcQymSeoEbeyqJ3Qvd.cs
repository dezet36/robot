﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;
using Skink.SnR.Common.UserMeta;

// Token: 0x02000086 RID: 134
internal sealed class #=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd
{
	// Token: 0x060003AE RID: 942 RVA: 0x00020A68 File Offset: 0x0001EC68
	public static void #=zNrsrq6kkMTvgTNVx_j_LZu4=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=z1XjzHqnI5znaF40b1A==, #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4)
	{
		#=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zV_Jaipud2OIj6AvV0w== #=zV_Jaipud2OIj6AvV0w== = new #=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zV_Jaipud2OIj6AvV0w==();
		#=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.#=zi1hFJwI=();
		#=zV_Jaipud2OIj6AvV0w==.#=zYdMYE6q9ijwU = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.Find(new Predicate<#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky>(#=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zyDNvciU=.#=zLkw0NRU=.#=zKzA_S9m2lN_ndg675aEifSZYcEviVFyg_w==));
		#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== = #=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zV_Jaipud2OIj6AvV0w==.#=zMqgCli5uyurumw5rn8obvq4p53wJd43dMg==));
		DateTime t = (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== != null) ? #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=z71_rggORFKZ5() : DateTime.MinValue;
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = new List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>();
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in #=z1XjzHqnI5znaF40b1A==)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() != #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)2 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Count > 0)
			{
				Task task = null;
				foreach (Task task2 in #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==())
				{
					if (task2.Type == TaskTypes.SendToAcropolImmediate && task2 is #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== && (task2 as #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==).#=zuFPZLKs=() == #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=().ToString())
					{
						task = task2;
						break;
					}
				}
				if (task == null)
				{
					list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==);
				}
			}
		}
		if (list.Count > 0)
		{
			object #=zBCxv0_Eazs = #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zBCxv0_Eazs01;
			lock (#=zBCxv0_Eazs)
			{
				foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in list)
				{
					List<int> list2 = new List<int>();
					switch (#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolTroopType)
					{
					case ActionSettings.SentToAcropolType.OnlyAttackers:
					case ActionSettings.SentToAcropolType.GarrisonDefendersAndScouts:
						list2.Add(1);
						break;
					case ActionSettings.SentToAcropolType.GarrisonDefenders:
						list2.Add(1);
						list2.Add(3);
						break;
					}
					UnitSquadCollection unitSquadCollection;
					if (list2.Count == 0)
					{
						unitSquadCollection = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD();
					}
					else
					{
						unitSquadCollection = new UnitSquadCollection();
						for (int i = 0; i < #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD().Count; i++)
						{
							UnitSquad unitSquad = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD()[i];
							if (list2.Contains((int)unitSquad.Type.Function))
							{
								unitSquadCollection.Add(unitSquad);
							}
						}
					}
					if (unitSquadCollection.Count > 0 && (unitSquadCollection.Count > 1 || unitSquadCollection[0].Number > 1))
					{
						DateTime dateTime = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==());
						if (dateTime > t)
						{
							DateTime #=zxSBcx18= = dateTime - TimeSpan.FromSeconds(15.0);
							Dictionary<string, object> dictionary = new Dictionary<string, object>();
							if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z70nxNNOsj8r_VDWUf_jWQh8=() != null && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z70nxNNOsj8r_VDWUf_jWQh8=()[ResourceTypes.Grain] > 1000 && #=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobIsBuyTroopsAfterRob && #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoAutoRobbery)
							{
								dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964460)] = 1;
							}
							string #=zQI5IZCs= = JSONManager.SerializeData(dictionary);
							Task task3 = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSources.ManualNotSavable, TaskSeverities.Immediate, TaskTypes.SendToAcropolImmediate, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false, TaskSendUnitTypes.RecallReinforcement, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z$lI_VTM=().ToString(), #=zQI5IZCs=, unitSquadCollection.ToString(), 0, 0);
							task3.Options |= TaskOptions.NoDataRequired;
							#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(task3);
							#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964443), new object[]
							{
								dateTime.ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068281))
							});
						}
					}
				}
				#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Sort();
			}
		}
	}

	// Token: 0x060003AF RID: 943 RVA: 0x00020E94 File Offset: 0x0001F094
	public static void #=zx6mAD3WBJ$C1JPgizQctvRQ=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=z1XjzHqnI5znaF40b1A==)
	{
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = new List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>();
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in #=z1XjzHqnI5znaF40b1A==)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() != #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)2 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z70nxNNOsj8r_VDWUf_jWQh8=() != null && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z70nxNNOsj8r_VDWUf_jWQh8=()[ResourceTypes.Grain] > 1000)
			{
				Task task = null;
				foreach (Task task2 in #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==())
				{
					if (task2.Type == TaskTypes.HireTroopsImmediate && task2 is #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== && (task2 as #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==).#=zs6AfR9w58BN2() == #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=())
					{
						task = task2;
						break;
					}
				}
				if (task == null)
				{
					list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==);
				}
			}
		}
		if (list.Count > 0)
		{
			object #=zBCxv0_Eazs = #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zBCxv0_Eazs01;
			lock (#=zBCxv0_Eazs)
			{
				foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in list)
				{
					DateTime #=zxSBcx18= = #=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==()) - TimeSpan.FromSeconds(15.0);
					Task task3 = new #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z$lI_VTM=(), TaskSources.ManualNotSavable, TaskSeverities.Immediate, TaskTypes.HireTroopsImmediate, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
					task3.Options |= TaskOptions.NoDataRequired;
					#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Add(task3);
				}
				#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Sort();
			}
		}
	}

	// Token: 0x02000087 RID: 135
	private sealed class #=zV_Jaipud2OIj6AvV0w==
	{
		// Token: 0x060003B1 RID: 945 RVA: 0x000210A0 File Offset: 0x0001F2A0
		internal bool #=zMqgCli5uyurumw5rn8obvq4p53wJd43dMg==(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return this.#=zYdMYE6q9ijwU.#=z0gRgrrIGr5L_().Contains(#=zQrqFdos=.#=zMuFMjGQ=());
		}

		// Token: 0x0400014A RID: 330
		public #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zYdMYE6q9ijwU;
	}

	// Token: 0x02000088 RID: 136
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x060003B4 RID: 948 RVA: 0x000210CC File Offset: 0x0001F2CC
		internal bool #=zKzA_S9m2lN_ndg675aEifSZYcEviVFyg_w==(#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zJce$Sys=)
		{
			return #=zJce$Sys=.#=zMuFMjGQ=() == 10055;
		}

		// Token: 0x0400014B RID: 331
		public static readonly #=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zyDNvciU= #=zLkw0NRU= = new #=z7$SJDjIAHsMhZKSxikWAtU9BM7OcQymSeoEbeyqJ3Qvd.#=zyDNvciU=();

		// Token: 0x0400014C RID: 332
		public static Predicate<#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky> #=zSN9dY7vFLj_oBqoMkw==;
	}
}
