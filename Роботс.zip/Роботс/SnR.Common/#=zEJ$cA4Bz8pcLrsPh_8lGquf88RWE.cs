﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020000E1 RID: 225
internal sealed class #=zEJ$cA4Bz8pcLrsPh_8lGquf88RWE : #=zIysmcffbrCbtDK6qpNil6NA=
{
	// Token: 0x06000603 RID: 1539 RVA: 0x0003118C File Offset: 0x0002F38C
	internal #=zEJ$cA4Bz8pcLrsPh_8lGquf88RWE(Record #=zihyUFzs=) : base(Type.LEFTMARGIN, #=zihyUFzs=)
	{
	}
}
