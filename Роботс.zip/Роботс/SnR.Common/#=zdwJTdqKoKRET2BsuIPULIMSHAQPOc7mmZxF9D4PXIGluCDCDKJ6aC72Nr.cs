﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000222 RID: 546
internal sealed class #=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060010C0 RID: 4288 RVA: 0x0008093C File Offset: 0x0007EB3C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=zwn5aCwWTvPV4 = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
		this.#=zFGZhAdTFY4nt1H_JUw== = #=zuJjQ1XU=.#=zjp4T2o8sDgUmdadFiw==();
	}

	// Token: 0x060010C1 RID: 4289 RVA: 0x00080964 File Offset: 0x0007EB64
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		List<#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=> list = new List<#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=>();
		list.Add(#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=().#=zd634hMCtcd$T(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().ItemTypeId));
		for (int i = 0; i < #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().AltItemTypeIds.Count; i++)
		{
			list.Add(#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=().#=zd634hMCtcd$T(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().AltItemTypeIds[i]));
		}
		List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> list2 = new List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>();
		List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> list3 = new List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>();
		if (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsUseEffect)
		{
			List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> list4 = new List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>();
			foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= in this.#=zCY4az9$WUjLsEJ7fgg==.Values)
			{
				for (int j = 0; j < list.Count; j++)
				{
					#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = list[j];
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zd$BbM3Y=() == #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zd$BbM3Y=() || #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zMuFMjGQ=() == #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=())
					{
						list4.Add(new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_()));
					}
				}
			}
			list4.Sort(new #=zxAOF4gsFJUxe2TtLxrT4ECzagpIl7qBMHlmoPJ8=((#=zxAOF4gsFJUxe2TtLxrT4ECzagpIl7qBMHlmoPJ8=.#=zzCQAPJBFMi3_)1));
			double num = #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Effect - #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zVJyJYuKV4nbu();
			for (int k = list4.Count - 1; k >= 0; k--)
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = list4[k];
				if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH() <= num)
				{
					int num2 = (int)Math.Floor(num / #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH());
					if (num2 > #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_())
					{
						num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
					}
					num -= (double)num2 * #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH();
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() - num2);
					if (num == #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH() && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() > 0)
					{
						num2++;
						num = 0.0;
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() - 1);
					}
					list2.Add(new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=(), num2));
					if (num <= 0.0)
					{
						break;
					}
				}
			}
			if (num > 0.0)
			{
				for (int l = 0; l < list4.Count; l++)
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3 = list4[l];
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4 = null;
					for (int m = 0; m < list2.Count; m++)
					{
						if (list2[m].#=zq2bPTdY=().#=zMuFMjGQ=() == #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zq2bPTdY=().#=zMuFMjGQ=())
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4 = list2[m];
							break;
						}
					}
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4 == null)
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4 = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zq2bPTdY=(), 0);
						list2.Add(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4);
					}
					int num3 = (int)Math.Ceiling(num / #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zq2bPTdY=().#=zjw43QGFcPyHH());
					if (num3 > #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zlIXJ9$NfUZc_())
					{
						num3 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zlIXJ9$NfUZc_();
					}
					num -= (double)num3 * #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zq2bPTdY=().#=zjw43QGFcPyHH();
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zlIXJ9$NfUZc_() - num3);
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=4.#=zlIXJ9$NfUZc_() + num3);
					if (num <= 0.0)
					{
						break;
					}
				}
			}
			if (num > 0.0 && #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsBuyAndUse && #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().ItemTypeId == 500)
			{
				#=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX = #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX.#=zPxk4qAkYdYmplkSIOw==(this.#=zFGZhAdTFY4nt1H_JUw==);
				if (#=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX != null)
				{
					list3.Add(new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX), 1));
					list2.Clear();
				}
			}
		}
		else
		{
			int num4 = #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount - #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zr6zmRf3YG3UG();
			for (int n = 0; n < list.Count; n++)
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5 = this.#=zCY4az9$WUjLsEJ7fgg==[list[n].#=zMuFMjGQ=()];
				if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5 != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5.#=zlIXJ9$NfUZc_() > 0)
				{
					int num5 = (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5.#=zlIXJ9$NfUZc_() >= num4) ? num4 : #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5.#=zlIXJ9$NfUZc_();
					list2.Add(new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=5.#=zq2bPTdY=(), num5));
					num4 -= num5;
					if (num4 <= 0)
					{
						break;
					}
				}
			}
			if (num4 > 0)
			{
				if (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsBuyAndUse)
				{
					list3.Add(new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(list[0], num4));
				}
				else if (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsDontUsePartially)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977968), new object[]
					{
						list[0].#=zkfqcY3I=()
					});
					list2.Clear();
				}
			}
		}
		if (list3.Count > 0)
		{
			foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6 in list3)
			{
				string text = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zq2bPTdY=().#=zMuFMjGQ=(), #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zlIXJ9$NfUZc_(), false);
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923954), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zq2bPTdY=().#=zkfqcY3I=(),
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zlIXJ9$NfUZc_()
					});
					list2.Add(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6);
				}
				else
				{
					text = JSONManager.Cut(text);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924146), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zq2bPTdY=().#=zkfqcY3I=(),
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=6.#=zlIXJ9$NfUZc_(),
						text
					});
				}
			}
		}
		if (list2.Count > 0)
		{
			foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7 in list2)
			{
				string text2 = #=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra.#=zOctqvmBd0r83lEcEiiCTW1M=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7, this.#=zwn5aCwWTvPV4);
				if (!string.IsNullOrEmpty(text2))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, text2, Array.Empty<object>());
				}
				else
				{
					int num6;
					int num7;
					if (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsUseOneAtATime)
					{
						num6 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zlIXJ9$NfUZc_();
						num7 = 1;
					}
					else
					{
						num6 = 1;
						num7 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zlIXJ9$NfUZc_();
					}
					for (int num8 = 0; num8 < num6; num8++)
					{
						#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zq2bPTdY=(), num7);
						if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15() != null)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926957), new object[]
							{
								#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zq2bPTdY=().#=zkfqcY3I=(),
								#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zlIXJ9$NfUZc_()
							});
							#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXzFijdeUdQgj(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zq2bPTdY=(), #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zlIXJ9$NfUZc_());
						}
						else if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926895), new object[]
							{
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zq2bPTdY=().#=zkfqcY3I=(),
								num7
							});
							#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXzFijdeUdQgj(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zq2bPTdY=(), num7);
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926506), new object[]
							{
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=7.#=zq2bPTdY=().#=zkfqcY3I=(),
								num7,
								JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
							});
						}
					}
				}
			}
		}
	}

	// Token: 0x060010C2 RID: 4290 RVA: 0x00081160 File Offset: 0x0007F360
	public static string #=zOctqvmBd0r83lEcEiiCTW1M=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zsbwXxuA=, #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zQwNUa7X4qnHM)
	{
		Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>
		{
			{
				11616,
				new List<int>
				{
					11507,
					11509,
					11511,
					11513
				}
			}
		};
		using (Dictionary<int, List<int>>.KeyCollection.Enumerator enumerator = dictionary.Keys.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				#=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra.#=zAzqsXKU9G9G$qkIMsw== #=zAzqsXKU9G9G$qkIMsw== = new #=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra.#=zAzqsXKU9G9G$qkIMsw==();
				#=zAzqsXKU9G9G$qkIMsw==.#=zD5HlgsI= = enumerator.Current;
				if (dictionary[#=zAzqsXKU9G9G$qkIMsw==.#=zD5HlgsI=].Contains(#=zsbwXxuA=.#=zq2bPTdY=().#=zMuFMjGQ=()))
				{
					#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== = #=zQwNUa7X4qnHM.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zAzqsXKU9G9G$qkIMsw==.#=zXAY5wbI55ufnhmUaeRDaioKAGgmNe2sshA==));
					if (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== != null && #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=z71_rggORFKZ5() > DateTime.Now)
					{
						#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=().#=zd634hMCtcd$T(#=zAzqsXKU9G9G$qkIMsw==.#=zD5HlgsI=);
						return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977941), new object[]
						{
							#=zsbwXxuA=.#=zq2bPTdY=().#=zkfqcY3I=(),
							#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zkfqcY3I=()
						}).ToString();
					}
				}
			}
		}
		return null;
	}

	// Token: 0x0400090D RID: 2317
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x0400090E RID: 2318
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4;

	// Token: 0x0400090F RID: 2319
	private int #=zFGZhAdTFY4nt1H_JUw==;

	// Token: 0x02000223 RID: 547
	private sealed class #=zAzqsXKU9G9G$qkIMsw==
	{
		// Token: 0x060010C4 RID: 4292 RVA: 0x00081298 File Offset: 0x0007F498
		internal bool #=zXAY5wbI55ufnhmUaeRDaioKAGgmNe2sshA==(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == this.#=zD5HlgsI=;
		}

		// Token: 0x04000910 RID: 2320
		public int #=zD5HlgsI=;
	}
}
