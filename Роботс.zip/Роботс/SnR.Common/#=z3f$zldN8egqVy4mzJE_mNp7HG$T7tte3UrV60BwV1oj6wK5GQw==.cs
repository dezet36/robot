﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000052 RID: 82
internal sealed class #=z3f$zldN8egqVy4mzJE_mNp7HG$T7tte3UrV60BwV1oj6wK5GQw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600027E RID: 638 RVA: 0x00016208 File Offset: 0x00014408
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x0600027F RID: 639 RVA: 0x0001620C File Offset: 0x0001440C
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==))
		{
			return;
		}
		#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== = this.#=zcDRV51Ut$7oP as #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==;
		UnitSquadCollection unitSquadCollection = UnitSquadCollection.FromString(#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zlIXJ9$NfUZc_(), null);
		DateTime d = #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.ExecutionTime + TimeSpan.FromSeconds(15.0);
		bool flag = JSONManager.ExtractInt((!string.IsNullOrEmpty(#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.Details)) ? ((Dictionary<string, object>)JSONManager.DeserializeData(#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.Details)) : null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964460), 0) == 1;
		int num = (int)(d - DateTime.Now).TotalMilliseconds;
		if (num > 0)
		{
			Thread.Sleep(num + 1);
		}
		string text = this.#=zBsXSanI=.#=zj6mJJFZU84bVSPLgcS8vCmc=(unitSquadCollection);
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878900), new object[]
			{
				unitSquadCollection.ToStringLabels()
			});
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878871), new object[]
			{
				unitSquadCollection.ToStringLabels(),
				JSONManager.Cut(text)
			});
		}
		object data = JSONManager.GetData(text);
		base.#=zL1HTbwC75LO$(data);
		if (flag)
		{
			#=zcAioOxLrSCaNUY8WB6BWlWow_$LLreAAm98rBuM7Nvlpo_dosw==.#=zwqF5KngciPEuUAe8xmYIVt0=(this.#=zG2wnL_q7IxpD, data);
		}
	}
}
