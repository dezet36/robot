﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x0200027E RID: 638
internal sealed class #=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns= : #=zM2IXTcon_Hd$W3PwdqAcldAgZzVT
{
	// Token: 0x06001341 RID: 4929 RVA: 0x00095E9C File Offset: 0x0009409C
	public #=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns=(Dictionary<string, object> #=zYEcCIbg=)
	{
		this.#=zbsxKkj4=(Convert.ToInt32(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
		this.#=zI74NzG$2ecMvvw_Hiw==(Convert.ToInt32(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899)]));
		this.#=zMU3h5OahHKt6(Convert.ToInt32(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883)]));
		this.#=zFzGvi_S6jJhE(Convert.ToInt32(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
		this.#=z9KnRZHNhKWt7(Convert.ToDouble(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]));
		this.#=zGg2E1S_O$_XC(Convert.ToInt32(#=zYEcCIbg=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)]) == 1);
	}

	// Token: 0x06001342 RID: 4930 RVA: 0x00095F54 File Offset: 0x00094154
	[CompilerGenerated]
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001343 RID: 4931 RVA: 0x00095F5C File Offset: 0x0009415C
	private void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001344 RID: 4932 RVA: 0x00095F68 File Offset: 0x00094168
	public int #=zFMDiymuLQ7_4()
	{
		return 0;
	}

	// Token: 0x06001345 RID: 4933 RVA: 0x00095F6C File Offset: 0x0009416C
	public string #=zTbtwDpWhYGtF()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070075), new object[]
		{
			#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070061)),
			this.#=zaKAy47_E$9SRuF6oiw==(),
			this.#=ztj93y6niVpCR(),
			this.#=zvnZc$RhG_1Du()
		});
	}

	// Token: 0x06001346 RID: 4934 RVA: 0x00095FCC File Offset: 0x000941CC
	[CompilerGenerated]
	public int #=zaKAy47_E$9SRuF6oiw==()
	{
		return this.#=zg9DHdRJeKrYsJIc4CEiCbn4=;
	}

	// Token: 0x06001347 RID: 4935 RVA: 0x00095FD4 File Offset: 0x000941D4
	private void #=zI74NzG$2ecMvvw_Hiw==(int #=z$Ib9gYQ=)
	{
		this.#=zg9DHdRJeKrYsJIc4CEiCbn4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001348 RID: 4936 RVA: 0x00095FE0 File Offset: 0x000941E0
	[CompilerGenerated]
	public int #=ztj93y6niVpCR()
	{
		return this.#=zW7kHJvkAORBWJxF1eQ==;
	}

	// Token: 0x06001349 RID: 4937 RVA: 0x00095FE8 File Offset: 0x000941E8
	private void #=zMU3h5OahHKt6(int #=z$Ib9gYQ=)
	{
		this.#=zW7kHJvkAORBWJxF1eQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600134A RID: 4938 RVA: 0x00095FF4 File Offset: 0x000941F4
	public int #=zVm_gjb4pLtQN()
	{
		return 0;
	}

	// Token: 0x0600134B RID: 4939 RVA: 0x00095FF8 File Offset: 0x000941F8
	[CompilerGenerated]
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x0600134C RID: 4940 RVA: 0x00096000 File Offset: 0x00094200
	private void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600134D RID: 4941 RVA: 0x0009600C File Offset: 0x0009420C
	public double #=z5iePdUZjnAHd()
	{
		return this.#=zrd8wq0PM626XQEKZ4g==;
	}

	// Token: 0x0600134E RID: 4942 RVA: 0x00096014 File Offset: 0x00094214
	private void #=z9KnRZHNhKWt7(double #=z$Ib9gYQ=)
	{
		this.#=zrd8wq0PM626XQEKZ4g== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600134F RID: 4943 RVA: 0x00096020 File Offset: 0x00094220
	public bool #=ztP$zSGbniHTJ()
	{
		return this.#=zmc2nR24tjsJgpF420A==;
	}

	// Token: 0x06001350 RID: 4944 RVA: 0x00096028 File Offset: 0x00094228
	private void #=zGg2E1S_O$_XC(bool #=z$Ib9gYQ=)
	{
		this.#=zmc2nR24tjsJgpF420A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001351 RID: 4945 RVA: 0x00096034 File Offset: 0x00094234
	public string #=zPEhDdtHVGNHR()
	{
		return string.Empty;
	}

	// Token: 0x06001352 RID: 4946 RVA: 0x0009603C File Offset: 0x0009423C
	public string #=zNTEClmggtyu4()
	{
		return string.Empty;
	}

	// Token: 0x06001353 RID: 4947 RVA: 0x00096044 File Offset: 0x00094244
	public override string ToString()
	{
		return this.#=zTbtwDpWhYGtF();
	}

	// Token: 0x04000B1B RID: 2843
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000B1C RID: 2844
	private int #=zg9DHdRJeKrYsJIc4CEiCbn4=;

	// Token: 0x04000B1D RID: 2845
	private int #=zW7kHJvkAORBWJxF1eQ==;

	// Token: 0x04000B1E RID: 2846
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x04000B1F RID: 2847
	private double #=zrd8wq0PM626XQEKZ4g==;

	// Token: 0x04000B20 RID: 2848
	private bool #=zmc2nR24tjsJgpF420A==;
}
