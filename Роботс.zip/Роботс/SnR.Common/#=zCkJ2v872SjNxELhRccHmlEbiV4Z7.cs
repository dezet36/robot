﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;

// Token: 0x020000D5 RID: 213
internal sealed class #=zCkJ2v872SjNxELhRccHmlEbiV4Z7
{
	// Token: 0x060005B8 RID: 1464 RVA: 0x0002F9CC File Offset: 0x0002DBCC
	public #=zCkJ2v872SjNxELhRccHmlEbiV4Z7(#=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zHVme10f0LAof)
	{
		this.#=zCfkx7npKnqtktLJ6$g== = DateTime.MinValue;
		this.#=zyfyFTf4= = #=zHVme10f0LAof;
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x0002F9FC File Offset: 0x0002DBFC
	public static void #=zoR8PNRNYefFV(List<ProxyInfo> #=z47HdmrEE_7KL)
	{
		if (!#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=z_Ihd7uV3C6HaosTTMg==)
		{
			object obj = #=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (!#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=z_Ihd7uV3C6HaosTTMg==)
				{
					try
					{
						#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=z_Ihd7uV3C6HaosTTMg== = true;
						new Thread(new ParameterizedThreadStart(#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=zBHBZQj6yVAJS)).Start(#=z47HdmrEE_7KL);
					}
					catch (Exception #=zN_s5Z5A=)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
						#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=z_Ihd7uV3C6HaosTTMg== = false;
					}
				}
			}
		}
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x0002FA80 File Offset: 0x0002DC80
	private static void #=zBHBZQj6yVAJS(object #=zwUfPLzMnExqeP2W60Q==)
	{
		try
		{
			List<ProxyInfo> list = (List<ProxyInfo>)#=zwUfPLzMnExqeP2W60Q==;
			for (int i = list.Count - 1; i >= 0; i--)
			{
				if (GameApplicationData.#=zv3f1uqjnJC$0())
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)8, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935379), Array.Empty<object>());
				}
				try
				{
					if (i < list.Count)
					{
						ProxyInfo proxyInfo = list[i];
						if (proxyInfo.State == ProxyStates.Unchecked)
						{
							if (#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=zIR5HcVSIfROf(proxyInfo))
							{
								proxyInfo.State = ProxyStates.Ok;
							}
							else
							{
								proxyInfo.State = ProxyStates.Unworking;
							}
						}
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
				}
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=2);
		}
		finally
		{
			#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=z_Ihd7uV3C6HaosTTMg== = false;
		}
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x0002FB40 File Offset: 0x0002DD40
	private static bool #=zIR5HcVSIfROf(ProxyInfo #=zsHG$Y6w=)
	{
		string #=z1vcRUAMD40W = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938700);
		bool result;
		try
		{
			string text = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zNDs2uEY=(#=z1vcRUAMD40W, 1, #=zsHG$Y6w=);
			if (text == null)
			{
				result = false;
			}
			else if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				result = false;
			}
			else
			{
				result = true;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x0400025F RID: 607
	private DateTime #=zCfkx7npKnqtktLJ6$g==;

	// Token: 0x04000260 RID: 608
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000261 RID: 609
	private static bool #=z_Ihd7uV3C6HaosTTMg== = false;

	// Token: 0x04000262 RID: 610
	private #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zyfyFTf4=;
}
