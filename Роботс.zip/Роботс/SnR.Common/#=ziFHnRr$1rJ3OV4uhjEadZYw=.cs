﻿using System;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x0200025C RID: 604
internal sealed class #=ziFHnRr$1rJ3OV4uhjEadZYw= : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x06001255 RID: 4693 RVA: 0x00090528 File Offset: 0x0008E728
	public #=ziFHnRr$1rJ3OV4uhjEadZYw=(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=zK5y0_mc= = this.Instance;
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		this.#=zoLA$hk4= = IntegerHelper.getInt(array[0], array[1], array[2], array[3]);
		this.#=zTNCQ73g= = IntegerHelper.getInt(array[4], array[5], array[6], array[7]);
	}

	// Token: 0x06001256 RID: 4694 RVA: 0x00090580 File Offset: 0x0008E780
	public #=ziFHnRr$1rJ3OV4uhjEadZYw=(int #=zGb7A6IvAklNb2verzA==) : base(EscherRecordType.DG)
	{
		this.#=zK5y0_mc= = 1;
		this.#=zoLA$hk4= = #=zGb7A6IvAklNb2verzA== + 1;
		this.#=zTNCQ73g= = 1024 + this.#=zoLA$hk4= + 1;
		this.Instance = this.#=zK5y0_mc=;
	}

	// Token: 0x06001257 RID: 4695 RVA: 0x000905C0 File Offset: 0x0008E7C0
	public int #=zCOLhRySs7QKK()
	{
		return this.#=zK5y0_mc=;
	}

	// Token: 0x17000059 RID: 89
	// (get) Token: 0x06001258 RID: 4696 RVA: 0x000905C8 File Offset: 0x0008E7C8
	public override sbyte[] Data
	{
		get
		{
			this.#=zJ5GWysk= = new sbyte[8];
			IntegerHelper.getFourBytes(this.#=zoLA$hk4=, this.#=zJ5GWysk=, 0);
			IntegerHelper.getFourBytes(this.#=zTNCQ73g=, this.#=zJ5GWysk=, 4);
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x04000A95 RID: 2709
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x04000A96 RID: 2710
	private int #=zK5y0_mc=;

	// Token: 0x04000A97 RID: 2711
	private int #=zoLA$hk4=;

	// Token: 0x04000A98 RID: 2712
	private int #=zTNCQ73g=;
}
