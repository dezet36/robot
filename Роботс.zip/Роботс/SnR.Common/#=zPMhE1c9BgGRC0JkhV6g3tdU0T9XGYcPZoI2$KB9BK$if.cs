﻿using System;
using System.Collections.Generic;

// Token: 0x0200017E RID: 382
internal sealed class #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if : IComparer<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>
{
	// Token: 0x06000AF4 RID: 2804 RVA: 0x00054B20 File Offset: 0x00052D20
	public #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if(#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs= #=zvRLj9WQ=, int #=zTDtB7zv7BfB4)
	{
		this.#=zQ4_NWTk= = #=zvRLj9WQ=;
		this.#=z7PeX7p1J$Z7N = #=zTDtB7zv7BfB4;
	}

	// Token: 0x06000AF5 RID: 2805 RVA: 0x00054B38 File Offset: 0x00052D38
	public int Compare(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zCaYgp6U=, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zldMR4Hg=)
	{
		switch (this.#=zQ4_NWTk=)
		{
		case (#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)0:
		{
			int num = #=zCaYgp6U=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zldMR4Hg=.#=zaKAy47_E$9SRuF6oiw==());
			if (num != 0)
			{
				return num;
			}
			num = #=zCaYgp6U=.#=zVaUA5_qegiur().CompareTo(#=zldMR4Hg=.#=zVaUA5_qegiur());
			if (num != 0)
			{
				return num;
			}
			double num2 = #=zCaYgp6U=.#=zmLisBvRBDI2r();
			return num2.CompareTo(#=zldMR4Hg=.#=zmLisBvRBDI2r());
		}
		case (#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)1:
		{
			double num2 = (#=zldMR4Hg=.#=zVaUA5_qegiur() >= this.#=z7PeX7p1J$Z7N) ? #=zldMR4Hg=.#=zA8HgqWet8sw7() : 0.0;
			return num2.CompareTo((#=zCaYgp6U=.#=zVaUA5_qegiur() >= this.#=z7PeX7p1J$Z7N) ? #=zCaYgp6U=.#=zA8HgqWet8sw7() : 0.0);
		}
		case (#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)2:
		{
			double num2 = (#=zldMR4Hg=.#=zVaUA5_qegiur() >= this.#=z7PeX7p1J$Z7N) ? #=zldMR4Hg=.#=zmLisBvRBDI2r() : 0.0;
			return num2.CompareTo((#=zCaYgp6U=.#=zVaUA5_qegiur() >= this.#=z7PeX7p1J$Z7N) ? #=zCaYgp6U=.#=zmLisBvRBDI2r() : 0.0);
		}
		default:
			return 0;
		}
	}

	// Token: 0x040005D9 RID: 1497
	private #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs= #=zQ4_NWTk=;

	// Token: 0x040005DA RID: 1498
	private int #=z7PeX7p1J$Z7N;

	// Token: 0x0200017F RID: 383
	public enum #=zArez$Gs=
	{

	}
}
