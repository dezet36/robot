﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;

// Token: 0x0200003D RID: 61
internal sealed class #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==
{
	// Token: 0x060001EB RID: 491 RVA: 0x00012F38 File Offset: 0x00011138
	public #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==(#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD, bool #=z_sNmetJrIPOP)
	{
		this.#=zC68QI$8=(#=zMEwuTGAUgTDD, #=z_sNmetJrIPOP);
	}

	// Token: 0x060001EC RID: 492 RVA: 0x00012F48 File Offset: 0x00011148
	private void #=zC68QI$8=(#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD, bool #=z_sNmetJrIPOP)
	{
		this.#=zeQR4lQ$1_B1yvoLI1g== = (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Nords);
		this.#=zzE4jG$VMEYruQ4Bp3eUYAdA= = false;
		if (#=z_sNmetJrIPOP)
		{
			using (List<#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==>.Enumerator enumerator = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=().GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.World == Worlds.Veor)
					{
						this.#=zzE4jG$VMEYruQ4Bp3eUYAdA= = true;
						break;
					}
				}
			}
		}
		this.#=zGJZ5BFTjtmtw = new List<#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=>();
		foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== in #=zMEwuTGAUgTDD)
		{
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7())
			{
				this.#=zGJZ5BFTjtmtw.Add(this.#=zhlj9a4JUzMiQ(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==));
			}
		}
	}

	// Token: 0x060001ED RID: 493 RVA: 0x00013018 File Offset: 0x00011218
	public bool #=z0vSd8LyXizI7(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A)
	{
		return !this.#=zGJZ5BFTjtmtw.Contains(#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zhlj9a4JUzMiQ(#=z3v_Pt336Xf0A));
	}

	// Token: 0x060001EE RID: 494 RVA: 0x00013030 File Offset: 0x00011230
	public bool #=z0vSd8LyXizI7(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z3v_Pt336Xf0A)
	{
		return !this.#=zGJZ5BFTjtmtw.Contains(this.#=zhlj9a4JUzMiQ(#=z3v_Pt336Xf0A));
	}

	// Token: 0x060001EF RID: 495 RVA: 0x00013048 File Offset: 0x00011248
	public void #=zR__3$vI=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A)
	{
		this.#=zGJZ5BFTjtmtw.Add(#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zhlj9a4JUzMiQ(#=z3v_Pt336Xf0A));
	}

	// Token: 0x060001F0 RID: 496 RVA: 0x0001305C File Offset: 0x0001125C
	public void #=zR__3$vI=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z3v_Pt336Xf0A)
	{
		this.#=zGJZ5BFTjtmtw.Add(this.#=zhlj9a4JUzMiQ(#=z3v_Pt336Xf0A));
	}

	// Token: 0x060001F1 RID: 497 RVA: 0x00013070 File Offset: 0x00011270
	public static #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs= #=zhlj9a4JUzMiQ(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A)
	{
		if (#=z3v_Pt336Xf0A.World == Worlds.Legend)
		{
			return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)3;
		}
		if (#=z3v_Pt336Xf0A.World == Worlds.Veor)
		{
			return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)2;
		}
		return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)0;
	}

	// Token: 0x060001F2 RID: 498 RVA: 0x0001308C File Offset: 0x0001128C
	private #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs= #=zhlj9a4JUzMiQ(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z3v_Pt336Xf0A)
	{
		if (#=z3v_Pt336Xf0A.#=zq2bPTdY=().World == Worlds.Legend)
		{
			return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)3;
		}
		if (#=z3v_Pt336Xf0A.#=zq2bPTdY=().World == Worlds.Veor)
		{
			return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)2;
		}
		if (#=z3v_Pt336Xf0A.#=zvnZc$RhG_1Du() > 0 && this.#=zeQR4lQ$1_B1yvoLI1g==)
		{
			return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)1;
		}
		return (#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=)0;
	}

	// Token: 0x04000071 RID: 113
	private bool #=zeQR4lQ$1_B1yvoLI1g==;

	// Token: 0x04000072 RID: 114
	private bool #=zzE4jG$VMEYruQ4Bp3eUYAdA=;

	// Token: 0x04000073 RID: 115
	private List<#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=> #=zGJZ5BFTjtmtw;

	// Token: 0x0200003E RID: 62
	public enum #=zArez$Gs=
	{

	}
}
