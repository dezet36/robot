﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001B2 RID: 434
internal sealed class #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew== : List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>
{
	// Token: 0x06000D12 RID: 3346 RVA: 0x00067A5C File Offset: 0x00065C5C
	public #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew==()
	{
		this.#=zqfA74JKFKldk(new int[2]);
	}

	// Token: 0x06000D13 RID: 3347 RVA: 0x00067A70 File Offset: 0x00065C70
	public #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew==(Dictionary<string, object> #=ziEgMPELuAz2O, #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=zY6BuiKQeE9Eb)
	{
		object[] array = JSONManager.ExtractArray(#=ziEgMPELuAz2O, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== item = new #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==((Dictionary<string, object>)array[i], #=zY6BuiKQeE9Eb, false);
				base.Add(item);
			}
		}
		object[] array2 = JSONManager.ExtractArray(#=ziEgMPELuAz2O, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237));
		if (array2 != null)
		{
			for (int j = 0; j < array2.Length; j++)
			{
				#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== item2 = new #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==((Dictionary<string, object>)array2[j], #=zY6BuiKQeE9Eb, true);
				base.Add(item2);
			}
		}
		this.#=zqfA74JKFKldk(new int[2]);
		this.#=zi0n5Dw6d6LiE()[0] = JSONManager.ExtractInt(#=ziEgMPELuAz2O, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
		this.#=zi0n5Dw6d6LiE()[1] = JSONManager.ExtractInt(#=ziEgMPELuAz2O, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0);
	}

	// Token: 0x06000D14 RID: 3348 RVA: 0x00067B38 File Offset: 0x00065D38
	public int[] #=zi0n5Dw6d6LiE()
	{
		return this.#=z6X75hCY8NL6fmSzCwtsObHA=;
	}

	// Token: 0x06000D15 RID: 3349 RVA: 0x00067B40 File Offset: 0x00065D40
	public void #=zqfA74JKFKldk(int[] #=z$Ib9gYQ=)
	{
		this.#=z6X75hCY8NL6fmSzCwtsObHA= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000791 RID: 1937
	private int[] #=z6X75hCY8NL6fmSzCwtsObHA=;
}
