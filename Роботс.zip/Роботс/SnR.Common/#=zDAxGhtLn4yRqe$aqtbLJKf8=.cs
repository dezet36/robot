﻿using System;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020000DD RID: 221
internal sealed class #=zDAxGhtLn4yRqe$aqtbLJKf8= : CellValue, BooleanCell, Cell
{
	// Token: 0x060005E3 RID: 1507 RVA: 0x000309B0 File Offset: 0x0002EBB0
	public #=zDAxGhtLn4yRqe$aqtbLJKf8=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		this.#=zzMSGcBE= = false;
		this.#=zaiKvawI= = false;
		sbyte[] data = this.getRecord().Data;
		this.#=zzMSGcBE= = (data[7] == 1);
		if (!this.#=zzMSGcBE=)
		{
			this.#=zaiKvawI= = (data[6] == 1);
		}
	}

	// Token: 0x060005E4 RID: 1508 RVA: 0x00030A00 File Offset: 0x0002EC00
	public bool #=zZEc75Ho=()
	{
		return this.#=zzMSGcBE=;
	}

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x060005E5 RID: 1509 RVA: 0x00030A08 File Offset: 0x0002EC08
	public bool BooleanValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x060005E6 RID: 1510 RVA: 0x00030A10 File Offset: 0x0002EC10
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x060005E7 RID: 1511 RVA: 0x00030A20 File Offset: 0x0002EC20
	public new string Contents
	{
		get
		{
			Assert.verify(!this.#=zZEc75Ho=());
			return this.#=zaiKvawI=.ToString().ToUpper();
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x060005E8 RID: 1512 RVA: 0x00030A40 File Offset: 0x0002EC40
	public new CellType Type
	{
		get
		{
			return CellType.BOOLEAN;
		}
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x00030A48 File Offset: 0x0002EC48
	public override Record getRecord()
	{
		return base.getRecord();
	}

	// Token: 0x04000270 RID: 624
	private bool #=zzMSGcBE=;

	// Token: 0x04000271 RID: 625
	private bool #=zaiKvawI=;
}
