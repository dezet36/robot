﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200021B RID: 539
internal sealed class #=zcsIgna2XJlarOA7v4qCXrywzRrfs
{
	// Token: 0x06001062 RID: 4194 RVA: 0x0007EFF8 File Offset: 0x0007D1F8
	public static string #=zNerpgmc=(string #=zNraCe1Y=)
	{
		string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940074);
		string #=zaFTbRSM= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zqZuF95gmazGG(#=zNraCe1Y=, GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN(), GameApplicationData.#=zihLsmTesqApV(), null, 0, null);
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zJrZHM9C4etWE(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, false));
	}

	// Token: 0x06001063 RID: 4195 RVA: 0x0007F040 File Offset: 0x0007D240
	public static #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=zPXfWr_IJGy1A(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=)
	{
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zTCuJRaMvDUye(new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>
		{
			#=zhoOF5s8=
		});
		if (list.Count > 0)
		{
			return list[0];
		}
		return null;
	}

	// Token: 0x06001064 RID: 4196 RVA: 0x0007F074 File Offset: 0x0007D274
	public static List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zTCuJRaMvDUye(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zEhGRLRSSQTM3nxmPHQ==)
	{
		object[] array = new object[#=zEhGRLRSSQTM3nxmPHQ==.Count];
		for (int i = 0; i < #=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = #=zEhGRLRSSQTM3nxmPHQ==[i];
			array[i] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zSByqmFV12x0z()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940038),
					#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zi1hFJwI=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==).#=zhv7OhlM=()
				}
			};
		}
		string dataStr = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940287), new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940263),
				array
			}
		});
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>();
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(dataStr);
		for (int j = 0; j < #=zEhGRLRSSQTM3nxmPHQ==.Count; j++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2 = #=zEhGRLRSSQTM3nxmPHQ==[j];
			Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe());
			if (dictionary2 != null)
			{
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = new #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl();
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zBSjk$U_t1Pev(GameApplicationData.#=z7wsmjLWw49AC());
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zinKNQicbcZrD(GameApplicationData.#=zZ2dsDUeWDYAN());
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=ze8TQhOAtefck(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe());
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zwXKUV2c=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zSByqmFV12x0z());
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zSYGTieA=((AccoutRegistrationResults)Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899)]));
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zFzGvi_S6jJhE((AccessLevels)Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zYTBroMkKB8GB(DateTime.Now);
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zzM_7pdfAr69D(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940242), 100));
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zojHCQcuGBXly(#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zi1hFJwI=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2));
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl item = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl;
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06001065 RID: 4197 RVA: 0x0007F224 File Offset: 0x0007D424
	public static void #=zvuVAl$GL8W_$(string #=zDu2ZTOnSae3g, GameApplicationData.GameHosters #=z74XFXnQ7Q8Ia, GameApplicationData.Games #=zR2PWq$tkHfd5)
	{
		if (!string.IsNullOrEmpty(#=zDu2ZTOnSae3g))
		{
			#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940235), #=z74XFXnQ7Q8Ia, #=zR2PWq$tkHfd5, #=zDu2ZTOnSae3g);
			return;
		}
		#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940211));
	}

	// Token: 0x06001066 RID: 4198 RVA: 0x0007F254 File Offset: 0x0007D454
	public static string #=znuPcZoWYeDnJ(List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zEhGRLRSSQTM3nxmPHQ==)
	{
		object[] array = new object[#=zEhGRLRSSQTM3nxmPHQ==.Count];
		for (int i = 0; i < #=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zEhGRLRSSQTM3nxmPHQ==[i];
			array[i] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCCvotbi$42tS()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940038),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zc8qEfLcp5D1z().#=zhv7OhlM=()
				}
			};
		}
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940197), new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940263),
				array
			}
		});
	}

	// Token: 0x06001067 RID: 4199 RVA: 0x0007F2E4 File Offset: 0x0007D4E4
	public static string #=zf9StgC1$9ZxV()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940161));
	}

	// Token: 0x06001068 RID: 4200 RVA: 0x0007F2F8 File Offset: 0x0007D4F8
	public static string #=zYt_eIZ4_tO7y(int #=zXAUWJhqdRUdu)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939880),
				#=zXAUWJhqdRUdu
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939877), #=z1$25lUQ=);
	}

	// Token: 0x06001069 RID: 4201 RVA: 0x0007F334 File Offset: 0x0007D534
	public static string #=zEBRdQRVVATQG(int #=z3hPMuug=)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939861),
				#=z3hPMuug=
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939841), #=z1$25lUQ=);
	}

	// Token: 0x0600106A RID: 4202 RVA: 0x0007F370 File Offset: 0x0007D570
	public static string #=zbKUEYvdUKPog(string #=zx9NCziM=, int #=zXAUWJhqdRUdu)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939880),
				#=zXAUWJhqdRUdu
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				#=zx9NCziM=
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939818), #=z1$25lUQ=);
	}

	// Token: 0x0600106B RID: 4203 RVA: 0x0007F3BC File Offset: 0x0007D5BC
	public static string #=zi7BLllIjRjs1(string #=zwzUumn8=, int #=z84LHPL2J2FN6, int #=zSc7_kYiCqktH, string #=zaBPAiEqHB7k2)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zwzUumn8=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053),
				#=z84LHPL2J2FN6
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zSc7_kYiCqktH
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zaBPAiEqHB7k2
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939802), #=z1$25lUQ=);
	}

	// Token: 0x0600106C RID: 4204 RVA: 0x0007F430 File Offset: 0x0007D630
	public static string #=zK$qD7CpO$n0s(string #=zwzUumn8=, string #=zOK8PtA0e32u3, string #=zhJIMfB0=, int #=z84LHPL2J2FN6, int #=zSc7_kYiCqktH, string #=zaBPAiEqHB7k2)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zwzUumn8=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094335),
				#=zOK8PtA0e32u3
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094324),
				#=zhJIMfB0=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053),
				#=z84LHPL2J2FN6
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zSc7_kYiCqktH
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zaBPAiEqHB7k2
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939790), #=z1$25lUQ=);
	}

	// Token: 0x0600106D RID: 4205 RVA: 0x0007F4C8 File Offset: 0x0007D6C8
	public static string #=z12aNaH2rayZG(int #=zF2SCy$5A7Gvc, DateTime #=z08RgUIiFfhZdvFN2UQ==, int #=ziCCE9_QLT$ol, string #=zCgD4QQxEzNdL, bool #=zdKHqacYNXPetqbNHJorQLKw=)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zF2SCy$5A7Gvc
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966),
				JSONManager.EncodeTimeInt(#=z08RgUIiFfhZdvFN2UQ==, true)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071759),
				#=ziCCE9_QLT$ol
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601),
				#=zCgD4QQxEzNdL
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940029),
				(#=zdKHqacYNXPetqbNHJorQLKw= > false) ? 1 : 0
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940010), #=z1$25lUQ=);
	}

	// Token: 0x0600106E RID: 4206 RVA: 0x0007F560 File Offset: 0x0007D760
	public static string #=zjELnqk91QI3ekOlKzw==(int #=z7TFvEVeXLgukxR$rJTq0x3U=)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050266),
				#=z7TFvEVeXLgukxR$rJTq0x3U=
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939993), #=z1$25lUQ=);
	}

	// Token: 0x0600106F RID: 4207 RVA: 0x0007F59C File Offset: 0x0007D79C
	public static string #=zjELnqk91QI3ekOlKzw==(int #=zfHa3nO1vcims, DateTime #=zdtvGg8ImlGHQ)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zfHa3nO1vcims
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966),
				JSONManager.EncodeTimeInt(#=zdtvGg8ImlGHQ, true)
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939993), #=z1$25lUQ=);
	}

	// Token: 0x06001070 RID: 4208 RVA: 0x0007F5F4 File Offset: 0x0007D7F4
	public static string #=zh53_YUdjalU1Rlni_w==(int #=z7QQ$ZPOe84UP, int #=ziCCE9_QLT$ol, string #=zCgD4QQxEzNdL, bool #=zdKHqacYNXPetqbNHJorQLKw=)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] = #=z7QQ$ZPOe84UP;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)] = #=ziCCE9_QLT$ol;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = #=zCgD4QQxEzNdL;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = ((#=zdKHqacYNXPetqbNHJorQLKw= > false) ? 1 : 0);
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939969), dictionary);
	}

	// Token: 0x06001071 RID: 4209 RVA: 0x0007F670 File Offset: 0x0007D870
	public static bool #=zrrJL63eTcjQB(string #=zaBPAiEqHB7k2)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094317),
				#=zaBPAiEqHB7k2
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939958), #=z1$25lUQ=).Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939934));
	}

	// Token: 0x06001072 RID: 4210 RVA: 0x0007F6B4 File Offset: 0x0007D8B4
	public static string #=z7hPlwc__UnvN(Dictionary<string, object> #=zJ5GWysk=)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939925), #=zJ5GWysk=);
	}

	// Token: 0x06001073 RID: 4211 RVA: 0x0007F6C8 File Offset: 0x0007D8C8
	public static string #=zKOquhttg3c04(int #=zpJoL1NTIrSFC)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939909));
	}

	// Token: 0x06001074 RID: 4212 RVA: 0x0007F6DC File Offset: 0x0007D8DC
	public static string #=zp8YKVzmTER2u()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939629));
	}

	// Token: 0x06001075 RID: 4213 RVA: 0x0007F6F0 File Offset: 0x0007D8F0
	public static string #=zLAsqqvHbp_SVIBZG6A==(Dictionary<string, object> #=z140gaAPv1JG3)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939606), #=z140gaAPv1JG3);
	}

	// Token: 0x06001076 RID: 4214 RVA: 0x0007F704 File Offset: 0x0007D904
	public static string #=zt1VrUkwJ$Xqa(Dictionary<string, object> #=zyY0f3OQ=)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939580), #=zyY0f3OQ=);
	}

	// Token: 0x06001077 RID: 4215 RVA: 0x0007F718 File Offset: 0x0007D918
	public static string #=zPYgX1sPMvLlo()
	{
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zmWSq0sTYcJfLLSlbyQ==())
		{
			return null;
		}
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939553));
	}

	// Token: 0x06001078 RID: 4216 RVA: 0x0007F738 File Offset: 0x0007D938
	public static string #=zGGL_CKcwA0bfABCwew==(int #=zLeeSKrg=, string #=zG7NtWas=, string #=zuNH8yYs=, object[] #=zhWOz9mg=)
	{
		string result;
		try
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939535),
					#=zG7NtWas=
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939775),
					#=zuNH8yYs=
				}
			};
			if (#=zhWOz9mg= != null)
			{
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939759)] = #=zhWOz9mg=;
			}
			result = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939742), #=zLeeSKrg=, dictionary);
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			result = null;
		}
		return result;
	}

	// Token: 0x06001079 RID: 4217 RVA: 0x0007F7B0 File Offset: 0x0007D9B0
	public static string #=zw374AcbLnrWfTy2Hqg==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, Task #=zcTyyNys=)
	{
		string result;
		try
		{
			Dictionary<string, object> #=z1$25lUQ= = #=zcTyyNys=.Serialize();
			result = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939715), #=z8StzeqE=.#=zYgvZuBwR$a1C(), #=z1$25lUQ=);
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			result = null;
		}
		return result;
	}

	// Token: 0x0600107A RID: 4218 RVA: 0x0007F7F8 File Offset: 0x0007D9F8
	public static string #=zVGwH_lTBz68N()
	{
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zOdy_aU_tk1aY();
		object[] array = new object[list.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = list[i].#=z9Yordw6ZFjQe();
		}
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				array
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939701), #=z1$25lUQ=);
	}

	// Token: 0x0600107B RID: 4219 RVA: 0x0007F860 File Offset: 0x0007DA60
	public static void #=zZj33c9eGCdD2H3Vhqw==(List<object> #=zJe6TLpo=)
	{
		try
		{
			bool flag = false;
			List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
			for (int i = 0; i < #=zJe6TLpo=.Count; i++)
			{
				object obj = #=zJe6TLpo=[i];
				if (obj is #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== && obj != null)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = obj as #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==;
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B() != null)
					{
						list.Add(new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939679),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939669),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108019),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zSByqmFV12x0z()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050285),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939649),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939388),
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939369),
								(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsDispermitSpam > false) ? 1 : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939364),
								(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsDispermitAllianceSpam > false) ? 1 : 0
							}
						});
					}
					if (!flag && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==))
					{
						flag = true;
					}
				}
			}
			if (flag && list.Count > 0)
			{
				object[] array = new object[list.Count];
				for (int j = 0; j < list.Count; j++)
				{
					array[j] = list[j];
				}
				Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						array
					}
				};
				#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939345), #=z1$25lUQ=);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
	}

	// Token: 0x0600107C RID: 4220 RVA: 0x0007FA50 File Offset: 0x0007DC50
	public static string #=zB2UH099PEmWB(string #=z7AcZdMA=, string #=zjMfTbhE=)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z7AcZdMA=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zjMfTbhE=
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939334), #=z1$25lUQ=);
	}

	// Token: 0x0600107D RID: 4221 RVA: 0x0007FA98 File Offset: 0x0007DC98
	public static string #=zg9RGssIaCxTP(object[] #=zhts9LUSlSJfo)
	{
		Dictionary<string, object> #=z1$25lUQ= = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zhts9LUSlSJfo
			}
		};
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939316), #=z1$25lUQ=);
	}

	// Token: 0x0600107E RID: 4222 RVA: 0x0007FACC File Offset: 0x0007DCCC
	public static string #=zCmS$HxCaJMxw(string #=zhJIMfB0=, string #=zBGZydVI=)
	{
		string result;
		try
		{
			result = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zJrZHM9C4etWE(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939282), #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==(), HttpUtility.UrlEncode(#=zhJIMfB0=), GameApplicationData.#=zihLsmTesqApV()), #=zBGZydVI=, false));
		}
		catch (Exception #=zN_s5Z5A=)
		{
			result = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
		}
		return result;
	}

	// Token: 0x0600107F RID: 4223 RVA: 0x0007FB28 File Offset: 0x0007DD28
	public static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zZhqMK1rUHEaR0OpJtPNbpIw=(string #=zgaoDPaw=)
	{
		string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939493) + #=zgaoDPaw=;
		string #=zaFTbRSM= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zqZuF95gmazGG(null, GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN(), GameApplicationData.#=zihLsmTesqApV(), null, 0, null);
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, true);
	}

	// Token: 0x06001080 RID: 4224 RVA: 0x0007FB6C File Offset: 0x0007DD6C
	public static string #=z6gHxCh_5wegADapekA==(GameApplicationData.GameHosters #=z1oEF8gM=, GameApplicationData.Games #=zSg73axlT2_0Z, int #=za8Itzhs=)
	{
		string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939453);
		string #=zaFTbRSM= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zqZuF95gmazGG(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939411), #=z1oEF8gM=, #=zSg73axlT2_0Z, #=za8Itzhs=, null, 0, null);
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zJrZHM9C4etWE(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, false));
	}

	// Token: 0x06001081 RID: 4225 RVA: 0x0007FBB0 File Offset: 0x0007DDB0
	public static bool #=zpoMn3b1qsfyz()
	{
		bool result;
		try
		{
			string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939399);
			string #=zaFTbRSM= = JSONManager.SerializeData(new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941166),
					#=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==.#=zYhB1CCJa0Gd_()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941157),
					#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zKhLzVPbpHenM()
				}
			});
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, false);
			if (!string.IsNullOrEmpty(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof()))
			{
				#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941141) + #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof());
				result = false;
			}
			else
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2());
				if (dictionary == null)
				{
					#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941111));
					result = false;
				}
				else if (JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941305), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699)).ToLower() != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716))
				{
					#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941291) + JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941269), string.Empty));
					result = false;
				}
				else
				{
					result = true;
				}
			}
		}
		catch (Exception ex)
		{
			#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941255) + ex.Message);
			result = false;
		}
		return result;
	}

	// Token: 0x06001082 RID: 4226 RVA: 0x0007FD08 File Offset: 0x0007DF08
	public static bool #=zjRJeiqafBpN5(byte[] #=zt5PLcjEKUG_I, byte[] #=zPZohVRG2lpLa)
	{
		try
		{
			string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941217);
			string #=zaFTbRSM= = JSONManager.SerializeData(new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941166),
					#=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==.#=zYhB1CCJa0Gd_()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941187),
					Convert.ToBase64String(#=zt5PLcjEKUG_I)
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940914),
					Convert.ToBase64String(#=zPZohVRG2lpLa)
				}
			});
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, false).#=z0KhF75_5Qux2());
			if (dictionary != null && JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941305), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699)).ToLower() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716))
			{
				return true;
			}
		}
		catch (Exception ex)
		{
			#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940902), ex.Message));
		}
		return false;
	}

	// Token: 0x06001083 RID: 4227 RVA: 0x0007FDF8 File Offset: 0x0007DFF8
	public static int #=zetA27_gYDu_0b8eNlA==(GameApplicationData.Games #=zSg73axlT2_0Z)
	{
		int num = 2;
		int i = #=zSg73axlT2_0Z - GameApplicationData.Games.RulesOfWar;
		int num2 = 1;
		while (i > 0)
		{
			if ((i & 1) == 1)
			{
				num2 *= num;
			}
			num *= num;
			i >>= 1;
		}
		return num2;
	}

	// Token: 0x06001084 RID: 4228 RVA: 0x0007FE28 File Offset: 0x0007E028
	public static GameApplicationData.Games #=zIsC$qK_fWhaH76s5gg==(int #=zEDDbm48=)
	{
		if (#=zEDDbm48= >= 32)
		{
			return GameApplicationData.Games.Nords;
		}
		if (#=zEDDbm48= >= 16)
		{
			return GameApplicationData.Games.Sparta;
		}
		if (#=zEDDbm48= >= 8)
		{
			return GameApplicationData.Games.Konflikt;
		}
		if (#=zEDDbm48= >= 4)
		{
			return GameApplicationData.Games.WarOfThrones;
		}
		if (#=zEDDbm48= >= 2)
		{
			return GameApplicationData.Games.CodexOfPirate;
		}
		if (#=zEDDbm48= >= 1)
		{
			return GameApplicationData.Games.RulesOfWar;
		}
		return (GameApplicationData.Games)0;
	}

	// Token: 0x06001085 RID: 4229 RVA: 0x0007FE54 File Offset: 0x0007E054
	public static string #=zc6nxpDwQGYzXkRSaV8fwIZ8=()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEV7FHuDKYdFw() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940856);
	}

	// Token: 0x06001086 RID: 4230 RVA: 0x0007FE6C File Offset: 0x0007E06C
	public static string #=zauZ5ugS0UuQ5APHXwoaYSDNsgcpy()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEV7FHuDKYdFw() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940833);
	}

	// Token: 0x06001087 RID: 4231 RVA: 0x0007FE84 File Offset: 0x0007E084
	public static string #=zhh55J5n3TXto$ziZkHI_f_sjloD9YalyIA==()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEV7FHuDKYdFw() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940802);
	}

	// Token: 0x06001088 RID: 4232 RVA: 0x0007FE9C File Offset: 0x0007E09C
	public static string #=z9d79e5_LBtjxlNqMiw==()
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEV7FHuDKYdFw() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941046);
	}

	// Token: 0x06001089 RID: 4233 RVA: 0x0007FEB4 File Offset: 0x0007E0B4
	private static string #=zEV7FHuDKYdFw()
	{
		if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zlRrfRpmZlokbwl5Xnw==())
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941019);
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940986);
	}

	// Token: 0x0600108A RID: 4234 RVA: 0x0007FED8 File Offset: 0x0007E0D8
	private static string #=zEW26cddHtgm2f787cw==()
	{
		if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zlRrfRpmZlokbwl5Xnw==())
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940953);
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940666);
	}

	// Token: 0x0600108B RID: 4235 RVA: 0x0007FEFC File Offset: 0x0007E0FC
	private static string #=zKhLzVPbpHenM()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940638);
	}

	// Token: 0x0600108C RID: 4236 RVA: 0x0007FF08 File Offset: 0x0007E108
	private static string #=zqZuF95gmazGG(string #=zNraCe1Y=, GameApplicationData.GameHosters #=z1oEF8gM=, GameApplicationData.Games #=zSg73axlT2_0Z, int #=za8Itzhs=, string #=zDu2ZTOnSae3g, int #=zLeeSKrg=, Dictionary<string, object> #=z1$25lUQ=)
	{
		string text = #=zNraCe1Y=;
		if (text == null)
		{
			text = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zVZd$8ug=();
		}
		Dictionary<string, object> dictionary = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940429),
				text
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052955),
				(int)#=z1oEF8gM=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052950),
				#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(#=zSg73axlT2_0Z)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942203),
				#=za8Itzhs=
			}
		};
		if (#=zDu2ZTOnSae3g != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942196)] = #=zDu2ZTOnSae3g;
		}
		if (#=zLeeSKrg= != 0)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942171)] = #=zLeeSKrg=;
		}
		if (#=z1$25lUQ= != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942153)] = #=z1$25lUQ=;
		}
		return JSONManager.SerializeData(dictionary);
	}

	// Token: 0x0600108D RID: 4237 RVA: 0x0007FFD0 File Offset: 0x0007E1D0
	private static string #=zJrZHM9C4etWE(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zC1K2Mos=)
	{
		if (!string.IsNullOrEmpty(#=zC1K2Mos=.#=z37JbfhBQfNof()))
		{
			return #=zC1K2Mos=.#=z37JbfhBQfNof();
		}
		return #=zC1K2Mos=.#=z0KhF75_5Qux2();
	}

	// Token: 0x0600108E RID: 4238 RVA: 0x0007FFEC File Offset: 0x0007E1EC
	private static string #=zEIYz$9w=(string #=zyhUp4Hk=)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=zyhUp4Hk=, GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN(), null, 0, null);
	}

	// Token: 0x0600108F RID: 4239 RVA: 0x00080004 File Offset: 0x0007E204
	private static string #=zEIYz$9w=(string #=zyhUp4Hk=, Dictionary<string, object> #=z1$25lUQ=)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=zyhUp4Hk=, GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN(), null, 0, #=z1$25lUQ=);
	}

	// Token: 0x06001090 RID: 4240 RVA: 0x0008001C File Offset: 0x0007E21C
	private static string #=zEIYz$9w=(string #=zyhUp4Hk=, int #=zLeeSKrg=, Dictionary<string, object> #=z1$25lUQ=)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=zyhUp4Hk=, GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN(), null, #=zLeeSKrg=, #=z1$25lUQ=);
	}

	// Token: 0x06001091 RID: 4241 RVA: 0x00080034 File Offset: 0x0007E234
	private static string #=zEIYz$9w=(string #=zyhUp4Hk=, GameApplicationData.GameHosters #=z1oEF8gM=, GameApplicationData.Games #=zSg73axlT2_0Z, string #=zDu2ZTOnSae3g)
	{
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEIYz$9w=(#=zyhUp4Hk=, #=z1oEF8gM=, #=zSg73axlT2_0Z, #=zDu2ZTOnSae3g, 0, null);
	}

	// Token: 0x06001092 RID: 4242 RVA: 0x00080044 File Offset: 0x0007E244
	private static string #=zEIYz$9w=(string #=zyhUp4Hk=, GameApplicationData.GameHosters #=z1oEF8gM=, GameApplicationData.Games #=zSg73axlT2_0Z, string #=zDu2ZTOnSae3g, int #=zLeeSKrg=, Dictionary<string, object> #=z1$25lUQ=)
	{
		string #=zVI_2r0M= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEW26cddHtgm2f787cw==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942139) + #=zyhUp4Hk=;
		string #=zaFTbRSM= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zqZuF95gmazGG(null, #=z1oEF8gM=, #=zSg73axlT2_0Z, GameApplicationData.#=zihLsmTesqApV(), #=zDu2ZTOnSae3g, #=zLeeSKrg=, #=z1$25lUQ=);
		return #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zJrZHM9C4etWE(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNQgfFf0S6hqr(#=zVI_2r0M=, #=zaFTbRSM=, false));
	}

	// Token: 0x06001093 RID: 4243 RVA: 0x00080088 File Offset: 0x0007E288
	private static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zNQgfFf0S6hqr(string #=zVI_2r0M=, string #=zaFTbRSM=, bool #=zcb71Q2npj32t)
	{
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(#=zVI_2r0M=);
		httpWebRequest.Method = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108880);
		httpWebRequest.ContentType = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108456);
		string value = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z_ipaLQxA31uf.#=zm4asrbQ=(#=zaFTbRSM=);
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942110),
				value
			}
		});
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zTvO8aG2BI37U(httpWebRequest, #=zWC15sHaiwX4N);
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 result;
		using (HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse())
		{
			result = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(httpWebResponse, #=zcb71Q2npj32t);
		}
		return result;
	}

	// Token: 0x0200021C RID: 540
	private static class #=z_ipaLQxA31uf
	{
		// Token: 0x06001095 RID: 4245 RVA: 0x00080148 File Offset: 0x0007E348
		public static string #=zm4asrbQ=(string #=z3jG7bGU61GQj)
		{
			string result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z_ipaLQxA31uf.#=zka8$rTQ=;
				aes.IV = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z_ipaLQxA31uf.#=zOpUSWDY=;
				aes.Mode = CipherMode.CBC;
				aes.Padding = PaddingMode.PKCS7;
				using (ICryptoTransform cryptoTransform = aes.CreateEncryptor())
				{
					byte[] bytes = Encoding.UTF8.GetBytes(#=z3jG7bGU61GQj);
					result = Convert.ToBase64String(cryptoTransform.TransformFinalBlock(bytes, 0, bytes.Length));
				}
			}
			return result;
		}

		// Token: 0x040008F9 RID: 2297
		private static readonly byte[] #=zka8$rTQ= = Convert.FromBase64String(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938372));

		// Token: 0x040008FA RID: 2298
		private static readonly byte[] #=zOpUSWDY= = Convert.FromBase64String(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940107));
	}
}
