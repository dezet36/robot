﻿using System;
using System.Collections.Generic;

// Token: 0x02000248 RID: 584
internal sealed class #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= : #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==
{
	// Token: 0x060011CF RID: 4559 RVA: 0x0008A1B8 File Offset: 0x000883B8
	public #=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg=()
	{
		this.#=zmF_FmcR8nF97miROJyzUDXA=(new List<#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP>());
		base.#=zniBL6E3VL6qZBQF9fw==(false);
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x0008A1D4 File Offset: 0x000883D4
	public int #=z3FoeVNn2CiyhA1ZyUw==()
	{
		return this.#=zIsIq44xH1bClL6ZNSRH2Kbg=;
	}

	// Token: 0x060011D1 RID: 4561 RVA: 0x0008A1DC File Offset: 0x000883DC
	public void #=zf2R7C9IfGGsfWN39Hw==(int #=z$Ib9gYQ=)
	{
		this.#=zIsIq44xH1bClL6ZNSRH2Kbg= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011D2 RID: 4562 RVA: 0x0008A1E8 File Offset: 0x000883E8
	public int #=zLvqwQumxHX8WduSlGQ==()
	{
		return this.#=zIfDIg4izt5xrjyeU3nfJxKWJLnUf;
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x0008A1F0 File Offset: 0x000883F0
	public void #=z6U0GQOJYJX1Mx0n3FA==(int #=z$Ib9gYQ=)
	{
		this.#=zIfDIg4izt5xrjyeU3nfJxKWJLnUf = #=z$Ib9gYQ=;
	}

	// Token: 0x060011D4 RID: 4564 RVA: 0x0008A1FC File Offset: 0x000883FC
	public List<#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP> #=zZUNqx7t2T5W7fS1fb5XafzQ=()
	{
		return this.#=zBWC2VuW0c6V8WPczd8fKfcClQE3U;
	}

	// Token: 0x060011D5 RID: 4565 RVA: 0x0008A204 File Offset: 0x00088404
	public void #=zmF_FmcR8nF97miROJyzUDXA=(List<#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP> #=z$Ib9gYQ=)
	{
		this.#=zBWC2VuW0c6V8WPczd8fKfcClQE3U = #=z$Ib9gYQ=;
	}

	// Token: 0x040009F2 RID: 2546
	private int #=zIsIq44xH1bClL6ZNSRH2Kbg=;

	// Token: 0x040009F3 RID: 2547
	private int #=zIfDIg4izt5xrjyeU3nfJxKWJLnUf;

	// Token: 0x040009F4 RID: 2548
	private List<#=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP> #=zBWC2VuW0c6V8WPczd8fKfcClQE3U;
}
