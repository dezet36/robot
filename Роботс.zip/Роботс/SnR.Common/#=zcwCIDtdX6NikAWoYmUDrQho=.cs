﻿using System;
using common;
using NExcel.Biff.Drawing;

// Token: 0x0200021D RID: 541
internal sealed class #=zcwCIDtdX6NikAWoYmUDrQho= : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x06001096 RID: 4246 RVA: 0x000801D8 File Offset: 0x0007E3D8
	public #=zcwCIDtdX6NikAWoYmUDrQho=(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
	}

	// Token: 0x06001097 RID: 4247 RVA: 0x000801E4 File Offset: 0x0007E3E4
	public #=zcwCIDtdX6NikAWoYmUDrQho=() : base(EscherRecordType.CLIENT_DATA)
	{
	}

	// Token: 0x1700004D RID: 77
	// (get) Token: 0x06001099 RID: 4249 RVA: 0x0008020C File Offset: 0x0007E40C
	public override sbyte[] Data
	{
		get
		{
			this.#=zJ5GWysk= = new sbyte[0];
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x040008FB RID: 2299
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zcwCIDtdX6NikAWoYmUDrQho=));

	// Token: 0x040008FC RID: 2300
	private sbyte[] #=zJ5GWysk=;
}
