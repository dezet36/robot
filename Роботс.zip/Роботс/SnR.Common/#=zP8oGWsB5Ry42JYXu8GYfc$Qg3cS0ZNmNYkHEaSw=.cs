﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000174 RID: 372
internal sealed class #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=
{
	// Token: 0x060009FB RID: 2555 RVA: 0x000504B0 File Offset: 0x0004E6B0
	public #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=(Dictionary<string, object> #=z_gBpTbFvOt4U)
	{
		this.#=zbsxKkj4=(Convert.ToInt32(#=z_gBpTbFvOt4U[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
		this.#=zzQwUIEs=((#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs=)Convert.ToInt32(#=z_gBpTbFvOt4U[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
		this.#=zLRvdhdwvyoKg4NQTAIphJh$EiuVr(#=z_gBpTbFvOt4U.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069987)));
		this.#=zF5kC7O4ZfMmxY4pgm00JXUg1_PFk(#=z_gBpTbFvOt4U.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976)));
		this.#=z3u856vvih3R8lkvAF6h_FfyPcL6C(JSONManager.ExtractInt(#=z_gBpTbFvOt4U, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), 0) != 0);
		this.#=zERAfCoRkDnt28bTxtZjF43vOKahUVRnO$g==(new List<DateTime>());
		object[] array = JSONManager.GetArray(#=z_gBpTbFvOt4U, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069968));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				this.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==().Add(JSONManager.DecodeTime(Convert.ToString(array[i]), false));
			}
		}
		object[] array2 = JSONManager.ExtractArray(#=z_gBpTbFvOt4U, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
		if (array2 != null)
		{
			this.#=z2CmYuMFa$KvvrA8DzUq$wnlIlrms(array2.Length);
		}
	}

	// Token: 0x060009FC RID: 2556 RVA: 0x000505A4 File Offset: 0x0004E7A4
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060009FD RID: 2557 RVA: 0x000505AC File Offset: 0x0004E7AC
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009FE RID: 2558 RVA: 0x000505B8 File Offset: 0x0004E7B8
	public #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060009FF RID: 2559 RVA: 0x000505C0 File Offset: 0x0004E7C0
	public void #=zzQwUIEs=(#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A00 RID: 2560 RVA: 0x000505CC File Offset: 0x0004E7CC
	public bool #=zdyJ3f33C0g8OTd$jQPjXVGgGUPCf()
	{
		return this.#=z5iTZ_LoSFjRrgZP76z4QYPi0ma33JSJkIw==;
	}

	// Token: 0x06000A01 RID: 2561 RVA: 0x000505D4 File Offset: 0x0004E7D4
	public void #=zLRvdhdwvyoKg4NQTAIphJh$EiuVr(bool #=z$Ib9gYQ=)
	{
		this.#=z5iTZ_LoSFjRrgZP76z4QYPi0ma33JSJkIw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A02 RID: 2562 RVA: 0x000505E0 File Offset: 0x0004E7E0
	public bool #=zt5ldqGJD4wtmVa54mBffsQcig7CL()
	{
		return this.#=zDcQ4WY3VZkZMAAJOzAVYCHo9M9I59eS1Gw==;
	}

	// Token: 0x06000A03 RID: 2563 RVA: 0x000505E8 File Offset: 0x0004E7E8
	public void #=zF5kC7O4ZfMmxY4pgm00JXUg1_PFk(bool #=z$Ib9gYQ=)
	{
		this.#=zDcQ4WY3VZkZMAAJOzAVYCHo9M9I59eS1Gw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A04 RID: 2564 RVA: 0x000505F4 File Offset: 0x0004E7F4
	public bool #=z6ZCJ35XpMZv9qsAuPBwV5nGAIfKB()
	{
		return this.#=zMC0g8J9K7LxV_KDfJgqAZ7aiVII7rTAlkQ==;
	}

	// Token: 0x06000A05 RID: 2565 RVA: 0x000505FC File Offset: 0x0004E7FC
	public void #=z3u856vvih3R8lkvAF6h_FfyPcL6C(bool #=z$Ib9gYQ=)
	{
		this.#=zMC0g8J9K7LxV_KDfJgqAZ7aiVII7rTAlkQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A06 RID: 2566 RVA: 0x00050608 File Offset: 0x0004E808
	public List<DateTime> #=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==()
	{
		return this.#=zXRIjoICq25xAD6FAzfblIK$iUs57H_JBAxGVuZA=;
	}

	// Token: 0x06000A07 RID: 2567 RVA: 0x00050610 File Offset: 0x0004E810
	public void #=zERAfCoRkDnt28bTxtZjF43vOKahUVRnO$g==(List<DateTime> #=z$Ib9gYQ=)
	{
		this.#=zXRIjoICq25xAD6FAzfblIK$iUs57H_JBAxGVuZA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A08 RID: 2568 RVA: 0x0005061C File Offset: 0x0004E81C
	public int #=zZQ6lX1_$WuQNGY73aoLLl7Yqn8Qj()
	{
		return this.#=zUlX9L9TU4r08zhxc9abwxzdctsZBOhvL$A==;
	}

	// Token: 0x06000A09 RID: 2569 RVA: 0x00050624 File Offset: 0x0004E824
	public void #=z2CmYuMFa$KvvrA8DzUq$wnlIlrms(int #=z$Ib9gYQ=)
	{
		this.#=zUlX9L9TU4r08zhxc9abwxzdctsZBOhvL$A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A0A RID: 2570 RVA: 0x00050630 File Offset: 0x0004E830
	public bool #=zFGyhIvqZjyZD()
	{
		#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs= #=zArez$Gs= = this.#=zq2bPTdY=();
		if (#=zArez$Gs= != (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs=)5)
		{
			return #=zArez$Gs= == (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs=)7 && !this.#=zdyJ3f33C0g8OTd$jQPjXVGgGUPCf();
		}
		return !this.#=zt5ldqGJD4wtmVa54mBffsQcig7CL();
	}

	// Token: 0x040005B7 RID: 1463
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040005B8 RID: 1464
	private #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040005B9 RID: 1465
	private bool #=z5iTZ_LoSFjRrgZP76z4QYPi0ma33JSJkIw==;

	// Token: 0x040005BA RID: 1466
	private bool #=zDcQ4WY3VZkZMAAJOzAVYCHo9M9I59eS1Gw==;

	// Token: 0x040005BB RID: 1467
	private bool #=zMC0g8J9K7LxV_KDfJgqAZ7aiVII7rTAlkQ==;

	// Token: 0x040005BC RID: 1468
	private List<DateTime> #=zXRIjoICq25xAD6FAzfblIK$iUs57H_JBAxGVuZA=;

	// Token: 0x040005BD RID: 1469
	private int #=zUlX9L9TU4r08zhxc9abwxzdctsZBOhvL$A==;

	// Token: 0x02000175 RID: 373
	public enum #=zArez$Gs=
	{

	}
}
