﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001AD RID: 429
internal sealed class #=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=
{
	// Token: 0x06000CF1 RID: 3313 RVA: 0x0006721C File Offset: 0x0006541C
	public #=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zv7S2lZXwkZ4C(null);
		this.#=zYymncTzrSSIR(0);
		foreach (string text in #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060298).Split(new char[]
		{
			','
		}))
		{
			int num = JSONManager.ExtractInt(#=zJ5GWysk=, text, 0);
			if (num > 0)
			{
				this.#=zv7S2lZXwkZ4C(text);
				this.#=zYymncTzrSSIR(num);
				break;
			}
		}
		this.#=zXSzshOGDSfGl(JSONManager.ExtractLong(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0L));
		this.#=zIAgAcVPUIXI83qdFOA==(null);
		object[] array2 = JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399));
		if (array2 != null && array2.Length != 0)
		{
			this.#=zIAgAcVPUIXI83qdFOA==(new List<int>());
			for (int j = 0; j < array2.Length; j++)
			{
				this.#=zxqd8DBH0LUsd0xrIUw==().Add(Convert.ToInt32(array2[j]));
			}
		}
	}

	// Token: 0x06000CF2 RID: 3314 RVA: 0x00067308 File Offset: 0x00065508
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000CF3 RID: 3315 RVA: 0x00067310 File Offset: 0x00065510
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CF4 RID: 3316 RVA: 0x0006731C File Offset: 0x0006551C
	public string #=zxr6xC83bUzbu()
	{
		return this.#=zBiXPAXNigFWcs6JANg==;
	}

	// Token: 0x06000CF5 RID: 3317 RVA: 0x00067324 File Offset: 0x00065524
	public void #=zv7S2lZXwkZ4C(string #=z$Ib9gYQ=)
	{
		this.#=zBiXPAXNigFWcs6JANg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CF6 RID: 3318 RVA: 0x00067330 File Offset: 0x00065530
	public int #=zAkb1y5EVFbiC()
	{
		return this.#=zwlidEvR9hj2CFaWpgUk2rX8=;
	}

	// Token: 0x06000CF7 RID: 3319 RVA: 0x00067338 File Offset: 0x00065538
	public void #=zYymncTzrSSIR(int #=z$Ib9gYQ=)
	{
		this.#=zwlidEvR9hj2CFaWpgUk2rX8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CF8 RID: 3320 RVA: 0x00067344 File Offset: 0x00065544
	public long #=zqcrTsdIQiIZP()
	{
		return this.#=zIEaQNU69Tvnxn65iZHs6R9Y=;
	}

	// Token: 0x06000CF9 RID: 3321 RVA: 0x0006734C File Offset: 0x0006554C
	public void #=zXSzshOGDSfGl(long #=z$Ib9gYQ=)
	{
		this.#=zIEaQNU69Tvnxn65iZHs6R9Y= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CFA RID: 3322 RVA: 0x00067358 File Offset: 0x00065558
	public List<int> #=zxqd8DBH0LUsd0xrIUw==()
	{
		return this.#=zq0ejRoUODrZOVYB1qgUPLNk=;
	}

	// Token: 0x06000CFB RID: 3323 RVA: 0x00067360 File Offset: 0x00065560
	public void #=zIAgAcVPUIXI83qdFOA==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zq0ejRoUODrZOVYB1qgUPLNk= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000773 RID: 1907
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000774 RID: 1908
	private string #=zBiXPAXNigFWcs6JANg==;

	// Token: 0x04000775 RID: 1909
	private int #=zwlidEvR9hj2CFaWpgUk2rX8=;

	// Token: 0x04000776 RID: 1910
	private long #=zIEaQNU69Tvnxn65iZHs6R9Y=;

	// Token: 0x04000777 RID: 1911
	private List<int> #=zq0ejRoUODrZOVYB1qgUPLNk=;
}
