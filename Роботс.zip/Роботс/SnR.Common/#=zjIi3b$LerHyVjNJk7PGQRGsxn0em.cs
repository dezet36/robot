﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x0200026A RID: 618
internal sealed class #=zjIi3b$LerHyVjNJk7PGQRGsxn0em : EscherContainer
{
	// Token: 0x060012A9 RID: 4777 RVA: 0x000919F0 File Offset: 0x0008FBF0
	public #=zjIi3b$LerHyVjNJk7PGQRGsxn0em(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=zoSy3UGepIM8f = this.Instance;
	}

	// Token: 0x060012AA RID: 4778 RVA: 0x00091A08 File Offset: 0x0008FC08
	public #=zjIi3b$LerHyVjNJk7PGQRGsxn0em(int #=z4UDysxM=) : base(EscherRecordType.BSTORE_CONTAINER)
	{
		this.#=zoSy3UGepIM8f = #=z4UDysxM=;
		this.Instance = this.#=zoSy3UGepIM8f;
	}

	// Token: 0x060012AB RID: 4779 RVA: 0x00091A28 File Offset: 0x0008FC28
	public int #=zEmRQXCLWaJpN5MUbog==()
	{
		return this.#=zoSy3UGepIM8f;
	}

	// Token: 0x04000ABE RID: 2750
	private int #=zoSy3UGepIM8f;
}
