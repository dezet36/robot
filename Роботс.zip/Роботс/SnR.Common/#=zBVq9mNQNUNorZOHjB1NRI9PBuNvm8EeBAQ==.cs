﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000CC RID: 204
internal sealed class #=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ==
{
	// Token: 0x06000573 RID: 1395 RVA: 0x0002E538 File Offset: 0x0002C738
	public #=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ==(int #=z5w6HcG4=, Dictionary<string, object> #=zR1k_w58=)
	{
		this.#=zFzGvi_S6jJhE(#=z5w6HcG4=);
		this.#=zR_v5$VjDx30e(Convert.ToInt32(#=zR1k_w58=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
		this.#=z5WWGoy64FUfHT4MZnA==(Convert.ToInt32(#=zR1k_w58=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
		this.#=zdMm8cbXw4OEf(new List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==>());
		object[] array = JSONManager.GetArray(#=zR1k_w58=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== item = new #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==((Dictionary<string, object>)array[i]);
				this.#=z6Uo9D2yKen_Y().Add(item);
			}
		}
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x0002E5D0 File Offset: 0x0002C7D0
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x0002E5D8 File Offset: 0x0002C7D8
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x0002E5E4 File Offset: 0x0002C7E4
	public int #=zLYM$_iu7NZc_()
	{
		return this.#=zbCFovRgm5pQQfvHcqw==;
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x0002E5EC File Offset: 0x0002C7EC
	public void #=zR_v5$VjDx30e(int #=z$Ib9gYQ=)
	{
		this.#=zbCFovRgm5pQQfvHcqw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x0002E5F8 File Offset: 0x0002C7F8
	public int #=zxYYxigIASBLAf6qBNw==()
	{
		return this.#=z56sbKr4CXHtrCzgGrs8sY4s=;
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x0002E600 File Offset: 0x0002C800
	public void #=z5WWGoy64FUfHT4MZnA==(int #=z$Ib9gYQ=)
	{
		this.#=z56sbKr4CXHtrCzgGrs8sY4s= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x0002E60C File Offset: 0x0002C80C
	public List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=z6Uo9D2yKen_Y()
	{
		return this.#=zDAr22$BxOb_X0tWnjA==;
	}

	// Token: 0x0600057B RID: 1403 RVA: 0x0002E614 File Offset: 0x0002C814
	public void #=zdMm8cbXw4OEf(List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=z$Ib9gYQ=)
	{
		this.#=zDAr22$BxOb_X0tWnjA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400022B RID: 555
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400022C RID: 556
	private int #=zbCFovRgm5pQQfvHcqw==;

	// Token: 0x0400022D RID: 557
	private int #=z56sbKr4CXHtrCzgGrs8sY4s=;

	// Token: 0x0400022E RID: 558
	private List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zDAr22$BxOb_X0tWnjA==;
}
