﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x02000047 RID: 71
internal sealed class #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==
{
	// Token: 0x06000232 RID: 562 RVA: 0x00014FF0 File Offset: 0x000131F0
	public #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM= #=zGYfvSSc=, int #=zp13pRNQ=, int #=z5w6HcG4=)
	{
		this.#=zR4C_mQI=(#=zGYfvSSc=);
		this.#=zedb$WwBQsoJF(#=zp13pRNQ=);
		this.#=zzQwUIEs=(null);
		this.#=zFzGvi_S6jJhE(#=z5w6HcG4=);
	}

	// Token: 0x06000233 RID: 563 RVA: 0x00015014 File Offset: 0x00013214
	public #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==(Dictionary<string, object> #=z8TOr0zY=)
	{
		this.#=zR4C_mQI=((#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM=)0);
		this.#=zedb$WwBQsoJF(Convert.ToInt32(#=z8TOr0zY=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
		this.#=zzQwUIEs=(null);
		this.#=zFzGvi_S6jJhE(Convert.ToInt32(#=z8TOr0zY=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
	}

	// Token: 0x06000234 RID: 564 RVA: 0x0001506C File Offset: 0x0001326C
	public #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM= #=zbOVbkzM=()
	{
		return this.#=zqwpBIVzrCZFhB$HSQw==;
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00015074 File Offset: 0x00013274
	public void #=zR4C_mQI=(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM= #=z$Ib9gYQ=)
	{
		this.#=zqwpBIVzrCZFhB$HSQw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000236 RID: 566 RVA: 0x00015080 File Offset: 0x00013280
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00015088 File Offset: 0x00013288
	public void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000238 RID: 568 RVA: 0x00015094 File Offset: 0x00013294
	public AbstractType #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000239 RID: 569 RVA: 0x0001509C File Offset: 0x0001329C
	public void #=zzQwUIEs=(AbstractType #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600023A RID: 570 RVA: 0x000150A8 File Offset: 0x000132A8
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x0600023B RID: 571 RVA: 0x000150B0 File Offset: 0x000132B0
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x040000A8 RID: 168
	private #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM= #=zqwpBIVzrCZFhB$HSQw==;

	// Token: 0x040000A9 RID: 169
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x040000AA RID: 170
	private AbstractType #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040000AB RID: 171
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x02000048 RID: 72
	public enum #=z3L1b1JM=
	{

	}
}
