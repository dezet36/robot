﻿using System;
using System.Collections.Generic;

// Token: 0x02000078 RID: 120
internal sealed class #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U : List<#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky>
{
	// Token: 0x06000362 RID: 866 RVA: 0x0001F130 File Offset: 0x0001D330
	private #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U()
	{
		this.#=z48rEd0A=(500, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069642)), new List<int>
		{
			500,
			501,
			502,
			503,
			504
		}, 505);
		this.#=z48rEd0A=(11507, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069622)), new List<int>
		{
			11509,
			11508,
			11507
		}, 11509, 11508);
		this.#=z48rEd0A=(11511, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069599)), new List<int>
		{
			11513,
			11512,
			11511
		}, 11513, 11512);
		this.#=z48rEd0A=(10055, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069572)), new List<int>
		{
			10055,
			11000,
			11001
		}, 11001, 11000);
		this.#=z48rEd0A=(11100, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069804)), new List<int>
		{
			11100,
			11101,
			11102
		}, 11102, 11101);
		this.#=z48rEd0A=(11110, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069769)), new List<int>
		{
			11110,
			11111,
			11112
		}, 11112, 11111);
		this.#=z48rEd0A=(11720, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069744)), new List<int>
		{
			11722,
			11721,
			11720
		}, 11722, 11721);
		this.#=z48rEd0A=(8000, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069727)), new List<int>
		{
			8050,
			8051,
			8000,
			8001
		}, 8051);
		this.#=z48rEd0A=(202, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069426)), new List<int>
		{
			202,
			205,
			250,
			251
		}, 205);
		this.#=z48rEd0A=(201, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069405)), new List<int>
		{
			201,
			204,
			250,
			251
		}, 204);
		this.#=z48rEd0A=(200, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069373)), new List<int>
		{
			200,
			203,
			250,
			251
		}, 203);
		this.#=z48rEd0A=(21007, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069341)), new List<int>
		{
			21007,
			21008
		}, 21008);
		this.#=z48rEd0A=(11730, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069552)), new List<int>
		{
			11732,
			11731,
			11730
		}, 11732, 11731);
		this.#=z48rEd0A=(11700, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069527)), new List<int>
		{
			11700,
			11702
		}, 11702);
		this.#=z48rEd0A=(11754, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069490)), 0);
		this.#=z48rEd0A=(11755, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069460)), 0);
		this.#=z48rEd0A=(11752, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071214)), new List<int>
		{
			11752,
			11750
		}, 0);
		this.#=z48rEd0A=(11753, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071177)), new List<int>
		{
			11753,
			11751
		}, 0);
		this.#=z48rEd0A=(11756, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071144)), 0);
		this.#=z48rEd0A=(17008, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071106)), new List<int>
		{
			17008,
			17009
		}, 17009);
	}

	// Token: 0x06000363 RID: 867 RVA: 0x0001F650 File Offset: 0x0001D850
	public static #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U #=zi1hFJwI=()
	{
		return new #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U();
	}

	// Token: 0x06000364 RID: 868 RVA: 0x0001F658 File Offset: 0x0001D858
	private void #=z48rEd0A=(int #=zAk8mKBk=, string #=z6QPrZ_4=, int #=z3RslP7e4jWN_)
	{
		this.#=z48rEd0A=(#=zAk8mKBk=, #=z6QPrZ_4=, new List<int>
		{
			#=zAk8mKBk=
		}, #=z3RslP7e4jWN_);
	}

	// Token: 0x06000365 RID: 869 RVA: 0x0001F670 File Offset: 0x0001D870
	private void #=z48rEd0A=(int #=zAk8mKBk=, string #=z6QPrZ_4=, List<int> #=z8EXY5D4=, int #=zFvMWy0GLvSSlT$ERGg==)
	{
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky = new #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky();
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zbsxKkj4=(#=zAk8mKBk=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zwXKUV2c=(#=z6QPrZ_4=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=z9Dz_ou4g$lCI(#=z8EXY5D4=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zeFwpq2vl2GrQM6lTEQ==(#=zFvMWy0GLvSSlT$ERGg==);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zGbsh0V8TjEsKv0I3qMat3rw=(0);
		base.Add(#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky);
	}

	// Token: 0x06000366 RID: 870 RVA: 0x0001F6A4 File Offset: 0x0001D8A4
	private void #=z48rEd0A=(int #=zAk8mKBk=, string #=z6QPrZ_4=, List<int> #=z8EXY5D4=, int #=zFvMWy0GLvSSlT$ERGg==, int #=znbhcahe6IJEvTSB8PmCmPJo=)
	{
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky = new #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky();
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zbsxKkj4=(#=zAk8mKBk=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zwXKUV2c=(#=z6QPrZ_4=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=z9Dz_ou4g$lCI(#=z8EXY5D4=);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zeFwpq2vl2GrQM6lTEQ==(#=zFvMWy0GLvSSlT$ERGg==);
		#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky.#=zGbsh0V8TjEsKv0I3qMat3rw=(#=znbhcahe6IJEvTSB8PmCmPJo=);
		base.Add(#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky);
	}
}
