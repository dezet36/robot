﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x020001C8 RID: 456
internal sealed class #=zWaKLKYohuwvUhLIsA$3P6cJseyjrr3iLFJ_ms3U= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000D8A RID: 3466 RVA: 0x000694B8 File Offset: 0x000676B8
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z6Bha1HM= = #=zuJjQ1XU=.#=z6Kl4FbeUhsIC();
		this.#=zY5j036GBN4QD = new #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE=(this.#=z8StzeqE=, #=zuJjQ1XU=);
	}

	// Token: 0x06000D8B RID: 3467 RVA: 0x000694D8 File Offset: 0x000676D8
	protected override void #=zvb5bnug=()
	{
		int num = 0;
		if (this.#=zcDRV51Ut$7oP is #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==)
		{
			num = (this.#=zcDRV51Ut$7oP as #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==).#=zs6AfR9w58BN2();
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983061), Array.Empty<object>());
		if (GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=())
		{
			using (List<object[]>.Enumerator enumerator = new List<object[]>
			{
				new object[]
				{
					100,
					113,
					114,
					115,
					134
				},
				new object[]
				{
					119,
					122,
					127,
					128,
					129
				},
				new object[]
				{
					123,
					124,
					125,
					126,
					135
				}
			}.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					object[] #=zVmHaWqy$65pX = enumerator.Current;
					string text = this.#=zBsXSanI=.#=zY59gu_lFZnDu9HO$jJ9ew2SJpU6t(#=zVmHaWqy$65pX);
					text = text.Trim();
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983272), Array.Empty<object>());
					}
					else
					{
						if (text.Length > 1000)
						{
							text = text.Substring(0, 1000);
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983244), new object[]
						{
							text
						});
					}
				}
				return;
			}
		}
		int i = this.#=z6Bha1HM= - 26;
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983203), new object[]
		{
			i
		});
		if (GameApplicationData.#=zlTUywgPvafDO().Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983169), Array.Empty<object>());
			return;
		}
		int num2 = GameApplicationData.#=zlTUywgPvafDO()[GameApplicationData.#=zlTUywgPvafDO().Count - 1].#=zATNrME6IUBVz();
		if (num2 > i)
		{
			Dictionary<ResourceTypes, int> #=zLM9sNe1kTfAD = new Dictionary<ResourceTypes, int>
			{
				{
					ResourceTypes.Grain,
					50 * GameApplicationData.#=zlTUywgPvafDO().Count
				},
				{
					ResourceTypes.Bronze,
					50 * GameApplicationData.#=zlTUywgPvafDO().Count
				},
				{
					ResourceTypes.Lumber,
					50 * GameApplicationData.#=zlTUywgPvafDO().Count
				}
			};
			this.#=zY5j036GBN4QD.#=z21YYvJ6a1B3O(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982881), Array.Empty<object>()), #=zLM9sNe1kTfAD, true, true);
			foreach (GameApplicationData.#=zgqETFlBJCPw4 #=zgqETFlBJCPw in GameApplicationData.#=zlTUywgPvafDO())
			{
				if (#=zgqETFlBJCPw.#=zATNrME6IUBVz() > i)
				{
					string text2 = this.#=zBsXSanI=.#=zew8mYj9PXteE(#=zgqETFlBJCPw.#=zATNrME6IUBVz(), #=zgqETFlBJCPw.#=z0I9lfENpa60boKog9g==(), false);
					text2 = text2.Trim();
					if (text2.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982856), new object[]
						{
							#=zgqETFlBJCPw.#=zATNrME6IUBVz()
						});
						i = #=zgqETFlBJCPw.#=zATNrME6IUBVz();
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982822), new object[]
						{
							#=zgqETFlBJCPw.#=zATNrME6IUBVz(),
							JSONManager.Cut(text2)
						});
					}
				}
			}
		}
		if (i < num && num2 <= i)
		{
			while (i < num)
			{
				int num3 = i + 4;
				string text3 = this.#=zBsXSanI=.#=zew8mYj9PXteE(num3, 0, true);
				text3 = text3.Trim();
				if (text3.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982822), new object[]
					{
						num3,
						JSONManager.Cut(text3)
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982856), new object[]
				{
					num3
				});
				i = num3;
			}
		}
	}

	// Token: 0x040007BE RID: 1982
	private int #=z6Bha1HM=;

	// Token: 0x040007BF RID: 1983
	private #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE= #=zY5j036GBN4QD;
}
