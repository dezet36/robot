﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Interface;

// Token: 0x020000B2 RID: 178
internal sealed partial class #=z9HZcARnstYnQ$aripH3S6L9t52vEbkCnxw== : Form
{
	// Token: 0x060004A8 RID: 1192 RVA: 0x00026D90 File Offset: 0x00024F90
	public #=z9HZcARnstYnQ$aripH3S6L9t52vEbkCnxw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=)
	{
		this.#=zG_DebDU= = true;
		this.#=zgpzgXirqPT5_();
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zEhGRLRSSQTM3nxmPHQ== = new List<AccountInfoForBinding>();
		int count = this.#=zshVEGQI=.#=zOdy_aU_tk1aY().Count;
		this.#=zKwY5fhI=.Items.Clear();
		for (int i = 0; i < count; i++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = this.#=zshVEGQI=.#=zOdy_aU_tk1aY()[i];
			AccountInfoForBinding accountInfoForBinding = new AccountInfoForBinding(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
			accountInfoForBinding.UserName = #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zbfOGJA_8wt3H();
			this.#=zEhGRLRSSQTM3nxmPHQ==.Add(accountInfoForBinding);
			this.#=zKwY5fhI=.Items.Add(i + 1);
		}
		this.#=zyOh81vGXmDSr1fHzng==.AutoGenerateColumns = false;
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zEhGRLRSSQTM3nxmPHQ==;
		this.#=zG_DebDU= = false;
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x00026E64 File Offset: 0x00025064
	private void #=z7aNFeNnCVbyMj1E8Zln$LrcS3B8u(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		int num = 1;
		if (#=z4Q$h3mE=.ColumnIndex == num && #=z4Q$h3mE=.RowIndex > 0)
		{
			this.#=zEhGRLRSSQTM3nxmPHQ==.Reverse(#=z4Q$h3mE=.RowIndex - 1, 2);
			this.#=z0HUmd$RgePjJ();
			return;
		}
		if (#=z4Q$h3mE=.ColumnIndex == num + 1 && #=z4Q$h3mE=.RowIndex < this.#=zEhGRLRSSQTM3nxmPHQ==.Count - 1)
		{
			this.#=zEhGRLRSSQTM3nxmPHQ==.Reverse(#=z4Q$h3mE=.RowIndex, 2);
			this.#=z0HUmd$RgePjJ();
		}
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x00026ED8 File Offset: 0x000250D8
	private void #=zc4froDOSW6u9u5p4SXg_Ww8=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zG_DebDU=)
		{
			return;
		}
		if (#=z4Q$h3mE=.ColumnIndex == 0 && #=z4Q$h3mE=.RowIndex >= 0)
		{
			int rowIndex = #=z4Q$h3mE=.RowIndex;
			AccountInfoForBinding accountInfoForBinding = this.#=zEhGRLRSSQTM3nxmPHQ==[rowIndex];
			this.#=zEhGRLRSSQTM3nxmPHQ==.RemoveAt(rowIndex);
			this.#=zEhGRLRSSQTM3nxmPHQ==.Insert(accountInfoForBinding.Position, accountInfoForBinding);
			this.#=z0HUmd$RgePjJ();
		}
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x00026F38 File Offset: 0x00025138
	private void #=z0HUmd$RgePjJ()
	{
		this.#=zG_DebDU= = true;
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
		for (int i = 0; i < this.#=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			this.#=zEhGRLRSSQTM3nxmPHQ==[i].Position = i;
		}
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zEhGRLRSSQTM3nxmPHQ==;
		this.#=zG_DebDU= = false;
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x00026F98 File Offset: 0x00025198
	private void #=zUeK9k2DP6FKAnO9eVTsdRjQcVYLJ(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zyOh81vGXmDSr1fHzng==.CurrentCell.ColumnIndex == 0)
		{
			this.#=zyOh81vGXmDSr1fHzng==.CommitEdit(DataGridViewDataErrorContexts.Commit);
		}
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x00026FC0 File Offset: 0x000251C0
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==> list = new List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==>();
		foreach (AccountInfoForBinding accountInfoForBinding in this.#=zEhGRLRSSQTM3nxmPHQ==)
		{
			list.Add(accountInfoForBinding.#=zh5Q$jgycqA15());
		}
		this.#=zshVEGQI=.#=z0ZcCdTI=(list, false);
		base.Close();
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x00027034 File Offset: 0x00025234
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x0002705C File Offset: 0x0002525C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zyOh81vGXmDSr1fHzng== = new DataGridView();
		this.#=zKwY5fhI= = new DataGridViewComboBoxColumn();
		this.#=zDbjCW2c= = new DataGridViewButtonColumn();
		this.#=zswuKTlM= = new DataGridViewButtonColumn();
		this.#=zUYDMdDU= = new DataGridViewTextBoxColumn();
		this.#=zWVnfo6o= = new DataGridViewTextBoxColumn();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zHeAVXAs= = new Button();
		this.#=zuCaP$Fc= = new Button();
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).BeginInit();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		base.SuspendLayout();
		this.#=zyOh81vGXmDSr1fHzng==.AllowUserToAddRows = false;
		this.#=zyOh81vGXmDSr1fHzng==.AllowUserToDeleteRows = false;
		this.#=zyOh81vGXmDSr1fHzng==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zyOh81vGXmDSr1fHzng==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zKwY5fhI=,
			this.#=zDbjCW2c=,
			this.#=zswuKTlM=,
			this.#=zUYDMdDU=,
			this.#=zWVnfo6o=
		});
		this.#=zyOh81vGXmDSr1fHzng==.Dock = DockStyle.Fill;
		this.#=zyOh81vGXmDSr1fHzng==.Location = new Point(0, 0);
		this.#=zyOh81vGXmDSr1fHzng==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111099);
		this.#=zyOh81vGXmDSr1fHzng==.Size = new Size(540, 317);
		this.#=zyOh81vGXmDSr1fHzng==.TabIndex = 0;
		this.#=zyOh81vGXmDSr1fHzng==.CellContentClick += this.#=z7aNFeNnCVbyMj1E8Zln$LrcS3B8u;
		this.#=zyOh81vGXmDSr1fHzng==.CellValueChanged += this.#=zc4froDOSW6u9u5p4SXg_Ww8=;
		this.#=zyOh81vGXmDSr1fHzng==.CurrentCellDirtyStateChanged += this.#=zUeK9k2DP6FKAnO9eVTsdRjQcVYLJ;
		this.#=zKwY5fhI=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111086);
		this.#=zKwY5fhI=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112973);
		this.#=zKwY5fhI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112690);
		this.#=zDbjCW2c=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112674);
		this.#=zDbjCW2c=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112665);
		this.#=zDbjCW2c=.Resizable = DataGridViewTriState.True;
		this.#=zDbjCW2c=.SortMode = DataGridViewColumnSortMode.Automatic;
		this.#=zDbjCW2c=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080192);
		this.#=zDbjCW2c=.UseColumnTextForButtonValue = true;
		this.#=zDbjCW2c=.Width = 60;
		this.#=zswuKTlM=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112648);
		this.#=zswuKTlM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112645);
		this.#=zswuKTlM=.Resizable = DataGridViewTriState.True;
		this.#=zswuKTlM=.SortMode = DataGridViewColumnSortMode.Automatic;
		this.#=zswuKTlM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767);
		this.#=zswuKTlM=.UseColumnTextForButtonValue = true;
		this.#=zswuKTlM=.Width = 60;
		this.#=zUYDMdDU=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111263);
		this.#=zUYDMdDU=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zUYDMdDU=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112618);
		this.#=zUYDMdDU=.ReadOnly = true;
		this.#=zWVnfo6o=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111293);
		this.#=zWVnfo6o=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112603);
		this.#=zWVnfo6o=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112597);
		this.#=zWVnfo6o=.ReadOnly = true;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel2;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zyOh81vGXmDSr1fHzng==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zuCaP$Fc=);
		this.#=zByiHPAwyKD$Q.Size = new Size(540, 363);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 317;
		this.#=zByiHPAwyKD$Q.TabIndex = 1;
		this.#=zHeAVXAs=.Location = new Point(202, 7);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(111, 23);
		this.#=zHeAVXAs=.TabIndex = 1;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zuCaP$Fc=.Location = new Point(12, 7);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(111, 23);
		this.#=zuCaP$Fc=.TabIndex = 0;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112827);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(540, 363);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112820);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112799);
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).EndInit();
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040001BD RID: 445
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x040001BE RID: 446
	private List<AccountInfoForBinding> #=zEhGRLRSSQTM3nxmPHQ==;

	// Token: 0x040001BF RID: 447
	private bool #=zG_DebDU=;

	// Token: 0x040001C1 RID: 449
	private DataGridView #=zyOh81vGXmDSr1fHzng==;

	// Token: 0x040001C2 RID: 450
	private DataGridViewComboBoxColumn #=zKwY5fhI=;

	// Token: 0x040001C3 RID: 451
	private DataGridViewButtonColumn #=zDbjCW2c=;

	// Token: 0x040001C4 RID: 452
	private DataGridViewButtonColumn #=zswuKTlM=;

	// Token: 0x040001C5 RID: 453
	private DataGridViewTextBoxColumn #=zUYDMdDU=;

	// Token: 0x040001C6 RID: 454
	private DataGridViewTextBoxColumn #=zWVnfo6o=;

	// Token: 0x040001C7 RID: 455
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x040001C8 RID: 456
	private Button #=zHeAVXAs=;

	// Token: 0x040001C9 RID: 457
	private Button #=zuCaP$Fc=;
}
