﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x020000DE RID: 222
internal sealed class #=zDQJuiDzV7frl3AP2cTATd6w_y1fmnPyLvUV8aCnHkP7nva7tPC5251B4PMz_ : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060005EB RID: 1515 RVA: 0x00030A58 File Offset: 0x0002EC58
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x00030A5C File Offset: 0x0002EC5C
	protected override void #=zvb5bnug=()
	{
		#=zr0knfnO6bFMIIWkqFkXITx$Q7xlZx93KVy0tLj8= #=zr0knfnO6bFMIIWkqFkXITx$Q7xlZx93KVy0tLj8= = (#=zr0knfnO6bFMIIWkqFkXITx$Q7xlZx93KVy0tLj8=)this.#=zcDRV51Ut$7oP;
		int num = #=zr0knfnO6bFMIIWkqFkXITx$Q7xlZx93KVy0tLj8=.#=zs6AfR9w58BN2()[0];
		switch (#=zr0knfnO6bFMIIWkqFkXITx$Q7xlZx93KVy0tLj8=.#=zs6AfR9w58BN2()[1])
		{
		case 0:
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929054), new object[]
			{
				num
			});
			string text = this.#=zBsXSanI=.#=zcMzsxux2PNxUE9oteQcj1JR6QFos(num);
			text = text.Trim();
			if (#=zDQJuiDzV7frl3AP2cTATd6w_y1fmnPyLvUV8aCnHkP7nva7tPC5251B4PMz_.#=z2D7syGj03O9k(num, text))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929248), new object[]
				{
					num
				});
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929215), new object[]
				{
					num,
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929164), new object[]
			{
				num,
				JSONManager.Cut(text)
			});
			return;
		}
		case 1:
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930900), new object[]
			{
				num
			});
			string text = this.#=zBsXSanI=.#=z0sb_hDoHi3y3UT4$gvmU2Vyh96kwPFmAew==(num);
			text = text.Trim();
			if (#=zDQJuiDzV7frl3AP2cTATd6w_y1fmnPyLvUV8aCnHkP7nva7tPC5251B4PMz_.#=z2D7syGj03O9k(num, text))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930844), new object[]
				{
					num
				});
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931041), new object[]
				{
					num,
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930988), new object[]
			{
				num,
				JSONManager.Cut(text)
			});
			return;
		}
		case 2:
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930678), Array.Empty<object>());
			string text = this.#=zBsXSanI=.#=zAOb$cs_A61B707qbrY1kYGvsDAwUtSn96A==();
			text = text.Trim();
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930628), Array.Empty<object>());
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930567), new object[]
				{
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930744), new object[]
			{
				JSONManager.Cut(text)
			});
			return;
		}
		default:
			return;
		}
	}

	// Token: 0x060005ED RID: 1517 RVA: 0x00030D3C File Offset: 0x0002EF3C
	public static bool #=z2D7syGj03O9k(int #=zXuGeJQbVMolHLiENIA==, string #=zWPMc4vfO9Ufs)
	{
		if (#=zWPMc4vfO9Ufs.Length > 10000)
		{
			return true;
		}
		if (#=zWPMc4vfO9Ufs.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055745)))
		{
			return true;
		}
		try
		{
			if (JSONManager.GetInt(JSONManager.GetData(#=zWPMc4vfO9Ufs), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930689), 0) == #=zXuGeJQbVMolHLiENIA==)
			{
				return true;
			}
		}
		catch
		{
		}
		return false;
	}
}
