﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020001EA RID: 490
internal sealed class #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= : IIntID
{
	// Token: 0x06000ECD RID: 3789 RVA: 0x00076424 File Offset: 0x00074624
	public #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=(int #=zAk8mKBk=, int #=zTDtB7zv7BfB4, int #=zUTW72M70Fvrc)
	{
		this.Id = #=zAk8mKBk=;
		this.#=zwXKUV2c=(#=zAk8mKBk=.ToString());
		this.#=z8RUD$1mtl5at(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Unknown);
		this.#=zHKKXo3Re_b4C(#=zTDtB7zv7BfB4);
		this.#=zI74NzG$2ecMvvw_Hiw==(#=zUTW72M70Fvrc);
		this.#=zzdBW4vN6GeOP(new List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U>());
	}

	// Token: 0x06000ECE RID: 3790 RVA: 0x00076460 File Offset: 0x00074660
	public #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=(Dictionary<string, object> #=z1YNp7IY=)
	{
		this.Id = JSONManager.ExtractInt(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
		this.#=zwXKUV2c=(JSONManager.GetString(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060580));
		this.#=z8RUD$1mtl5at((#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), -1));
		if (this.#=zZOFUOewkm7ea() == #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Ring)
		{
			if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060525), 0) > 0)
			{
				this.#=z8RUD$1mtl5at(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack);
			}
			else if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060506), 0) > 0)
			{
				this.#=z8RUD$1mtl5at(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingDefense);
			}
		}
		object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086));
		if (array != null)
		{
			this.#=zHKKXo3Re_b4C(array.Length);
		}
		else
		{
			this.#=zHKKXo3Re_b4C(0);
		}
		this.#=zI74NzG$2ecMvvw_Hiw==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), -1) + 1);
		this.#=zZUzs45h2fs9w(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		this.#=zzdBW4vN6GeOP(new List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U>());
		object[] array2 = JSONManager.GetArray(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060499));
		object[] array3 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069914));
		this.#=zpR$SovC$uXLU(0);
		if (array2 != null && array3 != null)
		{
			int num = (array2.Length > array3.Length) ? array3.Length : array2.Length;
			double num2 = 0.0;
			for (int i = 0; i < num; i++)
			{
				Dictionary<string, object> dictionary2 = (Dictionary<string, object>)array3[i];
				double num3 = JSONManager.ExtractDouble(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0.0);
				double num4 = JSONManager.ExtractDouble(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0.0);
				double num5 = (num3 > 0.0) ? num3 : num4;
				num2 += num5;
				List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U> list = this.#=z2fOvUeiaHzR6();
				#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U #=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U = new #=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U();
				#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U.#=zFzGvi_S6jJhE(i);
				#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U.#=zxyxsU3Nw3pkbz6KzQL4a3Lw=(JSONManager.GetInt(array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0));
				#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U.#=z$lXumYwaQq$0(num5);
				#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U.#=zN4pxYhBIgTlk(num2);
				list.Add(#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U);
				if (i == 0)
				{
					this.#=zpR$SovC$uXLU(JSONManager.GetInt(array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0));
				}
			}
		}
	}

	// Token: 0x17000049 RID: 73
	// (get) Token: 0x06000ECF RID: 3791 RVA: 0x0007668C File Offset: 0x0007488C
	// (set) Token: 0x06000ED0 RID: 3792 RVA: 0x00076694 File Offset: 0x00074894
	public int Id
	{
		[CompilerGenerated]
		get
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = value;
		}
	}

	// Token: 0x06000ED1 RID: 3793 RVA: 0x000766A0 File Offset: 0x000748A0
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06000ED2 RID: 3794 RVA: 0x000766A8 File Offset: 0x000748A8
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000ED3 RID: 3795 RVA: 0x000766B4 File Offset: 0x000748B4
	public #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions #=zZOFUOewkm7ea()
	{
		return this.#=zxxpCOnxCUYo104orQw==;
	}

	// Token: 0x06000ED4 RID: 3796 RVA: 0x000766BC File Offset: 0x000748BC
	public void #=z8RUD$1mtl5at(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions #=z$Ib9gYQ=)
	{
		this.#=zxxpCOnxCUYo104orQw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000ED5 RID: 3797 RVA: 0x000766C8 File Offset: 0x000748C8
	public int #=zVaUA5_qegiur()
	{
		return this.#=z4bgbc9KraCP04E8LTg==;
	}

	// Token: 0x06000ED6 RID: 3798 RVA: 0x000766D0 File Offset: 0x000748D0
	private void #=zHKKXo3Re_b4C(int #=z$Ib9gYQ=)
	{
		this.#=z4bgbc9KraCP04E8LTg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000ED7 RID: 3799 RVA: 0x000766DC File Offset: 0x000748DC
	public int #=zaKAy47_E$9SRuF6oiw==()
	{
		return this.#=zg9DHdRJeKrYsJIc4CEiCbn4=;
	}

	// Token: 0x06000ED8 RID: 3800 RVA: 0x000766E4 File Offset: 0x000748E4
	private void #=zI74NzG$2ecMvvw_Hiw==(int #=z$Ib9gYQ=)
	{
		this.#=zg9DHdRJeKrYsJIc4CEiCbn4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000ED9 RID: 3801 RVA: 0x000766F0 File Offset: 0x000748F0
	public int #=zehX0B69q4EZn()
	{
		return this.#=zMoJVbnpRgc0mKKQieg==;
	}

	// Token: 0x06000EDA RID: 3802 RVA: 0x000766F8 File Offset: 0x000748F8
	private void #=zZUzs45h2fs9w(int #=z$Ib9gYQ=)
	{
		this.#=zMoJVbnpRgc0mKKQieg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EDB RID: 3803 RVA: 0x00076704 File Offset: 0x00074904
	public List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U> #=z2fOvUeiaHzR6()
	{
		return this.#=z_c5$1iH1aVFBZJaO9ZRRwRQ=;
	}

	// Token: 0x06000EDC RID: 3804 RVA: 0x0007670C File Offset: 0x0007490C
	private void #=zzdBW4vN6GeOP(List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U> #=z$Ib9gYQ=)
	{
		this.#=z_c5$1iH1aVFBZJaO9ZRRwRQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EDD RID: 3805 RVA: 0x00076718 File Offset: 0x00074918
	public int #=zFpfdS67Awhv4Ns$3NQ==()
	{
		return this.#=z2fOvUeiaHzR6().Count - 1;
	}

	// Token: 0x06000EDE RID: 3806 RVA: 0x00076728 File Offset: 0x00074928
	public int #=zZwcQkwkOzFoj()
	{
		return this.#=zFZ2jFMPolMMAlB4UQjKBZA0=;
	}

	// Token: 0x06000EDF RID: 3807 RVA: 0x00076730 File Offset: 0x00074930
	public void #=zpR$SovC$uXLU(int #=z$Ib9gYQ=)
	{
		this.#=zFZ2jFMPolMMAlB4UQjKBZA0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EE0 RID: 3808 RVA: 0x0007673C File Offset: 0x0007493C
	public static bool #=zXkKSxVcvanF8qkH_$A==(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions #=z3lUqbh8=)
	{
		switch (#=z3lUqbh8=)
		{
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Sword:
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Gloves:
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Boots:
			break;
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Helmet:
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Shield:
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.ChestArmor:
			return false;
		default:
			if (#=z3lUqbh8= != #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack)
			{
				if (#=z3lUqbh8= != #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingDefense)
				{
					return false;
				}
				return false;
			}
			break;
		}
		return true;
	}

	// Token: 0x06000EE1 RID: 3809 RVA: 0x00076770 File Offset: 0x00074970
	public static int[] #=zdW1iUhMLgxS2(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions #=z3lUqbh8=)
	{
		switch (#=z3lUqbh8=)
		{
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Sword:
			return new int[]
			{
				5
			};
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Helmet:
			return new int[]
			{
				8
			};
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Shield:
			return new int[]
			{
				9
			};
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.ChestArmor:
			return new int[]
			{
				10
			};
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Gloves:
			return new int[]
			{
				4
			};
		case #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.Boots:
			return new int[]
			{
				6
			};
		default:
			if (#=z3lUqbh8= - #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack <= 1)
			{
				return new int[]
				{
					3,
					7
				};
			}
			return new int[0];
		}
	}

	// Token: 0x06000EE2 RID: 3810 RVA: 0x000767FC File Offset: 0x000749FC
	public int[] #=zjUdjHK39LnOi()
	{
		return #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zdW1iUhMLgxS2(this.#=zZOFUOewkm7ea());
	}

	// Token: 0x06000EE3 RID: 3811 RVA: 0x0007680C File Offset: 0x00074A0C
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x04000840 RID: 2112
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000841 RID: 2113
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000842 RID: 2114
	private #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions #=zxxpCOnxCUYo104orQw==;

	// Token: 0x04000843 RID: 2115
	private int #=z4bgbc9KraCP04E8LTg==;

	// Token: 0x04000844 RID: 2116
	private int #=zg9DHdRJeKrYsJIc4CEiCbn4=;

	// Token: 0x04000845 RID: 2117
	private int #=zMoJVbnpRgc0mKKQieg==;

	// Token: 0x04000846 RID: 2118
	private List<#=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U> #=z_c5$1iH1aVFBZJaO9ZRRwRQ=;

	// Token: 0x04000847 RID: 2119
	private int #=zFZ2jFMPolMMAlB4UQjKBZA0=;

	// Token: 0x020001EB RID: 491
	public enum Functions
	{
		// Token: 0x04000849 RID: 2121
		Unknown = -1,
		// Token: 0x0400084A RID: 2122
		Sword,
		// Token: 0x0400084B RID: 2123
		Helmet,
		// Token: 0x0400084C RID: 2124
		Shield,
		// Token: 0x0400084D RID: 2125
		ChestArmor,
		// Token: 0x0400084E RID: 2126
		Gloves,
		// Token: 0x0400084F RID: 2127
		Boots,
		// Token: 0x04000850 RID: 2128
		Ring,
		// Token: 0x04000851 RID: 2129
		RingAttack = 61,
		// Token: 0x04000852 RID: 2130
		RingDefense
	}
}
