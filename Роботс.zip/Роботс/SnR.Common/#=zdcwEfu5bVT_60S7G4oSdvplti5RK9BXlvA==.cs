﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;

// Token: 0x02000220 RID: 544
internal sealed class #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=> : IComparer<#=zQSoxQMk=>
{
	// Token: 0x060010A6 RID: 4262 RVA: 0x000803AC File Offset: 0x0007E5AC
	public #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==(PropertyDescriptor #=zOWJ4bdA=, ListSortDirection #=zRGPJDz8=)
	{
		this.#=zOY$UO5o= = #=zOWJ4bdA=;
		Type type = typeof(Comparer<>).MakeGenericType(new Type[]
		{
			#=zOWJ4bdA=.PropertyType
		});
		this.#=z6_x9K_4= = (IComparer)type.InvokeMember(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050249), BindingFlags.Static | BindingFlags.Public | BindingFlags.GetProperty, null, null, null);
		this.#=zSL_qZ5aA4tnJ(#=zRGPJDz8=);
	}

	// Token: 0x060010A7 RID: 4263 RVA: 0x00080410 File Offset: 0x0007E610
	public int Compare(#=zQSoxQMk= #=zQrqFdos=, #=zQSoxQMk= #=zKFlJyLE=)
	{
		return this.#=zTGL5frw= * this.#=z6_x9K_4=.Compare(this.#=zOY$UO5o=.GetValue(#=zQrqFdos=), this.#=zOY$UO5o=.GetValue(#=zKFlJyLE=));
	}

	// Token: 0x060010A8 RID: 4264 RVA: 0x00080448 File Offset: 0x0007E648
	private void #=zqSUPSqLEdvs4(PropertyDescriptor #=zOwizNcA=)
	{
		this.#=zOY$UO5o= = #=zOwizNcA=;
	}

	// Token: 0x060010A9 RID: 4265 RVA: 0x00080454 File Offset: 0x0007E654
	private void #=zSL_qZ5aA4tnJ(ListSortDirection #=zRGPJDz8=)
	{
		this.#=zTGL5frw= = ((#=zRGPJDz8= == ListSortDirection.Ascending) ? 1 : -1);
	}

	// Token: 0x060010AA RID: 4266 RVA: 0x00080464 File Offset: 0x0007E664
	public void #=zgtrfwuEw1r5T(PropertyDescriptor #=zOwizNcA=, ListSortDirection #=zRGPJDz8=)
	{
		this.#=zqSUPSqLEdvs4(#=zOwizNcA=);
		this.#=zSL_qZ5aA4tnJ(#=zRGPJDz8=);
	}

	// Token: 0x04000902 RID: 2306
	private readonly IComparer #=z6_x9K_4=;

	// Token: 0x04000903 RID: 2307
	private PropertyDescriptor #=zOY$UO5o=;

	// Token: 0x04000904 RID: 2308
	private int #=zTGL5frw=;
}
