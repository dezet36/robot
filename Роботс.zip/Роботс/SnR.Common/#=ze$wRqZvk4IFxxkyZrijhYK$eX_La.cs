﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;

// Token: 0x02000224 RID: 548
internal sealed class #=ze$wRqZvk4IFxxkyZrijhYK$eX_La : List<#=zDSiRXECNe4Awos25aECUKlmR8FRd>, IDisposable
{
	// Token: 0x060010C5 RID: 4293 RVA: 0x000812A8 File Offset: 0x0007F4A8
	public #=ze$wRqZvk4IFxxkyZrijhYK$eX_La(string #=zpkz1bP8=, int #=zLeeSKrg=)
	{
		this.#=zgrqggGpnoQz_ = #=zpkz1bP8=;
		this.#=zgs9J0JlAFhod = #=zLeeSKrg=;
		this.#=zSV4$mlFB34WM = new object();
	}

	// Token: 0x060010C6 RID: 4294 RVA: 0x000812CC File Offset: 0x0007F4CC
	public void #=z48rEd0A=(#=zDSiRXECNe4Awos25aECUKlmR8FRd #=zsbwXxuA=)
	{
		object obj = this.#=zSV4$mlFB34WM;
		lock (obj)
		{
			base.Add(#=zsbwXxuA=);
		}
	}

	// Token: 0x060010C7 RID: 4295 RVA: 0x00081310 File Offset: 0x0007F510
	public void #=zLyaSD5E=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Debug, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
	}

	// Token: 0x060010C8 RID: 4296 RVA: 0x00081324 File Offset: 0x0007F524
	public void #=z9tn1xKU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Tracing, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
	}

	// Token: 0x060010C9 RID: 4297 RVA: 0x00081338 File Offset: 0x0007F538
	public void #=zJWtlXjI=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Action, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
	}

	// Token: 0x060010CA RID: 4298 RVA: 0x0008134C File Offset: 0x0007F54C
	public void #=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, Exception #=zN_s5Z5A=)
	{
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Exception, #=zN_s5Z5A=.Message, new object[0]));
		if (!#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zOYMXOJADXFX8(#=zN_s5Z5A=))
		{
			ProxyInfo proxyInfo = (#=zG2wnL_q7IxpD != null) ? #=zG2wnL_q7IxpD.#=z9TrQaE7EBV1U() : null;
			string #=z52HL_CpuRYfT;
			object[] #=zlP66l7Q4Pzmc;
			if (proxyInfo != null)
			{
				#=z52HL_CpuRYfT = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023743);
				#=zlP66l7Q4Pzmc = new object[]
				{
					#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=),
					proxyInfo.ProxyKey
				};
			}
			else
			{
				#=z52HL_CpuRYfT = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
				#=zlP66l7Q4Pzmc = new object[0];
			}
			this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Debug, #=z52HL_CpuRYfT, #=zlP66l7Q4Pzmc));
		}
	}

	// Token: 0x060010CB RID: 4299 RVA: 0x000813D0 File Offset: 0x0007F5D0
	public void #=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Exception, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
	}

	// Token: 0x060010CC RID: 4300 RVA: 0x000813E4 File Offset: 0x0007F5E4
	public void #=zwxyx_F3Vi0PD(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		int num = base.Count - 1;
		while (num >= base.Count - 11 && num >= 0)
		{
			if (base[num].#=zTNSS3ihKtVfU().Equals(#=zx9NCziM=))
			{
				return;
			}
			num--;
		}
		this.#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, LogTypes.Exception, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
	}

	// Token: 0x060010CD RID: 4301 RVA: 0x00081434 File Offset: 0x0007F634
	public void #=zsmQjpuU8O8mL()
	{
		for (int i = 0; i < base.Count; i++)
		{
			base[i].#=zWRBkqWnAY2Zq(false);
		}
	}

	// Token: 0x060010CE RID: 4302 RVA: 0x00081460 File Offset: 0x0007F660
	public void #=zrXwvRiNy$F1i(double #=zjrBBdA_KdVXO)
	{
		this.#=zrXwvRiNy$F1i(#=zjrBBdA_KdVXO, 100);
	}

	// Token: 0x060010CF RID: 4303 RVA: 0x0008146C File Offset: 0x0007F66C
	private void #=zrXwvRiNy$F1i(double #=zjrBBdA_KdVXO, int #=zqgBhlVa1qeK2JiFNAw==)
	{
		try
		{
			if (base.Count > #=zqgBhlVa1qeK2JiFNAw== && base.Count > 0)
			{
				#=ze$wRqZvk4IFxxkyZrijhYK$eX_La.#=zbjP7ZBivanWUvybn8iffczU= #=zbjP7ZBivanWUvybn8iffczU= = new #=ze$wRqZvk4IFxxkyZrijhYK$eX_La.#=zbjP7ZBivanWUvybn8iffczU=();
				StringBuilder stringBuilder = new StringBuilder();
				#=zbjP7ZBivanWUvybn8iffczU=.#=z3hhV84$aYAY7 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z_B7PL3U2K4yBHXwnUg==();
				object obj = this.#=zSV4$mlFB34WM;
				lock (obj)
				{
					DateTime t = DateTime.Now - TimeSpan.FromHours(#=zjrBBdA_KdVXO);
					while (base.Count > #=zqgBhlVa1qeK2JiFNAw== && base[0].#=zPHMvvJ8=() < t)
					{
						if (#=zbjP7ZBivanWUvybn8iffczU=.#=z3hhV84$aYAY7 > 0)
						{
							stringBuilder.AppendLine(base[0].#=zwoF3kPznsOcA());
						}
						base.RemoveAt(0);
					}
				}
				if (stringBuilder.Length > 0)
				{
					try
					{
						string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023531), new object[]
						{
							GameApplicationData.#=zZ2dsDUeWDYAN(),
							this.#=zgrqggGpnoQz_,
							this.#=zgs9J0JlAFhod,
							DateTime.Today.ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023695))
						});
						DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetDirectoryName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023531)));
						if (!directoryInfo.Exists)
						{
							directoryInfo.Create();
						}
						if (!#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
						{
							FileInfo[] array = Enumerable.ToArray<FileInfo>(Enumerable.Where<FileInfo>(directoryInfo.GetFiles(), new Func<FileInfo, bool>(#=zbjP7ZBivanWUvybn8iffczU=.#=z2aTnz97l7zfSm$47HQ==)));
							for (int i = 0; i < array.Length; i++)
							{
								#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(array[i].FullName);
							}
						}
						#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zxyAQIs1RlUuf(#=z0ONi4Bk=, stringBuilder.ToString(), null);
					}
					catch (Exception #=zN_s5Z5A=)
					{
						this.#=zbbu$0jU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023678), new object[]
						{
							#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
						});
					}
				}
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zbbu$0jU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023624), new object[]
			{
				#=zjrBBdA_KdVXO,
				#=zqgBhlVa1qeK2JiFNAw==,
				#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=2)
			});
		}
	}

	// Token: 0x060010D0 RID: 4304 RVA: 0x000816A8 File Offset: 0x0007F8A8
	public void Dispose()
	{
		this.#=zrXwvRiNy$F1i(-100.0, 0);
	}

	// Token: 0x04000911 RID: 2321
	private string #=zgrqggGpnoQz_;

	// Token: 0x04000912 RID: 2322
	private int #=zgs9J0JlAFhod;

	// Token: 0x04000913 RID: 2323
	private object #=zSV4$mlFB34WM;

	// Token: 0x02000225 RID: 549
	private sealed class #=zbjP7ZBivanWUvybn8iffczU=
	{
		// Token: 0x060010D2 RID: 4306 RVA: 0x000816C4 File Offset: 0x0007F8C4
		internal bool #=z2aTnz97l7zfSm$47HQ==(FileInfo #=zQrqFdos=)
		{
			return #=zQrqFdos=.LastWriteTime < DateTime.Now.AddDays((double)(-(double)this.#=z3hhV84$aYAY7));
		}

		// Token: 0x04000914 RID: 2324
		public int #=z3hhV84$aYAY7;
	}
}
