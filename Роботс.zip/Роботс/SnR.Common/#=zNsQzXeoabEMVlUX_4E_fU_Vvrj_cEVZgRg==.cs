﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

// Token: 0x0200016D RID: 365
internal sealed class #=zNsQzXeoabEMVlUX_4E_fU_Vvrj_cEVZgRg==
{
	// Token: 0x060009A9 RID: 2473 RVA: 0x0004F928 File Offset: 0x0004DB28
	private #=zNsQzXeoabEMVlUX_4E_fU_Vvrj_cEVZgRg==(DataGridView #=zTNBXCzs=, string[] #=znpqO4SAeWz$_)
	{
		this.#=zCKPevQOlZNKv = #=zTNBXCzs=;
		this.#=zmU2HDA4YP0n$ = new List<int>();
		foreach (string columnName in #=znpqO4SAeWz$_)
		{
			DataGridViewColumn dataGridViewColumn = #=zTNBXCzs=.Columns[columnName];
			if (dataGridViewColumn != null)
			{
				this.#=zmU2HDA4YP0n$.Add(dataGridViewColumn.Index);
			}
		}
		this.#=zCKPevQOlZNKv.CellFormatting += this.#=zyES_ll9khY7s;
		this.#=zCKPevQOlZNKv.EditingControlShowing += this.#=zAcWcAE$3JReH;
	}

	// Token: 0x060009AA RID: 2474 RVA: 0x0004F9B0 File Offset: 0x0004DBB0
	public static #=zNsQzXeoabEMVlUX_4E_fU_Vvrj_cEVZgRg== #=zcBW$PBE=(DataGridView #=zTNBXCzs=, string[] #=znpqO4SAeWz$_)
	{
		return new #=zNsQzXeoabEMVlUX_4E_fU_Vvrj_cEVZgRg==(#=zTNBXCzs=, #=znpqO4SAeWz$_);
	}

	// Token: 0x060009AB RID: 2475 RVA: 0x0004F9BC File Offset: 0x0004DBBC
	private void #=zyES_ll9khY7s(object #=zP95I7AY=, DataGridViewCellFormattingEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zmU2HDA4YP0n$.Contains(#=z4Q$h3mE=.ColumnIndex) && #=z4Q$h3mE=.Value != null)
		{
			this.#=zCKPevQOlZNKv.Rows[#=z4Q$h3mE=.RowIndex].Tag = #=z4Q$h3mE=.Value;
			#=z4Q$h3mE=.Value = new string('●', #=z4Q$h3mE=.Value.ToString().Length);
		}
	}

	// Token: 0x060009AC RID: 2476 RVA: 0x0004FA28 File Offset: 0x0004DC28
	private void #=zAcWcAE$3JReH(object #=zP95I7AY=, DataGridViewEditingControlShowingEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zmU2HDA4YP0n$.Contains(this.#=zCKPevQOlZNKv.CurrentCell.ColumnIndex))
		{
			TextBox textBox = #=z4Q$h3mE=.Control as TextBox;
			if (textBox != null)
			{
				textBox.Text = Convert.ToString(this.#=zCKPevQOlZNKv.CurrentCell.Value);
			}
		}
	}

	// Token: 0x04000597 RID: 1431
	private DataGridView #=zCKPevQOlZNKv;

	// Token: 0x04000598 RID: 1432
	private List<int> #=zmU2HDA4YP0n$;
}
