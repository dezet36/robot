﻿using System;

// Token: 0x0200004F RID: 79
internal class #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
{
	// Token: 0x06000259 RID: 601 RVA: 0x00015D54 File Offset: 0x00013F54
	public #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(string #=zgFysrZ8=, params object[] #=zDRWcagA=)
	{
		this.#=zm3ehwk5yRgFG(#=zgFysrZ8=);
		this.#=zXCr1quctu2Or(#=zDRWcagA=);
		this.#=z3PF$mHcYYZUd = null;
	}

	// Token: 0x0600025A RID: 602 RVA: 0x00015D74 File Offset: 0x00013F74
	public string #=z7mqTU3dQdEe4()
	{
		return this.#=zuqolnELh8Nj9aGT3Tg==;
	}

	// Token: 0x0600025B RID: 603 RVA: 0x00015D7C File Offset: 0x00013F7C
	public void #=zm3ehwk5yRgFG(string #=z$Ib9gYQ=)
	{
		this.#=zuqolnELh8Nj9aGT3Tg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600025C RID: 604 RVA: 0x00015D88 File Offset: 0x00013F88
	public object[] #=ztGBL67USKnGE()
	{
		return this.#=zd4tSLHqI7ftmZWU4cg==;
	}

	// Token: 0x0600025D RID: 605 RVA: 0x00015D90 File Offset: 0x00013F90
	public void #=zXCr1quctu2Or(object[] #=z$Ib9gYQ=)
	{
		this.#=zd4tSLHqI7ftmZWU4cg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600025E RID: 606 RVA: 0x00015D9C File Offset: 0x00013F9C
	public override string ToString()
	{
		if (this.#=z3PF$mHcYYZUd == null)
		{
			this.#=z3PF$mHcYYZUd = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(this.#=z7mqTU3dQdEe4(), this.#=ztGBL67USKnGE());
		}
		return this.#=z3PF$mHcYYZUd;
	}

	// Token: 0x0600025F RID: 607 RVA: 0x00015DC4 File Offset: 0x00013FC4
	public static string #=zJHLHKso=(string #=zgFysrZ8=, object[] #=zDRWcagA=)
	{
		string text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zgFysrZ8=);
		if (#=zDRWcagA=.Length != 0)
		{
			return string.Format(text, #=zDRWcagA=);
		}
		return text;
	}

	// Token: 0x040000B7 RID: 183
	private string #=zuqolnELh8Nj9aGT3Tg==;

	// Token: 0x040000B8 RID: 184
	private object[] #=zd4tSLHqI7ftmZWU4cg==;

	// Token: 0x040000B9 RID: 185
	private string #=z3PF$mHcYYZUd;
}
