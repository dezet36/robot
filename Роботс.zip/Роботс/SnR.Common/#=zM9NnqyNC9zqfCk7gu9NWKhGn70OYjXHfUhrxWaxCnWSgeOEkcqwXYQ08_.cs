﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x0200015F RID: 351
internal sealed class #=zM9NnqyNC9zqfCk7gu9NWKhGn70OYjXHfUhrxWaxCnWSgeOEkcqwXYQ08_a0UgtFvNA== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000951 RID: 2385 RVA: 0x0004BB14 File Offset: 0x00049D14
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=zwn5aCwWTvPV4 = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
		this.#=zFGZhAdTFY4nt1H_JUw== = #=zuJjQ1XU=.#=zjp4T2o8sDgUmdadFiw==();
	}

	// Token: 0x06000952 RID: 2386 RVA: 0x0004BB3C File Offset: 0x00049D3C
	protected override void #=zvb5bnug=()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BlackMarketContBoosts.Count == 0)
		{
			return;
		}
		int num = 2;
		#=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.#=zi1hFJwI=();
		#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= = this.#=zCY4az9$WUjLsEJ7fgg==;
		#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=();
		#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= = this.#=zwn5aCwWTvPV4;
		DateTime dateTime = DateTime.MaxValue;
		for (int i = 0; i < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BlackMarketContBoosts.Count; i++)
		{
			#=zM9NnqyNC9zqfCk7gu9NWKhGn70OYjXHfUhrxWaxCnWSgeOEkcqwXYQ08_a0UgtFvNA==.#=zjfITWWrauqUMWlwNww== #=zjfITWWrauqUMWlwNww== = new #=zM9NnqyNC9zqfCk7gu9NWKhGn70OYjXHfUhrxWaxCnWSgeOEkcqwXYQ08_a0UgtFvNA==.#=zjfITWWrauqUMWlwNww==();
			#=zjfITWWrauqUMWlwNww==.#=zVCUvPns= = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BlackMarketContBoosts[i];
			if (#=zjfITWWrauqUMWlwNww==.#=zVCUvPns=.IsUse)
			{
				#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ= = #=z5zfUeBGpgiN8mUTYavVv$Zik9DTuqK07TLmoFY$o0m8U.Find(new Predicate<#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky>(#=zjfITWWrauqUMWlwNww==.#=z8ROWZYlEsQJ5));
				if (#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ= != null)
				{
					#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== = #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zjfITWWrauqUMWlwNww==.#=zuYcj8jIHDmuf));
					DateTime dateTime2;
					if (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== != null)
					{
						dateTime2 = #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=z71_rggORFKZ5();
						if (dateTime2 > DateTime.Now + TimeSpan.FromHours((double)num))
						{
							goto IL_6CE;
						}
					}
					else
					{
						dateTime2 = DateTime.MinValue;
					}
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = null;
					List<int> list;
					if (#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zMuFMjGQ=() == 500)
					{
						list = new List<int>();
						using (Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU>.ValueCollection.Enumerator enumerator = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zkUUmwSA23UXVOIFutxPsL6ZrnvCf().Values.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = enumerator.Current;
								if (#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU is #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX)
								{
									list.Add(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zMuFMjGQ=());
								}
							}
							goto IL_159;
						}
						goto IL_14C;
					}
					goto IL_14C;
					IL_159:
					int j = 0;
					while (j < list.Count)
					{
						int #=zH2f5zJg= = list[j];
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=[#=zH2f5zJg=];
						if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() != 0)
						{
							if (!#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zskZ$IzJYQKQa() || !(dateTime2 >= DateTime.Now))
							{
								int num2 = 1;
								if ((#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zMuFMjGQ=() == 500 || #=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zMuFMjGQ=() == 17008) && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH() < (double)num)
								{
									double num3 = (dateTime2 >= DateTime.Now) ? (dateTime2 - DateTime.Now).TotalHours : 0.0;
									num2 = (int)Math.Ceiling(((double)num - num3) / #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH());
									if (num2 < 0 || num2 > 10)
									{
										this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925144), new object[]
										{
											dateTime2,
											num3,
											num,
											#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH(),
											num2
										});
									}
								}
								if (num2 > #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_())
								{
									num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
								}
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=(), num2);
								break;
							}
							if (dateTime > dateTime2)
							{
								dateTime = dateTime2;
								break;
							}
							break;
						}
						else
						{
							j++;
						}
					}
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= == null && #=zjfITWWrauqUMWlwNww==.#=zVCUvPns=.IsBuy && #=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zBzeaLS1hmg6bFYWHJA==() > 0)
					{
						int num4 = #=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zBzeaLS1hmg6bFYWHJA==();
						if (num4 == 505)
						{
							#=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX = #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX.#=zPxk4qAkYdYmplkSIOw==(this.#=zFGZhAdTFY4nt1H_JUw==);
							if (#=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX != null)
							{
								num4 = #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX.#=zMuFMjGQ=();
							}
						}
						int num5 = 1;
						string text = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(num4, num5, false);
						if (text.Length > 10000)
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zd634hMCtcd$T(num4), 1);
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923954), new object[]
							{
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
								num5
							});
						}
						else
						{
							text = JSONManager.Cut(text);
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924146), new object[]
							{
								num4,
								num5,
								text
							});
						}
					}
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= == null && #=zjfITWWrauqUMWlwNww==.#=zVCUvPns=.IsBuyForGlory && #=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zfvqZlK1NEWTQR1rpQxY5eLw=() > 0)
					{
						int num6 = 1;
						string text2 = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zfvqZlK1NEWTQR1rpQxY5eLw=(), num6, false);
						if (text2.Length > 10000)
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zd634hMCtcd$T(#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zfvqZlK1NEWTQR1rpQxY5eLw=()), 1);
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923954), new object[]
							{
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
								num6
							});
						}
						else
						{
							text2 = JSONManager.Cut(text2);
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924146), new object[]
							{
								#=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=zfvqZlK1NEWTQR1rpQxY5eLw=(),
								num6,
								text2
							});
						}
					}
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= == null)
					{
						goto IL_6CE;
					}
					string text3 = #=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra.#=zOctqvmBd0r83lEcEiiCTW1M=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=, this.#=zwn5aCwWTvPV4);
					if (!string.IsNullOrEmpty(text3))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, text3, Array.Empty<object>());
						goto IL_6CE;
					}
					#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_());
					if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15() != null)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926957), new object[]
						{
							#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zq2bPTdY=().#=zkfqcY3I=(),
							#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zlIXJ9$NfUZc_()
						});
						goto IL_6CE;
					}
					if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926895), new object[]
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_()
						});
						goto IL_6CE;
					}
					if (!#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926570)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926506), new object[]
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_(),
							JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
						});
						goto IL_6CE;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926544), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_(),
						JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
					});
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zjDwFDaMA8CSQ(true);
					if (dateTime > dateTime2)
					{
						dateTime = dateTime2;
						goto IL_6CE;
					}
					goto IL_6CE;
					IL_14C:
					list = #=zjfITWWrauqUMWlwNww==.#=zvRLj9WQ=.#=z0gRgrrIGr5L_();
					goto IL_159;
				}
			}
			IL_6CE:;
		}
		if (dateTime < DateTime.Now + this.#=zcDRV51Ut$7oP.RepeatDelayMin)
		{
			this.#=zcDRV51Ut$7oP.NextExecutionTime = dateTime;
		}
	}

	// Token: 0x04000558 RID: 1368
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x04000559 RID: 1369
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4;

	// Token: 0x0400055A RID: 1370
	private int #=zFGZhAdTFY4nt1H_JUw==;

	// Token: 0x02000160 RID: 352
	private sealed class #=zjfITWWrauqUMWlwNww==
	{
		// Token: 0x06000954 RID: 2388 RVA: 0x0004C27C File Offset: 0x0004A47C
		internal bool #=z8ROWZYlEsQJ5(#=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == this.#=zVCUvPns=.TypeId;
		}

		// Token: 0x06000955 RID: 2389 RVA: 0x0004C294 File Offset: 0x0004A494
		internal bool #=zuYcj8jIHDmuf(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return this.#=zvRLj9WQ=.#=z0gRgrrIGr5L_().Contains(#=zQrqFdos=.#=zMuFMjGQ=());
		}

		// Token: 0x0400055B RID: 1371
		public BlackMarketBoostSettings #=zVCUvPns=;

		// Token: 0x0400055C RID: 1372
		public #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky #=zvRLj9WQ=;
	}
}
