﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200009B RID: 155
internal sealed class #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k= : Task
{
	// Token: 0x06000423 RID: 1059 RVA: 0x000243E8 File Offset: 0x000225E8
	public #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=(string[] #=zDkEAHr8=, TaskSources #=zk656SlQ=, TaskSeverities #=z_qaYpFQ=, TaskTypes #=zvRLj9WQ=, DateTime #=zxSBcx18=, TimeSpan #=zKMZQB_CxkF$Q, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo) : base(#=zk656SlQ=, #=z_qaYpFQ=, #=zvRLj9WQ=, #=zxSBcx18=, #=zKMZQB_CxkF$Q, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
		this.#=zZnRoml8BrRh7(#=zDkEAHr8=);
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x00024414 File Offset: 0x00022614
	public #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x00024424 File Offset: 0x00022624
	public string[] #=zs6AfR9w58BN2()
	{
		return this.#=zFF02quCDrD$kTba0Ow==;
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x0002442C File Offset: 0x0002262C
	public void #=zZnRoml8BrRh7(string[] #=z$Ib9gYQ=)
	{
		this.#=zFF02quCDrD$kTba0Ow== = #=z$Ib9gYQ=;
	}

	// Token: 0x1700000B RID: 11
	// (get) Token: 0x06000427 RID: 1063 RVA: 0x00024438 File Offset: 0x00022638
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874233);
		}
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x00024444 File Offset: 0x00022644
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		object[] array = JSONManager.ExtractArray(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875192));
		if (array != null)
		{
			this.#=zZnRoml8BrRh7(new string[array.Length]);
			for (int i = 0; i < this.#=zs6AfR9w58BN2().Length; i++)
			{
				this.#=zs6AfR9w58BN2()[i] = Convert.ToString(array[i]);
			}
		}
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x00024498 File Offset: 0x00022698
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		if (this.#=zs6AfR9w58BN2() != null)
		{
			object[] array = new object[this.#=zs6AfR9w58BN2().Length];
			for (int i = 0; i < this.#=zs6AfR9w58BN2().Length; i++)
			{
				array[i] = this.#=zs6AfR9w58BN2()[i];
			}
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875192)] = array;
		}
		return dictionary;
	}

	// Token: 0x04000184 RID: 388
	private string[] #=zFF02quCDrD$kTba0Ow==;
}
