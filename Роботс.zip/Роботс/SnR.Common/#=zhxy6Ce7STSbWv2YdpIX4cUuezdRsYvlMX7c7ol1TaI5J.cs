﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Units;

// Token: 0x02000255 RID: 597
internal sealed partial class #=zhxy6Ce7STSbWv2YdpIX4cUuezdRsYvlMX7c7ol1TaI5J : Form
{
	// Token: 0x06001214 RID: 4628 RVA: 0x0008AC80 File Offset: 0x00088E80
	public #=zhxy6Ce7STSbWv2YdpIX4cUuezdRsYvlMX7c7ol1TaI5J(HiringPlanFrame #=zEfCr8HM=, Worlds #=z4bTgQI8RY7Z2)
	{
		this.#=zqTUsrROtfZh6(#=zEfCr8HM=);
		this.#=zgpzgXirqPT5_();
		List<UnitType> list = UnitTypeCollection.Get();
		this.#=zekWx3oxlwTfc.Items.Clear();
		foreach (UnitType unitType in list)
		{
			if (#=z4bTgQI8RY7Z2 != Worlds.Veor)
			{
				if (unitType.Categories_HasNoneBut(new UnitType.Categories[]
				{
					UnitType.Categories.m_Elite,
					UnitType.Categories.r_Denaries,
					UnitType.Categories.w_Future
				}))
				{
					this.#=zekWx3oxlwTfc.Items.Add(unitType);
				}
			}
			else if (unitType.World == Worlds.Veor)
			{
				this.#=zekWx3oxlwTfc.Items.Add(unitType);
			}
		}
		if (this.#=z2rLDbX7PDceR() != null)
		{
			if (this.#=z2rLDbX7PDceR().TypeId > 0)
			{
				foreach (object obj in this.#=zekWx3oxlwTfc.Items)
				{
					UnitType unitType2 = (UnitType)obj;
					if (unitType2.Id == this.#=z2rLDbX7PDceR().TypeId)
					{
						this.#=zekWx3oxlwTfc.SelectedItem = unitType2;
					}
				}
			}
			this.#=zkZKnFCdWfJPd.Text = ((this.#=z2rLDbX7PDceR().BlockSize > 0) ? this.#=z2rLDbX7PDceR().BlockSize.ToString() : string.Empty);
			this.#=z5fdEXx2qNf28.Text = ((this.#=z2rLDbX7PDceR().QueueLenght > 0) ? this.#=z2rLDbX7PDceR().QueueLenght.ToString() : string.Empty);
			this.#=ziaQcJEFvniBC.Text = ((this.#=z2rLDbX7PDceR().MaxAmount > 0) ? this.#=z2rLDbX7PDceR().MaxAmount.ToString() : string.Empty);
			this.#=zJiBnBkaEm1GZ7EFdqw==.Checked = this.#=z2rLDbX7PDceR().IsTimeBoost;
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001215 RID: 4629 RVA: 0x0008AE74 File Offset: 0x00089074
	public HiringPlanFrame #=z2rLDbX7PDceR()
	{
		return this.#=zxnGiD$PUPFfP89kZUQ==;
	}

	// Token: 0x06001216 RID: 4630 RVA: 0x0008AE7C File Offset: 0x0008907C
	public void #=zqTUsrROtfZh6(HiringPlanFrame #=z$Ib9gYQ=)
	{
		this.#=zxnGiD$PUPFfP89kZUQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001217 RID: 4631 RVA: 0x0008AE88 File Offset: 0x00089088
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zekWx3oxlwTfc.SelectedItem == null)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106523));
			return;
		}
		int blockSize;
		if (!string.IsNullOrWhiteSpace(this.#=zkZKnFCdWfJPd.Text))
		{
			if (!int.TryParse(this.#=zkZKnFCdWfJPd.Text, out blockSize))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106496));
				return;
			}
		}
		else
		{
			blockSize = 0;
		}
		int queueLenght;
		if (!string.IsNullOrWhiteSpace(this.#=z5fdEXx2qNf28.Text))
		{
			if (!int.TryParse(this.#=z5fdEXx2qNf28.Text, out queueLenght))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106454));
				return;
			}
		}
		else
		{
			queueLenght = 0;
		}
		int maxAmount;
		if (!string.IsNullOrWhiteSpace(this.#=ziaQcJEFvniBC.Text))
		{
			if (!int.TryParse(this.#=ziaQcJEFvniBC.Text, out maxAmount))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106672));
				return;
			}
		}
		else
		{
			maxAmount = 0;
		}
		if (this.#=z2rLDbX7PDceR() == null)
		{
			this.#=zqTUsrROtfZh6(new HiringPlanFrame());
		}
		this.#=z2rLDbX7PDceR().TypeId = (this.#=zekWx3oxlwTfc.SelectedItem as UnitType).Id;
		this.#=z2rLDbX7PDceR().BlockSize = blockSize;
		this.#=z2rLDbX7PDceR().QueueLenght = queueLenght;
		this.#=z2rLDbX7PDceR().MaxAmount = maxAmount;
		this.#=z2rLDbX7PDceR().IsTimeBoost = this.#=zJiBnBkaEm1GZ7EFdqw==.Checked;
		base.DialogResult = DialogResult.OK;
		base.Close();
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x0008AFD8 File Offset: 0x000891D8
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.DialogResult = DialogResult.Cancel;
		base.Close();
	}

	// Token: 0x0600121A RID: 4634 RVA: 0x0008B008 File Offset: 0x00089208
	private void #=zgpzgXirqPT5_()
	{
		this.#=zekWx3oxlwTfc = new ComboBox();
		this.#=zuCaP$Fc= = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=z_TzT833XVTG2 = new Label();
		this.#=zu0ApWam8yxxT = new Label();
		this.#=z8L8rxRUJ$ifO = new Label();
		this.#=ziaQcJEFvniBC = new TextBox();
		this.#=z5fdEXx2qNf28 = new TextBox();
		this.#=zkZKnFCdWfJPd = new TextBox();
		this.#=zRhNsOeut12N6 = new Label();
		this.#=zJiBnBkaEm1GZ7EFdqw== = new CheckBox();
		base.SuspendLayout();
		this.#=zekWx3oxlwTfc.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zekWx3oxlwTfc.FormattingEnabled = true;
		this.#=zekWx3oxlwTfc.Location = new Point(81, 9);
		this.#=zekWx3oxlwTfc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106646);
		this.#=zekWx3oxlwTfc.Size = new Size(326, 21);
		this.#=zekWx3oxlwTfc.TabIndex = 0;
		this.#=zuCaP$Fc=.Location = new Point(81, 160);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(75, 23);
		this.#=zuCaP$Fc=.TabIndex = 1;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112827);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		this.#=zHeAVXAs=.Location = new Point(223, 160);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 2;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=z_TzT833XVTG2.AutoSize = true;
		this.#=z_TzT833XVTG2.Location = new Point(12, 9);
		this.#=z_TzT833XVTG2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106617);
		this.#=z_TzT833XVTG2.Size = new Size(37, 13);
		this.#=z_TzT833XVTG2.TabIndex = 3;
		this.#=z_TzT833XVTG2.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106605);
		this.#=zu0ApWam8yxxT.AutoSize = true;
		this.#=zu0ApWam8yxxT.Location = new Point(13, 65);
		this.#=zu0ApWam8yxxT.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106590);
		this.#=zu0ApWam8yxxT.Size = new Size(93, 13);
		this.#=zu0ApWam8yxxT.TabIndex = 4;
		this.#=zu0ApWam8yxxT.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106561);
		this.#=z8L8rxRUJ$ifO.AutoSize = true;
		this.#=z8L8rxRUJ$ifO.Location = new Point(15, 91);
		this.#=z8L8rxRUJ$ifO.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106281);
		this.#=z8L8rxRUJ$ifO.Size = new Size(122, 13);
		this.#=z8L8rxRUJ$ifO.TabIndex = 5;
		this.#=z8L8rxRUJ$ifO.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106258);
		this.#=ziaQcJEFvniBC.Location = new Point(142, 88);
		this.#=ziaQcJEFvniBC.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106226);
		this.#=ziaQcJEFvniBC.Size = new Size(100, 20);
		this.#=ziaQcJEFvniBC.TabIndex = 6;
		this.#=z5fdEXx2qNf28.Location = new Point(142, 62);
		this.#=z5fdEXx2qNf28.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106213);
		this.#=z5fdEXx2qNf28.Size = new Size(100, 20);
		this.#=z5fdEXx2qNf28.TabIndex = 7;
		this.#=zkZKnFCdWfJPd.Location = new Point(142, 36);
		this.#=zkZKnFCdWfJPd.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106178);
		this.#=zkZKnFCdWfJPd.Size = new Size(100, 20);
		this.#=zkZKnFCdWfJPd.TabIndex = 7;
		this.#=zRhNsOeut12N6.AutoSize = true;
		this.#=zRhNsOeut12N6.Location = new Point(13, 39);
		this.#=zRhNsOeut12N6.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106421);
		this.#=zRhNsOeut12N6.Size = new Size(120, 13);
		this.#=zRhNsOeut12N6.TabIndex = 4;
		this.#=zRhNsOeut12N6.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106398);
		this.#=zJiBnBkaEm1GZ7EFdqw==.AutoSize = true;
		this.#=zJiBnBkaEm1GZ7EFdqw==.Location = new Point(16, 118);
		this.#=zJiBnBkaEm1GZ7EFdqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114672);
		this.#=zJiBnBkaEm1GZ7EFdqw==.Size = new Size(171, 17);
		this.#=zJiBnBkaEm1GZ7EFdqw==.TabIndex = 8;
		this.#=zJiBnBkaEm1GZ7EFdqw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106360);
		this.#=zJiBnBkaEm1GZ7EFdqw==.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(437, 234);
		base.Controls.Add(this.#=zJiBnBkaEm1GZ7EFdqw==);
		base.Controls.Add(this.#=zkZKnFCdWfJPd);
		base.Controls.Add(this.#=z5fdEXx2qNf28);
		base.Controls.Add(this.#=ziaQcJEFvniBC);
		base.Controls.Add(this.#=z8L8rxRUJ$ifO);
		base.Controls.Add(this.#=zRhNsOeut12N6);
		base.Controls.Add(this.#=zu0ApWam8yxxT);
		base.Controls.Add(this.#=z_TzT833XVTG2);
		base.Controls.Add(this.#=zHeAVXAs=);
		base.Controls.Add(this.#=zuCaP$Fc=);
		base.Controls.Add(this.#=zekWx3oxlwTfc);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106322);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106322);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000A15 RID: 2581
	private HiringPlanFrame #=zxnGiD$PUPFfP89kZUQ==;

	// Token: 0x04000A17 RID: 2583
	private ComboBox #=zekWx3oxlwTfc;

	// Token: 0x04000A18 RID: 2584
	private Button #=zuCaP$Fc=;

	// Token: 0x04000A19 RID: 2585
	private Button #=zHeAVXAs=;

	// Token: 0x04000A1A RID: 2586
	private Label #=z_TzT833XVTG2;

	// Token: 0x04000A1B RID: 2587
	private Label #=zu0ApWam8yxxT;

	// Token: 0x04000A1C RID: 2588
	private Label #=z8L8rxRUJ$ifO;

	// Token: 0x04000A1D RID: 2589
	private TextBox #=ziaQcJEFvniBC;

	// Token: 0x04000A1E RID: 2590
	private TextBox #=z5fdEXx2qNf28;

	// Token: 0x04000A1F RID: 2591
	private TextBox #=zkZKnFCdWfJPd;

	// Token: 0x04000A20 RID: 2592
	private Label #=zRhNsOeut12N6;

	// Token: 0x04000A21 RID: 2593
	private CheckBox #=zJiBnBkaEm1GZ7EFdqw==;
}
