﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000167 RID: 359
internal sealed class #=zN8eMCGe_TZb6LVfI$b1iH3kieigqM0f4LPP7drJRLY2UP4kkOw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600098E RID: 2446 RVA: 0x0004E908 File Offset: 0x0004CB08
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zeYLQo2n2g2lR = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
	}

	// Token: 0x0600098F RID: 2447 RVA: 0x0004E918 File Offset: 0x0004CB18
	protected override void #=zvb5bnug=()
	{
		foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== in this.#=zeYLQo2n2g2lR)
		{
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zosN4hoVyBAOs() && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zN0c_qE6yJTk7() && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=() > 0 && !#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=ztHG2xIVtnVuUuCv$xQRGrWc=() && !#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zsGegpFIDm4HnM1ZwbMKrm1OyKO$D())
			{
				string text = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=(), null);
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967622), new object[]
					{
						#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967570), new object[]
					{
						#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=(),
						JSONManager.Cut(text)
					});
				}
			}
			else if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zLg_4gHQfENBn() == 0 && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=znqqYiI0yKfELaxv8MQ==() == ProphecyTypes.NotProphecy && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zXuw1agBmq5jc() == DateTime.MinValue)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983882), new object[]
				{
					#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
				});
				this.#=zBsXSanI=.#=z5zbVlDidbmAsW3XxUg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=());
				this.#=zBsXSanI=.#=zEoRJ9iFCtj0AXzcGqw==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=());
			}
		}
	}

	// Token: 0x04000581 RID: 1409
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zeYLQo2n2g2lR;
}
