﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.Managers;

// Token: 0x02000027 RID: 39
internal sealed class #=z0$hsXh8Yx45LUUakrnf4tFcWiHH6HvvzGWPLouVPt8CM : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000088 RID: 136 RVA: 0x00004590 File Offset: 0x00002790
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zl_LhqvU3sUkXyuHhEw== = #=zuJjQ1XU=.#=zjVMzCR4MCwpUphuGNUeoxDg=();
		this.#=ze_IU2kdzl1D$sgxFeQ== = #=zuJjQ1XU=.#=zvQRf_STy5v8Sm5tuw7Xh278usASc();
	}

	// Token: 0x06000089 RID: 137 RVA: 0x000045AC File Offset: 0x000027AC
	protected override void #=zvb5bnug=()
	{
		if (this.#=zl_LhqvU3sUkXyuHhEw== > DateTime.Now)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980814), new object[]
			{
				this.#=zl_LhqvU3sUkXyuHhEw==
			});
			return;
		}
		if (this.#=z$dAyfDJZKc7VEUEh6rdEBXlLCLiu())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980758), Array.Empty<object>());
			string text = this.#=zBsXSanI=.#=zFo2XPpZtgBNRmKX_gg==();
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980970), Array.Empty<object>());
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980949), new object[]
			{
				JSONManager.Cut(text)
			});
		}
	}

	// Token: 0x0600008A RID: 138 RVA: 0x000046A0 File Offset: 0x000028A0
	private bool #=z$dAyfDJZKc7VEUEh6rdEBXlLCLiu()
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonSelect)
		{
			return true;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980899), Array.Empty<object>());
		#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5.#=zi1hFJwI=();
		int num = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonSlotsNumber;
		if (num < 6)
		{
			num++;
		}
		List<int> dragonAbilitiesToUpgradeIds = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonAbilitiesToUpgradeIds;
		string text = null;
		List<int> list = new List<int>();
		int i = 0;
		while (i < dragonAbilitiesToUpgradeIds.Count)
		{
			#=z0$hsXh8Yx45LUUakrnf4tFcWiHH6HvvzGWPLouVPt8CM.#=zjfITWWrauqUMWlwNww== #=zjfITWWrauqUMWlwNww== = new #=z0$hsXh8Yx45LUUakrnf4tFcWiHH6HvvzGWPLouVPt8CM.#=zjfITWWrauqUMWlwNww==();
			int #=zAk8mKBk= = dragonAbilitiesToUpgradeIds[i];
			int num2 = 0;
			#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d = this.#=ze_IU2kdzl1D$sgxFeQ==.#=zk$6QZNA=(#=zAk8mKBk=);
			if (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d == null)
			{
				while (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d == null)
				{
					#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(#=zAk8mKBk=);
					if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW == null || #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW.#=z5irrWqrwWHrPajKrZw==() <= 0)
					{
						break;
					}
					#=zAk8mKBk= = #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW.#=z5irrWqrwWHrPajKrZw==();
					#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d = this.#=ze_IU2kdzl1D$sgxFeQ==.#=zk$6QZNA=(#=zAk8mKBk=);
				}
				if (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d == null)
				{
					goto IL_176;
				}
				if (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d.#=zq2bPTdY=().#=zaDKBEnk8Vsod() != 1)
				{
					num2 = #=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d.#=zMuFMjGQ=();
					goto IL_176;
				}
			}
			else if (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d.#=zq2bPTdY=().#=zaDKBEnk8Vsod() != 1)
			{
				num2 = #=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d.#=zMuFMjGQ=();
				while (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d != null)
				{
					#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d = this.#=ze_IU2kdzl1D$sgxFeQ==.Find(new Predicate<#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN>(#=zjfITWWrauqUMWlwNww==.#=zal7euC3_XcMo32jOwhMt4c2t$sxjeM5gFMN6uos=));
					if (#=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d != null)
					{
						num2 = #=zjfITWWrauqUMWlwNww==.#=zDhcgbR$yJg9d.#=zMuFMjGQ=();
					}
				}
				goto IL_176;
			}
			IL_196:
			i++;
			continue;
			IL_176:
			if (num2 <= 0 || list.Contains(num2))
			{
				goto IL_196;
			}
			list.Add(num2);
			if (list.Count < num)
			{
				goto IL_196;
			}
			break;
		}
		int[] array = new int[0];
		try
		{
			for (;;)
			{
				if (list.Count <= num || list.Count <= 0)
				{
					array = new int[list.Count];
					for (int j = 0; j < array.Length; j++)
					{
						array[j] = list[j];
					}
					text = this.#=zBsXSanI=.#=zLWZRJ6GAUW7RYgV1qGPDspvOoW_8(array);
					if (!text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980595)))
					{
						break;
					}
					if (num > array.Length)
					{
						num = array.Length - 1;
					}
					else
					{
						num--;
					}
					if (num <= 0)
					{
						break;
					}
				}
				else
				{
					list.RemoveAt(list.Count - 1);
				}
			}
		}
		catch (Exception ex)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, ex);
			text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980564) + ex.Message + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945802);
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (int k = 0; k < array.Length; k++)
		{
			#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = this.#=ze_IU2kdzl1D$sgxFeQ==.#=zk$6QZNA=(array[k]);
			if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN != null)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=());
			}
		}
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980557), new object[]
			{
				stringBuilder
			});
			if (num != this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonSlotsNumber)
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonSlotsNumber = num;
			}
			return true;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980512), new object[]
		{
			stringBuilder,
			JSONManager.Cut(text)
		});
		return false;
	}

	// Token: 0x0400002B RID: 43
	private DateTime #=zl_LhqvU3sUkXyuHhEw==;

	// Token: 0x0400002C RID: 44
	private #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ #=ze_IU2kdzl1D$sgxFeQ==;

	// Token: 0x02000028 RID: 40
	private sealed class #=zjfITWWrauqUMWlwNww==
	{
		// Token: 0x0600008C RID: 140 RVA: 0x00004A28 File Offset: 0x00002C28
		internal bool #=zal7euC3_XcMo32jOwhMt4c2t$sxjeM5gFMN6uos=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zq2bPTdY=().#=z5irrWqrwWHrPajKrZw==() == this.#=zDhcgbR$yJg9d.#=zMuFMjGQ=();
		}

		// Token: 0x0400002D RID: 45
		public #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=zDhcgbR$yJg9d;
	}
}
