﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000053 RID: 83
internal sealed class #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== : #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==
{
	// Token: 0x06000280 RID: 640 RVA: 0x00016354 File Offset: 0x00014554
	public #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(int #=zLeeSKrg=, string #=z0idSdYs=, #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=ztBYdg6o6UCbJ, bool #=z9kwIljrONOCZ) : base(#=ztBYdg6o6UCbJ.#=zPHMvvJ8=(), #=ztBYdg6o6UCbJ.#=zpZQhzm3O9fac(), #=ztBYdg6o6UCbJ.#=znqRcj_cT3li8())
	{
		this.#=z8hJHIKFp6jOv(#=zLeeSKrg=);
		this.#=zMUnSpas=(#=z0idSdYs=);
		this.#=zYVGWxPXEfq57(#=z9kwIljrONOCZ);
	}

	// Token: 0x06000281 RID: 641 RVA: 0x00016384 File Offset: 0x00014584
	private #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(int #=zLeeSKrg=) : base(DateTime.MinValue, false, -1)
	{
		this.#=z8hJHIKFp6jOv(#=zLeeSKrg=);
		this.#=zMUnSpas=(string.Empty);
		this.#=zYVGWxPXEfq57(false);
	}

	// Token: 0x06000282 RID: 642 RVA: 0x000163AC File Offset: 0x000145AC
	public int #=zYgvZuBwR$a1C()
	{
		return this.#=z$eM7GpXgW_KO8hkYHQ==;
	}

	// Token: 0x06000283 RID: 643 RVA: 0x000163B4 File Offset: 0x000145B4
	public void #=z8hJHIKFp6jOv(int #=z$Ib9gYQ=)
	{
		this.#=z$eM7GpXgW_KO8hkYHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000284 RID: 644 RVA: 0x000163C0 File Offset: 0x000145C0
	public string #=zXqmPC7g=()
	{
		return this.#=zsW$vcbJs8M$jrLaEdQ==;
	}

	// Token: 0x06000285 RID: 645 RVA: 0x000163C8 File Offset: 0x000145C8
	public void #=zMUnSpas=(string #=z$Ib9gYQ=)
	{
		this.#=zsW$vcbJs8M$jrLaEdQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000286 RID: 646 RVA: 0x000163D4 File Offset: 0x000145D4
	public bool #=z98rNtdMlpo2r()
	{
		return this.#=zKNsIVQt8SBX2$dYlyK8v8yU=;
	}

	// Token: 0x06000287 RID: 647 RVA: 0x000163DC File Offset: 0x000145DC
	public void #=zYVGWxPXEfq57(bool #=z$Ib9gYQ=)
	{
		this.#=zKNsIVQt8SBX2$dYlyK8v8yU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000288 RID: 648 RVA: 0x000163E8 File Offset: 0x000145E8
	public new Dictionary<string, object> #=zhv7OhlM=()
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049979),
				this.#=zXqmPC7g=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909078463),
				base.#=zPHMvvJ8=().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049969))
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049951),
				base.#=znqRcj_cT3li8() + 1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049941),
				(base.#=zpZQhzm3O9fac() > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				this.#=z98rNtdMlpo2r() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)
			}
		};
	}

	// Token: 0x06000289 RID: 649 RVA: 0x000164A4 File Offset: 0x000146A4
	public override string ToString()
	{
		return JSONManager.SerializeData(this.#=zhv7OhlM=());
	}

	// Token: 0x0600028A RID: 650 RVA: 0x000164B4 File Offset: 0x000146B4
	public static string #=z2cVYJJw=(Dictionary<int, Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>> #=zyfyFTf4=, List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==> #=zL9RnQpyChfuL, int #=zLeeSKrg=)
	{
		List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==> list = new List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==>();
		List<string> list2 = new List<string>();
		if (#=zL9RnQpyChfuL != null)
		{
			using (List<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==>.Enumerator enumerator = #=zL9RnQpyChfuL.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== = enumerator.Current;
					if (#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== != null)
					{
						if (#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=zYgvZuBwR$a1C() == #=zLeeSKrg=)
						{
							list.Add(#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==);
						}
					}
					else
					{
						list.Add(new #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(#=zLeeSKrg=));
					}
				}
				goto IL_6F;
			}
		}
		list2.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049923));
		IL_6F:
		if (#=zyfyFTf4= != null)
		{
			if (#=zyfyFTf4=.ContainsKey(#=zLeeSKrg=))
			{
				Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>> dictionary = #=zyfyFTf4=[#=zLeeSKrg=];
				if (dictionary != null)
				{
					using (Dictionary<string, List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>>.KeyCollection.Enumerator enumerator2 = dictionary.Keys.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							string text = enumerator2.Current;
							if (text != #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL)
							{
								List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==> list3 = dictionary[text];
								if (list3 != null)
								{
									using (List<#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==>.Enumerator enumerator3 = list3.GetEnumerator())
									{
										while (enumerator3.MoveNext())
										{
											#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== = enumerator3.Current;
											if (#=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ== != null)
											{
												list.Add(new #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(#=zLeeSKrg=, text, #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==, true));
											}
											else
											{
												list.Add(new #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==(#=zLeeSKrg=));
											}
										}
										continue;
									}
								}
								list2.Add(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049909), #=zLeeSKrg=, text));
							}
						}
						goto IL_180;
					}
				}
				list2.Add(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049873), #=zLeeSKrg=));
			}
		}
		else
		{
			list2.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050104));
		}
		IL_180:
		list.Sort(new Comparison<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==>(#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zm5wIL1oeFCsabvMLuA==));
		object[] array = new object[list.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = list[i].#=zhv7OhlM=();
		}
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				array
			}
		};
		if (list2.Count > 0)
		{
			object[] array2 = new object[list2.Count];
			for (int j = 0; j < array2.Length; j++)
			{
				array2[j] = list2[j];
			}
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)] = array2;
		}
		return JSONManager.SerializeData(dictionary2);
	}

	// Token: 0x040000C6 RID: 198
	private int #=z$eM7GpXgW_KO8hkYHQ==;

	// Token: 0x040000C7 RID: 199
	private string #=zsW$vcbJs8M$jrLaEdQ==;

	// Token: 0x040000C8 RID: 200
	private bool #=zKNsIVQt8SBX2$dYlyK8v8yU=;

	// Token: 0x02000054 RID: 84
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600028D RID: 653 RVA: 0x00016734 File Offset: 0x00014934
		internal int #=zm5wIL1oeFCsabvMLuA==(#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== #=zm8PpuDU=, #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ== #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zPHMvvJ8=().CompareTo(#=zcltuPyw=.#=zPHMvvJ8=());
		}

		// Token: 0x040000C9 RID: 201
		public static readonly #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=zyDNvciU= #=zLkw0NRU= = new #=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==.#=zyDNvciU=();

		// Token: 0x040000CA RID: 202
		public static Comparison<#=z3osj8lpigutsHiUPKYW8VowxZbHjOY10RQ==> #=zIp6kwz2oWtknzAUT1A==;
	}
}
