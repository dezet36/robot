﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000219 RID: 537
internal sealed class #=zcrOVZP3y1tL51HDCqoQyhR4gGvym : RecordData
{
	// Token: 0x0600105B RID: 4187 RVA: 0x0007EF78 File Offset: 0x0007D178
	protected internal #=zcrOVZP3y1tL51HDCqoQyhR4gGvym(Record #=zihyUFzs=) : base(Type.SCL)
	{
		sbyte[] data = #=zihyUFzs=.Data;
		this.#=z0Yw9Qf$SmAIWMrvD7g== = IntegerHelper.getInt(data[0], data[1]);
		this.#=zYjHhMRr0App_8mLkUw== = IntegerHelper.getInt(data[2], data[3]);
	}

	// Token: 0x0600105C RID: 4188 RVA: 0x0007EFBC File Offset: 0x0007D1BC
	public int #=zCKlbGs0WDfWv()
	{
		return this.#=z0Yw9Qf$SmAIWMrvD7g== * 100 / this.#=zYjHhMRr0App_8mLkUw==;
	}

	// Token: 0x040008F7 RID: 2295
	private int #=z0Yw9Qf$SmAIWMrvD7g==;

	// Token: 0x040008F8 RID: 2296
	private int #=zYjHhMRr0App_8mLkUw==;
}
