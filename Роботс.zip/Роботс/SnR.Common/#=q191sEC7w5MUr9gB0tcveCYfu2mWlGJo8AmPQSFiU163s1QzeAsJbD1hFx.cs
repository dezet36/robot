﻿using System;

// Token: 0x02000002 RID: 2
internal static class #=q191sEC7w5MUr9gB0tcveCYfu2mWlGJo8AmPQSFiU163s1QzeAsJbD1hFx4yl93v4
{
}
