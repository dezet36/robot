﻿using System;

// Token: 0x02000269 RID: 617
internal interface #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=
{
	// Token: 0x060012A8 RID: 4776
	string ToStringLabels();
}
