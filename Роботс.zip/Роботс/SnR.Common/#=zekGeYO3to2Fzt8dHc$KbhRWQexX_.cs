﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common.Managers;

// Token: 0x02000232 RID: 562
internal sealed class #=zekGeYO3to2Fzt8dHc$KbhRWQexX_
{
	// Token: 0x0600112E RID: 4398 RVA: 0x000843B4 File Offset: 0x000825B4
	private #=zekGeYO3to2Fzt8dHc$KbhRWQexX_()
	{
	}

	// Token: 0x06001130 RID: 4400 RVA: 0x000843D8 File Offset: 0x000825D8
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001131 RID: 4401 RVA: 0x000843E0 File Offset: 0x000825E0
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001132 RID: 4402 RVA: 0x000843EC File Offset: 0x000825EC
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x06001133 RID: 4403 RVA: 0x000843F4 File Offset: 0x000825F4
	public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001134 RID: 4404 RVA: 0x00084400 File Offset: 0x00082600
	public string #=zqjHOR9Q=()
	{
		return this.#=zMOn$W0DW3iFpiytW9w==;
	}

	// Token: 0x06001135 RID: 4405 RVA: 0x00084408 File Offset: 0x00082608
	public void #=zeAChU_4=(string #=z$Ib9gYQ=)
	{
		this.#=zMOn$W0DW3iFpiytW9w== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001136 RID: 4406 RVA: 0x00084414 File Offset: 0x00082614
	public string #=zS9abAdvN0L8f()
	{
		return this.#=zAsiyJrmZGrWif6DESLochNM=;
	}

	// Token: 0x06001137 RID: 4407 RVA: 0x0008441C File Offset: 0x0008261C
	public void #=zlQvi8B9uJGuL(string #=z$Ib9gYQ=)
	{
		this.#=zAsiyJrmZGrWif6DESLochNM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001138 RID: 4408 RVA: 0x00084428 File Offset: 0x00082628
	public int #=z2HvY9a8=(object #=zcltuPyw=)
	{
		if (#=zcltuPyw= is #=zekGeYO3to2Fzt8dHc$KbhRWQexX_)
		{
			return this.#=zMuFMjGQ=().CompareTo((#=zcltuPyw= as #=zekGeYO3to2Fzt8dHc$KbhRWQexX_).#=zMuFMjGQ=());
		}
		return -1;
	}

	// Token: 0x06001139 RID: 4409 RVA: 0x00084458 File Offset: 0x00082658
	public static #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ== #=z4WsFPIqF78Zw()
	{
		if (#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zjbBMZXVy7lnP == null)
		{
			object obj = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zjbBMZXVy7lnP == null)
				{
					#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zjbBMZXVy7lnP = new #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==();
				}
			}
		}
		return #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zjbBMZXVy7lnP;
	}

	// Token: 0x0600113A RID: 4410 RVA: 0x000844B4 File Offset: 0x000826B4
	public static void #=zOB21CVc=()
	{
		if (DateTime.Now >= #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zqCdBoz3jo0J$T31T7g==)
		{
			object obj = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zqCdBoz3jo0J$T31T7g== = DateTime.Now + TimeSpan.FromMinutes(60.0);
				new Thread(new ThreadStart(#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zpyVL5hn1NFVC)).Start();
			}
		}
	}

	// Token: 0x0600113B RID: 4411 RVA: 0x00084534 File Offset: 0x00082734
	public static void #=zpyVL5hn1NFVC()
	{
		#=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ== #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ== = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=z4WsFPIqF78Zw();
		object obj = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zSV4$mlFB34WM;
		lock (obj)
		{
			try
			{
				#=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==.#=zm7nSMZ8=();
				string text = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zPYgX1sPMvLlo();
				if (!string.IsNullOrEmpty(text))
				{
					Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(text);
					foreach (Dictionary<string, object> dictionary2 in JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050266)))
					{
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_ #=zekGeYO3to2Fzt8dHc$KbhRWQexX_ = new #=zekGeYO3to2Fzt8dHc$KbhRWQexX_();
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zbsxKkj4=(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zIR9Xlcg=(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), true));
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zeAChU_4=(JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), string.Empty));
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zlQvi8B9uJGuL(JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), string.Empty));
						#=zekGeYO3to2Fzt8dHc$KbhRWQexX_ item = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_;
						#=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==.Add(item);
					}
					object[] array2 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050259));
					#=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==.#=zSeqcSs2s84emDcMs_EHmHqDAfH_U().Clear();
					if (array2 != null)
					{
						for (int j = 0; j < array2.Length; j++)
						{
							#=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ==.#=zSeqcSs2s84emDcMs_EHmHqDAfH_U().Add(Convert.ToInt32(array2[j]));
						}
					}
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
		}
	}

	// Token: 0x0600113C RID: 4412 RVA: 0x000846B4 File Offset: 0x000828B4
	public static void #=zm7nSMZ8=()
	{
		object obj = #=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zSV4$mlFB34WM;
		lock (obj)
		{
			#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=z4WsFPIqF78Zw().#=zm7nSMZ8=();
		}
	}

	// Token: 0x0400094E RID: 2382
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400094F RID: 2383
	private DateTime #=zJDEdzIaDvHbnYM06$w==;

	// Token: 0x04000950 RID: 2384
	private string #=zMOn$W0DW3iFpiytW9w==;

	// Token: 0x04000951 RID: 2385
	private string #=zAsiyJrmZGrWif6DESLochNM=;

	// Token: 0x04000952 RID: 2386
	private static #=zgoOChzWzh9fR18jvhwgoqLbCybsYOus_XQ== #=zjbBMZXVy7lnP = null;

	// Token: 0x04000953 RID: 2387
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000954 RID: 2388
	private static DateTime #=zqCdBoz3jo0J$T31T7g== = DateTime.MinValue;
}
