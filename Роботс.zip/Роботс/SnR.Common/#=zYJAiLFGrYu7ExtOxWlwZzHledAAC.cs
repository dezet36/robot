﻿using System;

// Token: 0x020001DD RID: 477
internal sealed class #=zYJAiLFGrYu7ExtOxWlwZzHledAAC : #=z9EpCy_XFXi2VByCFZQZwOVUhFCY7, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000E76 RID: 3702 RVA: 0x0007353C File Offset: 0x0007173C
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zX_PPthewR8yJjLyF0w==;
	}

	// Token: 0x06000E77 RID: 3703 RVA: 0x00073544 File Offset: 0x00071744
	internal override int #=zXiDCyaHY58$0()
	{
		return 2;
	}

	// Token: 0x06000E78 RID: 3704 RVA: 0x00073548 File Offset: 0x00071748
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871);
	}
}
