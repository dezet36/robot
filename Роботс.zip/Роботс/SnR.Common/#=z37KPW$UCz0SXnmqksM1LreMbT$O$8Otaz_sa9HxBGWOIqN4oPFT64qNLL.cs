﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x0200004D RID: 77
internal sealed class #=z37KPW$UCz0SXnmqksM1LreMbT$O$8Otaz_sa9HxBGWOIqN4oPFT64qNLLoSLfkEQey9V5QE= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000253 RID: 595 RVA: 0x00015944 File Offset: 0x00013B44
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zMEwuTGAUgTDD = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zOtmvYykNkDbU = #=zuJjQ1XU=.#=zTbkv095gWozyg_xVnw==();
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00015960 File Offset: 0x00013B60
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		this.#=zm0en4pBKWtQLi5pHyrNs0Se7hKsotEM9kQ==(#=zcTyyNys=);
	}

	// Token: 0x06000255 RID: 597 RVA: 0x00015990 File Offset: 0x00013B90
	private void #=zm0en4pBKWtQLi5pHyrNs0Se7hKsotEM9kQ==(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zcTyyNys=)
	{
		for (int i = 0; i < this.#=zMEwuTGAUgTDD.Count; i++)
		{
			if (this.#=zMEwuTGAUgTDD[i].#=zq2bPTdY=().Id == #=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924204), new object[]
				{
					this.#=zMEwuTGAUgTDD[i].#=zq2bPTdY=().Name
				});
				return;
			}
		}
		#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=().#=zk$6QZNA=(#=zcTyyNys=.#=zXFnsTSimqiPo().ItemTypeId);
		#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = this.#=zOtmvYykNkDbU.#=zk$6QZNA=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id);
		if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924171), new object[]
			{
				#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
			});
			return;
		}
		bool flag = false;
		for (int j = 0; j < #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=z6ZIr13K_h_d4(); j++)
		{
			if (!#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zTiHFkB7xQT2C(j))
			{
				flag = true;
				string text = this.#=zBsXSanI=.#=zjIOixtU6nn$Kt5RoUw==(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==, j);
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924322), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924370), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
					j + 1
				});
			}
		}
		if (!flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924007), new object[]
			{
				#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
			});
		}
	}

	// Token: 0x040000B5 RID: 181
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD;

	// Token: 0x040000B6 RID: 182
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zOtmvYykNkDbU;
}
