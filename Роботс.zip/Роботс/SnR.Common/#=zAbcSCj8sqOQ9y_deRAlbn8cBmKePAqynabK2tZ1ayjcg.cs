﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x020000BB RID: 187
internal sealed class #=zAbcSCj8sqOQ9y_deRAlbn8cBmKePAqynabK2tZ1ayjcg : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060004F1 RID: 1265 RVA: 0x000281B0 File Offset: 0x000263B0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zwn5aCwWTvPV4 = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
		this.#=zU2V2Q9bXseGY = new #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1(this.#=z8StzeqE=, #=zuJjQ1XU=);
	}

	// Token: 0x060004F2 RID: 1266 RVA: 0x0002820C File Offset: 0x0002640C
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879660), Array.Empty<object>());
			return;
		}
		#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0= #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0= = (#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=)this.#=zcDRV51Ut$7oP;
		int num;
		if (!int.TryParse(#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zuFPZLKs=(), out num))
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879852), new object[]
			{
				#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zuFPZLKs=()
			});
		}
		int num2;
		switch (#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z2UYVtfD6dFvM())
		{
		case #=zUYB79z3coxPKjfLVGQT58nQo28R2ixgZps$KOFU=.Calculate:
		{
			#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zUCIeSv7ynlYy(this.#=z8StzeqE=, num, true, this.#=zBsXSanI=);
			num2 = this.#=zCuBGo5tW0kBH(#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zlIXJ9$NfUZc_(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zfTB62qendhk_VEy8rw==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zY0soxphmGIACbOHy6A==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==, #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=zzktmgUcownAwsqMagJZ$NbE=());
			break;
		}
		case #=zUYB79z3coxPKjfLVGQT58nQo28R2ixgZps$KOFU=.MeasureApproximate:
			num2 = this.#=zjKLo8ptKvm2a(#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zlIXJ9$NfUZc_(), num, #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zeWSpwqqtMyd5(), false);
			break;
		case #=zUYB79z3coxPKjfLVGQT58nQo28R2ixgZps$KOFU=.MeasurePrecise:
			num2 = this.#=zjKLo8ptKvm2a(#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zlIXJ9$NfUZc_(), num, #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().#=zeWSpwqqtMyd5(), true);
			break;
		default:
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879808), new object[]
			{
				#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z2UYVtfD6dFvM().ToString()
			});
		}
		DateTime dateTime = #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().ExecutionTime - TimeSpan.FromSeconds((double)num2);
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879758), new object[]
		{
			num2,
			dateTime
		});
		#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==().ExecutionTime = dateTime;
		this.#=z8StzeqE=.#=zeR3QFrc=(#=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=.#=z1YYNWBd$be$s1fFldQ==());
	}

	// Token: 0x060004F3 RID: 1267 RVA: 0x000283D8 File Offset: 0x000265D8
	private int #=zjKLo8ptKvm2a(string #=z1TUMLauEf$RC, int #=zbwrJfOI=, TaskSendUnitTypes #=zPJCAPrY=, bool #=z032GOgI=)
	{
		UnitSquadCollection #=z9pa8tnf0N4olSB4NFA==;
		UnitSquadCollection #=zOv1QRcjirZF1egFClCYli68=;
		int num;
		#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(#=z1TUMLauEf$RC, this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out #=z9pa8tnf0N4olSB4NFA==, out #=zOv1QRcjirZF1egFClCYli68=, out num);
		return this.#=zjKLo8ptKvm2a(#=z9pa8tnf0N4olSB4NFA==, #=zOv1QRcjirZF1egFClCYli68=, #=zbwrJfOI=, #=zPJCAPrY=, #=z032GOgI=);
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x0002840C File Offset: 0x0002660C
	private int #=zjKLo8ptKvm2a(UnitSquadCollection #=z9pa8tnf0N4olSB4NFA==, UnitSquadCollection #=zOv1QRcjirZF1egFClCYli68=, int #=zbwrJfOI=, TaskSendUnitTypes #=zPJCAPrY=, bool #=z032GOgI=)
	{
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		UnitSquadCollection unitSquadCollection2 = new UnitSquadCollection();
		if (#=z032GOgI=)
		{
			int num = 100;
			for (int i = #=z9pa8tnf0N4olSB4NFA==.Count - 1; i >= 0; i--)
			{
				UnitSquad unitSquad = #=z9pa8tnf0N4olSB4NFA==[i];
				if (unitSquad.Type.SpeedBaseMultiplier < num && unitSquad.Number > 0)
				{
					num = unitSquad.Type.SpeedBaseMultiplier;
					if (num == 1)
					{
						break;
					}
				}
			}
			if (num > 1)
			{
				for (int j = #=zOv1QRcjirZF1egFClCYli68=.Count - 1; j >= 0; j--)
				{
					UnitSquad unitSquad2 = #=zOv1QRcjirZF1egFClCYli68=[j];
					if (unitSquad2.Type.SpeedBaseMultiplier < num && unitSquad2.Number > 0)
					{
						num = unitSquad2.Type.SpeedBaseMultiplier;
						if (num == 1)
						{
							break;
						}
					}
				}
			}
			for (int k = #=z9pa8tnf0N4olSB4NFA==.Count - 1; k >= 0; k--)
			{
				UnitSquad unitSquad3 = #=z9pa8tnf0N4olSB4NFA==[k];
				if (unitSquad3.Type.SpeedBaseMultiplier == num && unitSquad3.Number > 0)
				{
					unitSquadCollection.Add(new UnitSquad(unitSquad3.Type, 1));
				}
			}
			for (int l = #=zOv1QRcjirZF1egFClCYli68=.Count - 1; l >= 0; l--)
			{
				UnitSquad unitSquad4 = #=zOv1QRcjirZF1egFClCYli68=[l];
				if (unitSquad4.Type.SpeedBaseMultiplier == num && unitSquad4.Number > 0)
				{
					unitSquadCollection2.Add(new UnitSquad(unitSquad4.Type, 1));
				}
			}
		}
		else
		{
			UnitType unitType = null;
			for (int m = #=z9pa8tnf0N4olSB4NFA==.Count - 1; m >= 0; m--)
			{
				UnitSquad unitSquad5 = #=z9pa8tnf0N4olSB4NFA==[m];
				if (unitSquad5.Number > 0)
				{
					if (unitType == null)
					{
						unitType = unitSquad5.Type;
					}
					else if (#=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
					{
						unitSquad5.Type.SpeedBaseMultiplier.CompareTo(unitType.SpeedBaseMultiplier),
						unitSquad5.Type.Class.CompareTo(unitType.Class),
						unitSquad5.Type.Resource.CompareTo(unitType.Resource),
						unitSquad5.Type.Modification.CompareTo(unitType.Modification)
					}) < 0)
					{
						unitType = unitSquad5.Type;
					}
				}
			}
			for (int n = #=zOv1QRcjirZF1egFClCYli68=.Count - 1; n >= 0; n--)
			{
				UnitSquad unitSquad6 = #=zOv1QRcjirZF1egFClCYli68=[n];
				if (unitSquad6.Number > 0)
				{
					if (unitType == null)
					{
						unitType = unitSquad6.Type;
					}
					else if (#=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
					{
						unitSquad6.Type.SpeedBaseMultiplier.CompareTo(unitType.SpeedBaseMultiplier),
						unitSquad6.Type.Class.CompareTo(unitType.Class),
						unitSquad6.Type.Resource.CompareTo(unitType.Resource),
						unitSquad6.Type.Modification.CompareTo(unitType.Modification)
					}) < 0)
					{
						unitType = unitSquad6.Type;
					}
				}
			}
			for (int num2 = #=z9pa8tnf0N4olSB4NFA==.Count - 1; num2 >= 0; num2--)
			{
				UnitSquad unitSquad7 = #=z9pa8tnf0N4olSB4NFA==[num2];
				if (unitSquad7.Type.Id == unitType.Id)
				{
					unitSquadCollection.Add(new UnitSquad(unitSquad7.Type, 1));
					break;
				}
			}
			if (unitSquadCollection.Count == 0)
			{
				for (int num3 = #=zOv1QRcjirZF1egFClCYli68=.Count - 1; num3 >= 0; num3--)
				{
					UnitSquad unitSquad8 = #=zOv1QRcjirZF1egFClCYli68=[num3];
					if (unitSquad8.Type.Id == unitType.Id)
					{
						unitSquadCollection2.Add(new UnitSquad(unitSquad8.Type, 1));
						break;
					}
				}
			}
		}
		int num4 = 0;
		#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= = this.#=zwn5aCwWTvPV4;
		#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=();
		for (int num5 = 0; num5 < #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=.Count; num5++)
		{
			#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zk$6QZNA=(#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=[num5].#=zMuFMjGQ=());
			if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= != null && #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11100)
			{
				num4 = #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=();
				break;
			}
		}
		string text = #=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zy0P4$vJTLTxpa7WEqw==(unitSquadCollection, unitSquadCollection2, null);
		string text2 = this.#=zBsXSanI=.#=zZgTEjjDG86v_(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=z4ttDoYN4UeOZsvmnr4f1eMo=(#=zPJCAPrY=), #=zbwrJfOI=, unitSquadCollection, unitSquadCollection2, 0);
		if (!text2.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			object data = JSONManager.GetData(text2);
			Dictionary<string, object> dictionary = JSONManager.GetDictionary(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684));
			if (dictionary == null)
			{
				object[] array = JSONManager.GetArray(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
				dictionary = (Dictionary<string, object>)array[array.Length - 1];
			}
			int num6 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879395), new object[]
			{
				num6,
				text
			});
			if (!this.#=zU2V2Q9bXseGY.#=zgxmFrVwfCJn_(num6))
			{
				Task #=zcTyyNys= = new #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==(num6, TaskSources.ManualNotSavable, TaskSeverities.Urgent, TaskTypes.CancelSendUnits, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
				this.#=z8StzeqE=.#=zeR3QFrc=(#=zcTyyNys=);
			}
			if (num4 > 0)
			{
				Task #=zcTyyNys=2 = new #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(new TaskBlackMarketParams(num4, false, 1, 0.0, true, false, false), TaskSources.ManualNotSavable, TaskSeverities.Urgent, TaskTypes.UseBlackMarketItem, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
				this.#=z8StzeqE=.#=zeR3QFrc=(#=zcTyyNys=2);
			}
			Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071474));
			DateTime d = JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false);
			return (int)Math.Round((JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), false) - d).TotalSeconds);
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879589), new object[]
		{
			text,
			JSONManager.Cut(text2)
		});
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zUCIeSv7ynlYy(this.#=z8StzeqE=, #=zbwrJfOI=, true, this.#=zBsXSanI=);
		return this.#=zCuBGo5tW0kBH(#=z9pa8tnf0N4olSB4NFA==, #=zOv1QRcjirZF1egFClCYli68=, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zfTB62qendhk_VEy8rw==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zY0soxphmGIACbOHy6A==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==, null);
	}

	// Token: 0x060004F5 RID: 1269 RVA: 0x00028A48 File Offset: 0x00026C48
	private int #=zCuBGo5tW0kBH(string #=z1TUMLauEf$RC, int #=zhfS69jI=, int #=zmWD8vxE=, bool #=zGqELP6gXhHGm, string #=zLe9w5J5D7WUIKcPv8KlRyzV_gqtu)
	{
		UnitSquadCollection #=zFaw3GplOScPRKEa5Sw==;
		UnitSquadCollection #=zs32iWYSGTwqcfgnkoXdA_AM=;
		int num;
		#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(#=z1TUMLauEf$RC, this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out #=zFaw3GplOScPRKEa5Sw==, out #=zs32iWYSGTwqcfgnkoXdA_AM=, out num);
		return this.#=zCuBGo5tW0kBH(#=zFaw3GplOScPRKEa5Sw==, #=zs32iWYSGTwqcfgnkoXdA_AM=, #=zhfS69jI=, #=zmWD8vxE=, #=zGqELP6gXhHGm, #=zLe9w5J5D7WUIKcPv8KlRyzV_gqtu);
	}

	// Token: 0x060004F6 RID: 1270 RVA: 0x00028A7C File Offset: 0x00026C7C
	private int #=zCuBGo5tW0kBH(UnitSquadCollection #=zFaw3GplOScPRKEa5Sw==, UnitSquadCollection #=zs32iWYSGTwqcfgnkoXdA_AM=, int #=zhfS69jI=, int #=zmWD8vxE=, bool #=zGqELP6gXhHGm, string #=zLe9w5J5D7WUIKcPv8KlRyzV_gqtu)
	{
		double num = 10000.0;
		for (int i = #=zFaw3GplOScPRKEa5Sw==.Count - 1; i >= 0; i--)
		{
			UnitSquad unitSquad = #=zFaw3GplOScPRKEa5Sw==[i];
			if (unitSquad.Number > 0)
			{
				double num2 = #=zAbcSCj8sqOQ9y_deRAlbn8cBmKePAqynabK2tZ1ayjcg.#=zsQvruDEafBZD(unitSquad.Type);
				if (num2 < num)
				{
					num = num2;
				}
			}
		}
		for (int j = #=zs32iWYSGTwqcfgnkoXdA_AM=.Count - 1; j >= 0; j--)
		{
			UnitSquad unitSquad2 = #=zs32iWYSGTwqcfgnkoXdA_AM=[j];
			if (unitSquad2.Number > 0)
			{
				double num3 = #=zAbcSCj8sqOQ9y_deRAlbn8cBmKePAqynabK2tZ1ayjcg.#=zsQvruDEafBZD(unitSquad2.Type);
				if (num3 < num)
				{
					num = num3;
				}
			}
		}
		if (!string.IsNullOrEmpty(#=zLe9w5J5D7WUIKcPv8KlRyzV_gqtu))
		{
			string[] array = #=zLe9w5J5D7WUIKcPv8KlRyzV_gqtu.Split(new char[]
			{
				' ',
				',',
				'+',
				';',
				'\t',
				'\n',
				'\r'
			});
			for (int k = 0; k < array.Length; k++)
			{
				int num4;
				if (int.TryParse(array[k], out num4))
				{
					num = num * (100.0 + (double)num4) / 100.0;
				}
			}
		}
		double num5 = Math.Sqrt(Math.Pow((double)(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() - #=zhfS69jI=), 2.0) + Math.Pow((double)(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() - #=zmWD8vxE=), 2.0)) * 3600.0 / num;
		if (num5 > 86400.0)
		{
			num5 = 86400.0;
		}
		if (!#=zGqELP6gXhHGm)
		{
			num5 /= 8.0;
		}
		if (num5 < 60.0)
		{
			num5 = 60.0;
		}
		if (#=zs32iWYSGTwqcfgnkoXdA_AM= != null && #=zs32iWYSGTwqcfgnkoXdA_AM=.Count > 0)
		{
			num5 += 15.0;
		}
		return (int)Math.Round(num5);
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x00028C1C File Offset: 0x00026E1C
	private static double #=zsQvruDEafBZD(UnitType #=zvRLj9WQ=)
	{
		return (double)(#=zvRLj9WQ=.SpeedBaseMultiplier * 6 * 30);
	}

	// Token: 0x040001E7 RID: 487
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x040001E8 RID: 488
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x040001E9 RID: 489
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x040001EA RID: 490
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x040001EB RID: 491
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4;

	// Token: 0x040001EC RID: 492
	private #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1 #=zU2V2Q9bXseGY;
}
