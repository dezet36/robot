﻿using System;

// Token: 0x02000149 RID: 329
internal sealed class #=zLGNGlYZDYbmkMT1n62URMkfUc7HZ79TcvXpBZdwsZHuP
{
	// Token: 0x060008A8 RID: 2216 RVA: 0x0004451C File Offset: 0x0004271C
	public int #=zEpmJu0QO9VH_()
	{
		return this.#=zv1cPvddGDW17yRoN6A==;
	}

	// Token: 0x060008A9 RID: 2217 RVA: 0x00044524 File Offset: 0x00042724
	public void #=z_MMDqXnekqn_(int #=z$Ib9gYQ=)
	{
		this.#=zv1cPvddGDW17yRoN6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060008AA RID: 2218 RVA: 0x00044530 File Offset: 0x00042730
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x060008AB RID: 2219 RVA: 0x00044538 File Offset: 0x00042738
	public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x00044544 File Offset: 0x00042744
	public int #=zlIXJ9$NfUZc_()
	{
		return this.#=zxojFZYWVfXhu329mAA==;
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x0004454C File Offset: 0x0004274C
	public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
	{
		this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040004EA RID: 1258
	private int #=zv1cPvddGDW17yRoN6A==;

	// Token: 0x040004EB RID: 1259
	private DateTime #=zJDEdzIaDvHbnYM06$w==;

	// Token: 0x040004EC RID: 1260
	private int #=zxojFZYWVfXhu329mAA==;
}
