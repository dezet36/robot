﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200014D RID: 333
internal sealed class #=zLdas1G0kAAODvaqZgJo9xEujgDGZ : #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K
{
	// Token: 0x060008C5 RID: 2245 RVA: 0x00045C2C File Offset: 0x00043E2C
	private #=zLdas1G0kAAODvaqZgJo9xEujgDGZ(int #=zKJA8IWQ=, string #=zx9NCziM=, string #=z9G$C$ZArZiF$51$sEg==, DateTime #=z9iiP2tA=) : base((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6, #=zx9NCziM=, Array.Empty<object>())
	{
		this.#=zIaGGDzQ=(#=zKJA8IWQ=);
		this.#=zl8uGjuSZRpz0M$v1Yat74J8=(#=z9G$C$ZArZiF$51$sEg==);
		this.#=zIR9Xlcg=(#=z9iiP2tA=);
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x00045C54 File Offset: 0x00043E54
	public int #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x00045C5C File Offset: 0x00043E5C
	private void #=zIaGGDzQ=(int #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x00045C68 File Offset: 0x00043E68
	public string #=zz_zA9A3cg$dy3_yotwWFDqU=()
	{
		return this.#=z_JMFP_76iYQHeMmt23SUQHpW0f4f;
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x00045C70 File Offset: 0x00043E70
	private void #=zl8uGjuSZRpz0M$v1Yat74J8=(string #=z$Ib9gYQ=)
	{
		this.#=z_JMFP_76iYQHeMmt23SUQHpW0f4f = #=z$Ib9gYQ=;
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x00045C7C File Offset: 0x00043E7C
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x00045C84 File Offset: 0x00043E84
	private void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x060008CC RID: 2252 RVA: 0x00045C90 File Offset: 0x00043E90
	public static #=zLdas1G0kAAODvaqZgJo9xEujgDGZ #=zOBwwFP4=(string #=zx9NCziM=)
	{
		if (#=zx9NCziM= != null && #=zx9NCziM=.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			try
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zx9NCziM=.Substring(1));
				int #=zKJA8IWQ= = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0);
				string text = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), string.Empty);
				if (!string.IsNullOrEmpty(text) && text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205)))
				{
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)JSONManager.DeserializeData(text);
					string text2 = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), string.Empty);
					if (text2.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927197)))
					{
						string #=z9G$C$ZArZiF$51$sEg== = text2.Substring(30);
						DateTime #=z9iiP2tA= = JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false);
						return new #=zLdas1G0kAAODvaqZgJo9xEujgDGZ(#=zKJA8IWQ=, text2, #=z9G$C$ZArZiF$51$sEg==, #=z9iiP2tA=);
					}
					if (text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936695))
					{
						string #=zM8IB4GHgekmL = #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL;
						DateTime #=z9iiP2tA=2 = JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false);
						return new #=zLdas1G0kAAODvaqZgJo9xEujgDGZ(#=zKJA8IWQ=, text2, #=zM8IB4GHgekmL, #=z9iiP2tA=2);
					}
				}
			}
			catch (Exception innerException)
			{
				throw new Exception(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927158), #=zx9NCziM=), innerException);
			}
		}
		return null;
	}

	// Token: 0x04000502 RID: 1282
	private int #=z7Xrwc11cWxGe$3RbFQ==;

	// Token: 0x04000503 RID: 1283
	private string #=z_JMFP_76iYQHeMmt23SUQHpW0f4f;

	// Token: 0x04000504 RID: 1284
	private DateTime #=zJDEdzIaDvHbnYM06$w==;
}
