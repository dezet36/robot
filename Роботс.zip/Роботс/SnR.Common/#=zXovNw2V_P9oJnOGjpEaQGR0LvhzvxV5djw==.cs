﻿using System;
using System.Collections.Generic;

// Token: 0x020001D4 RID: 468
internal sealed class #=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw== : List<#=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==>
{
	// Token: 0x06000E12 RID: 3602 RVA: 0x00071428 File Offset: 0x0006F628
	public void #=z20ohAjI=(object[] #=zxxBHSdL4n_F4)
	{
		for (int i = 0; i < #=zxxBHSdL4n_F4.Length; i++)
		{
			base.Add(new #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==((Dictionary<string, object>)#=zxxBHSdL4n_F4[i]));
		}
	}

	// Token: 0x06000E13 RID: 3603 RVA: 0x00071458 File Offset: 0x0006F658
	public #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng== #=zS9T3RUESmMfO(int #=z5w6HcG4=)
	{
		if (base.Count == 0 || #=z5w6HcG4= <= 0)
		{
			return new #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==();
		}
		if (base.Count >= #=z5w6HcG4=)
		{
			return base[#=z5w6HcG4= - 1];
		}
		return base[base.Count - 1];
	}
}
