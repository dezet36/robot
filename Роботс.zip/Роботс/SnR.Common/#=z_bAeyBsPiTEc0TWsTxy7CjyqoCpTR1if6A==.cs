﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001F5 RID: 501
internal sealed class #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== : List<#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==>
{
	// Token: 0x06000F30 RID: 3888 RVA: 0x00078B24 File Offset: 0x00076D24
	public static #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=zi1hFJwI=()
	{
		if (#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr == null)
		{
			#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zpwV01Fffu0h0tuAXRw==();
			if (#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr != null)
			{
				ReadFileManager readFileManager = new ReadFileManager(FileResources.Academy, true);
				while (readFileManager.NextLine())
				{
					#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr.#=zk$6QZNA=(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0));
					if (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== != null)
					{
						string text = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315), 4);
						if (!string.IsNullOrWhiteSpace(text) && string.IsNullOrWhiteSpace(#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=zkfqcY3I=()))
						{
							#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=zwXKUV2c=(text);
						}
					}
				}
				for (int i = 0; i < #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr.Count; i++)
				{
					if (string.IsNullOrEmpty(#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr[i].#=zkfqcY3I=()))
					{
						#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr[i].#=zwXKUV2c=(#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr[i].Id.ToString());
					}
				}
			}
			else
			{
				#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr = new #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==();
			}
		}
		return #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zOHvkTyexIHpr;
	}

	// Token: 0x06000F31 RID: 3889 RVA: 0x00078C14 File Offset: 0x00076E14
	public #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== in this)
		{
			if (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.Id == #=zAk8mKBk=)
			{
				return #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==;
			}
		}
		return null;
	}

	// Token: 0x06000F32 RID: 3890 RVA: 0x00078C6C File Offset: 0x00076E6C
	public #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=zk$6QZNA=(string #=zAk8mKBk=)
	{
		int #=zAk8mKBk=2;
		if (int.TryParse(#=zAk8mKBk=, out #=zAk8mKBk=2))
		{
			return this.#=zk$6QZNA=(#=zAk8mKBk=2);
		}
		return null;
	}

	// Token: 0x06000F33 RID: 3891 RVA: 0x00078C8C File Offset: 0x00076E8C
	public string #=zC6JIMv4=(int #=zp13pRNQ=)
	{
		#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== = this.#=zk$6QZNA=(#=zp13pRNQ=);
		if (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== != null)
		{
			return #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=zkfqcY3I=();
		}
		return #=zp13pRNQ=.ToString();
	}

	// Token: 0x04000878 RID: 2168
	private static #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=zOHvkTyexIHpr;
}
