﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;

// Token: 0x020000DF RID: 223
internal sealed class #=zDSiRXECNe4Awos25aECUKlmR8FRd
{
	// Token: 0x060005EE RID: 1518 RVA: 0x00030DA8 File Offset: 0x0002EFA8
	public #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, LogTypes #=zvRLj9WQ=, string #=z52HL_CpuRYfT, object[] #=zlP66l7Q4Pzmc)
	{
		this.#=z3OOfjngD3sLD = ((#=zG2wnL_q7IxpD == null) ? LogThreadPartTypes.None : (#=zG2wnL_q7IxpD.#=zU3NiAfDQweme8jKsqw==() ? LogThreadPartTypes.Urgent : LogThreadPartTypes.Background));
		this.#=zQ4_NWTk= = #=zvRLj9WQ=;
		this.#=z7LIqqf8= = DateTime.Now;
		this.#=zXghrlS5ZAJsA = ((#=z52HL_CpuRYfT == null) ? string.Empty : #=z52HL_CpuRYfT.Trim(new char[1]));
		this.#=z8UIjt5tRtzVS = #=zlP66l7Q4Pzmc;
		this.#=z0SJ2qFt1o3tk = null;
		this.#=zRQBwguoTAAxk = false;
	}

	// Token: 0x060005EF RID: 1519 RVA: 0x00030E18 File Offset: 0x0002F018
	public LogTypes #=zq2bPTdY=()
	{
		return this.#=zQ4_NWTk=;
	}

	// Token: 0x060005F0 RID: 1520 RVA: 0x00030E20 File Offset: 0x0002F020
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=z7LIqqf8=;
	}

	// Token: 0x060005F1 RID: 1521 RVA: 0x00030E28 File Offset: 0x0002F028
	public string #=zTNSS3ihKtVfU()
	{
		return this.#=zXghrlS5ZAJsA;
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x00030E30 File Offset: 0x0002F030
	public object[] #=zVIqstfu8tTbu()
	{
		return this.#=z8UIjt5tRtzVS;
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x00030E38 File Offset: 0x0002F038
	public bool #=zwDJkyD$O$Kj_()
	{
		return this.#=zRQBwguoTAAxk;
	}

	// Token: 0x060005F4 RID: 1524 RVA: 0x00030E40 File Offset: 0x0002F040
	public void #=zWRBkqWnAY2Zq(bool #=z$Ib9gYQ=)
	{
		this.#=zRQBwguoTAAxk = #=z$Ib9gYQ=;
	}

	// Token: 0x060005F5 RID: 1525 RVA: 0x00030E4C File Offset: 0x0002F04C
	public string #=znwxGN8g=(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg== #=zGR3UNcM=)
	{
		if (this.#=z0SJ2qFt1o3tk == null)
		{
			string format = #=zGR3UNcM=.#=zt5hOKIs=(this.#=zXghrlS5ZAJsA);
			if (this.#=z8UIjt5tRtzVS.Length != 0)
			{
				this.#=z0SJ2qFt1o3tk = string.Format(format, this.#=z8UIjt5tRtzVS);
			}
			else
			{
				this.#=z0SJ2qFt1o3tk = format;
			}
		}
		return this.#=z0SJ2qFt1o3tk;
	}

	// Token: 0x060005F6 RID: 1526 RVA: 0x00030E98 File Offset: 0x0002F098
	public string #=zwoF3kPznsOcA()
	{
		LogThreadPartTypes logThreadPartTypes = this.#=z3OOfjngD3sLD;
		string text;
		if (logThreadPartTypes != LogThreadPartTypes.Background)
		{
			if (logThreadPartTypes == LogThreadPartTypes.Urgent)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026589);
			}
			else
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023908);
			}
		}
		else
		{
			text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070606);
		}
		string text2;
		if (this.#=z8UIjt5tRtzVS.Length != 0)
		{
			text2 = string.Format(this.#=zXghrlS5ZAJsA, this.#=z8UIjt5tRtzVS).Trim(new char[]
			{
				'[',
				']'
			});
		}
		else
		{
			text2 = this.#=zXghrlS5ZAJsA.Trim(new char[]
			{
				'[',
				']'
			});
		}
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023900), new object[]
		{
			this.#=zPHMvvJ8=(),
			text,
			this.#=zq2bPTdY=(),
			text2
		});
	}

	// Token: 0x060005F7 RID: 1527 RVA: 0x00030F60 File Offset: 0x0002F160
	public static void #=zTzbblUpMiEIf(Exception #=zN_s5Z5A=)
	{
		#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00030F70 File Offset: 0x0002F170
	public static void #=zTzbblUpMiEIf(string #=zx9NCziM=)
	{
		try
		{
			string #=z0ONi4Bk= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023592);
			string #=zNt13QGc= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023568), DateTime.Now, #=zx9NCziM=, Environment.NewLine);
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zxyAQIs1RlUuf(#=z0ONi4Bk=, #=zNt13QGc=, Encoding.UTF8);
		}
		catch
		{
		}
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x00030FC8 File Offset: 0x0002F1C8
	public static List<string> #=zpLDa5fpZcmyK(string #=zpkz1bP8=, int #=zLeeSKrg=, bool #=zmwtclNNtkfCT, bool #=zxd_fRJSorPMC)
	{
		string directoryName = Path.GetDirectoryName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023531));
		if (!Directory.Exists(directoryName))
		{
			return new List<string>();
		}
		List<string> list = new List<string>();
		if (#=zmwtclNNtkfCT)
		{
			string searchPattern = string.Format(Path.GetFileName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023531)), new object[]
			{
				GameApplicationData.#=zZ2dsDUeWDYAN(),
				#=zpkz1bP8=,
				#=zLeeSKrg=,
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263)
			});
			list.AddRange(Directory.EnumerateFiles(directoryName, searchPattern));
		}
		if (#=zxd_fRJSorPMC)
		{
			string searchPattern2 = string.Format(Path.GetFileName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023531)), new object[]
			{
				GameApplicationData.#=zZ2dsDUeWDYAN(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023490),
				0,
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263)
			});
			list.AddRange(Directory.EnumerateFiles(directoryName, searchPattern2));
		}
		return list;
	}

	// Token: 0x04000272 RID: 626
	private LogThreadPartTypes #=z3OOfjngD3sLD;

	// Token: 0x04000273 RID: 627
	private LogTypes #=zQ4_NWTk=;

	// Token: 0x04000274 RID: 628
	private DateTime #=z7LIqqf8=;

	// Token: 0x04000275 RID: 629
	private string #=zXghrlS5ZAJsA;

	// Token: 0x04000276 RID: 630
	private object[] #=z8UIjt5tRtzVS;

	// Token: 0x04000277 RID: 631
	private string #=z0SJ2qFt1o3tk;

	// Token: 0x04000278 RID: 632
	private bool #=zRQBwguoTAAxk;
}
