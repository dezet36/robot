﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x02000246 RID: 582
internal sealed class #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q : IIntID
{
	// Token: 0x060011BB RID: 4539 RVA: 0x00089F8C File Offset: 0x0008818C
	public #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q(int #=zAk8mKBk=, string #=z6QPrZ_4=, #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q.#=zJppzcmQ= #=z3lUqbh8=)
	{
		this.Id = #=zAk8mKBk=;
		this.#=zwXKUV2c=(#=z6QPrZ_4=);
		this.#=z8RUD$1mtl5at(#=z3lUqbh8=);
		this.#=zjAHB4aZjs9ee(0);
		this.#=zI74NzG$2ecMvvw_Hiw==(0);
		this.#=z3fBYDJSJTfKs(1.0);
		this.#=zGXx5PO7A_7$H(new List<int>());
		this.#=zbIWQPetTad15jE1XBg==(0);
	}

	// Token: 0x060011BC RID: 4540 RVA: 0x00089FE4 File Offset: 0x000881E4
	public #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q(Dictionary<string, object> #=z1YNp7IY=)
	{
		this.Id = JSONManager.ExtractInt(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
		this.#=zwXKUV2c=(JSONManager.GetString(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070020));
		this.#=z8RUD$1mtl5at((#=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q.#=zJppzcmQ=)JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), 0));
		this.#=zjAHB4aZjs9ee(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		this.#=zI74NzG$2ecMvvw_Hiw==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), 0));
		this.#=z3fBYDJSJTfKs(JSONManager.ExtractDouble(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), -1.0));
		this.#=zGXx5PO7A_7$H(new List<int>());
		object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070013));
		if (array != null)
		{
			foreach (int item in array)
			{
				this.#=zje04I5G2OOWR().Add(item);
			}
		}
		this.#=zbIWQPetTad15jE1XBg==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069994), 0));
	}

	// Token: 0x17000056 RID: 86
	// (get) Token: 0x060011BD RID: 4541 RVA: 0x0008A0F8 File Offset: 0x000882F8
	// (set) Token: 0x060011BE RID: 4542 RVA: 0x0008A100 File Offset: 0x00088300
	public int Id
	{
		[CompilerGenerated]
		get
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = value;
		}
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x0008A10C File Offset: 0x0008830C
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060011C0 RID: 4544 RVA: 0x0008A114 File Offset: 0x00088314
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011C1 RID: 4545 RVA: 0x0008A120 File Offset: 0x00088320
	public #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q.#=zJppzcmQ= #=zZOFUOewkm7ea()
	{
		return this.#=zxxpCOnxCUYo104orQw==;
	}

	// Token: 0x060011C2 RID: 4546 RVA: 0x0008A128 File Offset: 0x00088328
	public void #=z8RUD$1mtl5at(#=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q.#=zJppzcmQ= #=z$Ib9gYQ=)
	{
		this.#=zxxpCOnxCUYo104orQw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011C3 RID: 4547 RVA: 0x0008A134 File Offset: 0x00088334
	public int #=ziH$Mdl0ewcJR()
	{
		return this.#=zYT8l5i9D3Gd0EYZO$CkaDng=;
	}

	// Token: 0x060011C4 RID: 4548 RVA: 0x0008A13C File Offset: 0x0008833C
	public void #=zjAHB4aZjs9ee(int #=z$Ib9gYQ=)
	{
		this.#=zYT8l5i9D3Gd0EYZO$CkaDng= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011C5 RID: 4549 RVA: 0x0008A148 File Offset: 0x00088348
	public int #=zaKAy47_E$9SRuF6oiw==()
	{
		return this.#=zg9DHdRJeKrYsJIc4CEiCbn4=;
	}

	// Token: 0x060011C6 RID: 4550 RVA: 0x0008A150 File Offset: 0x00088350
	public void #=zI74NzG$2ecMvvw_Hiw==(int #=z$Ib9gYQ=)
	{
		this.#=zg9DHdRJeKrYsJIc4CEiCbn4= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011C7 RID: 4551 RVA: 0x0008A15C File Offset: 0x0008835C
	public double #=zMTX4MPxRrytT()
	{
		return this.#=zEolvYBbkuOT_MiNalB9jA3s=;
	}

	// Token: 0x060011C8 RID: 4552 RVA: 0x0008A164 File Offset: 0x00088364
	public void #=z3fBYDJSJTfKs(double #=z$Ib9gYQ=)
	{
		this.#=zEolvYBbkuOT_MiNalB9jA3s= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011C9 RID: 4553 RVA: 0x0008A170 File Offset: 0x00088370
	public bool #=zXOftPVs2kwOr()
	{
		return this.#=zMTX4MPxRrytT() <= 0.0;
	}

	// Token: 0x060011CA RID: 4554 RVA: 0x0008A188 File Offset: 0x00088388
	public List<int> #=zje04I5G2OOWR()
	{
		return this.#=zANsBpRxnQzrvHMNbScIN84s=;
	}

	// Token: 0x060011CB RID: 4555 RVA: 0x0008A190 File Offset: 0x00088390
	public void #=zGXx5PO7A_7$H(List<int> #=z$Ib9gYQ=)
	{
		this.#=zANsBpRxnQzrvHMNbScIN84s= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011CC RID: 4556 RVA: 0x0008A19C File Offset: 0x0008839C
	public int #=z45sd5C$gcFqwpb5U$A==()
	{
		return this.#=zVHoY1x1rLDb0Vo2ZLX55qWWn1gc1;
	}

	// Token: 0x060011CD RID: 4557 RVA: 0x0008A1A4 File Offset: 0x000883A4
	public void #=zbIWQPetTad15jE1XBg==(int #=z$Ib9gYQ=)
	{
		this.#=zVHoY1x1rLDb0Vo2ZLX55qWWn1gc1 = #=z$Ib9gYQ=;
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x0008A1B0 File Offset: 0x000883B0
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x040009E9 RID: 2537
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040009EA RID: 2538
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040009EB RID: 2539
	private #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q.#=zJppzcmQ= #=zxxpCOnxCUYo104orQw==;

	// Token: 0x040009EC RID: 2540
	private int #=zYT8l5i9D3Gd0EYZO$CkaDng=;

	// Token: 0x040009ED RID: 2541
	private int #=zg9DHdRJeKrYsJIc4CEiCbn4=;

	// Token: 0x040009EE RID: 2542
	private double #=zEolvYBbkuOT_MiNalB9jA3s=;

	// Token: 0x040009EF RID: 2543
	private List<int> #=zANsBpRxnQzrvHMNbScIN84s=;

	// Token: 0x040009F0 RID: 2544
	private int #=zVHoY1x1rLDb0Vo2ZLX55qWWn1gc1;

	// Token: 0x02000247 RID: 583
	public enum #=zJppzcmQ=
	{

	}
}
