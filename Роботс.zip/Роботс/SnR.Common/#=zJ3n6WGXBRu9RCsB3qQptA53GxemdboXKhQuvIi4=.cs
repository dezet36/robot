﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;

// Token: 0x02000125 RID: 293
internal sealed class #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=
{
	// Token: 0x0600073A RID: 1850 RVA: 0x0003C91C File Offset: 0x0003AB1C
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zJ5GWysk=)
	{
		this.#=z9HdGFQI= = #=zJ5GWysk=;
		if (#=zJ5GWysk= is #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX)
		{
			this.#=zIaGGDzQ=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071336));
			this.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)500);
			this.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)0);
			this.#=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes.Gold);
			this.#=zpmbhfimGMj3U((double)#=zJ5GWysk=.#=zgxqDXpkUbQpR() / 3600.0);
			return;
		}
		if (#=zJ5GWysk= is #=zP8oGWsB5Ry42JYXu8GYfc8JVNXPN8ynx1wb1krDoZ5nNMzEX$tV4FR0=)
		{
			this.#=zIaGGDzQ=(this.#=z9HdGFQI=.#=zMuFMjGQ=().ToString());
			this.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)5101);
			this.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)6);
			this.#=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes.Gold);
			this.#=zpmbhfimGMj3U((double)#=zJ5GWysk=.#=zgxqDXpkUbQpR() / 3600.0);
			return;
		}
		this.#=zIaGGDzQ=(this.#=z9HdGFQI=.#=zMuFMjGQ=().ToString());
		this.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)0);
		this.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)0);
		this.#=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes.Unknown);
		this.#=zpmbhfimGMj3U(0.0);
	}

	// Token: 0x0600073C RID: 1852 RVA: 0x0003CA6C File Offset: 0x0003AC6C
	public int #=zMuFMjGQ=()
	{
		return this.#=z9HdGFQI=.#=zMuFMjGQ=();
	}

	// Token: 0x0600073D RID: 1853 RVA: 0x0003CA7C File Offset: 0x0003AC7C
	public string #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x0600073E RID: 1854 RVA: 0x0003CA84 File Offset: 0x0003AC84
	public void #=zIaGGDzQ=(string #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600073F RID: 1855 RVA: 0x0003CA90 File Offset: 0x0003AC90
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM= #=z9gSOax4=()
	{
		return this.#=zOPBAYSIdpaoKtoM9Ug==;
	}

	// Token: 0x06000740 RID: 1856 RVA: 0x0003CA98 File Offset: 0x0003AC98
	public void #=z_PEN4Dg=(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM= #=z$Ib9gYQ=)
	{
		this.#=zOPBAYSIdpaoKtoM9Ug== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000741 RID: 1857 RVA: 0x0003CAA4 File Offset: 0x0003ACA4
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D #=z_hmItAwnEING()
	{
		return this.#=z0mxovMquR76GfWkQlbqHFIw=;
	}

	// Token: 0x06000742 RID: 1858 RVA: 0x0003CAAC File Offset: 0x0003ACAC
	public void #=zYFVB57ja3aZW(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D #=z$Ib9gYQ=)
	{
		this.#=z0mxovMquR76GfWkQlbqHFIw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000743 RID: 1859 RVA: 0x0003CAB8 File Offset: 0x0003ACB8
	public ResourceTypes #=zQ4pGtq_Ng_rixBGQrQ==()
	{
		return this.#=zOJHBGzCldrQpTdSJfxTrP9wJJtVd;
	}

	// Token: 0x06000744 RID: 1860 RVA: 0x0003CAC0 File Offset: 0x0003ACC0
	public void #=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zOJHBGzCldrQpTdSJfxTrP9wJJtVd = #=z$Ib9gYQ=;
	}

	// Token: 0x06000745 RID: 1861 RVA: 0x0003CACC File Offset: 0x0003ACCC
	public double #=zjw43QGFcPyHH()
	{
		return this.#=z$cjfMsOUZJUVVe7pGQ==;
	}

	// Token: 0x06000746 RID: 1862 RVA: 0x0003CAD4 File Offset: 0x0003ACD4
	public void #=zpmbhfimGMj3U(double #=z$Ib9gYQ=)
	{
		this.#=z$cjfMsOUZJUVVe7pGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000747 RID: 1863 RVA: 0x0003CAE0 File Offset: 0x0003ACE0
	public string #=zkfqcY3I=()
	{
		return this.#=z9HdGFQI=.#=zkfqcY3I=();
	}

	// Token: 0x06000748 RID: 1864 RVA: 0x0003CAF0 File Offset: 0x0003ACF0
	public int #=zisvlKsvs85jd()
	{
		return this.#=zwrxFSXxdh_fTOBnHX1jxmt0=;
	}

	// Token: 0x06000749 RID: 1865 RVA: 0x0003CAF8 File Offset: 0x0003ACF8
	public void #=z2a_u_nRabC8z(int #=z$Ib9gYQ=)
	{
		this.#=zwrxFSXxdh_fTOBnHX1jxmt0= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600074A RID: 1866 RVA: 0x0003CB04 File Offset: 0x0003AD04
	public ResourceTypes #=zQ4T_EIPCifaGgxLmcA==()
	{
		return this.#=zM4jg7MW2M3vg3N6GM1uuD0M=;
	}

	// Token: 0x0600074B RID: 1867 RVA: 0x0003CB0C File Offset: 0x0003AD0C
	public void #=zW$nvWxUdcXuzAEErVw==(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zM4jg7MW2M3vg3N6GM1uuD0M= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600074C RID: 1868 RVA: 0x0003CB18 File Offset: 0x0003AD18
	public bool #=zJVAdIDg9hSidub8$Uw==()
	{
		return this.#=z9HdGFQI=.#=zJVAdIDg9hSidub8$Uw==();
	}

	// Token: 0x0600074D RID: 1869 RVA: 0x0003CB28 File Offset: 0x0003AD28
	public bool #=zskZ$IzJYQKQa()
	{
		return this.#=ziYIHJ9bBkSpgoLqg7m0L4UQ=;
	}

	// Token: 0x0600074E RID: 1870 RVA: 0x0003CB30 File Offset: 0x0003AD30
	public void #=zjDwFDaMA8CSQ(bool #=z$Ib9gYQ=)
	{
		this.#=ziYIHJ9bBkSpgoLqg7m0L4UQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600074F RID: 1871 RVA: 0x0003CB3C File Offset: 0x0003AD3C
	public bool #=z$NyihN71ouQU()
	{
		return this.#=z9HdGFQI=.#=z$NyihN71ouQU();
	}

	// Token: 0x06000750 RID: 1872 RVA: 0x0003CB4C File Offset: 0x0003AD4C
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x0400045A RID: 1114
	public static readonly List<int> #=zhcdDwgYfw_ImvQmMXQ== = new List<int>
	{
		9020,
		9021,
		9022,
		9030,
		9031,
		9032
	};

	// Token: 0x0400045B RID: 1115
	private #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=z9HdGFQI=;

	// Token: 0x0400045C RID: 1116
	private string #=z7Xrwc11cWxGe$3RbFQ==;

	// Token: 0x0400045D RID: 1117
	private #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM= #=zOPBAYSIdpaoKtoM9Ug==;

	// Token: 0x0400045E RID: 1118
	private #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D #=z0mxovMquR76GfWkQlbqHFIw=;

	// Token: 0x0400045F RID: 1119
	private ResourceTypes #=zOJHBGzCldrQpTdSJfxTrP9wJJtVd;

	// Token: 0x04000460 RID: 1120
	private double #=z$cjfMsOUZJUVVe7pGQ==;

	// Token: 0x04000461 RID: 1121
	private int #=zwrxFSXxdh_fTOBnHX1jxmt0=;

	// Token: 0x04000462 RID: 1122
	private ResourceTypes #=zM4jg7MW2M3vg3N6GM1uuD0M=;

	// Token: 0x04000463 RID: 1123
	private bool #=ziYIHJ9bBkSpgoLqg7m0L4UQ=;

	// Token: 0x02000126 RID: 294
	public enum #=zj19KhTM=
	{

	}

	// Token: 0x02000127 RID: 295
	public enum #=zqRJC4XyBqf1D
	{

	}
}
