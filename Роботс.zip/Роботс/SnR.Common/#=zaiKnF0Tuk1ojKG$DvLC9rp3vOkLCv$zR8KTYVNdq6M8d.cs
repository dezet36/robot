﻿using System;

// Token: 0x020001FE RID: 510
internal sealed class #=zaiKnF0Tuk1ojKG$DvLC9rp3vOkLCv$zR8KTYVNdq6M8d : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000FAA RID: 4010 RVA: 0x0007A528 File Offset: 0x00078728
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zuke9abg= = new #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1(this.#=z8StzeqE=, #=zuJjQ1XU=);
	}

	// Token: 0x06000FAB RID: 4011 RVA: 0x0007A53C File Offset: 0x0007873C
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959246), Array.Empty<object>());
			return;
		}
		#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== = (#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==)this.#=zcDRV51Ut$7oP;
		this.#=zuke9abg=.#=zgxmFrVwfCJn_(#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==.#=zs6AfR9w58BN2());
	}

	// Token: 0x040008AB RID: 2219
	private #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1 #=zuke9abg=;
}
