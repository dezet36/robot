﻿using System;
using System.Collections.Generic;

// Token: 0x02000045 RID: 69
internal sealed class #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ : List<#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN>
{
	// Token: 0x06000228 RID: 552 RVA: 0x00014F40 File Offset: 0x00013140
	public #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN in this)
		{
			if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN;
			}
		}
		return null;
	}
}
