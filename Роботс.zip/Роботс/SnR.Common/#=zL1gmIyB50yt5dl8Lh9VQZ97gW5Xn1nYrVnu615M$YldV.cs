﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.TaskProcessors;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x0200013A RID: 314
internal sealed class #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV
{
	// Token: 0x0600083F RID: 2111 RVA: 0x00041FAC File Offset: 0x000401AC
	private #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV()
	{
		this.#=zgI2P7ZrELaRz = false;
		this.#=zV68dPxoDznd7 = null;
		this.#=zSZPX3uYqrgEshnsYng== = null;
		this.#=zsH1oMGdy3Eph = new Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>();
		this.#=z$mUMMstCPPVgxiGZfMryi04= = null;
		this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc= = new Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm$tWybb298uwhMVBRw==>();
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x00041FFC File Offset: 0x000401FC
	public static bool #=zvb5bnug=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=, Task #=zcDRV51Ut$7oP)
	{
		if (#=zcDRV51Ut$7oP.Type == TaskTypes.MassAttackManage)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=z20ohAjI=(#=zuJjQ1XU=);
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zyadZ79g=(#=zcDRV51Ut$7oP as #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs);
			return true;
		}
		if (#=zcDRV51Ut$7oP.Type == TaskTypes.MassAttackExecute)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=z20ohAjI=(#=zuJjQ1XU=);
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zEGKDsXI=();
			return true;
		}
		return false;
	}

	// Token: 0x06000842 RID: 2114 RVA: 0x00042054 File Offset: 0x00040254
	public static #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zKVN4CRU=()
	{
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zOAzeRO$HqsMN == null)
		{
			object obj = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zOAzeRO$HqsMN == null)
				{
					#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zOAzeRO$HqsMN = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV();
				}
			}
		}
		return #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zOAzeRO$HqsMN;
	}

	// Token: 0x06000843 RID: 2115 RVA: 0x000420B0 File Offset: 0x000402B0
	public void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zpzrSpck= = #=zuJjQ1XU=.#=zQ4wZnctPyyRO();
		this.#=zBsXSanI= = #=zuJjQ1XU=.#=z$2ijYGRf0FB5();
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x00042120 File Offset: 0x00040320
	public static int #=zNRcDVdwkBNkN()
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		if (!#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zgI2P7ZrELaRz)
		{
			object obj = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (!#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zgI2P7ZrELaRz)
				{
					if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== == null)
					{
						List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zol80P7TKoihZ();
						for (int i = 0; i < list.Count; i++)
						{
							Task task = list[i].#=zzia5edbZiDd_52XM1A==().#=zEh7CJ2RYceMs(TaskTypes.MassAttackManage);
							if (task != null && task is #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs)
							{
								#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zV68dPxoDznd7 = list[i];
								#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== = (task as #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs);
							}
						}
					}
					#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zgI2P7ZrELaRz = true;
				}
			}
		}
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== != null)
		{
			return #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2();
		}
		return -1;
	}

	// Token: 0x06000845 RID: 2117 RVA: 0x000421F0 File Offset: 0x000403F0
	public static string #=zqErSmu7W4tPC()
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zV68dPxoDznd7;
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
		{
			return #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==();
		}
		return string.Empty;
	}

	// Token: 0x06000846 RID: 2118 RVA: 0x00042218 File Offset: 0x00040418
	public static int[] #=zy$srgl7q7hWR()
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== == null)
		{
			return new int[2];
		}
		return new int[]
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY().Count,
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY().Count + #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Count
		};
	}

	// Token: 0x06000847 RID: 2119 RVA: 0x00042278 File Offset: 0x00040478
	public static List<TriadState> #=zSuB9zc1tfPyVEea83Q==()
	{
		List<TriadState> list = new List<TriadState>();
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== == null)
		{
			return list;
		}
		List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> list2 = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==();
		for (int i = 0; i < list2.Count; i++)
		{
			list.Add(new TriadState(list2[i], #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2(), #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=));
		}
		return list;
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x000422DC File Offset: 0x000404DC
	public static void #=z373T$7SkZDkT(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zCsFfX0LBCUiE)
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zH6bes6nyzqqTevjbM$5ga2c= #=zH6bes6nyzqqTevjbM$5ga2c= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zH6bes6nyzqqTevjbM$5ga2c=();
		#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE = #=zCsFfX0LBCUiE;
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng== == null)
		{
			return;
		}
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Remove(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE);
		if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Count == 0)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zUXevGubU4Zg5();
			return;
		}
		#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg= = 0;
		while (#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg= < #=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE.Count)
		{
			if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==() != null)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Remove(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE[#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg=].#=zCCvotbi$42tS());
			}
			if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY() != null)
			{
				List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> list = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY();
				Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> match;
				if ((match = #=zH6bes6nyzqqTevjbM$5ga2c=.#=zxwmV42lQK4CR) == null)
				{
					match = (#=zH6bes6nyzqqTevjbM$5ga2c=.#=zxwmV42lQK4CR = new Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zoMggb9ZQEqG6Mxjw6LFb6aE=));
				}
				list.RemoveAll(match);
			}
			if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zsH1oMGdy3Eph != null)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zsH1oMGdy3Eph.Remove(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE[#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg=].#=zCCvotbi$42tS());
			}
			if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z$mUMMstCPPVgxiGZfMryi04= != null)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z$mUMMstCPPVgxiGZfMryi04=.Remove(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE[#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg=].#=zCCvotbi$42tS());
			}
			if (#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z4ZAGqp_z8K5R6k$SsSWZ3hc= != null)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=.Remove(#=zH6bes6nyzqqTevjbM$5ga2c=.#=zCsFfX0LBCUiE[#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg=].#=zCCvotbi$42tS());
			}
			int #=zH2f5zJg= = #=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg=;
			#=zH6bes6nyzqqTevjbM$5ga2c=.#=zH2f5zJg= = #=zH2f5zJg= + 1;
		}
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x00042458 File Offset: 0x00040658
	public void #=zEGKDsXI=()
	{
		if (this.#=zSZPX3uYqrgEshnsYng== == null)
		{
			return;
		}
		switch (this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2())
		{
		case 0:
			this.#=zxaZoPOQ37eXM();
			break;
		case 2:
			this.#=zmqoJehgOyVbAO83iYLqvZ9xEOjdz();
			break;
		case 3:
			this.#=zf$T5FDANGJpgXj9T4XQH$uffPTrIsZXtFA==();
			break;
		}
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965803), Array.Empty<object>());
	}

	// Token: 0x0600084A RID: 2122 RVA: 0x000424D4 File Offset: 0x000406D4
	private void #=zxaZoPOQ37eXM()
	{
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965502), Array.Empty<object>());
		if (this.#=zsUAjCQwjeHewB1krNJlOKEY=.Count == 0)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965424), Array.Empty<object>());
			return;
		}
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zmLrGNVIgSMUH8cG0eyaa7PQ=(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B(), this.#=zpzrSpck=, this.#=zBsXSanI=);
		UnitSquadCollection unitSquadCollection;
		UnitSquadCollection addSquads;
		int num;
		#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(this.#=zSZPX3uYqrgEshnsYng==.#=zI0JHwt8spVuO(), this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out unitSquadCollection, out addSquads, out num);
		unitSquadCollection.AddUnits(addSquads);
		if ((this.#=zSZPX3uYqrgEshnsYng==.#=zs3hM4e6_G31KBZ9flA==() & (#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)1) == (#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)1)
		{
			#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zgCEatgfxawCZM3H0DQ==(this.#=zSZPX3uYqrgEshnsYng==.#=zi0WaUTfkdjJMIVEyAg==() / 3, unitSquadCollection, false, this.#=zJF2YTStZkxdpBvijgveKmkY=);
		}
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= value = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=(this.#=zpzrSpck=, unitSquadCollection);
		object obj = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zSV4$mlFB34WM;
		lock (obj)
		{
			this.#=zsH1oMGdy3Eph[this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()] = value;
		}
	}

	// Token: 0x0600084B RID: 2123 RVA: 0x0004260C File Offset: 0x0004080C
	private void #=zmqoJehgOyVbAO83iYLqvZ9xEOjdz()
	{
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965382), Array.Empty<object>());
		if (this.#=z$mUMMstCPPVgxiGZfMryi04= == null)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965574), Array.Empty<object>());
			return;
		}
		if (this.#=z$mUMMstCPPVgxiGZfMryi04=.ContainsKey(this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()))
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965505), Array.Empty<object>());
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = this.#=z$mUMMstCPPVgxiGZfMryi04=[this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()];
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = this.#=z48EqDrJggLl29t1RdOpA7iYdNvUP(#=zBbLKsV0=.#=zMuFMjGQ=());
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== != null)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965186), new object[]
				{
					#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().ToStringLabels()
				});
				this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=[this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()] = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm$tWybb298uwhMVBRw==(this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), #=zBbLKsV0=.#=zMuFMjGQ=(), #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==());
				this.#=z$mUMMstCPPVgxiGZfMryi04=.Remove(this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe());
				return;
			}
			UnitSquadCollection unitSquadCollection;
			UnitSquadCollection unitSquadCollection2;
			int num;
			#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(this.#=zSZPX3uYqrgEshnsYng==.#=zI0JHwt8spVuO(), this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out unitSquadCollection, out unitSquadCollection2, out num);
			if ((this.#=zSZPX3uYqrgEshnsYng==.#=zs3hM4e6_G31KBZ9flA==() & (#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)1) == (#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)1)
			{
				#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zgCEatgfxawCZM3H0DQ==(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zgCEatgfxawCZM3H0DQ==(this.#=zSZPX3uYqrgEshnsYng==.#=zi0WaUTfkdjJMIVEyAg==() / 3, unitSquadCollection2, false, this.#=zJF2YTStZkxdpBvijgveKmkY=), unitSquadCollection, false, this.#=zJF2YTStZkxdpBvijgveKmkY=);
			}
			int #=zTH01DjU= = 0;
			string text;
			if (unitSquadCollection.Count == 0)
			{
				text = unitSquadCollection2.ToStringLabels();
			}
			else if (unitSquadCollection2.Count == 0)
			{
				text = unitSquadCollection.ToStringLabels();
			}
			else
			{
				text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965363), new object[]
				{
					unitSquadCollection.ToStringLabels(),
					unitSquadCollection2.ToStringLabels()
				}).ToString();
			}
			string text2 = this.#=zBsXSanI=.#=zWYvEC7HhMxBOcSI89TZRLg0=(#=zBbLKsV0=.#=zMuFMjGQ=(), unitSquadCollection, unitSquadCollection2, #=zTH01DjU=);
			if (text2.Length > 10000)
			{
				this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965335), new object[]
				{
					#=zBbLKsV0=.#=zkfqcY3I=(),
					text
				});
				this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.RemoveUnits(unitSquadCollection);
				this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==.RemoveUnits(unitSquadCollection);
				this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection2);
				this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection2);
				return;
			}
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965275), new object[]
			{
				#=zBbLKsV0=.#=zkfqcY3I=(),
				text,
				JSONManager.Cut(text2)
			});
		}
	}

	// Token: 0x0600084C RID: 2124 RVA: 0x00042904 File Offset: 0x00040B04
	private void #=zf$T5FDANGJpgXj9T4XQH$uffPTrIsZXtFA==()
	{
		this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964956), Array.Empty<object>());
		if (!this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=.ContainsKey(this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()))
		{
			this.#=zmqoJehgOyVbAO83iYLqvZ9xEOjdz();
			return;
		}
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm$tWybb298uwhMVBRw== #=zm$tWybb298uwhMVBRw== = this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=[this.#=zpzrSpck=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()];
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = this.#=z48EqDrJggLl29t1RdOpA7iYdNvUP(#=zm$tWybb298uwhMVBRw==.#=zK5gF1KeGk_H_());
		if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== == null)
		{
			this.#=zpzrSpck=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964882), Array.Empty<object>());
			this.#=zmqoJehgOyVbAO83iYLqvZ9xEOjdz();
			return;
		}
		if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0)
		{
			#=zm$tWybb298uwhMVBRw==.#=zLkO3VEKrN2mHIZiieQ==(DateTime.MinValue);
		}
		else
		{
			#=zm$tWybb298uwhMVBRw==.#=zLkO3VEKrN2mHIZiieQ==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==());
		}
		#=zm$tWybb298uwhMVBRw==.#=zrW8jNzZ5MSGa(DateTime.MinValue);
	}

	// Token: 0x0600084D RID: 2125 RVA: 0x000429E8 File Offset: 0x00040BE8
	private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z48EqDrJggLl29t1RdOpA7iYdNvUP(int #=zbwrJfOI=)
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z4tAn7AX3LuhkbIOLQECdajU= #=z4tAn7AX3LuhkbIOLQECdajU= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z4tAn7AX3LuhkbIOLQECdajU=();
		#=z4tAn7AX3LuhkbIOLQECdajU=.#=zbwrJfOI= = #=zbwrJfOI=;
		#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= = null;
		UnitSquadCollection unitSquadCollection = null;
		if (#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zzfuUJztcOt9$(this.#=zSZPX3uYqrgEshnsYng==.#=zI0JHwt8spVuO()))
		{
			#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zRNqnDZfnmn0P(this.#=zSZPX3uYqrgEshnsYng==.#=zI0JHwt8spVuO());
		}
		else
		{
			unitSquadCollection = UnitSquadCollection.FromString(this.#=zSZPX3uYqrgEshnsYng==.#=zI0JHwt8spVuO(), null);
		}
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zVG1EPv1OUDdyLeGHGQ==.FindAll(new Predicate<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>(#=z4tAn7AX3LuhkbIOLQECdajU=.#=zHhrhKHUCx06fFG4O6JaGxOile$SqPL6dZw==));
		list.Sort(new Comparison<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=zBWkPviJoiRtzDnH2IZye2RvUfmxQyEhwyik2ZHo=));
		for (int i = 0; i < list.Count; i++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = list[i];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == this.#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == #=z4tAn7AX3LuhkbIOLQECdajU=.#=zbwrJfOI= && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1)
				{
					bool flag = false;
					double num = 0.0;
					for (int j = 0; j < #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Count; j++)
					{
						UnitSquad unitSquad = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD()[j];
						bool flag2;
						if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= != null)
						{
							flag2 = #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(unitSquad);
						}
						else
						{
							UnitSquad unitSquad2 = unitSquadCollection.Find(unitSquad.Type.Id);
							flag2 = (unitSquad2 != null && unitSquad2.Number >= unitSquad.Number);
						}
						if (!flag2)
						{
							flag = true;
							break;
						}
						num += unitSquad.Type.Consumption * (double)unitSquad.Number;
					}
					if (!flag && num >= 5.0)
					{
						return #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==;
					}
				}
				else if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0)
				{
					double num2 = 0.0;
					for (int k = 0; k < #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Count; k++)
					{
						UnitSquad unitSquad3 = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD()[k];
						bool flag3;
						if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= != null)
						{
							flag3 = #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(unitSquad3);
						}
						else
						{
							UnitSquad unitSquad4 = unitSquadCollection.Find(unitSquad3.Type.Id);
							flag3 = (unitSquad4 != null && unitSquad4.Number >= unitSquad3.Number);
						}
						if (flag3)
						{
							num2 += unitSquad3.Type.Consumption * (double)unitSquad3.Number;
						}
					}
					if (num2 >= 5.0)
					{
						return #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==;
					}
				}
			}
		}
		return null;
	}

	// Token: 0x0600084E RID: 2126 RVA: 0x00042C44 File Offset: 0x00040E44
	public void #=zyadZ79g=(#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=zcTyyNys=)
	{
		if (this.#=zV68dPxoDznd7 == null || this.#=zSZPX3uYqrgEshnsYng== == null)
		{
			this.#=zV68dPxoDznd7 = this.#=zpzrSpck=;
			this.#=zSZPX3uYqrgEshnsYng== = #=zcTyyNys=;
		}
		if (this.#=zSZPX3uYqrgEshnsYng== != #=zcTyyNys=)
		{
			#=zcTyyNys=.State = TaskStates.Cancelled;
			return;
		}
		switch (this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2())
		{
		case 0:
			this.#=zfFdSNAcT4cJU();
			break;
		case 1:
			this.#=zTXgFQCuFQILJHRLhrA==();
			break;
		case 2:
			this.#=z_OPYAfAhIkSMkvCmgJfAdHL96TxS();
			break;
		case 3:
			this.#=z3H0GtzYnVR9UMosmklj_1_MAyzSRZ02GsBUs15A=();
			break;
		}
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965086), Array.Empty<object>());
	}

	// Token: 0x0600084F RID: 2127 RVA: 0x00042CF8 File Offset: 0x00040EF8
	private void #=zfFdSNAcT4cJU()
	{
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965039), Array.Empty<object>());
		foreach (string text in this.#=zsH1oMGdy3Eph.Keys)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= item = this.#=zsH1oMGdy3Eph[text];
			if (this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Contains(text))
			{
				this.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY().Add(item);
				this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Remove(text);
			}
		}
		if (this.#=zsH1oMGdy3Eph.Count > 0)
		{
			this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966758), new object[]
			{
				this.#=zsH1oMGdy3Eph.Count
			});
			this.#=zsH1oMGdy3Eph.Clear();
		}
		if (this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Count > 0)
		{
			List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z8UZtCANlu8eL = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zol80P7TKoihZ();
			for (int i = 0; i < this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Count; i++)
			{
				this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==()[i]);
			}
		}
		if (this.#=zsH1oMGdy3Eph.Count == 0 && this.#=zSZPX3uYqrgEshnsYng==.#=zOre4g_jCK$pTWlVosQ==().Count == 0)
		{
			#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs = this.#=zSZPX3uYqrgEshnsYng==;
			int num = #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zBRFMv9W0kxd2();
			#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zFKyxw$KrE1EN(num + 1);
			this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966690), new object[]
			{
				this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2() + 1
			});
			this.#=zTXgFQCuFQILJHRLhrA==();
		}
	}

	// Token: 0x06000850 RID: 2128 RVA: 0x00042EDC File Offset: 0x000410DC
	private void #=zTXgFQCuFQILJHRLhrA==()
	{
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966896), Array.Empty<object>());
		List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> list = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zmNLpGNxrJ6Hu(this.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY(), this.#=zSZPX3uYqrgEshnsYng==.#=zi0WaUTfkdjJMIVEyAg==());
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966835), new object[]
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm0CcZODYHCXQ(this.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY(), this.#=zSZPX3uYqrgEshnsYng==.#=zi0WaUTfkdjJMIVEyAg==(), list)
		});
		this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().AddRange(list);
		this.#=zSZPX3uYqrgEshnsYng==.#=zDj2G6j0D0dzY().Clear();
		#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs = this.#=zSZPX3uYqrgEshnsYng==;
		int num = #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zBRFMv9W0kxd2();
		#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zFKyxw$KrE1EN(num + 1);
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966690), new object[]
		{
			this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2() + 1
		});
		this.#=z3Hgp_jHAieDMdpcnQ5ueiLjvEqva();
		this.#=z_OPYAfAhIkSMkvCmgJfAdHL96TxS();
	}

	// Token: 0x06000851 RID: 2129 RVA: 0x00042FFC File Offset: 0x000411FC
	private void #=z3Hgp_jHAieDMdpcnQ5ueiLjvEqva()
	{
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966799), Array.Empty<object>());
		if (this.#=zSZPX3uYqrgEshnsYng==.#=z3i_XNDE9Pwkn5y0M30IZRnJ145cm() > 0)
		{
			TaskBlackMarketParams #=zHbX7HNM= = new TaskBlackMarketParams(this.#=zSZPX3uYqrgEshnsYng==.#=z3i_XNDE9Pwkn5y0M30IZRnJ145cm(), false, 1, 0.0, true, false, false);
			List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zol80P7TKoihZ();
			for (int i = 0; i < this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Count; i++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zpEtMM0peHbYsZs_GCB7kiu4= #=zpEtMM0peHbYsZs_GCB7kiu4= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zpEtMM0peHbYsZs_GCB7kiu4=();
				#=zpEtMM0peHbYsZs_GCB7kiu4=.#=zlJSAjfPMVf41 = this;
				#=zpEtMM0peHbYsZs_GCB7kiu4=.#=zCsFfX0LBCUiE = this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==()[i];
				if (#=zpEtMM0peHbYsZs_GCB7kiu4=.#=zCsFfX0LBCUiE.Count > 1)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = list.Find(new Predicate<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(#=zpEtMM0peHbYsZs_GCB7kiu4=.#=zHSi7JMjcOmKg22yCMOE0wfXhpiEYQlZKIjoouXU=));
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(new #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(#=zHbX7HNM=, TaskSources.Manual, TaskSeverities.Urgent, TaskTypes.UseBlackMarketItem, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false));
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
					}
				}
			}
		}
	}

	// Token: 0x06000852 RID: 2130 RVA: 0x00043108 File Offset: 0x00041308
	private void #=z_OPYAfAhIkSMkvCmgJfAdHL96TxS()
	{
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966450), Array.Empty<object>());
		if (this.#=z$mUMMstCPPVgxiGZfMryi04= == null)
		{
			this.#=z$mUMMstCPPVgxiGZfMryi04= = new Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>();
			for (int i = 0; i < this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Count; i++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==()[i];
				for (int j = 1; j < #=zis3YTWs9V96i.Count; j++)
				{
					this.#=z$mUMMstCPPVgxiGZfMryi04=.Add(#=zis3YTWs9V96i[j].#=zCCvotbi$42tS(), #=zis3YTWs9V96i[0]);
				}
			}
			this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966643), new object[]
			{
				this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Count
			});
		}
		if (this.#=z$mUMMstCPPVgxiGZfMryi04=.Count > 0)
		{
			List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z8UZtCANlu8eL = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zol80P7TKoihZ();
			foreach (string #=z6Jj71Ypaz6TggTjcbg== in this.#=z$mUMMstCPPVgxiGZfMryi04=.Keys)
			{
				this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, #=z6Jj71Ypaz6TggTjcbg==);
			}
			this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966597), new object[]
			{
				this.#=z$mUMMstCPPVgxiGZfMryi04=.Count
			});
			return;
		}
		#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs = this.#=zSZPX3uYqrgEshnsYng==;
		int num = #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zBRFMv9W0kxd2();
		#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zFKyxw$KrE1EN(num + 1);
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966266), new object[]
		{
			this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2() + 1
		});
	}

	// Token: 0x06000853 RID: 2131 RVA: 0x000432F8 File Offset: 0x000414F8
	private void #=z3H0GtzYnVR9UMosmklj_1_MAyzSRZ02GsBUs15A=()
	{
		this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966219), Array.Empty<object>());
		if (this.#=z$mUMMstCPPVgxiGZfMryi04= == null)
		{
			this.#=z_OPYAfAhIkSMkvCmgJfAdHL96TxS();
		}
		bool flag = true;
		List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z8UZtCANlu8eL = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zol80P7TKoihZ();
		for (int i = 0; i < this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==().Count; i++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = this.#=zSZPX3uYqrgEshnsYng==.#=z9lg8rYEayWFsMkjAqA==()[i];
			for (int j = 1; j < #=zis3YTWs9V96i.Count; j++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = #=zis3YTWs9V96i[j];
				if (!this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=.ContainsKey(#=zBbLKsV0=.#=zCCvotbi$42tS()))
				{
					this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, #=zBbLKsV0=.#=zCCvotbi$42tS());
					flag = false;
				}
				else
				{
					#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm$tWybb298uwhMVBRw== #=zm$tWybb298uwhMVBRw== = this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=[#=zBbLKsV0=.#=zCCvotbi$42tS()];
					if (!#=zm$tWybb298uwhMVBRw==.#=zDqA$IszsnQU58WBPkA==())
					{
						if (!#=zm$tWybb298uwhMVBRw==.#=zE6NlIzUF$OZQDXJwPw==())
						{
							Task task = this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, #=zBbLKsV0=.#=zCCvotbi$42tS(), #=zm$tWybb298uwhMVBRw==.#=zL4D9WC8RTH921DofgQ==() + TimeSpan.FromSeconds(15.0));
							#=zm$tWybb298uwhMVBRw==.#=zrW8jNzZ5MSGa(task.ExecutionTime);
						}
						else if (#=zm$tWybb298uwhMVBRw==.#=z$jARfXJ2G0xh() < DateTime.Now - TimeSpan.FromMinutes(3.0))
						{
							Task task2 = this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, #=zBbLKsV0=.#=zCCvotbi$42tS(), DateTime.Now);
							#=zm$tWybb298uwhMVBRw==.#=zrW8jNzZ5MSGa(task2.ExecutionTime);
						}
						flag = false;
					}
				}
			}
		}
		if (flag)
		{
			#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs = this.#=zSZPX3uYqrgEshnsYng==;
			int num = #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zBRFMv9W0kxd2();
			#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zFKyxw$KrE1EN(num + 1);
			this.#=zV68dPxoDznd7.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966690), new object[]
			{
				this.#=zSZPX3uYqrgEshnsYng==.#=zBRFMv9W0kxd2() + 1
			});
		}
	}

	// Token: 0x06000854 RID: 2132 RVA: 0x000434D0 File Offset: 0x000416D0
	private Task #=zApR0nGmTJ1cbK0ZpZw==(List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z8UZtCANlu8eL, string #=z6Jj71Ypaz6TggTjcbg==)
	{
		return this.#=zApR0nGmTJ1cbK0ZpZw==(#=z8UZtCANlu8eL, #=z6Jj71Ypaz6TggTjcbg==, DateTime.Now);
	}

	// Token: 0x06000855 RID: 2133 RVA: 0x000434E0 File Offset: 0x000416E0
	private Task #=zApR0nGmTJ1cbK0ZpZw==(List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z8UZtCANlu8eL, string #=z6Jj71Ypaz6TggTjcbg==, DateTime #=zxSBcx18=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=z8UZtCANlu8eL.Find(new Predicate<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zRqJcCAGO_Y69urjFj7O66VU=
		{
			#=zlJSAjfPMVf41 = this,
			#=z6Jj71Ypaz6TggTjcbg== = #=z6Jj71Ypaz6TggTjcbg==
		}.#=zMt7uCWXOqJ_icIN_EAqccUs=));
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
		{
			Task task = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().#=zEh7CJ2RYceMs(TaskTypes.MassAttackExecute);
			if (task == null)
			{
				task = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.ManualNotSavable, TaskSeverities.Urgent, TaskTypes.MassAttackExecute, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(task);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
			}
			return task;
		}
		return null;
	}

	// Token: 0x06000856 RID: 2134 RVA: 0x00043558 File Offset: 0x00041758
	public static void #=zCCgFSA0=(string #=z40sk5mc=, bool #=zGB4gUFgD1yZBkVSpIA==, string #=zQI5IZCs=, int #=zk_4E_3muViYC, List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zJe6TLpo=, DateTime #=z9iiP2tA=, bool #=zzraSH0KDs8t4Q_hMLA==, #=zUYB79z3coxPKjfLVGQT58nQo28R2ixgZps$KOFU= #=zpf7HkwmgKCtMzCKAZA==, string #=zOoGk4c6$lQd5wt9KPajdQGDFlVV7)
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z0i9ycwWPUqnk11MToLZ5aO4= #=z0i9ycwWPUqnk11MToLZ5aO4= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z0i9ycwWPUqnk11MToLZ5aO4=();
		#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zSZPX3uYqrgEshnsYng==;
		if (#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966158), Array.Empty<object>());
		}
		#=z0i9ycwWPUqnk11MToLZ5aO4=.#=zLeeSKrg= = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zV68dPxoDznd7.#=zYgvZuBwR$a1C();
		for (int i = 0; i < #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=z9lg8rYEayWFsMkjAqA==().Count; i++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zUI7y$nA9wN4Y7ZcWivYuYWI= #=zUI7y$nA9wN4Y7ZcWivYuYWI= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zUI7y$nA9wN4Y7ZcWivYuYWI=();
			#=zUI7y$nA9wN4Y7ZcWivYuYWI=.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg= = #=z0i9ycwWPUqnk11MToLZ5aO4=;
			#=zUI7y$nA9wN4Y7ZcWivYuYWI=.#=zCsFfX0LBCUiE = #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=z9lg8rYEayWFsMkjAqA==()[i];
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zJe6TLpo=.Find(new Predicate<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(#=zUI7y$nA9wN4Y7ZcWivYuYWI=.#=zAatYdlHivk5vBfc2$A==));
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
			{
				TaskSendUnitTypes #=zPJCAPrY= = #=zGB4gUFgD1yZBkVSpIA== ? TaskSendUnitTypes.AttackCapital : TaskSendUnitTypes.Siege;
				List<int> list = new List<int>();
				for (int j = 1; j < #=zUI7y$nA9wN4Y7ZcWivYuYWI=.#=zCsFfX0LBCUiE.Count; j++)
				{
					list.Add(#=zUI7y$nA9wN4Y7ZcWivYuYWI=.#=zCsFfX0LBCUiE[j].#=zMuFMjGQ=());
				}
				Task task;
				if (list.Count > 0)
				{
					task = new #=zwd1fHYOJrNrsOf$gElMHXmuGupWZfcbWIJcB8gM=(#=z9iiP2tA=, #=zPJCAPrY=, #=z40sk5mc=, #=zQI5IZCs=, #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zI0JHwt8spVuO(), list, #=zk_4E_3muViYC, #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zi0WaUTfkdjJMIVEyAg==());
				}
				else
				{
					task = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSeverities.Urgent, #=z9iiP2tA=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false, #=zPJCAPrY=, #=z40sk5mc=, #=zQI5IZCs=, #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zI0JHwt8spVuO(), #=zk_4E_3muViYC, #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zi0WaUTfkdjJMIVEyAg==());
				}
				if (#=zzraSH0KDs8t4Q_hMLA==)
				{
					task = new #=zsT_LxdQQnExU7EM$eDJVWZpjrnrsynAGc8Ltbl0=((#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==)task, #=zpf7HkwmgKCtMzCKAZA==, #=zOoGk4c6$lQd5wt9KPajdQGDFlVV7);
				}
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(task);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
			}
		}
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zUXevGubU4Zg5();
	}

	// Token: 0x06000857 RID: 2135 RVA: 0x000436C4 File Offset: 0x000418C4
	public static void #=zesQCEYw=()
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=().#=zUXevGubU4Zg5();
	}

	// Token: 0x06000858 RID: 2136 RVA: 0x000436D0 File Offset: 0x000418D0
	private void #=zUXevGubU4Zg5()
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zV68dPxoDznd7;
		if (this.#=zSZPX3uYqrgEshnsYng== != null)
		{
			this.#=zSZPX3uYqrgEshnsYng==.State = TaskStates.Cancelled;
		}
		this.#=zgI2P7ZrELaRz = true;
		this.#=zV68dPxoDznd7 = null;
		this.#=zSZPX3uYqrgEshnsYng== = null;
		this.#=zsH1oMGdy3Eph.Clear();
		this.#=z$mUMMstCPPVgxiGZfMryi04= = null;
		this.#=z4ZAGqp_z8K5R6k$SsSWZ3hc=.Clear();
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966368), Array.Empty<object>());
		}
	}

	// Token: 0x06000859 RID: 2137 RVA: 0x00043754 File Offset: 0x00041954
	public static List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z49efLN4h2B_r()
	{
		object obj = JSONManager.DeserializeData(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966340));
		object[] array = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237));
		List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> list = new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>();
		for (int i = 0; i < array.Length; i++)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)array[i];
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=();
			#=zBbLKsV0=.#=zbsxKkj4=(i);
			#=zBbLKsV0=.#=ze8TQhOAtefck(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168) + i.ToString());
			#=zBbLKsV0=.#=zwXKUV2c=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315) + i.ToString());
			#=zBbLKsV0=.#=zAsCgbAN02olKpq2GjA==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0) + 1);
			#=zBbLKsV0=.#=z6AhOmwNDely78tSumg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085715) + (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0) + 1).ToString());
			#=zBbLKsV0=.#=zL1nSSuED6_G9CQfsch1Gzg0=((JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0) == 1) ? 30 : 80);
			#=zBbLKsV0=.#=zHD9M6IxBLboIezSsHQ==(0);
			#=zBbLKsV0=.#=z2WdNm_CMtqBR6ukyUw==(0);
			#=zBbLKsV0=.#=zLNM6_FpNs$Ws(new UnitSquadCollection
			{
				new UnitSquad(1, JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0))
			});
			#=zBbLKsV0=.#=zQs2eT6ebSpBF(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= item = #=zBbLKsV0=;
			list.Add(item);
		}
		int @int = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0);
		return #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zmNLpGNxrJ6Hu(list, @int);
	}

	// Token: 0x0600085A RID: 2138 RVA: 0x000438C8 File Offset: 0x00041AC8
	private static List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=zmNLpGNxrJ6Hu(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zEhGRLRSSQTM3nxmPHQ==, int #=zShL45qY=)
	{
		if (#=zShL45qY= <= 0)
		{
			#=zShL45qY= = int.MaxValue;
		}
		Dictionary<int, List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>> dictionary = new Dictionary<int, List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>>();
		for (int i = 0; i < #=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = #=zEhGRLRSSQTM3nxmPHQ==[i];
			if (#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==() > 0 && #=zBbLKsV0=.#=zuPMhw87glikS() >= 5)
			{
				if (!dictionary.ContainsKey(#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==()))
				{
					dictionary.Add(#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==(), new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>());
				}
				dictionary[#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==()].Add(#=zBbLKsV0=);
			}
		}
		List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> list = new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i>();
		foreach (List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zEhGRLRSSQTM3nxmPHQ==2 in dictionary.Values)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zDvhqbts1t$ax #=zDvhqbts1t$ax = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=ztgpN7vj3Q0PqYD6Z2QN_yEQ=(#=zEhGRLRSSQTM3nxmPHQ==2, #=zShL45qY=);
			for (int j = 0; j < #=zDvhqbts1t$ax.#=z9lg8rYEayWFsMkjAqA==().Count; j++)
			{
				list.Add(#=zDvhqbts1t$ax.#=z9lg8rYEayWFsMkjAqA==()[j].#=z87clB5Sy7fqe());
			}
			for (int k = 0; k < #=zDvhqbts1t$ax.#=z8J0sZsr1gCw7Cxw4RQ==().Count; k++)
			{
				list.Add(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=[]
				{
					#=zDvhqbts1t$ax.#=z8J0sZsr1gCw7Cxw4RQ==()[k]
				}));
			}
		}
		return list;
	}

	// Token: 0x0600085B RID: 2139 RVA: 0x00043A04 File Offset: 0x00041C04
	private static #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zDvhqbts1t$ax #=ztgpN7vj3Q0PqYD6Z2QN_yEQ=(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zEhGRLRSSQTM3nxmPHQ==, int #=zShL45qY=)
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zDvhqbts1t$ax #=zDvhqbts1t$ax = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zDvhqbts1t$ax();
		#=zEhGRLRSSQTM3nxmPHQ==.Sort(new Comparison<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=z4wMVHqGh6QXULZL4_JBP_$w_DT9SrK2YWQ==));
		for (int i = 0; i < #=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zhoOF5s8= = #=zEhGRLRSSQTM3nxmPHQ==[i];
			List<int> list = new List<int>();
			while (#=zhoOF5s8= != null)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zXTZllgIJvROr(#=zhoOF5s8=, #=zDvhqbts1t$ax, #=zShL45qY=);
				if (#=zBbLKsV0= != null)
				{
					if (list.Contains(#=zBbLKsV0=.#=zMuFMjGQ=()))
					{
						throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908965925), new object[]
						{
							#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm0CcZODYHCXQ(#=zEhGRLRSSQTM3nxmPHQ==, #=zShL45qY=, null)
						});
					}
					list.Add(#=zBbLKsV0=.#=zMuFMjGQ=());
				}
				#=zhoOF5s8= = #=zBbLKsV0=;
			}
		}
		return #=zDvhqbts1t$ax;
	}

	// Token: 0x0600085C RID: 2140 RVA: 0x00043AB0 File Offset: 0x00041CB0
	private static #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zXTZllgIJvROr(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zhoOF5s8=, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zDvhqbts1t$ax #=zAVDks_MrkWZf9hzNxijP8K0=, int #=zShL45qY=)
	{
		for (int i = 0; i < #=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==().Count; i++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = #=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==()[i];
			int num = Enumerable.Sum<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zis3YTWs9V96i, new Func<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=, int>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=znMKp4PrO2VPldCVPGwj6_bc=));
			if (#=zis3YTWs9V96i.Count < 3 && num + #=zhoOF5s8=.#=zuPMhw87glikS() <= #=zShL45qY=)
			{
				#=zis3YTWs9V96i.Add(#=zhoOF5s8=);
				return null;
			}
			for (int j = 0; j < #=zis3YTWs9V96i.Count; j++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zbNDPf$Hd8gYrHkOOd7T_3VE= #=zbNDPf$Hd8gYrHkOOd7T_3VE= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zbNDPf$Hd8gYrHkOOd7T_3VE=();
				#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zZJFL8xQY3Vp51xEzHw== = #=zis3YTWs9V96i[j];
				if (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zZJFL8xQY3Vp51xEzHw==.#=zuPMhw87glikS() < #=zhoOF5s8=.#=zuPMhw87glikS() && num - #=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zZJFL8xQY3Vp51xEzHw==.#=zuPMhw87glikS() + #=zhoOF5s8=.#=zuPMhw87glikS() <= #=zShL45qY= && (#=zhoOF5s8=.#=zP3ojUl2Dti9YfccUMg==() || #=zis3YTWs9V96i.Find(new Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zpK7yULQLdRddKUw5$g==)) != null))
				{
					#=zis3YTWs9V96i.Remove(#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zZJFL8xQY3Vp51xEzHw==);
					#=zis3YTWs9V96i.Add(#=zhoOF5s8=);
					return #=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zZJFL8xQY3Vp51xEzHw==;
				}
			}
		}
		if (#=zhoOF5s8=.#=zP3ojUl2Dti9YfccUMg==())
		{
			#=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==().Add(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=[]
			{
				#=zhoOF5s8=
			}));
			return null;
		}
		for (int k = #=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==().Count - 1; k >= 0; k--)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i2 = #=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==()[k];
			List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> list = #=zis3YTWs9V96i2.FindAll(new Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=zDJnu4Nxp7psgiT0k2DHVAOg=));
			if (list.Count >= 2)
			{
				list.Sort(new Comparison<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=zhhVzgIRysSsnU_NEZP7sQpM=));
				int num2 = Enumerable.Sum<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>(#=zis3YTWs9V96i2, new Func<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=, int>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=.#=zLkw0NRU=.#=z3lL2s404cCTvRwVvqcPxnbE=));
				for (int l = 0; l < list.Count; l++)
				{
					#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = list[l];
					if (num2 - #=zBbLKsV0=.#=zuPMhw87glikS() + #=zhoOF5s8=.#=zuPMhw87glikS() <= #=zShL45qY=)
					{
						#=zis3YTWs9V96i2.Remove(#=zBbLKsV0=);
						#=zis3YTWs9V96i2.Add(#=zhoOF5s8=);
						#=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==().Add(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=[]
						{
							#=zBbLKsV0=
						}));
						return null;
					}
				}
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0=2 = list[0];
				#=zis3YTWs9V96i2.Remove(#=zBbLKsV0=2);
				#=zAVDks_MrkWZf9hzNxijP8K0=.#=z9lg8rYEayWFsMkjAqA==().Add(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i(new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=[]
				{
					#=zhoOF5s8=,
					#=zBbLKsV0=2
				}));
				return null;
			}
		}
		#=zAVDks_MrkWZf9hzNxijP8K0=.#=z8J0sZsr1gCw7Cxw4RQ==().Add(#=zhoOF5s8=);
		return null;
	}

	// Token: 0x0600085D RID: 2141 RVA: 0x00043D30 File Offset: 0x00041F30
	public static string #=zm0CcZODYHCXQ(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zhoDKkByqLHZR, int #=zShL45qY=, List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z_jCo8l$DvHP_)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		List<int> list = new List<int>();
		if (#=zhoDKkByqLHZR != null)
		{
			object[] array = new object[#=zhoDKkByqLHZR.Count];
			for (int i = 0; i < #=zhoDKkByqLHZR.Count; i++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = #=zhoDKkByqLHZR[i];
				if (!list.Contains(#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==()))
				{
					list.Add(#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==());
				}
				array[i] = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
						(#=zBbLKsV0=.#=zP3ojUl2Dti9YfccUMg==() > false) ? 1 : 0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						#=zBbLKsV0=.#=zuPMhw87glikS()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						list.IndexOf(#=zBbLKsV0=.#=zO1FX6YkNZlqlvFZqJg==())
					}
				};
			}
			dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), array);
		}
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), #=zShL45qY=);
		if (#=z_jCo8l$DvHP_ != null)
		{
			object[] array2 = new object[#=z_jCo8l$DvHP_.Count];
			for (int j = 0; j < #=z_jCo8l$DvHP_.Count; j++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = #=z_jCo8l$DvHP_[j];
				object[] array3 = new object[#=zis3YTWs9V96i.Count];
				for (int k = 0; k < #=zis3YTWs9V96i.Count; k++)
				{
					#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0=2 = #=zis3YTWs9V96i[k];
					array3[k] = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
							(#=zBbLKsV0=2.#=zP3ojUl2Dti9YfccUMg==() > false) ? 1 : 0
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							#=zBbLKsV0=2.#=zuPMhw87glikS()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
							list.IndexOf(#=zBbLKsV0=2.#=zO1FX6YkNZlqlvFZqJg==())
						}
					};
				}
				array2[j] = array3;
			}
			dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), array2);
		}
		return JSONManager.SerializeData(dictionary);
	}

	// Token: 0x040004B5 RID: 1205
	private static #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zOAzeRO$HqsMN = null;

	// Token: 0x040004B6 RID: 1206
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x040004B7 RID: 1207
	private bool #=zgI2P7ZrELaRz;

	// Token: 0x040004B8 RID: 1208
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zV68dPxoDznd7;

	// Token: 0x040004B9 RID: 1209
	private #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs #=zSZPX3uYqrgEshnsYng==;

	// Token: 0x040004BA RID: 1210
	private Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zsH1oMGdy3Eph;

	// Token: 0x040004BB RID: 1211
	private Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=z$mUMMstCPPVgxiGZfMryi04=;

	// Token: 0x040004BC RID: 1212
	private Dictionary<string, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zm$tWybb298uwhMVBRw==> #=z4ZAGqp_z8K5R6k$SsSWZ3hc=;

	// Token: 0x040004BD RID: 1213
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zpzrSpck=;

	// Token: 0x040004BE RID: 1214
	private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=;

	// Token: 0x040004BF RID: 1215
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x040004C0 RID: 1216
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x040004C1 RID: 1217
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x040004C2 RID: 1218
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x040004C3 RID: 1219
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x040004C4 RID: 1220
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x0200013B RID: 315
	private sealed class #=z0i9ycwWPUqnk11MToLZ5aO4=
	{
		// Token: 0x040004C5 RID: 1221
		public int #=zLeeSKrg=;
	}

	// Token: 0x0200013C RID: 316
	private sealed class #=z4tAn7AX3LuhkbIOLQECdajU=
	{
		// Token: 0x06000860 RID: 2144 RVA: 0x00043F20 File Offset: 0x00042120
		internal bool #=zHhrhKHUCx06fFG4O6JaGxOile$SqPL6dZw==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zK5gF1KeGk_H_() == this.#=zbwrJfOI=;
		}

		// Token: 0x040004C6 RID: 1222
		public int #=zbwrJfOI=;
	}

	// Token: 0x0200013D RID: 317
	internal sealed class #=zBbLKsV0=
	{
		// Token: 0x06000861 RID: 2145 RVA: 0x00043F30 File Offset: 0x00042130
		public #=zBbLKsV0=()
		{
		}

		// Token: 0x06000862 RID: 2146 RVA: 0x00043F38 File Offset: 0x00042138
		public #=zBbLKsV0=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, UnitSquadCollection #=zZ0NLbUc=)
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=z8StzeqE=.#=zjV_wsuvJ0R_B();
			this.#=zbsxKkj4=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=());
			this.#=ze8TQhOAtefck(#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe());
			this.#=zwXKUV2c=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=());
			this.#=zAsCgbAN02olKpq2GjA==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==());
			this.#=z6AhOmwNDely78tSumg==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==());
			this.#=zL1nSSuED6_G9CQfsch1Gzg0=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zw10jEpGax3aM3DGZDfjgXOQ=());
			this.#=zHD9M6IxBLboIezSsHQ==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zfTB62qendhk_VEy8rw==());
			this.#=z2WdNm_CMtqBR6ukyUw==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zY0soxphmGIACbOHy6A==());
			this.#=zLNM6_FpNs$Ws(#=zZ0NLbUc=);
			this.#=zQs2eT6ebSpBF((int)Math.Ceiling(Enumerable.Sum<UnitSquad>(this.#=zDy8wm$yKq8XD(), new Func<UnitSquad, double>(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=.#=zyDNvciU=.#=zLkw0NRU=.#=zYhT5s55Z2bWvl78HkDXmAzM=))));
		}

		// Token: 0x06000863 RID: 2147 RVA: 0x00043FF4 File Offset: 0x000421F4
		public int #=zMuFMjGQ=()
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}

		// Token: 0x06000864 RID: 2148 RVA: 0x00043FFC File Offset: 0x000421FC
		public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000865 RID: 2149 RVA: 0x00044008 File Offset: 0x00042208
		public string #=zCCvotbi$42tS()
		{
			return this.#=zPkv_E4Wq237BeckNiw==;
		}

		// Token: 0x06000866 RID: 2150 RVA: 0x00044010 File Offset: 0x00042210
		public void #=ze8TQhOAtefck(string #=z$Ib9gYQ=)
		{
			this.#=zPkv_E4Wq237BeckNiw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000867 RID: 2151 RVA: 0x0004401C File Offset: 0x0004221C
		public string #=zkfqcY3I=()
		{
			return this.#=zWd4PtJyWoTk_ZThs2A==;
		}

		// Token: 0x06000868 RID: 2152 RVA: 0x00044024 File Offset: 0x00042224
		public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
		{
			this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000869 RID: 2153 RVA: 0x00044030 File Offset: 0x00042230
		public int #=zO1FX6YkNZlqlvFZqJg==()
		{
			return this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;
		}

		// Token: 0x0600086A RID: 2154 RVA: 0x00044038 File Offset: 0x00042238
		public void #=zAsCgbAN02olKpq2GjA==(int #=z$Ib9gYQ=)
		{
			this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk = #=z$Ib9gYQ=;
		}

		// Token: 0x0600086B RID: 2155 RVA: 0x00044044 File Offset: 0x00042244
		public string #=zj661vGqZTMsoJ4JrPg==()
		{
			return this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1;
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x0004404C File Offset: 0x0004224C
		public void #=z6AhOmwNDely78tSumg==(string #=z$Ib9gYQ=)
		{
			this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1 = #=z$Ib9gYQ=;
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x00044058 File Offset: 0x00042258
		public int #=zw10jEpGax3aM3DGZDfjgXOQ=()
		{
			return this.#=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe;
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x00044060 File Offset: 0x00042260
		public void #=zL1nSSuED6_G9CQfsch1Gzg0=(int #=z$Ib9gYQ=)
		{
			this.#=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe = #=z$Ib9gYQ=;
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x0004406C File Offset: 0x0004226C
		public int #=zfTB62qendhk_VEy8rw==()
		{
			return this.#=zuCoBS22$SHwioNCsSm1KoiA=;
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x00044074 File Offset: 0x00042274
		public void #=zHD9M6IxBLboIezSsHQ==(int #=z$Ib9gYQ=)
		{
			this.#=zuCoBS22$SHwioNCsSm1KoiA= = #=z$Ib9gYQ=;
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x00044080 File Offset: 0x00042280
		public int #=zY0soxphmGIACbOHy6A==()
		{
			return this.#=zAZaEN2rHjtRHI7RjIU6YTJk=;
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00044088 File Offset: 0x00042288
		public void #=z2WdNm_CMtqBR6ukyUw==(int #=z$Ib9gYQ=)
		{
			this.#=zAZaEN2rHjtRHI7RjIU6YTJk= = #=z$Ib9gYQ=;
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00044094 File Offset: 0x00042294
		public UnitSquadCollection #=zDy8wm$yKq8XD()
		{
			return this.#=zH68$xslqIYbV8rfxLg==;
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x0004409C File Offset: 0x0004229C
		public void #=zLNM6_FpNs$Ws(UnitSquadCollection #=z$Ib9gYQ=)
		{
			this.#=zH68$xslqIYbV8rfxLg== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000875 RID: 2165 RVA: 0x000440A8 File Offset: 0x000422A8
		public bool #=zP3ojUl2Dti9YfccUMg==()
		{
			return this.#=zw10jEpGax3aM3DGZDfjgXOQ=() <= 40;
		}

		// Token: 0x06000876 RID: 2166 RVA: 0x000440B8 File Offset: 0x000422B8
		public int #=zuPMhw87glikS()
		{
			return this.#=zyPmXvh8R0Kr0FkU7hMOmJGQ=;
		}

		// Token: 0x06000877 RID: 2167 RVA: 0x000440C0 File Offset: 0x000422C0
		public void #=zQs2eT6ebSpBF(int #=z$Ib9gYQ=)
		{
			this.#=zyPmXvh8R0Kr0FkU7hMOmJGQ= = #=z$Ib9gYQ=;
		}

		// Token: 0x040004C7 RID: 1223
		private int #=zdw4aIlzRxu5LWjlGFw==;

		// Token: 0x040004C8 RID: 1224
		private string #=zPkv_E4Wq237BeckNiw==;

		// Token: 0x040004C9 RID: 1225
		private string #=zWd4PtJyWoTk_ZThs2A==;

		// Token: 0x040004CA RID: 1226
		private int #=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;

		// Token: 0x040004CB RID: 1227
		private string #=zmNuFeIk1PExEPxrcVomfAICh_vk1;

		// Token: 0x040004CC RID: 1228
		private int #=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe;

		// Token: 0x040004CD RID: 1229
		private int #=zuCoBS22$SHwioNCsSm1KoiA=;

		// Token: 0x040004CE RID: 1230
		private int #=zAZaEN2rHjtRHI7RjIU6YTJk=;

		// Token: 0x040004CF RID: 1231
		private UnitSquadCollection #=zH68$xslqIYbV8rfxLg==;

		// Token: 0x040004D0 RID: 1232
		private int #=zyPmXvh8R0Kr0FkU7hMOmJGQ=;

		// Token: 0x0200013E RID: 318
		[Serializable]
		private sealed class #=zyDNvciU=
		{
			// Token: 0x0600087A RID: 2170 RVA: 0x000440E0 File Offset: 0x000422E0
			internal double #=zYhT5s55Z2bWvl78HkDXmAzM=(UnitSquad #=zQrqFdos=)
			{
				return #=zQrqFdos=.Type.Consumption * (double)#=zQrqFdos=.Number;
			}

			// Token: 0x040004D1 RID: 1233
			public static readonly #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=.#=zyDNvciU= #=zLkw0NRU= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=.#=zyDNvciU=();

			// Token: 0x040004D2 RID: 1234
			public static Func<UnitSquad, double> #=za6TefQl$OCVfRyWDeA==;
		}
	}

	// Token: 0x0200013F RID: 319
	internal sealed class #=zDvhqbts1t$ax
	{
		// Token: 0x0600087B RID: 2171 RVA: 0x000440F8 File Offset: 0x000422F8
		public #=zDvhqbts1t$ax()
		{
			this.#=zKrwD_u4diGwvCHJVdQ==(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i>());
			this.#=z7Oxr_Sp05RN9rfzrLg==(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>());
		}

		// Token: 0x0600087C RID: 2172 RVA: 0x00044118 File Offset: 0x00042318
		public List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z9lg8rYEayWFsMkjAqA==()
		{
			return this.#=zeUFISYl60Q_JSAoZfA2$CXU=;
		}

		// Token: 0x0600087D RID: 2173 RVA: 0x00044120 File Offset: 0x00042320
		private void #=zKrwD_u4diGwvCHJVdQ==(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z$Ib9gYQ=)
		{
			this.#=zeUFISYl60Q_JSAoZfA2$CXU= = #=z$Ib9gYQ=;
		}

		// Token: 0x0600087E RID: 2174 RVA: 0x0004412C File Offset: 0x0004232C
		public List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=z8J0sZsr1gCw7Cxw4RQ==()
		{
			return this.#=zQq0C6IYO9ahWliPMyD$PNNY=;
		}

		// Token: 0x0600087F RID: 2175 RVA: 0x00044134 File Offset: 0x00042334
		private void #=z7Oxr_Sp05RN9rfzrLg==(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=z$Ib9gYQ=)
		{
			this.#=zQq0C6IYO9ahWliPMyD$PNNY= = #=z$Ib9gYQ=;
		}

		// Token: 0x040004D3 RID: 1235
		private List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=zeUFISYl60Q_JSAoZfA2$CXU=;

		// Token: 0x040004D4 RID: 1236
		private List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zQq0C6IYO9ahWliPMyD$PNNY=;
	}

	// Token: 0x02000140 RID: 320
	private sealed class #=zH6bes6nyzqqTevjbM$5ga2c=
	{
		// Token: 0x06000881 RID: 2177 RVA: 0x00044148 File Offset: 0x00042348
		internal bool #=zoMggb9ZQEqG6Mxjw6LFb6aE=(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zCCvotbi$42tS() == this.#=zCsFfX0LBCUiE[this.#=zH2f5zJg=].#=zCCvotbi$42tS();
		}

		// Token: 0x040004D5 RID: 1237
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zCsFfX0LBCUiE;

		// Token: 0x040004D6 RID: 1238
		public int #=zH2f5zJg=;

		// Token: 0x040004D7 RID: 1239
		public Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zxwmV42lQK4CR;
	}

	// Token: 0x02000141 RID: 321
	private sealed class #=zRqJcCAGO_Y69urjFj7O66VU=
	{
		// Token: 0x06000883 RID: 2179 RVA: 0x00044174 File Offset: 0x00042374
		internal bool #=zMt7uCWXOqJ_icIN_EAqccUs=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zYgvZuBwR$a1C() == this.#=zlJSAjfPMVf41.#=zV68dPxoDznd7.#=zYgvZuBwR$a1C() && #=zQrqFdos=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe() == this.#=z6Jj71Ypaz6TggTjcbg==;
		}

		// Token: 0x040004D8 RID: 1240
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zlJSAjfPMVf41;

		// Token: 0x040004D9 RID: 1241
		public string #=z6Jj71Ypaz6TggTjcbg==;
	}

	// Token: 0x02000142 RID: 322
	private sealed class #=zUI7y$nA9wN4Y7ZcWivYuYWI=
	{
		// Token: 0x06000885 RID: 2181 RVA: 0x000441B0 File Offset: 0x000423B0
		internal bool #=zAatYdlHivk5vBfc2$A==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zYgvZuBwR$a1C() == this.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=.#=zLeeSKrg= && #=zQrqFdos=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe() == this.#=zCsFfX0LBCUiE[0].#=zCCvotbi$42tS();
		}

		// Token: 0x040004DA RID: 1242
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zCsFfX0LBCUiE;

		// Token: 0x040004DB RID: 1243
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=z0i9ycwWPUqnk11MToLZ5aO4= #=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=;
	}

	// Token: 0x02000143 RID: 323
	private sealed class #=zbNDPf$Hd8gYrHkOOd7T_3VE=
	{
		// Token: 0x06000887 RID: 2183 RVA: 0x000441F0 File Offset: 0x000423F0
		internal bool #=zpK7yULQLdRddKUw5$g==(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zP3ojUl2Dti9YfccUMg==() && #=zQrqFdos=.#=zMuFMjGQ=() != this.#=zZJFL8xQY3Vp51xEzHw==.#=zMuFMjGQ=();
		}

		// Token: 0x040004DC RID: 1244
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zZJFL8xQY3Vp51xEzHw==;
	}

	// Token: 0x02000144 RID: 324
	internal sealed class #=zis3YTWs9V96i : List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>
	{
		// Token: 0x06000888 RID: 2184 RVA: 0x00044214 File Offset: 0x00042414
		public #=zis3YTWs9V96i(params #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=[] #=zEhGRLRSSQTM3nxmPHQ==)
		{
			for (int i = 0; i < #=zEhGRLRSSQTM3nxmPHQ==.Length; i++)
			{
				base.Add(#=zEhGRLRSSQTM3nxmPHQ==[i]);
			}
		}

		// Token: 0x06000889 RID: 2185 RVA: 0x00044240 File Offset: 0x00042440
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=z87clB5Sy7fqe()
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = null;
			double num = 1000000000.0;
			for (int i = 0; i < base.Count; i++)
			{
				#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0=2 = base[i];
				if (#=zBbLKsV0=2.#=zP3ojUl2Dti9YfccUMg==())
				{
					double num2 = 0.0;
					for (int j = 0; j < base.Count; j++)
					{
						if (j != i)
						{
							#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0=3 = base[j];
							double num3 = Math.Sqrt(Math.Pow((double)(#=zBbLKsV0=2.#=zfTB62qendhk_VEy8rw==() - #=zBbLKsV0=3.#=zfTB62qendhk_VEy8rw==()), 2.0) + Math.Pow((double)(#=zBbLKsV0=2.#=zY0soxphmGIACbOHy6A==() - #=zBbLKsV0=3.#=zY0soxphmGIACbOHy6A==()), 2.0));
							if (num3 > num2)
							{
								num2 = num3;
							}
						}
					}
					if (num2 < num)
					{
						#=zBbLKsV0= = #=zBbLKsV0=2;
						num = num2;
					}
				}
			}
			if (#=zBbLKsV0= != null)
			{
				base.Remove(#=zBbLKsV0=);
				base.Insert(0, #=zBbLKsV0=);
			}
			return this;
		}

		// Token: 0x0600088A RID: 2186 RVA: 0x0004431C File Offset: 0x0004251C
		public string #=zkXSnibl91hNL()
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < base.Count; i++)
			{
				if (i > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(base[i].#=zkfqcY3I=());
			}
			return stringBuilder.ToString();
		}
	}

	// Token: 0x02000145 RID: 325
	internal sealed class #=zm$tWybb298uwhMVBRw==
	{
		// Token: 0x0600088B RID: 2187 RVA: 0x00044370 File Offset: 0x00042570
		public #=zm$tWybb298uwhMVBRw==(int #=zz2WGoFE=, int #=zbwrJfOI=, DateTime #=z7iJcLPfMecrfYDQL0w==)
		{
			this.#=zHvlDumbw87fH(#=zz2WGoFE=);
			this.#=zWIeOkE0$UPjN(#=zbwrJfOI=);
			this.#=zLkO3VEKrN2mHIZiieQ==(#=z7iJcLPfMecrfYDQL0w==);
			this.#=zrW8jNzZ5MSGa(DateTime.MinValue);
		}

		// Token: 0x0600088C RID: 2188 RVA: 0x00044398 File Offset: 0x00042598
		public int #=zvHeSI2qaaZ6r()
		{
			return this.#=z8ID4bK9_Ws8rI76lOQ==;
		}

		// Token: 0x0600088D RID: 2189 RVA: 0x000443A0 File Offset: 0x000425A0
		public void #=zHvlDumbw87fH(int #=z$Ib9gYQ=)
		{
			this.#=z8ID4bK9_Ws8rI76lOQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x0600088E RID: 2190 RVA: 0x000443AC File Offset: 0x000425AC
		public int #=zK5gF1KeGk_H_()
		{
			return this.#=z$PjuEd9p6uF7ftQ3QA==;
		}

		// Token: 0x0600088F RID: 2191 RVA: 0x000443B4 File Offset: 0x000425B4
		public void #=zWIeOkE0$UPjN(int #=z$Ib9gYQ=)
		{
			this.#=z$PjuEd9p6uF7ftQ3QA== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000890 RID: 2192 RVA: 0x000443C0 File Offset: 0x000425C0
		public DateTime #=zL4D9WC8RTH921DofgQ==()
		{
			return this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;
		}

		// Token: 0x06000891 RID: 2193 RVA: 0x000443C8 File Offset: 0x000425C8
		public void #=zLkO3VEKrN2mHIZiieQ==(DateTime #=z$Ib9gYQ=)
		{
			this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD = #=z$Ib9gYQ=;
		}

		// Token: 0x06000892 RID: 2194 RVA: 0x000443D4 File Offset: 0x000425D4
		public bool #=zDqA$IszsnQU58WBPkA==()
		{
			return this.#=zL4D9WC8RTH921DofgQ==() == DateTime.MinValue;
		}

		// Token: 0x06000893 RID: 2195 RVA: 0x000443E8 File Offset: 0x000425E8
		public DateTime #=z$jARfXJ2G0xh()
		{
			return this.#=zjHhyDUmY_zAd1JrbnNqM8VM=;
		}

		// Token: 0x06000894 RID: 2196 RVA: 0x000443F0 File Offset: 0x000425F0
		public void #=zrW8jNzZ5MSGa(DateTime #=z$Ib9gYQ=)
		{
			this.#=zjHhyDUmY_zAd1JrbnNqM8VM= = #=z$Ib9gYQ=;
		}

		// Token: 0x06000895 RID: 2197 RVA: 0x000443FC File Offset: 0x000425FC
		public bool #=zE6NlIzUF$OZQDXJwPw==()
		{
			return this.#=z$jARfXJ2G0xh() != DateTime.MinValue;
		}

		// Token: 0x040004DD RID: 1245
		private int #=z8ID4bK9_Ws8rI76lOQ==;

		// Token: 0x040004DE RID: 1246
		private int #=z$PjuEd9p6uF7ftQ3QA==;

		// Token: 0x040004DF RID: 1247
		private DateTime #=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;

		// Token: 0x040004E0 RID: 1248
		private DateTime #=zjHhyDUmY_zAd1JrbnNqM8VM=;
	}

	// Token: 0x02000146 RID: 326
	private sealed class #=zpEtMM0peHbYsZs_GCB7kiu4=
	{
		// Token: 0x06000897 RID: 2199 RVA: 0x00044418 File Offset: 0x00042618
		internal bool #=zHSi7JMjcOmKg22yCMOE0wfXhpiEYQlZKIjoouXU=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zYgvZuBwR$a1C() == this.#=zlJSAjfPMVf41.#=zV68dPxoDznd7.#=zYgvZuBwR$a1C() && #=zQrqFdos=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() == this.#=zCsFfX0LBCUiE[0].#=zMuFMjGQ=();
		}

		// Token: 0x040004E1 RID: 1249
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zCsFfX0LBCUiE;

		// Token: 0x040004E2 RID: 1250
		public #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zlJSAjfPMVf41;
	}

	// Token: 0x02000147 RID: 327
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600089A RID: 2202 RVA: 0x00044468 File Offset: 0x00042668
		internal int #=zBWkPviJoiRtzDnH2IZye2RvUfmxQyEhwyik2ZHo=(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zm8PpuDU=, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zcltuPyw=)
		{
			return #=zcltuPyw=.#=z8waQMcfHThTd().CompareTo(#=zm8PpuDU=.#=z8waQMcfHThTd());
		}

		// Token: 0x0600089B RID: 2203 RVA: 0x00044494 File Offset: 0x00042694
		internal int #=z4wMVHqGh6QXULZL4_JBP_$w_DT9SrK2YWQ==(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zm8PpuDU=, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zcltuPyw=)
		{
			if (#=zm8PpuDU=.#=zP3ojUl2Dti9YfccUMg==() != #=zcltuPyw=.#=zP3ojUl2Dti9YfccUMg==())
			{
				return #=zcltuPyw=.#=zP3ojUl2Dti9YfccUMg==().CompareTo(#=zm8PpuDU=.#=zP3ojUl2Dti9YfccUMg==());
			}
			return #=zcltuPyw=.#=zuPMhw87glikS().CompareTo(#=zm8PpuDU=.#=zuPMhw87glikS());
		}

		// Token: 0x0600089C RID: 2204 RVA: 0x000444D8 File Offset: 0x000426D8
		internal int #=znMKp4PrO2VPldCVPGwj6_bc=(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zuPMhw87glikS();
		}

		// Token: 0x0600089D RID: 2205 RVA: 0x000444E0 File Offset: 0x000426E0
		internal bool #=zDJnu4Nxp7psgiT0k2DHVAOg=(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zP3ojUl2Dti9YfccUMg==();
		}

		// Token: 0x0600089E RID: 2206 RVA: 0x000444E8 File Offset: 0x000426E8
		internal int #=zhhVzgIRysSsnU_NEZP7sQpM=(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zm8PpuDU=, #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zuPMhw87glikS().CompareTo(#=zcltuPyw=.#=zuPMhw87glikS());
		}

		// Token: 0x0600089F RID: 2207 RVA: 0x0004450C File Offset: 0x0004270C
		internal int #=z3lL2s404cCTvRwVvqcPxnbE=(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zuPMhw87glikS();
		}

		// Token: 0x040004E3 RID: 1251
		public static readonly #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU= #=zLkw0NRU= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zyDNvciU=();

		// Token: 0x040004E4 RID: 1252
		public static Comparison<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zvk83RafbZnhZdlflsw==;

		// Token: 0x040004E5 RID: 1253
		public static Comparison<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zs33owmHLqq38TUjIyQ==;

		// Token: 0x040004E6 RID: 1254
		public static Func<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=, int> #=zad5ZGdearMoh4ywjqw==;

		// Token: 0x040004E7 RID: 1255
		public static Predicate<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zad5ZGdearMp$Wm5iOA==;

		// Token: 0x040004E8 RID: 1256
		public static Comparison<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=z5L96ayI9as3cQMhgtg==;

		// Token: 0x040004E9 RID: 1257
		public static Func<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=, int> #=zzjC3ZrDwmUQbYfv6fg==;
	}
}
