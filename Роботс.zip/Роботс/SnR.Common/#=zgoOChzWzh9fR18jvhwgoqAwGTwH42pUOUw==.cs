﻿using System;

// Token: 0x0200024E RID: 590
internal sealed class #=zgoOChzWzh9fR18jvhwgoqAwGTwH42pUOUw==<#=zQSoxQMk=>
{
	// Token: 0x060011E3 RID: 4579 RVA: 0x0008A4B0 File Offset: 0x000886B0
	public #=zgoOChzWzh9fR18jvhwgoqAwGTwH42pUOUw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zXqKwUc4= = #=z8StzeqE=;
		this.#=zIkyUNGE= = null;
		this.#=z9HdGFQI= = default(#=zQSoxQMk=);
		this.#=zDdyVDzU$I_uf = false;
		this.#=z9wQDh14Pspmq = null;
	}

	// Token: 0x060011E4 RID: 4580 RVA: 0x0008A4E0 File Offset: 0x000886E0
	public #=zgoOChzWzh9fR18jvhwgoqAwGTwH42pUOUw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zQSoxQMk= #=zk$WIGF8=)
	{
		this.#=zXqKwUc4= = #=z8StzeqE=;
		this.#=zIkyUNGE= = null;
		this.#=z9HdGFQI= = #=zk$WIGF8=;
		this.#=zDdyVDzU$I_uf = false;
		this.#=z9wQDh14Pspmq = null;
	}

	// Token: 0x060011E5 RID: 4581 RVA: 0x0008A50C File Offset: 0x0008870C
	public #=zQSoxQMk= #=zsDSkhrM=()
	{
		return this.#=z9HdGFQI=;
	}

	// Token: 0x060011E6 RID: 4582 RVA: 0x0008A514 File Offset: 0x00088714
	public void #=zIQTCoGs=(#=zQSoxQMk= #=z$Ib9gYQ=)
	{
		this.#=z9HdGFQI= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011E7 RID: 4583 RVA: 0x0008A520 File Offset: 0x00088720
	public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQ4wZnctPyyRO()
	{
		return this.#=zXqKwUc4=;
	}

	// Token: 0x060011E8 RID: 4584 RVA: 0x0008A528 File Offset: 0x00088728
	public object[] #=ziT498HrULWY6()
	{
		return this.#=zIkyUNGE=;
	}

	// Token: 0x060011E9 RID: 4585 RVA: 0x0008A530 File Offset: 0x00088730
	public void #=ztSXsLQ8KrKAU(object[] #=z$Ib9gYQ=)
	{
		this.#=zIkyUNGE= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011EA RID: 4586 RVA: 0x0008A53C File Offset: 0x0008873C
	public bool #=ziasHiGlKUcpU()
	{
		return this.#=zDdyVDzU$I_uf;
	}

	// Token: 0x060011EB RID: 4587 RVA: 0x0008A544 File Offset: 0x00088744
	public void #=z8w$9U75qCzHc(bool #=z$Ib9gYQ=)
	{
		this.#=zDdyVDzU$I_uf = #=z$Ib9gYQ=;
	}

	// Token: 0x060011EC RID: 4588 RVA: 0x0008A550 File Offset: 0x00088750
	public string #=z37JbfhBQfNof()
	{
		return this.#=z9wQDh14Pspmq;
	}

	// Token: 0x060011ED RID: 4589 RVA: 0x0008A558 File Offset: 0x00088758
	public void #=zegbyLruW1Ya2(string #=z$Ib9gYQ=)
	{
		this.#=z9wQDh14Pspmq = #=z$Ib9gYQ=;
	}

	// Token: 0x04000A03 RID: 2563
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zXqKwUc4=;

	// Token: 0x04000A04 RID: 2564
	private object[] #=zIkyUNGE=;

	// Token: 0x04000A05 RID: 2565
	private #=zQSoxQMk= #=z9HdGFQI=;

	// Token: 0x04000A06 RID: 2566
	private bool #=zDdyVDzU$I_uf;

	// Token: 0x04000A07 RID: 2567
	private string #=z9wQDh14Pspmq;
}
