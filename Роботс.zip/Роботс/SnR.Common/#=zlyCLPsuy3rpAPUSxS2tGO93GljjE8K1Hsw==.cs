﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000281 RID: 641
internal sealed class #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==
{
	// Token: 0x0600135B RID: 4955 RVA: 0x00096210 File Offset: 0x00094410
	public #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==(string #=zkVrYiTU$B1Ks)
	{
		this.#=zXCVViNS9EcQD = #=zkVrYiTU$B1Ks;
	}

	// Token: 0x0600135C RID: 4956 RVA: 0x00096220 File Offset: 0x00094420
	private object #=zsDSkhrM=()
	{
		if (this.#=z9HdGFQI= == null)
		{
			this.#=z9HdGFQI= = JSONManager.GetData(this.#=zXCVViNS9EcQD);
		}
		return this.#=z9HdGFQI=;
	}

	// Token: 0x0600135D RID: 4957 RVA: 0x00096244 File Offset: 0x00094444
	public #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zNnx4xxtx9xYwefJwdg==()
	{
		if (this.#=zf3BfycIK2AJQRKWskQ== == null)
		{
			this.#=zf3BfycIK2AJQRKWskQ== = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z4UvGiLJo6$eGNGd0Mg==(this.#=zsDSkhrM=());
		}
		return this.#=zf3BfycIK2AJQRKWskQ==;
	}

	// Token: 0x0600135E RID: 4958 RVA: 0x00096268 File Offset: 0x00094468
	public Dictionary<string, object> #=zfBt$fipohITJELd1KQUdRGFOof7U()
	{
		if (this.#=zX4EQLdxz05HigMSBXSuOeGBh7QOa == null)
		{
			this.#=zX4EQLdxz05HigMSBXSuOeGBh7QOa = (Dictionary<string, object>)JSONManager.GetObject(this.#=zsDSkhrM=(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074327));
			if (this.#=zX4EQLdxz05HigMSBXSuOeGBh7QOa == null)
			{
				this.#=zX4EQLdxz05HigMSBXSuOeGBh7QOa = new Dictionary<string, object>();
			}
		}
		return this.#=zX4EQLdxz05HigMSBXSuOeGBh7QOa;
	}

	// Token: 0x04000B2F RID: 2863
	private string #=zXCVViNS9EcQD;

	// Token: 0x04000B30 RID: 2864
	private object #=z9HdGFQI=;

	// Token: 0x04000B31 RID: 2865
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zf3BfycIK2AJQRKWskQ==;

	// Token: 0x04000B32 RID: 2866
	private Dictionary<string, object> #=zX4EQLdxz05HigMSBXSuOeGBh7QOa;
}
