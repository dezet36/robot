﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000192 RID: 402
internal sealed class #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= : #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU
{
	// Token: 0x06000B86 RID: 2950 RVA: 0x00058034 File Offset: 0x00056234
	public #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=(int #=zAk8mKBk=, string #=z6QPrZ_4=, int #=zAVt12cNd9egB, int #=zsEJ$5DeyTl5k) : base(#=zAk8mKBk=, #=z6QPrZ_4=)
	{
		this.#=zeO5h974InkCtPCzm6A==(#=zAVt12cNd9egB);
		this.#=zvprfh8wlkPZPcZ$rhg==(#=zsEJ$5DeyTl5k);
	}

	// Token: 0x06000B87 RID: 2951 RVA: 0x00058050 File Offset: 0x00056250
	public #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=(int #=zAk8mKBk=, Dictionary<string, object> #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2) : base(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
		this.#=zeO5h974InkCtPCzm6A==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), 0));
		this.#=zvprfh8wlkPZPcZ$rhg==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
	}

	// Token: 0x06000B88 RID: 2952 RVA: 0x000580A4 File Offset: 0x000562A4
	public int #=zxD6I$sU8FaBnH9eeRg==()
	{
		return this.#=zwnYyrYMuFBTAYmK9ei$iAwI=;
	}

	// Token: 0x06000B89 RID: 2953 RVA: 0x000580AC File Offset: 0x000562AC
	public void #=zeO5h974InkCtPCzm6A==(int #=z$Ib9gYQ=)
	{
		this.#=zwnYyrYMuFBTAYmK9ei$iAwI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B8A RID: 2954 RVA: 0x000580B8 File Offset: 0x000562B8
	public int #=zFGv2TEt4Pg1fjr57ew==()
	{
		return this.#=zC_t$YSLRRaZnpJcYzzH9NHA=;
	}

	// Token: 0x06000B8B RID: 2955 RVA: 0x000580C0 File Offset: 0x000562C0
	public void #=zvprfh8wlkPZPcZ$rhg==(int #=z$Ib9gYQ=)
	{
		this.#=zC_t$YSLRRaZnpJcYzzH9NHA= = #=z$Ib9gYQ=;
	}

	// Token: 0x0400063A RID: 1594
	private int #=zwnYyrYMuFBTAYmK9ei$iAwI=;

	// Token: 0x0400063B RID: 1595
	private int #=zC_t$YSLRRaZnpJcYzzH9NHA=;
}
