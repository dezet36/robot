﻿using System;
using Skink.SnR.Common.Global;

// Token: 0x0200021F RID: 543
internal sealed class #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==
{
	// Token: 0x0600109B RID: 4251 RVA: 0x00080230 File Offset: 0x0007E430
	public #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zofFle5Q=, bool #=zXax54lzEowMN, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zpyiXGMucDhJn(#=zofFle5Q=);
		this.#=zyZjP5ISUBvqKAkowJA==(#=zXax54lzEowMN);
		this.#=zBsf2L3480hVT(#=z8StzeqE=);
		this.#=ztoPAnqNMJdCZ = null;
		this.#=zRzUen$zbM50ANV2TNA==(false);
	}

	// Token: 0x0600109C RID: 4252 RVA: 0x0008025C File Offset: 0x0007E45C
	public #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zZhtNEVG9mdJh()
	{
		return this.#=zUYX2eIdAUAinG5EXPw==;
	}

	// Token: 0x0600109D RID: 4253 RVA: 0x00080264 File Offset: 0x0007E464
	public void #=zpyiXGMucDhJn(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=z$Ib9gYQ=)
	{
		this.#=zUYX2eIdAUAinG5EXPw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600109E RID: 4254 RVA: 0x00080270 File Offset: 0x0007E470
	public bool #=zU3NiAfDQweme8jKsqw==()
	{
		return this.#=zmjXMcO1hY409GOjLGX52HdQ=;
	}

	// Token: 0x0600109F RID: 4255 RVA: 0x00080278 File Offset: 0x0007E478
	public void #=zyZjP5ISUBvqKAkowJA==(bool #=z$Ib9gYQ=)
	{
		this.#=zmjXMcO1hY409GOjLGX52HdQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x060010A0 RID: 4256 RVA: 0x00080284 File Offset: 0x0007E484
	public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQ4wZnctPyyRO()
	{
		return this.#=zn5LuGRjGhlKnH_18GQ==;
	}

	// Token: 0x060010A1 RID: 4257 RVA: 0x0008028C File Offset: 0x0007E48C
	public void #=zBsf2L3480hVT(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z$Ib9gYQ=)
	{
		this.#=zn5LuGRjGhlKnH_18GQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x00080298 File Offset: 0x0007E498
	public bool #=zmV5ijznC$olBuQ$vDQ==()
	{
		return this.#=z0sR25D4C7ZnWuzannklI0Ko=;
	}

	// Token: 0x060010A3 RID: 4259 RVA: 0x000802A0 File Offset: 0x0007E4A0
	public void #=zRzUen$zbM50ANV2TNA==(bool #=z$Ib9gYQ=)
	{
		this.#=z0sR25D4C7ZnWuzannklI0Ko= = #=z$Ib9gYQ=;
	}

	// Token: 0x060010A4 RID: 4260 RVA: 0x000802AC File Offset: 0x0007E4AC
	public ProxyInfo #=z9TrQaE7EBV1U()
	{
		if (this.#=zZhtNEVG9mdJh() != null)
		{
			return this.#=zZhtNEVG9mdJh().#=z9TrQaE7EBV1U();
		}
		if (this.#=ztoPAnqNMJdCZ != null)
		{
			if (this.#=ztoPAnqNMJdCZ.State == ProxyStates.Ok)
			{
				return this.#=ztoPAnqNMJdCZ;
			}
			this.#=ztoPAnqNMJdCZ = null;
		}
		#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== = ProxyInfo.#=zn2ovxJQcP5BV();
		try
		{
			for (int i = 0; i < #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count; i++)
			{
				if (#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[i].State == ProxyStates.Ok)
				{
					this.#=ztoPAnqNMJdCZ = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[i];
					break;
				}
			}
			if (this.#=ztoPAnqNMJdCZ == null && #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count > 0)
			{
				this.#=ztoPAnqNMJdCZ = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[0];
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
		if (this.#=ztoPAnqNMJdCZ == null)
		{
			this.#=ztoPAnqNMJdCZ = new ProxyInfo(ProxyTypes.NoProxy, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051852)), 0);
		}
		return this.#=ztoPAnqNMJdCZ;
	}

	// Token: 0x060010A5 RID: 4261 RVA: 0x00080388 File Offset: 0x0007E588
	public bool #=z9$ebnKOpXUdG()
	{
		return !this.#=zU3NiAfDQweme8jKsqw==() && this.#=zZhtNEVG9mdJh() != null && this.#=zZhtNEVG9mdJh().#=zaktMlI6Lx5IGn58ypg==() != null;
	}

	// Token: 0x040008FD RID: 2301
	private #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zUYX2eIdAUAinG5EXPw==;

	// Token: 0x040008FE RID: 2302
	private bool #=zmjXMcO1hY409GOjLGX52HdQ=;

	// Token: 0x040008FF RID: 2303
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zn5LuGRjGhlKnH_18GQ==;

	// Token: 0x04000900 RID: 2304
	private ProxyInfo #=ztoPAnqNMJdCZ;

	// Token: 0x04000901 RID: 2305
	private bool #=z0sR25D4C7ZnWuzannklI0Ko=;
}
