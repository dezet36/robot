﻿using System;
using System.Text;
using common;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x020001E0 RID: 480
internal sealed class #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000E8E RID: 3726 RVA: 0x000756FC File Offset: 0x000738FC
	internal #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU(ExternalSheet #=z8MJaPcg=)
	{
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=z8MJaPcg=;
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x0007570C File Offset: 0x0007390C
	internal #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU(string #=zWj7xLq8=, ExternalSheet #=z8MJaPcg=)
	{
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=z8MJaPcg=;
		int num = #=zWj7xLq8=.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074));
		Assert.verify(num != -1);
		string s = #=zWj7xLq8=.Substring(num + 1);
		int num2 = #=zWj7xLq8=.IndexOf('!');
		string s2 = #=zWj7xLq8=.Substring(num2 + 1, num - (num2 + 1));
		this.#=zDec2DjUIpVoA = CellReferenceHelper.getColumn(s2);
		this.#=zkVbotU1onZOR = CellReferenceHelper.getRow(s2);
		string text = #=zWj7xLq8=.Substring(0, num2);
		if (text[0] == '\'' && text[text.Length - 1] == '\'')
		{
			text = text.Substring(1, text.Length - 1 - 1);
		}
		this.#=zNEZ0SGey$A9J = #=z8MJaPcg=.getExternalSheetIndex(text);
		if (this.#=zNEZ0SGey$A9J < 0)
		{
			throw new FormulaException(FormulaException.#=zvQjmbmClENVK8Iem6A==, text);
		}
		this.#=zh1vaBWFzORUr = CellReferenceHelper.getColumn(s);
		this.#=znnJ2FmckCK2R = CellReferenceHelper.getRow(s);
		this.#=z3EZeT1Eq9S9C = true;
		this.#=zcCic2xXY931G = true;
		this.#=z0ObI7fN0V9z1 = true;
		this.#=zDW3g0K7EfcSm = true;
	}

	// Token: 0x06000E90 RID: 3728 RVA: 0x00075810 File Offset: 0x00073A10
	internal int #=zas6WF9Y7vCuz()
	{
		return this.#=zDec2DjUIpVoA;
	}

	// Token: 0x06000E91 RID: 3729 RVA: 0x00075818 File Offset: 0x00073A18
	internal int #=zEEViUu7KfNd$()
	{
		return this.#=zkVbotU1onZOR;
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x00075820 File Offset: 0x00073A20
	internal int #=zf4bYulRRFW0C()
	{
		return this.#=zh1vaBWFzORUr;
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x00075828 File Offset: 0x00073A28
	internal int #=zW5QkwOB5a$bC()
	{
		return this.#=znnJ2FmckCK2R;
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x00075830 File Offset: 0x00073A30
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[11];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zGsPufWW4LYcC.#=zd$BbM3Y=();
		IntegerHelper.getTwoBytes(this.#=zNEZ0SGey$A9J, array, 1);
		IntegerHelper.getTwoBytes(this.#=zkVbotU1onZOR, array, 3);
		IntegerHelper.getTwoBytes(this.#=znnJ2FmckCK2R, array, 5);
		int num = this.#=zDec2DjUIpVoA;
		if (this.#=zcCic2xXY931G)
		{
			num |= 32768;
		}
		if (this.#=z3EZeT1Eq9S9C)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 7);
		num = this.#=zh1vaBWFzORUr;
		if (this.#=zDW3g0K7EfcSm)
		{
			num |= 32768;
		}
		if (this.#=z0ObI7fN0V9z1)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 9);
		return array;
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x000758DC File Offset: 0x00073ADC
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zNEZ0SGey$A9J = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		this.#=zkVbotU1onZOR = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		this.#=znnJ2FmckCK2R = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 4], #=zJ5GWysk=[#=z4J_G3VM= + 5]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 6], #=zJ5GWysk=[#=z4J_G3VM= + 7]);
		this.#=zDec2DjUIpVoA = (@int & 255);
		this.#=z3EZeT1Eq9S9C = ((@int & 16384) != 0);
		this.#=zcCic2xXY931G = ((@int & 32768) != 0);
		@int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 8], #=zJ5GWysk=[#=z4J_G3VM= + 9]);
		this.#=zh1vaBWFzORUr = (@int & 255);
		this.#=z0ObI7fN0V9z1 = ((@int & 16384) != 0);
		this.#=zDW3g0K7EfcSm = ((@int & 32768) != 0);
		return 10;
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x000759A4 File Offset: 0x00073BA4
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		CellReferenceHelper.getCellReference(this.#=zNEZ0SGey$A9J, this.#=zDec2DjUIpVoA, this.#=zkVbotU1onZOR, this.#=zJY$tXiAJ_$AzbtOFtg==, #=zXvwCnz8=);
		#=zXvwCnz8=.Append(':');
		CellReferenceHelper.getCellReference(this.#=zh1vaBWFzORUr, this.#=znnJ2FmckCK2R, #=zXvwCnz8=);
	}

	// Token: 0x06000E97 RID: 3735 RVA: 0x000759E0 File Offset: 0x00073BE0
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		if (this.#=z3EZeT1Eq9S9C)
		{
			this.#=zDec2DjUIpVoA += #=zUFUpoGQeXcCf;
		}
		if (this.#=z0ObI7fN0V9z1)
		{
			this.#=zh1vaBWFzORUr += #=zUFUpoGQeXcCf;
		}
		if (this.#=zcCic2xXY931G)
		{
			this.#=zkVbotU1onZOR += #=zJhSli$dVSPlw;
		}
		if (this.#=zDW3g0K7EfcSm)
		{
			this.#=znnJ2FmckCK2R += #=zJhSli$dVSPlw;
		}
	}

	// Token: 0x06000E98 RID: 3736 RVA: 0x00075A48 File Offset: 0x00073C48
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (this.#=zDec2DjUIpVoA >= #=zMYEXL$w=)
		{
			this.#=zDec2DjUIpVoA++;
		}
		if (this.#=zh1vaBWFzORUr >= #=zMYEXL$w=)
		{
			this.#=zh1vaBWFzORUr++;
		}
	}

	// Token: 0x06000E99 RID: 3737 RVA: 0x00075A84 File Offset: 0x00073C84
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (#=zMYEXL$w= < this.#=zDec2DjUIpVoA)
		{
			this.#=zDec2DjUIpVoA--;
		}
		if (#=zMYEXL$w= <= this.#=zh1vaBWFzORUr)
		{
			this.#=zh1vaBWFzORUr--;
		}
	}

	// Token: 0x06000E9A RID: 3738 RVA: 0x00075AC0 File Offset: 0x00073CC0
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (#=zg9A8_dw= <= this.#=zkVbotU1onZOR)
		{
			this.#=zkVbotU1onZOR++;
		}
		if (#=zg9A8_dw= <= this.#=znnJ2FmckCK2R)
		{
			this.#=znnJ2FmckCK2R++;
		}
	}

	// Token: 0x06000E9B RID: 3739 RVA: 0x00075AFC File Offset: 0x00073CFC
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (#=zg9A8_dw= < this.#=zkVbotU1onZOR)
		{
			this.#=zkVbotU1onZOR--;
		}
		if (#=zg9A8_dw= <= this.#=znnJ2FmckCK2R)
		{
			this.#=znnJ2FmckCK2R--;
		}
	}

	// Token: 0x04000821 RID: 2081
	private int #=zNEZ0SGey$A9J;

	// Token: 0x04000822 RID: 2082
	private int #=zDec2DjUIpVoA;

	// Token: 0x04000823 RID: 2083
	private int #=zkVbotU1onZOR;

	// Token: 0x04000824 RID: 2084
	private int #=zh1vaBWFzORUr;

	// Token: 0x04000825 RID: 2085
	private int #=znnJ2FmckCK2R;

	// Token: 0x04000826 RID: 2086
	private bool #=z3EZeT1Eq9S9C;

	// Token: 0x04000827 RID: 2087
	private bool #=zcCic2xXY931G;

	// Token: 0x04000828 RID: 2088
	private bool #=z0ObI7fN0V9z1;

	// Token: 0x04000829 RID: 2089
	private bool #=zDW3g0K7EfcSm;

	// Token: 0x0400082A RID: 2090
	private ExternalSheet #=zJY$tXiAJ_$AzbtOFtg==;
}
