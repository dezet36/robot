﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.AppLocal;

// Token: 0x02000039 RID: 57
internal sealed class #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== : List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>
{
	// Token: 0x060001D3 RID: 467 RVA: 0x000127F4 File Offset: 0x000109F4
	public #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==()
	{
		this.#=zYDhAqWySolcWM87a$g== = new Dictionary<int, int>();
		this.#=zmqCvHANCk51bos95nw== = -1;
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x00012810 File Offset: 0x00010A10
	public int #=zPZX$iwso2aYN(int #=zp13pRNQ=)
	{
		if (this.#=zYDhAqWySolcWM87a$g==.ContainsKey(#=zp13pRNQ=))
		{
			return this.#=zYDhAqWySolcWM87a$g==[#=zp13pRNQ=];
		}
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zFMDiymuLQ7_4() == #=zp13pRNQ=)
			{
				this.#=zYDhAqWySolcWM87a$g==[#=zp13pRNQ=] = base[i].#=zjw43QGFcPyHH();
				return base[i].#=zjw43QGFcPyHH();
			}
		}
		this.#=zYDhAqWySolcWM87a$g==[#=zp13pRNQ=] = 0;
		return 0;
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x0001288C File Offset: 0x00010A8C
	public int #=zAfzFlD9Pxopy(int #=zp13pRNQ=)
	{
		if (this.#=zYDhAqWySolcWM87a$g==.ContainsKey(#=zp13pRNQ=))
		{
			return this.#=zYDhAqWySolcWM87a$g==[#=zp13pRNQ=];
		}
		int num = 0;
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zFMDiymuLQ7_4() == #=zp13pRNQ=)
			{
				num += base[i].#=zjw43QGFcPyHH();
			}
		}
		this.#=zYDhAqWySolcWM87a$g==[#=zp13pRNQ=] = num;
		return num;
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x000128F4 File Offset: 0x00010AF4
	public double #=zhtBrxwDVNBSt(int #=zp13pRNQ=, #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zBIACkqg=)
	{
		double num = 0.0;
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zFMDiymuLQ7_4() == #=zp13pRNQ=)
			{
				double num2 = base[i].#=zJtclDBkKCg12()[#=zBIACkqg=];
				if (num2 > num)
				{
					num = num2;
				}
			}
		}
		return num;
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x00012948 File Offset: 0x00010B48
	public bool #=zefHMDAN40dlccrzuRg==()
	{
		if (this.#=zmqCvHANCk51bos95nw== < 0)
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].#=zvnZc$RhG_1Du() > 1)
				{
					this.#=zmqCvHANCk51bos95nw== = 1;
					break;
				}
			}
			if (this.#=zmqCvHANCk51bos95nw== < 1)
			{
				this.#=zmqCvHANCk51bos95nw== = 0;
			}
		}
		return this.#=zmqCvHANCk51bos95nw== == 1;
	}

	// Token: 0x060001D8 RID: 472 RVA: 0x000129A0 File Offset: 0x00010BA0
	public int #=zxZCerbvcGABMaw4jNA==()
	{
		return this.#=zAfzFlD9Pxopy(108) + 1000;
	}

	// Token: 0x060001D9 RID: 473 RVA: 0x000129B0 File Offset: 0x00010BB0
	public int #=zhv46JpQA_A2R328PYqjpCx8=()
	{
		return this.#=zAfzFlD9Pxopy(109) + 1000;
	}

	// Token: 0x060001DA RID: 474 RVA: 0x000129C0 File Offset: 0x00010BC0
	public int #=z5HP2qqqcT7UpKkfKeQ==()
	{
		return this.#=zPZX$iwso2aYN(150);
	}

	// Token: 0x060001DB RID: 475 RVA: 0x000129D0 File Offset: 0x00010BD0
	public string #=zBS773tnqLiMjJUTanNGAdN0=()
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.AddRange(this);
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Sort(new #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==((#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)1));
		StringBuilder stringBuilder = new StringBuilder();
		bool flag = GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=();
		for (int i = 0; i < #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(Environment.NewLine);
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==[i];
			stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4());
			stringBuilder.Append('\t');
			stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=());
			if (!flag)
			{
				stringBuilder.Append('\t');
				stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zfTB62qendhk_VEy8rw==());
				stringBuilder.Append('\t');
				stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zY0soxphmGIACbOHy6A==());
			}
			else
			{
				stringBuilder.Append('\t');
				stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zlSY2GGkBa6S3MkHuDQ==());
			}
			stringBuilder.Append('\t');
			stringBuilder.Append(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zAdM$oWHPKFC_gx1bYQ==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071019) : string.Empty);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0400006A RID: 106
	private Dictionary<int, int> #=zYDhAqWySolcWM87a$g==;

	// Token: 0x0400006B RID: 107
	private int #=zmqCvHANCk51bos95nw==;
}
