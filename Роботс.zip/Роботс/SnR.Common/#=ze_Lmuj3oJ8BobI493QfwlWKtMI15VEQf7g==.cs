﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200022E RID: 558
internal sealed class #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==
{
	// Token: 0x06001119 RID: 4377 RVA: 0x00083640 File Offset: 0x00081840
	public #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==(Dictionary<string, object> #=zbWbysAaKzDhE)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zbWbysAaKzDhE, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102));
		this.#=zKHQ0BifFBUDT(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zn_uDwt7HzoEf(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071037), 0));
		this.#=zIaGGDzQ=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0));
	}

	// Token: 0x0600111A RID: 4378 RVA: 0x000836AC File Offset: 0x000818AC
	public int #=zLEh48lU$jhVz()
	{
		return this.#=z4HE6wN4t$YNNAL52hA==;
	}

	// Token: 0x0600111B RID: 4379 RVA: 0x000836B4 File Offset: 0x000818B4
	public void #=zKHQ0BifFBUDT(int #=z$Ib9gYQ=)
	{
		this.#=z4HE6wN4t$YNNAL52hA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600111C RID: 4380 RVA: 0x000836C0 File Offset: 0x000818C0
	public int #=zwTvtD4XPFdA4()
	{
		return this.#=zw1bE__IgywCmwAh_QQ==;
	}

	// Token: 0x0600111D RID: 4381 RVA: 0x000836C8 File Offset: 0x000818C8
	public void #=zn_uDwt7HzoEf(int #=z$Ib9gYQ=)
	{
		this.#=zw1bE__IgywCmwAh_QQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600111E RID: 4382 RVA: 0x000836D4 File Offset: 0x000818D4
	public int #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x0600111F RID: 4383 RVA: 0x000836DC File Offset: 0x000818DC
	public void #=zIaGGDzQ=(int #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000942 RID: 2370
	private int #=z4HE6wN4t$YNNAL52hA==;

	// Token: 0x04000943 RID: 2371
	private int #=zw1bE__IgywCmwAh_QQ==;

	// Token: 0x04000944 RID: 2372
	private int #=z7Xrwc11cWxGe$3RbFQ==;
}
