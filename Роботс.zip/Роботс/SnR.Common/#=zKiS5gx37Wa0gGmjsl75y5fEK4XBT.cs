﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000135 RID: 309
internal sealed class #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT
{
	// Token: 0x060007E4 RID: 2020 RVA: 0x0003FC2C File Offset: 0x0003DE2C
	private #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT()
	{
		this.#=zGt5f4PUe5cDD(new List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z>());
		this.#=zO_vDyrXPn57Q(false);
		this.#=zWYcPsmYfFE_m_gR5Hw==(false);
		this.#=zDQyfq5TJqPTQ82Z7gd1tufydJqXR(0);
		this.#=ztL1KtTkNGu$1JyLqs0hugvTdwZln(0);
		this.#=zMP7HvHmce23$(new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>());
		this.#=z7jFoQg9jFkJ$(false);
	}

	// Token: 0x060007E6 RID: 2022 RVA: 0x0003FCAC File Offset: 0x0003DEAC
	public bool #=zNc3SMEwRW2Y7()
	{
		return this.#=zU3pUoGbbbQ7e2IXLdQ==;
	}

	// Token: 0x060007E7 RID: 2023 RVA: 0x0003FCB4 File Offset: 0x0003DEB4
	public void #=z7jFoQg9jFkJ$(bool #=z$Ib9gYQ=)
	{
		this.#=zU3pUoGbbbQ7e2IXLdQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007E8 RID: 2024 RVA: 0x0003FCC0 File Offset: 0x0003DEC0
	public string #=zVZd$8ug=()
	{
		return this.#=zZlZW7E0$79DKYupoZw==;
	}

	// Token: 0x060007E9 RID: 2025 RVA: 0x0003FCC8 File Offset: 0x0003DEC8
	public void #=zZd4EYe4=(string #=z$Ib9gYQ=)
	{
		this.#=zZlZW7E0$79DKYupoZw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007EA RID: 2026 RVA: 0x0003FCD4 File Offset: 0x0003DED4
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x0003FCDC File Offset: 0x0003DEDC
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x0003FCE8 File Offset: 0x0003DEE8
	public List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> #=zBPfdebBv4RQN()
	{
		return this.#=zATrXbudnGdMpS8oALA==;
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x0003FCF0 File Offset: 0x0003DEF0
	private void #=zGt5f4PUe5cDD(List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> #=z$Ib9gYQ=)
	{
		this.#=zATrXbudnGdMpS8oALA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x0003FCFC File Offset: 0x0003DEFC
	public DateTime #=zBoNb_vDDi2WG()
	{
		return this.#=zDFyHbhY8vowXIHy6gAMUa3k=;
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x0003FD04 File Offset: 0x0003DF04
	private void #=zODJV6lumTRqY(DateTime #=z$Ib9gYQ=)
	{
		this.#=zDFyHbhY8vowXIHy6gAMUa3k= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x0003FD10 File Offset: 0x0003DF10
	public bool #=z27xw9AtrFib$()
	{
		return this.#=ziAKiZ37QAxcQ94mMwrVR9tk=;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x0003FD18 File Offset: 0x0003DF18
	public void #=zO_vDyrXPn57Q(bool #=z$Ib9gYQ=)
	{
		this.#=ziAKiZ37QAxcQ94mMwrVR9tk= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x0003FD24 File Offset: 0x0003DF24
	public bool #=zmWSq0sTYcJfLLSlbyQ==()
	{
		return this.#=zlFiwGkLD9hXcWXRCQ86J218=;
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x0003FD2C File Offset: 0x0003DF2C
	public void #=zWYcPsmYfFE_m_gR5Hw==(bool #=z$Ib9gYQ=)
	{
		this.#=zlFiwGkLD9hXcWXRCQ86J218= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x0003FD38 File Offset: 0x0003DF38
	public int #=zhnZtiNfmX6jGblnmG_kFgQvgBk7N()
	{
		return this.#=zROPj4H79bf1QPgFwClor9mQnCFkN3pazCHYd1bQ=;
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x0003FD40 File Offset: 0x0003DF40
	public void #=zDQyfq5TJqPTQ82Z7gd1tufydJqXR(int #=z$Ib9gYQ=)
	{
		this.#=zROPj4H79bf1QPgFwClor9mQnCFkN3pazCHYd1bQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007F6 RID: 2038 RVA: 0x0003FD4C File Offset: 0x0003DF4C
	public int #=z0tAtvpk59AX6IZiVIY9dxVvko3Cf()
	{
		return this.#=zrO2$QPouI9xj1S$_pZfVXN$xiJ5hGsTZlW2lglM=;
	}

	// Token: 0x060007F7 RID: 2039 RVA: 0x0003FD54 File Offset: 0x0003DF54
	public void #=ztL1KtTkNGu$1JyLqs0hugvTdwZln(int #=z$Ib9gYQ=)
	{
		this.#=zrO2$QPouI9xj1S$_pZfVXN$xiJ5hGsTZlW2lglM= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007F8 RID: 2040 RVA: 0x0003FD60 File Offset: 0x0003DF60
	public string #=zZEc75Ho=()
	{
		return this.#=zMUWZqaYIG9GBGxTFGQ==;
	}

	// Token: 0x060007F9 RID: 2041 RVA: 0x0003FD68 File Offset: 0x0003DF68
	public void #=zL5jsuAE=(string #=z$Ib9gYQ=)
	{
		this.#=zMUWZqaYIG9GBGxTFGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007FA RID: 2042 RVA: 0x0003FD74 File Offset: 0x0003DF74
	public List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zOdy_aU_tk1aY()
	{
		return this.#=zE4nL0joTP9M_JnPBOQ==;
	}

	// Token: 0x060007FB RID: 2043 RVA: 0x0003FD7C File Offset: 0x0003DF7C
	private void #=zMP7HvHmce23$(List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=z$Ib9gYQ=)
	{
		this.#=zE4nL0joTP9M_JnPBOQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007FC RID: 2044 RVA: 0x0003FD88 File Offset: 0x0003DF88
	internal string #=zt7cEftjDSBcU()
	{
		return this.#=zjgDXgbkVXsnH;
	}

	// Token: 0x060007FD RID: 2045 RVA: 0x0003FD90 File Offset: 0x0003DF90
	internal string #=zsk0hydW1JJxU()
	{
		return this.#=z7d2dWYYz2_Hu;
	}

	// Token: 0x060007FE RID: 2046 RVA: 0x0003FD98 File Offset: 0x0003DF98
	public string #=zkx7sQeJXOOQR()
	{
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(null);
		if (string.IsNullOrEmpty(this.#=zZEc75Ho=()))
		{
			if (this.#=zmWSq0sTYcJfLLSlbyQ==())
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942703), Array.Empty<object>());
				if (this.#=zBoNb_vDDi2WG().Year < 2090)
				{
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988), Array.Empty<object>());
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942678), new object[]
					{
						this.#=zBoNb_vDDi2WG()
					});
				}
			}
			else if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zL0R09Ps=(this.#=zBoNb_vDDi2WG()))
			{
				if (#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zKh04cf8=() > 0)
				{
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(Environment.NewLine, Array.Empty<object>());
				}
				for (int i = 0; i < this.#=zBPfdebBv4RQN().Count; i++)
				{
					if (i > 0)
					{
						#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988), Array.Empty<object>());
					}
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(this.#=zBPfdebBv4RQN()[i].#=z6O$zzzXbpQKK().ToString(), Array.Empty<object>());
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031), Array.Empty<object>());
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zvdd3S149BbHjoM_$979W2bZlSqhG(this.#=zBPfdebBv4RQN()[i].#=zvnZc$RhG_1Du()), Array.Empty<object>());
				}
				if (this.#=zBoNb_vDDi2WG().Year < 2090)
				{
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988), Array.Empty<object>());
					#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942678), new object[]
					{
						this.#=zBoNb_vDDi2WG()
					});
				}
			}
			else
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942641), Array.Empty<object>());
			}
		}
		else
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(this.#=zZEc75Ho=(), Array.Empty<object>());
		}
		return #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString();
	}

	// Token: 0x060007FF RID: 2047 RVA: 0x0003FF64 File Offset: 0x0003E164
	public bool #=zrWDyvmK4AlwWe_UcjA==()
	{
		if (this.#=zYQDjTc6Y57pZNQ85dPEsPhc= < DateTime.Now - TimeSpan.FromHours(24.0) && this.#=zBoNb_vDDi2WG() < DateTime.Now + TimeSpan.FromDays(3.0))
		{
			this.#=zYQDjTc6Y57pZNQ85dPEsPhc= = DateTime.Now;
			return true;
		}
		return false;
	}

	// Token: 0x06000800 RID: 2048 RVA: 0x0003FFCC File Offset: 0x0003E1CC
	private static string #=zvdd3S149BbHjoM_$979W2bZlSqhG(AccessLevels #=z5w6HcG4=)
	{
		if (#=z5w6HcG4= <= AccessLevels.MultiExclude)
		{
			if (#=z5w6HcG4= <= AccessLevels.Standard)
			{
				if (#=z5w6HcG4= == AccessLevels.PremiumInactive)
				{
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942629);
				}
				if (#=z5w6HcG4= == AccessLevels.Standard)
				{
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085087);
				}
			}
			else
			{
				if (#=z5w6HcG4= == AccessLevels.Multi)
				{
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942598);
				}
				if (#=z5w6HcG4= == AccessLevels.MultiExclude)
				{
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909084705);
				}
			}
		}
		else if (#=z5w6HcG4= <= AccessLevels.PremiumExclude)
		{
			if (#=z5w6HcG4= == AccessLevels.Premium)
			{
				return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942827);
			}
			if (#=z5w6HcG4= == AccessLevels.PremiumExclude)
			{
				return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942811);
			}
		}
		else
		{
			if (#=z5w6HcG4= == AccessLevels.Xtreme)
			{
				return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942787);
			}
			if (#=z5w6HcG4= == AccessLevels.Author)
			{
				return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942781);
			}
		}
		return #=z5w6HcG4=.ToString();
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x00040088 File Offset: 0x0003E288
	public static void #=z1jlGMrg=(string #=zeMqpycI=, string #=zVuFgr_Q=, bool #=zxl2fBYqB3HlD, Action #=zJNXU07qCQQkB)
	{
		string text = string.Format(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zCBUXJdDks5Kc, GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z74RxmPlvSTcl(text);
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s == null)
		{
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z74RxmPlvSTcl(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859));
		}
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s == null)
		{
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z74RxmPlvSTcl(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064854));
		}
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s == null)
		{
			string text2 = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zcMLM9uRws_Bw(string.Format(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zCBUXJdDks5Kc, GameApplicationData.#=zZ2dsDUeWDYAN()));
			if (string.IsNullOrEmpty(text2))
			{
				text2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909084930);
			}
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = new #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT();
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zZd4EYe4=(text2);
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zwXKUV2c=(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942767)));
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zODJV6lumTRqY(DateTime.MaxValue);
			List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> list = new List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z>();
			#=z20QKvPoEBQeZntMw4AkDy90Awj_Z #=z20QKvPoEBQeZntMw4AkDy90Awj_Z = new #=z20QKvPoEBQeZntMw4AkDy90Awj_Z();
			#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zFzGvi_S6jJhE(AccessLevels.Standard);
			#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zLxATV0X$vbyM(1);
			list.Add(#=z20QKvPoEBQeZntMw4AkDy90Awj_Z);
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zGt5f4PUe5cDD(list);
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zO_vDyrXPn57Q(true);
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zWYcPsmYfFE_m_gR5Hw==(true);
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT;
		}
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zL5jsuAE=(null);
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zjgDXgbkVXsnH = #=zeMqpycI=;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=z7d2dWYYz2_Hu = #=zVuFgr_Q=;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zH2ngPbbyUE9U = #=zxl2fBYqB3HlD;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zIzrzKG0SnY5X = #=zJNXU07qCQQkB;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromHours(3.0);
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zClaXzZj7xRP6eRQGVw== = 0;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zT4UU0xuTbhVkq6gV2g== = 100;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=z$QMRdIKJA2M4vKNwVA== = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051837);
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z9Cr3BXA=(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s.#=zVZd$8ug=());
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x00040220 File Offset: 0x0003E420
	private static #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=z74RxmPlvSTcl(string #=zPkHZxKs=)
	{
		try
		{
			if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=zPkHZxKs=))
			{
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = new #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT();
				if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=znsb1z4CnXTx4(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT, #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=zPkHZxKs=)))
				{
					return #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT;
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(#=zN_s5Z5A=);
		}
		return null;
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x0004026C File Offset: 0x0003E46C
	private static string #=zcMLM9uRws_Bw(string #=zPkHZxKs=)
	{
		try
		{
			if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=zPkHZxKs=))
			{
				string[] array = JSONManager.Decode16(#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=zPkHZxKs=), true).Split(new string[]
				{
					Environment.NewLine
				}, StringSplitOptions.None);
				if (array.Length >= 3)
				{
					return array[0];
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(#=zN_s5Z5A=);
		}
		return null;
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x000402D0 File Offset: 0x0003E4D0
	private static bool #=znsb1z4CnXTx4(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zNraCe1Y=, string #=zXB$yBjB7lQNF)
	{
		try
		{
			if (#=zXB$yBjB7lQNF.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201)))
			{
				#=zXB$yBjB7lQNF = #=zXB$yBjB7lQNF.Substring(2);
			}
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zXB$yBjB7lQNF);
			#=zNraCe1Y=.#=zZd4EYe4=(JSONManager.Decode16(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), string.Empty), true));
			#=zNraCe1Y=.#=zwXKUV2c=(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty));
			object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094));
			#=zNraCe1Y=.#=zBPfdebBv4RQN().Clear();
			if (array.Length != 0)
			{
				Dictionary<string, object> dictionary2 = (Dictionary<string, object>)array[0];
				#=zNraCe1Y=.#=zODJV6lumTRqY(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), true));
				foreach (Dictionary<string, object> dictionary3 in JSONManager.ExtractArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)))
				{
					List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> list = #=zNraCe1Y=.#=zBPfdebBv4RQN();
					#=z20QKvPoEBQeZntMw4AkDy90Awj_Z #=z20QKvPoEBQeZntMw4AkDy90Awj_Z = new #=z20QKvPoEBQeZntMw4AkDy90Awj_Z();
					#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zFzGvi_S6jJhE((AccessLevels)JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
					#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zLxATV0X$vbyM(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0));
					list.Add(#=z20QKvPoEBQeZntMw4AkDy90Awj_Z);
				}
			}
			else
			{
				#=zNraCe1Y=.#=zODJV6lumTRqY(DateTime.MinValue);
			}
			#=zNraCe1Y=.#=zO_vDyrXPn57Q(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0) == 1);
			#=zNraCe1Y=.#=zWYcPsmYfFE_m_gR5Hw==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), 0) == 1);
			#=zNraCe1Y=.#=zDQyfq5TJqPTQ82Z7gd1tufydJqXR(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0));
			#=zNraCe1Y=.#=ztL1KtTkNGu$1JyLqs0hugvTdwZln(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
			#=zNraCe1Y=.#=zOdy_aU_tk1aY().Clear();
			object[] array3 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237));
			for (int j = 0; j < array3.Length; j++)
			{
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl item = new #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl((Dictionary<string, object>)array3[j]);
				#=zNraCe1Y=.#=zOdy_aU_tk1aY().Add(item);
			}
			return true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
		return false;
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x000404D8 File Offset: 0x0003E6D8
	public static string #=zFeMULgBuN$zi(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zNraCe1Y=)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940429), #=zNraCe1Y=.#=zVZd$8ug=());
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), JSONManager.Encode16(#=zNraCe1Y=.#=zVZd$8ug=(), true));
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), #=zNraCe1Y=.#=zkfqcY3I=());
		object[] array = new object[1];
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), array);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
		array[0] = dictionary2;
		dictionary2.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), JSONManager.EncodeTime(#=zNraCe1Y=.#=zBoNb_vDDi2WG(), true));
		object[] array2 = new object[#=zNraCe1Y=.#=zBPfdebBv4RQN().Count];
		dictionary2.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), array2);
		for (int i = 0; i < #=zNraCe1Y=.#=zBPfdebBv4RQN().Count; i++)
		{
			#=z20QKvPoEBQeZntMw4AkDy90Awj_Z #=z20QKvPoEBQeZntMw4AkDy90Awj_Z = #=zNraCe1Y=.#=zBPfdebBv4RQN()[i];
			Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
			array2[i] = dictionary3;
			dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), (int)#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zvnZc$RhG_1Du());
			dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), #=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=z6O$zzzXbpQKK());
		}
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), (#=zNraCe1Y=.#=z27xw9AtrFib$() > false) ? 1 : 0);
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), (#=zNraCe1Y=.#=zmWSq0sTYcJfLLSlbyQ==() > false) ? 1 : 0);
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), #=zNraCe1Y=.#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N());
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), #=zNraCe1Y=.#=z0tAtvpk59AX6IZiVIY9dxVvko3Cf());
		object[] array3 = new object[#=zNraCe1Y=.#=zOdy_aU_tk1aY().Count];
		dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), array3);
		for (int j = 0; j < #=zNraCe1Y=.#=zOdy_aU_tk1aY().Count; j++)
		{
			array3[j] = #=zNraCe1Y=.#=zOdy_aU_tk1aY()[j].#=zhv7OhlM=();
		}
		return JSONManager.SerializeData(dictionary);
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x000406CC File Offset: 0x0003E8CC
	public static #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=z7d1QsAA=()
	{
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942751), Array.Empty<object>());
		}
		return #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeXg6qLKcPK0s;
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x000406F0 File Offset: 0x0003E8F0
	public static void #=z9Cr3BXA=(string #=zNraCe1Y=)
	{
		if (#=zNraCe1Y= != null)
		{
			#=zNraCe1Y= = #=zNraCe1Y=.Trim();
		}
		new Thread(new ParameterizedThreadStart(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$yO$QkY=)).Start(#=zNraCe1Y=);
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x00040714 File Offset: 0x0003E914
	public static void #=zm_HETL6BUa$M()
	{
		if (DateTime.Now >= #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE)
		{
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zhZBY4XA=();
		}
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x00040734 File Offset: 0x0003E934
	public static void #=zhZBY4XA=()
	{
		new Thread(new ParameterizedThreadStart(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$yO$QkY=)).Start(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zVZd$8ug=());
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x00040758 File Offset: 0x0003E958
	public static void #=z$yO$QkY=(object #=zQABIDhGsC0OB)
	{
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zTcpqtfI=)
		{
			return;
		}
		object obj = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zSV4$mlFB34WM;
		lock (obj)
		{
			if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zTcpqtfI=)
			{
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zTcpqtfI= = true;
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
				try
				{
					if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942446), Array.Empty<object>());
					}
					string text = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNerpgmc=(Convert.ToString(#=zQABIDhGsC0OB));
					if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942394), Array.Empty<object>());
					}
					if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201)))
					{
						if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
						{
							#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942353), Array.Empty<object>());
						}
						if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=znsb1z4CnXTx4(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=(), text))
						{
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=znKPtYpu$_Iui5nzMAw==();
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(null);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zKmAxxeI=();
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromHours(3.0);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 5;
							if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY() != null)
							{
								#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zErl_Y6xnxoeCbRncEQ==();
							}
							#=zekGeYO3to2Fzt8dHc$KbhRWQexX_.#=zm7nSMZ8=();
							List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zQQQYPaZHedvo();
							if (list.Count > 0)
							{
								string text2 = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=znuPcZoWYeDnJ(list);
								if (text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201))
								{
									#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(5.0);
								}
								else if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
								{
									#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, text2, Array.Empty<object>());
								}
							}
						}
						else
						{
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942576)));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(10.0);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 90;
						}
					}
					else if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942538)))
					{
						if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
						{
							#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942528), Array.Empty<object>());
						}
						if (text[3] == 'A')
						{
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zODJV6lumTRqY(DateTime.MinValue);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zBPfdebBv4RQN().Clear();
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zwXKUV2c=(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942499)));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(text.Substring(4));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromHours(6.0);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 3;
						}
						else if (text[3] == 'C')
						{
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zODJV6lumTRqY(DateTime.Today - TimeSpan.FromDays(3.0));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zBPfdebBv4RQN().Clear();
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zwXKUV2c=(text.Substring(4));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(text.Substring(4));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY().Clear();
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromHours(6.0);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 3;
						}
						else
						{
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(text.Substring(4));
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(10.0);
							#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 90;
						}
					}
					else
					{
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(text);
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(10.0);
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 90;
					}
				}
				catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
				{
					if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)9)
					{
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY().Clear();
					}
					if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104554), new object[]
						{
							#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
						});
					}
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K));
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(10.0);
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 90;
				}
				catch (Exception #=zN_s5Z5A=)
				{
					if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104554), new object[]
						{
							#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
						});
					}
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zL5jsuAE=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zou$WkksUfMBE = DateTime.Now + TimeSpan.FromMinutes(10.0);
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g== = 90;
				}
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z7jFoQg9jFkJ$(true);
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zIzrzKG0SnY5X();
				if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942493), Array.Empty<object>());
				}
				if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zClaXzZj7xRP6eRQGVw== >= #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zT4UU0xuTbhVkq6gV2g==)
				{
					try
					{
						List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY();
						object[] array = new object[list2.Count];
						for (int i = 0; i < array.Length; i++)
						{
							array[i] = list2[i].#=z9Yordw6ZFjQe();
						}
						object[] array2 = JSONManager.GetArray(JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z7hPlwc__UnvN(new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
								(int)#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zQ4wZnctPyyRO())
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								array
							}
						})), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
						if (array2 != null)
						{
							foreach (Dictionary<string, object> dictionary in array2)
							{
								string text3 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), string.Empty);
								if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z$QMRdIKJA2M4vKNwVA==.Contains(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927871), text3)))
								{
									int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
									object[] array4 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909010257));
									List<string> list3 = new List<string>();
									foreach (object value in array4)
									{
										list3.Add(Convert.ToString(value));
									}
									Dictionary<string, object> #=z8e5z318= = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
									foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY())
									{
										if (list3.Contains(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe()))
										{
											foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
											{
												if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == num)
												{
													#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(Task.#=zErO$$v4=(#=z8e5z318=, null));
													#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
												}
											}
										}
									}
									#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
									#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$QMRdIKJA2M4vKNwVA== = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$QMRdIKJA2M4vKNwVA== + text3 + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051837);
								}
							}
						}
					}
					catch (Exception ex)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927851), new object[]
						{
							ex.Message
						});
					}
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zClaXzZj7xRP6eRQGVw== = 0;
				}
				else
				{
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zClaXzZj7xRP6eRQGVw==++;
				}
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zTcpqtfI= = false;
			}
		}
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x00040F58 File Offset: 0x0003F158
	private void #=zKmAxxeI=()
	{
		string #=z0ONi4Bk= = string.Format(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zCBUXJdDks5Kc, GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
		string #=zNt13QGc= = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zFeMULgBuN$zi(this);
		#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, #=zNt13QGc=, null, true);
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x00040F84 File Offset: 0x0003F184
	public static void #=znKPtYpu$_Iui5nzMAw==()
	{
		if (Math.Abs(#=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zT2035AWHYheVm68Ctg==().TotalDays) > 1.5)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927808), Array.Empty<object>());
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zODJV6lumTRqY(new DateTime(1900, 1, 1));
		}
	}

	// Token: 0x0600080D RID: 2061 RVA: 0x00040FE4 File Offset: 0x0003F1E4
	private static AccessLevels #=zt28H$Tj3cxOr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		AccessLevels result;
		try
		{
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
			if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT == null)
			{
				result = AccessLevels.None;
			}
			else if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zL0R09Ps=(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zBoNb_vDDi2WG()))
			{
				result = AccessLevels.None;
			}
			else if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zmWSq0sTYcJfLLSlbyQ==())
			{
				result = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zrM12dgk7c6Mf();
			}
			else
			{
				if (#=z8StzeqE= != null)
				{
					GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
					GameApplicationData.Games games = GameApplicationData.#=zZ2dsDUeWDYAN();
					int i = 0;
					while (i < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count)
					{
						#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY()[i];
						if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCCvotbi$42tS() == #=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe() && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == gameHosters && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN() == games)
						{
							#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z$slFH0_Vf3dL(true);
							if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zDZReNK0=() == AccoutRegistrationResults.Successful)
							{
								if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zvnZc$RhG_1Du() > AccessLevels.None)
								{
									Dictionary<AccessLevels, int> dictionary = new Dictionary<AccessLevels, int>();
									for (int j = 0; j < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count; j++)
									{
										#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2 = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY()[j];
										if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zvnZc$RhG_1Du() > AccessLevels.None)
										{
											if (dictionary.ContainsKey(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zvnZc$RhG_1Du()))
											{
												Dictionary<AccessLevels, int> dictionary2 = dictionary;
												AccessLevels key = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zvnZc$RhG_1Du();
												dictionary2[key] += #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zuAUSO_bM1Gri();
											}
											else
											{
												dictionary[#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zvnZc$RhG_1Du()] = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zuAUSO_bM1Gri();
											}
										}
									}
									bool flag = true;
									for (int k = 0; k < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zBPfdebBv4RQN().Count; k++)
									{
										#=z20QKvPoEBQeZntMw4AkDy90Awj_Z #=z20QKvPoEBQeZntMw4AkDy90Awj_Z = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zBPfdebBv4RQN()[k];
										if (dictionary.ContainsKey(#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zvnZc$RhG_1Du()))
										{
											if (dictionary[#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zvnZc$RhG_1Du()] > #=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=z6O$zzzXbpQKK() * 100)
											{
												flag = false;
												break;
											}
											dictionary.Remove(#=z20QKvPoEBQeZntMw4AkDy90Awj_Z.#=zvnZc$RhG_1Du());
										}
									}
									if (dictionary.Count > 0)
									{
										flag = false;
									}
									if (!flag)
									{
										for (int l = 0; l < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count; l++)
										{
											#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY()[l].#=zFzGvi_S6jJhE(AccessLevels.None);
										}
									}
								}
								return #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zvnZc$RhG_1Du();
							}
							return AccessLevels.NotRegistered;
						}
						else
						{
							i++;
						}
					}
				}
				result = AccessLevels.NotRegistered;
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			result = AccessLevels.None;
		}
		return result;
	}

	// Token: 0x0600080E RID: 2062 RVA: 0x00041220 File Offset: 0x0003F420
	public static int #=zpGeTUhk0$z9R()
	{
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
		int num = 0;
		for (int i = 0; i < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count; i++)
		{
			#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY()[i];
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zvnZc$RhG_1Du() > AccessLevels.None)
			{
				num += #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zuAUSO_bM1Gri();
			}
		}
		if (num % 100 > 0)
		{
			return num / 100 + 1;
		}
		return num / 100;
	}

	// Token: 0x0600080F RID: 2063 RVA: 0x0004127C File Offset: 0x0003F47C
	private static bool #=zL0R09Ps=(DateTime #=zt_FFMBE=)
	{
		return #=zt_FFMBE= < JSONManager.CurrentUTCDate();
	}

	// Token: 0x06000810 RID: 2064 RVA: 0x0004128C File Offset: 0x0003F48C
	public static string #=zK3aDXykDxiue(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string text = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=z8StzeqE=).ToString();
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < text.Length; i++)
		{
			if (char.IsUpper(text[i]))
			{
				stringBuilder.Append(text[i]);
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000811 RID: 2065 RVA: 0x000412E8 File Offset: 0x0003F4E8
	private static bool #=zZdU226d7_zh7(AccessLevels #=z5w6HcG4=)
	{
		return #=z5w6HcG4= >= AccessLevels.Standard;
	}

	// Token: 0x06000812 RID: 2066 RVA: 0x000412F4 File Offset: 0x0003F4F4
	public static bool #=zeN7AHdfQJNd1(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=z8StzeqE=));
	}

	// Token: 0x06000813 RID: 2067 RVA: 0x00041304 File Offset: 0x0003F504
	private static bool #=zeN7AHdfQJNd1(AccessLevels #=z5w6HcG4=)
	{
		return #=z5w6HcG4= >= AccessLevels.Premium || #=z5w6HcG4= == AccessLevels.PremiumInactive;
	}

	// Token: 0x06000814 RID: 2068 RVA: 0x00041314 File Offset: 0x0003F514
	public static bool #=zdYIzg6l2nfKFX3LUnA==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=z8StzeqE=));
	}

	// Token: 0x06000815 RID: 2069 RVA: 0x00041324 File Offset: 0x0003F524
	private static bool #=zdYIzg6l2nfKFX3LUnA==(AccessLevels #=z5w6HcG4=)
	{
		return #=z5w6HcG4= >= AccessLevels.Xtreme;
	}

	// Token: 0x06000816 RID: 2070 RVA: 0x00041334 File Offset: 0x0003F534
	public static bool #=z5Sl0mODf9vA5()
	{
		List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> list = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zBPfdebBv4RQN();
		return list.Count > 0 && list[0].#=zvnZc$RhG_1Du() == AccessLevels.Author;
	}

	// Token: 0x06000817 RID: 2071 RVA: 0x0004136C File Offset: 0x0003F56C
	public static bool #=zoLApeJ0pWgroDmMCgQ==()
	{
		return !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z27xw9AtrFib$();
	}

	// Token: 0x06000818 RID: 2072 RVA: 0x0004137C File Offset: 0x0003F57C
	public static int #=zuz_M2jEYZbqf()
	{
		return #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zuz_M2jEYZbqf(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=());
	}

	// Token: 0x06000819 RID: 2073 RVA: 0x00041388 File Offset: 0x0003F588
	private static int #=zuz_M2jEYZbqf(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zNraCe1Y=)
	{
		int num = 0;
		for (int i = 0; i < #=zNraCe1Y=.#=zBPfdebBv4RQN().Count; i++)
		{
			num += #=zNraCe1Y=.#=zBPfdebBv4RQN()[i].#=z6O$zzzXbpQKK();
		}
		return num;
	}

	// Token: 0x0600081A RID: 2074 RVA: 0x000413C4 File Offset: 0x0003F5C4
	public AccessLevels #=zrM12dgk7c6Mf()
	{
		List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> list = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zBPfdebBv4RQN();
		if (list.Count > 0)
		{
			return list[0].#=zvnZc$RhG_1Du();
		}
		return AccessLevels.None;
	}

	// Token: 0x0600081B RID: 2075 RVA: 0x000413F4 File Offset: 0x0003F5F4
	public static bool #=zcc0cnYs5WkmZ(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zz5ZPPqg2d3qG)
	{
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
		if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zNc3SMEwRW2Y7())
		{
			return false;
		}
		AccessLevels accessLevels = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=z8StzeqE=);
		if (accessLevels == AccessLevels.None)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927783), Array.Empty<object>());
			int num = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zuz_M2jEYZbqf(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT);
			if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count > num)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927749), new object[]
				{
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Count,
					num
				});
			}
			return false;
		}
		if (accessLevels == AccessLevels.PremiumInactive)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927887), Array.Empty<object>());
			return false;
		}
		if (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Sparta && (accessLevels == AccessLevels.MultiExclude || accessLevels == AccessLevels.PremiumExclude))
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927562), Array.Empty<object>());
			return false;
		}
		if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zH2ngPbbyUE9U && !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zoLApeJ0pWgroDmMCgQ==())
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927505), Array.Empty<object>());
			return false;
		}
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zmWSq0sTYcJfLLSlbyQ==())
		{
			int num2 = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zuz_M2jEYZbqf(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT);
			if (#=zz5ZPPqg2d3qG > num2)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927701), new object[]
				{
					#=zz5ZPPqg2d3qG,
					num2
				});
				return false;
			}
		}
		if (accessLevels == AccessLevels.NotRegistered)
		{
			#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zCxHD3w0bmUUD(#=z8StzeqE=);
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl == null)
			{
				return false;
			}
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zDZReNK0=() != AccoutRegistrationResults.Successful)
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x00041564 File Offset: 0x0003F764
	public static bool #=zFaAgw7POs43y(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, TaskTypes #=zmV6257E=)
	{
		if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zcc0cnYs5WkmZ(#=z8StzeqE=, 1))
		{
			return false;
		}
		AccessLevels #=z5w6HcG4= = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zt28H$Tj3cxOr(#=z8StzeqE=);
		bool flag;
		if (#=zmV6257E= <= TaskTypes.UpgradeGenerals)
		{
			if (#=zmV6257E= <= TaskTypes.ExchangeResources)
			{
				if (#=zmV6257E= != TaskTypes.EmporiaCapture && #=zmV6257E= != TaskTypes.ExchangeResources)
				{
					goto IL_71;
				}
			}
			else if (#=zmV6257E= != TaskTypes.MassOccupation && #=zmV6257E= - TaskTypes.AutoRobberyStart > 2)
			{
				goto IL_71;
			}
		}
		else if (#=zmV6257E= <= TaskTypes.MassAttackExecute)
		{
			if (#=zmV6257E= != TaskTypes.TechSchemasStockExchange && #=zmV6257E= - TaskTypes.MassAttackManage > 1)
			{
				goto IL_71;
			}
		}
		else if (#=zmV6257E= != TaskTypes.BuyInCoalitionShop)
		{
			if (#=zmV6257E= == TaskTypes.UpdateLoginsTable)
			{
				flag = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z5Sl0mODf9vA5();
				goto IL_78;
			}
			if (#=zmV6257E= != TaskTypes.Initiation)
			{
				goto IL_71;
			}
		}
		flag = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=z5w6HcG4=);
		goto IL_78;
		IL_71:
		flag = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zZdU226d7_zh7(#=z5w6HcG4=);
		IL_78:
		if (!flag)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zwxyx_F3Vi0PD(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927632), new object[]
			{
				#=zmV6257E=.ToString()
			});
			return false;
		}
		return true;
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x0004161C File Offset: 0x0003F81C
	public static #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=zCxHD3w0bmUUD(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zLXwBvF2Br4Z6a$vNWvLyW2s= #=zLXwBvF2Br4Z6a$vNWvLyW2s= = new #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zLXwBvF2Br4Z6a$vNWvLyW2s=();
		#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE= = #=z8StzeqE=;
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
		#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Find(new Predicate<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>(#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=zBiTvjvGhx64CkIsVYsteS44=));
		if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl != null && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zDZReNK0=() != AccoutRegistrationResults.Successful && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCa0AyEddce6P() > DateTime.Now - TimeSpan.FromMinutes(60.0))
		{
			return #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl;
		}
		if (!#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zObGzldk_Y5$c())
		{
			return null;
		}
		#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2 = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zPXfWr_IJGy1A(#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15());
		object obj = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zSV4$mlFB34WM;
		#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl result;
		lock (obj)
		{
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2 != null)
			{
				if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl == null || #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zvnZc$RhG_1Du() == AccessLevels.NotRegistered)
				{
					if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zDZReNK0=() == AccoutRegistrationResults.Successful)
					{
						#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927344), Array.Empty<object>());
					}
					else
					{
						if (string.IsNullOrEmpty(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zfrnDBNz$xQBu()))
						{
							switch (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zDZReNK0=())
							{
							case AccoutRegistrationResults.MaxAccountNumExceed:
								#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zdsiwBTS4ofKZ(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927298)));
								break;
							case AccoutRegistrationResults.AccountKeyRestricted:
								#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zdsiwBTS4ofKZ(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927247)));
								break;
							case AccoutRegistrationResults.ForbiddenRepeatedRegister:
								#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zdsiwBTS4ofKZ(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927438)));
								break;
							}
						}
						if (!string.IsNullOrEmpty(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zfrnDBNz$xQBu()))
						{
							#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927374), new object[]
							{
								#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zfrnDBNz$xQBu()
							});
						}
						else
						{
							#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927079), Array.Empty<object>());
						}
					}
					if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl != null)
					{
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Remove(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl);
					}
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY().Add(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2);
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zKmAxxeI=();
					result = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2;
				}
				else
				{
					result = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl;
				}
			}
			else
			{
				#=zLXwBvF2Br4Z6a$vNWvLyW2s=.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908927034), Array.Empty<object>());
				result = null;
			}
		}
		return result;
	}

	// Token: 0x0600081E RID: 2078 RVA: 0x00041848 File Offset: 0x0003FA48
	public static void #=zvuVAl$GL8W_$(string #=zDu2ZTOnSae3g, GameApplicationData.GameHosters #=z74XFXnQ7Q8Ia, GameApplicationData.Games #=zR2PWq$tkHfd5)
	{
		#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zvuVAl$GL8W_$(#=zDu2ZTOnSae3g, #=z74XFXnQ7Q8Ia, #=zR2PWq$tkHfd5);
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$yO$QkY=(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zVZd$8ug=());
	}

	// Token: 0x0600081F RID: 2079 RVA: 0x00041864 File Offset: 0x0003FA64
	public static void #=zWF51hHDlgzMZ()
	{
		#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zvuVAl$GL8W_$(null, (GameApplicationData.GameHosters)0, (GameApplicationData.Games)0);
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z$yO$QkY=(#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zVZd$8ug=());
	}

	// Token: 0x04000492 RID: 1170
	private static string #=zCBUXJdDks5Kc = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942977);

	// Token: 0x04000493 RID: 1171
	private bool #=zU3pUoGbbbQ7e2IXLdQ==;

	// Token: 0x04000494 RID: 1172
	private string #=zZlZW7E0$79DKYupoZw==;

	// Token: 0x04000495 RID: 1173
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000496 RID: 1174
	private List<#=z20QKvPoEBQeZntMw4AkDy90Awj_Z> #=zATrXbudnGdMpS8oALA==;

	// Token: 0x04000497 RID: 1175
	private DateTime #=zDFyHbhY8vowXIHy6gAMUa3k=;

	// Token: 0x04000498 RID: 1176
	private bool #=ziAKiZ37QAxcQ94mMwrVR9tk=;

	// Token: 0x04000499 RID: 1177
	private bool #=zlFiwGkLD9hXcWXRCQ86J218=;

	// Token: 0x0400049A RID: 1178
	private int #=zROPj4H79bf1QPgFwClor9mQnCFkN3pazCHYd1bQ=;

	// Token: 0x0400049B RID: 1179
	private int #=zrO2$QPouI9xj1S$_pZfVXN$xiJ5hGsTZlW2lglM=;

	// Token: 0x0400049C RID: 1180
	private string #=zMUWZqaYIG9GBGxTFGQ==;

	// Token: 0x0400049D RID: 1181
	private List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zE4nL0joTP9M_JnPBOQ==;

	// Token: 0x0400049E RID: 1182
	private string #=zjgDXgbkVXsnH;

	// Token: 0x0400049F RID: 1183
	private string #=z7d2dWYYz2_Hu;

	// Token: 0x040004A0 RID: 1184
	private bool #=zH2ngPbbyUE9U;

	// Token: 0x040004A1 RID: 1185
	private Action #=zIzrzKG0SnY5X;

	// Token: 0x040004A2 RID: 1186
	private DateTime #=zou$WkksUfMBE;

	// Token: 0x040004A3 RID: 1187
	private int #=zClaXzZj7xRP6eRQGVw==;

	// Token: 0x040004A4 RID: 1188
	private int #=zT4UU0xuTbhVkq6gV2g==;

	// Token: 0x040004A5 RID: 1189
	private string #=z$QMRdIKJA2M4vKNwVA==;

	// Token: 0x040004A6 RID: 1190
	private static bool #=zTcpqtfI= = false;

	// Token: 0x040004A7 RID: 1191
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x040004A8 RID: 1192
	private DateTime #=zYQDjTc6Y57pZNQ85dPEsPhc= = DateTime.MinValue;

	// Token: 0x040004A9 RID: 1193
	private static #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zeXg6qLKcPK0s = null;

	// Token: 0x02000136 RID: 310
	private sealed class #=zLXwBvF2Br4Z6a$vNWvLyW2s=
	{
		// Token: 0x06000821 RID: 2081 RVA: 0x00041888 File Offset: 0x0003FA88
		internal bool #=zBiTvjvGhx64CkIsVYsteS44=(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z1_H9FhQ=)
		{
			return #=z1_H9FhQ=.#=zCCvotbi$42tS() == this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe() && #=z1_H9FhQ=.#=z7wsmjLWw49AC() == GameApplicationData.#=z7wsmjLWw49AC() && #=z1_H9FhQ=.#=zZ2dsDUeWDYAN() == GameApplicationData.#=zZ2dsDUeWDYAN();
		}

		// Token: 0x040004AA RID: 1194
		public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;
	}
}
