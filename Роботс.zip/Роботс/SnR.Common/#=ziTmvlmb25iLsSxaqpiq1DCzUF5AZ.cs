﻿using System;
using System.Collections;
using System.IO;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x0200025E RID: 606
internal sealed class #=ziTmvlmb25iLsSxaqpiq1DCzUF5AZ : #=zZ$R16GhWBF9T3o7$kk5QJk8=
{
	// Token: 0x06001260 RID: 4704 RVA: 0x00090758 File Offset: 0x0008E958
	public #=ziTmvlmb25iLsSxaqpiq1DCzUF5AZ(string #=zTRA8u0c=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, WorkbookSettings #=z4JisLog=)
	{
		this.#=zdsV3iBbBdGzM = #=zTRA8u0c=;
		this.#=z6bRJXNQ= = #=z4JisLog=;
		this.#=z$qdebj6dfyrP = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
	}

	// Token: 0x06001262 RID: 4706 RVA: 0x00090798 File Offset: 0x0008E998
	private ArrayList #=zaYMx8G8s7kyr()
	{
		ArrayList arrayList = new ArrayList();
		#=z1yuYjQXH4nEyt3SccyfPX9D2D9EN #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN = new #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN(this.#=zdsV3iBbBdGzM);
		#=z1yuYjQXH4nEyt3SccyfPX9D2D9EN.#=zqi7Ie2gUQ822(this.#=z$qdebj6dfyrP);
		#=z1yuYjQXH4nEyt3SccyfPX9D2D9EN.#=zsJ5QVYmSq3En(this.#=zLJGAifU=);
		try
		{
			for (#=zoImewjUBfkPyF1oU_G4atTk= value = #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN.#=zDuKUJOe5JTYV(); value != null; value = #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN.#=zDuKUJOe5JTYV())
			{
				arrayList.Add(value);
			}
		}
		catch (IOException ex)
		{
			#=ziTmvlmb25iLsSxaqpiq1DCzUF5AZ.#=zJLdzGuI=.warn(ex.Message);
		}
		catch (ApplicationException)
		{
			throw new FormulaException(FormulaException.#=zu_jIt38=, this.#=zdsV3iBbBdGzM + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079928) + #=z1yuYjQXH4nEyt3SccyfPX9D2D9EN.#=zK7OiD87uox7o().ToString());
		}
		return arrayList;
	}

	// Token: 0x06001263 RID: 4707 RVA: 0x0009084C File Offset: 0x0008EA4C
	public string #=zmUYpUBj2v7o$()
	{
		if (this.#=zsz1EcJTtTP8C == null)
		{
			StringBuilder stringBuilder = new StringBuilder();
			this.#=zUQxuxX4=.#=zSpOkW5A=(stringBuilder);
			this.#=zsz1EcJTtTP8C = stringBuilder.ToString();
		}
		return this.#=zsz1EcJTtTP8C;
	}

	// Token: 0x06001264 RID: 4708 RVA: 0x00090888 File Offset: 0x0008EA88
	public sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = this.#=zUQxuxX4=.#=ztbIWLuVjfGLU();
		if (this.#=zUQxuxX4=.#=zgKtpZzY=())
		{
			sbyte[] array2 = new sbyte[array.Length + 4];
			Array.Copy(array, 0, array2, 4, array.Length);
			array2[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=.#=zd$BbM3Y=();
			array2[1] = 1;
			array = array2;
		}
		return array;
	}

	// Token: 0x06001265 RID: 4709 RVA: 0x000908DC File Offset: 0x0008EADC
	public void #=zGgEMxSM=()
	{
		ArrayList #=zn2WmVgI= = this.#=zaYMx8G8s7kyr();
		this.#=zUQxuxX4= = this.#=zD1DIly4=(#=zn2WmVgI=);
	}

	// Token: 0x06001266 RID: 4710 RVA: 0x00090900 File Offset: 0x0008EB00
	private #=zoImewjUBfkPyF1oU_G4atTk= #=zD1DIly4=(ArrayList #=zn2WmVgI=)
	{
		Stack stack = new Stack();
		Stack stack2 = new Stack();
		Stack stack3 = null;
		bool flag = false;
		#=zoImewjUBfkPyF1oU_G4atTk= #=zoImewjUBfkPyF1oU_G4atTk= = null;
		using (IEnumerator enumerator = #=zn2WmVgI=.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				object obj = enumerator.Current;
				#=zoImewjUBfkPyF1oU_G4atTk= #=zoImewjUBfkPyF1oU_G4atTk=2 = (#=zoImewjUBfkPyF1oU_G4atTk=)obj;
				if (flag)
				{
					break;
				}
				if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=zsackb8N$OhpeUQLwxSU_3Lg=)
				{
					stack.Push(#=zoImewjUBfkPyF1oU_G4atTk=2);
				}
				else if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=zya1IgD5Efg9ZmZdd$BLsbHs=)
				{
					this.#=zfrV939WdQoKZ((#=zya1IgD5Efg9ZmZdd$BLsbHs=)#=zoImewjUBfkPyF1oU_G4atTk=2, #=zn2WmVgI=, stack);
				}
				else if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=zrACqpkJvpkMu2ypmK4UXXdQ=)
				{
					#=zrACqpkJvpkMu2ypmK4UXXdQ= #=zrACqpkJvpkMu2ypmK4UXXdQ= = (#=zrACqpkJvpkMu2ypmK4UXXdQ=)#=zoImewjUBfkPyF1oU_G4atTk=2;
					if (#=zrACqpkJvpkMu2ypmK4UXXdQ= is #=z36JBXQyrOsCqlqj$QTz_Lzc=)
					{
						#=z36JBXQyrOsCqlqj$QTz_Lzc= #=z36JBXQyrOsCqlqj$QTz_Lzc= = (#=z36JBXQyrOsCqlqj$QTz_Lzc=)#=zrACqpkJvpkMu2ypmK4UXXdQ=;
						if (stack.Count <= 0 || #=zoImewjUBfkPyF1oU_G4atTk= is #=zrACqpkJvpkMu2ypmK4UXXdQ=)
						{
							#=zrACqpkJvpkMu2ypmK4UXXdQ= = #=z36JBXQyrOsCqlqj$QTz_Lzc=.#=zlyKJojCmkfuG();
						}
						else
						{
							#=zrACqpkJvpkMu2ypmK4UXXdQ= = #=z36JBXQyrOsCqlqj$QTz_Lzc=.#=zZAPsYpRBEGf_();
						}
					}
					if (stack2.Count <= 0)
					{
						stack2.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=);
					}
					else
					{
						#=zrACqpkJvpkMu2ypmK4UXXdQ= #=zrACqpkJvpkMu2ypmK4UXXdQ=2 = (#=zrACqpkJvpkMu2ypmK4UXXdQ=)stack2.Peek();
						if (#=zrACqpkJvpkMu2ypmK4UXXdQ=.#=zXiDCyaHY58$0() < #=zrACqpkJvpkMu2ypmK4UXXdQ=2.#=zXiDCyaHY58$0())
						{
							stack2.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=);
						}
						else
						{
							stack2.Pop();
							#=zrACqpkJvpkMu2ypmK4UXXdQ=2.#=zb$ssayA=(stack);
							stack.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=2);
							stack2.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=);
						}
					}
				}
				else if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=zEXYK_umUb2AVdmteSIANd1sVlDma)
				{
					while (stack2.Count > 0)
					{
						#=zrACqpkJvpkMu2ypmK4UXXdQ= #=zrACqpkJvpkMu2ypmK4UXXdQ=3 = (#=zrACqpkJvpkMu2ypmK4UXXdQ=)stack2.Pop();
						#=zrACqpkJvpkMu2ypmK4UXXdQ=3.#=zb$ssayA=(stack);
						stack.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=3);
					}
					if (stack3 == null)
					{
						stack3 = new Stack();
					}
					stack3.Push(stack.Pop());
					stack.Clear();
				}
				else if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=z6cy6tUTuwcUEnm8g5QDGa6YOEpyz)
				{
					#=zoImewjUBfkPyF1oU_G4atTk= #=zoImewjUBfkPyF1oU_G4atTk=3 = this.#=zD1DIly4=(#=zn2WmVgI=);
					#=ztrvdaaecFaDOU3dtdEtTmfs= #=ztrvdaaecFaDOU3dtdEtTmfs= = new #=ztrvdaaecFaDOU3dtdEtTmfs=();
					#=zoImewjUBfkPyF1oU_G4atTk=3.#=zn2dh4vc=(#=ztrvdaaecFaDOU3dtdEtTmfs=);
					#=ztrvdaaecFaDOU3dtdEtTmfs=.#=zdJYbEvQ=(#=zoImewjUBfkPyF1oU_G4atTk=3);
					stack.Push(#=ztrvdaaecFaDOU3dtdEtTmfs=);
				}
				else if (#=zoImewjUBfkPyF1oU_G4atTk=2 is #=zAwfcpmMuOjMkYcf_C4vnZwMbC5St)
				{
					flag = true;
				}
				#=zoImewjUBfkPyF1oU_G4atTk= = #=zoImewjUBfkPyF1oU_G4atTk=2;
			}
			goto IL_1DF;
		}
		IL_1C2:
		#=zrACqpkJvpkMu2ypmK4UXXdQ= #=zrACqpkJvpkMu2ypmK4UXXdQ=4 = (#=zrACqpkJvpkMu2ypmK4UXXdQ=)stack2.Pop();
		#=zrACqpkJvpkMu2ypmK4UXXdQ=4.#=zb$ssayA=(stack);
		stack.Push(#=zrACqpkJvpkMu2ypmK4UXXdQ=4);
		IL_1DF:
		if (stack2.Count <= 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zoImewjUBfkPyF1oU_G4atTk=4 = (stack.Count > 0) ? ((#=zoImewjUBfkPyF1oU_G4atTk=)stack.Pop()) : null;
			if (stack3 != null && #=zoImewjUBfkPyF1oU_G4atTk=4 != null)
			{
				stack3.Push(#=zoImewjUBfkPyF1oU_G4atTk=4);
			}
			this.#=zXd8eE_4= = stack3;
			if (stack.Count > 0 || stack2.Count > 0)
			{
				#=ziTmvlmb25iLsSxaqpiq1DCzUF5AZ.#=zJLdzGuI=.warn(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079913) + this.#=zdsV3iBbBdGzM + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079896));
			}
			return #=zoImewjUBfkPyF1oU_G4atTk=4;
		}
		goto IL_1C2;
	}

	// Token: 0x06001267 RID: 4711 RVA: 0x00090B80 File Offset: 0x0008ED80
	private void #=zfrV939WdQoKZ(#=zya1IgD5Efg9ZmZdd$BLsbHs= #=zeIs4bFM=, ArrayList #=zn2WmVgI=, Stack #=z3p0QK_4=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4= = this.#=zD1DIly4=(#=zn2WmVgI=);
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=) == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zNUFwPq0=)
		{
			throw new FormulaException(FormulaException.#=zAy$UZry2YS1XUZrXrCUyOXk=);
		}
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=) == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zS_qq6Ks= && this.#=zXd8eE_4= == null)
		{
			#=zKtn4_SrRtk6XXy4d83LlFV0= #=zKtn4_SrRtk6XXy4d83LlFV0= = new #=zKtn4_SrRtk6XXy4d83LlFV0=(#=zeIs4bFM=, this.#=z6bRJXNQ=);
			#=zKtn4_SrRtk6XXy4d83LlFV0=.#=zdJYbEvQ=(#=zpvGJrv4=);
			#=z3p0QK_4=.Push(#=zKtn4_SrRtk6XXy4d83LlFV0=);
			return;
		}
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=) == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zJ$VOQdA=)
		{
			#=zKtn4_SrRtk6XXy4d83LlFV0= #=zKtn4_SrRtk6XXy4d83LlFV0=2 = new #=zKtn4_SrRtk6XXy4d83LlFV0=(#=zeIs4bFM=, this.#=z6bRJXNQ=);
			#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q = new #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(this.#=z6bRJXNQ=);
			object[] array = this.#=zXd8eE_4=.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q.#=zdJYbEvQ=((#=zoImewjUBfkPyF1oU_G4atTk=)array[i]);
			}
			#=zKtn4_SrRtk6XXy4d83LlFV0=2.#=zVy1K$GX42gsg(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q);
			#=z3p0QK_4=.Push(#=zKtn4_SrRtk6XXy4d83LlFV0=2);
			return;
		}
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=).#=z7z0EEAB0rXFG() != 255)
		{
			#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_ #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_ = new #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_(#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=), this.#=z6bRJXNQ=);
			int num = #=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=).#=z7z0EEAB0rXFG();
			if (num == 1)
			{
				#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_.#=zdJYbEvQ=(#=zpvGJrv4=);
			}
			else
			{
				if ((this.#=zXd8eE_4= == null && num != 0) || (this.#=zXd8eE_4= != null && num != this.#=zXd8eE_4=.Count))
				{
					throw new FormulaException(FormulaException.#=ziZAS18kN$eCgTHpHcA==);
				}
				object[] array2 = this.#=zXd8eE_4=.ToArray();
				for (int j = 0; j < num; j++)
				{
					#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_.#=zdJYbEvQ=((#=zoImewjUBfkPyF1oU_G4atTk=)array2[j]);
				}
			}
			#=z3p0QK_4=.Push(#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_);
			return;
		}
		if (this.#=zXd8eE_4= == null)
		{
			#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q2 = new #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=), 1, this.#=z6bRJXNQ=);
			#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q2.#=zdJYbEvQ=(#=zpvGJrv4=);
			#=z3p0QK_4=.Push(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q2);
			return;
		}
		int count = this.#=zXd8eE_4=.Count;
		#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q3 = new #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=), count, this.#=z6bRJXNQ=);
		for (int k = 0; k < count; k++)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4=2 = (#=zoImewjUBfkPyF1oU_G4atTk=)this.#=zXd8eE_4=.Pop();
			#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q3.#=zdJYbEvQ=(#=zpvGJrv4=2);
		}
		#=z3p0QK_4=.Push(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q3);
		this.#=zXd8eE_4=.Clear();
		this.#=zXd8eE_4= = null;
	}

	// Token: 0x06001268 RID: 4712 RVA: 0x00090DAC File Offset: 0x0008EFAC
	public void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		this.#=zUQxuxX4=.#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
	}

	// Token: 0x06001269 RID: 4713 RVA: 0x00090DBC File Offset: 0x0008EFBC
	public void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x00090DCC File Offset: 0x0008EFCC
	public void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x00090DDC File Offset: 0x0008EFDC
	public void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x0600126C RID: 4716 RVA: 0x00090DEC File Offset: 0x0008EFEC
	public void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x04000A9B RID: 2715
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=ziTmvlmb25iLsSxaqpiq1DCzUF5AZ));

	// Token: 0x04000A9C RID: 2716
	private string #=zdsV3iBbBdGzM;

	// Token: 0x04000A9D RID: 2717
	private string #=zsz1EcJTtTP8C;

	// Token: 0x04000A9E RID: 2718
	private #=zoImewjUBfkPyF1oU_G4atTk= #=zUQxuxX4=;

	// Token: 0x04000A9F RID: 2719
	private Stack #=zXd8eE_4=;

	// Token: 0x04000AA0 RID: 2720
	private WorkbookSettings #=z6bRJXNQ=;

	// Token: 0x04000AA1 RID: 2721
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x04000AA2 RID: 2722
	private WorkbookMethods #=zLJGAifU=;
}
