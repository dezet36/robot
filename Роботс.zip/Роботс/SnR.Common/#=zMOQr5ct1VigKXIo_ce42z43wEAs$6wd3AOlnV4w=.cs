﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x02000162 RID: 354
internal sealed class #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= : Task
{
	// Token: 0x06000959 RID: 2393 RVA: 0x0004C628 File Offset: 0x0004A828
	public #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=(TimeSpan #=zwqcPfATuimvUnjjg$A==) : base(TaskSources.ManualNotSavable, TaskSeverities.Background, TaskTypes.AutoRobbery, DateTime.Now, TimeSpan.Zero, TimeSpan.FromSeconds(60.0), TimeSpan.FromSeconds(60.0), DateTime.MaxValue, true)
	{
		this.#=zpBfn6r1zNq_pLwELOQ==(DateTime.Now);
		this.#=z8uK0PRffgr7wFZ9DRg==(new List<#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1>());
		this.#=zORTAr0PYVZMAmxSIft1lGlQ=(#=zwqcPfATuimvUnjjg$A==);
		this.#=zUMHLzk0YzhFh(new #=zCn6$dSEIeGKpKiH$kWD3okBGgnU4());
		this.#=zP9nJD5fkPIBZftsclxGxPg3GZMBgzgzLAeCdBvBpvqMk(1);
		this.#=zWF8G8qD8vQtGjS8Y8lpaTFM=(DateTime.MaxValue);
	}

	// Token: 0x0600095A RID: 2394 RVA: 0x0004C6A8 File Offset: 0x0004A8A8
	public #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== #=znz2cmfctRYJnk8_ikA==()
	{
		return this.#=zIf98on$ZB6UxBsWGoS6$3LE=;
	}

	// Token: 0x0600095B RID: 2395 RVA: 0x0004C6B0 File Offset: 0x0004A8B0
	public void #=zaG9Dgn2hcyzWaAUsNA==(#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== #=z$Ib9gYQ=)
	{
		this.#=zIf98on$ZB6UxBsWGoS6$3LE= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600095C RID: 2396 RVA: 0x0004C6BC File Offset: 0x0004A8BC
	public List<int> #=zpbz203I90pe6jeaNNQ==()
	{
		return this.#=zGCmZ7L_AweiQBMh3X1TPmEMLL14d;
	}

	// Token: 0x0600095D RID: 2397 RVA: 0x0004C6C4 File Offset: 0x0004A8C4
	public void #=ziKpRrk$lWVCJhGJRcA==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zGCmZ7L_AweiQBMh3X1TPmEMLL14d = #=z$Ib9gYQ=;
	}

	// Token: 0x0600095E RID: 2398 RVA: 0x0004C6D0 File Offset: 0x0004A8D0
	public #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=z5_3JqsL118hV()
	{
		return this.#=zLUXgXBJ7ip_y9Q2xIi3YUK0=;
	}

	// Token: 0x0600095F RID: 2399 RVA: 0x0004C6D8 File Offset: 0x0004A8D8
	public void #=zYx4FxxkdU5tE(#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=z$Ib9gYQ=)
	{
		this.#=zLUXgXBJ7ip_y9Q2xIi3YUK0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000960 RID: 2400 RVA: 0x0004C6E4 File Offset: 0x0004A8E4
	public DateTime #=zwfXQmA03imo05bRmQw==()
	{
		return this.#=zxLF3TTXShd1E7xglL1229AOJxXgy;
	}

	// Token: 0x06000961 RID: 2401 RVA: 0x0004C6EC File Offset: 0x0004A8EC
	public void #=zpBfn6r1zNq_pLwELOQ==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zxLF3TTXShd1E7xglL1229AOJxXgy = #=z$Ib9gYQ=;
	}

	// Token: 0x06000962 RID: 2402 RVA: 0x0004C6F8 File Offset: 0x0004A8F8
	public List<int> #=zwao59F9WTZ4llri_3A==()
	{
		return this.#=z2d8iWXVwQDzisWy5kXr5hvjCy8ia;
	}

	// Token: 0x06000963 RID: 2403 RVA: 0x0004C700 File Offset: 0x0004A900
	public void #=zfJg0zSfdHKGW$fTQAQ==(List<int> #=z$Ib9gYQ=)
	{
		this.#=z2d8iWXVwQDzisWy5kXr5hvjCy8ia = #=z$Ib9gYQ=;
	}

	// Token: 0x06000964 RID: 2404 RVA: 0x0004C70C File Offset: 0x0004A90C
	public List<int> #=zfZLfjNugUHq7lHwxyg==()
	{
		return this.#=z50qPTWUHUrjEKl_qMlB2MZyPnMF5;
	}

	// Token: 0x06000965 RID: 2405 RVA: 0x0004C714 File Offset: 0x0004A914
	public void #=zf2xpHQyExsx20x0Byg==(List<int> #=z$Ib9gYQ=)
	{
		this.#=z50qPTWUHUrjEKl_qMlB2MZyPnMF5 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x0004C720 File Offset: 0x0004A920
	public List<UnitSquadCollection> #=zonHNsEoZn7AAb2smew==()
	{
		return this.#=zRMQrlTL6XOC2bKr4MJ_n9244P7Wo;
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x0004C728 File Offset: 0x0004A928
	public void #=zyUXiBfaJ5g4UiO5trA==(List<UnitSquadCollection> #=z$Ib9gYQ=)
	{
		this.#=zRMQrlTL6XOC2bKr4MJ_n9244P7Wo = #=z$Ib9gYQ=;
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x0004C734 File Offset: 0x0004A934
	public List<#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1> #=zsBGQTpOIxxCe6$2KLA==()
	{
		return this.#=zXVglW6u5jW74gCG84LEzSpiyEUY5;
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x0004C73C File Offset: 0x0004A93C
	private void #=z8uK0PRffgr7wFZ9DRg==(List<#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1> #=z$Ib9gYQ=)
	{
		this.#=zXVglW6u5jW74gCG84LEzSpiyEUY5 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x0004C748 File Offset: 0x0004A948
	public int #=zRsQ5gV$zlUjk()
	{
		return this.#=z_JohQ9gdYm1_4TAjqw==;
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x0004C750 File Offset: 0x0004A950
	public void #=zGSYXNAWR258T(int #=z$Ib9gYQ=)
	{
		this.#=z_JohQ9gdYm1_4TAjqw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600096C RID: 2412 RVA: 0x0004C75C File Offset: 0x0004A95C
	public TimeSpan #=znfPjOezUI9V6FOMG_g7VWK8=()
	{
		return this.#=zBiHgoyDka1YakH1sBqYbiUZTKB9B;
	}

	// Token: 0x0600096D RID: 2413 RVA: 0x0004C764 File Offset: 0x0004A964
	public void #=zORTAr0PYVZMAmxSIft1lGlQ=(TimeSpan #=z$Ib9gYQ=)
	{
		this.#=zBiHgoyDka1YakH1sBqYbiUZTKB9B = #=z$Ib9gYQ=;
	}

	// Token: 0x0600096E RID: 2414 RVA: 0x0004C770 File Offset: 0x0004A970
	public #=zCn6$dSEIeGKpKiH$kWD3okBGgnU4 #=znRSpoHRxOsWr()
	{
		return this.#=zmwXwvZFo8$BA6DtElSKMWgE=;
	}

	// Token: 0x0600096F RID: 2415 RVA: 0x0004C778 File Offset: 0x0004A978
	private void #=zUMHLzk0YzhFh(#=zCn6$dSEIeGKpKiH$kWD3okBGgnU4 #=z$Ib9gYQ=)
	{
		this.#=zmwXwvZFo8$BA6DtElSKMWgE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000970 RID: 2416 RVA: 0x0004C784 File Offset: 0x0004A984
	public int #=zCb4PsTBNolywZCYiu4flce3$chIhEQ$MmeYpKxqXplA1()
	{
		return this.#=z1ZRrJgXhP4vBqjhUKa3msFtxQvmTrKaTbA88LWR4zPZTxbq6GQ==;
	}

	// Token: 0x06000971 RID: 2417 RVA: 0x0004C78C File Offset: 0x0004A98C
	public void #=zP9nJD5fkPIBZftsclxGxPg3GZMBgzgzLAeCdBvBpvqMk(int #=z$Ib9gYQ=)
	{
		this.#=z1ZRrJgXhP4vBqjhUKa3msFtxQvmTrKaTbA88LWR4zPZTxbq6GQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000972 RID: 2418 RVA: 0x0004C798 File Offset: 0x0004A998
	public DateTime #=zXk8s4ULAsIXsAvv01hkXUGs=()
	{
		return this.#=zr4o34uTSshRB6z2TyUdElOm_F1uoCcBNAw==;
	}

	// Token: 0x06000973 RID: 2419 RVA: 0x0004C7A0 File Offset: 0x0004A9A0
	public void #=zWF8G8qD8vQtGjS8Y8lpaTFM=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zr4o34uTSshRB6z2TyUdElOm_F1uoCcBNAw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000974 RID: 2420 RVA: 0x0004C7AC File Offset: 0x0004A9AC
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		if (this.#=znz2cmfctRYJnk8_ikA==() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874142)] = this.#=znz2cmfctRYJnk8_ikA==().Serialize();
		}
		if (this.#=zpbz203I90pe6jeaNNQ==() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874121)] = JSONManager.ListToArr(this.#=zpbz203I90pe6jeaNNQ==());
		}
		if (this.#=z5_3JqsL118hV() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873848)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873349),
					this.#=z5_3JqsL118hV().#=zh4f6s4TyRiwr()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873847),
					this.#=z5_3JqsL118hV().Count
				}
			};
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873829)] = JSONManager.DateToUserString(this.#=zwfXQmA03imo05bRmQw==());
		if (this.#=zwao59F9WTZ4llri_3A==() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873812)] = JSONManager.ListToArr(this.#=zwao59F9WTZ4llri_3A==());
		}
		if (this.#=zfZLfjNugUHq7lHwxyg==() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873797)] = JSONManager.ListToArr(this.#=zfZLfjNugUHq7lHwxyg==());
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964025)] = this.#=zRsQ5gV$zlUjk();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873783)] = this.#=znfPjOezUI9V6FOMG_g7VWK8=().TotalHours;
		if (this.#=znRSpoHRxOsWr() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873766)] = this.#=znRSpoHRxOsWr().#=zhv7OhlM=();
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873756)] = this.#=zCb4PsTBNolywZCYiu4flce3$chIhEQ$MmeYpKxqXplA1();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873741)] = JSONManager.DateToUserString(this.#=zXk8s4ULAsIXsAvv01hkXUGs=());
		return dictionary;
	}

	// Token: 0x0400055D RID: 1373
	private #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== #=zIf98on$ZB6UxBsWGoS6$3LE=;

	// Token: 0x0400055E RID: 1374
	private List<int> #=zGCmZ7L_AweiQBMh3X1TPmEMLL14d;

	// Token: 0x0400055F RID: 1375
	private #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zLUXgXBJ7ip_y9Q2xIi3YUK0=;

	// Token: 0x04000560 RID: 1376
	private DateTime #=zxLF3TTXShd1E7xglL1229AOJxXgy;

	// Token: 0x04000561 RID: 1377
	private List<int> #=z2d8iWXVwQDzisWy5kXr5hvjCy8ia;

	// Token: 0x04000562 RID: 1378
	private List<int> #=z50qPTWUHUrjEKl_qMlB2MZyPnMF5;

	// Token: 0x04000563 RID: 1379
	private List<UnitSquadCollection> #=zRMQrlTL6XOC2bKr4MJ_n9244P7Wo;

	// Token: 0x04000564 RID: 1380
	private List<#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1> #=zXVglW6u5jW74gCG84LEzSpiyEUY5;

	// Token: 0x04000565 RID: 1381
	private int #=z_JohQ9gdYm1_4TAjqw==;

	// Token: 0x04000566 RID: 1382
	private TimeSpan #=zBiHgoyDka1YakH1sBqYbiUZTKB9B;

	// Token: 0x04000567 RID: 1383
	private #=zCn6$dSEIeGKpKiH$kWD3okBGgnU4 #=zmwXwvZFo8$BA6DtElSKMWgE=;

	// Token: 0x04000568 RID: 1384
	private int #=z1ZRrJgXhP4vBqjhUKa3msFtxQvmTrKaTbA88LWR4zPZTxbq6GQ==;

	// Token: 0x04000569 RID: 1385
	private DateTime #=zr4o34uTSshRB6z2TyUdElOm_F1uoCcBNAw==;
}
