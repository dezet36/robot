﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x0200027A RID: 634
internal sealed class #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk= : #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=, #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=
{
	// Token: 0x06001320 RID: 4896 RVA: 0x00094DF4 File Offset: 0x00092FF4
	public #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=(string #=zNGc03YwTxm9f)
	{
		this.#=z9HdGFQI= = null;
		if (!string.IsNullOrWhiteSpace(#=zNGc03YwTxm9f) && #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=z84ZpbGPv0D55(#=zNGc03YwTxm9f))
		{
			this.#=z9HdGFQI= = (object[])JSONManager.DeserializeData(#=zNGc03YwTxm9f);
		}
		if (this.#=z9HdGFQI= == null)
		{
			this.#=z9HdGFQI= = new object[0];
		}
		this.#=zr8qQP_eVlWnyHkl2Mw== = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAw1EIzRREaKz_nggig==();
	}

	// Token: 0x06001321 RID: 4897 RVA: 0x00094E50 File Offset: 0x00093050
	public #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=(Dictionary<string, object> #=zxsl97vw0vsKt)
	{
		this.#=z9HdGFQI= = new object[]
		{
			#=zxsl97vw0vsKt
		};
		this.#=zr8qQP_eVlWnyHkl2Mw== = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAw1EIzRREaKz_nggig==();
	}

	// Token: 0x06001322 RID: 4898 RVA: 0x00094E74 File Offset: 0x00093074
	public void #=zxb81q3Y=(Dictionary<string, object> #=z7IhKXao=)
	{
		object[] array = new object[this.#=z9HdGFQI=.Length + 1];
		for (int i = 0; i < this.#=z9HdGFQI=.Length; i++)
		{
			array[i] = this.#=z9HdGFQI=[i];
		}
		array[this.#=z9HdGFQI=.Length] = #=z7IhKXao=;
		this.#=z9HdGFQI= = array;
	}

	// Token: 0x06001323 RID: 4899 RVA: 0x00094EC4 File Offset: 0x000930C4
	public void #=z2_qRu9m1Fd55(int #=z8_JH_IQ=)
	{
		if (#=z8_JH_IQ= < 0 || #=z8_JH_IQ= >= this.#=z9HdGFQI=.Length)
		{
			return;
		}
		object[] array = new object[this.#=z9HdGFQI=.Length - 1];
		for (int i = 0; i < #=z8_JH_IQ=; i++)
		{
			array[i] = this.#=z9HdGFQI=[i];
		}
		for (int j = #=z8_JH_IQ= + 1; j < this.#=z9HdGFQI=.Length; j++)
		{
			array[j - 1] = this.#=z9HdGFQI=[j];
		}
		this.#=z9HdGFQI= = array;
	}

	// Token: 0x06001324 RID: 4900 RVA: 0x00094F34 File Offset: 0x00093134
	public static Dictionary<string, Dictionary<int, string>> #=zwZUcWHU=()
	{
		string #=zNraCe1Y= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874832);
		Dictionary<string, Dictionary<int, string>> dictionary = (Dictionary<string, Dictionary<int, string>>)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zp2obHa8=(#=zNraCe1Y=);
		if (dictionary != null)
		{
			return dictionary;
		}
		dictionary = new Dictionary<string, Dictionary<int, string>>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				new Dictionary<int, string>
				{
					{
						1,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090465)
					},
					{
						2,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090448)
					},
					{
						3,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090432)
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				new Dictionary<int, string>
				{
					{
						1,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874799)
					},
					{
						2,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874774)
					},
					{
						3,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875001)
					},
					{
						4,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874985)
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966),
				new Dictionary<int, string>
				{
					{
						1,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874799)
					},
					{
						2,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874774)
					},
					{
						3,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875001)
					},
					{
						4,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874985)
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				new Dictionary<int, string>
				{
					{
						1,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874969)
					},
					{
						2,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874958)
					},
					{
						3,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874930)
					},
					{
						4,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874913)
					},
					{
						5,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874900)
					},
					{
						6,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876667)
					},
					{
						7,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876652)
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				new Dictionary<int, string>
				{
					{
						1,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876636)
					},
					{
						2,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876606)
					},
					{
						3,
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876583)
					}
				}
			}
		};
		foreach (Dictionary<int, string> dictionary2 in dictionary.Values)
		{
			List<int> list = new List<int>();
			list.AddRange(dictionary2.Keys);
			foreach (int key in list)
			{
				dictionary2[key] = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(dictionary2[key]);
			}
		}
		UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
		List<int> list2 = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAw1EIzRREaKz_nggig==();
		foreach (string text in new List<string>
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)
		})
		{
			Dictionary<int, string> dictionary3 = dictionary[text];
			List<int> list3 = new List<int>();
			foreach (int num in dictionary3.Keys)
			{
				object[] #=zht_dZsXaUsCY = new object[]
				{
					num
				};
				bool flag = false;
				for (int i = 0; i < unitTypeCollection.Count; i++)
				{
					#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY #=zHA4XdxIthrmY = #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zQLl7KKs=(unitTypeCollection[i], text, #=zht_dZsXaUsCY, list2);
					if (#=zHA4XdxIthrmY == (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)1 || #=zHA4XdxIthrmY == (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)2)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					list3.Add(num);
				}
			}
			foreach (int key2 in list3)
			{
				dictionary3.Remove(key2);
			}
		}
		Dictionary<int, string> dictionary4 = new Dictionary<int, string>();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)] = dictionary4;
		for (int j = 0; j < unitTypeCollection.Count; j++)
		{
			UnitType unitType = unitTypeCollection[j];
			if (list2.Contains(unitType.Id))
			{
				dictionary4.Add(unitType.Id, unitType.Name);
			}
		}
		#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOlAKdDM=(#=zNraCe1Y=, dictionary);
		return dictionary;
	}

	// Token: 0x06001325 RID: 4901 RVA: 0x0009538C File Offset: 0x0009358C
	public bool #=zQLl7KKs=(UnitSquad #=zCtbXRq2SiURL)
	{
		return this.#=zQLl7KKs=(#=zCtbXRq2SiURL.Type);
	}

	// Token: 0x06001326 RID: 4902 RVA: 0x0009539C File Offset: 0x0009359C
	public bool #=zQLl7KKs=(UnitType #=zvRLj9WQ=)
	{
		for (int i = 0; i < this.#=z9HdGFQI=.Length; i++)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)this.#=z9HdGFQI=[i];
			bool flag = false;
			foreach (string text in dictionary.Keys)
			{
				object[] array = (object[])dictionary[text];
				if (array != null)
				{
					#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY #=zHA4XdxIthrmY = #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zQLl7KKs=(#=zvRLj9WQ=, text, array, this.#=zr8qQP_eVlWnyHkl2Mw==);
					if (#=zHA4XdxIthrmY != (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)0)
					{
						if (#=zHA4XdxIthrmY == (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)2)
						{
							return true;
						}
					}
					else
					{
						flag = true;
					}
				}
			}
			if (!flag)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06001327 RID: 4903 RVA: 0x00095454 File Offset: 0x00093654
	private static #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY #=zQLl7KKs=(UnitType #=zvRLj9WQ=, string #=zNraCe1Y=, object[] #=zht_dZsXaUsCY, List<int> #=zsMeEu6amRJlJ)
	{
		if (!(#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)))
		{
			if (!(#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)))
			{
				if (!(#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
				{
					if (!(#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)))
					{
						if (!(#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)))
						{
							if (#=zNraCe1Y= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253))
							{
								if (!#=zsMeEu6amRJlJ.Contains(#=zvRLj9WQ=.Id))
								{
									return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)3;
								}
								if (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, #=zvRLj9WQ=.Id) == (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)1)
								{
									return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)2;
								}
								return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)0;
							}
						}
						else
						{
							if (!#=zvRLj9WQ=.IsStrategic)
							{
								return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)3;
							}
							switch (#=zvRLj9WQ=.SpecPower)
							{
							case UnitType.SpecialPowers.None:
								return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 1);
							case UnitType.SpecialPowers.ResurrectMinions:
								return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 2);
							case UnitType.SpecialPowers.DoubleDamageChance:
								return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 3);
							}
						}
					}
					else
					{
						if (#=zvRLj9WQ=.IsStrategic)
						{
							return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)3;
						}
						if (#=zvRLj9WQ=.World == Worlds.Veor)
						{
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 7);
						}
						if (#=zvRLj9WQ=.Resource == UnitType.Resources.Denaries)
						{
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 3);
						}
						switch (#=zvRLj9WQ=.Modification)
						{
						case UnitType.Modifications.Ordinary:
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 1);
						case UnitType.Modifications.Elite:
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 2);
						case UnitType.Modifications.Mutated:
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 4);
						case UnitType.Modifications.Imperial:
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 5);
						case UnitType.Modifications.Noble:
							return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 6);
						}
					}
				}
				else
				{
					if (#=zvRLj9WQ=.World != Worlds.Elisium)
					{
						return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)3;
					}
					if (#=zvRLj9WQ=.IsStrategic)
					{
						return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, new int[]
						{
							1,
							2,
							3,
							4
						});
					}
					switch (#=zvRLj9WQ=.Class)
					{
					case UnitType.Classes.LightInfantry:
						return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 1);
					case UnitType.Classes.HeavyInfantry:
						return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 2);
					case UnitType.Classes.Phalanx:
						return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 3);
					case UnitType.Classes.Cavalry:
						return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 4);
					}
				}
			}
			else
			{
				if (#=zvRLj9WQ=.World == Worlds.Elisium)
				{
					return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)3;
				}
				switch (#=zvRLj9WQ=.Class)
				{
				case UnitType.Classes.LightInfantry:
					return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 1);
				case UnitType.Classes.HeavyInfantry:
					return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 2);
				case UnitType.Classes.Phalanx:
					return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 3);
				case UnitType.Classes.Cavalry:
					return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 4);
				}
			}
		}
		else
		{
			switch (#=zvRLj9WQ=.Function)
			{
			case UnitType.Functions.Offence:
				return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 1);
			case UnitType.Functions.Defence:
				return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 2);
			case UnitType.Functions.Scouting:
				return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, 3);
			case UnitType.Functions.OffenseAndDefense:
				return #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zJz0fOUwt6WZr(#=zht_dZsXaUsCY, new int[]
				{
					1,
					2
				});
			}
		}
		return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)0;
	}

	// Token: 0x06001328 RID: 4904 RVA: 0x000956DC File Offset: 0x000938DC
	private static #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY #=zJz0fOUwt6WZr(object[] #=zyNJipTY=, int #=ze7ZtytQ=)
	{
		for (int i = #=zyNJipTY=.Length - 1; i >= 0; i--)
		{
			if (Convert.ToInt32(#=zyNJipTY=[i]) == #=ze7ZtytQ=)
			{
				return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)1;
			}
		}
		return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)0;
	}

	// Token: 0x06001329 RID: 4905 RVA: 0x00095708 File Offset: 0x00093908
	private static #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY #=zJz0fOUwt6WZr(object[] #=zyNJipTY=, int[] #=zht_dZsXaUsCY)
	{
		for (int i = #=zyNJipTY=.Length - 1; i >= 0; i--)
		{
			for (int j = #=zht_dZsXaUsCY.Length - 1; j >= 0; j--)
			{
				if (Convert.ToInt32(#=zyNJipTY=[i]) == #=zht_dZsXaUsCY[j])
				{
					return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)1;
				}
			}
		}
		return (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zHA4XdxIthrmY)0;
	}

	// Token: 0x0600132A RID: 4906 RVA: 0x00095748 File Offset: 0x00093948
	public static bool #=z84ZpbGPv0D55(string #=zdPovgAA=)
	{
		return !string.IsNullOrEmpty(#=zdPovgAA=) && #=zdPovgAA=[0] == '[';
	}

	// Token: 0x0600132B RID: 4907 RVA: 0x00095760 File Offset: 0x00093960
	public bool #=zcDE8qrwi2sri()
	{
		return this.#=z9HdGFQI=.Length != 0;
	}

	// Token: 0x0600132C RID: 4908 RVA: 0x0009576C File Offset: 0x0009396C
	public bool #=zkOC20NtZ3vNZ()
	{
		return this.#=z9HdGFQI=.Length > 1;
	}

	// Token: 0x0600132D RID: 4909 RVA: 0x0009577C File Offset: 0x0009397C
	public List<int> #=zJL4YNniqVWpk(string #=zNraCe1Y=)
	{
		List<int> list = new List<int>();
		if (this.#=z9HdGFQI=.Length != 1)
		{
			return list;
		}
		Dictionary<string, object> dictionary = (Dictionary<string, object>)this.#=z9HdGFQI=[0];
		if (!dictionary.ContainsKey(#=zNraCe1Y=))
		{
			return list;
		}
		object[] array = (object[])dictionary[#=zNraCe1Y=];
		for (int i = 0; i < array.Length; i++)
		{
			list.Add(Convert.ToInt32(array[i]));
		}
		return list;
	}

	// Token: 0x0600132E RID: 4910 RVA: 0x000957E0 File Offset: 0x000939E0
	public override string ToString()
	{
		return JSONManager.SerializeData(this.#=z9HdGFQI=);
	}

	// Token: 0x0600132F RID: 4911 RVA: 0x000957F0 File Offset: 0x000939F0
	public string ToStringLabels()
	{
		StringBuilder stringBuilder = new StringBuilder();
		Dictionary<string, Dictionary<int, string>> #=zvn3I_mE= = #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zwZUcWHU=();
		for (int i = 0; i < this.#=z9HdGFQI=.Length; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876547));
			}
			stringBuilder.Append(#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zGoc_YKSxzfEy((Dictionary<string, object>)this.#=z9HdGFQI=[i], #=zvn3I_mE=));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06001330 RID: 4912 RVA: 0x00095854 File Offset: 0x00093A54
	public string[] #=zE3XmUE66AJFk()
	{
		string[] array = new string[this.#=z9HdGFQI=.Length];
		Dictionary<string, Dictionary<int, string>> #=zvn3I_mE= = #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zwZUcWHU=();
		for (int i = 0; i < this.#=z9HdGFQI=.Length; i++)
		{
			array[i] = #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=zGoc_YKSxzfEy((Dictionary<string, object>)this.#=z9HdGFQI=[i], #=zvn3I_mE=);
		}
		return array;
	}

	// Token: 0x06001331 RID: 4913 RVA: 0x000958A0 File Offset: 0x00093AA0
	private static string #=zGoc_YKSxzfEy(Dictionary<string, object> #=zl9wEIreVbQj$, Dictionary<string, Dictionary<int, string>> #=zvn3I_mE=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		bool flag = true;
		foreach (string text in #=zl9wEIreVbQj$.Keys)
		{
			object[] array = (object[])#=zl9wEIreVbQj$[text];
			if (array.Length != 0)
			{
				if (!flag)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876793));
				}
				else
				{
					flag = false;
				}
				if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)))
				{
					if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)))
					{
						if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
						{
							if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)))
							{
								if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)))
								{
									if (!(text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)))
									{
										stringBuilder.Append(text);
									}
									else
									{
										stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909016943)));
									}
								}
								else
								{
									stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876756)));
								}
							}
							else
							{
								stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909022901)));
							}
						}
						else
						{
							stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090163)));
						}
					}
					else
					{
						stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876772)));
					}
				}
				else
				{
					stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876790)));
				}
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070981));
				Dictionary<int, string> dictionary = #=zvn3I_mE=.ContainsKey(text) ? #=zvn3I_mE=[text] : new Dictionary<int, string>();
				for (int i = 0; i < array.Length; i++)
				{
					int num = Convert.ToInt32(array[i]);
					if (i > 0)
					{
						stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
					}
					if (dictionary.ContainsKey(num))
					{
						stringBuilder.Append(dictionary[num]);
					}
					else
					{
						stringBuilder.Append(num);
					}
				}
			}
		}
		return stringBuilder.ToString();
	}

	// Token: 0x04000B11 RID: 2833
	private object[] #=z9HdGFQI=;

	// Token: 0x04000B12 RID: 2834
	private List<int> #=zr8qQP_eVlWnyHkl2Mw==;

	// Token: 0x0200027B RID: 635
	private enum #=zHA4XdxIthrmY
	{

	}
}
