﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x0200002B RID: 43
internal class #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000098 RID: 152 RVA: 0x000051A4 File Offset: 0x000033A4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zvPVvZaDW5sGehlg4AA== = #=zuJjQ1XU=.#=zOo2ORcNoE4PzlDAS9fQ8Rc8=();
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zkdGdpYZ7Wpxf = #=zuJjQ1XU=.#=zoSyVTLOhKIN4();
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zWF6MNCHjVXd5 = #=zuJjQ1XU=.#=zzDosIddISk1$();
		this.#=zwn5aCwWTvPV4 = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
		this.#=zkTFDbK1WLBVA = #=zuJjQ1XU=.#=zuMXv8DnEbNVrFpFzVw==();
		this.#=zrJxqbHPykBpmqmJyrg== = #=zuJjQ1XU=.#=zADpc34x0JAcLsjuojA==();
		this.#=zdNjNHgQybBKI = #=zuJjQ1XU=.#=zSLoaXUvNBvPo();
		this.#=zJBQO3ZaujaPU = #=zuJjQ1XU=.#=zqCMgNvOChEJ_GNc9ng==();
		if (this.#=z5thIYRgpTTs8KNlZHQ==())
		{
			this.#=zZKzdsPms7IDM = new #=zyVB4NB_Tbn2hBQdpseFYk5YGBB52sxlVfonIQHub7h5ic5Dnmg==(this.#=z8StzeqE=, #=zuJjQ1XU=);
		}
		this.#=zFhEyBouv8Ijn4t019A== = null;
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00005270 File Offset: 0x00003470
	protected virtual bool #=z5thIYRgpTTs8KNlZHQ==()
	{
		return this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpHiringWithBoostersMode != 0;
	}

	// Token: 0x0600009A RID: 154 RVA: 0x00005288 File Offset: 0x00003488
	protected override void #=zvb5bnug=()
	{
		this.#=zSeh8xQvQ9zqr();
		this.#=zP9zWgiLkSOHlVpujDQ==();
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00005298 File Offset: 0x00003498
	private void #=zP9zWgiLkSOHlVpujDQ==()
	{
		UnitTypeCollection #=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsHireTroops && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HiringPlan != null)
		{
			bool #=z8GAhfBs_fhwN;
			List<UnitType.Resources> #=zYwLs4tIWOEn$Tg75Hw==;
			if ((this.#=zcDRV51Ut$7oP.Options & TaskOptions.Cyclic) == TaskOptions.Cyclic)
			{
				#=z8GAhfBs_fhwN = true;
				#=zYwLs4tIWOEn$Tg75Hw== = null;
			}
			else
			{
				#=z8GAhfBs_fhwN = (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsHireTroopsMultipleAlways || (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsHireTroopsMultipleIfMinus && (this.#=z8StzeqE=.#=zfgnLN9jbKv4ZyrxNJg3Xr78=().#=zcPDeKMQFl$$_() <= 0 || #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zfkMjd4$nuTc4l5SAG5VXdaY=(this.#=z8StzeqE=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq, this.#=zVG1EPv1OUDdyLeGHGQ==, this.#=zWF6MNCHjVXd5) <= 0)));
				#=zYwLs4tIWOEn$Tg75Hw== = new List<UnitType.Resources>
				{
					UnitType.Resources.Resource,
					UnitType.Resources.ResourceTitanium,
					UnitType.Resources.ResourceUranium
				};
			}
			this.#=zP9zWgiLkSOHlVpujDQ==(#=zlhLE8UQVU0AG, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HiringPlan, #=z8GAhfBs_fhwN, #=zYwLs4tIWOEn$Tg75Hw==, true);
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpHiringWithBoostersMode != 0 && this.#=zZKzdsPms7IDM != null)
			{
				if (!string.IsNullOrEmpty(this.#=zFhEyBouv8Ijn4t019A==))
				{
					base.#=zL1HTbwC75LO$(this.#=zFhEyBouv8Ijn4t019A==);
				}
				this.#=zZKzdsPms7IDM.#=z6jx9xxMN66y9ozaJ4ff4nj_dDht$(this.#=zvPVvZaDW5sGehlg4AA==, this.#=z3yL5bKs=);
			}
		}
	}

	// Token: 0x0600009C RID: 156 RVA: 0x000053DC File Offset: 0x000035DC
	protected void #=zP9zWgiLkSOHlVpujDQ==(UnitTypeCollection #=zlhLE8UQVU0AG, HiringPlan #=zdXeYDv5k4hUOtKDvng==, bool #=z8GAhfBs_fhwN, List<UnitType.Resources> #=zYwLs4tIWOEn$Tg75Hw==, bool #=zMh1KPFys32cKGN5XckRUA0qFcc0U)
	{
		List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zxrOfbefO$1eQzrPLHQ== = this.#=zmxzDCUKXjmdylmQQ3FV9Nas=(#=zlhLE8UQVU0AG, #=zdXeYDv5k4hUOtKDvng==, #=z8GAhfBs_fhwN, #=zYwLs4tIWOEn$Tg75Hw==, #=zMh1KPFys32cKGN5XckRUA0qFcc0U);
		this.#=z5L0KrRLS4QTUHWDmnj0ttAI=(#=zxrOfbefO$1eQzrPLHQ==);
		List<ResourceTypes> list = new List<ResourceTypes>();
		Dictionary<int, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>> dictionary;
		UnitSquadCollection unitSquadCollection = this.#=zWgW4$AvK9Vhep3MfrXLJ7gA=(#=zxrOfbefO$1eQzrPLHQ==, 0, list, out dictionary);
		List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zR7si8C9LfgQiYAtDmQ== = new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>();
		for (int i = 0; i < unitSquadCollection.Count; i++)
		{
			UnitSquad unitSquad = unitSquadCollection[i];
			List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zggAQeyA= = dictionary[unitSquad.Type.Id];
			this.#=zzgV7Qg8jMMhc795pNA==(unitSquad, #=zggAQeyA=, #=zR7si8C9LfgQiYAtDmQ==, list, 0L);
		}
		if (#=zMh1KPFys32cKGN5XckRUA0qFcc0U)
		{
			foreach (ResourceTypes item in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().AllResourcePriorityTypes)
			{
				if (list.Contains(item))
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(new List<ResourceTypes>
					{
						item
					}, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983037));
				}
				else
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(new List<ResourceTypes>
					{
						item
					}, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983037));
				}
			}
		}
	}

	// Token: 0x0600009D RID: 157 RVA: 0x00005504 File Offset: 0x00003704
	public void #=zkcXnL8F0L56vUTI_jbqUKJg=(UnitTypeCollection #=zlhLE8UQVU0AG, HiringPlan #=zdXeYDv5k4hUOtKDvng==)
	{
		List<UnitType.Resources> #=zYwLs4tIWOEn$Tg75Hw== = new List<UnitType.Resources>
		{
			UnitType.Resources.Resource,
			UnitType.Resources.ResourceTitanium,
			UnitType.Resources.ResourceUranium
		};
		List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> list = this.#=zmxzDCUKXjmdylmQQ3FV9Nas=(#=zlhLE8UQVU0AG, #=zdXeYDv5k4hUOtKDvng==, true, #=zYwLs4tIWOEn$Tg75Hw==, false);
		List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> list2 = new List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=>();
		for (int i = 0; i < list.Count; i++)
		{
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw= = list[i];
			if (#=zUQNPugDCQidULApjIlqxKfw=.#=zeK37O9MfqEuI() > 1 && #=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().IsStandardResource)
			{
				list2.Add(#=zUQNPugDCQidULApjIlqxKfw=);
				break;
			}
		}
		this.#=z5L0KrRLS4QTUHWDmnj0ttAI=(list2);
		if (list2.Count > 0)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer <= 0)
			{
				if (this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] > 2000)
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer = 1000;
				}
				else
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer = this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] / 2;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983018), new object[]
				{
					0,
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer
				});
			}
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw=2 = list2[0];
			int num = #=zUQNPugDCQidULApjIlqxKfw=2.#=zGIM5CE3RnPsC();
			#=zUQNPugDCQidULApjIlqxKfw=2.#=zYnZg_D01icPu(1);
			#=zUQNPugDCQidULApjIlqxKfw=2.#=zjE7MIAg1oIkf(#=zUQNPugDCQidULApjIlqxKfw=2.#=zeK37O9MfqEuI() * num);
			List<ResourceTypes> #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw== = new List<ResourceTypes>();
			Dictionary<int, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>> dictionary;
			UnitSquadCollection unitSquadCollection = this.#=zWgW4$AvK9Vhep3MfrXLJ7gA=(list2, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer, #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, out dictionary);
			if (unitSquadCollection.Count > 0)
			{
				UnitSquad unitSquad = unitSquadCollection[0];
				List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zggAQeyA= = dictionary[unitSquad.Type.Id];
				List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zR7si8C9LfgQiYAtDmQ== = new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>();
				if (string.IsNullOrEmpty(this.#=zzgV7Qg8jMMhc795pNA==(unitSquad, #=zggAQeyA=, #=zR7si8C9LfgQiYAtDmQ==, #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, this.#=zJBQO3ZaujaPU)) && unitSquad.Number >= 2)
				{
					unitSquad.Number /= 2;
					if (!string.IsNullOrEmpty(this.#=zzgV7Qg8jMMhc795pNA==(unitSquad, #=zggAQeyA=, #=zR7si8C9LfgQiYAtDmQ==, #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, this.#=zJBQO3ZaujaPU + 1000L)))
					{
						int hireTroopsImmediateGrainBuffer = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer;
						this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer * 2;
						if (this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer * 2)
						{
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer = this.#=zkdGdpYZ7Wpxf[ResourceTypes.Grain] / 2;
						}
						if (hireTroopsImmediateGrainBuffer != this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983018), new object[]
							{
								hireTroopsImmediateGrainBuffer,
								this.#=z8StzeqE=.#=zv2Kyu17YrGOC().HireTroopsImmediateGrainBuffer
							});
						}
					}
				}
			}
		}
	}

	// Token: 0x0600009E RID: 158 RVA: 0x000057D8 File Offset: 0x000039D8
	protected void #=zANXaSexKcWE6QaKrzVUaQlM=(UnitTypeCollection #=zlhLE8UQVU0AG, HiringPlan #=zdXeYDv5k4hUOtKDvng==, bool #=z8GAhfBs_fhwN, List<UnitType.Resources> #=zYwLs4tIWOEn$Tg75Hw==, bool #=zMh1KPFys32cKGN5XckRUA0qFcc0U)
	{
		List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zxrOfbefO$1eQzrPLHQ== = this.#=zmxzDCUKXjmdylmQQ3FV9Nas=(#=zlhLE8UQVU0AG, #=zdXeYDv5k4hUOtKDvng==, #=z8GAhfBs_fhwN, #=zYwLs4tIWOEn$Tg75Hw==, #=zMh1KPFys32cKGN5XckRUA0qFcc0U);
		this.#=z5L0KrRLS4QTUHWDmnj0ttAI=(#=zxrOfbefO$1eQzrPLHQ==);
		List<int> list = null;
		List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zR7si8C9LfgQiYAtDmQ== = new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>();
		List<ResourceTypes> #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw== = new List<ResourceTypes>();
		if (!#=z8GAhfBs_fhwN)
		{
			string text;
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zriRu5TAV_AtI5yXAcbMEnKQ0NEFw(#=zxrOfbefO$1eQzrPLHQ==, this.#=z8StzeqE=, this.#=zBsXSanI=, list, #=zR7si8C9LfgQiYAtDmQ==, #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, out text);
			if (text != null)
			{
				this.#=zFhEyBouv8Ijn4t019A== = text;
				return;
			}
		}
		else
		{
			for (int i = 0; i < 100; i++)
			{
				string text;
				list = #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zriRu5TAV_AtI5yXAcbMEnKQ0NEFw(#=zxrOfbefO$1eQzrPLHQ==, this.#=z8StzeqE=, this.#=zBsXSanI=, list, #=zR7si8C9LfgQiYAtDmQ==, #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, out text);
				if (text != null)
				{
					this.#=zFhEyBouv8Ijn4t019A== = text;
				}
				if (list.Count == 0)
				{
					break;
				}
			}
		}
	}

	// Token: 0x0600009F RID: 159 RVA: 0x0000586C File Offset: 0x00003A6C
	private List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zmxzDCUKXjmdylmQQ3FV9Nas=(UnitTypeCollection #=zlhLE8UQVU0AG, HiringPlan #=zdXeYDv5k4hUOtKDvng==, bool #=z8GAhfBs_fhwN, List<UnitType.Resources> #=zYwLs4tIWOEn$Tg75Hw==, bool #=zMh1KPFys32cKGN5XckRUA0qFcc0U)
	{
		List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> list = new List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=>();
		foreach (HiringPlanFrame hiringPlanFrame in #=zdXeYDv5k4hUOtKDvng==)
		{
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zdH1XRTae6g2ih8TFLRj_iGQ= #=zdH1XRTae6g2ih8TFLRj_iGQ= = new #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zdH1XRTae6g2ih8TFLRj_iGQ=();
			UnitType unitType = #=zlhLE8UQVU0AG.FindOrCreate(hiringPlanFrame.TypeId);
			if (!AbstractType.IsFutureWorld(unitType.World) || this.#=zkTFDbK1WLBVA)
			{
				if (!#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(unitType.#=zdL$RcwsYpqvy(), this.#=z8StzeqE=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJF2YTStZkxdpBvijgveKmkY=))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982955), new object[]
					{
						string.Empty,
						unitType.Name,
						string.Empty
					});
				}
				else
				{
					#=zdH1XRTae6g2ih8TFLRj_iGQ=.#=zg0vMsd4NTdNlawQbww== = this.#=zvPVvZaDW5sGehlg4AA==[hiringPlanFrame.TypeId];
					if (#=zdH1XRTae6g2ih8TFLRj_iGQ=.#=zg0vMsd4NTdNlawQbww==.#=zBHuoQg9JVxim() < hiringPlanFrame.QueueLenght || hiringPlanFrame.QueueLenght <= 0)
					{
						int num = #=zdH1XRTae6g2ih8TFLRj_iGQ=.#=zg0vMsd4NTdNlawQbww==.#=zBHuoQg9JVxim();
						if (hiringPlanFrame.MaxAmount > 0)
						{
							UnitSquad unitSquad = this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.Find(hiringPlanFrame.TypeId);
							if (unitSquad != null)
							{
								num += unitSquad.Number;
							}
							foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
							{
								if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
								{
									unitSquad = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().Find(hiringPlanFrame.TypeId);
									if (unitSquad != null)
									{
										num += unitSquad.Number;
										if (num > hiringPlanFrame.MaxAmount)
										{
											break;
										}
									}
								}
							}
						}
						if (num < hiringPlanFrame.MaxAmount || hiringPlanFrame.MaxAmount <= 0)
						{
							if (#=zMh1KPFys32cKGN5XckRUA0qFcc0U && unitType.#=zUwkBvlaPfotf().#=z_CUgG1uVO0_6ruY6OA==()[ResourceTypes.Grain] > 0 && !this.#=z8StzeqE=.#=zkXsxKS4OL0sN(new List<ResourceTypes>
							{
								ResourceTypes.Grain
							}, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983037), false))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982640), new object[]
								{
									unitType.Name,
									#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=ziW1QRqvFMUe2(ResourceTypes.Grain)
								});
								this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(new List<ResourceTypes>
								{
									ResourceTypes.Grain
								}, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983037));
							}
							else
							{
								List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> list2 = #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zCsLQRc5IYRE_(unitType, this.#=z8StzeqE=, this.#=zwn5aCwWTvPV4);
								if (list2.Count > 1)
								{
									list2.Sort(new Comparison<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>(#=zdH1XRTae6g2ih8TFLRj_iGQ=.#=zWCk3qxJbjm7bJjfNulTwBCZu960L));
									if (!#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=zX35dz$Dz2oVq(unitType.World, list2[0]))
									{
										while (list2.Count > 1)
										{
											list2.RemoveAt(1);
										}
									}
								}
								int num2 = #=zdH1XRTae6g2ih8TFLRj_iGQ=.#=zg0vMsd4NTdNlawQbww==.#=z8bPgQdHrr2WZ(list2[0]);
								int num3;
								if (hiringPlanFrame.BlockSize > 0)
								{
									num3 = hiringPlanFrame.BlockSize;
								}
								else if (hiringPlanFrame.QueueLenght > 0)
								{
									num3 = ((num2 < hiringPlanFrame.QueueLenght / 2) ? hiringPlanFrame.QueueLenght : (hiringPlanFrame.QueueLenght / 2));
								}
								else
								{
									switch (unitType.Class)
									{
									case UnitType.Classes.LightInfantry:
										num3 = 100;
										break;
									case UnitType.Classes.HeavyInfantry:
										num3 = 25;
										break;
									case UnitType.Classes.Phalanx:
										num3 = 10;
										break;
									case UnitType.Classes.Cavalry:
										num3 = ((unitType.Function == UnitType.Functions.Scouting) ? 25 : 5);
										break;
									default:
										num3 = 5;
										break;
									}
								}
								if (num3 <= 0)
								{
									num3 = 1;
								}
								int num4 = 999999;
								if (hiringPlanFrame.QueueLenght > 0 && hiringPlanFrame.QueueLenght - num2 < num4)
								{
									num4 = hiringPlanFrame.QueueLenght - num2;
								}
								if (hiringPlanFrame.MaxAmount > 0 && hiringPlanFrame.MaxAmount - num < num4)
								{
									num4 = hiringPlanFrame.MaxAmount - num;
								}
								int num5 = num4 / num3 + 1;
								if (num5 > 1)
								{
									if (!#=z8GAhfBs_fhwN)
									{
										num5 = 1;
									}
									else if (#=zYwLs4tIWOEn$Tg75Hw== != null && !#=zYwLs4tIWOEn$Tg75Hw==.Contains(unitType.Resource))
									{
										num5 = 1;
									}
								}
								List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> list3 = list;
								#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw= = new #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=();
								#=zUQNPugDCQidULApjIlqxKfw=.#=zzQwUIEs=(unitType);
								#=zUQNPugDCQidULApjIlqxKfw=.#=zYnZg_D01icPu(num3);
								#=zUQNPugDCQidULApjIlqxKfw=.#=zjE7MIAg1oIkf(num5);
								#=zUQNPugDCQidULApjIlqxKfw=.#=z4s1J_BTngVeY(list2);
								#=zUQNPugDCQidULApjIlqxKfw=.#=zbTadlnbeRrPdZ9zQew==(num2 / num3);
								list3.Add(#=zUQNPugDCQidULApjIlqxKfw=);
							}
						}
					}
				}
			}
		}
		list.Sort();
		return list;
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00005CC8 File Offset: 0x00003EC8
	private void #=z5L0KrRLS4QTUHWDmnj0ttAI=(List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zxrOfbefO$1eQzrPLHQ==)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < #=zxrOfbefO$1eQzrPLHQ==.Count; i++)
		{
			if (i > 0)
			{
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
			}
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw= = #=zxrOfbefO$1eQzrPLHQ==[i];
			if (!#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=z1G2yq220nKu$(#=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().World, #=zUQNPugDCQidULApjIlqxKfw=.#=zw9C6B_6NSRtu()[0]))
			{
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982582), #=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().ShortName, #=zUQNPugDCQidULApjIlqxKfw=.#=zGIM5CE3RnPsC(), #=zUQNPugDCQidULApjIlqxKfw=.#=zyVwXscYaxwfVbFDRkA==());
			}
			else
			{
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982565), #=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().ShortName, #=zUQNPugDCQidULApjIlqxKfw=.#=zGIM5CE3RnPsC(), #=zUQNPugDCQidULApjIlqxKfw=.#=zyVwXscYaxwfVbFDRkA==());
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982542), new object[]
		{
			stringBuilder.ToString()
		});
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00005DC8 File Offset: 0x00003FC8
	private UnitSquadCollection #=zWgW4$AvK9Vhep3MfrXLJ7gA=(List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zxrOfbefO$1eQzrPLHQ==, int #=z5bb5$Knl7DYe, List<ResourceTypes> #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, out Dictionary<int, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>> #=zVzDloYUwPwBF)
	{
		#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== = this.#=z3yL5bKs=.#=zmTCxtJo=().#=zTnMGkyA=();
		if (#=z5bb5$Knl7DYe > 0)
		{
			#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==.#=zWyy2M2Q=(ResourceTypes.Grain, #=z5bb5$Knl7DYe);
		}
		Dictionary<int, #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==> dictionary = new Dictionary<int, #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==>();
		foreach (#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw= in #=zxrOfbefO$1eQzrPLHQ==)
		{
			#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==2 = #=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().#=zUwkBvlaPfotf().#=z_CUgG1uVO0_6ruY6OA==();
			foreach (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV #=zF_m$qwkni_ep$nCra3nSOCYbdgBV in this.#=zdNjNHgQybBKI)
			{
				if (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zq2bPTdY=().#=z45sd5C$gcFqwpb5U$A==() != 0 && #=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zq2bPTdY=().#=zje04I5G2OOWR().Contains(#=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().Id))
				{
					#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==3 = new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==();
					foreach (ResourceTypes #=zvRLj9WQ= in #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==2.Keys)
					{
						#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==3[#=zvRLj9WQ=] = (int)Math.Ceiling((double)#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==2[#=zvRLj9WQ=] * (100.0 - (double)#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zq2bPTdY=().#=z45sd5C$gcFqwpb5U$A==()) / 100.0);
					}
					#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==2 = #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==3;
				}
			}
			dictionary[#=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=().Id] = #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==2;
		}
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		#=zVzDloYUwPwBF = new Dictionary<int, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>>();
		for (int i = 0; i < 9999; i++)
		{
			bool flag = false;
			for (int j = 0; j < #=zxrOfbefO$1eQzrPLHQ==.Count; j++)
			{
				#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw=2 = #=zxrOfbefO$1eQzrPLHQ==[j];
				UnitType unitType = #=zUQNPugDCQidULApjIlqxKfw=2.#=zq2bPTdY=();
				int num = #=zUQNPugDCQidULApjIlqxKfw=2.#=zGIM5CE3RnPsC();
				ResourceTypes item = #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zy$A_VnA=(unitType);
				if (!#=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==.Contains(item) && #=zUQNPugDCQidULApjIlqxKfw=2.#=zeK37O9MfqEuI() > 0)
				{
					if (#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==.#=znxdqlEM=(dictionary[unitType.Id], num))
					{
						unitSquadCollection.AddUnits(new UnitSquad(unitType, num));
						if (!#=zVzDloYUwPwBF.ContainsKey(unitType.Id))
						{
							#=zVzDloYUwPwBF[unitType.Id] = #=zUQNPugDCQidULApjIlqxKfw=2.#=zw9C6B_6NSRtu();
						}
						#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw=3 = #=zUQNPugDCQidULApjIlqxKfw=2;
						int num2 = #=zUQNPugDCQidULApjIlqxKfw=3.#=zeK37O9MfqEuI();
						#=zUQNPugDCQidULApjIlqxKfw=3.#=zjE7MIAg1oIkf(num2 - 1);
						flag = true;
					}
					else
					{
						#=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==.Add(item);
						if (unitSquadCollection.Find(unitType.Id) == null)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982759), new object[]
							{
								string.Empty,
								unitType.Name,
								string.Empty
							});
						}
					}
				}
			}
			if (!flag)
			{
				break;
			}
		}
		return unitSquadCollection;
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x000060BC File Offset: 0x000042BC
	private string #=zzgV7Qg8jMMhc795pNA==(UnitSquad #=zyfFMVVRMf$KEfE9kYQ==, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zggAQeyA=, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zR7si8C9LfgQiYAtDmQ==, List<ResourceTypes> #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, long #=zDDM3RaZctOJ8YHNUCAlnJ_I=)
	{
		string result = null;
		UnitType type = #=zyfFMVVRMf$KEfE9kYQ==.Type;
		int number = #=zyfFMVVRMf$KEfE9kYQ==.Number;
		for (int i = 0; i < #=zggAQeyA=.Count; i++)
		{
			#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== = #=zggAQeyA=[i];
			if (!#=zR7si8C9LfgQiYAtDmQ==.Contains(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==))
			{
				string text = this.#=zBsXSanI=.#=zoO8X4UjQ2pwEKUcTrw==(type, number, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, #=zDDM3RaZctOJ8YHNUCAlnJ_I=);
				text = text.Trim();
				string text2 = #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=z1G2yq220nKu$(type.World, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==) ? (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982684))) : string.Empty;
				if (text.Length < 10000)
				{
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925958)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982955), new object[]
						{
							number,
							type.Name,
							text2
						});
						break;
					}
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982660)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982379)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982367), new object[]
						{
							number,
							type.Name,
							text2
						});
						#=zR7si8C9LfgQiYAtDmQ==.Add(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==);
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
					{
						#=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==.Add(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zy$A_VnA=(type));
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982759), new object[]
						{
							number,
							type.Name,
							text2
						});
						if (#=zDDM3RaZctOJ8YHNUCAlnJ_I= > 0L)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982302), new object[]
							{
								this.#=z3yL5bKs=.ToString(),
								JSONManager.DecodeTime(#=zDDM3RaZctOJ8YHNUCAlnJ_I=.ToString(), false),
								#=zDDM3RaZctOJ8YHNUCAlnJ_I=,
								this.#=z8StzeqE=.#=zc3DeoTSaHY6p5yNLew==()
							});
							break;
						}
						break;
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982483), new object[]
						{
							number,
							type.Name,
							text2,
							text
						});
					}
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982436), new object[]
					{
						number,
						type.Name,
						text2
					});
					result = text;
					this.#=zFhEyBouv8Ijn4t019A== = text;
					if (#=zDDM3RaZctOJ8YHNUCAlnJ_I= > 0L)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982302), new object[]
						{
							this.#=z3yL5bKs=.ToString(),
							JSONManager.DecodeTime(#=zDDM3RaZctOJ8YHNUCAlnJ_I=.ToString(), false),
							#=zDDM3RaZctOJ8YHNUCAlnJ_I=,
							this.#=z8StzeqE=.#=zc3DeoTSaHY6p5yNLew==()
						});
						break;
					}
					break;
				}
			}
		}
		return result;
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x00006420 File Offset: 0x00004620
	private static ResourceTypes #=zy$A_VnA=(UnitType #=zvRLj9WQ=)
	{
		UnitType.Resources resource = #=zvRLj9WQ=.Resource;
		switch (resource)
		{
		case UnitType.Resources.Resource:
			break;
		case UnitType.Resources.Denaries:
			return ResourceTypes.Denaries;
		case UnitType.Resources.Drachmas:
		case UnitType.Resources.Special:
			return ResourceTypes.Unknown;
		case UnitType.Resources.Future:
			return ResourceTypes.FutureCurrency;
		default:
			if (resource - UnitType.Resources.ResourceTitanium > 1)
			{
				return ResourceTypes.Unknown;
			}
			break;
		}
		return ResourceTypes.Grain;
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x00006460 File Offset: 0x00004660
	private static List<int> #=zriRu5TAV_AtI5yXAcbMEnKQ0NEFw(List<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=> #=zxrOfbefO$1eQzrPLHQ==, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, List<int> #=zgvxo2OO1CeN89SUmyg==, List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zR7si8C9LfgQiYAtDmQ==, List<ResourceTypes> #=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==, out string #=ztM7CuD$H0hzOP10wrg==)
	{
		#=ztM7CuD$H0hzOP10wrg== = null;
		List<int> list = new List<int>();
		int i = 0;
		while (i < #=zxrOfbefO$1eQzrPLHQ==.Count)
		{
			#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw= = #=zxrOfbefO$1eQzrPLHQ==[i];
			UnitType unitType = #=zUQNPugDCQidULApjIlqxKfw=.#=zq2bPTdY=();
			int num = #=zUQNPugDCQidULApjIlqxKfw=.#=zGIM5CE3RnPsC();
			UnitType.Resources resource = unitType.Resource;
			ResourceTypes item;
			switch (resource)
			{
			case UnitType.Resources.Resource:
				goto IL_57;
			case UnitType.Resources.Denaries:
				item = ResourceTypes.Denaries;
				break;
			case UnitType.Resources.Drachmas:
			case UnitType.Resources.Special:
				goto IL_67;
			case UnitType.Resources.Future:
				item = ResourceTypes.FutureCurrency;
				break;
			default:
				if (resource - UnitType.Resources.ResourceTitanium <= 1)
				{
					goto IL_57;
				}
				goto IL_67;
			}
			IL_6A:
			if (!#=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==.Contains(item) && (#=zgvxo2OO1CeN89SUmyg== == null || #=zgvxo2OO1CeN89SUmyg==.Contains(unitType.Id)) && #=zUQNPugDCQidULApjIlqxKfw=.#=zeK37O9MfqEuI() > 0)
			{
				for (int j = 0; j < #=zUQNPugDCQidULApjIlqxKfw=.#=zw9C6B_6NSRtu().Count; j++)
				{
					#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== = #=zUQNPugDCQidULApjIlqxKfw=.#=zw9C6B_6NSRtu()[j];
					if (!#=zR7si8C9LfgQiYAtDmQ==.Contains(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==))
					{
						string text = #=zBsXSanI=.#=zoO8X4UjQ2pwEKUcTrw==(unitType, num, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==, 0L);
						text = text.Trim();
						string text2 = #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=z1G2yq220nKu$(unitType.World, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==) ? (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031) + #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982684))) : string.Empty;
						if (text.Length >= 10000)
						{
							#=ztM7CuD$H0hzOP10wrg== = text;
							#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982436), new object[]
							{
								num,
								unitType.Name,
								text2
							});
							if (!list.Contains(unitType.Id))
							{
								list.Add(unitType.Id);
							}
							#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zUQNPugDCQidULApjIlqxKfw=2 = #=zUQNPugDCQidULApjIlqxKfw=;
							int num2 = #=zUQNPugDCQidULApjIlqxKfw=2.#=zeK37O9MfqEuI();
							#=zUQNPugDCQidULApjIlqxKfw=2.#=zjE7MIAg1oIkf(num2 - 1);
							break;
						}
						if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925958)))
						{
							#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982955), new object[]
							{
								num,
								unitType.Name,
								text2
							});
							break;
						}
						if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982660)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982379)))
						{
							#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982367), new object[]
							{
								num,
								unitType.Name,
								text2
							});
							#=zR7si8C9LfgQiYAtDmQ==.Add(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==);
						}
						else
						{
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
							{
								#=z7aPjuk$OMNBs_I4Fl6L70809cXCB4eJbQw==.Add(item);
								#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982759), new object[]
								{
									num,
									unitType.Name,
									text2
								});
								break;
							}
							#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982483), new object[]
							{
								num,
								unitType.Name,
								text2,
								text
							});
						}
					}
				}
			}
			i++;
			continue;
			IL_57:
			item = ResourceTypes.Grain;
			goto IL_6A;
			IL_67:
			item = ResourceTypes.Unknown;
			goto IL_6A;
		}
		return list;
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x0000676C File Offset: 0x0000496C
	private bool #=zSeh8xQvQ9zqr()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBuildTraps)
		{
			this.#=zMQem9lpnP1FUdCOCtw==(this.#=zrJxqbHPykBpmqmJyrg==, 11000, 9);
			this.#=zMQem9lpnP1FUdCOCtw==(this.#=zrJxqbHPykBpmqmJyrg==, 11001, 16);
			this.#=zMQem9lpnP1FUdCOCtw==(this.#=zrJxqbHPykBpmqmJyrg==, 11002, 16);
			this.#=zMQem9lpnP1FUdCOCtw==(this.#=zrJxqbHPykBpmqmJyrg==, 11003, 16);
			this.#=zMQem9lpnP1FUdCOCtw==(this.#=zrJxqbHPykBpmqmJyrg==, 11004, 16);
		}
		return true;
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x000067EC File Offset: 0x000049EC
	private void #=zMQem9lpnP1FUdCOCtw==(Dictionary<int, int> #=zrJxqbHPykBpmqmJyrg==, int #=zRZTpgwIXt4_m, int #=zNvCMwussKumm)
	{
		UnitType #=z9C46aFM= = new UnitType
		{
			Id = #=zRZTpgwIXt4_m,
			World = Worlds.Default
		};
		int num = #=zrJxqbHPykBpmqmJyrg==.ContainsKey(#=zRZTpgwIXt4_m) ? #=zrJxqbHPykBpmqmJyrg==[#=zRZTpgwIXt4_m] : 0;
		if (num > 0 && num < #=zNvCMwussKumm)
		{
			#=zNvCMwussKumm -= num;
		}
		string text = this.#=zBsXSanI=.#=zoO8X4UjQ2pwEKUcTrw==(#=z9C46aFM=, #=zNvCMwussKumm);
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984187), new object[]
			{
				#=zRZTpgwIXt4_m,
				#=zNvCMwussKumm
			});
			return;
		}
		if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984142)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984113), new object[]
			{
				#=zRZTpgwIXt4_m,
				#=zNvCMwussKumm
			});
			return;
		}
		if (text.Length > 1000)
		{
			text = text.Substring(0, 1000);
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984284), new object[]
		{
			#=zRZTpgwIXt4_m,
			#=zNvCMwussKumm,
			text
		});
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00006924 File Offset: 0x00004B24
	private static List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zCsLQRc5IYRE_(UnitType #=zvRLj9WQ=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4)
	{
		if (#=zvRLj9WQ= == null)
		{
			return new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>
			{
				(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0
			};
		}
		List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> list = new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>();
		Worlds world = #=zvRLj9WQ=.World;
		if (world != Worlds.Elisium)
		{
			if (world != Worlds.Veor)
			{
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0);
				switch (#=zvRLj9WQ=.Class)
				{
				case UnitType.Classes.LightInfantry:
					if (#=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=.#=zLkw0NRU=.#=z02DaXzdtpY7ZuTlFVnrD39qKUFYm)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)3);
					}
					break;
				case UnitType.Classes.HeavyInfantry:
					if (#=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=.#=zLkw0NRU=.#=z2kuXskRzAs70csAujT1Ie$g1QWy$)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)4);
					}
					break;
				case UnitType.Classes.Phalanx:
					if (#=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=.#=zLkw0NRU=.#=zlXQhRnOWAv2noF1b01tI8qtJYh2r)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)5);
					}
					break;
				case UnitType.Classes.Cavalry:
					if (#=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=.#=zLkw0NRU=.#=zZTIAkG43kZVrDm1i0BDFh5PqySBG)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)6);
					}
					break;
				}
			}
			else
			{
				if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroopsAsUsual && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(#=z8StzeqE=))
				{
					list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0);
				}
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)8);
			}
		}
		else
		{
			list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)1);
			if (#=zwn5aCwWTvPV4.Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=.#=zLkw0NRU=.#=z7Dfky84Ncb1asfIWZD_XnHL5d_Z_)) != null)
			{
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)7);
			}
		}
		return list;
	}

	// Token: 0x04000032 RID: 50
	protected #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= #=zvPVvZaDW5sGehlg4AA==;

	// Token: 0x04000033 RID: 51
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x04000034 RID: 52
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x04000035 RID: 53
	protected #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x04000036 RID: 54
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zkdGdpYZ7Wpxf;

	// Token: 0x04000037 RID: 55
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x04000038 RID: 56
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x04000039 RID: 57
	private #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=zWF6MNCHjVXd5;

	// Token: 0x0400003A RID: 58
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zwn5aCwWTvPV4;

	// Token: 0x0400003B RID: 59
	private bool #=zkTFDbK1WLBVA;

	// Token: 0x0400003C RID: 60
	private Dictionary<int, int> #=zrJxqbHPykBpmqmJyrg==;

	// Token: 0x0400003D RID: 61
	private List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=zdNjNHgQybBKI;

	// Token: 0x0400003E RID: 62
	private long #=zJBQO3ZaujaPU;

	// Token: 0x0400003F RID: 63
	protected #=zyVB4NB_Tbn2hBQdpseFYk5YGBB52sxlVfonIQHub7h5ic5Dnmg== #=zZKzdsPms7IDM;

	// Token: 0x04000040 RID: 64
	protected string #=zFhEyBouv8Ijn4t019A==;

	// Token: 0x0200002C RID: 44
	private sealed class #=zUQNPugDCQidULApjIlqxKfw= : IComparable<#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw=>
	{
		// Token: 0x060000A9 RID: 169 RVA: 0x00006AB8 File Offset: 0x00004CB8
		public UnitType #=zq2bPTdY=()
		{
			return this.#=zmgOIL9ya65ae7QIXVQ==;
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00006AC0 File Offset: 0x00004CC0
		public void #=zzQwUIEs=(UnitType #=z$Ib9gYQ=)
		{
			this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00006ACC File Offset: 0x00004CCC
		public int #=zGIM5CE3RnPsC()
		{
			return this.#=z1_CqO3eRRG65FWg0VA==;
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00006AD4 File Offset: 0x00004CD4
		public void #=zYnZg_D01icPu(int #=z$Ib9gYQ=)
		{
			this.#=z1_CqO3eRRG65FWg0VA== = #=z$Ib9gYQ=;
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00006AE0 File Offset: 0x00004CE0
		public int #=zeK37O9MfqEuI()
		{
			return this.#=zlwR2mBJLPvxKfOaE_deLOfw=;
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00006AE8 File Offset: 0x00004CE8
		public void #=zjE7MIAg1oIkf(int #=z$Ib9gYQ=)
		{
			this.#=zlwR2mBJLPvxKfOaE_deLOfw= = #=z$Ib9gYQ=;
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00006AF4 File Offset: 0x00004CF4
		public List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zw9C6B_6NSRtu()
		{
			return this.#=zMnHH$$rDNKf9IWyXag==;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00006AFC File Offset: 0x00004CFC
		public void #=z4s1J_BTngVeY(List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=z$Ib9gYQ=)
		{
			this.#=zMnHH$$rDNKf9IWyXag== = #=z$Ib9gYQ=;
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00006B08 File Offset: 0x00004D08
		public int #=zyVwXscYaxwfVbFDRkA==()
		{
			return this.#=zmbdXcVaVpYrWRhOlzPYAD10=;
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00006B10 File Offset: 0x00004D10
		public void #=zbTadlnbeRrPdZ9zQew==(int #=z$Ib9gYQ=)
		{
			this.#=zmbdXcVaVpYrWRhOlzPYAD10= = #=z$Ib9gYQ=;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00006B1C File Offset: 0x00004D1C
		public int CompareTo(#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zUQNPugDCQidULApjIlqxKfw= #=zzHmvhNYN5X_r)
		{
			if (this.#=zq2bPTdY=().Id == #=zzHmvhNYN5X_r.#=zq2bPTdY=().Id)
			{
				return this.#=zGIM5CE3RnPsC().CompareTo(#=zzHmvhNYN5X_r.#=zGIM5CE3RnPsC());
			}
			return this.#=zyVwXscYaxwfVbFDRkA==().CompareTo(#=zzHmvhNYN5X_r.#=zyVwXscYaxwfVbFDRkA==());
		}

		// Token: 0x04000041 RID: 65
		private UnitType #=zmgOIL9ya65ae7QIXVQ==;

		// Token: 0x04000042 RID: 66
		private int #=z1_CqO3eRRG65FWg0VA==;

		// Token: 0x04000043 RID: 67
		private int #=zlwR2mBJLPvxKfOaE_deLOfw=;

		// Token: 0x04000044 RID: 68
		private List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zMnHH$$rDNKf9IWyXag==;

		// Token: 0x04000045 RID: 69
		private int #=zmbdXcVaVpYrWRhOlzPYAD10=;
	}

	// Token: 0x0200002D RID: 45
	private sealed class #=zdH1XRTae6g2ih8TFLRj_iGQ=
	{
		// Token: 0x060000B5 RID: 181 RVA: 0x00006B74 File Offset: 0x00004D74
		internal int #=zWCk3qxJbjm7bJjfNulTwBCZu960L(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zm8PpuDU=, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zcltuPyw=)
		{
			return this.#=zg0vMsd4NTdNlawQbww==.#=z8bPgQdHrr2WZ(#=zm8PpuDU=).CompareTo(this.#=zg0vMsd4NTdNlawQbww==.#=z8bPgQdHrr2WZ(#=zcltuPyw=));
		}

		// Token: 0x04000046 RID: 70
		public #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= #=zg0vMsd4NTdNlawQbww==;
	}

	// Token: 0x0200002E RID: 46
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x060000B8 RID: 184 RVA: 0x00006BB8 File Offset: 0x00004DB8
		internal bool #=z7Dfky84Ncb1asfIWZD_XnHL5d_Z_(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11804;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00006BC8 File Offset: 0x00004DC8
		internal bool #=z02DaXzdtpY7ZuTlFVnrD39qKUFYm(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11800;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00006BD8 File Offset: 0x00004DD8
		internal bool #=z2kuXskRzAs70csAujT1Ie$g1QWy$(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11801;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00006BE8 File Offset: 0x00004DE8
		internal bool #=zlXQhRnOWAv2noF1b01tI8qtJYh2r(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11802;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00006BF8 File Offset: 0x00004DF8
		internal bool #=zZTIAkG43kZVrDm1i0BDFh5PqySBG(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11803;
		}

		// Token: 0x04000047 RID: 71
		public static readonly #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU= #=zLkw0NRU= = new #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zyDNvciU=();

		// Token: 0x04000048 RID: 72
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zYWWKGjaic_r8d$QjyA==;

		// Token: 0x04000049 RID: 73
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zVMI07_YwzFh$Io$Nnw==;

		// Token: 0x0400004A RID: 74
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zd3$5uxjp9ghzZYpZGw==;

		// Token: 0x0400004B RID: 75
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=z1mN4RoXpK5y1WX7SQQ==;

		// Token: 0x0400004C RID: 76
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zxjO7$HLrmhKqxGJWWQ==;
	}
}
