﻿using System;
using System.Collections.Generic;

// Token: 0x020001BF RID: 447
internal sealed class #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU : List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>
{
	// Token: 0x06000D53 RID: 3411 RVA: 0x0006878C File Offset: 0x0006698C
	public bool #=zrJFmBpXHyl62(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zZ5kJVzhNAUVG)
	{
		if (#=zU4TPzxM=.#=zi2a1Q$EWsrif())
		{
			return false;
		}
		for (int i = 0; i < #=zZ5kJVzhNAUVG.Count; i++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=zZ5kJVzhNAUVG[i];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT() != null && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT().Contains(#=zU4TPzxM=.#=zMuFMjGQ=()))
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000D54 RID: 3412 RVA: 0x000687F0 File Offset: 0x000669F0
	public #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zIIyQciJSnOoKi3wyQA==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zp13pRNQ=, List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zZ5kJVzhNAUVG, List<int> #=zswOzKY7NkLeFU7Ob7y4qNtQ=)
	{
		if (#=zswOzKY7NkLeFU7Ob7y4qNtQ= == null)
		{
			#=zswOzKY7NkLeFU7Ob7y4qNtQ= = new List<int>();
		}
		for (int i = 0; i < #=zZ5kJVzhNAUVG.Count; i++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=zZ5kJVzhNAUVG[i];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT() != null)
			{
				#=zswOzKY7NkLeFU7Ob7y4qNtQ=.AddRange(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT());
			}
		}
		#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ result = null;
		double num = 0.0;
		for (int j = 0; j < base.Count; j++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = base[j];
			if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4() == #=zp13pRNQ= && !#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zi2a1Q$EWsrif() && !#=zswOzKY7NkLeFU7Ob7y4qNtQ=.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()) && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=() > num)
			{
				result = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$;
				num = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=();
			}
		}
		return result;
	}

	// Token: 0x06000D55 RID: 3413 RVA: 0x000688A8 File Offset: 0x00066AA8
	public static #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zx5vCqcUFWsBk(string #=zcpJ6bUA=)
	{
		#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU = new #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU();
		string[] array = #=zcpJ6bUA=.Split(new string[]
		{
			Environment.NewLine
		}, StringSplitOptions.RemoveEmptyEntries);
		#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
		for (int i = 0; i < array.Length; i++)
		{
			#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.#=zV_Jaipud2OIj6AvV0w== #=zV_Jaipud2OIj6AvV0w== = new #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.#=zV_Jaipud2OIj6AvV0w==();
			string text = array[i];
			int num = 0;
			while (!char.IsDigit(text[num + 1]))
			{
				num = text.IndexOf(' ', num + 1);
			}
			#=zV_Jaipud2OIj6AvV0w==.#=z6QPrZ_4= = text.Substring(0, num);
			string[] array2 = text.Substring(#=zV_Jaipud2OIj6AvV0w==.#=z6QPrZ_4=.Length + 1, text.IndexOf(',') - #=zV_Jaipud2OIj6AvV0w==.#=z6QPrZ_4=.Length - 1).Split(new char[]
			{
				'/'
			});
			#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zvRLj9WQ= = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Find(new Predicate<#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG>(#=zV_Jaipud2OIj6AvV0w==.#=zKWqWCnAJ__wodMNXyQ==));
			int #=zUTW72M70Fvrc = Convert.ToInt32(array2[0]);
			int #=z0i3iSog= = Convert.ToInt32(array2[1]);
			int #=z5w6HcG4= = Convert.ToInt32(array2[2]);
			int #=zEK0jbApsR_WU;
			if (array2.Length > 4)
			{
				#=zEK0jbApsR_WU = Convert.ToInt32(array2[3]);
				string text2 = array2[4];
			}
			else
			{
				#=zEK0jbApsR_WU = 0;
				string text3 = array2[3];
			}
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ item = new #=zrDcgv9ny10MzDWIXXLpHLoin_0n$(i, #=zvRLj9WQ=, #=zUTW72M70Fvrc, #=z0i3iSog=, #=zEK0jbApsR_WU, #=z5w6HcG4=, 0);
			#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Add(item);
		}
		return #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU;
	}

	// Token: 0x020001C0 RID: 448
	private sealed class #=zV_Jaipud2OIj6AvV0w==
	{
		// Token: 0x06000D57 RID: 3415 RVA: 0x000689E0 File Offset: 0x00066BE0
		internal bool #=zKWqWCnAJ__wodMNXyQ==(#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zQrqFdos=)
		{
			return #=zQrqFdos=.Name == this.#=z6QPrZ_4=;
		}

		// Token: 0x040007AC RID: 1964
		public string #=z6QPrZ_4=;
	}
}
