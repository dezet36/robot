﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000217 RID: 535
internal sealed class #=zcju5$uN1PXXbbiPydrm_fqtw2qRc3ZeiQ$Lz7oTcYAJiZuV8QVnmaqI= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001059 RID: 4185 RVA: 0x0007E9DC File Offset: 0x0007CBDC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x0600105A RID: 4186 RVA: 0x0007E9E0 File Offset: 0x0007CBE0
	protected override void #=zvb5bnug=()
	{
		#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg== #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg== = (#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==)this.#=zcDRV51Ut$7oP;
		UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
		int num = 0;
		while (num < 10 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z1WDH323JMKY$().Count != 0)
		{
			int num2 = this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() + #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zf0e9blCCGf6ut3r1Nw==();
			int num3 = this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() + #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zbRWovF5fxGmOqm7gAQ==();
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983423), new object[]
			{
				num2,
				num3
			});
			object[] array = (object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=zpeSgyDU=(num2, num3)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)];
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z1WDH323JMKY$().Count == 0)
				{
					break;
				}
				if (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878615)]) == 0 && (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]) < #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zUR9k9kQY04fa() || (#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z7JFejtRJqjAeXQAJwSKlDTTnS2Bn() && dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)].ToString() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908922165))) && !dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)) && !dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)))
				{
					int num4 = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
					if (!#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Contains(num4) && !#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zq$FF1Xp_gWzjPg1dZmUhwxQ4W63k().Contains(num4))
					{
						Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)];
						string text = dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)) ? dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)].ToString() : (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908919036) + dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)].ToString() + dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)].ToString()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871), string.Empty);
						UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
						unitSquadCollection.Add(new UnitSquad
						{
							Type = unitTypeCollection.FindOrCreate(#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z1WDH323JMKY$()[0]),
							Number = 1
						});
						string text2 = this.#=zBsXSanI=.#=ztRSQy0HcRHKziQrWOA==(num4, null, unitSquadCollection, 0);
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878604), new object[]
						{
							text,
							dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)],
							dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]
						});
						if (text2.Length < 10000)
						{
							if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921209)))
							{
								#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z1WDH323JMKY$().RemoveAt(0);
							}
							else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878808)) || text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878765)))
							{
								#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zq$FF1Xp_gWzjPg1dZmUhwxQ4W63k().Add(num4);
							}
							else if (!text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878721)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878444), new object[]
								{
									text2
								});
							}
						}
						else
						{
							#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Add(num4);
						}
					}
				}
			}
			#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zrYsCATIY3Mmo();
			if (array.Length == 0)
			{
				if (((this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() >= 0 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zf0e9blCCGf6ut3r1Nw==() < 0) || (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() < 0 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zf0e9blCCGf6ut3r1Nw==() >= 0)) && ((this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() >= 0 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zbRWovF5fxGmOqm7gAQ==() < 0) || (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() < 0 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zbRWovF5fxGmOqm7gAQ==() >= 0)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878398), new object[]
					{
						#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Count
					});
					this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Remove(this.#=zcDRV51Ut$7oP);
					break;
				}
				break;
			}
			else
			{
				num++;
			}
		}
		if (#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zwhK$$GndvTzZNGp_qw==() > 0 && #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Count >= #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=zwhK$$GndvTzZNGp_qw==())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878551), new object[]
			{
				#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Count
			});
			this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Remove(this.#=zcDRV51Ut$7oP);
			return;
		}
		if (#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=z1WDH323JMKY$().Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878160), new object[]
			{
				#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Count
			});
			this.#=z8StzeqE=.#=zGQl3yUpez1XJ().Remove(this.#=zcDRV51Ut$7oP);
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878314), new object[]
		{
			#=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==.#=ziSW13U6hvpcgX8hDGQ==().Count
		});
	}
}
