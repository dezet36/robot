﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000D9 RID: 217
internal sealed class #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== : List<#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG>
{
	// Token: 0x060005C7 RID: 1479 RVA: 0x0002FF74 File Offset: 0x0002E174
	public static #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zi1hFJwI=()
	{
		if (#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr == null)
		{
			#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zmHNyaeH1VqT_();
			if (#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr == null)
			{
				#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr = new #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==();
				ReadFileManager readFileManager = new ReadFileManager(FileResources.GeneralTypes, true);
				while (readFileManager.NextLine())
				{
					#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG item = new #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0), readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315), 1), false, 4, null);
					#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr.Add(item);
				}
			}
		}
		return #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zOHvkTyexIHpr;
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x0002FFF0 File Offset: 0x0002E1F0
	public #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA== #=z28jSeKWn3BZi()
	{
		if (base.Count <= 0)
		{
			return null;
		}
		return base[0].#=zBhjHkv0$tplT();
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x0003000C File Offset: 0x0002E20C
	public #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG in this)
		{
			if (#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG.Id == #=zAk8mKBk=)
			{
				return #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG;
			}
		}
		return null;
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x00030064 File Offset: 0x0002E264
	public #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zd634hMCtcd$T(int #=zAk8mKBk=)
	{
		#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG = this.#=zk$6QZNA=(#=zAk8mKBk=);
		if (#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG != null)
		{
			return #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG;
		}
		return new #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG(#=zAk8mKBk=, #=zAk8mKBk=.ToString(), false, 4, this.#=z28jSeKWn3BZi());
	}

	// Token: 0x04000269 RID: 617
	private static #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zOHvkTyexIHpr;
}
