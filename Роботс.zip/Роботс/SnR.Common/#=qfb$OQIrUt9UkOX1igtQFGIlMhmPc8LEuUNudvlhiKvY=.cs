﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

// Token: 0x02000010 RID: 16
internal static class #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=
{
	// Token: 0x06000037 RID: 55 RVA: 0x00003420 File Offset: 0x00001620
	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static long #=ze04twNQ=()
	{
		if (Assembly.GetCallingAssembly() != typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=).Assembly || !#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z2lYB1tdbY73_8Z7qmVRPX_pzHapr())
		{
			return 0L;
		}
		long result;
		lock (#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zifUFYfI7tI49SeS_2lo0C4T2RoDU)
		{
			long num = #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zifUFYfI7tI49SeS_2lo0C4T2RoDU.#=z1_VX2P2n9BH75dN1JBo6GGAEnt9R();
			if (num == 0L)
			{
				Assembly executingAssembly = Assembly.GetExecutingAssembly();
				List<byte> list = new List<byte>();
				AssemblyName assemblyName;
				try
				{
					assemblyName = executingAssembly.GetName();
				}
				catch
				{
					assemblyName = new AssemblyName(executingAssembly.FullName);
				}
				byte[] array = assemblyName.GetPublicKeyToken();
				if (array != null && array.Length == 0)
				{
					array = null;
				}
				if (array != null)
				{
					list.AddRange(array);
				}
				list.AddRange(Encoding.Unicode.GetBytes(assemblyName.Name));
				int num2 = #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=));
				int num3 = #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zJxMSUas=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52();
				list.Add((byte)(num2 >> 24));
				list.Add((byte)(num3 >> 16));
				list.Add((byte)(num2 >> 8));
				list.Add((byte)num3);
				list.Add((byte)(num2 >> 16));
				list.Add((byte)(num3 >> 8));
				list.Add((byte)num2);
				list.Add((byte)(num3 >> 24));
				int count = list.Count;
				ulong num4 = 0UL;
				for (int num5 = 0; num5 != count; num5++)
				{
					num4 += (ulong)list[num5];
					num4 += num4 << 20;
					num4 ^= num4 >> 12;
					list[num5] = 0;
				}
				num4 += num4 << 6;
				num4 ^= num4 >> 22;
				num4 += num4 << 30;
				num = (long)num4;
				num ^= 1890634235581159324L;
				#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zifUFYfI7tI49SeS_2lo0C4T2RoDU.#=zGWlgX$THSvuWd$9vSep4vzZFi2gn(num);
			}
			result = num;
		}
		return result;
	}

	// Token: 0x06000038 RID: 56 RVA: 0x000035E8 File Offset: 0x000017E8
	[MethodImpl(MethodImplOptions.NoInlining)]
	private static bool #=z2lYB1tdbY73_8Z7qmVRPX_pzHapr()
	{
		return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zYJ8wYjOpPK7O261IitTwl5D$35py();
	}

	// Token: 0x06000039 RID: 57 RVA: 0x000035F4 File Offset: 0x000017F4
	[MethodImpl(MethodImplOptions.NoInlining)]
	private static bool #=zYJ8wYjOpPK7O261IitTwl5D$35py()
	{
		StackTrace stackTrace = new StackTrace();
		StackFrame frame = stackTrace.GetFrame(3);
		MethodBase methodBase = (frame == null) ? null : frame.GetMethod();
		Type type = (methodBase == null) ? null : methodBase.DeclaringType;
		return type != typeof(RuntimeMethodHandle) && type != null && type.Assembly == typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=).Assembly;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00003658 File Offset: 0x00001858
	private static int #=z$AFJbHNFjtzMDp3YvAonFHHWBsni(Type #=zkw7VD0e35RWO99_cAs$aGq9iZGlT)
	{
		return #=zkw7VD0e35RWO99_cAs$aGq9iZGlT.MetadataToken;
	}

	// Token: 0x04000015 RID: 21
	private static #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zS6t7HW16N$Yx9qjlibGPYBTbje7d #=zifUFYfI7tI49SeS_2lo0C4T2RoDU = new #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zS6t7HW16N$Yx9qjlibGPYBTbje7d();

	// Token: 0x02000011 RID: 17
	private sealed class #=zJxMSUas=
	{
		// Token: 0x0600003C RID: 60 RVA: 0x00003668 File Offset: 0x00001868
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUMK4X5k=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zJxMSUas=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=za5WSwR4=)))), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52());
		}
	}

	// Token: 0x02000012 RID: 18
	private sealed class #=zS6t7HW16N$Yx9qjlibGPYBTbje7d
	{
		// Token: 0x0600003D RID: 61 RVA: 0x000036B8 File Offset: 0x000018B8
		internal #=zS6t7HW16N$Yx9qjlibGPYBTbje7d()
		{
			this.#=zGWlgX$THSvuWd$9vSep4vzZFi2gn(0L);
		}

		// Token: 0x0600003E RID: 62 RVA: 0x000036C8 File Offset: 0x000018C8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal long #=z1_VX2P2n9BH75dN1JBo6GGAEnt9R()
		{
			if (Assembly.GetCallingAssembly() != typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zS6t7HW16N$Yx9qjlibGPYBTbje7d).Assembly)
			{
				return 2918384L;
			}
			if (!#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z2lYB1tdbY73_8Z7qmVRPX_pzHapr())
			{
				return 2918384L;
			}
			int[] array = new int[]
			{
				0,
				0,
				0,
				~(-(~(-(-(~(~(-(~-1166434406))))))))
			};
			array[1] = -(~(-(~(-(~(~(-(~-1924798385))))))));
			array[2] = -(~(~(-(-(~(-(~(-(~(~-1059858593))))))))));
			array[0] = ~(-(~(-(~(-(-(~(~(-(~1925098677))))))))));
			int num = this.#=z_2$INd60ZwDNLIb$7kgM2NQ=;
			int num2 = this.#=z39Rq0zpMc8KltQM51slD6Ylrj$9w;
			int num3 = -(~(-(~(~(-(-(~(~1640531528))))))));
			int num4 = -(~(~(-(~(-(~(-(~(-(~957401308))))))))));
			for (int num5 = 0; num5 != 32; num5++)
			{
				num2 -= ((num << 4 ^ num >> 5) + num ^ num4 + array[num4 >> 11 & 3]);
				num4 -= num3;
				num -= ((num2 << 4 ^ num2 >> 5) + num2 ^ num4 + array[num4 & 3]);
			}
			for (int num6 = 0; num6 != 4; num6++)
			{
				array[num6] = 0;
			}
			ulong num7 = (ulong)((ulong)((long)num2) << 32);
			return (long)(num7 | (ulong)num);
		}

		// Token: 0x0600003F RID: 63 RVA: 0x000037E4 File Offset: 0x000019E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal void #=zGWlgX$THSvuWd$9vSep4vzZFi2gn(long #=zQhuK7OrUJFQBbVZQsTLTKK0=)
		{
			if (Assembly.GetCallingAssembly() != typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zS6t7HW16N$Yx9qjlibGPYBTbje7d).Assembly)
			{
				return;
			}
			if (!#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z2lYB1tdbY73_8Z7qmVRPX_pzHapr())
			{
				return;
			}
			int[] array = new int[4];
			array[1] = -(~(-(~(~(-(-(~(~(-(~-1924798386))))))))));
			array[0] = -(~(-(~(~(-(-(~(~1925098682))))))));
			array[2] = -(~(~(-(~(-(~(-(~-1059858598))))))));
			array[3] = ~(-(~(-(-(~(~(-(~-1166434406))))))));
			int num = ~(-(~(-(-(~(~(-(~1640531524))))))));
			int num2 = (int)#=zQhuK7OrUJFQBbVZQsTLTKK0=;
			int num3 = (int)(#=zQhuK7OrUJFQBbVZQsTLTKK0= >> 32);
			int num4 = 0;
			for (int num5 = 0; num5 != 32; num5++)
			{
				num2 += ((num3 << 4 ^ num3 >> 5) + num3 ^ num4 + array[num4 & 3]);
				num4 += num;
				num3 += ((num2 << 4 ^ num2 >> 5) + num2 ^ num4 + array[num4 >> 11 & 3]);
			}
			for (int num6 = 0; num6 != 4; num6++)
			{
				array[num6] = 0;
			}
			this.#=z_2$INd60ZwDNLIb$7kgM2NQ= = num2;
			this.#=z39Rq0zpMc8KltQM51slD6Ylrj$9w = num3;
		}

		// Token: 0x04000016 RID: 22
		private int #=z_2$INd60ZwDNLIb$7kgM2NQ=;

		// Token: 0x04000017 RID: 23
		private int #=z39Rq0zpMc8KltQM51slD6Ylrj$9w;
	}

	// Token: 0x02000013 RID: 19
	private sealed class #=zUKJAYq0=
	{
		// Token: 0x06000041 RID: 65 RVA: 0x000038E4 File Offset: 0x00001AE4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=za5WSwR4=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zJxMSUas=))), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zVnDyQrg=)) ^ ~(-(-(~(-(~(~(-(~(-(~1615011681)))))))))), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=za5WSwR4=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52())));
		}
	}

	// Token: 0x02000014 RID: 20
	private sealed class #=zUMK4X5k=
	{
		// Token: 0x06000043 RID: 67 RVA: 0x00003960 File Offset: 0x00001B60
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zVnDyQrg=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zg5x1YPY=)) ^ #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUMK4X5k=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zg5x1YPY=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52())));
		}
	}

	// Token: 0x02000015 RID: 21
	private sealed class #=zVnDyQrg=
	{
		// Token: 0x06000045 RID: 69 RVA: 0x000039C8 File Offset: 0x00001BC8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUMK4X5k=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52() ^ -(~(~(-(-(~(-(~(-(~(~-527758444)))))))))), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zg5x1YPY=))), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zJxMSUas=)) ^ #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=)), -(~(~(-(~(-(~(-(~2077273585))))))))));
		}
	}

	// Token: 0x02000016 RID: 22
	private static class #=z_RTO342fSw7ANPN3JTFwzyAZ_AU6
	{
		// Token: 0x06000046 RID: 70 RVA: 0x00003A38 File Offset: 0x00001C38
		internal static int #=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(int #=zfvd0tWD$Jg77SRNh_jz_S2cazguz, int #=zR6W2zbufIrVsiBN27FuRk9eB0PR2)
		{
			return #=zfvd0tWD$Jg77SRNh_jz_S2cazguz ^ #=zR6W2zbufIrVsiBN27FuRk9eB0PR2 - ~(-(-(~(-(~(-(~(~(-(~1486853272))))))))));
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00003A50 File Offset: 0x00001C50
		internal static int #=zY7DevvoimF9LCXtwoHGtSvOEzBCO(int #=zfvd0tWD$Jg77SRNh_jz_S2cazguz, int #=zR6W2zbufIrVsiBN27FuRk9eB0PR2)
		{
			return #=zfvd0tWD$Jg77SRNh_jz_S2cazguz - -(~(-(~(~(-(-(~(-(~(~-1743109966)))))))))) ^ #=zR6W2zbufIrVsiBN27FuRk9eB0PR2 + -(~(~(-(-(~(-(~(~(-(~-1231601094))))))))));
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003A78 File Offset: 0x00001C78
		internal static int #=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(int #=zfvd0tWD$Jg77SRNh_jz_S2cazguz, int #=zR6W2zbufIrVsiBN27FuRk9eB0PR2)
		{
			return #=zfvd0tWD$Jg77SRNh_jz_S2cazguz ^ (#=zR6W2zbufIrVsiBN27FuRk9eB0PR2 - -(~(-(~(-(~(~(-(~1361942460)))))))) ^ #=zfvd0tWD$Jg77SRNh_jz_S2cazguz - #=zR6W2zbufIrVsiBN27FuRk9eB0PR2);
		}
	}

	// Token: 0x02000017 RID: 23
	private sealed class #=za5WSwR4=
	{
		// Token: 0x0600004A RID: 74 RVA: 0x00003A98 File Offset: 0x00001C98
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zVnDyQrg=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52(), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=za5WSwR4=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUMK4X5k=.#=zEPENnY7yMtFihohrI_h1Qo4$Jn52())), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=)));
		}
	}

	// Token: 0x02000018 RID: 24
	private sealed class #=zg5x1YPY=
	{
		// Token: 0x0600004C RID: 76 RVA: 0x00003ADC File Offset: 0x00001CDC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int #=zEPENnY7yMtFihohrI_h1Qo4$Jn52()
		{
			return #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zg5x1YPY=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zJxMSUas=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zY7DevvoimF9LCXtwoHGtSvOEzBCO(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUMK4X5k=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zRpOnv0ci46NXlbHYxJL0TUZNjOeZ(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zVnDyQrg=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z_RTO342fSw7ANPN3JTFwzyAZ_AU6.#=zQM7XK$wA8T1cRDcAnA$h7NxvODsA(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=za5WSwR4=)), #=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=z$AFJbHNFjtzMDp3YvAonFHHWBsni(typeof(#=qfb$OQIrUt9UkOX1igtQFGIlMhmPc8LEuUNudvlhiKvY=.#=zUKJAYq0=)))))));
		}
	}
}
