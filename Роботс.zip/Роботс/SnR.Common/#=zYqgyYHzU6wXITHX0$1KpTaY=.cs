﻿using System;

// Token: 0x020001E8 RID: 488
internal sealed class #=zYqgyYHzU6wXITHX0$1KpTaY= : #=z36JBXQyrOsCqlqj$QTz_Lzc=
{
	// Token: 0x06000EC0 RID: 3776 RVA: 0x00076380 File Offset: 0x00074580
	internal override #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zZAPsYpRBEGf_()
	{
		return new #=z7najYys5p26JyZMBb3SOJ2o=();
	}

	// Token: 0x06000EC1 RID: 3777 RVA: 0x00076388 File Offset: 0x00074588
	internal override #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zlyKJojCmkfuG()
	{
		return new #=zYJAiLFGrYu7ExtOxWlwZzHledAAC();
	}
}
