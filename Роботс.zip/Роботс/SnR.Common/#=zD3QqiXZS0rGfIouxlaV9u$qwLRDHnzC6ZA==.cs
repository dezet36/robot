﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000DA RID: 218
internal sealed class #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==
{
	// Token: 0x060005CB RID: 1483 RVA: 0x00030094 File Offset: 0x0002E294
	public #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==(Dictionary<string, object> #=zSC7PxCoMyjeX$u0GmA==, string #=znSp3HeA$$w4X)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zSC7PxCoMyjeX$u0GmA==, #=znSp3HeA$$w4X);
		this.#=zp09oSB04$0qLMRalQQ== = this.#=zUdm9lEE9q$zk(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060905), 0.0);
		this.#=zYy7u9Z25a3nAxaDD8cjKmmiyFZER = new List<double>();
		int num = 1;
		while (dictionary.ContainsKey(num.ToString()))
		{
			double num2 = this.#=zUdm9lEE9q$zk(dictionary, num.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060891), 0.0);
			this.#=zYy7u9Z25a3nAxaDD8cjKmmiyFZER.Add(num2 / this.#=zp09oSB04$0qLMRalQQ==);
			num++;
		}
		Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588));
		this.#=zZtEVG9Zt8Bx7 = new List<#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==>();
		int num3 = 1;
		while (dictionary2.ContainsKey(num3.ToString()))
		{
			Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary2, num3.ToString());
			int num4 = 1;
			while (dictionary3.ContainsKey(num4.ToString()))
			{
				num4++;
			}
			int num5 = 1;
			int #=z$Ib9gYQ= = num4 - 1;
			double num6 = this.#=zUdm9lEE9q$zk(dictionary3, num5.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060884), 0.0);
			double num7 = this.#=zUdm9lEE9q$zk(dictionary3, #=z$Ib9gYQ=.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060884), 0.0);
			List<#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==> list = this.#=zZtEVG9Zt8Bx7;
			#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg== #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg== = new #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==();
			#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zN$ZzBOHbXzEf(#=z$Ib9gYQ=);
			#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zgBlL3_zh1lX8(num6 / this.#=zp09oSB04$0qLMRalQQ==);
			#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zpnk5VVbxf0Sq(num7 / this.#=zp09oSB04$0qLMRalQQ==);
			list.Add(#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==);
			num3++;
		}
		this.#=zCYflB8Bp47jXROAvKrqUTz4= = new Dictionary<int, int>();
		Dictionary<string, object> dictionary4 = JSONManager.ExtractDictionary(dictionary2, (this.#=zZtEVG9Zt8Bx7.Count - 1).ToString());
		int num8 = 1;
		while (dictionary4.ContainsKey(num8.ToString()))
		{
			int @int = JSONManager.GetInt(dictionary4, num8.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060877), 0);
			this.#=zCYflB8Bp47jXROAvKrqUTz4=[num8] = @int;
			num8++;
		}
		this.#=zcz3R5mX3wXXyhFfhqKIYvXux0P16 = new List<int>
		{
			0,
			5,
			15,
			25,
			35,
			50
		};
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x000302CC File Offset: 0x0002E4CC
	public List<int> #=zU_hwy6iIKqOTpVC7XxbjykhJ2rAr()
	{
		return this.#=zcz3R5mX3wXXyhFfhqKIYvXux0P16;
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x000302D4 File Offset: 0x0002E4D4
	private double #=zUdm9lEE9q$zk(Dictionary<string, object> #=zYEcCIbg=, string #=zNraCe1Y=, double #=zJeYCQZg=)
	{
		object[] array = JSONManager.GetArray(#=zYEcCIbg=, #=zNraCe1Y=);
		if (array == null)
		{
			return #=zJeYCQZg=;
		}
		if (array.Length == 0)
		{
			return #=zJeYCQZg=;
		}
		return Convert.ToDouble(array[0]);
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x000302FC File Offset: 0x0002E4FC
	private double #=zDLiQIHMHocuTy1Tlnw==(int #=zUTW72M70Fvrc)
	{
		if (#=zUTW72M70Fvrc >= 1 && #=zUTW72M70Fvrc <= this.#=zYy7u9Z25a3nAxaDD8cjKmmiyFZER.Count)
		{
			return this.#=zYy7u9Z25a3nAxaDD8cjKmmiyFZER[#=zUTW72M70Fvrc - 1];
		}
		throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059343), new object[]
		{
			#=zUTW72M70Fvrc
		});
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00030348 File Offset: 0x0002E548
	private #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg== #=zWIieKTLZ7zqY(int #=z0i3iSog=)
	{
		if (#=z0i3iSog= >= 1 && #=z0i3iSog= <= this.#=zZtEVG9Zt8Bx7.Count)
		{
			return this.#=zZtEVG9Zt8Bx7[#=z0i3iSog= - 1];
		}
		throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059539), new object[]
		{
			#=z0i3iSog=
		});
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x00030394 File Offset: 0x0002E594
	private double #=zn$Ue_ZUvrQa8(int #=z0i3iSog=, int #=z5w6HcG4=)
	{
		#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg== #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg== = this.#=zWIieKTLZ7zqY(#=z0i3iSog=);
		double num = ((double)#=z5w6HcG4= - 1.0) / ((double)#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zaDKBEnk8Vsod() - 1.0);
		return #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zJYKibYVjSOeP() + (#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=z7oFO_AGnloVR() - #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==.#=zJYKibYVjSOeP()) * num;
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x000303E0 File Offset: 0x0002E5E0
	private double #=zBzCpIiEJLPmRpq$VyA==(int #=z0i3iSog=)
	{
		return this.#=zWIieKTLZ7zqY(#=z0i3iSog=).#=z7oFO_AGnloVR();
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x000303F0 File Offset: 0x0002E5F0
	private double #=zjTPNDBUrJao0BvAvNQ==(int #=zC_LWydoilQVqNucSpQ==)
	{
		if (#=zC_LWydoilQVqNucSpQ== >= 0 && #=zC_LWydoilQVqNucSpQ== < this.#=zcz3R5mX3wXXyhFfhqKIYvXux0P16.Count)
		{
			return 1.0 + 0.01 * (double)this.#=zcz3R5mX3wXXyhFfhqKIYvXux0P16[#=zC_LWydoilQVqNucSpQ==];
		}
		throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059489), new object[]
		{
			#=zC_LWydoilQVqNucSpQ==
		});
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x00030450 File Offset: 0x0002E650
	private double #=zjTPNDBUrJao0BvAvNQ==(int[] #=zBHbuR2n6nU7$, int #=zSPLDPE4=)
	{
		if (#=zBHbuR2n6nU7$ == null)
		{
			return 1.0;
		}
		return this.#=zjTPNDBUrJao0BvAvNQ==(#=zBHbuR2n6nU7$[#=zSPLDPE4=]);
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x00030468 File Offset: 0x0002E668
	private double #=zIGDXT83h4UOSKUNuZw==(int[] #=zBHbuR2n6nU7$)
	{
		if (#=zBHbuR2n6nU7$ == null)
		{
			return 1.0;
		}
		int num = 0;
		for (int i = 0; i < #=zBHbuR2n6nU7$.Length; i++)
		{
			if (#=zBHbuR2n6nU7$[i] > num)
			{
				num = #=zBHbuR2n6nU7$[i];
			}
		}
		return this.#=zjTPNDBUrJao0BvAvNQ==(num);
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x000304A4 File Offset: 0x0002E6A4
	private double #=zwrXiiUg9VKYD(int #=zEK0jbApsR_WU)
	{
		return 1.0 + 0.05 * (double)#=zEK0jbApsR_WU;
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x000304BC File Offset: 0x0002E6BC
	public int #=z$SLcm8wly5I$()
	{
		return this.#=zZtEVG9Zt8Bx7.Count;
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x000304CC File Offset: 0x0002E6CC
	public int #=zE4sG9qwcF06$(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		int num = this.#=zWIieKTLZ7zqY(#=zU4TPzxM=.#=ztj93y6niVpCR()).#=zaDKBEnk8Vsod();
		if (#=zU4TPzxM=.#=zVm_gjb4pLtQN() == 0 && num > 30)
		{
			num = 30;
		}
		return num;
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x000304FC File Offset: 0x0002E6FC
	public double #=zIttox1M=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		return this.#=zDLiQIHMHocuTy1Tlnw==(#=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==()) * this.#=zn$Ue_ZUvrQa8(#=zU4TPzxM=.#=ztj93y6niVpCR(), #=zU4TPzxM=.#=zvnZc$RhG_1Du()) * this.#=zIGDXT83h4UOSKUNuZw==(#=zU4TPzxM=.#=zJ6MFTstpNdtu4Bsjrw==()) * this.#=zwrXiiUg9VKYD(#=zU4TPzxM=.#=zVm_gjb4pLtQN());
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x00030538 File Offset: 0x0002E738
	public double #=zpoRmlojd2iH8(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		return this.#=zDLiQIHMHocuTy1Tlnw==(#=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==()) * this.#=zBzCpIiEJLPmRpq$VyA==(#=zU4TPzxM=.#=ztj93y6niVpCR()) * this.#=zIGDXT83h4UOSKUNuZw==(#=zU4TPzxM=.#=zJ6MFTstpNdtu4Bsjrw==()) * this.#=zwrXiiUg9VKYD(#=zU4TPzxM=.#=zVm_gjb4pLtQN());
	}

	// Token: 0x060005DA RID: 1498 RVA: 0x00030570 File Offset: 0x0002E770
	public int #=zV5ExdG_LnjKvL2xqmjiS75A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=zCYflB8Bp47jXROAvKrqUTz4=.ContainsKey(#=zU4TPzxM=.#=zvnZc$RhG_1Du()))
		{
			return this.#=zCYflB8Bp47jXROAvKrqUTz4=[#=zU4TPzxM=.#=zvnZc$RhG_1Du()];
		}
		return 525;
	}

	// Token: 0x060005DB RID: 1499 RVA: 0x0003059C File Offset: 0x0002E79C
	public double #=zL9KMJ9Y=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		return this.#=zp09oSB04$0qLMRalQQ== * this.#=zIttox1M=(#=zU4TPzxM=);
	}

	// Token: 0x0400026A RID: 618
	private double #=zp09oSB04$0qLMRalQQ==;

	// Token: 0x0400026B RID: 619
	private List<double> #=zYy7u9Z25a3nAxaDD8cjKmmiyFZER;

	// Token: 0x0400026C RID: 620
	private List<#=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==> #=zZtEVG9Zt8Bx7;

	// Token: 0x0400026D RID: 621
	private List<int> #=zcz3R5mX3wXXyhFfhqKIYvXux0P16;

	// Token: 0x0400026E RID: 622
	private Dictionary<int, int> #=zCYflB8Bp47jXROAvKrqUTz4=;
}
