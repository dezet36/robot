﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.Managers;

// Token: 0x02000216 RID: 534
internal sealed class #=zcju5$uN1PXXbbiPydrm_fmxsscNNICBypc9SgqmSLLzxSSqkiw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001056 RID: 4182 RVA: 0x0007E5FC File Offset: 0x0007C7FC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zDQRZGh8= = #=zuJjQ1XU=.#=zJTtJgwWTp9gijtuuAA==();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
	}

	// Token: 0x06001057 RID: 4183 RVA: 0x0007E618 File Offset: 0x0007C818
	protected override void #=zvb5bnug=()
	{
		if (!this.#=zDQRZGh8=.#=z6MYBfs3dpkwm())
		{
			return;
		}
		int num = this.#=zCY4az9$WUjLsEJ7fgg==.#=z2cw4dd0=(28430);
		if (this.#=zDQRZGh8=.#=zfeAuAuTFIUk$ZhBQzw==() && this.#=zDQRZGh8=.#=zQ7ygciKkebhEvwzqLUW7vIE=() > 0)
		{
			int num2 = num + this.#=zDQRZGh8=.#=zcvNx6XGgs__ws7999w==();
			int num3 = (num2 > 0) ? ((this.#=zDQRZGh8=.#=zp_aXyfSPS2SK() - this.#=zDQRZGh8=.#=zQ7ygciKkebhEvwzqLUW7vIE=()) / num2) : 0;
			if (this.#=zDQRZGh8=.#=zQ7ygciKkebhEvwzqLUW7vIE=() >= num3 && num2 < 144)
			{
				string text = this.#=zBsXSanI=.#=zalB6bH$XAqaFZVzivG8KkfQt0H0k();
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967714), Array.Empty<object>());
					base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967934), new object[]
					{
						text
					});
				}
			}
		}
		bool flag = true;
		while (flag)
		{
			flag = false;
			num = this.#=zCY4az9$WUjLsEJ7fgg==.#=z2cw4dd0=(28430);
			if (this.#=zDQRZGh8=.#=z9YzLV$hp8NK$().Count == 36 && this.#=zDQRZGh8=.#=zj$g2Nu72AlHi() < 4)
			{
				string text2 = this.#=zBsXSanI=.#=zgBGzAD4pD1A6r8zlGQ==();
				if (text2.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967877), Array.Empty<object>());
					base.#=zL1HTbwC75LO$(JSONManager.GetData(text2));
					flag = true;
					this.#=zDQRZGh8=.#=zwvUbzGECX4A2yMf_HQ==(-1);
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967817), new object[]
					{
						text2
					});
				}
			}
			if (this.#=zDQRZGh8=.#=zVL6eyHdiImEax4IH9A==() < 0)
			{
				int num4 = 0;
				while (this.#=zDQRZGh8=.#=zYElf33kvwWUgxXThrpQDfeg=().Contains(num4) && num4 < 4)
				{
					num4++;
				}
				string text3 = this.#=zBsXSanI=.#=z_7p5vRiirljDfHALeiFkc8A2Dv92(num4);
				if (text3.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967496), new object[]
					{
						num4 + 1
					});
					base.#=zL1HTbwC75LO$(JSONManager.GetData(text3));
					flag = true;
					this.#=zDQRZGh8=.#=z9YzLV$hp8NK$().Clear();
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967476), new object[]
					{
						num4 + 1,
						text3
					});
				}
			}
			if (num > 0)
			{
				List<int> list = new List<int>();
				StringBuilder stringBuilder = new StringBuilder();
				int num5 = 1;
				while (num5 <= 36 && list.Count < num)
				{
					if (!this.#=zDQRZGh8=.#=z9YzLV$hp8NK$().Contains(num5))
					{
						list.Add(num5);
						if (stringBuilder.Length > 0)
						{
							stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
						}
						stringBuilder.Append(num5);
					}
					num5++;
				}
				if (list.Count > 0)
				{
					string text4 = this.#=zBsXSanI=.#=zf_kcxgfuggif6HMgUQ==(list);
					if (text4.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967426), new object[]
						{
							stringBuilder
						});
						base.#=zL1HTbwC75LO$(JSONManager.GetData(text4));
						flag = true;
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967657), new object[]
						{
							stringBuilder,
							text4
						});
					}
				}
			}
		}
	}

	// Token: 0x040008F4 RID: 2292
	private #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ== #=zDQRZGh8=;

	// Token: 0x040008F5 RID: 2293
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;
}
