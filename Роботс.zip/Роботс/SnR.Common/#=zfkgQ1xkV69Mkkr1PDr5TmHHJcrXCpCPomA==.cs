﻿using System;
using Skink.SnR.Common.GZip;

// Token: 0x02000239 RID: 569
internal sealed class #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==
{
	// Token: 0x0600115C RID: 4444 RVA: 0x00085C2C File Offset: 0x00083E2C
	internal #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==()
	{
		this.#=zDsOPwvAFrw_PWDhdrw== = new short[#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zCO1be_pw_8RU * 2];
		this.#=zrcMr8pqkhRLQ = new short[(2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zy6c71GKkjESr + 1) * 2];
		this.#=zuqfjDpP_X5Bw = new short[(2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zC6iFNr6sEM6VSyYjjg== + 1) * 2];
	}

	// Token: 0x0600115E RID: 4446 RVA: 0x00085E0C File Offset: 0x0008400C
	private void #=zPJWoWjb64o8z()
	{
		this.#=z_k2pBquMtfoC = 2 * this.#=zzb8ZcArEaC3W;
		Array.Clear(this.#=z6_6XQKs=, 0, this.#=z6COySntztyaf);
		this.#=zVsqOgh8= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=.#=z55MbmG4=(this.#=zltbHchNfArRn);
		this.#=zWJQOm6YsQXyUh9uYJw==();
		this.#=zeA_K5S0njaXQlITcUw== = 0;
		this.#=zlbu_H6vQDZui = 0;
		this.#=zvVLPn87OcsrNH_47wA== = 0;
		this.#=zZMe5LEQ2DIie = (this.#=zzWrVcDTzyiEX = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1);
		this.#=z2ke40tS7SV6r = 0;
		this.#=zJpjhfe4b$c0e = 0;
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x00085E8C File Offset: 0x0008408C
	private void #=z2gezqg2v5NsB()
	{
		this.#=zuDE8VGQ9_O5V.#=zVnLx7cu3S4sV = this.#=zDsOPwvAFrw_PWDhdrw==;
		this.#=zuDE8VGQ9_O5V.#=zb9dSZnEz1qIR = #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zcWP_MIw=;
		this.#=zR0loHvxEjwywO1Iidg==.#=zVnLx7cu3S4sV = this.#=zrcMr8pqkhRLQ;
		this.#=zR0loHvxEjwywO1Iidg==.#=zb9dSZnEz1qIR = #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zyMm7t6GJlzMbbFogaA==;
		this.#=z1GTenplEBYm2.#=zVnLx7cu3S4sV = this.#=zuqfjDpP_X5Bw;
		this.#=z1GTenplEBYm2.#=zb9dSZnEz1qIR = #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zTYlxgh4cXXjk;
		this.#=zhBP95zayY8AN = 0;
		this.#=zcXxMrmM9nuW4 = 0;
		this.#=zsA8UeIo$tsLcz_j3iw== = 8;
		this.#=zAzSUkRVFuKPU();
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x00085F18 File Offset: 0x00084118
	internal void #=zAzSUkRVFuKPU()
	{
		for (int i = 0; i < #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zexLItYjL27h5; i++)
		{
			this.#=zDsOPwvAFrw_PWDhdrw==[i * 2] = 0;
		}
		for (int j = 0; j < #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zy6c71GKkjESr; j++)
		{
			this.#=zrcMr8pqkhRLQ[j * 2] = 0;
		}
		for (int k = 0; k < #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zC6iFNr6sEM6VSyYjjg==; k++)
		{
			this.#=zuqfjDpP_X5Bw[k * 2] = 0;
		}
		this.#=zDsOPwvAFrw_PWDhdrw==[#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgl3Y5C_JJ1D8 * 2] = 1;
		this.#=z3nPze4xN8xfT = (this.#=zQzrhsNbgIMpy = 0);
		this.#=zQ5CGcJs$SF9h = (this.#=zKQzkG64= = 0);
	}

	// Token: 0x06001161 RID: 4449 RVA: 0x00085FA8 File Offset: 0x000841A8
	internal void #=zCu4lG9BjZkFjY$eOAg==(short[] #=zZUWDhT4=, int #=zzGl$RlI=)
	{
		int num = this.#=zpXKZvhI=[#=zzGl$RlI=];
		for (int i = #=zzGl$RlI= << 1; i <= this.#=zh85prTr2G_WY; i <<= 1)
		{
			if (i < this.#=zh85prTr2G_WY && #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zIebAsXVOmPS3Rk0zOw==(#=zZUWDhT4=, this.#=zpXKZvhI=[i + 1], this.#=zpXKZvhI=[i], this.#=z8h8JAHU=))
			{
				i++;
			}
			if (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zIebAsXVOmPS3Rk0zOw==(#=zZUWDhT4=, num, this.#=zpXKZvhI=[i], this.#=z8h8JAHU=))
			{
				break;
			}
			this.#=zpXKZvhI=[#=zzGl$RlI=] = this.#=zpXKZvhI=[i];
			#=zzGl$RlI= = i;
		}
		this.#=zpXKZvhI=[#=zzGl$RlI=] = num;
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x00086034 File Offset: 0x00084234
	internal static bool #=zIebAsXVOmPS3Rk0zOw==(short[] #=zZUWDhT4=, int #=zpvGJrv4=, int #=z8f5WtV0=, sbyte[] #=z8h8JAHU=)
	{
		short num = #=zZUWDhT4=[#=zpvGJrv4= * 2];
		short num2 = #=zZUWDhT4=[#=z8f5WtV0= * 2];
		return num < num2 || (num == num2 && #=z8h8JAHU=[#=zpvGJrv4=] <= #=z8h8JAHU=[#=z8f5WtV0=]);
	}

	// Token: 0x06001163 RID: 4451 RVA: 0x00086064 File Offset: 0x00084264
	internal void #=zZle7Mwiz3ocj(short[] #=zZUWDhT4=, int #=zDjtKVgb3mIkZ)
	{
		int num = -1;
		int num2 = (int)#=zZUWDhT4=[1];
		int num3 = 0;
		int num4 = 7;
		int num5 = 4;
		if (num2 == 0)
		{
			num4 = 138;
			num5 = 3;
		}
		#=zZUWDhT4=[(#=zDjtKVgb3mIkZ + 1) * 2 + 1] = short.MaxValue;
		for (int i = 0; i <= #=zDjtKVgb3mIkZ; i++)
		{
			int num6 = num2;
			num2 = (int)#=zZUWDhT4=[(i + 1) * 2 + 1];
			if (++num3 >= num4 || num6 != num2)
			{
				if (num3 < num5)
				{
					this.#=zuqfjDpP_X5Bw[num6 * 2] = (short)((int)this.#=zuqfjDpP_X5Bw[num6 * 2] + num3);
				}
				else if (num6 != 0)
				{
					if (num6 != num)
					{
						short[] array = this.#=zuqfjDpP_X5Bw;
						int num7 = num6 * 2;
						array[num7] += 1;
					}
					short[] array2 = this.#=zuqfjDpP_X5Bw;
					int num8 = #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z3mQdQlI$L62c * 2;
					array2[num8] += 1;
				}
				else if (num3 <= 10)
				{
					short[] array3 = this.#=zuqfjDpP_X5Bw;
					int num9 = #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z4iBqsDKHpHV6bSPFyQ== * 2;
					array3[num9] += 1;
				}
				else
				{
					short[] array4 = this.#=zuqfjDpP_X5Bw;
					int num10 = #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=znkdM0JtXkHZEq$NDTw== * 2;
					array4[num10] += 1;
				}
				num3 = 0;
				num = num6;
				if (num2 == 0)
				{
					num4 = 138;
					num5 = 3;
				}
				else if (num6 == num2)
				{
					num4 = 6;
					num5 = 3;
				}
				else
				{
					num4 = 7;
					num5 = 4;
				}
			}
		}
	}

	// Token: 0x06001164 RID: 4452 RVA: 0x0008617C File Offset: 0x0008437C
	internal int #=zLLq2eFVt3JVtEZfYDQ==()
	{
		this.#=zZle7Mwiz3ocj(this.#=zDsOPwvAFrw_PWDhdrw==, this.#=zuDE8VGQ9_O5V.#=zDjtKVgb3mIkZ);
		this.#=zZle7Mwiz3ocj(this.#=zrcMr8pqkhRLQ, this.#=zR0loHvxEjwywO1Iidg==.#=zDjtKVgb3mIkZ);
		this.#=z1GTenplEBYm2.#=zS0Twt13P67pD(this);
		int num = #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zC6iFNr6sEM6VSyYjjg== - 1;
		while (num >= 3 && this.#=zuqfjDpP_X5Bw[(int)(#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zIRTm2U81INPo[num] * 2 + 1)] == 0)
		{
			num--;
		}
		this.#=z3nPze4xN8xfT += 3 * (num + 1) + 5 + 5 + 4;
		return num;
	}

	// Token: 0x06001165 RID: 4453 RVA: 0x00086204 File Offset: 0x00084404
	internal void #=znZHmfpnOrW3imJvNeg==(int #=zG4VswDTKrrRq, int #=zGgLL8R24BOVG, int #=zpz3NVj_WitrA)
	{
		this.#=zmpnZYBar22uK(#=zG4VswDTKrrRq - 257, 5);
		this.#=zmpnZYBar22uK(#=zGgLL8R24BOVG - 1, 5);
		this.#=zmpnZYBar22uK(#=zpz3NVj_WitrA - 4, 4);
		for (int i = 0; i < #=zpz3NVj_WitrA; i++)
		{
			this.#=zmpnZYBar22uK((int)this.#=zuqfjDpP_X5Bw[(int)(#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zIRTm2U81INPo[i] * 2 + 1)], 3);
		}
		this.#=zmUndQ0gxaPSE(this.#=zDsOPwvAFrw_PWDhdrw==, #=zG4VswDTKrrRq - 1);
		this.#=zmUndQ0gxaPSE(this.#=zrcMr8pqkhRLQ, #=zGgLL8R24BOVG - 1);
	}

	// Token: 0x06001166 RID: 4454 RVA: 0x00086278 File Offset: 0x00084478
	internal void #=zmUndQ0gxaPSE(short[] #=zZUWDhT4=, int #=zDjtKVgb3mIkZ)
	{
		int num = -1;
		int num2 = (int)#=zZUWDhT4=[1];
		int num3 = 0;
		int num4 = 7;
		int num5 = 4;
		if (num2 == 0)
		{
			num4 = 138;
			num5 = 3;
		}
		for (int i = 0; i <= #=zDjtKVgb3mIkZ; i++)
		{
			int num6 = num2;
			num2 = (int)#=zZUWDhT4=[(i + 1) * 2 + 1];
			if (++num3 >= num4 || num6 != num2)
			{
				if (num3 < num5)
				{
					do
					{
						this.#=z6teJui46vpSY(num6, this.#=zuqfjDpP_X5Bw);
					}
					while (--num3 != 0);
				}
				else if (num6 != 0)
				{
					if (num6 != num)
					{
						this.#=z6teJui46vpSY(num6, this.#=zuqfjDpP_X5Bw);
						num3--;
					}
					this.#=z6teJui46vpSY(#=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z3mQdQlI$L62c, this.#=zuqfjDpP_X5Bw);
					this.#=zmpnZYBar22uK(num3 - 3, 2);
				}
				else if (num3 <= 10)
				{
					this.#=z6teJui46vpSY(#=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z4iBqsDKHpHV6bSPFyQ==, this.#=zuqfjDpP_X5Bw);
					this.#=zmpnZYBar22uK(num3 - 3, 3);
				}
				else
				{
					this.#=z6teJui46vpSY(#=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=znkdM0JtXkHZEq$NDTw==, this.#=zuqfjDpP_X5Bw);
					this.#=zmpnZYBar22uK(num3 - 11, 7);
				}
				num3 = 0;
				num = num6;
				if (num2 == 0)
				{
					num4 = 138;
					num5 = 3;
				}
				else if (num6 == num2)
				{
					num4 = 6;
					num5 = 3;
				}
				else
				{
					num4 = 7;
					num5 = 4;
				}
			}
		}
	}

	// Token: 0x06001167 RID: 4455 RVA: 0x00086384 File Offset: 0x00084584
	private void #=z1lTnzuk84TZ$(byte[] #=z6Q8LaXo=, int #=z1qaC5B0=, int #=zZBlusgI=)
	{
		Array.Copy(#=z6Q8LaXo=, #=z1qaC5B0=, this.#=zgG3ckmc=, this.#=zr2hx6oQ=, #=zZBlusgI=);
		this.#=zr2hx6oQ= += #=zZBlusgI=;
	}

	// Token: 0x06001168 RID: 4456 RVA: 0x000863A8 File Offset: 0x000845A8
	internal void #=z6teJui46vpSY(int #=zQUn_5_A=, short[] #=zZUWDhT4=)
	{
		int num = #=zQUn_5_A= * 2;
		this.#=zmpnZYBar22uK((int)#=zZUWDhT4=[num] & 65535, (int)#=zZUWDhT4=[num + 1] & 65535);
	}

	// Token: 0x06001169 RID: 4457 RVA: 0x000863D4 File Offset: 0x000845D4
	internal void #=zmpnZYBar22uK(int #=z$Ib9gYQ=, int #=z7HqoPh0=)
	{
		if (this.#=zcXxMrmM9nuW4 > #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=z2iv4I6teQPhz - #=z7HqoPh0=)
		{
			this.#=zhBP95zayY8AN |= (short)(#=z$Ib9gYQ= << this.#=zcXxMrmM9nuW4);
			byte[] array = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array[num] = (byte)this.#=zhBP95zayY8AN;
			byte[] array2 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array2[num] = (byte)(this.#=zhBP95zayY8AN >> 8);
			this.#=zhBP95zayY8AN = (short)((uint)#=z$Ib9gYQ= >> #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=z2iv4I6teQPhz - this.#=zcXxMrmM9nuW4);
			this.#=zcXxMrmM9nuW4 += #=z7HqoPh0= - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=z2iv4I6teQPhz;
			return;
		}
		this.#=zhBP95zayY8AN |= (short)(#=z$Ib9gYQ= << this.#=zcXxMrmM9nuW4);
		this.#=zcXxMrmM9nuW4 += #=z7HqoPh0=;
	}

	// Token: 0x0600116A RID: 4458 RVA: 0x000864A4 File Offset: 0x000846A4
	internal void #=zxrZLfT1Nw9Qf()
	{
		this.#=zmpnZYBar22uK(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmg5v$PzOFuq8biuDeQ== << 1, 3);
		this.#=z6teJui46vpSY(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgl3Y5C_JJ1D8, #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zBDb5Ka_po3rvrTsOUg==);
		this.#=zqkouHPl84sVX();
		if (1 + this.#=zsA8UeIo$tsLcz_j3iw== + 10 - this.#=zcXxMrmM9nuW4 < 9)
		{
			this.#=zmpnZYBar22uK(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmg5v$PzOFuq8biuDeQ== << 1, 3);
			this.#=z6teJui46vpSY(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgl3Y5C_JJ1D8, #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zBDb5Ka_po3rvrTsOUg==);
			this.#=zqkouHPl84sVX();
		}
		this.#=zsA8UeIo$tsLcz_j3iw== = 7;
	}

	// Token: 0x0600116B RID: 4459 RVA: 0x00086518 File Offset: 0x00084718
	internal bool #=zl5dNX0JPbwpWIgk5ag==(int #=z0id6pM2wr9jd, int #=zUFUU8Dk=)
	{
		this.#=zgG3ckmc=[this.#=zhhX$L2GhNIGR + this.#=zQ5CGcJs$SF9h * 2] = (byte)((uint)#=z0id6pM2wr9jd >> 8);
		this.#=zgG3ckmc=[this.#=zhhX$L2GhNIGR + this.#=zQ5CGcJs$SF9h * 2 + 1] = (byte)#=z0id6pM2wr9jd;
		this.#=zgG3ckmc=[this.#=zjIfLx08Qsx1R + this.#=zQ5CGcJs$SF9h] = (byte)#=zUFUU8Dk=;
		this.#=zQ5CGcJs$SF9h++;
		if (#=z0id6pM2wr9jd == 0)
		{
			short[] array = this.#=zDsOPwvAFrw_PWDhdrw==;
			int num = #=zUFUU8Dk= * 2;
			array[num] += 1;
		}
		else
		{
			this.#=zKQzkG64=++;
			#=z0id6pM2wr9jd--;
			short[] array2 = this.#=zDsOPwvAFrw_PWDhdrw==;
			int num2 = ((int)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zsobUQ2s=[#=zUFUU8Dk=] + #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z8or$P5xhr503XB4g1A== + 1) * 2;
			array2[num2] += 1;
			short[] array3 = this.#=zrcMr8pqkhRLQ;
			int num3 = #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zql2UPBE=(#=z0id6pM2wr9jd) * 2;
			array3[num3] += 1;
		}
		if ((this.#=zQ5CGcJs$SF9h & 8191) == 0 && this.#=zltbHchNfArRn > CompressionLevel.Level2)
		{
			int num4 = this.#=zQ5CGcJs$SF9h << 3;
			int num5 = this.#=zeA_K5S0njaXQlITcUw== - this.#=zlbu_H6vQDZui;
			for (int i = 0; i < #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zy6c71GKkjESr; i++)
			{
				num4 = (int)((long)num4 + (long)this.#=zrcMr8pqkhRLQ[i * 2] * (5L + (long)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=ziI2CPZrUbbyH[i]));
			}
			num4 >>= 3;
			if (this.#=zKQzkG64= < this.#=zQ5CGcJs$SF9h / 2 && num4 < num5 / 2)
			{
				return true;
			}
		}
		return this.#=zQ5CGcJs$SF9h == this.#=zHSo1xM06V91z7wLekA== - 1 || this.#=zQ5CGcJs$SF9h == this.#=zHSo1xM06V91z7wLekA==;
	}

	// Token: 0x0600116C RID: 4460 RVA: 0x0008667C File Offset: 0x0008487C
	internal void #=zXpTvU2Gdrwiexf3PZA==(short[] #=zn7WZLHmxufVR, short[] #=zQ5O21TQ=)
	{
		int num = 0;
		if (this.#=zQ5CGcJs$SF9h != 0)
		{
			do
			{
				int num2 = this.#=zhhX$L2GhNIGR + num * 2;
				int num3 = ((int)this.#=zgG3ckmc=[num2] << 8 & 65280) | (int)(this.#=zgG3ckmc=[num2 + 1] & byte.MaxValue);
				int num4 = (int)(this.#=zgG3ckmc=[this.#=zjIfLx08Qsx1R + num] & byte.MaxValue);
				num++;
				if (num3 == 0)
				{
					this.#=z6teJui46vpSY(num4, #=zn7WZLHmxufVR);
				}
				else
				{
					int num5 = (int)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zsobUQ2s=[num4];
					this.#=z6teJui46vpSY(num5 + #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z8or$P5xhr503XB4g1A== + 1, #=zn7WZLHmxufVR);
					int num6 = #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zzQyDK_wHTKNo[num5];
					if (num6 != 0)
					{
						num4 -= #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zHuD6mw0=[num5];
						this.#=zmpnZYBar22uK(num4, num6);
					}
					num3--;
					num5 = #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zql2UPBE=(num3);
					this.#=z6teJui46vpSY(num5, #=zQ5O21TQ=);
					num6 = #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=ziI2CPZrUbbyH[num5];
					if (num6 != 0)
					{
						num3 -= #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=z4vhELrw=[num5];
						this.#=zmpnZYBar22uK(num3, num6);
					}
				}
			}
			while (num < this.#=zQ5CGcJs$SF9h);
		}
		this.#=z6teJui46vpSY(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgl3Y5C_JJ1D8, #=zn7WZLHmxufVR);
		this.#=zsA8UeIo$tsLcz_j3iw== = (int)#=zn7WZLHmxufVR[#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgl3Y5C_JJ1D8 * 2 + 1];
	}

	// Token: 0x0600116D RID: 4461 RVA: 0x00086784 File Offset: 0x00084984
	internal void #=z5namUgB71ER2()
	{
		int i = 0;
		int num = 0;
		int num2 = 0;
		while (i < 7)
		{
			num2 += (int)this.#=zDsOPwvAFrw_PWDhdrw==[i * 2];
			i++;
		}
		while (i < 128)
		{
			num += (int)this.#=zDsOPwvAFrw_PWDhdrw==[i * 2];
			i++;
		}
		while (i < #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=z8or$P5xhr503XB4g1A==)
		{
			num2 += (int)this.#=zDsOPwvAFrw_PWDhdrw==[i * 2];
			i++;
		}
		this.#=ze7Q4V45fhnnc = (sbyte)((num2 > num >> 2) ? #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zgVK62mOivabR : #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zltmA0mqMkwQC);
	}

	// Token: 0x0600116E RID: 4462 RVA: 0x00086800 File Offset: 0x00084A00
	internal void #=zqkouHPl84sVX()
	{
		if (this.#=zcXxMrmM9nuW4 == 16)
		{
			byte[] array = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array[num] = (byte)this.#=zhBP95zayY8AN;
			byte[] array2 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array2[num] = (byte)(this.#=zhBP95zayY8AN >> 8);
			this.#=zhBP95zayY8AN = 0;
			this.#=zcXxMrmM9nuW4 = 0;
			return;
		}
		if (this.#=zcXxMrmM9nuW4 >= 8)
		{
			byte[] array3 = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array3[num] = (byte)this.#=zhBP95zayY8AN;
			this.#=zhBP95zayY8AN = (short)(this.#=zhBP95zayY8AN >> 8);
			this.#=zcXxMrmM9nuW4 -= 8;
		}
	}

	// Token: 0x0600116F RID: 4463 RVA: 0x000868AC File Offset: 0x00084AAC
	internal void #=z2w_B8S1y2De_g3SIXQ==()
	{
		if (this.#=zcXxMrmM9nuW4 > 8)
		{
			byte[] array = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array[num] = (byte)this.#=zhBP95zayY8AN;
			byte[] array2 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array2[num] = (byte)(this.#=zhBP95zayY8AN >> 8);
		}
		else if (this.#=zcXxMrmM9nuW4 > 0)
		{
			byte[] array3 = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array3[num] = (byte)this.#=zhBP95zayY8AN;
		}
		this.#=zhBP95zayY8AN = 0;
		this.#=zcXxMrmM9nuW4 = 0;
	}

	// Token: 0x06001170 RID: 4464 RVA: 0x0008693C File Offset: 0x00084B3C
	internal void #=zzv_fK787wma8(int #=zXvwCnz8=, int #=zZBlusgI=, bool #=zv8YDx2Q=)
	{
		this.#=z2w_B8S1y2De_g3SIXQ==();
		this.#=zsA8UeIo$tsLcz_j3iw== = 8;
		if (#=zv8YDx2Q=)
		{
			byte[] array = this.#=zgG3ckmc=;
			int num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array[num] = (byte)#=zZBlusgI=;
			byte[] array2 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array2[num] = (byte)(#=zZBlusgI= >> 8);
			byte[] array3 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array3[num] = (byte)(~(byte)#=zZBlusgI=);
			byte[] array4 = this.#=zgG3ckmc=;
			num = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num + 1;
			array4[num] = (byte)(~#=zZBlusgI= >> 8);
		}
		this.#=z1lTnzuk84TZ$(this.#=zgcFyF1E=, #=zXvwCnz8=, #=zZBlusgI=);
	}

	// Token: 0x06001171 RID: 4465 RVA: 0x000869D8 File Offset: 0x00084BD8
	internal void #=zHYBdwSZmb8BhrmUrPg==(bool #=zgtkTvBk=)
	{
		this.#=zfT573sna5HgywenSZA==((this.#=zlbu_H6vQDZui >= 0) ? this.#=zlbu_H6vQDZui : -1, this.#=zeA_K5S0njaXQlITcUw== - this.#=zlbu_H6vQDZui, #=zgtkTvBk=);
		this.#=zlbu_H6vQDZui = this.#=zeA_K5S0njaXQlITcUw==;
		this.#=zcXgLydccbe5C.#=zRTRWkVe6uyyf();
	}

	// Token: 0x06001172 RID: 4466 RVA: 0x00086A18 File Offset: 0x00084C18
	internal #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== #=zaQXRgSVlE7r1(FlushType #=zmhpr6mQ=)
	{
		int num = 65535;
		if (num > this.#=zgG3ckmc=.Length - 5)
		{
			num = this.#=zgG3ckmc=.Length - 5;
		}
		for (;;)
		{
			if (this.#=zvVLPn87OcsrNH_47wA== <= 1)
			{
				this.#=zLXO1WzsyKKNV();
				if (this.#=zvVLPn87OcsrNH_47wA== == 0 && #=zmhpr6mQ= == FlushType.None)
				{
					break;
				}
				if (this.#=zvVLPn87OcsrNH_47wA== == 0)
				{
					goto IL_DB;
				}
			}
			this.#=zeA_K5S0njaXQlITcUw== += this.#=zvVLPn87OcsrNH_47wA==;
			this.#=zvVLPn87OcsrNH_47wA== = 0;
			int num2 = this.#=zlbu_H6vQDZui + num;
			if (this.#=zeA_K5S0njaXQlITcUw== == 0 || this.#=zeA_K5S0njaXQlITcUw== >= num2)
			{
				this.#=zvVLPn87OcsrNH_47wA== = this.#=zeA_K5S0njaXQlITcUw== - num2;
				this.#=zeA_K5S0njaXQlITcUw== = num2;
				this.#=zHYBdwSZmb8BhrmUrPg==(false);
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
				}
			}
			if (this.#=zeA_K5S0njaXQlITcUw== - this.#=zlbu_H6vQDZui >= this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
			{
				this.#=zHYBdwSZmb8BhrmUrPg==(false);
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
				}
			}
		}
		return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
		IL_DB:
		this.#=zHYBdwSZmb8BhrmUrPg==(#=zmhpr6mQ= == FlushType.Finish);
		if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
		{
			if (#=zmhpr6mQ= != FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)2;
		}
		else
		{
			if (#=zmhpr6mQ= != FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)1;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)3;
		}
	}

	// Token: 0x06001173 RID: 4467 RVA: 0x00086B28 File Offset: 0x00084D28
	internal void #=zk7SnZVegZN9KUODWRA==(int #=zXvwCnz8=, int #=zEhm0VHHWSeuQ, bool #=zgtkTvBk=)
	{
		this.#=zmpnZYBar22uK((#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zbbpc0WiM_j3fA93$sw== << 1) + ((#=zgtkTvBk= > false) ? 1 : 0), 3);
		this.#=zzv_fK787wma8(#=zXvwCnz8=, #=zEhm0VHHWSeuQ, true);
	}

	// Token: 0x06001174 RID: 4468 RVA: 0x00086B48 File Offset: 0x00084D48
	internal void #=zfT573sna5HgywenSZA==(int #=zXvwCnz8=, int #=zEhm0VHHWSeuQ, bool #=zgtkTvBk=)
	{
		int num = 0;
		int num2;
		int num3;
		if (this.#=zltbHchNfArRn > CompressionLevel.None)
		{
			if ((int)this.#=ze7Q4V45fhnnc == #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zuoOqadetLYUR)
			{
				this.#=z5namUgB71ER2();
			}
			this.#=zuDE8VGQ9_O5V.#=zS0Twt13P67pD(this);
			this.#=zR0loHvxEjwywO1Iidg==.#=zS0Twt13P67pD(this);
			num = this.#=zLLq2eFVt3JVtEZfYDQ==();
			num2 = this.#=z3nPze4xN8xfT + 3 + 7 >> 3;
			num3 = this.#=zQzrhsNbgIMpy + 3 + 7 >> 3;
			if (num3 <= num2)
			{
				num2 = num3;
			}
		}
		else
		{
			num3 = (num2 = #=zEhm0VHHWSeuQ + 5);
		}
		if (#=zEhm0VHHWSeuQ + 4 <= num2 && #=zXvwCnz8= != -1)
		{
			this.#=zk7SnZVegZN9KUODWRA==(#=zXvwCnz8=, #=zEhm0VHHWSeuQ, #=zgtkTvBk=);
		}
		else if (num3 == num2)
		{
			this.#=zmpnZYBar22uK((#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmg5v$PzOFuq8biuDeQ== << 1) + ((#=zgtkTvBk= > false) ? 1 : 0), 3);
			this.#=zXpTvU2Gdrwiexf3PZA==(#=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=zBDb5Ka_po3rvrTsOUg==, #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w==.#=z1CXrEY32ZjvaprRggQ==);
		}
		else
		{
			this.#=zmpnZYBar22uK((#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zrKC4fGS5hKItCCy89g== << 1) + ((#=zgtkTvBk= > false) ? 1 : 0), 3);
			this.#=znZHmfpnOrW3imJvNeg==(this.#=zuDE8VGQ9_O5V.#=zDjtKVgb3mIkZ + 1, this.#=zR0loHvxEjwywO1Iidg==.#=zDjtKVgb3mIkZ + 1, num + 1);
			this.#=zXpTvU2Gdrwiexf3PZA==(this.#=zDsOPwvAFrw_PWDhdrw==, this.#=zrcMr8pqkhRLQ);
		}
		this.#=zAzSUkRVFuKPU();
		if (#=zgtkTvBk=)
		{
			this.#=z2w_B8S1y2De_g3SIXQ==();
		}
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x00086C50 File Offset: 0x00084E50
	private void #=zLXO1WzsyKKNV()
	{
		for (;;)
		{
			int num = this.#=z_k2pBquMtfoC - this.#=zvVLPn87OcsrNH_47wA== - this.#=zeA_K5S0njaXQlITcUw==;
			int num2;
			if (num == 0 && this.#=zeA_K5S0njaXQlITcUw== == 0 && this.#=zvVLPn87OcsrNH_47wA== == 0)
			{
				num = this.#=zzb8ZcArEaC3W;
			}
			else if (num == -1)
			{
				num--;
			}
			else if (this.#=zeA_K5S0njaXQlITcUw== >= this.#=zzb8ZcArEaC3W + this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
			{
				Array.Copy(this.#=zgcFyF1E=, this.#=zzb8ZcArEaC3W, this.#=zgcFyF1E=, 0, this.#=zzb8ZcArEaC3W);
				this.#=zDm2cVP3OyApB -= this.#=zzb8ZcArEaC3W;
				this.#=zeA_K5S0njaXQlITcUw== -= this.#=zzb8ZcArEaC3W;
				this.#=zlbu_H6vQDZui -= this.#=zzb8ZcArEaC3W;
				num2 = this.#=z6COySntztyaf;
				int num3 = num2;
				do
				{
					int num4 = (int)this.#=z6_6XQKs=[--num3] & 65535;
					this.#=z6_6XQKs=[num3] = (short)((num4 >= this.#=zzb8ZcArEaC3W) ? (num4 - this.#=zzb8ZcArEaC3W) : 0);
				}
				while (--num2 != 0);
				num2 = this.#=zzb8ZcArEaC3W;
				num3 = num2;
				do
				{
					int num4 = (int)this.#=zXKdfibw=[--num3] & 65535;
					this.#=zXKdfibw=[num3] = (short)((num4 >= this.#=zzb8ZcArEaC3W) ? (num4 - this.#=zzb8ZcArEaC3W) : 0);
				}
				while (--num2 != 0);
				num += this.#=zzb8ZcArEaC3W;
			}
			if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
			{
				break;
			}
			num2 = this.#=zcXgLydccbe5C.#=zaMVRYPCY4H95(this.#=zgcFyF1E=, this.#=zeA_K5S0njaXQlITcUw== + this.#=zvVLPn87OcsrNH_47wA==, num);
			this.#=zvVLPn87OcsrNH_47wA== += num2;
			if (this.#=zvVLPn87OcsrNH_47wA== >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
			{
				this.#=zJpjhfe4b$c0e = (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw==] & byte.MaxValue);
				this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + 1] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
			}
			if (this.#=zvVLPn87OcsrNH_47wA== >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE= || this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
			{
				return;
			}
		}
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x00086E50 File Offset: 0x00085050
	internal #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== #=zD9bkFa$SgMcV(FlushType #=zmhpr6mQ=)
	{
		int num = 0;
		for (;;)
		{
			if (this.#=zvVLPn87OcsrNH_47wA== < #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
			{
				this.#=zLXO1WzsyKKNV();
				if (this.#=zvVLPn87OcsrNH_47wA== < #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE= && #=zmhpr6mQ= == FlushType.None)
				{
					break;
				}
				if (this.#=zvVLPn87OcsrNH_47wA== == 0)
				{
					goto IL_2E8;
				}
			}
			if (this.#=zvVLPn87OcsrNH_47wA== >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
			{
				this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1)] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
				num = ((int)this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] & 65535);
				this.#=zXKdfibw=[this.#=zeA_K5S0njaXQlITcUw== & this.#=zpIZW$KqITEox] = this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e];
				this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] = (short)this.#=zeA_K5S0njaXQlITcUw==;
			}
			if ((long)num != 0L && (this.#=zeA_K5S0njaXQlITcUw== - num & 65535) <= this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE= && this.#=z_T7b_6JP9bsg != CompressionStrategy.HuffmanOnly)
			{
				this.#=zZMe5LEQ2DIie = this.#=zYr3kAAmrW2HKqvdumQ==(num);
			}
			bool flag;
			if (this.#=zZMe5LEQ2DIie >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
			{
				flag = this.#=zl5dNX0JPbwpWIgk5ag==(this.#=zeA_K5S0njaXQlITcUw== - this.#=zDm2cVP3OyApB, this.#=zZMe5LEQ2DIie - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk);
				this.#=zvVLPn87OcsrNH_47wA== -= this.#=zZMe5LEQ2DIie;
				if (this.#=zZMe5LEQ2DIie <= this.#=zVsqOgh8=.#=z63G$lffKfQX$ && this.#=zvVLPn87OcsrNH_47wA== >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
				{
					this.#=zZMe5LEQ2DIie--;
					int num2;
					do
					{
						this.#=zeA_K5S0njaXQlITcUw==++;
						this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1)] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
						num = ((int)this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] & 65535);
						this.#=zXKdfibw=[this.#=zeA_K5S0njaXQlITcUw== & this.#=zpIZW$KqITEox] = this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e];
						this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] = (short)this.#=zeA_K5S0njaXQlITcUw==;
						num2 = this.#=zZMe5LEQ2DIie - 1;
						this.#=zZMe5LEQ2DIie = num2;
					}
					while (num2 != 0);
					this.#=zeA_K5S0njaXQlITcUw==++;
				}
				else
				{
					this.#=zeA_K5S0njaXQlITcUw== += this.#=zZMe5LEQ2DIie;
					this.#=zZMe5LEQ2DIie = 0;
					this.#=zJpjhfe4b$c0e = (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw==] & byte.MaxValue);
					this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + 1] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
				}
			}
			else
			{
				flag = this.#=zl5dNX0JPbwpWIgk5ag==(0, (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw==] & byte.MaxValue));
				this.#=zvVLPn87OcsrNH_47wA==--;
				this.#=zeA_K5S0njaXQlITcUw==++;
			}
			if (flag)
			{
				this.#=zHYBdwSZmb8BhrmUrPg==(false);
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
				}
			}
		}
		return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
		IL_2E8:
		this.#=zHYBdwSZmb8BhrmUrPg==(#=zmhpr6mQ= == FlushType.Finish);
		if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
		{
			if (#=zmhpr6mQ= == FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)2;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
		}
		else
		{
			if (#=zmhpr6mQ= != FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)1;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)3;
		}
	}

	// Token: 0x06001177 RID: 4471 RVA: 0x0008716C File Offset: 0x0008536C
	internal #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== #=z_yffvhQoNGyh(FlushType #=zmhpr6mQ=)
	{
		int num = 0;
		for (;;)
		{
			if (this.#=zvVLPn87OcsrNH_47wA== < #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
			{
				this.#=zLXO1WzsyKKNV();
				if (this.#=zvVLPn87OcsrNH_47wA== < #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE= && #=zmhpr6mQ= == FlushType.None)
				{
					break;
				}
				if (this.#=zvVLPn87OcsrNH_47wA== == 0)
				{
					goto IL_363;
				}
			}
			if (this.#=zvVLPn87OcsrNH_47wA== >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
			{
				this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1)] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
				num = ((int)this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] & 65535);
				this.#=zXKdfibw=[this.#=zeA_K5S0njaXQlITcUw== & this.#=zpIZW$KqITEox] = this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e];
				this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] = (short)this.#=zeA_K5S0njaXQlITcUw==;
			}
			this.#=zzWrVcDTzyiEX = this.#=zZMe5LEQ2DIie;
			this.#=zrgxZNlSufyOf = this.#=zDm2cVP3OyApB;
			this.#=zZMe5LEQ2DIie = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1;
			if (num != 0 && this.#=zzWrVcDTzyiEX < this.#=zVsqOgh8=.#=z63G$lffKfQX$ && (this.#=zeA_K5S0njaXQlITcUw== - num & 65535) <= this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
			{
				if (this.#=z_T7b_6JP9bsg != CompressionStrategy.HuffmanOnly)
				{
					this.#=zZMe5LEQ2DIie = this.#=zYr3kAAmrW2HKqvdumQ==(num);
				}
				if (this.#=zZMe5LEQ2DIie <= 5 && (this.#=z_T7b_6JP9bsg == CompressionStrategy.Filtered || (this.#=zZMe5LEQ2DIie == #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk && this.#=zeA_K5S0njaXQlITcUw== - this.#=zDm2cVP3OyApB > 4096)))
				{
					this.#=zZMe5LEQ2DIie = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1;
				}
			}
			if (this.#=zzWrVcDTzyiEX >= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk && this.#=zZMe5LEQ2DIie <= this.#=zzWrVcDTzyiEX)
			{
				int num2 = this.#=zeA_K5S0njaXQlITcUw== + this.#=zvVLPn87OcsrNH_47wA== - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk;
				bool flag = this.#=zl5dNX0JPbwpWIgk5ag==(this.#=zeA_K5S0njaXQlITcUw== - 1 - this.#=zrgxZNlSufyOf, this.#=zzWrVcDTzyiEX - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk);
				this.#=zvVLPn87OcsrNH_47wA== -= this.#=zzWrVcDTzyiEX - 1;
				this.#=zzWrVcDTzyiEX -= 2;
				int num3;
				do
				{
					num3 = this.#=zeA_K5S0njaXQlITcUw== + 1;
					this.#=zeA_K5S0njaXQlITcUw== = num3;
					if (num3 <= num2)
					{
						this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== + (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1)] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
						num = ((int)this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] & 65535);
						this.#=zXKdfibw=[this.#=zeA_K5S0njaXQlITcUw== & this.#=zpIZW$KqITEox] = this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e];
						this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] = (short)this.#=zeA_K5S0njaXQlITcUw==;
					}
					num3 = this.#=zzWrVcDTzyiEX - 1;
					this.#=zzWrVcDTzyiEX = num3;
				}
				while (num3 != 0);
				this.#=z2ke40tS7SV6r = 0;
				this.#=zZMe5LEQ2DIie = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1;
				this.#=zeA_K5S0njaXQlITcUw==++;
				if (flag)
				{
					this.#=zHYBdwSZmb8BhrmUrPg==(false);
					if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
					{
						return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
					}
				}
			}
			else if (this.#=z2ke40tS7SV6r != 0)
			{
				bool flag = this.#=zl5dNX0JPbwpWIgk5ag==(0, (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== - 1] & byte.MaxValue));
				if (flag)
				{
					this.#=zHYBdwSZmb8BhrmUrPg==(false);
				}
				this.#=zeA_K5S0njaXQlITcUw==++;
				this.#=zvVLPn87OcsrNH_47wA==--;
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
				}
			}
			else
			{
				this.#=z2ke40tS7SV6r = 1;
				this.#=zeA_K5S0njaXQlITcUw==++;
				this.#=zvVLPn87OcsrNH_47wA==--;
			}
		}
		return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
		IL_363:
		if (this.#=z2ke40tS7SV6r != 0)
		{
			bool flag = this.#=zl5dNX0JPbwpWIgk5ag==(0, (int)(this.#=zgcFyF1E=[this.#=zeA_K5S0njaXQlITcUw== - 1] & byte.MaxValue));
			this.#=z2ke40tS7SV6r = 0;
		}
		this.#=zHYBdwSZmb8BhrmUrPg==(#=zmhpr6mQ= == FlushType.Finish);
		if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
		{
			if (#=zmhpr6mQ= == FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)2;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0;
		}
		else
		{
			if (#=zmhpr6mQ= != FlushType.Finish)
			{
				return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)1;
			}
			return (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)3;
		}
	}

	// Token: 0x06001178 RID: 4472 RVA: 0x00087530 File Offset: 0x00085730
	internal int #=zYr3kAAmrW2HKqvdumQ==(int #=zGA2bPk5MYPxJ)
	{
		int num = this.#=zVsqOgh8=.#=z0Ypz9SujqFpW;
		int num2 = this.#=zeA_K5S0njaXQlITcUw==;
		int num3 = this.#=zzWrVcDTzyiEX;
		int num4 = (this.#=zeA_K5S0njaXQlITcUw== > this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=) ? (this.#=zeA_K5S0njaXQlITcUw== - (this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)) : 0;
		int #=z_LainSUwbilC = this.#=zVsqOgh8=.#=z_LainSUwbilC;
		int num5 = this.#=zpIZW$KqITEox;
		int num6 = this.#=zeA_K5S0njaXQlITcUw== + #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zxlqWnQx1wBEj;
		byte b = this.#=zgcFyF1E=[num2 + num3 - 1];
		byte b2 = this.#=zgcFyF1E=[num2 + num3];
		if (this.#=zzWrVcDTzyiEX >= this.#=zVsqOgh8=.#=z1dkBew7DHH3k)
		{
			num >>= 2;
		}
		if (#=z_LainSUwbilC > this.#=zvVLPn87OcsrNH_47wA==)
		{
			#=z_LainSUwbilC = this.#=zvVLPn87OcsrNH_47wA==;
		}
		do
		{
			int num7 = #=zGA2bPk5MYPxJ;
			if (this.#=zgcFyF1E=[num7 + num3] == b2 && this.#=zgcFyF1E=[num7 + num3 - 1] == b && this.#=zgcFyF1E=[num7] == this.#=zgcFyF1E=[num2] && this.#=zgcFyF1E=[++num7] == this.#=zgcFyF1E=[num2 + 1])
			{
				num2 += 2;
				num7++;
				while (this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && this.#=zgcFyF1E=[++num2] == this.#=zgcFyF1E=[++num7] && num2 < num6)
				{
				}
				int num8 = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zxlqWnQx1wBEj - (num6 - num2);
				num2 = num6 - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zxlqWnQx1wBEj;
				if (num8 > num3)
				{
					this.#=zDm2cVP3OyApB = #=zGA2bPk5MYPxJ;
					num3 = num8;
					if (num8 >= #=z_LainSUwbilC)
					{
						break;
					}
					b = this.#=zgcFyF1E=[num2 + num3 - 1];
					b2 = this.#=zgcFyF1E=[num2 + num3];
				}
			}
		}
		while ((#=zGA2bPk5MYPxJ = ((int)this.#=zXKdfibw=[#=zGA2bPk5MYPxJ & num5] & 65535)) > num4 && --num != 0);
		if (num3 <= this.#=zvVLPn87OcsrNH_47wA==)
		{
			return num3;
		}
		return this.#=zvVLPn87OcsrNH_47wA==;
	}

	// Token: 0x06001179 RID: 4473 RVA: 0x000877A0 File Offset: 0x000859A0
	internal bool #=zt6$Qbs5KfMCNZF2kvCnMhQs=()
	{
		return this.#=zKKCikhgYnBiczmmcfq4938g=;
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x000877A8 File Offset: 0x000859A8
	internal void #=zCNkYni0Ubaaxpcnd2wEb0eQ=(bool #=z$Ib9gYQ=)
	{
		this.#=zKKCikhgYnBiczmmcfq4938g= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x000877B4 File Offset: 0x000859B4
	internal int #=z1jlGMrg=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, CompressionLevel #=z5w6HcG4=)
	{
		return this.#=z1jlGMrg=(#=zuuFHPjILnjRT, #=z5w6HcG4=, 15);
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x000877C0 File Offset: 0x000859C0
	internal int #=z1jlGMrg=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, CompressionLevel #=z5w6HcG4=, int #=zGyL$Taw=)
	{
		return this.#=z1jlGMrg=(#=zuuFHPjILnjRT, #=z5w6HcG4=, #=zGyL$Taw=, #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zdBiu7i9pgGBq6p9Fww==, CompressionStrategy.Default);
	}

	// Token: 0x0600117D RID: 4477 RVA: 0x000877D4 File Offset: 0x000859D4
	internal int #=z1jlGMrg=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, CompressionLevel #=z5w6HcG4=, int #=zGyL$Taw=, CompressionStrategy #=z_T7b_6JP9bsg)
	{
		return this.#=z1jlGMrg=(#=zuuFHPjILnjRT, #=z5w6HcG4=, #=zGyL$Taw=, #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zdBiu7i9pgGBq6p9Fww==, #=z_T7b_6JP9bsg);
	}

	// Token: 0x0600117E RID: 4478 RVA: 0x000877E8 File Offset: 0x000859E8
	internal int #=z1jlGMrg=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, CompressionLevel #=z5w6HcG4=, int #=zGRpGdBZE2aZz, int #=zMy4gY$0If2IN, CompressionStrategy #=zDz_4k2s=)
	{
		this.#=zcXgLydccbe5C = #=zuuFHPjILnjRT;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = null;
		if (#=zGRpGdBZE2aZz < 9 || #=zGRpGdBZE2aZz > 15)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062853));
		}
		if (#=zMy4gY$0If2IN < 1 || #=zMy4gY$0If2IN > #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zg5EGz162bXd6rZqI4A==)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062806), #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zg5EGz162bXd6rZqI4A==));
		}
		this.#=zcXgLydccbe5C.#=zlUgwGfK7z66f = this;
		this.#=zXbmKbRCl9WAf = #=zGRpGdBZE2aZz;
		this.#=zzb8ZcArEaC3W = 1 << this.#=zXbmKbRCl9WAf;
		this.#=zpIZW$KqITEox = this.#=zzb8ZcArEaC3W - 1;
		this.#=zrz4se8dbimFz = #=zMy4gY$0If2IN + 7;
		this.#=z6COySntztyaf = 1 << this.#=zrz4se8dbimFz;
		this.#=zZE0tTY7UGhtE = this.#=z6COySntztyaf - 1;
		this.#=zHFMIIAOhUjc7 = (this.#=zrz4se8dbimFz + #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1) / #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk;
		this.#=zgcFyF1E= = new byte[this.#=zzb8ZcArEaC3W * 2];
		this.#=zXKdfibw= = new short[this.#=zzb8ZcArEaC3W];
		this.#=z6_6XQKs= = new short[this.#=z6COySntztyaf];
		this.#=zHSo1xM06V91z7wLekA== = 1 << #=zMy4gY$0If2IN + 6;
		this.#=zgG3ckmc= = new byte[this.#=zHSo1xM06V91z7wLekA== * 4];
		this.#=zhhX$L2GhNIGR = this.#=zHSo1xM06V91z7wLekA==;
		this.#=zjIfLx08Qsx1R = 3 * this.#=zHSo1xM06V91z7wLekA==;
		this.#=zltbHchNfArRn = #=z5w6HcG4=;
		this.#=z_T7b_6JP9bsg = #=zDz_4k2s=;
		this.#=zW3vXs9Q=();
		return 0;
	}

	// Token: 0x0600117F RID: 4479 RVA: 0x0008794C File Offset: 0x00085B4C
	internal void #=zW3vXs9Q=()
	{
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 = (this.#=zcXgLydccbe5C.#=z0KaacqESNJ$P = 0L);
		this.#=zcXgLydccbe5C.#=znwxGN8g= = null;
		this.#=zr2hx6oQ= = 0;
		this.#=zElex9Ew9marJ = 0;
		this.#=z9tIIjMNb7mNc3khxHw== = false;
		this.#=zViv_PBQ= = (this.#=zt6$Qbs5KfMCNZF2kvCnMhQs=() ? #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zi5z9V8Se6I8d : #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zu1_9IJdwBjBT);
		this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = Adler.Adler32(0U, null, 0, 0);
		this.#=zPIU36Rl0lIg3 = 0;
		this.#=z2gezqg2v5NsB();
		this.#=zPJWoWjb64o8z();
	}

	// Token: 0x06001180 RID: 4480 RVA: 0x000879D8 File Offset: 0x00085BD8
	internal int #=zhjKhhfc=()
	{
		if (this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zi5z9V8Se6I8d && this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zu1_9IJdwBjBT && this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zXN7sCqSKFpfg)
		{
			return -2;
		}
		this.#=zgG3ckmc= = null;
		this.#=z6_6XQKs= = null;
		this.#=zXKdfibw= = null;
		this.#=zgcFyF1E= = null;
		if (this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zu1_9IJdwBjBT)
		{
			return 0;
		}
		return -3;
	}

	// Token: 0x06001181 RID: 4481 RVA: 0x00087A3C File Offset: 0x00085C3C
	private void #=zWJQOm6YsQXyUh9uYJw==()
	{
		switch (this.#=zVsqOgh8=.#=zMkZUgxo=)
		{
		case (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)0:
			this.#=z6aCgJy8o2mpO = new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zsbGAnE2GbPlT(this.#=zaQXRgSVlE7r1);
			return;
		case (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)1:
			this.#=z6aCgJy8o2mpO = new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zsbGAnE2GbPlT(this.#=zD9bkFa$SgMcV);
			return;
		case (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2:
			this.#=z6aCgJy8o2mpO = new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zsbGAnE2GbPlT(this.#=z_yffvhQoNGyh);
			return;
		default:
			return;
		}
	}

	// Token: 0x06001182 RID: 4482 RVA: 0x00087AA0 File Offset: 0x00085CA0
	internal int #=zg$5DrSs=(CompressionLevel #=z5w6HcG4=, CompressionStrategy #=zDz_4k2s=)
	{
		int result = 0;
		if (this.#=zltbHchNfArRn != #=z5w6HcG4=)
		{
			#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as= #=zSTdA3as= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=.#=z55MbmG4=(#=z5w6HcG4=);
			if (#=zSTdA3as=.#=zMkZUgxo= != this.#=zVsqOgh8=.#=zMkZUgxo= && this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 != 0L)
			{
				result = this.#=zcXgLydccbe5C.#=zYdo2_SU=(FlushType.Partial);
			}
			this.#=zltbHchNfArRn = #=z5w6HcG4=;
			this.#=zVsqOgh8= = #=zSTdA3as=;
			this.#=zWJQOm6YsQXyUh9uYJw==();
		}
		this.#=z_T7b_6JP9bsg = #=zDz_4k2s=;
		return result;
	}

	// Token: 0x06001183 RID: 4483 RVA: 0x00087B08 File Offset: 0x00085D08
	internal int #=zv4DxgDs=(byte[] #=zrnw7iZQ=)
	{
		int num = #=zrnw7iZQ=.Length;
		int sourceIndex = 0;
		if (#=zrnw7iZQ= == null || this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zi5z9V8Se6I8d)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062498));
		}
		this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = Adler.Adler32(this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA==, #=zrnw7iZQ=, 0, #=zrnw7iZQ=.Length);
		if (num < #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk)
		{
			return 0;
		}
		if (num > this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=)
		{
			num = this.#=zzb8ZcArEaC3W - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=znYmYBHQJeqQsMKMyAIEHowE=;
			sourceIndex = #=zrnw7iZQ=.Length - num;
		}
		Array.Copy(#=zrnw7iZQ=, sourceIndex, this.#=zgcFyF1E=, 0, num);
		this.#=zeA_K5S0njaXQlITcUw== = num;
		this.#=zlbu_H6vQDZui = num;
		this.#=zJpjhfe4b$c0e = (int)(this.#=zgcFyF1E=[0] & byte.MaxValue);
		this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[1] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
		for (int i = 0; i <= num - #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk; i++)
		{
			this.#=zJpjhfe4b$c0e = ((this.#=zJpjhfe4b$c0e << this.#=zHFMIIAOhUjc7 ^ (int)(this.#=zgcFyF1E=[i + (#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk - 1)] & byte.MaxValue)) & this.#=zZE0tTY7UGhtE);
			this.#=zXKdfibw=[i & this.#=zpIZW$KqITEox] = this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e];
			this.#=z6_6XQKs=[this.#=zJpjhfe4b$c0e] = (short)i;
		}
		return 0;
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x00087C58 File Offset: 0x00085E58
	internal int #=zYdo2_SU=(FlushType #=zmhpr6mQ=)
	{
		if (this.#=zcXgLydccbe5C.#=zTkQEpCPgqFwZ == null || (this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0 == null && this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 != 0) || (this.#=zViv_PBQ= == #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zXN7sCqSKFpfg && #=zmhpr6mQ= != FlushType.Finish))
		{
			this.#=zcXgLydccbe5C.#=znwxGN8g= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSNpGdQ0=[4];
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062486), this.#=zcXgLydccbe5C.#=znwxGN8g=));
		}
		if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
		{
			this.#=zcXgLydccbe5C.#=znwxGN8g= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSNpGdQ0=[7];
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062454));
		}
		int num = this.#=zPIU36Rl0lIg3;
		this.#=zPIU36Rl0lIg3 = (int)#=zmhpr6mQ=;
		int num4;
		if (this.#=zViv_PBQ= == #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zi5z9V8Se6I8d)
		{
			int num2 = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zxpdM9gMCtQidpYR6eA== + (this.#=zXbmKbRCl9WAf - 8 << 4) << 8;
			int num3 = (this.#=zltbHchNfArRn - CompressionLevel.BestSpeed & 255) >> 1;
			if (num3 > 3)
			{
				num3 = 3;
			}
			num2 |= num3 << 6;
			if (this.#=zeA_K5S0njaXQlITcUw== != 0)
			{
				num2 |= #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zvIu1h5lQVYb7KS2NKw==;
			}
			num2 += 31 - num2 % 31;
			this.#=zViv_PBQ= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zu1_9IJdwBjBT;
			byte[] array = this.#=zgG3ckmc=;
			num4 = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num4 + 1;
			array[num4] = (byte)(num2 >> 8);
			byte[] array2 = this.#=zgG3ckmc=;
			num4 = this.#=zr2hx6oQ=;
			this.#=zr2hx6oQ= = num4 + 1;
			array2[num4] = (byte)num2;
			if (this.#=zeA_K5S0njaXQlITcUw== != 0)
			{
				byte[] array3 = this.#=zgG3ckmc=;
				num4 = this.#=zr2hx6oQ=;
				this.#=zr2hx6oQ= = num4 + 1;
				array3[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 4278190080U) >> 24);
				byte[] array4 = this.#=zgG3ckmc=;
				num4 = this.#=zr2hx6oQ=;
				this.#=zr2hx6oQ= = num4 + 1;
				array4[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 16711680U) >> 16);
				byte[] array5 = this.#=zgG3ckmc=;
				num4 = this.#=zr2hx6oQ=;
				this.#=zr2hx6oQ= = num4 + 1;
				array5[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 65280U) >> 8);
				byte[] array6 = this.#=zgG3ckmc=;
				num4 = this.#=zr2hx6oQ=;
				this.#=zr2hx6oQ= = num4 + 1;
				array6[num4] = (byte)this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA==;
			}
			this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = Adler.Adler32(0U, null, 0, 0);
		}
		if (this.#=zr2hx6oQ= != 0)
		{
			this.#=zcXgLydccbe5C.#=zRTRWkVe6uyyf();
			if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
			{
				this.#=zPIU36Rl0lIg3 = -1;
				return 0;
			}
		}
		else if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0 && #=zmhpr6mQ= <= (FlushType)num && #=zmhpr6mQ= != FlushType.Finish)
		{
			return 0;
		}
		if (this.#=zViv_PBQ= == #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zXN7sCqSKFpfg && this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 != 0)
		{
			this.#=zcXgLydccbe5C.#=znwxGN8g= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSNpGdQ0=[7];
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062650));
		}
		if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 != 0 || this.#=zvVLPn87OcsrNH_47wA== != 0 || (#=zmhpr6mQ= != FlushType.None && this.#=zViv_PBQ= != #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zXN7sCqSKFpfg))
		{
			#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== = this.#=z6aCgJy8o2mpO(#=zmhpr6mQ=);
			if (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== == (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)2 || #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== == (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)3)
			{
				this.#=zViv_PBQ= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zXN7sCqSKFpfg;
			}
			if (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== == (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)0 || #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== == (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)2)
			{
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					this.#=zPIU36Rl0lIg3 = -1;
				}
				return 0;
			}
			if (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== == (#=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ==)1)
			{
				if (#=zmhpr6mQ= == FlushType.Partial)
				{
					this.#=zxrZLfT1Nw9Qf();
				}
				else
				{
					this.#=zk7SnZVegZN9KUODWRA==(0, 0, false);
					if (#=zmhpr6mQ= == FlushType.Full)
					{
						for (int i = 0; i < this.#=z6COySntztyaf; i++)
						{
							this.#=z6_6XQKs=[i] = 0;
						}
					}
				}
				this.#=zcXgLydccbe5C.#=zRTRWkVe6uyyf();
				if (this.#=zcXgLydccbe5C.#=zRQNIMvX_JmPR == 0)
				{
					this.#=zPIU36Rl0lIg3 = -1;
					return 0;
				}
			}
		}
		if (#=zmhpr6mQ= != FlushType.Finish)
		{
			return 0;
		}
		if (!this.#=zt6$Qbs5KfMCNZF2kvCnMhQs=() || this.#=z9tIIjMNb7mNc3khxHw==)
		{
			return 1;
		}
		byte[] array7 = this.#=zgG3ckmc=;
		num4 = this.#=zr2hx6oQ=;
		this.#=zr2hx6oQ= = num4 + 1;
		array7[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 4278190080U) >> 24);
		byte[] array8 = this.#=zgG3ckmc=;
		num4 = this.#=zr2hx6oQ=;
		this.#=zr2hx6oQ= = num4 + 1;
		array8[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 16711680U) >> 16);
		byte[] array9 = this.#=zgG3ckmc=;
		num4 = this.#=zr2hx6oQ=;
		this.#=zr2hx6oQ= = num4 + 1;
		array9[num4] = (byte)((this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== & 65280U) >> 8);
		byte[] array10 = this.#=zgG3ckmc=;
		num4 = this.#=zr2hx6oQ=;
		this.#=zr2hx6oQ= = num4 + 1;
		array10[num4] = (byte)this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA==;
		this.#=zcXgLydccbe5C.#=zRTRWkVe6uyyf();
		this.#=z9tIIjMNb7mNc3khxHw== = true;
		return (this.#=zr2hx6oQ= == 0) ? 1 : 0;
	}

	// Token: 0x0400097E RID: 2430
	private static readonly int #=zg5EGz162bXd6rZqI4A== = 9;

	// Token: 0x0400097F RID: 2431
	private static readonly int #=zdBiu7i9pgGBq6p9Fww== = 8;

	// Token: 0x04000980 RID: 2432
	private #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zsbGAnE2GbPlT #=z6aCgJy8o2mpO;

	// Token: 0x04000981 RID: 2433
	private static readonly string[] #=zSNpGdQ0= = new string[]
	{
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062753),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062731),
		string.Empty,
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062712),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062697),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062684),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062669),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062891),
		#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062878),
		string.Empty
	};

	// Token: 0x04000982 RID: 2434
	private static readonly int #=zvIu1h5lQVYb7KS2NKw== = 32;

	// Token: 0x04000983 RID: 2435
	private static readonly int #=zi5z9V8Se6I8d = 42;

	// Token: 0x04000984 RID: 2436
	private static readonly int #=zu1_9IJdwBjBT = 113;

	// Token: 0x04000985 RID: 2437
	private static readonly int #=zXN7sCqSKFpfg = 666;

	// Token: 0x04000986 RID: 2438
	private static readonly int #=zxpdM9gMCtQidpYR6eA== = 8;

	// Token: 0x04000987 RID: 2439
	private static readonly int #=zbbpc0WiM_j3fA93$sw== = 0;

	// Token: 0x04000988 RID: 2440
	private static readonly int #=zmg5v$PzOFuq8biuDeQ== = 1;

	// Token: 0x04000989 RID: 2441
	private static readonly int #=zrKC4fGS5hKItCCy89g== = 2;

	// Token: 0x0400098A RID: 2442
	private static readonly int #=zgVK62mOivabR = 0;

	// Token: 0x0400098B RID: 2443
	private static readonly int #=zltmA0mqMkwQC = 1;

	// Token: 0x0400098C RID: 2444
	private static readonly int #=zuoOqadetLYUR = 2;

	// Token: 0x0400098D RID: 2445
	private static readonly int #=z2iv4I6teQPhz = 16;

	// Token: 0x0400098E RID: 2446
	private static readonly int #=zmG5UHwrUVYhk = 3;

	// Token: 0x0400098F RID: 2447
	private static readonly int #=zxlqWnQx1wBEj = 258;

	// Token: 0x04000990 RID: 2448
	private static readonly int #=znYmYBHQJeqQsMKMyAIEHowE= = #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zxlqWnQx1wBEj + #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zmG5UHwrUVYhk + 1;

	// Token: 0x04000991 RID: 2449
	private static readonly int #=zCO1be_pw_8RU = 2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zexLItYjL27h5 + 1;

	// Token: 0x04000992 RID: 2450
	private static readonly int #=zgl3Y5C_JJ1D8 = 256;

	// Token: 0x04000993 RID: 2451
	internal #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zcXgLydccbe5C;

	// Token: 0x04000994 RID: 2452
	internal int #=zViv_PBQ=;

	// Token: 0x04000995 RID: 2453
	internal byte[] #=zgG3ckmc=;

	// Token: 0x04000996 RID: 2454
	internal int #=zElex9Ew9marJ;

	// Token: 0x04000997 RID: 2455
	internal int #=zr2hx6oQ=;

	// Token: 0x04000998 RID: 2456
	internal sbyte #=ze7Q4V45fhnnc;

	// Token: 0x04000999 RID: 2457
	internal int #=zPIU36Rl0lIg3;

	// Token: 0x0400099A RID: 2458
	internal int #=zzb8ZcArEaC3W;

	// Token: 0x0400099B RID: 2459
	internal int #=zXbmKbRCl9WAf;

	// Token: 0x0400099C RID: 2460
	internal int #=zpIZW$KqITEox;

	// Token: 0x0400099D RID: 2461
	internal byte[] #=zgcFyF1E=;

	// Token: 0x0400099E RID: 2462
	internal int #=z_k2pBquMtfoC;

	// Token: 0x0400099F RID: 2463
	internal short[] #=zXKdfibw=;

	// Token: 0x040009A0 RID: 2464
	internal short[] #=z6_6XQKs=;

	// Token: 0x040009A1 RID: 2465
	internal int #=zJpjhfe4b$c0e;

	// Token: 0x040009A2 RID: 2466
	internal int #=z6COySntztyaf;

	// Token: 0x040009A3 RID: 2467
	internal int #=zrz4se8dbimFz;

	// Token: 0x040009A4 RID: 2468
	internal int #=zZE0tTY7UGhtE;

	// Token: 0x040009A5 RID: 2469
	internal int #=zHFMIIAOhUjc7;

	// Token: 0x040009A6 RID: 2470
	internal int #=zlbu_H6vQDZui;

	// Token: 0x040009A7 RID: 2471
	private #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as= #=zVsqOgh8=;

	// Token: 0x040009A8 RID: 2472
	internal int #=zZMe5LEQ2DIie;

	// Token: 0x040009A9 RID: 2473
	internal int #=zrgxZNlSufyOf;

	// Token: 0x040009AA RID: 2474
	internal int #=z2ke40tS7SV6r;

	// Token: 0x040009AB RID: 2475
	internal int #=zeA_K5S0njaXQlITcUw==;

	// Token: 0x040009AC RID: 2476
	internal int #=zDm2cVP3OyApB;

	// Token: 0x040009AD RID: 2477
	internal int #=zvVLPn87OcsrNH_47wA==;

	// Token: 0x040009AE RID: 2478
	internal int #=zzWrVcDTzyiEX;

	// Token: 0x040009AF RID: 2479
	internal CompressionLevel #=zltbHchNfArRn;

	// Token: 0x040009B0 RID: 2480
	internal CompressionStrategy #=z_T7b_6JP9bsg;

	// Token: 0x040009B1 RID: 2481
	internal short[] #=zDsOPwvAFrw_PWDhdrw==;

	// Token: 0x040009B2 RID: 2482
	internal short[] #=zrcMr8pqkhRLQ;

	// Token: 0x040009B3 RID: 2483
	internal short[] #=zuqfjDpP_X5Bw;

	// Token: 0x040009B4 RID: 2484
	internal #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ #=zuDE8VGQ9_O5V = new #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ();

	// Token: 0x040009B5 RID: 2485
	internal #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ #=zR0loHvxEjwywO1Iidg== = new #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ();

	// Token: 0x040009B6 RID: 2486
	internal #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ #=z1GTenplEBYm2 = new #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ();

	// Token: 0x040009B7 RID: 2487
	internal short[] #=zRQKwGJjqgRGa = new short[#=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zO9LTehyXK9Wr + 1];

	// Token: 0x040009B8 RID: 2488
	internal int[] #=zpXKZvhI= = new int[2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zexLItYjL27h5 + 1];

	// Token: 0x040009B9 RID: 2489
	internal int #=zh85prTr2G_WY;

	// Token: 0x040009BA RID: 2490
	internal int #=zheGHEHMCIpNT;

	// Token: 0x040009BB RID: 2491
	internal sbyte[] #=z8h8JAHU= = new sbyte[2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zexLItYjL27h5 + 1];

	// Token: 0x040009BC RID: 2492
	internal int #=zjIfLx08Qsx1R;

	// Token: 0x040009BD RID: 2493
	internal int #=zHSo1xM06V91z7wLekA==;

	// Token: 0x040009BE RID: 2494
	internal int #=zQ5CGcJs$SF9h;

	// Token: 0x040009BF RID: 2495
	internal int #=zhhX$L2GhNIGR;

	// Token: 0x040009C0 RID: 2496
	internal int #=z3nPze4xN8xfT;

	// Token: 0x040009C1 RID: 2497
	internal int #=zQzrhsNbgIMpy;

	// Token: 0x040009C2 RID: 2498
	internal int #=zKQzkG64=;

	// Token: 0x040009C3 RID: 2499
	internal int #=zsA8UeIo$tsLcz_j3iw==;

	// Token: 0x040009C4 RID: 2500
	internal short #=zhBP95zayY8AN;

	// Token: 0x040009C5 RID: 2501
	internal int #=zcXxMrmM9nuW4;

	// Token: 0x040009C6 RID: 2502
	private bool #=z9tIIjMNb7mNc3khxHw==;

	// Token: 0x040009C7 RID: 2503
	private bool #=zKKCikhgYnBiczmmcfq4938g= = true;

	// Token: 0x0200023A RID: 570
	internal sealed class #=zSTdA3as=
	{
		// Token: 0x06001185 RID: 4485 RVA: 0x00088090 File Offset: 0x00086290
		private #=zSTdA3as=(int #=zDSPkgM3xJIiQ, int #=znrKneOXlQdOv, int #=zAp0uoba4ZY7d, int #=zYzoJw5xzZOMR, #=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w== #=zFBKIcq0=)
		{
			this.#=z1dkBew7DHH3k = #=zDSPkgM3xJIiQ;
			this.#=z63G$lffKfQX$ = #=znrKneOXlQdOv;
			this.#=z_LainSUwbilC = #=zAp0uoba4ZY7d;
			this.#=z0Ypz9SujqFpW = #=zYzoJw5xzZOMR;
			this.#=zMkZUgxo= = #=zFBKIcq0=;
		}

		// Token: 0x06001187 RID: 4487 RVA: 0x00088190 File Offset: 0x00086390
		public static #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as= #=z55MbmG4=(CompressionLevel #=z5w6HcG4=)
		{
			return #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=.#=zvOmIp0Q=[(int)#=z5w6HcG4=];
		}

		// Token: 0x040009C8 RID: 2504
		internal int #=z1dkBew7DHH3k;

		// Token: 0x040009C9 RID: 2505
		internal int #=z63G$lffKfQX$;

		// Token: 0x040009CA RID: 2506
		internal int #=z_LainSUwbilC;

		// Token: 0x040009CB RID: 2507
		internal int #=z0Ypz9SujqFpW;

		// Token: 0x040009CC RID: 2508
		internal #=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w== #=zMkZUgxo=;

		// Token: 0x040009CD RID: 2509
		private static readonly #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=[] #=zvOmIp0Q= = new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=[]
		{
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(0, 0, 0, 0, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)0),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(4, 4, 8, 4, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)1),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(4, 5, 16, 8, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)1),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(4, 6, 32, 32, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)1),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(4, 4, 16, 16, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(8, 16, 32, 32, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(8, 16, 128, 128, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(8, 32, 128, 256, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(32, 128, 258, 1024, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2),
			new #=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA==.#=zSTdA3as=(32, 258, 258, 4096, (#=zfyqWD7kzVevb6GiNOKejIxfu0bh1hdAQ_w==)2)
		};
	}

	// Token: 0x0200023B RID: 571
	// (Invoke) Token: 0x06001189 RID: 4489
	internal delegate #=zWNORJ5Z0s4ZJ1rERL3JDEQRo9g1t71g2EQ== #=zsbGAnE2GbPlT(FlushType #=zmhpr6mQ=);
}
