﻿using System;
using System.Collections.Generic;

// Token: 0x020002A1 RID: 673
internal sealed class #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=
{
	// Token: 0x06001479 RID: 5241 RVA: 0x0009C810 File Offset: 0x0009AA10
	public #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=()
	{
		this.#=zkJ2xDj9mSMZwqA$R0Q==(new List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=>());
		this.#=zWJtg2ZwejGqM(-1);
		this.#=zmveJs$A5$Bpd(0);
		this.#=zSF$lIVazflq3(0);
		this.#=zL8wh3TkHC91d(0);
		this.#=zL5jsuAE=(null);
	}

	// Token: 0x0600147A RID: 5242 RVA: 0x0009C848 File Offset: 0x0009AA48
	public List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=zeuby03ajdKyS073vzg==()
	{
		return this.#=zm8KVnLMqZhg2jyXEwA2AQXmQ_5Qr;
	}

	// Token: 0x0600147B RID: 5243 RVA: 0x0009C850 File Offset: 0x0009AA50
	public void #=zkJ2xDj9mSMZwqA$R0Q==(List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=z$Ib9gYQ=)
	{
		this.#=zm8KVnLMqZhg2jyXEwA2AQXmQ_5Qr = #=z$Ib9gYQ=;
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x0009C85C File Offset: 0x0009AA5C
	public int #=zYkDcCtJRo4Kt()
	{
		return this.#=zw5Re7hYQSgrGwxZ3vtKVhpg=;
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x0009C864 File Offset: 0x0009AA64
	public void #=zWJtg2ZwejGqM(int #=z$Ib9gYQ=)
	{
		this.#=zw5Re7hYQSgrGwxZ3vtKVhpg= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x0009C870 File Offset: 0x0009AA70
	public int #=z27qU0v2nVbmq()
	{
		return this.#=zdtGMPLYGNVkWFdBLPlimxwM=;
	}

	// Token: 0x0600147F RID: 5247 RVA: 0x0009C878 File Offset: 0x0009AA78
	public void #=zmveJs$A5$Bpd(int #=z$Ib9gYQ=)
	{
		this.#=zdtGMPLYGNVkWFdBLPlimxwM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001480 RID: 5248 RVA: 0x0009C884 File Offset: 0x0009AA84
	public int #=zaNJ233J3hmDJ()
	{
		return this.#=zR1hNu_XrT86JqGJolT8s90Y=;
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x0009C88C File Offset: 0x0009AA8C
	public void #=zSF$lIVazflq3(int #=z$Ib9gYQ=)
	{
		this.#=zR1hNu_XrT86JqGJolT8s90Y= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x0009C898 File Offset: 0x0009AA98
	public int #=zWiYm5yGEKz9k()
	{
		return this.#=zJY4hCPydKfG$Hd6FV9Tn3hs=;
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x0009C8A0 File Offset: 0x0009AAA0
	public void #=zL8wh3TkHC91d(int #=z$Ib9gYQ=)
	{
		this.#=zJY4hCPydKfG$Hd6FV9Tn3hs= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x0009C8AC File Offset: 0x0009AAAC
	public Exception #=zZEc75Ho=()
	{
		return this.#=zMUWZqaYIG9GBGxTFGQ==;
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x0009C8B4 File Offset: 0x0009AAB4
	public void #=zL5jsuAE=(Exception #=z$Ib9gYQ=)
	{
		this.#=zMUWZqaYIG9GBGxTFGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000BB0 RID: 2992
	private List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=zm8KVnLMqZhg2jyXEwA2AQXmQ_5Qr;

	// Token: 0x04000BB1 RID: 2993
	private int #=zw5Re7hYQSgrGwxZ3vtKVhpg=;

	// Token: 0x04000BB2 RID: 2994
	private int #=zdtGMPLYGNVkWFdBLPlimxwM=;

	// Token: 0x04000BB3 RID: 2995
	private int #=zR1hNu_XrT86JqGJolT8s90Y=;

	// Token: 0x04000BB4 RID: 2996
	private int #=zJY4hCPydKfG$Hd6FV9Tn3hs=;

	// Token: 0x04000BB5 RID: 2997
	private Exception #=zMUWZqaYIG9GBGxTFGQ==;
}
