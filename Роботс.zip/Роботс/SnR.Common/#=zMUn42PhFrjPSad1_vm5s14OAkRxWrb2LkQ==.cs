﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000164 RID: 356
internal sealed class #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==
{
	// Token: 0x0600097C RID: 2428 RVA: 0x0004D264 File Offset: 0x0004B464
	public #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==(Dictionary<string, object> #=z$F00z7HcZ7hu)
	{
		this.#=zOKl6UTGv_QX3Z8qqUg==(new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==(#=z$F00z7HcZ7hu[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)]));
		this.#=z3cMkeboeP0zjfiWAsw==(JSONManager.GetInt(#=z$F00z7HcZ7hu, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052672), 0));
		this.#=zdMm8cbXw4OEf(new List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==>());
		object[] array = JSONManager.GetArray(#=z$F00z7HcZ7hu, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052926));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== item = new #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==((Dictionary<string, object>)array[i]);
				this.#=z6Uo9D2yKen_Y().Add(item);
			}
		}
		this.#=zIR9Xlcg=(TimeSpan.FromSeconds((double)JSONManager.ExtractInt(#=z$F00z7HcZ7hu, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0)));
		int num = JSONManager.ExtractInt(#=z$F00z7HcZ7hu, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0);
		if (num > 0)
		{
			this.#=z6Uo9D2yKen_Y().Add(new #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==((#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM=)2, 0, num));
		}
	}

	// Token: 0x0600097D RID: 2429 RVA: 0x0004D338 File Offset: 0x0004B538
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z_CUgG1uVO0_6ruY6OA==()
	{
		return this.#=zplxL2vdXWaFiHhvBd8rgDJA=;
	}

	// Token: 0x0600097E RID: 2430 RVA: 0x0004D340 File Offset: 0x0004B540
	public void #=zOKl6UTGv_QX3Z8qqUg==(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z$Ib9gYQ=)
	{
		this.#=zplxL2vdXWaFiHhvBd8rgDJA= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600097F RID: 2431 RVA: 0x0004D34C File Offset: 0x0004B54C
	public int #=zVgg2Re6s58iR4sllZA==()
	{
		return this.#=znR0UhrpcUQJhptPwbeTgrx8=;
	}

	// Token: 0x06000980 RID: 2432 RVA: 0x0004D354 File Offset: 0x0004B554
	public void #=z3cMkeboeP0zjfiWAsw==(int #=z$Ib9gYQ=)
	{
		this.#=znR0UhrpcUQJhptPwbeTgrx8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000981 RID: 2433 RVA: 0x0004D360 File Offset: 0x0004B560
	public List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=z6Uo9D2yKen_Y()
	{
		return this.#=zDAr22$BxOb_X0tWnjA==;
	}

	// Token: 0x06000982 RID: 2434 RVA: 0x0004D368 File Offset: 0x0004B568
	public void #=zdMm8cbXw4OEf(List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=z$Ib9gYQ=)
	{
		this.#=zDAr22$BxOb_X0tWnjA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000983 RID: 2435 RVA: 0x0004D374 File Offset: 0x0004B574
	public TimeSpan #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x06000984 RID: 2436 RVA: 0x0004D37C File Offset: 0x0004B57C
	public void #=zIR9Xlcg=(TimeSpan #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400056D RID: 1389
	private #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zplxL2vdXWaFiHhvBd8rgDJA=;

	// Token: 0x0400056E RID: 1390
	private int #=znR0UhrpcUQJhptPwbeTgrx8=;

	// Token: 0x0400056F RID: 1391
	private List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zDAr22$BxOb_X0tWnjA==;

	// Token: 0x04000570 RID: 1392
	private TimeSpan #=zJDEdzIaDvHbnYM06$w==;
}
