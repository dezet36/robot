﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;
using Skink.SnR.Common.UserMeta;

// Token: 0x020001CE RID: 462
internal sealed class #=zX1MiJczxPMCN9tCBUgectCHF$DQ2
{
	// Token: 0x06000DAE RID: 3502 RVA: 0x0006A51C File Offset: 0x0006871C
	public #=zX1MiJczxPMCN9tCBUgectCHF$DQ2()
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOAzeRO$HqsMN = this;
		this.#=z6KD5Fixsanu8 = new #=ze$wRqZvk4IFxxkyZrijhYK$eX_La(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023490), 0);
	}

	// Token: 0x06000DB0 RID: 3504 RVA: 0x0006A5B0 File Offset: 0x000687B0
	public static #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zKVN4CRU=()
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOAzeRO$HqsMN;
	}

	// Token: 0x06000DB1 RID: 3505 RVA: 0x0006A5B8 File Offset: 0x000687B8
	public List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zOdy_aU_tk1aY()
	{
		return this.#=z87n$QYHiz3$vOoJLjA==;
	}

	// Token: 0x06000DB2 RID: 3506 RVA: 0x0006A5C0 File Offset: 0x000687C0
	public List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zol80P7TKoihZ()
	{
		return this.#=zgIqT5PY=;
	}

	// Token: 0x06000DB3 RID: 3507 RVA: 0x0006A5C8 File Offset: 0x000687C8
	public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQ4wZnctPyyRO()
	{
		if (this.#=zgIqT5PY= != null && this.#=zgIqT5PY=.Count > 0)
		{
			return this.#=zgIqT5PY=[0];
		}
		return null;
	}

	// Token: 0x06000DB4 RID: 3508 RVA: 0x0006A5F0 File Offset: 0x000687F0
	public #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zv2Kyu17YrGOC()
	{
		return #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC();
	}

	// Token: 0x06000DB5 RID: 3509 RVA: 0x0006A5F8 File Offset: 0x000687F8
	public #=zBNSjuxymwpzVeRYZu29JmEUUd7y_ZQcnPw== #=zevhuJealrhpG()
	{
		return this.#=zu4uJReDJb4ev;
	}

	// Token: 0x06000DB6 RID: 3510 RVA: 0x0006A600 File Offset: 0x00068800
	public #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zknIUyoRVNcX2()
	{
		return this.#=z6KD5Fixsanu8;
	}

	// Token: 0x06000DB7 RID: 3511 RVA: 0x0006A608 File Offset: 0x00068808
	public static void #=zibPHrbBZL5Cc(#=zDSiRXECNe4Awos25aECUKlmR8FRd #=zXC0ulc0=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null && #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2() != null)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z48rEd0A=(#=zXC0ulc0=);
		}
	}

	// Token: 0x06000DB8 RID: 3512 RVA: 0x0006A634 File Offset: 0x00068834
	public static void #=zibPHrbBZL5Cc(LogTypes #=zvRLj9WQ=, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null && #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2() != null)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(null, #=zvRLj9WQ=, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
		}
	}

	// Token: 0x06000DB9 RID: 3513 RVA: 0x0006A668 File Offset: 0x00068868
	public static void #=zfXC52bZ3r7yM(Exception #=zN_s5Z5A=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null && #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2() != null)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
		}
	}

	// Token: 0x06000DBA RID: 3514 RVA: 0x0006A694 File Offset: 0x00068894
	public #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ== #=z3vEaUui6bNl4()
	{
		return this.#=z2iktmSzYQHpk;
	}

	// Token: 0x06000DBB RID: 3515 RVA: 0x0006A69C File Offset: 0x0006889C
	public #=zxMOyT4mqlNEbNbr2evcJByuLqWmY66ZEzw== #=zZ7bll7yjWibZ()
	{
		return this.#=zQXlIqvTrwPLgFsMLMw==;
	}

	// Token: 0x06000DBC RID: 3516 RVA: 0x0006A6A4 File Offset: 0x000688A4
	public void #=zMBoy07_HlGOR(#=zxMOyT4mqlNEbNbr2evcJByuLqWmY66ZEzw== #=z$Ib9gYQ=)
	{
		this.#=zQXlIqvTrwPLgFsMLMw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000DBD RID: 3517 RVA: 0x0006A6B0 File Offset: 0x000688B0
	public void #=z1jlGMrg=()
	{
		#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=z$Ib9gYQ=;
		Dictionary<string, object> #=zaPDIgPVIJwMc6DcAuA==;
		this.#=z87n$QYHiz3$vOoJLjA== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zq09lacRJo0Of(out #=z$Ib9gYQ=, out #=zaPDIgPVIJwMc6DcAuA==);
		#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zdMaX3XaC3vQm(#=z$Ib9gYQ=);
		this.#=zErl_Y6xnxoeCbRncEQ==();
		this.#=zv_V_Yw63ia3c = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z330rKfPtihFX();
		this.#=z2iktmSzYQHpk = new #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==(#=zaPDIgPVIJwMc6DcAuA==);
		this.#=zgIqT5PY= = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in this.#=z87n$QYHiz3$vOoJLjA==)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbNwdgEO3SWKr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, this.#=zv_V_Yw63ia3c);
				this.#=zgIqT5PY=.Add(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
			}
		}
		this.#=zybD3gyKTiw1w();
		this.#=zBwAn1gXCuim2rBd5eA== = DateTime.MinValue;
		this.#=zSJdH6zXojLlk = new #=zCkJ2v872SjNxELhRccHmlEbiV4Z7(this.#=z6KD5Fixsanu8);
		this.#=zxzM$S$$Tasyo();
		this.#=zDt8M0JRTQpgMw6Nl6A== = new #=zBlV0sBQdC88uTJgOosW7FZ0cX0Gr();
		this.#=zSLICU36qdPPJ = new #=zJszBSBJVMeorD6roCiYj0PrZQRO_Ew1yUw==();
		this.#=zu4uJReDJb4ev = new #=zBNSjuxymwpzVeRYZu29JmEUUd7y_ZQcnPw==();
		ServicePointManager.DefaultConnectionLimit = 100;
	}

	// Token: 0x06000DBE RID: 3518 RVA: 0x0006A7DC File Offset: 0x000689DC
	public void #=zErl_Y6xnxoeCbRncEQ==()
	{
		GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
		for (int i = 0; i < this.#=z87n$QYHiz3$vOoJLjA==.Count; i++)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = this.#=z87n$QYHiz3$vOoJLjA==[i];
			for (int j = 0; j < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY().Count; j++)
			{
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY()[j];
				if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == gameHosters)
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zniPhYP4=(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl);
				}
			}
			for (int k = 0; k < this.#=z87n$QYHiz3$vOoJLjA==.Count; k++)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zniPhYP4=(this.#=z87n$QYHiz3$vOoJLjA==[k]);
			}
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zUvrxU4BElRg_WEPM3Q==();
		}
	}

	// Token: 0x06000DBF RID: 3519 RVA: 0x0006A884 File Offset: 0x00068A84
	public void #=z0ZcCdTI=(List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==> #=zoy6L17WMkUaQ, bool #=zwMbodNUH47FNsb_gIw==)
	{
		if (this.#=z87n$QYHiz3$vOoJLjA== == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023314), Array.Empty<object>());
		}
		if (this.#=zgIqT5PY= == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023275), Array.Empty<object>());
		}
		if (#=zoy6L17WMkUaQ == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023232), Array.Empty<object>());
		}
		for (int i = 0; i < #=zoy6L17WMkUaQ.Count; i++)
		{
			#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== = #=zoy6L17WMkUaQ[i];
			if (#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== == null)
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023448), new object[]
				{
					i
				});
			}
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = null;
			for (int j = 0; j < this.#=z87n$QYHiz3$vOoJLjA==.Count; j++)
			{
				if (this.#=z87n$QYHiz3$vOoJLjA==[j] == null)
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023413), new object[]
					{
						j
					});
				}
				if (this.#=z87n$QYHiz3$vOoJLjA==[j].#=z9Yordw6ZFjQe() == #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zCCvotbi$42tS())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = this.#=z87n$QYHiz3$vOoJLjA==[j];
					break;
				}
			}
			if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== == null)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = new #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==, i);
				this.#=z87n$QYHiz3$vOoJLjA==.Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15() == null)
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023367), new object[]
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z5KSZXEKT20zU()
					});
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z2iSHzUOfcQCGmQ541A==())
				{
					this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 1);
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zi0f5Pa6h6px6VelZcA==())
				{
					this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 2);
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpZW0ELWRfma6Hy7Ssw==())
				{
					this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 3);
				}
			}
			else
			{
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15() == null)
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909023367), new object[]
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z5KSZXEKT20zU()
					});
				}
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zZjKvLhjJMNEz(i);
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zJz$BeuY2bs5T(false);
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zuKcwTqrq7yWC(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zNX$RlG6YBqR7());
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z0yzdXaRNk7l4(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuyncuBlQbn2L());
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z2iSHzUOfcQCGmQ541A==() != #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z2iSHzUOfcQCGmQ541A==())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=znJq9SDhBSPImQwwzNw==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z2iSHzUOfcQCGmQ541A==());
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z2iSHzUOfcQCGmQ541A==())
					{
						this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 1);
					}
					else
					{
						this.#=zrpG$JIR$mx0j(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 1);
					}
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zi0f5Pa6h6px6VelZcA==() != #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zi0f5Pa6h6px6VelZcA==())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpCXbWGwIG26C0pyQVA==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zi0f5Pa6h6px6VelZcA==());
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zi0f5Pa6h6px6VelZcA==())
					{
						this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 2);
					}
					else
					{
						this.#=zrpG$JIR$mx0j(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 2);
					}
				}
				if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpZW0ELWRfma6Hy7Ssw==() != #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zpZW0ELWRfma6Hy7Ssw==())
				{
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zbptKj70_nY72H4iMaw==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zpZW0ELWRfma6Hy7Ssw==());
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpZW0ELWRfma6Hy7Ssw==())
					{
						this.#=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 3);
					}
					else
					{
						this.#=zrpG$JIR$mx0j(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 3);
					}
				}
				#=zsbSUbPIrr0Jx4i4zxZS5Yvu6Ma3k.#=zlOX8R3a9JCFG(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zuyncuBlQbn2L());
			}
		}
		for (int k = this.#=z87n$QYHiz3$vOoJLjA==.Count - 1; k >= 0; k--)
		{
			#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2 = this.#=z87n$QYHiz3$vOoJLjA==[k];
			#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==2 = null;
			for (int l = 0; l < #=zoy6L17WMkUaQ.Count; l++)
			{
				if (#=zoy6L17WMkUaQ[l].#=zCCvotbi$42tS() == #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe())
				{
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==2 = #=zoy6L17WMkUaQ[l];
					break;
				}
			}
			if (#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==2 == null)
			{
				for (int m = 0; m < #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zol80P7TKoihZ().Count; m++)
				{
					this.#=zgIqT5PY=.Remove(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zol80P7TKoihZ()[m]);
				}
				this.#=z87n$QYHiz3$vOoJLjA==.Remove(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2);
				if (#=zwMbodNUH47FNsb_gIw==)
				{
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zvuVAl$GL8W_$(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=z9Yordw6ZFjQe(), GameApplicationData.#=z7wsmjLWw49AC(), GameApplicationData.#=zZ2dsDUeWDYAN());
				}
			}
		}
		this.#=z87n$QYHiz3$vOoJLjA==.Sort(new Comparison<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zyDNvciU=.#=zLkw0NRU=.#=z7NoCWWotE6cOXbrrQT_sVfw=));
		this.#=zgIqT5PY=.Sort(new Comparison<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zyDNvciU=.#=zLkw0NRU=.#=zL4EmqyOSjUEktkyM3$mQYs8=));
		for (int n = 0; n < this.#=z87n$QYHiz3$vOoJLjA==.Count; n++)
		{
			this.#=z87n$QYHiz3$vOoJLjA==[n].#=zZjKvLhjJMNEz(n);
		}
		this.#=zPLWPn_Vlu7rO();
	}

	// Token: 0x06000DC0 RID: 3520 RVA: 0x0006ACB4 File Offset: 0x00068EB4
	private void #=zixARThQEbiKr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, int #=zLeeSKrg=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== item = new #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==(#=zhoOF5s8=, #=zLeeSKrg=);
		#=zhoOF5s8=.#=zol80P7TKoihZ().Add(item);
		this.#=zgIqT5PY=.Add(item);
	}

	// Token: 0x06000DC1 RID: 3521 RVA: 0x0006ACE4 File Offset: 0x00068EE4
	private void #=zrpG$JIR$mx0j(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, int #=zLeeSKrg=)
	{
		for (int i = 0; i < #=zhoOF5s8=.#=zol80P7TKoihZ().Count; i++)
		{
			if (#=zhoOF5s8=.#=zol80P7TKoihZ()[i].#=zYgvZuBwR$a1C() == #=zLeeSKrg=)
			{
				#=zhoOF5s8=.#=zol80P7TKoihZ().RemoveAt(i);
				break;
			}
		}
		for (int j = 0; j < this.#=zgIqT5PY=.Count; j++)
		{
			if (this.#=zgIqT5PY=[j].#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe() == #=zhoOF5s8=.#=z9Yordw6ZFjQe() && this.#=zgIqT5PY=[j].#=zYgvZuBwR$a1C() == #=zLeeSKrg=)
			{
				this.#=zgIqT5PY=.RemoveAt(j);
				return;
			}
		}
	}

	// Token: 0x06000DC2 RID: 3522 RVA: 0x0006AD84 File Offset: 0x00068F84
	private XmlNode #=zLF5Kx38=(XmlNode #=zzkKNTyw=, string #=z6QPrZ_4=, string #=zHWRkUDQ=, XmlDocument #=zxq0yPKs=)
	{
		XmlNode xmlNode = #=zxq0yPKs=.CreateElement(#=z6QPrZ_4=);
		if (!string.IsNullOrEmpty(#=zHWRkUDQ=))
		{
			xmlNode.InnerText = #=zHWRkUDQ=;
		}
		if (#=zzkKNTyw= != null)
		{
			#=zzkKNTyw=.AppendChild(xmlNode);
		}
		return xmlNode;
	}

	// Token: 0x06000DC3 RID: 3523 RVA: 0x0006ADB8 File Offset: 0x00068FB8
	private XmlNode #=z51NB$t0=(XmlNode #=zyPAQXIo=, string #=z6QPrZ_4=, string #=z$Ib9gYQ=, XmlDocument #=zxq0yPKs=)
	{
		XmlAttribute xmlAttribute = #=zxq0yPKs=.CreateAttribute(#=z6QPrZ_4=);
		xmlAttribute.Value = #=z$Ib9gYQ=;
		#=zyPAQXIo=.Attributes.Append(xmlAttribute);
		return xmlAttribute;
	}

	// Token: 0x06000DC4 RID: 3524 RVA: 0x0006ADE4 File Offset: 0x00068FE4
	public void #=z4r1Y$wYr4xSL(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zYZyOAbZiAYRn.#=zNiDqnIE=(#=z8StzeqE=);
	}

	// Token: 0x06000DC5 RID: 3525 RVA: 0x0006ADF4 File Offset: 0x00068FF4
	private void #=zPLWPn_Vlu7rO()
	{
		try
		{
			XmlDocument xmlDocument = new XmlDocument();
			XmlNode xmlNode = xmlDocument.CreateNode(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025097), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025083), string.Empty);
			XmlNode xmlNode2 = this.#=zLF5Kx38=(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025066), null, xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025063), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068317), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025045), this.#=zv2Kyu17YrGOC().#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025263), this.#=zv2Kyu17YrGOC().#=zxZUNpQr446iF4sFzC4IllHyNkuAk().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025217), JSONManager.EncodeTime(this.#=zv2Kyu17YrGOC().#=zkNpw_HkXGbLlGZ02xXjTauDMITO4(), false), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025170), this.#=zv2Kyu17YrGOC().#=zsJ3LVoBnMJ5KlcKlZw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024889), this.#=zv2Kyu17YrGOC().#=zi5UL_sLuZ3kXXvtS4g==().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024856), this.#=zv2Kyu17YrGOC().#=zD4i5XsuB4tQfZEBJSw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=zLF5Kx38=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024824), JSONManager.SerializeData(this.#=zv2Kyu17YrGOC().#=zUySUFPd4ZTeE()), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024802), this.#=zv2Kyu17YrGOC().#=zvQM7hTETWDsDiXZCaw==().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024769), this.#=zv2Kyu17YrGOC().#=zw2h_ju8xFkKozhcDJ6vjwpSYxkI6().ToString(), xmlDocument);
			this.#=zLF5Kx38=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024998), JSONManager.SerializeData(this.#=z2iktmSzYQHpk.#=zHTvXKUY=()), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024968), this.#=zv2Kyu17YrGOC().#=z0vyMSSgQNFYClT1jJg==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024957), this.#=zv2Kyu17YrGOC().#=zNIPvwbLh3eAI1kQdaS1a8Vi4cP4G() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024927), this.#=zv2Kyu17YrGOC().#=zrXOjFBdb5lleq1hEe$0hzQ_8RWgEbT9mog==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024636), this.#=zv2Kyu17YrGOC().#=zOyga2HEau$YaaQwjOw==(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024602), this.#=zv2Kyu17YrGOC().#=zoLzPtcVDz1OXV9drqA==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024577), this.#=zv2Kyu17YrGOC().#=zK6IaAIJJxtyc(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024561), this.#=zv2Kyu17YrGOC().#=zoB_PPwnFbKCa() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024539), this.#=zv2Kyu17YrGOC().#=zOfJCiJK$ZVVkuth4jDES0lb35dZpcHbrSQ==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024761), this.#=zv2Kyu17YrGOC().#=zQmMP6wt1RftoX0jGx5VWOLw=() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024741), this.#=zv2Kyu17YrGOC().#=zKatp2kKFbWctd3l7feJusRE=() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024708), this.#=zv2Kyu17YrGOC().#=zK0Bl_aLmVIcfjen9YvGM2N2U4PVP7Hbgng==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024666), this.#=zv2Kyu17YrGOC().#=zpCmQXZTzH4U2() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024642), this.#=zv2Kyu17YrGOC().#=zgS33aA7O0JjP5mZqsY2xXXg=() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024360), this.#=zv2Kyu17YrGOC().#=zgPkXqnTbuiTDilNJGQ==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024329), this.#=zv2Kyu17YrGOC().#=zgr_b3nv857lLfLmFjw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024308), this.#=zv2Kyu17YrGOC().#=z_B7PL3U2K4yBHXwnUg==().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024287), this.#=zv2Kyu17YrGOC().#=zHa_mQ_k2vULVf6_XNw==().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874)), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024511), this.#=zv2Kyu17YrGOC().#=z5gsZrvYx_Krzuff_zw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024472), this.#=zv2Kyu17YrGOC().#=zHXf6R08vedD$hfpwG5Ci3WE=().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024439), this.#=zv2Kyu17YrGOC().#=zSDzL$lsR3vYFW9AP7Wibl1x6NGFq() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024308), this.#=zv2Kyu17YrGOC().#=z_B7PL3U2K4yBHXwnUg==().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024387), this.#=zv2Kyu17YrGOC().#=zqGZod7DuP$m614qxIj6v4lE=().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944234), this.#=zv2Kyu17YrGOC().#=zDDkQ_RdZgdNGO6OtyQ==().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944221), this.#=zv2Kyu17YrGOC().#=zydSN$ZobqYZXe5Kw7A==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944190), this.#=zv2Kyu17YrGOC().#=zOR7fTvmTu73NfJN7OcVEOIaIdTad2ijeeg==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944157), this.#=zv2Kyu17YrGOC().#=zpxNt6CS3$Hsx().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944134), this.#=zv2Kyu17YrGOC().#=zEENapEnsc_FcfPHADJ3whqs=() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944362), this.#=zv2Kyu17YrGOC().#=ztmwqj9gOfD5f3LJDJXnN16s=() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944330), this.#=zv2Kyu17YrGOC().#=zLTcKZ4NeSgHgtq5frELA$x0=().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944305), this.#=zv2Kyu17YrGOC().#=z97Z7CxekCb4f() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944275), this.#=zv2Kyu17YrGOC().#=zrQfDHfQ_N5CC().ToString(), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944261), this.#=zv2Kyu17YrGOC().#=z1YiK06BjkZhJ62B0rQ==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943974), this.#=zv2Kyu17YrGOC().#=zL7ZDlcYJHrdWKPBrLfJWbCXAFa2U() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076699), xmlDocument);
			this.#=z51NB$t0=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943937), this.#=zv2Kyu17YrGOC().#=zNqNm8eiTRoJhiqVdyQ==(), xmlDocument);
			string text = this.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zhv7OhlM=();
			if (!string.IsNullOrEmpty(text))
			{
				this.#=zLF5Kx38=(xmlNode2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943918), text, xmlDocument);
			}
			foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in this.#=z87n$QYHiz3$vOoJLjA==)
			{
				XmlNode xmlNode3 = this.#=zLF5Kx38=(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943909), null, xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zCCvotbi$42tS(), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111208), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7(), xmlDocument);
				if (!string.IsNullOrWhiteSpace(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zuyncuBlQbn2L()))
				{
					this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943895), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zuyncuBlQbn2L().Trim(), xmlDocument);
				}
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113164), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z2iSHzUOfcQCGmQ541A==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113096), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zi0f5Pa6h6px6VelZcA==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596), xmlDocument);
				if (GameApplicationData.#=zMD9IS3VDVH4f() > 2)
				{
					this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113312), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpZW0ELWRfma6Hy7Ssw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596), xmlDocument);
				}
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944127), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==(), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944098), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zxSNRMjqS3yCO(), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944080), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zbfOGJA_8wt3H(), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944069), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zjWBl268nvo9O(), xmlDocument);
				this.#=z51NB$t0=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944045), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zUBdNbQEy4rFD(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944010), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zG96rwfOikL5q(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943737), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=znOgAsLixEItF(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943723), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z$V9uwJPAniCv(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943719), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zBy_Rtgu6pzWv(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943701), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zw3M1PzX18p_r(), xmlDocument);
				this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943675), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zg3LzOtbX7Rdo(), xmlDocument);
				foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
				{
					XmlNode xmlNode4 = this.#=zLF5Kx38=(xmlNode3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943651), null, xmlDocument);
					this.#=z51NB$t0=(xmlNode4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943645), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C().ToString(), xmlDocument);
					StringWriter stringWriter = new StringWriter();
					try
					{
						new XmlSerializer(typeof(ActionSettings)).Serialize(stringWriter, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC());
						string text2 = stringWriter.ToString();
						if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909101228)))
						{
							text2 = text2.Substring(text2.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909101228)) + 2).Trim();
						}
						xmlNode4.InnerXml = text2;
					}
					finally
					{
						((IDisposable)stringWriter).Dispose();
					}
				}
			}
			this.#=zLF5Kx38=(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943619), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943858), xmlDocument).InnerText = #=zEUBS1i3F2YjLKP$jPmnwi_fM9U4u.#=zoFZMcJzdKf_O(xmlNode.OuterXml, true);
			string text3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943843), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
			string outerXml = xmlNode.OuterXml;
			if (!string.IsNullOrEmpty(outerXml))
			{
				#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(text3, outerXml, Encoding.UTF8, false);
				string text4 = text3 + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859);
				string text5 = text3 + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064854);
				bool flag = false;
				if (!#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(text4))
				{
					flag = true;
				}
				else if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zFC3B_hWy9GfK(text4) < DateTime.Now - TimeSpan.FromHours(1.0))
				{
					flag = true;
				}
				if (flag)
				{
					try
					{
						string xml = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(text3);
						XmlDocument xmlDocument2 = new XmlDocument();
						xmlDocument2.LoadXml(xml);
						if (xmlDocument2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025083)] == null)
						{
							flag = false;
						}
						else if (xmlDocument2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025083)][#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943909)] == null)
						{
							flag = false;
						}
					}
					catch
					{
						flag = false;
					}
				}
				if (flag)
				{
					if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(text4))
					{
						if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(text5))
						{
							#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(text5);
						}
						#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z5CNc4A0=(text4, text5);
					}
					#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zz5WrUWQ=(text3, text4, true);
				}
			}
			if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943823)))
			{
				#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943823));
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in this.#=zgIqT5PY=)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			}
		}
	}

	// Token: 0x06000DC6 RID: 3526 RVA: 0x0006BC38 File Offset: 0x00069E38
	private static List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zq09lacRJo0Of(out #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=z6bRJXNQ=, out Dictionary<string, object> #=zaPDIgPVIJwMc6DcAuA==)
	{
		string text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943843), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list = new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCSoVrge0T492(text, list, out #=z6bRJXNQ=, out #=zaPDIgPVIJwMc6DcAuA==))
		{
			return list;
		}
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCSoVrge0T492(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859), list, out #=z6bRJXNQ=, out #=zaPDIgPVIJwMc6DcAuA==))
		{
			return list;
		}
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCSoVrge0T492(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064854), list, out #=z6bRJXNQ=, out #=zaPDIgPVIJwMc6DcAuA==))
		{
			return list;
		}
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCSoVrge0T492(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943823), list, out #=z6bRJXNQ=, out #=zaPDIgPVIJwMc6DcAuA==))
		{
			return list;
		}
		#=z6bRJXNQ= = new #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==();
		return new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>();
	}

	// Token: 0x06000DC7 RID: 3527 RVA: 0x0006BCC8 File Offset: 0x00069EC8
	private static bool #=zCSoVrge0T492(string #=zg3mKzgyTyR4f, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zrhvCoyA=, out #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=z6bRJXNQ=, out Dictionary<string, object> #=zaPDIgPVIJwMc6DcAuA==)
	{
		#=z6bRJXNQ= = new #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==();
		#=zaPDIgPVIJwMc6DcAuA== = null;
		try
		{
			if (!#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=zg3mKzgyTyR4f))
			{
				return false;
			}
			string text = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=zg3mKzgyTyR4f);
			if (text == null)
			{
				return false;
			}
			text = text.Trim().Trim(new char[1]);
			if (string.IsNullOrWhiteSpace(text))
			{
				return false;
			}
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(text);
			XmlElement xmlElement = xmlDocument[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025083)];
			XmlElement xmlElement2 = xmlElement[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943619)];
			string innerText = xmlElement2.InnerText;
			xmlElement2.InnerText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943858);
			string b = #=zEUBS1i3F2YjLKP$jPmnwi_fM9U4u.#=zoFZMcJzdKf_O(xmlElement.OuterXml, true);
			if (innerText != b && !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z5Sl0mODf9vA5())
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943798), Array.Empty<object>());
			}
			string text2 = null;
			foreach (object obj in xmlElement.ChildNodes)
			{
				XmlNode xmlNode = (XmlNode)obj;
				if (xmlNode.Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025066))
				{
					text2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025063));
					#=z6bRJXNQ=.#=zeK8uW$k$r3SqISDGBizDKLCXPH6E(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zo6iC9NQwsk2L(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025045), 4.0));
					#=z6bRJXNQ=.#=z85QWZwOqZayxq6LoxcnelCWHl6xw(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zo6iC9NQwsk2L(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025263), 6.0));
					#=z6bRJXNQ=.#=zy9zHV2WIukq_6fxsXZU_2cZnj_CL(JSONManager.DecodeTime(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025217)), false, DateTime.Now));
					#=z6bRJXNQ=.#=zvm9nJrl54We1hMNxrA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909025170)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zKXfdEG_SRmlW3RDnQw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024889), 180));
					#=z6bRJXNQ=.#=zbFxcPH$h2Pyozd$HmA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024856)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					string text3 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024824), null);
					if (!string.IsNullOrEmpty(text3))
					{
						try
						{
							Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(text3);
							#=z6bRJXNQ=.#=zUySUFPd4ZTeE().Clear();
							if (dictionary != null)
							{
								foreach (string text4 in dictionary.Keys)
								{
									string key = (text4.Length == 1) ? (text4 + #=zMUn42PhFrjPSad1_vm5s13vU$1t34Cq24A==.#=zM8IB4GHgekmL) : text4;
									#=z6bRJXNQ=.#=zUySUFPd4ZTeE().Add(key, JSONManager.ExtractInt(dictionary, text4, 0));
								}
							}
						}
						catch
						{
						}
					}
					#=z6bRJXNQ=.#=zqvsTI2pZsK$WYewZMg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024802), 5));
					string text5 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024998), null);
					if (!string.IsNullOrEmpty(text5))
					{
						try
						{
							#=zaPDIgPVIJwMc6DcAuA== = (Dictionary<string, object>)JSONManager.DeserializeData(text5);
						}
						catch
						{
						}
					}
					#=z6bRJXNQ=.#=zGDF9FhnW2XdR9t7SLgPSE2q5HYQU(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024769), 10));
					#=z6bRJXNQ=.#=zVzUJkQE1IS$VeSPi2A==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024968)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z8hsbIcjDAb1QrLOilgCsx6St8e5d(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024957)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zRSr8inJmIRdenO2Kx3fAd7mAq_BbK$tLcA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024927)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zlLOUC1_lSSSM_bwpIw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024636)));
					#=z6bRJXNQ=.#=z9ivAyW4kJ8CsXoR7IA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024602)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z2Hpm03d_VZLO(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024561)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zsWBzTCz304YK_806RooV1d_3HAzn_uZsVQ==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024539)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zkm$17$IlTaR2oM7WDU49iyU=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024761)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z3anSr65fJmAvGYgh9WMMlFQ=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024741)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zotjktKGp3XIW62npm5dfU8$W47mCR_183Q==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024708)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zniLh3STpapKu(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024666)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zjYfh5RMTctgdSZMAZRcXzCs=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024642)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z3cpv8KFh8oSKYPFmtw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024360)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zmBAbn8lVjzIxwUk4MQ==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024329)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zvpXQdiVrdaM09eg3Zw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024308), #=z6bRJXNQ=.#=z_B7PL3U2K4yBHXwnUg==()));
					#=z6bRJXNQ=.#=zA5paZH613b0CL2$_7A==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024511)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zLFRiaK_JMAMe2ckY2Oom7pg=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024472), #=z6bRJXNQ=.#=zHXf6R08vedD$hfpwG5Ci3WE=()));
					#=z6bRJXNQ=.#=zpXLX_3i5lnU$$w8oQw9YxRD26Uui(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024439), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zKMkR0RCsJW3J$G2ZVOji$Ec=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024387), #=z6bRJXNQ=.#=zqGZod7DuP$m614qxIj6v4lE=()));
					#=z6bRJXNQ=.#=zBgVYmVRHN2wEuC5Baw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944234), #=z6bRJXNQ=.#=zDDkQ_RdZgdNGO6OtyQ==()));
					#=z6bRJXNQ=.#=zHGnCecmvyt2BatHqzg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944221)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z33IiNiiFsCw9od2q2K0PfQw3V4OkL7GcIA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944190), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zst$ihAPKUnFr(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944157), #=z6bRJXNQ=.#=zpxNt6CS3$Hsx()));
					#=z6bRJXNQ=.#=zeERjfsoxtJoG2wzeDTXwjYs=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944134), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z6TlDAOtvSn994p7Nq9XYMYQ=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944362)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zvZS0089oji1A59BAw6JoJqs=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944330), #=z6bRJXNQ=.#=zLTcKZ4NeSgHgtq5frELA$x0=()));
					#=z6bRJXNQ=.#=zjg9CGODqQRqZ(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944305)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zDx485GAPH90Z(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z2Pp81HOyK55i(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944275), #=z6bRJXNQ=.#=zrQfDHfQ_N5CC()));
					#=z6bRJXNQ=.#=zrStz1Xlk9yosi9zyRg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944261)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=z9pCo1XzOwHnRILSrrSNR6mMOP_78(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943974), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
					#=z6bRJXNQ=.#=zEomkcsrzzqfsIGcH7g==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943937)));
					DateTime #=z$Ib9gYQ=;
					if (DateTime.TryParseExact(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909024287)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874), CultureInfo.InvariantCulture, DateTimeStyles.None, out #=z$Ib9gYQ=))
					{
						#=z6bRJXNQ=.#=z3feBcWbQtZMMROY1Iw==(#=z$Ib9gYQ=);
					}
					#=z6bRJXNQ=.#=z7_P2Ssq75CUN(new #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943918), null)));
				}
				else if (xmlNode.Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943909))
				{
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== = new #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==();
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=ze8TQhOAtefck(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168)].Value.Trim());
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuKcwTqrq7yWC(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111208)].Value);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z0yzdXaRNk7l4(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943895)));
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=znJq9SDhBSPImQwwzNw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113164), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588));
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zpCXbWGwIG26C0pyQVA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113096)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588));
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zbptKj70_nY72H4iMaw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113312)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588));
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = new #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==, #=zrhvCoyA=.Count);
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9l$gimR8dkJhDCQJAw==(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944127)].Value);
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zpVBlD$IJ4abR(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944080)].Value);
					if (string.IsNullOrWhiteSpace(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuyncuBlQbn2L()) && !string.IsNullOrWhiteSpace(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zbfOGJA_8wt3H()))
					{
						#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z0yzdXaRNk7l4(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zbfOGJA_8wt3H().Trim());
					}
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zVOkdnwLzxOWf(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944069)].Value);
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zhWr8WM11sNyG(xmlNode.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944045)].Value);
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zPzFoe9Yoa4Jh(xmlNode[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944010)].InnerText);
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zBFXSZ$Hu_V5Z(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943737), null));
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zchs2LGrZFGl4(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944098)));
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zZJbepNH_IDuQ(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943723), null));
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zsFXnaqjXugcU(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943719), null));
					if (string.IsNullOrEmpty(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z$V9uwJPAniCv()) && !string.IsNullOrEmpty(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zBy_Rtgu6pzWv()))
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zZJbepNH_IDuQ(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zBy_Rtgu6pzWv());
					}
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zpeAmYAKx8nem(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943701), null));
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zpo4eyll_HX97(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zrw9Jx0R06cJw(xmlNode, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943675), null));
					if (string.IsNullOrEmpty(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zw3M1PzX18p_r()) && !string.IsNullOrEmpty(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zg3LzOtbX7Rdo()))
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zpeAmYAKx8nem(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zg3LzOtbX7Rdo());
					}
					if (string.IsNullOrEmpty(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zxSNRMjqS3yCO()))
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z_CMx39SmGb4B(false);
					}
					bool flag = false;
					for (int i = 0; i < #=zrhvCoyA=.Count; i++)
					{
						if (#=zrhvCoyA=[i].#=z9Yordw6ZFjQe() == #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe())
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						#=zrhvCoyA=.Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
					}
					int num = GameApplicationData.#=zMD9IS3VDVH4f();
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=z2iSHzUOfcQCGmQ541A==() && num >= 1)
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ().Add(new #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 1));
					}
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zi0f5Pa6h6px6VelZcA==() && num >= 2)
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ().Add(new #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 2));
					}
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15().#=zpZW0ELWRfma6Hy7Ssw==() && num >= 3)
					{
						#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ().Add(new #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==, 3));
					}
					foreach (object obj2 in xmlNode.ChildNodes)
					{
						XmlNode xmlNode2 = (XmlNode)obj2;
						if (xmlNode2.Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943651))
						{
							string value = xmlNode2.Attributes[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943645)].Value;
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = null;
							foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
							{
								if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zYgvZuBwR$a1C().ToString() == value)
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2;
									break;
								}
							}
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
							{
								StringReader stringReader = new StringReader(xmlNode2.InnerXml);
								try
								{
									ActionSettings #=z6bRJXNQ=2 = (ActionSettings)new XmlSerializer(typeof(ActionSettings)).Deserialize(stringReader);
									ActionSettings actionSettings = null;
									if (actionSettings == null)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z7PpXELDatYLR(#=z6bRJXNQ=2);
									}
									else
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z7PpXELDatYLR(actionSettings);
									}
									#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCBHEy4NONPhU(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
								}
								finally
								{
									((IDisposable)stringReader).Dispose();
								}
							}
						}
					}
				}
			}
			if (text2 != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068317))
			{
				try
				{
					string str = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943843), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
					if (string.IsNullOrWhiteSpace(text2))
					{
						text2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943755);
					}
					string #=z7bZtJ$s= = str + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067993) + text2 + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859);
					#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zz5WrUWQ=(#=zg3mKzgyTyR4f, #=z7bZtJ$s=, true);
				}
				catch
				{
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTzbblUpMiEIf(#=zN_s5Z5A=);
			return false;
		}
		return true;
	}

	// Token: 0x06000DC8 RID: 3528 RVA: 0x0006CA80 File Offset: 0x0006AC80
	private static string #=zbf0Vz5p5ipTH(XmlNode #=zyPAQXIo=, string #=zM8rjytQ=)
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(#=zyPAQXIo=, #=zM8rjytQ=, string.Empty);
	}

	// Token: 0x06000DC9 RID: 3529 RVA: 0x0006CA90 File Offset: 0x0006AC90
	private static string #=zbf0Vz5p5ipTH(XmlNode #=zyPAQXIo=, string #=zM8rjytQ=, string #=zJeYCQZg=)
	{
		XmlAttribute xmlAttribute = #=zyPAQXIo=.Attributes[#=zM8rjytQ=];
		if (xmlAttribute != null)
		{
			return xmlAttribute.Value;
		}
		return #=zJeYCQZg=;
	}

	// Token: 0x06000DCA RID: 3530 RVA: 0x0006CAB8 File Offset: 0x0006ACB8
	private static int #=z2Pp81HOyK55i(XmlNode #=zyPAQXIo=, string #=zM8rjytQ=, int #=zJeYCQZg=)
	{
		int result;
		if (!int.TryParse(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(#=zyPAQXIo=, #=zM8rjytQ=, string.Empty), out result))
		{
			result = #=zJeYCQZg=;
		}
		return result;
	}

	// Token: 0x06000DCB RID: 3531 RVA: 0x0006CAE0 File Offset: 0x0006ACE0
	private static double #=zo6iC9NQwsk2L(XmlNode #=zyPAQXIo=, string #=zM8rjytQ=, double #=zJeYCQZg=)
	{
		double result;
		if (!double.TryParse(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zbf0Vz5p5ipTH(#=zyPAQXIo=, #=zM8rjytQ=, string.Empty), out result))
		{
			result = #=zJeYCQZg=;
		}
		return result;
	}

	// Token: 0x06000DCC RID: 3532 RVA: 0x0006CB08 File Offset: 0x0006AD08
	private static string #=zrw9Jx0R06cJw(XmlNode #=zzkKNTyw=, string #=z8S8yX4_JnDA2, string #=zJeYCQZg=)
	{
		XmlNode xmlNode = #=zzkKNTyw=[#=z8S8yX4_JnDA2];
		if (xmlNode != null)
		{
			return xmlNode.InnerText;
		}
		return #=zJeYCQZg=;
	}

	// Token: 0x06000DCD RID: 3533 RVA: 0x0006CB28 File Offset: 0x0006AD28
	public void #=z7AAGhiwXzGqB(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zQhFN4gS7pw0r4iXneeJbd3dveG5S.#=zNiDqnIE=(#=z8StzeqE=);
	}

	// Token: 0x06000DCE RID: 3534 RVA: 0x0006CB38 File Offset: 0x0006AD38
	public static void #=zZ26KHSLTYk$bHRH1Ag==(List<object> #=zDRWcagA=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		foreach (object obj in #=zDRWcagA=)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==)obj;
			if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zPLWPn_Vlu7rO();
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCBHEy4NONPhU(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
			}
		}
	}

	// Token: 0x06000DCF RID: 3535 RVA: 0x0006CB9C File Offset: 0x0006AD9C
	public void #=zCBHEy4NONPhU(int #=zbuCVyJk=)
	{
		this.#=zPLWPn_Vlu7rO();
		this.#=zt8qXnD$LK2FE(#=zbuCVyJk=);
	}

	// Token: 0x06000DD0 RID: 3536 RVA: 0x0006CBAC File Offset: 0x0006ADAC
	private void #=zt8qXnD$LK2FE(int #=zbuCVyJk=)
	{
		if (#=zbuCVyJk= >= 0 && this.#=zgIqT5PY=.Count > #=zbuCVyJk=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zCBHEy4NONPhU(this.#=zgIqT5PY=[#=zbuCVyJk=]);
		}
	}

	// Token: 0x06000DD1 RID: 3537 RVA: 0x0006CBD4 File Offset: 0x0006ADD4
	private static void #=zCBHEy4NONPhU(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().InitExpireHours != #=z8StzeqE=.#=zaudlwXG$FEcN().InitExpireHours)
		{
			#=z8StzeqE=.#=z_OReq$2Fp1WgvhSEAt7Hh6E=();
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendToAcropol != #=z8StzeqE=.#=zaudlwXG$FEcN().IsSendToAcropol || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendToAcropolUrgent != #=z8StzeqE=.#=zaudlwXG$FEcN().IsSendToAcropolUrgent || #=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolInterval != #=z8StzeqE=.#=zaudlwXG$FEcN().SendToAcropolInterval)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.SendToAcropol, #=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendToAcropolUrgent ? TaskSeverities.UrgentNoRelogin : TaskSeverities.Background, TimeSpan.FromSeconds((double)#=z8StzeqE=.#=zv2Kyu17YrGOC().SendToAcropolInterval), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendToAcropol, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCloseQuests != #=z8StzeqE=.#=zaudlwXG$FEcN().IsCloseQuests)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.CloseQuests, TaskSeverities.Background, TimeSpan.FromMinutes(10.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsCloseQuests);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProphecies != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoProphecies)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.CompleteProphecies, TaskSeverities.Background, TimeSpan.FromMinutes(10.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProphecies);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsExchangeDenaries != #=z8StzeqE=.#=zaudlwXG$FEcN().IsExchangeDenaries || #=z8StzeqE=.#=zv2Kyu17YrGOC().ExcangeDenariesPeriod != #=z8StzeqE=.#=zaudlwXG$FEcN().ExcangeDenariesPeriod)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ExchangeDenaries, TaskSeverities.Background, TimeSpan.FromMinutes((double)#=z8StzeqE=.#=zv2Kyu17YrGOC().ExcangeDenariesPeriod), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsExchangeDenaries, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCollectResources != #=z8StzeqE=.#=zaudlwXG$FEcN().IsCollectResources)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.CollectResources, TaskSeverities.Background, TimeSpan.FromMinutes(15.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsCollectResources);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCollectResourcesBuildings != #=z8StzeqE=.#=zaudlwXG$FEcN().IsCollectResourcesBuildings)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.CollectResourcesBuildings, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsCollectResourcesBuildings);
		}
		if ((#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuildBuildings || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeBuildings) != (#=z8StzeqE=.#=zaudlwXG$FEcN().IsBuildBuildings || #=z8StzeqE=.#=zaudlwXG$FEcN().IsUpgradeBuildings))
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.BuildBuildings, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuildBuildings || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeBuildings);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeHermes != #=z8StzeqE=.#=zaudlwXG$FEcN().IsUpgradeHermes)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.UpgradeHermes, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeHermes);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsHireTroops != #=z8StzeqE=.#=zaudlwXG$FEcN().IsHireTroops)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.HireTroops, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsHireTroops);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenClanReward != #=z8StzeqE=.#=zaudlwXG$FEcN().IsOpenClanReward)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.GrabGiftsAndRewards, TaskSeverities.Background, TimeSpan.FromHours(6.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenClanReward);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsReadAllMessages != #=z8StzeqE=.#=zaudlwXG$FEcN().IsReadAllMessages)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ReadAllMessages, TaskSeverities.Background, TimeSpan.FromHours(6.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsReadAllMessages);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCloseTournments != #=z8StzeqE=.#=zaudlwXG$FEcN().IsCloseTournments)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.CloseTournments, TaskSeverities.Background, TimeSpan.FromHours(6.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsCloseTournments);
		}
		if ((#=z8StzeqE=.#=zv2Kyu17YrGOC().IsResearchTechs || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeTechs) != (#=z8StzeqE=.#=zaudlwXG$FEcN().IsResearchTechs || #=z8StzeqE=.#=zaudlwXG$FEcN().IsUpgradeTechs))
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ResearchTechs, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsResearchTechs || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeTechs);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsExchangeTechsSchemas != #=z8StzeqE=.#=zaudlwXG$FEcN().IsExchangeTechsSchemas)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ExchangeTechSchemas, TaskSeverities.Background, TimeSpan.FromHours(12.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsExchangeTechsSchemas);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUseTechsSchemasStock != #=z8StzeqE=.#=zaudlwXG$FEcN().IsUseTechsSchemasStock)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.TechSchemasStockExchange, TaskSeverities.Background, TimeSpan.FromHours(3.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUseTechsSchemasStock);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaCapture != #=z8StzeqE=.#=zaudlwXG$FEcN().IsEmporiaCapture)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.EmporiaCapture, TaskSeverities.Background, TimeSpan.FromMinutes(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaCapture);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsPerformInitiation != #=z8StzeqE=.#=zaudlwXG$FEcN().IsPerformInitiation)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.Initiation, TaskSeverities.Background, TimeSpan.FromSeconds(15.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsPerformInitiation);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeNanos != #=z8StzeqE=.#=zaudlwXG$FEcN().IsUpgradeNanos)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.UpgradeNanos, TaskSeverities.Background, TimeSpan.FromHours(1.111), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeNanos);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonRefresh != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDragonRefresh)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.DragonRefresh, TaskSeverities.Background, TimeSpan.FromHours(3.02), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonRefresh);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonActivate != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDragonActivate)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.DragonActivate, TaskSeverities.Background, TimeSpan.FromHours(1.01), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonActivate);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonUpgrade != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDragonUpgrade)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.DragonUpgrade, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDragonUpgrade);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoAutoRobbery != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoAutoRobbery)
		{
			if (#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod == TimeSpan.Zero)
			{
				#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod = TimeSpan.FromHours(24.0);
				#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
			}
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.AutoRobberyStart, TaskSeverities.Background, #=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobberyPeriod, #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoAutoRobbery);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoResourceExchange != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoResourceExchange)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ExchangeResources, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoResourceExchange);
		}
		if ((#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgrade || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsTower) != (#=z8StzeqE=.#=zaudlwXG$FEcN().IsDoGeneralsUpgrade || #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoGeneralsTower) || #=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsUpgradePeriodMin != #=z8StzeqE=.#=zaudlwXG$FEcN().GeneralsUpgradePeriodMin)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.UpgradeGenerals, TaskSeverities.Background, TimeSpan.FromMinutes(#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsUpgradePeriodMin), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgrade || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsTower, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerCheckPeriod != #=z8StzeqE=.#=zaudlwXG$FEcN().GeneralsTowerCheckPeriod)
		{
			#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck = DateTime.MinValue;
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoOccupationBreak != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoOccupationBreak)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.OccupationBreak, TaskSeverities.Background, TimeSpan.FromMinutes(15.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoOccupationBreak);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsResurrectTroopsFree != #=z8StzeqE=.#=zaudlwXG$FEcN().IsResurrectTroopsFree || #=z8StzeqE=.#=zv2Kyu17YrGOC().ResurrectTroopsFreeIntervalHours != #=z8StzeqE=.#=zaudlwXG$FEcN().ResurrectTroopsFreeIntervalHours)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ResurrectAfterMassacre, TaskSeverities.Background, TimeSpan.FromHours(#=z8StzeqE=.#=zv2Kyu17YrGOC().ResurrectTroopsFreeIntervalHours), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsResurrectTroopsFree, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBlackMarketBuyResources != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoBlackMarketBuyResources)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.BuyBlackMarketResources, TaskSeverities.Background, TimeSpan.FromHours(22.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBlackMarketBuyResources);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoMutateTroops != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoMutateTroops || #=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsPeriodMin != #=z8StzeqE=.#=zaudlwXG$FEcN().MutateTroopsPeriodMin)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.MutateTroops, TaskSeverities.Background, TimeSpan.FromMinutes(#=z8StzeqE=.#=zv2Kyu17YrGOC().MutateTroopsPeriodMin), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoMutateTroops, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProcessWarlordItems != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoProcessWarlordItems)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.InventoryItems, TaskSeverities.Background, TimeSpan.FromMinutes(61.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProcessWarlordItems, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProcessArtifacts != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoProcessArtifacts)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.Artifacts, TaskSeverities.Background, TimeSpan.FromHours(6.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoProcessArtifacts, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoUpgradeTroops != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoUpgradeTroops)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.UpgradeTroops, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoUpgradeTroops, true);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroops != #=z8StzeqE=.#=zaudlwXG$FEcN().IsVeorHireTroops)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.VeorHireTroops, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroops);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorCollectLocaBonuses != #=z8StzeqE=.#=zaudlwXG$FEcN().IsVeorCollectLocaBonuses)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.VeorCollectLocaBonus, TaskSeverities.Background, TimeSpan.FromMinutes(10.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorCollectLocaBonuses);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding != #=z8StzeqE=.#=zaudlwXG$FEcN().IsCreateRequestAllianceHelpBuilding)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ProcessAllianceHelpRequests, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBlackMarketRunContBoosts != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDoBlackMarketRunContBoosts)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.RunContiniousBoosts, TaskSeverities.Background, TimeSpan.FromMinutes(60.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBlackMarketRunContBoosts);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyInAllianceShop != #=z8StzeqE=.#=zaudlwXG$FEcN().IsBuyInAllianceShop)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.BuyInCoalitionShop, TaskSeverities.Background, TimeSpan.FromHours(12.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyInAllianceShop);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsProcessGems != #=z8StzeqE=.#=zaudlwXG$FEcN().IsProcessGems)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ProcessGems, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsProcessGems);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsStrongholdProcess != #=z8StzeqE=.#=zaudlwXG$FEcN().IsStrongholdProcess)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.ProcessStronghold, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsStrongholdProcess);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsPlayDiceGame != #=z8StzeqE=.#=zaudlwXG$FEcN().IsPlayDiceGame)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.DiceEvent, TaskSeverities.Background, TimeSpan.FromHours(2.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsPlayDiceGame);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDispermitSpam != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDispermitSpam || #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDispermitAllianceSpam != #=z8StzeqE=.#=zaudlwXG$FEcN().IsDispermitAllianceSpam)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=z4r1Y$wYr4xSL(#=z8StzeqE=);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRunBingoEvent != #=z8StzeqE=.#=zaudlwXG$FEcN().IsRunBingoEvent)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.BingoEvent, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsRunBingoEvent);
		}
		if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendBeaconsHourly != #=z8StzeqE=.#=zaudlwXG$FEcN().IsSendBeaconsHourly)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, TaskTypes.SendAllianceBeacons, TaskSeverities.Background, TimeSpan.FromHours(1.0), #=z8StzeqE=.#=zv2Kyu17YrGOC().IsSendBeaconsHourly);
		}
		#=z8StzeqE=.#=zddKXe6nWZmil();
		#=z8StzeqE=.#=z_5FJXkan3koNCP1yRA==(DateTime.Now);
	}

	// Token: 0x06000DD2 RID: 3538 RVA: 0x0006D750 File Offset: 0x0006B950
	public bool #=zX2uRTSgMM0AC(int #=zbuCVyJk=)
	{
		bool result = false;
		bool flag = false;
		for (int i = 0; i < this.#=zgIqT5PY=.Count; i++)
		{
			if (this.#=zgIqT5PY=[i].#=zv2Kyu17YrGOC().IsNeedsSynchronization)
			{
				if (i == #=zbuCVyJk=)
				{
					result = true;
				}
				this.#=zt8qXnD$LK2FE(i);
				this.#=zgIqT5PY=[i].#=zv2Kyu17YrGOC().IsNeedsSynchronization = false;
				flag = true;
			}
		}
		if (flag)
		{
			this.#=zPLWPn_Vlu7rO();
		}
		if (this.#=zv_V_Yw63ia3c.IsNeedToSave)
		{
			this.#=zv_V_Yw63ia3c.IsNeedToSave = false;
			this.#=zybD3gyKTiw1w();
		}
		return result;
	}

	// Token: 0x06000DD3 RID: 3539 RVA: 0x0006D7E0 File Offset: 0x0006B9E0
	public void #=zjCV8P$Sfoe1z()
	{
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zgIqT5PY=)
		{
			if (!#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsAutoBackgroundOn && DateTime.Now - #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zxF$r5QndSVMh6QFdUw==() > TimeSpan.FromHours(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoBackgroundOnHours))
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zpAIjRlo0AKmKYNY3$g==(DateTime.Now);
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943745), Array.Empty<object>());
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = true;
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
			}
		}
	}

	// Token: 0x06000DD4 RID: 3540 RVA: 0x0006D8B4 File Offset: 0x0006BAB4
	private void #=zxzM$S$$Tasyo()
	{
		#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=z47HdmrEE_7KL = ProxyInfo.#=zn2ovxJQcP5BV();
		string text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943443), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
		if (!#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=ztdSgtRqjR6O2(#=z47HdmrEE_7KL, text) && !#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=ztdSgtRqjR6O2(#=z47HdmrEE_7KL, text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064859)))
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=ztdSgtRqjR6O2(#=z47HdmrEE_7KL, text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064854));
		}
	}

	// Token: 0x06000DD5 RID: 3541 RVA: 0x0006D914 File Offset: 0x0006BB14
	private static bool #=ztdSgtRqjR6O2(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=z47HdmrEE_7KL, string #=z0HqaquI=)
	{
		return #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0HqaquI=) && #=z47HdmrEE_7KL.#=z7YhN0h3LM3Il(#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0HqaquI=));
	}

	// Token: 0x06000DD6 RID: 3542 RVA: 0x0006D92C File Offset: 0x0006BB2C
	public void #=zmj_BPos=(string #=zelsO$ToBQhBgEInwqw==, ProxyFormats #=z7gOpVK0=, bool #=zD1JRGxwL9ZCt)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zm76lEb0vZHhP(#=zelsO$ToBQhBgEInwqw==, #=z7gOpVK0=, ProxyInfo.#=zn2ovxJQcP5BV(), #=zD1JRGxwL9ZCt);
		this.#=zvWto7jWOQvFn();
	}

	// Token: 0x06000DD7 RID: 3543 RVA: 0x0006D944 File Offset: 0x0006BB44
	private static void #=zm76lEb0vZHhP(string #=zelsO$ToBQhBgEInwqw==, ProxyFormats #=z7gOpVK0=, #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=z47HdmrEE_7KL, bool #=zD1JRGxwL9ZCt)
	{
		if (string.IsNullOrWhiteSpace(#=zelsO$ToBQhBgEInwqw==))
		{
			return;
		}
		ProxyTypes defaultProxyType = ProxyTypes.Static;
		object obj = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zvTOPl_zmYOP7;
		lock (obj)
		{
			string[] array = #=zelsO$ToBQhBgEInwqw==.Split(new char[]
			{
				'\r',
				'\n'
			}, StringSplitOptions.RemoveEmptyEntries);
			List<ProxyInfo> list = new List<ProxyInfo>();
			for (int i = 0; i < array.Length; i++)
			{
				ProxyInfo fromString = ProxyInfo.GetFromString(array[i], #=z7gOpVK0=, defaultProxyType);
				if (fromString != null)
				{
					if (#=zD1JRGxwL9ZCt && (fromString.Type == ProxyTypes.DynamicManual || fromString.Type == ProxyTypes.DynamicAuto))
					{
						fromString.State = ProxyStates.Unchecked;
					}
					list.Add(fromString);
				}
			}
			if (list.Count == 0)
			{
				foreach (object obj2 in Regex.Matches(#=zelsO$ToBQhBgEInwqw==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051189)))
				{
					MatchCollection matchCollection = Regex.Matches(((Match)obj2).Value, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051383));
					if (matchCollection.Count == 5)
					{
						bool flag2 = true;
						string[] array2 = new string[4];
						for (int j = 0; j < 4; j++)
						{
							int num;
							if (!int.TryParse(matchCollection[j].Value, out num))
							{
								flag2 = false;
							}
							if (num < 0 || num > 255)
							{
								flag2 = false;
							}
							array2[j] = num.ToString();
						}
						string ip = string.Join(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067993), array2);
						int num2;
						if (!int.TryParse(matchCollection[4].Value, out num2))
						{
							flag2 = false;
						}
						if (num2 <= 0 || num2 >= 65536)
						{
							flag2 = false;
						}
						if (flag2)
						{
							ProxyInfo proxyInfo = new ProxyInfo(ProxyTypes.DynamicManual, ip, num2);
							if (#=zD1JRGxwL9ZCt)
							{
								proxyInfo.State = ProxyStates.Unchecked;
							}
							list.Add(proxyInfo);
						}
					}
				}
			}
			for (int k = 0; k < list.Count; k++)
			{
				ProxyInfo proxyInfo2 = list[k];
				bool flag3 = false;
				for (int l = 0; l < #=z47HdmrEE_7KL.Count; l++)
				{
					if (#=z47HdmrEE_7KL[l].ProxyKey == proxyInfo2.ProxyKey)
					{
						if (#=z47HdmrEE_7KL[l].State != ProxyStates.Ok)
						{
							if (#=zD1JRGxwL9ZCt)
							{
								#=z47HdmrEE_7KL[l].State = ProxyStates.Unchecked;
							}
							else
							{
								#=z47HdmrEE_7KL[l].State = ProxyStates.Ok;
							}
						}
						flag3 = true;
						break;
					}
				}
				if (!flag3)
				{
					#=z47HdmrEE_7KL.#=z48rEd0A=(proxyInfo2);
				}
			}
		}
		if (#=zD1JRGxwL9ZCt)
		{
			#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=zoR8PNRNYefFV(#=z47HdmrEE_7KL);
		}
	}

	// Token: 0x06000DD8 RID: 3544 RVA: 0x0006DBD4 File Offset: 0x0006BDD4
	public void #=zvWto7jWOQvFn()
	{
		new Thread(new ThreadStart(this.#=zcp3lDCX6tX2r)).Start();
	}

	// Token: 0x06000DD9 RID: 3545 RVA: 0x0006DBEC File Offset: 0x0006BDEC
	private void #=zcp3lDCX6tX2r()
	{
		try
		{
			object obj = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zvTOPl_zmYOP7;
			lock (obj)
			{
				#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943443), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==()), ProxyInfo.#=zn2ovxJQcP5BV().#=zhv7OhlM=(), null, true);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
		}
	}

	// Token: 0x06000DDA RID: 3546 RVA: 0x0006DC6C File Offset: 0x0006BE6C
	private static void #=zz0X2vagK8cE7(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, TaskTypes #=zmV6257E=, TaskSeverities #=z_qaYpFQ=, TimeSpan #=znDUPTRWa892r, bool #=zEkaTxzY=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zz0X2vagK8cE7(#=z8StzeqE=, #=zmV6257E=, #=z_qaYpFQ=, #=znDUPTRWa892r, #=zEkaTxzY=, false);
	}

	// Token: 0x06000DDB RID: 3547 RVA: 0x0006DC7C File Offset: 0x0006BE7C
	private static void #=zz0X2vagK8cE7(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, TaskTypes #=zmV6257E=, TaskSeverities #=z_qaYpFQ=, TimeSpan #=znDUPTRWa892r, bool #=zEkaTxzY=, bool #=zOXY8bKOFHdiK)
	{
		object #=zBCxv0_Eazs = #=z8StzeqE=.#=zGQl3yUpez1XJ().#=zBCxv0_Eazs01;
		lock (#=zBCxv0_Eazs)
		{
			Task task = #=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(#=zmV6257E=);
			if (task == null)
			{
				task = #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zEh7CJ2RYceMs(#=zmV6257E=);
			}
			if (#=zEkaTxzY=)
			{
				if (task != null)
				{
					if (!#=zOXY8bKOFHdiK)
					{
						if (task.State == TaskStates.Cancelled || task.State == TaskStates.Complete)
						{
							task.State = TaskStates.Pending;
						}
					}
					else
					{
						task.State = TaskStates.Cancelled;
						foreach (Task task2 in #=z8StzeqE=.#=zGQl3yUpez1XJ())
						{
							if (task2.Type == #=zmV6257E=)
							{
								task2.State = TaskStates.Cancelled;
							}
						}
						foreach (Task task3 in #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==())
						{
							if (task3.Type == #=zmV6257E=)
							{
								task3.State = TaskStates.Cancelled;
							}
						}
						Task #=zcTyyNys= = Task.CreateSettings(#=zmV6257E=, #=z_qaYpFQ=, #=znDUPTRWa892r);
						#=z8StzeqE=.#=zeR3QFrc=(#=zcTyyNys=);
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=z8StzeqE=);
					}
				}
				else
				{
					task = Task.CreateSettings(#=zmV6257E=, #=z_qaYpFQ=, #=znDUPTRWa892r);
					#=z8StzeqE=.#=zeR3QFrc=(task);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=z8StzeqE=);
				}
			}
			else if (task != null)
			{
				task.State = TaskStates.Cancelled;
				using (List<Task>.Enumerator enumerator = #=z8StzeqE=.#=zGQl3yUpez1XJ().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Type == #=zmV6257E=)
						{
							task.State = TaskStates.Cancelled;
						}
					}
				}
				using (List<Task>.Enumerator enumerator = #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.Type == #=zmV6257E=)
						{
							task.State = TaskStates.Cancelled;
						}
					}
				}
			}
		}
	}

	// Token: 0x06000DDC RID: 3548 RVA: 0x0006DEC0 File Offset: 0x0006C0C0
	public List<Task> #=zqDq5W5FyhwVzz7jt9w==(int #=zbuCVyJk=, string #=zyGIt9szGF5Jz6Bly_6OHRnA=, string #=zlkYdSY2v6pUx, string #=zPwJ1RjfyOatLPA4eJA==, string #=zqH8alISSEei9LamU5k8q8Hg=, double #=zsilaWAN$JOvI, DateTime #=z9iiP2tA=, bool #=zW2Lbhs0dcyHe3X8J7g==, out string #=zx9NCziM=)
	{
		return this.#=zqDq5W5FyhwVzz7jt9w==(#=zbuCVyJk=, #=zyGIt9szGF5Jz6Bly_6OHRnA=, #=zlkYdSY2v6pUx, #=zPwJ1RjfyOatLPA4eJA==, #=zqH8alISSEei9LamU5k8q8Hg=, #=zsilaWAN$JOvI, #=z9iiP2tA=, #=zW2Lbhs0dcyHe3X8J7g==, out #=zx9NCziM=, false);
	}

	// Token: 0x06000DDD RID: 3549 RVA: 0x0006DEE4 File Offset: 0x0006C0E4
	private List<Task> #=zqDq5W5FyhwVzz7jt9w==(int #=zbuCVyJk=, string #=zyGIt9szGF5Jz6Bly_6OHRnA=, string #=zlkYdSY2v6pUx, string #=zPwJ1RjfyOatLPA4eJA==, string #=zqH8alISSEei9LamU5k8q8Hg=, double #=zsilaWAN$JOvI, DateTime #=z9iiP2tA=, bool #=zW2Lbhs0dcyHe3X8J7g==, out string #=zx9NCziM=, bool #=zOHpNIo3l68usnRl2IA==)
	{
		List<Task> list = new List<Task>();
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zgIqT5PY=[#=zbuCVyJk=];
		int num = 0;
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = null;
		try
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zXTTYoqGLxWmVM2mBWQ==(#=zyGIt9szGF5Jz6Bly_6OHRnA=, null)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088037));
			if (array != null)
			{
				foreach (Dictionary<string, object> dictionary in array)
				{
					string text = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)].ToString();
					if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)))
					{
						Dictionary<string, object> dictionary2 = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] as Dictionary<string, object>;
						int num2 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]);
						int num3 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]);
						string text2;
						bool #=z$Ib9gYQ=;
						if (text == #=zlkYdSY2v6pUx)
						{
							text2 = #=zPwJ1RjfyOatLPA4eJA==;
							#=z$Ib9gYQ= = #=zW2Lbhs0dcyHe3X8J7g==;
						}
						else
						{
							text2 = #=zqH8alISSEei9LamU5k8q8Hg=;
							#=z$Ib9gYQ= = true;
						}
						DateTime dateTime = #=z9iiP2tA= - #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zWRWylcMEygXu((double)#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), (double)#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==(), (double)num2, (double)num3, #=zsilaWAN$JOvI);
						if (dateTime < DateTime.Now)
						{
							num++;
						}
						string arg = UnitSquadCollection.TranslateUnitsString(text2);
						#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSeverities.Urgent, dateTime, TimeSpan.FromMinutes(10.0), TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false, TaskSendUnitTypes.Robbery, text, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943416), num2, num3, arg), text2, 0, 0);
						#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==.#=zDQLgsk65lVyJSMVPHQ==(#=z$Ib9gYQ=);
						list.Add(#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==);
					}
				}
			}
		}
		catch (Exception ex)
		{
			if (!#=zOHpNIo3l68usnRl2IA==)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
				return this.#=zqDq5W5FyhwVzz7jt9w==(#=zbuCVyJk=, #=zyGIt9szGF5Jz6Bly_6OHRnA=, #=zlkYdSY2v6pUx, #=zPwJ1RjfyOatLPA4eJA==, #=zqH8alISSEei9LamU5k8q8Hg=, #=zsilaWAN$JOvI, #=z9iiP2tA=, #=zW2Lbhs0dcyHe3X8J7g==, out #=zx9NCziM=, true);
			}
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), ex);
			#=zx9NCziM= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104554), new object[]
			{
				ex.Message
			}).ToString();
			return new List<Task>();
		}
		if (num > 0)
		{
			#=zx9NCziM= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943405), new object[]
			{
				num
			}).ToString();
		}
		else
		{
			#=zx9NCziM= = null;
		}
		return list;
	}

	// Token: 0x06000DDE RID: 3550 RVA: 0x0006E150 File Offset: 0x0006C350
	public void #=zABGh8yfTreQZ(int #=zbuCVyJk=, List<Task> #=zgV3wa0k=)
	{
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zgIqT5PY=[#=zbuCVyJk=];
		try
		{
			for (int i = 0; i < #=zgV3wa0k=.Count; i++)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(#=zgV3wa0k=[i]);
			}
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
		}
	}

	// Token: 0x06000DDF RID: 3551 RVA: 0x0006E1B0 File Offset: 0x0006C3B0
	public static void #=zqGxyYdiygKCr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		if (Monitor.TryEnter(#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zBCxv0_Eazs01))
		{
			try
			{
				#=z8StzeqE=.#=zGQl3yUpez1XJ().Sort();
				#=z8StzeqE=.#=z_5FJXkan3koNCP1yRA==(DateTime.MaxValue);
				if (#=z8StzeqE=.#=z5CQ3MMGT7KZ6NzsrOA==() == DateTime.MaxValue && #=z8StzeqE=.#=zGQl3yUpez1XJ().Count > 0)
				{
					#=z8StzeqE=.#=z_5FJXkan3koNCP1yRA==(#=z8StzeqE=.#=zGQl3yUpez1XJ()[0].ExecutionTime);
				}
			}
			finally
			{
				Monitor.Exit(#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zBCxv0_Eazs01);
			}
		}
		if (Monitor.TryEnter(#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zBCxv0_Eazs01))
		{
			try
			{
				#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Sort();
				#=z8StzeqE=.#=zbdyC5WKGPSBd2ERB$laIbwI=(DateTime.MaxValue);
				if (#=z8StzeqE=.#=zXhmu8wtI1QFueNwTW0lbj2Q=() == DateTime.MaxValue && #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().Count > 0)
				{
					#=z8StzeqE=.#=zbdyC5WKGPSBd2ERB$laIbwI=(#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==()[0].ExecutionTime);
				}
			}
			finally
			{
				Monitor.Exit(#=z8StzeqE=.#=zzia5edbZiDd_52XM1A==().#=zBCxv0_Eazs01);
			}
		}
	}

	// Token: 0x06000DE0 RID: 3552 RVA: 0x0006E2C4 File Offset: 0x0006C4C4
	public static void #=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=z8StzeqE=);
		#=z8StzeqE=.#=zfHO$ZGpgI$6H5Ku14A==(DateTime.Now);
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943507), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), JSONManager.FixStringForFileName(#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()), #=z8StzeqE=.#=zYgvZuBwR$a1C());
		#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z23sS9NhIcGaTj3irAlB1lVH1yUQC = new #=z23sS9NhIcGaTj3irAlB1lVH1yUQC(false);
		foreach (Task task in #=z8StzeqE=.#=zGQl3yUpez1XJ())
		{
			if (task.Source == TaskSources.Manual)
			{
				#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.Add(task);
			}
		}
		foreach (Task task2 in #=z8StzeqE=.#=zzia5edbZiDd_52XM1A==())
		{
			if (task2.Source == TaskSources.Manual)
			{
				#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.Add(task2);
			}
		}
		if (#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.Count > 0)
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, #=z23sS9NhIcGaTj3irAlB1lVH1yUQC.#=zhv7OhlM=(), Encoding.UTF8, false);
			return;
		}
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(#=z0ONi4Bk=);
		}
	}

	// Token: 0x06000DE1 RID: 3553 RVA: 0x0006E3E0 File Offset: 0x0006C5E0
	public MasterTask #=zXqyemJ7PVoRw(Task #=zcTyyNys=)
	{
		MasterTask masterTask = new MasterTask(#=zcTyyNys=, this.#=zv_V_Yw63ia3c);
		this.#=zv_V_Yw63ia3c.Add(masterTask);
		this.#=zv_V_Yw63ia3c.IsNeedToSave = true;
		return masterTask;
	}

	// Token: 0x06000DE2 RID: 3554 RVA: 0x0006E414 File Offset: 0x0006C614
	public void #=zybD3gyKTiw1w()
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943507), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945264), 0);
		List<Guid> list = new List<Guid>();
		for (int i = 0; i < this.#=zgIqT5PY=.Count; i++)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zgIqT5PY=[i];
			for (int j = 0; j < #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ().Count; j++)
			{
				Task task = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ()[j];
				if (task.Id != Guid.Empty && !list.Contains(task.Id))
				{
					list.Add(task.Id);
				}
			}
			for (int k = 0; k < #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().Count; k++)
			{
				Task task2 = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==()[k];
				if (task2.Id != Guid.Empty && !list.Contains(task2.Id))
				{
					list.Add(task2.Id);
				}
			}
		}
		for (int l = this.#=zv_V_Yw63ia3c.Count - 1; l >= 0; l--)
		{
			if (!list.Contains(this.#=zv_V_Yw63ia3c[l].Task.Id))
			{
				this.#=zv_V_Yw63ia3c.RemoveAt(l);
			}
		}
		if (this.#=zv_V_Yw63ia3c.Count > 0)
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, this.#=zv_V_Yw63ia3c.Serialize(), Encoding.UTF8, false);
			return;
		}
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(#=z0ONi4Bk=);
		}
	}

	// Token: 0x06000DE3 RID: 3555 RVA: 0x0006E5A0 File Offset: 0x0006C7A0
	private static MasterTaskCollection #=z330rKfPtihFX()
	{
		int num = 0;
		MasterTaskCollection result;
		try
		{
			MasterTaskCollection masterTaskCollection = new MasterTaskCollection();
			string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943507), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945264), num);
			if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
			{
				foreach (Task task in Task.#=zK9Qp$Yg7wkwd(null, #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=), null))
				{
					masterTaskCollection.Add(task);
				}
			}
			result = masterTaskCollection;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			throw;
		}
		return result;
	}

	// Token: 0x06000DE4 RID: 3556 RVA: 0x0006E64C File Offset: 0x0006C84C
	private static void #=zbNwdgEO3SWKr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, MasterTaskCollection #=ztLhClwt0HyEZ)
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943507), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), JSONManager.FixStringForFileName(#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()), #=z8StzeqE=.#=zYgvZuBwR$a1C());
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			try
			{
				foreach (Task #=zcTyyNys= in Task.#=zK9Qp$Yg7wkwd(#=z8StzeqE=, #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=), #=ztLhClwt0HyEZ))
				{
					#=z8StzeqE=.#=zeR3QFrc=(#=zcTyyNys=);
				}
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=z8StzeqE=);
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			}
		}
	}

	// Token: 0x06000DE5 RID: 3557 RVA: 0x0006E704 File Offset: 0x0006C904
	public static void #=zGncKSH4oJhxW9OLT6A==(#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zQZM1ujZRAuHk, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945257), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), JSONManager.FixStringForFileName(#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()), #=z8StzeqE=.#=zYgvZuBwR$a1C());
		string text = #=zQZM1ujZRAuHk.ToString();
		if (!string.IsNullOrEmpty(text))
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, text, Encoding.UTF8, false);
			return;
		}
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zorxJD84=(#=z0ONi4Bk=);
		}
	}

	// Token: 0x06000DE6 RID: 3558 RVA: 0x0006E76C File Offset: 0x0006C96C
	public static #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zGV9CLmCENINvspF3MQ==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945257), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), JSONManager.FixStringForFileName(#=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()), #=z8StzeqE=.#=zYgvZuBwR$a1C());
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			try
			{
				string #=zXvnc_Gc= = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=);
				return new #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945219), #=zXvnc_Gc=, #=z8StzeqE=, #=zSJY$s3o=);
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				return new #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945219));
			}
		}
		return new #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945219));
	}

	// Token: 0x06000DE7 RID: 3559 RVA: 0x0006E810 File Offset: 0x0006CA10
	public static #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zk55d778IdJE5fRurDw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zhfS69jI=, int #=zmWD8vxE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		if (#=zSJY$s3o= != null && #=zSJY$s3o=.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
		{
			return null;
		}
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zLr18QKpzilxyiDNuaw==(#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, false);
		if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== != null && #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== as #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
			if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==() > 0)
			{
				if (#=zSJY$s3o= == null)
				{
					#=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
				}
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zmLrGNVIgSMUH8cG0eyaa7PQ=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==, #=z8StzeqE=, #=zSJY$s3o=);
			}
			return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
		}
		return null;
	}

	// Token: 0x06000DE8 RID: 3560 RVA: 0x0006E86C File Offset: 0x0006CA6C
	public static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zLr18QKpzilxyiDNuaw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zhfS69jI=, int #=zmWD8vxE=, bool #=zXax54lzEowMN)
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zLr18QKpzilxyiDNuaw==(#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, #=zXax54lzEowMN, false);
	}

	// Token: 0x06000DE9 RID: 3561 RVA: 0x0006E878 File Offset: 0x0006CA78
	private static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zLr18QKpzilxyiDNuaw==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zhfS69jI=, int #=zmWD8vxE=, bool #=zXax54lzEowMN, bool #=zOHpNIo3l68usnRl2IA==)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = null;
		try
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
			if (!#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zq76JuU9WPIZn())
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
			}
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetData(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zpeSgyDU=(#=zhfS69jI=, #=zmWD8vxE=));
			foreach (Dictionary<string, object> dictionary2 in (object[])dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)])
			{
				Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
				if (JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0) == #=zhfS69jI= && JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0) == #=zmWD8vxE=)
				{
					#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk6dzl0XBwulh(dictionary2, #=z8StzeqE=);
					if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)
					{
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zGq68XSs=(#=z8StzeqE=.#=zYgvZuBwR$a1C(), (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==);
					}
					else
					{
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==);
					}
					return #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==;
				}
			}
			foreach (Dictionary<string, object> dictionary4 in (object[])dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)])
			{
				Dictionary<string, object> dictionary5 = JSONManager.ExtractDictionary(dictionary4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
				if (JSONManager.ExtractInt(dictionary5, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0) == #=zhfS69jI= && JSONManager.ExtractInt(dictionary5, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0) == #=zmWD8vxE=)
				{
					#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk6dzl0XBwulh(dictionary4, #=z8StzeqE=);
					if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2 is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)
					{
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zGq68XSs=(#=z8StzeqE=.#=zYgvZuBwR$a1C(), (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2);
					}
					else
					{
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2);
					}
					return #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2;
				}
			}
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), out flag);
			if (flag && #=zXax54lzEowMN && !#=zOHpNIo3l68usnRl2IA==)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
				return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zLr18QKpzilxyiDNuaw==(#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, #=zXax54lzEowMN, true);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
		return null;
	}

	// Token: 0x06000DEA RID: 3562 RVA: 0x0006EA88 File Offset: 0x0006CC88
	public static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zPW_gLmTtgAuduiPegg==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=z1lwIce2YhvXU)
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zPW_gLmTtgAuduiPegg==(#=z8StzeqE=, #=z1lwIce2YhvXU, false);
	}

	// Token: 0x06000DEB RID: 3563 RVA: 0x0006EA94 File Offset: 0x0006CC94
	private static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zPW_gLmTtgAuduiPegg==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=z1lwIce2YhvXU, bool #=zOHpNIo3l68usnRl2IA==)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = null;
		try
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
			if (!#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zq76JuU9WPIZn())
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
			}
			object data = JSONManager.GetData(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zUqoz8aR4mJrU(#=z1lwIce2YhvXU));
			return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zLr18QKpzilxyiDNuaw==(#=z8StzeqE=, JSONManager.GetInt(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0), JSONManager.GetInt(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0), true);
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), out flag);
			if (flag && !#=zOHpNIo3l68usnRl2IA==)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH();
				return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zPW_gLmTtgAuduiPegg==(#=z8StzeqE=, #=z1lwIce2YhvXU, true);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
		return null;
	}

	// Token: 0x06000DEC RID: 3564 RVA: 0x0006EB54 File Offset: 0x0006CD54
	public static #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zzPn$273mIKsu(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, string #=zvPiOyGQ=, bool #=zXax54lzEowMN, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=z8StzeqE=, #=zvPiOyGQ=, #=zXax54lzEowMN, #=zSJY$s3o=, false);
	}

	// Token: 0x06000DED RID: 3565 RVA: 0x0006EB60 File Offset: 0x0006CD60
	private static #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zzPn$273mIKsu(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, string #=zvPiOyGQ=, bool #=zXax54lzEowMN, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, bool #=zOHpNIo3l68usnRl2IA==)
	{
		if (#=zSJY$s3o= != null && #=zSJY$s3o=.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
		{
			return null;
		}
		try
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zEwTYXjk=(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zvPiOyGQ=);
			if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null)
			{
				return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
			}
			if (#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString() == #=zvPiOyGQ=)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zGq68XSs=(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=z8StzeqE=.#=zjV_wsuvJ0R_B());
				return #=z8StzeqE=.#=zjV_wsuvJ0R_B();
			}
			if (#=zSJY$s3o= == null)
			{
				#=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
			}
			if (!#=zSJY$s3o=.#=zq76JuU9WPIZn())
			{
				#=zSJY$s3o=.#=zuq1FOz8SJbyH();
			}
			foreach (Dictionary<string, object> dictionary in (object[])((Dictionary<string, object>)JSONManager.GetData(#=zSJY$s3o=.#=z$F1M_0mTucCE(#=zvPiOyGQ=)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976)])
			{
				if (dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)].ToString() == #=zvPiOyGQ=)
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zT$2iWxnv3qme(dictionary);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zmLrGNVIgSMUH8cG0eyaa7PQ=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2, #=z8StzeqE=, #=zSJY$s3o=);
					#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zGq68XSs=(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2);
					return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2;
				}
			}
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=zSJY$s3o=.#=zI4J7zo5ZdOzg(), out flag);
			if (flag && #=zXax54lzEowMN && !#=zOHpNIo3l68usnRl2IA==)
			{
				if (#=zSJY$s3o= == null)
				{
					#=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
				}
				#=zSJY$s3o=.#=zuq1FOz8SJbyH();
				return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=z8StzeqE=, #=zvPiOyGQ=, #=zXax54lzEowMN, #=zSJY$s3o=, true);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
		return null;
	}

	// Token: 0x06000DEE RID: 3566 RVA: 0x0006ECDC File Offset: 0x0006CEDC
	public static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zUCIeSv7ynlYy(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=z_g1gFFM=, bool #=zXax54lzEowMN, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> dictionary = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zH9Mroh$wsz82(#=z8StzeqE=, new List<int>
		{
			#=z_g1gFFM=
		}, #=zXax54lzEowMN, #=zSJY$s3o=, false);
		if (!dictionary.ContainsKey(#=z_g1gFFM=))
		{
			return null;
		}
		return dictionary[#=z_g1gFFM=];
	}

	// Token: 0x06000DEF RID: 3567 RVA: 0x0006ED14 File Offset: 0x0006CF14
	public static Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> #=zH9Mroh$wsz82(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, List<int> #=zJzTZmRk6sU2i, bool #=zXax54lzEowMN, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zH9Mroh$wsz82(#=z8StzeqE=, #=zJzTZmRk6sU2i, #=zXax54lzEowMN, #=zSJY$s3o=, false);
	}

	// Token: 0x06000DF0 RID: 3568 RVA: 0x0006ED20 File Offset: 0x0006CF20
	private static Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> #=zH9Mroh$wsz82(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, List<int> #=zJzTZmRk6sU2i, bool #=zXax54lzEowMN, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, bool #=zOHpNIo3l68usnRl2IA==)
	{
		Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> dictionary = new Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==>();
		if (#=zSJY$s3o= != null && #=zSJY$s3o=.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
		{
			return dictionary;
		}
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		for (int i = 0; i < #=zJzTZmRk6sU2i.Count; i++)
		{
			int num = #=zJzTZmRk6sU2i[i];
			#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zoMNV7yzvZ8th(#=z8StzeqE=.#=zYgvZuBwR$a1C(), num.ToString());
			if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== != null)
			{
				dictionary[num] = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==;
			}
			else if (#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() == num)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=z8StzeqE=.#=zjV_wsuvJ0R_B());
				dictionary[num] = #=z8StzeqE=.#=zjV_wsuvJ0R_B();
			}
			else if (num > 0)
			{
				list.Add(num);
			}
			else
			{
				list2.Add(-num);
			}
		}
		try
		{
			if (#=zSJY$s3o= == null)
			{
				#=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
			}
			if (!#=zSJY$s3o=.#=zq76JuU9WPIZn())
			{
				#=zSJY$s3o=.#=zuq1FOz8SJbyH();
			}
			if (list.Count > 0)
			{
				object[] array = (object[])((Dictionary<string, object>)JSONManager.GetData(#=zSJY$s3o=.#=z$F1M_0mTucCE(list)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976)];
				for (int j = 0; j < array.Length; j++)
				{
					#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk6dzl0XBwulh((Dictionary<string, object>)array[j], #=z8StzeqE=);
					#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2);
					dictionary[#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2.#=zMuFMjGQ=()] = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2;
				}
			}
			if (list2.Count > 0)
			{
				object[] array = (object[])JSONManager.GetData(#=zSJY$s3o=.#=z$V2EKEDsMxpw(list2));
				for (int j = 0; j < array.Length; j++)
				{
					#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==3 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk6dzl0XBwulh((Dictionary<string, object>)array[j], #=z8StzeqE=);
					#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==3);
					dictionary[-#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==3.#=zMuFMjGQ=()] = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==3;
				}
			}
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=zSJY$s3o=.#=zI4J7zo5ZdOzg(), out flag);
			if (flag && #=zXax54lzEowMN && !#=zOHpNIo3l68usnRl2IA==)
			{
				if (#=zSJY$s3o= == null)
				{
					#=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=);
				}
				#=zSJY$s3o=.#=zuq1FOz8SJbyH();
				return #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zH9Mroh$wsz82(#=z8StzeqE=, #=zJzTZmRk6sU2i, #=zXax54lzEowMN, #=zSJY$s3o=, true);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
		for (int k = 0; k < #=zJzTZmRk6sU2i.Count; k++)
		{
			int num2 = #=zJzTZmRk6sU2i[k];
			if (!dictionary.ContainsKey(num2))
			{
				#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==4 = new #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==(num2, null, null);
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zBDC6HVnfSGIL(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==4);
				dictionary[num2] = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==4;
			}
		}
		return dictionary;
	}

	// Token: 0x06000DF1 RID: 3569 RVA: 0x0006EF7C File Offset: 0x0006D17C
	private static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zk6dzl0XBwulh(Dictionary<string, object> #=zJdyVF9A=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		if (#=zJdyVF9A=.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)))
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zT$2iWxnv3qme(#=zJdyVF9A=);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zmLrGNVIgSMUH8cG0eyaa7PQ=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==, #=z8StzeqE=, new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=));
			return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
		}
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = new #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==();
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zbsxKkj4=(JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
		if (dictionary != null)
		{
			#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zHD9M6IxBLboIezSsHQ==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
			#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
		}
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zwXKUV2c=(JSONManager.ExtractString(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945215), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zfTB62qendhk_VEy8rw==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zY0soxphmGIACbOHy6A==())));
		Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
		if (dictionary2 != null)
		{
			#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zFzGvi_S6jJhE(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		}
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zCLd1HbpOa6Pc(JSONManager.ExtractDate(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false));
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zniBL6E3VL6qZBQF9fw==(JSONManager.GetInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945186), 0) > 0);
		#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zW2Vlp5vytS40(JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), 0));
		return #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==;
	}

	// Token: 0x06000DF2 RID: 3570 RVA: 0x0006F0C0 File Offset: 0x0006D2C0
	public static #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zT$2iWxnv3qme(Dictionary<string, object> #=zJdyVF9A=)
	{
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = new #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==();
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zbsxKkj4=(JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zgZ2Z53kGvTF4(JSONManager.ExtractString(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), string.Empty));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
		if (dictionary != null)
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zHD9M6IxBLboIezSsHQ==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zwXKUV2c=(JSONManager.ExtractString(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945176), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zfTB62qendhk_VEy8rw==(), #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zY0soxphmGIACbOHy6A==()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871), string.Empty)));
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zn60ui3ChU5Yk(JSONManager.ExtractString(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), string.Empty));
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zFzGvi_S6jJhE(JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zAsCgbAN02olKpq2GjA==(JSONManager.ExtractInt(#=zJdyVF9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
		return #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==;
	}

	// Token: 0x06000DF3 RID: 3571 RVA: 0x0006F1E0 File Offset: 0x0006D3E0
	public static void #=zY$pvpstqHPJzppOpm5pa2HJPtuI4(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zXduVemQ=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		if (#=zSJY$s3o= != null && #=zSJY$s3o=.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
		{
			return;
		}
		if (string.IsNullOrEmpty(#=zXduVemQ=.#=zj661vGqZTMsoJ4JrPg==()) && #=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==() >= 0)
		{
			if (#=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==() == 0)
			{
				#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=z8StzeqE=, #=zXduVemQ=.#=zMuFMjGQ=().ToString(), true, null);
				if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null)
				{
					#=zXduVemQ=.#=zAsCgbAN02olKpq2GjA==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==());
				}
				if (#=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==() == 0)
				{
					#=zXduVemQ=.#=zAsCgbAN02olKpq2GjA==(-1);
				}
			}
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zmLrGNVIgSMUH8cG0eyaa7PQ=(#=zXduVemQ=, #=z8StzeqE=, #=zSJY$s3o=);
		}
	}

	// Token: 0x06000DF4 RID: 3572 RVA: 0x0006F25C File Offset: 0x0006D45C
	public static void #=zmLrGNVIgSMUH8cG0eyaa7PQ=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zXduVemQ=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		if (#=zSJY$s3o= != null && #=zSJY$s3o=.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
		{
			return;
		}
		if (#=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==() > 0)
		{
			string text = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zYAdaM0gb6Gux4qLnpQ==(#=zSJY$s3o=, #=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==(), #=zXduVemQ=);
			if (string.IsNullOrEmpty(text) || text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945161), new object[]
				{
					#=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==(),
					#=z8StzeqE=.#=zYgvZuBwR$a1C(),
					#=z8StzeqE=.#=zKHqHudNIb2os(),
					JSONManager.Cut(text)
				});
				return;
			}
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetData(text);
			if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0) != #=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==())
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zaSj923AcHbIipudkqg==(#=z8StzeqE=.#=zYgvZuBwR$a1C(), #=zXduVemQ=.#=zO1FX6YkNZlqlvFZqJg==());
				return;
			}
			#=zXduVemQ=.#=z6AhOmwNDely78tSumg==(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty));
			foreach (Dictionary<string, object> dictionary2 in (object[])JSONManager.GetObject(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088037)))
			{
				if (dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)].ToString() == #=zXduVemQ=.#=zMuFMjGQ=().ToString())
				{
					#=zXduVemQ=.#=zL1nSSuED6_G9CQfsch1Gzg0=(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899)]));
					return;
				}
			}
		}
	}

	// Token: 0x06000DF5 RID: 3573 RVA: 0x0006F3D4 File Offset: 0x0006D5D4
	public static string #=zYAdaM0gb6Gux4qLnpQ==(#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=, int #=zLeeSKrg=, int #=zuip2jhc6oeXCWxswzQ==, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zRriteieuNhgzxzXk$g==)
	{
		if (#=zuip2jhc6oeXCWxswzQ== <= 0)
		{
			return string.Empty;
		}
		string text = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z88KXN9YQlR89lG4bcw==(#=zLeeSKrg=, #=zuip2jhc6oeXCWxswzQ==);
		if (string.IsNullOrWhiteSpace(text))
		{
			text = #=zSJY$s3o=.#=zXTTYoqGLxWmVM2mBWQ==(#=zuip2jhc6oeXCWxswzQ==.ToString(), #=zRriteieuNhgzxzXk$g==);
			if (!string.IsNullOrEmpty(text) && !text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z9Uo2__KT2KDVqGg7YQ==(#=zLeeSKrg=, #=zuip2jhc6oeXCWxswzQ==, text);
			}
		}
		return text;
	}

	// Token: 0x06000DF6 RID: 3574 RVA: 0x0006F430 File Offset: 0x0006D630
	public static double #=zOnM0lrc=(double #=zaknBcbE=, double #=zW9UfNlU=, double #=zkG0Mce4=, double #=zI0kV8Ds=)
	{
		return Math.Sqrt(Math.Pow(Math.Abs(#=zaknBcbE= - #=zkG0Mce4=), 2.0) + Math.Pow(Math.Abs(#=zW9UfNlU= - #=zI0kV8Ds=), 2.0));
	}

	// Token: 0x06000DF7 RID: 3575 RVA: 0x0006F464 File Offset: 0x0006D664
	public static TimeSpan #=zWRWylcMEygXu(double #=zaknBcbE=, double #=zW9UfNlU=, double #=zkG0Mce4=, double #=zI0kV8Ds=, double #=zsilaWAN$JOvI)
	{
		double num = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOnM0lrc=(#=zaknBcbE=, #=zW9UfNlU=, #=zkG0Mce4=, #=zI0kV8Ds=) / (#=zsilaWAN$JOvI * 10.0);
		if (num > 24.0)
		{
			num = 24.0;
		}
		if (#=zsilaWAN$JOvI > 100.0 && num > 1.0)
		{
			num = 1.0;
		}
		return TimeSpan.FromHours(num);
	}

	// Token: 0x06000DF8 RID: 3576 RVA: 0x0006F4C8 File Offset: 0x0006D6C8
	public UnitSquadCollection #=zu8GAa3qb_iNC(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, string #=zUeNLLxFUknOe)
	{
		return this.#=zu8GAa3qb_iNC(#=z8StzeqE=, #=zUeNLLxFUknOe, false);
	}

	// Token: 0x06000DF9 RID: 3577 RVA: 0x0006F4D4 File Offset: 0x0006D6D4
	private UnitSquadCollection #=zu8GAa3qb_iNC(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, string #=zUeNLLxFUknOe, bool #=zOHpNIo3l68usnRl2IA==)
	{
		#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD = null;
		UnitSquadCollection result;
		try
		{
			#=zG2wnL_q7IxpD = new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(null, false, #=z8StzeqE=);
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zG2wnL_q7IxpD, #=z8StzeqE=, null, null);
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zhuG9bG4zLi8ogdOUAA==();
			string allUnitsStr = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zow71wfuy88DngCDjGxC$_qOPtUTd().ToString();
			result = UnitSquadCollection.FromString(#=zUeNLLxFUknOe, allUnitsStr);
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=zG2wnL_q7IxpD, out flag);
			if (flag && !#=zOHpNIo3l68usnRl2IA==)
			{
				new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=).#=zuq1FOz8SJbyH();
				result = this.#=zu8GAa3qb_iNC(#=z8StzeqE=, #=zUeNLLxFUknOe, true);
			}
			else
			{
				result = new UnitSquadCollection();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = new UnitSquadCollection();
		}
		return result;
	}

	// Token: 0x06000DFA RID: 3578 RVA: 0x0006F574 File Offset: 0x0006D774
	public #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== #=z$qNhyVCEi3435jX2_ALVP10=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, bool #=zHKnPMPs8pw6ZZygxEQ==)
	{
		return this.#=z$qNhyVCEi3435jX2_ALVP10=(#=z8StzeqE=, #=zHKnPMPs8pw6ZZygxEQ==, false);
	}

	// Token: 0x06000DFB RID: 3579 RVA: 0x0006F580 File Offset: 0x0006D780
	private #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== #=z$qNhyVCEi3435jX2_ALVP10=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, bool #=zHKnPMPs8pw6ZZygxEQ==, bool #=zOHpNIo3l68usnRl2IA==)
	{
		#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD = null;
		#=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== result;
		try
		{
			#=zG2wnL_q7IxpD = new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(null, false, #=z8StzeqE=);
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zG2wnL_q7IxpD, #=z8StzeqE=, null, null);
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zhuG9bG4zLi8ogdOUAA==();
			List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zw$fMJ65lvs2ECx153Q==();
			#=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA== = new #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA==();
			foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== in list)
			{
				if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zzO1Tc28mhiyKO1MslOQ8t9E=() && !#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zosN4hoVyBAOs() && (#=zHKnPMPs8pw6ZZygxEQ== ? #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zuMDUwezH0nzaovu4ou0ba4x_JDN2b6S2ZA==() : #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zL_AjLx6G9w6sr8eOlj6hZ3k=()))
				{
					#=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA==.Add(new #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zd$BbM3Y=(), #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()));
				}
			}
			result = #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA==;
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=z8StzeqE=, #=zG2wnL_q7IxpD, out flag);
			if (flag && !#=zOHpNIo3l68usnRl2IA==)
			{
				new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=z8StzeqE=).#=zuq1FOz8SJbyH();
				result = this.#=z$qNhyVCEi3435jX2_ALVP10=(#=z8StzeqE=, #=zHKnPMPs8pw6ZZygxEQ==, true);
			}
			else
			{
				result = new #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA==();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = new #=zD0MDFqdsGkc9ae1V_FpRCVxz5$$l96tMJA==();
		}
		return result;
	}

	// Token: 0x06000DFC RID: 3580 RVA: 0x0006F690 File Offset: 0x0006D890
	public void #=z1GX$uzE=()
	{
		if (this.#=zBwAn1gXCuim2rBd5eA== == DateTime.MinValue)
		{
			object obj = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zdDVWRLKtNQo0;
			lock (obj)
			{
				if (this.#=zBwAn1gXCuim2rBd5eA== == DateTime.MinValue)
				{
					this.#=zBwAn1gXCuim2rBd5eA== = DateTime.Now;
					try
					{
						new Thread(new ParameterizedThreadStart(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z_ic$L3GxxUjP)).Start(this);
					}
					catch (Exception #=zN_s5Z5A=)
					{
						this.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
						this.#=zBwAn1gXCuim2rBd5eA== = DateTime.MinValue;
					}
				}
				return;
			}
		}
		if (this.#=zBwAn1gXCuim2rBd5eA== < DateTime.Now - TimeSpan.FromMinutes(10.0))
		{
			object obj = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zdDVWRLKtNQo0;
			lock (obj)
			{
				if (this.#=zBwAn1gXCuim2rBd5eA== != DateTime.MinValue && this.#=zBwAn1gXCuim2rBd5eA== < DateTime.Now - TimeSpan.FromMinutes(10.0))
				{
					this.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945341), Array.Empty<object>());
					this.#=zBwAn1gXCuim2rBd5eA== = DateTime.MinValue;
				}
			}
		}
	}

	// Token: 0x06000DFD RID: 3581 RVA: 0x0006F7EC File Offset: 0x0006D9EC
	public string #=zMdhsaiGx3fnI()
	{
		StringBuilder stringBuilder = new StringBuilder();
		try
		{
			foreach (#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C in this.#=zDt8M0JRTQpgMw6Nl6A==)
			{
				foreach (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== in #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=zbZ6OTR06cyHR())
				{
					if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zVv$Po1OfBUuq() != null)
					{
						stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945285), new object[]
						{
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z5VV8Oo_dYzMg(),
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=z9TrQaE7EBV1U().ProxyKey,
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zVv$Po1OfBUuq().#=zQ4wZnctPyyRO().#=zdEt_WRHpdEMmGTK_3Q==(),
							Environment.NewLine
						});
					}
					if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zaktMlI6Lx5IGn58ypg==() != null)
					{
						stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944996), new object[]
						{
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z5VV8Oo_dYzMg(),
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=z9TrQaE7EBV1U().ProxyKey,
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zaktMlI6Lx5IGn58ypg==().#=zQ4wZnctPyyRO().#=zdEt_WRHpdEMmGTK_3Q==(),
							Environment.NewLine
						});
					}
				}
			}
			foreach (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== in this.#=zSLICU36qdPPJ.#=zb1dVS05Z9T9fehB4nw==())
			{
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944967), #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.#=z5VV8Oo_dYzMg(), #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.Count, Environment.NewLine);
			}
			foreach (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2 in this.#=zSLICU36qdPPJ.#=zbPjqGaqJRDAevSEJtxEsxHA=())
			{
				if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.Count > 0)
				{
					stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944922), #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.#=z5VV8Oo_dYzMg(), #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.Count, Environment.NewLine);
				}
			}
		}
		catch
		{
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000DFE RID: 3582 RVA: 0x0006FA58 File Offset: 0x0006DC58
	private static void #=z_ic$L3GxxUjP(object #=zcyRsraWouSUf)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2)#=zcyRsraWouSUf;
		try
		{
			try
			{
				for (int i = 0; i < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=.Count; i++)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zu4uJReDJb4ev.#=zbPId9eg=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=[i]);
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=.Count > 0)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=[0].#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
				}
			}
			object obj = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zdDVWRLKtNQo0;
			lock (obj)
			{
				for (int j = 0; j < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.Count; j++)
				{
					#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==[j];
					for (int k = #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=zbZ6OTR06cyHR().Count - 1; k >= 0; k--)
					{
						#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== = #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=zbZ6OTR06cyHR()[k];
						if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
						{
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z$8IxHBJ8gJKf(k);
						}
						else
						{
							if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zVv$Po1OfBUuq() != null && #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zVv$Po1OfBUuq().#=zQ4wZnctPyyRO().#=zGQl3yUpez1XJ().#=z3MeIeP8$C0ue() == SessionProcessStates.Idle)
							{
								#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zyWBsBtq34zLJ(null);
							}
							if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zaktMlI6Lx5IGn58ypg==() != null && #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zaktMlI6Lx5IGn58ypg==().#=zQ4wZnctPyyRO().#=zzia5edbZiDd_52XM1A==().#=z3MeIeP8$C0ue() == SessionProcessStates.Idle)
							{
								#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==.#=zIsnh6OIR1zyxlKkRHg==(null);
							}
						}
					}
				}
				for (int l = 0; l < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=.Count; l++)
				{
					string text = #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z4FxeL2E=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=[l]);
					if (!#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.#=zavB3zWrtZYcs().Contains(text))
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.#=z48rEd0A=(new #=zkO3OALYBGNilukMF5u7j7K3EsP5C(text));
					}
				}
				#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== = ProxyInfo.#=zn2ovxJQcP5BV();
				bool flag2 = false;
				for (int m = 0; m < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.Count; m++)
				{
					#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==[m];
					for (int n = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1; n >= 0; n--)
					{
						ProxyInfo proxyInfo = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[n];
						if (proxyInfo.State == ProxyStates.Ok)
						{
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C2.#=zrUEQrg3CkNfVtOvihA==(proxyInfo);
						}
						else
						{
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C2.#=zIllIrRIrMKHU(proxyInfo.ProxyKey);
							if (proxyInfo.State == ProxyStates.Deleted)
							{
								#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Remove(proxyInfo);
							}
							else if (proxyInfo.State == ProxyStates.Unchecked)
							{
								flag2 = true;
							}
							if (proxyInfo.Type != ProxyTypes.NoProxy && !ProxyInfo.#=zBBqWg8YSrBWT(proxyInfo.Port))
							{
								#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z6KD5Fixsanu8.#=zbbu$0jU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945145), new object[]
								{
									proxyInfo.IP,
									proxyInfo.Port
								});
								#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Remove(proxyInfo);
							}
						}
					}
				}
				if (flag2)
				{
					#=zCkJ2v872SjNxELhRccHmlEbiV4Z7.#=zoR8PNRNYefFV(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==);
				}
				bool flag3 = false;
				foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=)
				{
					try
					{
						if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zObGzldk_Y5$c())
						{
							if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zcc0cnYs5WkmZ(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY().Count))
							{
								if (!(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=ziYbj9IsgzGRe7374EQ==() > DateTime.Now))
								{
									if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().#=z3MeIeP8$C0ue() == SessionProcessStates.Idle)
									{
										if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().Count > 0 && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zXhmu8wtI1QFueNwTW0lbj2Q=() <= DateTime.Now)
										{
											#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=z8mTF0fLVPqOZ(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
											#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().#=z0rhCzVKmQNwL(SessionProcessStates.Queued);
										}
									}
									else if (!flag3 && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==().#=z3MeIeP8$C0ue() == SessionProcessStates.Queued)
									{
										flag3 = true;
									}
									if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ().#=z3MeIeP8$C0ue() == SessionProcessStates.Idle && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ().Count > 0 && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z5CQ3MMGT7KZ6NzsrOA==() <= DateTime.Now)
									{
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=zZLCBaFk=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ().#=z0rhCzVKmQNwL(SessionProcessStates.Queued);
									}
								}
							}
						}
					}
					catch (Exception #=zN_s5Z5A=2)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=2);
					}
				}
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z5gsZrvYx_Krzuff_zw==())
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z2iktmSzYQHpk.#=zhqOtDQRSXQg8Qo8gmM6zXIg=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY());
					for (int num = 0; num < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.Count; num++)
					{
						#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C3 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==[num];
						for (int num2 = 0; num2 < #=zkO3OALYBGNilukMF5u7j7K3EsP5C3.#=zbZ6OTR06cyHR().Count; num2++)
						{
							if (#=zkO3OALYBGNilukMF5u7j7K3EsP5C3.#=zbZ6OTR06cyHR()[num2].#=zaktMlI6Lx5IGn58ypg==() == null)
							{
								#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=z23_js2cNQaAmWuNtfw==(#=zkO3OALYBGNilukMF5u7j7K3EsP5C3.#=z5VV8Oo_dYzMg());
								if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== != null)
								{
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2 = #=zkO3OALYBGNilukMF5u7j7K3EsP5C3.#=zbZ6OTR06cyHR()[num2];
									for (int num3 = 0; num3 < #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.Count; num3++)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 = #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==[num3];
										bool flag4;
										if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z2iktmSzYQHpk.#=zg6ifiug=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2, #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2.#=z9TrQaE7EBV1U(), #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY(), out flag4))
										{
											if (flag4)
											{
												#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zgi8txbeKnNhG(null);
											}
											#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2.#=zIsnh6OIR1zyxlKkRHg==(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2, true, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2));
											#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2.#=zaktMlI6Lx5IGn58ypg==().#=zQ4wZnctPyyRO().#=zzia5edbZiDd_52XM1A==().#=z0rhCzVKmQNwL(SessionProcessStates.Processing);
											#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.RemoveAt(num3);
											new Thread(new ParameterizedThreadStart(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z8nzsHUqZZ94u)).Start(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==2.#=zaktMlI6Lx5IGn58ypg==());
											break;
										}
									}
								}
							}
						}
					}
					int num4 = 0;
					for (int num5 = 0; num5 < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.Count; num5++)
					{
						#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C4 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==[num5];
						for (int num6 = 0; num6 < #=zkO3OALYBGNilukMF5u7j7K3EsP5C4.#=zbZ6OTR06cyHR().Count; num6++)
						{
							if (#=zkO3OALYBGNilukMF5u7j7K3EsP5C4.#=zbZ6OTR06cyHR()[num6].#=zVv$Po1OfBUuq() == null)
							{
								#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=zIxy9Fv4gtoZd(#=zkO3OALYBGNilukMF5u7j7K3EsP5C4.#=z5VV8Oo_dYzMg());
								if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2 != null)
								{
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3 = #=zkO3OALYBGNilukMF5u7j7K3EsP5C4.#=zbZ6OTR06cyHR()[num6];
									int num7 = 0;
									while (num7 < #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.Count)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3 = #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2[num7];
										bool flag5;
										if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z2iktmSzYQHpk.#=zg6ifiug=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3, #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3.#=z9TrQaE7EBV1U(), #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY(), out flag5))
										{
											if (flag5)
											{
												#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3.#=zgi8txbeKnNhG(null);
											}
											#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3.#=zyWBsBtq34zLJ(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3, false, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3));
											#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3.#=zVv$Po1OfBUuq().#=zQ4wZnctPyyRO().#=zGQl3yUpez1XJ().#=z0rhCzVKmQNwL(SessionProcessStates.Processing);
											#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.RemoveAt(num7);
											new Thread(new ParameterizedThreadStart(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z8nzsHUqZZ94u)).Start(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==3.#=zVv$Po1OfBUuq());
											if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.Count > num4)
											{
												num4 = #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==2.Count;
												break;
											}
											break;
										}
										else
										{
											num7++;
										}
									}
								}
							}
						}
					}
				}
				else
				{
					bool flag6 = false;
					foreach (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==3 in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=zbPjqGaqJRDAevSEJtxEsxHA=())
					{
						while (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==3.Count > 0)
						{
							flag6 = true;
							#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C5 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.#=zyo0_tZ8=(#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==3.#=z5VV8Oo_dYzMg());
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4 = null;
							for (int num8 = #=zkO3OALYBGNilukMF5u7j7K3EsP5C5.#=zbZ6OTR06cyHR().Count - 1; num8 >= 0; num8--)
							{
								if (#=zkO3OALYBGNilukMF5u7j7K3EsP5C5.#=zbZ6OTR06cyHR()[num8].#=zaktMlI6Lx5IGn58ypg==() == null)
								{
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4 = #=zkO3OALYBGNilukMF5u7j7K3EsP5C5.#=zbZ6OTR06cyHR()[num8];
									break;
								}
							}
							if (#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4 == null)
							{
								break;
							}
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4.#=zIsnh6OIR1zyxlKkRHg==(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4, true, #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==3[0]));
							#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4.#=zaktMlI6Lx5IGn58ypg==().#=zQ4wZnctPyyRO().#=zzia5edbZiDd_52XM1A==().#=z0rhCzVKmQNwL(SessionProcessStates.Processing);
							#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==3.RemoveAt(0);
							new Thread(new ParameterizedThreadStart(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z8nzsHUqZZ94u)).Start(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==4.#=zaktMlI6Lx5IGn58ypg==());
						}
					}
					if (flag3 && !flag6)
					{
						foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==4 in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zgIqT5PY=)
						{
							if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==4.#=zzia5edbZiDd_52XM1A==().#=z3MeIeP8$C0ue() == SessionProcessStates.Queued)
							{
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==4.#=zzia5edbZiDd_52XM1A==().#=z0rhCzVKmQNwL(SessionProcessStates.Idle);
							}
						}
					}
					int num9 = 0;
					for (int num10 = 0; num10 < #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==.Count; num10++)
					{
						#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zkO3OALYBGNilukMF5u7j7K3EsP5C6 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zDt8M0JRTQpgMw6Nl6A==[num10];
						for (int num11 = 0; num11 < #=zkO3OALYBGNilukMF5u7j7K3EsP5C6.#=zbZ6OTR06cyHR().Count; num11++)
						{
							if (#=zkO3OALYBGNilukMF5u7j7K3EsP5C6.#=zbZ6OTR06cyHR()[num11].#=zVv$Po1OfBUuq() == null)
							{
								#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zSLICU36qdPPJ.#=zIxy9Fv4gtoZd(#=zkO3OALYBGNilukMF5u7j7K3EsP5C6.#=z5VV8Oo_dYzMg());
								if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4 != null && #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4.Count > 0)
								{
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==5 = #=zkO3OALYBGNilukMF5u7j7K3EsP5C6.#=zbZ6OTR06cyHR()[num11];
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==5.#=zyWBsBtq34zLJ(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==5, false, #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4[0]));
									#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==5.#=zVv$Po1OfBUuq().#=zQ4wZnctPyyRO().#=zGQl3yUpez1XJ().#=z0rhCzVKmQNwL(SessionProcessStates.Processing);
									#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4.RemoveAt(0);
									new Thread(new ParameterizedThreadStart(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=z8nzsHUqZZ94u)).Start(#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==5.#=zVv$Po1OfBUuq());
									if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4.Count > num9)
									{
										num9 = #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==4.Count;
									}
								}
							}
						}
					}
				}
				if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z60QpHuOuvFhV < DateTime.Now)
				{
					if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z60QpHuOuvFhV > DateTime.MinValue)
					{
						object[] array = new object[#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY().Count];
						for (int num12 = 0; num12 < array.Length; num12++)
						{
							array[num12] = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY()[num12].#=zCCBXDJ5n_DGghKXXmA==();
						}
						try
						{
							object[] array2 = JSONManager.GetArray(JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zg9RGssIaCxTP(array)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
							if (array2 != null)
							{
								foreach (Dictionary<string, object> dictionary in array2)
								{
									string item = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), string.Empty);
									if (!#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z_i6cV3$u7k_e.Contains(item))
									{
										int num14 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
										object[] array4 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057325));
										List<string> list = new List<string>();
										foreach (object value in array4)
										{
											list.Add(Convert.ToString(value));
										}
										Dictionary<string, object> #=z8e5z318= = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
										foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY())
										{
											if (list.Contains(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==()))
											{
												foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==5 in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
												{
													if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==5.#=zYgvZuBwR$a1C() == num14)
													{
														#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==5.#=zeR3QFrc=(Task.#=zErO$$v4=(#=z8e5z318=, null));
														#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==5);
													}
												}
											}
										}
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z_i6cV3$u7k_e.Add(item);
									}
								}
							}
						}
						catch (Exception ex)
						{
							#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945052), new object[]
							{
								ex.Message
							});
						}
					}
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z60QpHuOuvFhV = DateTime.Now + TimeSpan.FromHours(12.0);
				}
			}
		}
		catch (Exception #=zN_s5Z5A=3)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=3);
		}
		finally
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zBwAn1gXCuim2rBd5eA== = DateTime.MinValue;
		}
	}

	// Token: 0x06000DFF RID: 3583 RVA: 0x000706A0 File Offset: 0x0006E8A0
	private static void #=z8nzsHUqZZ94u(object #=znzTISDFJmFex)
	{
		try
		{
			#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== = (#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==)#=znzTISDFJmFex;
			if (#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== != null)
			{
				if (#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=zQ4wZnctPyyRO() != null)
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=zQ4wZnctPyyRO();
					#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z23sS9NhIcGaTj3irAlB1lVH1yUQC = #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=zU3NiAfDQweme8jKsqw==() ? #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zzia5edbZiDd_52XM1A==() : #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zGQl3yUpez1XJ();
					if (#=z23sS9NhIcGaTj3irAlB1lVH1yUQC != null)
					{
						if (!#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zObGzldk_Y5$c())
						{
							#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.#=z0rhCzVKmQNwL(SessionProcessStates.Idle);
						}
						else
						{
							bool flag = false;
							bool flag2 = false;
							#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z23sS9NhIcGaTj3irAlB1lVH1yUQC2 = new #=z23sS9NhIcGaTj3irAlB1lVH1yUQC(#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.#=zU3NiAfDQweme8jKsqw==());
							try
							{
								bool flag3 = false;
								object #=zBCxv0_Eazs = #=z23sS9NhIcGaTj3irAlB1lVH1yUQC.#=zBCxv0_Eazs01;
								lock (#=zBCxv0_Eazs)
								{
									for (int i = #=z23sS9NhIcGaTj3irAlB1lVH1yUQC.Count - 1; i >= 0; i--)
									{
										Task task = #=z23sS9NhIcGaTj3irAlB1lVH1yUQC[i];
										if (task.State == TaskStates.Complete || task.State == TaskStates.Cancelled || task.State == TaskStates.Missed)
										{
											#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.RemoveAt(i);
											flag3 = true;
										}
									}
									for (int j = 0; j < #=z23sS9NhIcGaTj3irAlB1lVH1yUQC.Count; j++)
									{
										Task task2 = #=z23sS9NhIcGaTj3irAlB1lVH1yUQC[j];
										if (!(task2.ExecutionTime <= DateTime.Now))
										{
											break;
										}
										if (task2.State == TaskStates.Pending)
										{
											if (task2.Severity == TaskSeverities.Urgent || task2.Severity == TaskSeverities.Immediate || #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground)
											{
												#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.Add(task2);
											}
											else if (task2.Severity == TaskSeverities.UrgentNoRelogin || !#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground)
											{
												task2.ExecutionTime = DateTime.Now + TimeSpan.FromMinutes(1.0);
												flag3 = true;
											}
										}
										else if (task2.State == TaskStates.Running)
										{
											#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944753), Array.Empty<object>());
											#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.#=z0rhCzVKmQNwL(SessionProcessStates.Processing);
											#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.Clear();
											break;
										}
									}
								}
								if (#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.Count > 0)
								{
									if (!#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zq76JuU9WPIZn())
									{
										if (!#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zObGzldk_Y5$c())
										{
											return;
										}
										if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsResetAccountOnLogin && GameApplicationData.#=z7wsmjLWw49AC() != GameApplicationData.GameHosters.GamesMail && GameApplicationData.#=z7wsmjLWw49AC() != GameApplicationData.GameHosters.PlariumRu && GameApplicationData.#=z7wsmjLWw49AC() != GameApplicationData.GameHosters.PlariumEn)
										{
											#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zhltKJsaZJ5wf(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15());
										}
									}
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944729), new object[]
									{
										#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=z9TrQaE7EBV1U().ProxyKey,
										#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.Count,
										#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=zU3NiAfDQweme8jKsqw==() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944655) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944677))
									});
									#=z6ozZM$fwsEVn6xrBXDtluE0maUyDMS9naA==.#=z1GX$uzE=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=z23sS9NhIcGaTj3irAlB1lVH1yUQC2);
									flag3 = true;
								}
								else
								{
									#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zqGxyYdiygKCr(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
									flag2 = true;
								}
								if (flag3)
								{
									#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
									ProxyInfo.#=zn2ovxJQcP5BV().#=zmIBGvrsO$QbW(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==.#=z9TrQaE7EBV1U());
								}
								if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground)
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zpAIjRlo0AKmKYNY3$g==(DateTime.Now);
								}
								flag = true;
							}
							catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
							{
								if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)4)
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=z_CMx39SmGb4B(false);
								}
								else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)1)
								{
									if (GameApplicationData.#=z6KvP4MGoQFDo() >= 999)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = false;
									}
								}
								else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)10)
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = false;
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
								}
								else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)11)
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
								}
								else
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
								}
							}
							catch (Exception #=zN_s5Z5A=)
							{
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=zN_s5Z5A=);
							}
							finally
							{
								if (!flag2)
								{
									if (flag)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944893), Array.Empty<object>());
									}
									else
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944850), Array.Empty<object>());
									}
								}
								object #=zBCxv0_Eazs = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zdDVWRLKtNQo0;
								lock (#=zBCxv0_Eazs)
								{
									#=z23sS9NhIcGaTj3irAlB1lVH1yUQC.#=z0rhCzVKmQNwL(SessionProcessStates.Idle);
									for (int k = 0; k < #=z23sS9NhIcGaTj3irAlB1lVH1yUQC2.Count; k++)
									{
										if (#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2[k].State == TaskStates.Running)
										{
											#=z23sS9NhIcGaTj3irAlB1lVH1yUQC2[k].State = TaskStates.Pending;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=2);
		}
	}

	// Token: 0x040007CB RID: 1995
	private static #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zOAzeRO$HqsMN = null;

	// Token: 0x040007CC RID: 1996
	private static object #=zdDVWRLKtNQo0 = new object();

	// Token: 0x040007CD RID: 1997
	private static object #=zvTOPl_zmYOP7 = new object();

	// Token: 0x040007CE RID: 1998
	private List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=z87n$QYHiz3$vOoJLjA==;

	// Token: 0x040007CF RID: 1999
	private List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zgIqT5PY=;

	// Token: 0x040007D0 RID: 2000
	private MasterTaskCollection #=zv_V_Yw63ia3c;

	// Token: 0x040007D1 RID: 2001
	private #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ== #=z2iktmSzYQHpk;

	// Token: 0x040007D2 RID: 2002
	private DateTime #=zBwAn1gXCuim2rBd5eA==;

	// Token: 0x040007D3 RID: 2003
	private #=zCkJ2v872SjNxELhRccHmlEbiV4Z7 #=zSJdH6zXojLlk;

	// Token: 0x040007D4 RID: 2004
	private #=zBlV0sBQdC88uTJgOosW7FZ0cX0Gr #=zDt8M0JRTQpgMw6Nl6A==;

	// Token: 0x040007D5 RID: 2005
	private #=zJszBSBJVMeorD6roCiYj0PrZQRO_Ew1yUw== #=zSLICU36qdPPJ;

	// Token: 0x040007D6 RID: 2006
	private #=zBNSjuxymwpzVeRYZu29JmEUUd7y_ZQcnPw== #=zu4uJReDJb4ev;

	// Token: 0x040007D7 RID: 2007
	private #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=z6KD5Fixsanu8;

	// Token: 0x040007D8 RID: 2008
	private #=zxMOyT4mqlNEbNbr2evcJByuLqWmY66ZEzw== #=zQXlIqvTrwPLgFsMLMw==;

	// Token: 0x040007D9 RID: 2009
	private #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB #=zYZyOAbZiAYRn = new #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB(6, new #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=z1$_sdfQ=(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zZj33c9eGCdD2H3Vhqw==), true);

	// Token: 0x040007DA RID: 2010
	private #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB #=zQhFN4gS7pw0r4iXneeJbd3dveG5S = new #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB(2, new #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=z1$_sdfQ=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zZ26KHSLTYk$bHRH1Ag==), true);

	// Token: 0x040007DB RID: 2011
	private DateTime #=z60QpHuOuvFhV = DateTime.MinValue;

	// Token: 0x040007DC RID: 2012
	private List<string> #=z_i6cV3$u7k_e = new List<string>();

	// Token: 0x020001CF RID: 463
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000E02 RID: 3586 RVA: 0x00070B70 File Offset: 0x0006ED70
		internal int #=z7NoCWWotE6cOXbrrQT_sVfw=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zQrqFdos=, #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zKFlJyLE=)
		{
			return #=zQrqFdos=.#=z5KSZXEKT20zU().CompareTo(#=zKFlJyLE=.#=z5KSZXEKT20zU());
		}

		// Token: 0x06000E03 RID: 3587 RVA: 0x00070B94 File Offset: 0x0006ED94
		internal int #=zL4EmqyOSjUEktkyM3$mQYs8=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zKFlJyLE=)
		{
			if (#=zQrqFdos=.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU() == #=zKFlJyLE=.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU())
			{
				return #=zQrqFdos=.#=zYgvZuBwR$a1C().CompareTo(#=zKFlJyLE=.#=zYgvZuBwR$a1C());
			}
			return #=zQrqFdos=.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU().CompareTo(#=zKFlJyLE=.#=zh5Q$jgycqA15().#=z5KSZXEKT20zU());
		}

		// Token: 0x040007DD RID: 2013
		public static readonly #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zyDNvciU= #=zLkw0NRU= = new #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zyDNvciU=();

		// Token: 0x040007DE RID: 2014
		public static Comparison<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zrrq5dzCmhKunjoWt9g==;

		// Token: 0x040007DF RID: 2015
		public static Comparison<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zUq0twgM6eFRnThEc4g==;
	}
}
