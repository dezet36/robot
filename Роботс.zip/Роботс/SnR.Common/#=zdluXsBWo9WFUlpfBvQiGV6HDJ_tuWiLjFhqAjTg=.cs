﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000221 RID: 545
internal sealed class #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= : Task
{
	// Token: 0x060010AB RID: 4267 RVA: 0x00080474 File Offset: 0x0007E674
	public #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=(DateTime #=zxSBcx18=, int #=zYv8W575ANOZV, int #=zDjv6Nua1qD1G, int #=zIhiP4wI=, int #=zUxK$kPTRsh2L, bool #=z88eloGVFNEtT, bool #=zDLQRX1rLh6SH) : base(TaskSources.ManualNotSavable, TaskSeverities.UrgentNoRelogin, TaskTypes.ContributeResourcesToPant, #=zxSBcx18=, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false)
	{
		this.#=zsK0xyz$NG7eT = #=zYv8W575ANOZV;
		this.#=zl8cbHZmoQb6m = #=zDjv6Nua1qD1G;
		this.#=znSN3smY2Lxc2 = #=zIhiP4wI=;
		this.#=znHYz$BNE$UXT = #=zUxK$kPTRsh2L;
		this.#=zH5KNGtWQK02l = 0;
		this.#=zXfkFwEc_5SfU = #=z88eloGVFNEtT;
		this.#=z1$nvjxNwmRQdedJjtg== = #=zDLQRX1rLh6SH;
		base.Options |= TaskOptions.MasterIsSum;
	}

	// Token: 0x060010AC RID: 4268 RVA: 0x000804F0 File Offset: 0x0007E6F0
	public #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x060010AD RID: 4269 RVA: 0x0008050C File Offset: 0x0007E70C
	public #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=(MasterTask #=zwcZwAIGe3vUR) : base(#=zwcZwAIGe3vUR)
	{
		#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= = (#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=)#=zwcZwAIGe3vUR.Task;
		this.#=zsK0xyz$NG7eT = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zxI3h$5i_fx2h();
		this.#=zl8cbHZmoQb6m = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==();
		this.#=znSN3smY2Lxc2 = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=z8t$FeXGfLTQN();
		this.#=znHYz$BNE$UXT = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zg$iaM0kytTEf();
		this.#=zH5KNGtWQK02l = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zBm2rcaHKqpSf();
		this.#=zXfkFwEc_5SfU = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zLjm$kaoe2AbnoVRBfg==();
		this.#=z1$nvjxNwmRQdedJjtg== = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zxiTIzLO4JHjcG2ddqw==();
	}

	// Token: 0x060010AE RID: 4270 RVA: 0x0008058C File Offset: 0x0007E78C
	public int #=zxI3h$5i_fx2h()
	{
		return this.#=zsK0xyz$NG7eT;
	}

	// Token: 0x060010AF RID: 4271 RVA: 0x00080594 File Offset: 0x0007E794
	public int #=zMmwKnVQRjotIACC$jA==()
	{
		return this.#=zl8cbHZmoQb6m;
	}

	// Token: 0x060010B0 RID: 4272 RVA: 0x0008059C File Offset: 0x0007E79C
	public int #=z8t$FeXGfLTQN()
	{
		return this.#=znSN3smY2Lxc2;
	}

	// Token: 0x060010B1 RID: 4273 RVA: 0x000805A4 File Offset: 0x0007E7A4
	public int #=zg$iaM0kytTEf()
	{
		return this.#=znHYz$BNE$UXT;
	}

	// Token: 0x060010B2 RID: 4274 RVA: 0x000805AC File Offset: 0x0007E7AC
	public int #=zBm2rcaHKqpSf()
	{
		return this.#=zH5KNGtWQK02l;
	}

	// Token: 0x060010B3 RID: 4275 RVA: 0x000805B4 File Offset: 0x0007E7B4
	public bool #=zLjm$kaoe2AbnoVRBfg==()
	{
		return this.#=zXfkFwEc_5SfU;
	}

	// Token: 0x060010B4 RID: 4276 RVA: 0x000805BC File Offset: 0x0007E7BC
	public bool #=zxiTIzLO4JHjcG2ddqw==()
	{
		return this.#=z1$nvjxNwmRQdedJjtg==;
	}

	// Token: 0x1700004E RID: 78
	// (get) Token: 0x060010B5 RID: 4277 RVA: 0x000805C4 File Offset: 0x0007E7C4
	public override string Details
	{
		get
		{
			return new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875266), new object[]
			{
				this.#=zl8cbHZmoQb6m,
				this.#=znSN3smY2Lxc2
			}).ToString();
		}
	}

	// Token: 0x060010B6 RID: 4278 RVA: 0x000805FC File Offset: 0x0007E7FC
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zsK0xyz$NG7eT = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875488), 0);
		this.#=zl8cbHZmoQb6m = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875474), 0);
		this.#=znSN3smY2Lxc2 = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875468), 0);
		this.#=znHYz$BNE$UXT = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875454), 0);
		this.#=zH5KNGtWQK02l = 0;
		this.#=zXfkFwEc_5SfU = (JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875439), 0) == 1);
		this.#=z1$nvjxNwmRQdedJjtg== = (JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875416), 0) == 1);
	}

	// Token: 0x060010B7 RID: 4279 RVA: 0x000806A0 File Offset: 0x0007E8A0
	public override void UpdateTask(Dictionary<string, object> #=z8e5z318=)
	{
		base.UpdateTask(#=z8e5z318=);
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x1700004F RID: 79
	// (get) Token: 0x060010B8 RID: 4280 RVA: 0x000806B0 File Offset: 0x0007E8B0
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874387);
		}
	}

	// Token: 0x060010B9 RID: 4281 RVA: 0x000806BC File Offset: 0x0007E8BC
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875488)] = this.#=zsK0xyz$NG7eT;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875474)] = this.#=zl8cbHZmoQb6m;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875468)] = this.#=znSN3smY2Lxc2;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875454)] = this.#=znHYz$BNE$UXT + this.#=zH5KNGtWQK02l;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875439)] = ((this.#=zXfkFwEc_5SfU > false) ? 1 : 0);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875416)] = ((this.#=z1$nvjxNwmRQdedJjtg== > false) ? 1 : 0);
		return dictionary;
	}

	// Token: 0x060010BA RID: 4282 RVA: 0x00080780 File Offset: 0x0007E980
	public int #=z$IzzkOA=(int #=zNvCMwussKumm)
	{
		object obj = this.#=zSV4$mlFB34WM;
		int num;
		lock (obj)
		{
			num = Math.Min(this.#=znHYz$BNE$UXT, #=zNvCMwussKumm);
			this.#=znHYz$BNE$UXT -= num;
			this.#=zH5KNGtWQK02l += num;
		}
		return num;
	}

	// Token: 0x060010BB RID: 4283 RVA: 0x000807E4 File Offset: 0x0007E9E4
	public void #=zZFZo118=(int #=zNvCMwussKumm)
	{
		object obj = this.#=zSV4$mlFB34WM;
		lock (obj)
		{
			this.#=zH5KNGtWQK02l -= #=zNvCMwussKumm;
			if (this.#=zH5KNGtWQK02l < 0)
			{
				this.#=znHYz$BNE$UXT += this.#=zH5KNGtWQK02l;
				if (this.#=znHYz$BNE$UXT < 0)
				{
					this.#=znHYz$BNE$UXT = 0;
				}
				this.#=zH5KNGtWQK02l = 0;
			}
		}
	}

	// Token: 0x060010BC RID: 4284 RVA: 0x00080864 File Offset: 0x0007EA64
	public void #=zQgGl73U=(int #=zNvCMwussKumm)
	{
		object obj = this.#=zSV4$mlFB34WM;
		lock (obj)
		{
			int num = Math.Min(this.#=zH5KNGtWQK02l, #=zNvCMwussKumm);
			this.#=znHYz$BNE$UXT += num;
			this.#=zH5KNGtWQK02l -= num;
		}
	}

	// Token: 0x060010BD RID: 4285 RVA: 0x000808C8 File Offset: 0x0007EAC8
	public static int #=zu2IcrxE5FBJuMy3xGQ==(int #=zIcs8h4ehLWmq, int #=zIhiP4wI=)
	{
		int num = 0;
		for (int i = #=zIcs8h4ehLWmq + 1; i <= #=zIhiP4wI=; i++)
		{
			num += i * 500000;
		}
		return num;
	}

	// Token: 0x060010BE RID: 4286 RVA: 0x000808F0 File Offset: 0x0007EAF0
	public void #=zNZkkiPc=()
	{
		object obj = this.#=zSV4$mlFB34WM;
		lock (obj)
		{
			this.#=znHYz$BNE$UXT = 0;
		}
	}

	// Token: 0x04000905 RID: 2309
	private int #=zsK0xyz$NG7eT;

	// Token: 0x04000906 RID: 2310
	private int #=zl8cbHZmoQb6m;

	// Token: 0x04000907 RID: 2311
	private int #=znSN3smY2Lxc2;

	// Token: 0x04000908 RID: 2312
	private int #=znHYz$BNE$UXT;

	// Token: 0x04000909 RID: 2313
	private int #=zH5KNGtWQK02l;

	// Token: 0x0400090A RID: 2314
	private bool #=zXfkFwEc_5SfU;

	// Token: 0x0400090B RID: 2315
	private bool #=z1$nvjxNwmRQdedJjtg==;

	// Token: 0x0400090C RID: 2316
	private object #=zSV4$mlFB34WM = new object();
}
