﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Skink.SnR.Common;
using Skink.SnR.Common.Managers;

// Token: 0x020000C8 RID: 200
internal sealed class #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=
{
	// Token: 0x0600053D RID: 1341 RVA: 0x0002D084 File Offset: 0x0002B284
	private #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=(int #=zLeeSKrg=)
	{
		this.#=z8hJHIKFp6jOv(#=zLeeSKrg=);
		this.#=zExqbjbq9lTK4(new List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=>());
		this.#=zg6ol2CXXMmNJ21Ls0Q== = new List<int>();
		this.#=z90PpFfY$9YqO_2AZmQ== = DateTime.MinValue;
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x0002D0D4 File Offset: 0x0002B2D4
	private int #=zYgvZuBwR$a1C()
	{
		return this.#=z$eM7GpXgW_KO8hkYHQ==;
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x0002D0DC File Offset: 0x0002B2DC
	private void #=z8hJHIKFp6jOv(int #=z$Ib9gYQ=)
	{
		this.#=z$eM7GpXgW_KO8hkYHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x0002D0E8 File Offset: 0x0002B2E8
	private List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=zi9biyIcmNyLd()
	{
		return this.#=zhPN7yqrwKorL4AeTUQ==;
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x0002D0F0 File Offset: 0x0002B2F0
	private void #=zExqbjbq9lTK4(List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=z$Ib9gYQ=)
	{
		this.#=zhPN7yqrwKorL4AeTUQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000543 RID: 1347 RVA: 0x0002D0FC File Offset: 0x0002B2FC
	private DateTime #=zufhsknr$zYqx()
	{
		return this.#=zvrOVexdkkKIOSWZYOPZ6NZA=;
	}

	// Token: 0x06000544 RID: 1348 RVA: 0x0002D104 File Offset: 0x0002B304
	private void #=zSEQYEYi_8x6Q(DateTime #=z$Ib9gYQ=)
	{
		this.#=zvrOVexdkkKIOSWZYOPZ6NZA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000545 RID: 1349 RVA: 0x0002D110 File Offset: 0x0002B310
	public static #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zi1hFJwI=(int #=zLeeSKrg=)
	{
		object obj;
		if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m == null)
		{
			obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zz$JYe0tjSWxT;
			lock (obj)
			{
				if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m == null)
				{
					#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m = new List<#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=>();
				}
			}
		}
		for (int i = 0; i < #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m.Count; i++)
		{
			if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m[i].#=zYgvZuBwR$a1C() == #=zLeeSKrg=)
			{
				return #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m[i];
			}
		}
		obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zz$JYe0tjSWxT;
		#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= result;
		lock (obj)
		{
			for (int j = 0; j < #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m.Count; j++)
			{
				if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m[j].#=zYgvZuBwR$a1C() == #=zLeeSKrg=)
				{
					return #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m[j];
				}
			}
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= = new #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=(#=zLeeSKrg=);
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSEQYEYi_8x6Q(DateTime.MinValue);
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zRpmsU7faMqtoSE3WyQ==();
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zjz3qsKoI_h4m.Add(#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=);
			result = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=;
		}
		return result;
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x0002D224 File Offset: 0x0002B424
	private void #=zRpmsU7faMqtoSE3WyQ==()
	{
		if (this.#=zufhsknr$zYqx() > DateTime.Now)
		{
			return;
		}
		object obj = this.#=zSV4$mlFB34WM;
		lock (obj)
		{
			if (this.#=zufhsknr$zYqx() > DateTime.Now)
			{
				return;
			}
			this.#=zSEQYEYi_8x6Q(DateTime.Now + TimeSpan.FromHours(12.0));
		}
		try
		{
			List<object> list = new List<object>();
			int count = this.#=zi9biyIcmNyLd().Count;
			for (int i = 0; i < count; i++)
			{
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = this.#=zi9biyIcmNyLd()[i];
				if (!#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z7Ss1uIfnRw1fbvsZpg==())
				{
					list.Add(new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zMuFMjGQ=()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zEpmJu0QO9VH_()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909010257),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z9Yordw6ZFjQe()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zXAysPE5a2IRR()
						}
					});
				}
			}
			object[] array = new object[list.Count];
			list.CopyTo(array);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943339), new object[]
			{
				list.Count,
				this.#=zYgvZuBwR$a1C()
			});
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Debug, JSONManager.SerializeData(array), Array.Empty<object>());
			string text = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zGGL_CKcwA0bfABCwew==(this.#=zYgvZuBwR$a1C(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943249), null, array);
			if (!string.IsNullOrEmpty(text))
			{
				#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
				object[] array2 = (object[])JSONManager.DeserializeData(text);
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943233), new object[]
				{
					array2.Length,
					this.#=zYgvZuBwR$a1C()
				});
				for (int j = 0; j < count; j++)
				{
					this.#=zi9biyIcmNyLd()[j].#=zHQopOEXFlU$wegdg7g==(true);
				}
				foreach (Dictionary<string, object> dictionary in array2)
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2 = new #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=(new Guid(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)].ToString()), Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909010257), string.Empty), #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zgGkIlWWkq3Ly(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)])), Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)]));
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zHQopOEXFlU$wegdg7g==(true);
					bool flag2 = false;
					for (int l = 0; l < count; l++)
					{
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3 = this.#=zi9biyIcmNyLd()[l];
						if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zEpmJu0QO9VH_() == #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zEpmJu0QO9VH_() && #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4() == #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4() && #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zXAysPE5a2IRR() == #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR())
						{
							#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zbsxKkj4=(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zMuFMjGQ=());
							flag2 = true;
							break;
						}
					}
					if (!flag2)
					{
						this.#=zi9biyIcmNyLd().Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2);
					}
				}
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942882), new object[]
				{
					this.#=zi9biyIcmNyLd().Count,
					this.#=zYgvZuBwR$a1C()
				});
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			this.#=zSEQYEYi_8x6Q(DateTime.Now + TimeSpan.FromMinutes(15.0));
		}
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x0002D610 File Offset: 0x0002B810
	public static bool #=z15ufqu6UkMD2(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zpzrSpck=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zjZWhv$4=)
	{
		bool result;
		try
		{
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi1hFJwI=(#=zpzrSpck=.#=zYgvZuBwR$a1C());
			bool flag = false;
			object obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSV4$mlFB34WM;
			#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=;
			lock (obj)
			{
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zsJQoNA8w7l12(#=zjZWhv$4=);
				if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= == null)
				{
					return false;
				}
				if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zrNIiQ09PozZW(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()))
				{
					return false;
				}
				if (!#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z7Ss1uIfnRw1fbvsZpg==())
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zUn4qbBk$AaeQ(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zSUCWEnKUzUex(DateTime.Now + TimeSpan.FromMinutes(3.0));
					return true;
				}
				if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z8UpTpY7EO8gZ() == 1 && #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z4iM29j0EtduuG84aag==() > DateTime.Now)
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zUn4qbBk$AaeQ(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zSUCWEnKUzUex(DateTime.Now + TimeSpan.FromMinutes(3.0));
					return true;
				}
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zUn4qbBk$AaeQ(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zSUCWEnKUzUex(DateTime.Now + TimeSpan.FromMinutes(1.0));
				flag = true;
			}
			if (!flag)
			{
				result = false;
			}
			else
			{
				string text = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zGGL_CKcwA0bfABCwew==(#=zpzrSpck=.#=zYgvZuBwR$a1C(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943060), #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zMuFMjGQ=().ToString(), null);
				obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSV4$mlFB34WM;
				lock (obj)
				{
					if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zrNIiQ09PozZW(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()))
					{
						result = false;
					}
					else if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201)))
					{
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zUn4qbBk$AaeQ(#=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=());
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zSUCWEnKUzUex(DateTime.Now + TimeSpan.FromMinutes(3.0));
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zV6Dquhr54Is2(1);
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z5EKKr48gTsJaScefJw==(DateTime.Now + TimeSpan.FromMinutes(Convert.ToDouble(text.Substring(2), CultureInfo.InvariantCulture)));
						result = true;
					}
					else if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951189)))
					{
						#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi9biyIcmNyLd().Remove(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=);
						result = false;
					}
					else
					{
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zV6Dquhr54Is2(2);
						#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z5EKKr48gTsJaScefJw==(DateTime.Now + TimeSpan.FromMinutes(Convert.ToDouble(text.Substring(2), CultureInfo.InvariantCulture)));
						result = false;
					}
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x0002D8C8 File Offset: 0x0002BAC8
	public static void #=zkVnCyAE_ovFk(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zpzrSpck=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zjZWhv$4=)
	{
		try
		{
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi1hFJwI=(#=zpzrSpck=.#=zYgvZuBwR$a1C());
			object obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zsJQoNA8w7l12(#=zjZWhv$4=);
				if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= != null && #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zN3pqKKv6fQGP() == #=zpzrSpck=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zUn4qbBk$AaeQ(0);
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zSUCWEnKUzUex(DateTime.MinValue);
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
	}

	// Token: 0x06000549 RID: 1353 RVA: 0x0002D95C File Offset: 0x0002BB5C
	public static void #=zqvHy_roSewqZ(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zpzrSpck=, #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zjZWhv$4=)
	{
		try
		{
			#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi1hFJwI=(#=zpzrSpck=.#=zYgvZuBwR$a1C());
			object obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zSV4$mlFB34WM;
			#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=;
			lock (obj)
			{
				#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zsJQoNA8w7l12(#=zjZWhv$4=);
				if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= != null)
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zS5uus3Bg_NuG(true);
				}
			}
			if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=z7Ss1uIfnRw1fbvsZpg==())
			{
				#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zGGL_CKcwA0bfABCwew==(#=zpzrSpck=.#=zYgvZuBwR$a1C(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943043), #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zMuFMjGQ=().ToString(), null);
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
		}
	}

	// Token: 0x0600054A RID: 1354 RVA: 0x0002DA04 File Offset: 0x0002BC04
	private #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zsJQoNA8w7l12(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zjZWhv$4=)
	{
		if (this.#=zi9biyIcmNyLd().Contains(#=zjZWhv$4=))
		{
			return #=zjZWhv$4=;
		}
		for (int i = 0; i < this.#=zi9biyIcmNyLd().Count; i++)
		{
			#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = this.#=zi9biyIcmNyLd()[i];
			if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zMuFMjGQ=() == #=zjZWhv$4=.#=zMuFMjGQ=())
			{
				return #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=;
			}
		}
		return null;
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x0002DA5C File Offset: 0x0002BC5C
	public static #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zSFXFmKINPah26TjROQ==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zZ61w3rgvgY1YOZ4EoCDelTU=, #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zOtmvYykNkDbU)
	{
		return #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi1hFJwI=(#=z8StzeqE=.#=zYgvZuBwR$a1C()).#=zN6C0zJKQ4oMUwHLinsMjtvw=(#=z8StzeqE=, #=zZ61w3rgvgY1YOZ4EoCDelTU=, #=zOtmvYykNkDbU);
	}

	// Token: 0x0600054C RID: 1356 RVA: 0x0002DA74 File Offset: 0x0002BC74
	private #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zN6C0zJKQ4oMUwHLinsMjtvw=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD, #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zGFaDX7NUnXGa)
	{
		this.#=zRpmsU7faMqtoSE3WyQ==();
		#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= = new #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=();
		#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zWJtg2ZwejGqM(this.#=zi9biyIcmNyLd().Count);
		Dictionary<int, List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=>> dictionary = new Dictionary<int, List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=>>();
		for (int i = 0; i < this.#=zi9biyIcmNyLd().Count; i++)
		{
			#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= = this.#=zi9biyIcmNyLd()[i];
			if (dictionary.ContainsKey(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4()))
			{
				dictionary[#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4()].Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=);
			}
			else
			{
				dictionary[#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4()] = new List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=>
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=
				};
			}
		}
		try
		{
			List<string> list = new List<string>();
			object obj = this.#=zSV4$mlFB34WM;
			lock (obj)
			{
				List<int> list2 = new List<int>();
				for (int j = 0; j < #=zMEwuTGAUgTDD.Count; j++)
				{
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zMEwuTGAUgTDD[j];
					if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() > 0 || #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7())
					{
						list2.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4());
					}
				}
				for (int k = 0; k < #=zGFaDX7NUnXGa.Count; k++)
				{
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zGFaDX7NUnXGa[k];
					if (!#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=zsQC8qhbaqVU5q6hkHg==())
					{
						bool flag2 = list2.Contains(#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4());
						if (flag2 || #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=z_ePdViDI7p1r5Oy9Eg==())
						{
							Dictionary<int, int> dictionary2 = new Dictionary<int, int>();
							if (dictionary.ContainsKey(#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4()))
							{
								List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> list3 = dictionary[#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4()];
								for (int l = 0; l < list3.Count; l++)
								{
									#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2 = list3[l];
									if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4() == #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4() && !#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zrNIiQ09PozZW(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()) && #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()) && !this.#=zCL2byup68IyY(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zEpmJu0QO9VH_()))
									{
										int num = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==()[#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()];
										if (!flag2)
										{
											num--;
										}
										if (dictionary2.ContainsKey(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()))
										{
											num -= dictionary2[#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()];
										}
										if (num > 0)
										{
											#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==().Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2);
											if (dictionary2.ContainsKey(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()))
											{
												Dictionary<int, int> dictionary3 = dictionary2;
												int num2 = #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR();
												dictionary3[num2]++;
											}
											else
											{
												dictionary2[#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=2.#=zXAysPE5a2IRR()] = 1;
											}
										}
									}
								}
							}
						}
						else
						{
							#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=();
							List<int> list4 = new List<int>();
							if (dictionary.ContainsKey(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=ziV0Qa4zwZEC4()))
							{
								List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> list5 = dictionary[#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=ziV0Qa4zwZEC4()];
								for (int m = list5.Count - 1; m >= 0; m--)
								{
									#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3 = list5[m];
									if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zEpmJu0QO9VH_() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4() == #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=ziV0Qa4zwZEC4())
									{
										if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zXAysPE5a2IRR()))
										{
											list5.RemoveAt(m);
											this.#=zi9biyIcmNyLd().Remove(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3);
											#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=2 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=;
											int num2 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=2.#=zWiYm5yGEKz9k();
											#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=2.#=zL8wh3TkHC91d(num2 + 1);
											if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=z7Ss1uIfnRw1fbvsZpg==())
											{
												list.Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zMuFMjGQ=().ToString());
											}
										}
										else
										{
											list4.Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=3.#=zXAysPE5a2IRR());
										}
									}
								}
							}
							#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zSF$lIVazflq3(list4.Count);
							for (int n = 0; n < #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=z6ZIr13K_h_d4(); n++)
							{
								if (!#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(n) && !list4.Contains(n))
								{
									this.#=zi9biyIcmNyLd().Add(new #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=(Guid.NewGuid(), #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), #=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe(), #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==, n));
									#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=3 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=;
									int num2 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=3.#=z27qU0v2nVbmq();
									#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=3.#=zmveJs$A5$Bpd(num2 + 1);
								}
							}
						}
					}
				}
				for (int num3 = this.#=zi9biyIcmNyLd().Count - 1; num3 >= 0; num3--)
				{
					#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E= #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=4 = this.#=zi9biyIcmNyLd()[num3];
					if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=4.#=zEpmJu0QO9VH_() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && list2.Contains(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=4.#=zvx02C9X4TUpz().#=ziV0Qa4zwZEC4()))
					{
						this.#=zi9biyIcmNyLd().RemoveAt(num3);
						#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg= #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=4 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=;
						int num2 = #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=4.#=zWiYm5yGEKz9k();
						#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=4.#=zL8wh3TkHC91d(num2 + 1);
						if (#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=4.#=z7Ss1uIfnRw1fbvsZpg==())
						{
							list.Add(#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=4.#=zMuFMjGQ=().ToString());
						}
					}
				}
			}
			for (int num4 = 0; num4 < list.Count; num4++)
			{
				#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zGGL_CKcwA0bfABCwew==(this.#=zYgvZuBwR$a1C(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943039), list[num4], null);
			}
		}
		catch (Exception #=z$Ib9gYQ=)
		{
			#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zL5jsuAE=(#=z$Ib9gYQ=);
			#=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=.#=zeuby03ajdKyS073vzg==().Clear();
		}
		return #=zoQSSFsOKyY53xuekN0dLQIB$ardQ5jHAxWqraJg=;
	}

	// Token: 0x0600054D RID: 1357 RVA: 0x0002DFC4 File Offset: 0x0002C1C4
	private bool #=zCL2byup68IyY(int #=zvPiOyGQ=)
	{
		if (!this.#=zg6ol2CXXMmNJ21Ls0Q==.Contains(#=zvPiOyGQ=))
		{
			return false;
		}
		if (JSONManager.CurrentUTCDate().Day != this.#=z90PpFfY$9YqO_2AZmQ==.Day)
		{
			object obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zz$JYe0tjSWxT;
			lock (obj)
			{
				this.#=zg6ol2CXXMmNJ21Ls0Q==.Clear();
				this.#=z90PpFfY$9YqO_2AZmQ== = DateTime.MinValue;
			}
			return false;
		}
		return true;
	}

	// Token: 0x0600054E RID: 1358 RVA: 0x0002E040 File Offset: 0x0002C240
	public static void #=z318YUQXJBpE3(int #=zLeeSKrg=, int #=zvPiOyGQ=)
	{
		#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4= = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zi1hFJwI=(#=zLeeSKrg=);
		object obj = #=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zz$JYe0tjSWxT;
		lock (obj)
		{
			if (!#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zg6ol2CXXMmNJ21Ls0Q==.Contains(#=zvPiOyGQ=))
			{
				#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=zg6ol2CXXMmNJ21Ls0Q==.Add(#=zvPiOyGQ=);
			}
			if (#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=z90PpFfY$9YqO_2AZmQ== == DateTime.MinValue)
			{
				#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=.#=z90PpFfY$9YqO_2AZmQ== = JSONManager.CurrentUTCDate();
			}
		}
	}

	// Token: 0x04000211 RID: 529
	private int #=z$eM7GpXgW_KO8hkYHQ==;

	// Token: 0x04000212 RID: 530
	private List<#=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=> #=zhPN7yqrwKorL4AeTUQ==;

	// Token: 0x04000213 RID: 531
	private object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000214 RID: 532
	private DateTime #=zvrOVexdkkKIOSWZYOPZ6NZA=;

	// Token: 0x04000215 RID: 533
	private List<int> #=zg6ol2CXXMmNJ21Ls0Q==;

	// Token: 0x04000216 RID: 534
	private DateTime #=z90PpFfY$9YqO_2AZmQ==;

	// Token: 0x04000217 RID: 535
	private static List<#=zBSleL5r9oj28f68MpeVknWkErzkrnXlcOAD7$e4=> #=zjz3qsKoI_h4m = null;

	// Token: 0x04000218 RID: 536
	private static object #=zz$JYe0tjSWxT = new object();
}
