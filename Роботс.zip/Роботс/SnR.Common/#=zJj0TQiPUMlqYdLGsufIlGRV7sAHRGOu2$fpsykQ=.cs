﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Skink.SnR.Common.Managers;

// Token: 0x0200012F RID: 303
internal sealed class #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=
{
	// Token: 0x060007A3 RID: 1955 RVA: 0x0003E06C File Offset: 0x0003C26C
	public #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=()
	{
		this.#=zFIbAD3A= = new Dictionary<string, string>();
		#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=z5R0cG87q2Sh6(this.#=zFIbAD3A=, FileResources.TranslCommon);
		#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=z5R0cG87q2Sh6(this.#=zFIbAD3A=, FileResources.Translate);
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x0003E098 File Offset: 0x0003C298
	public string #=zt5hOKIs=(string #=zcpJ6bUA=)
	{
		if (string.IsNullOrEmpty(#=zcpJ6bUA=))
		{
			return #=zcpJ6bUA=;
		}
		string text = #=zcpJ6bUA=.ToLower();
		List<#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4> list = new List<#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4>();
		foreach (string text2 in this.#=zFIbAD3A=.Keys)
		{
			if (text.Contains(text2.ToLower()))
			{
				MatchCollection matchCollection = Regex.Matches(#=zcpJ6bUA=, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070320), text2), 1);
				for (int i = matchCollection.Count - 1; i >= 0; i--)
				{
					Match match = matchCollection[i];
					string text3 = this.#=zFIbAD3A=[text2];
					int num = #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zjx$VeEhY8Fa$(text2);
					int num2 = #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zjx$VeEhY8Fa$(match.Value);
					int num3 = #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zjx$VeEhY8Fa$(text3);
					if (num == num3 && num2 != num3)
					{
						text3 = #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zPytHvg8GILM7(text3, num2);
					}
					List<#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4> list2 = list;
					#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4 #=zORWCK7yGKLJ = new #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4();
					#=zORWCK7yGKLJ.#=zbrjKHU_JcYqa(match.Index);
					#=zORWCK7yGKLJ.#=zJppFtmQ=(match.Value);
					#=zORWCK7yGKLJ.#=z0zk5M2Q=(text3);
					list2.Add(#=zORWCK7yGKLJ);
				}
			}
		}
		if (list.Count > 0)
		{
			list.Sort();
			for (int j = list.Count - 1; j >= 1; j--)
			{
				int k = j - 1;
				while (k >= 0)
				{
					if (list[j].#=zAY1jOpC22BVU() < list[k].#=zAY1jOpC22BVU() + list[k].#=zm3q1j44=().Length)
					{
						if (list[j].#=zm3q1j44=().Length > list[k].#=zm3q1j44=().Length)
						{
							list.RemoveAt(k);
							break;
						}
						list.RemoveAt(j);
						break;
					}
					else
					{
						k--;
					}
				}
			}
			string text4 = #=zcpJ6bUA=;
			for (int l = list.Count - 1; l >= 0; l--)
			{
				#=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4 #=zORWCK7yGKLJ2 = list[l];
				try
				{
					text4 = text4.Substring(0, #=zORWCK7yGKLJ2.#=zAY1jOpC22BVU()) + #=zORWCK7yGKLJ2.#=zQUce44Q=() + text4.Substring(#=zORWCK7yGKLJ2.#=zAY1jOpC22BVU() + #=zORWCK7yGKLJ2.#=zm3q1j44=().Length);
				}
				catch (Exception)
				{
					throw;
				}
			}
			return text4;
		}
		return #=zcpJ6bUA=;
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x0003E2CC File Offset: 0x0003C4CC
	private static int #=zjx$VeEhY8Fa$(string #=zZQAkNI8=)
	{
		if (#=zZQAkNI8=.Length > 1 && char.IsUpper(#=zZQAkNI8=[1]))
		{
			return 2;
		}
		if (char.IsUpper(#=zZQAkNI8=[0]))
		{
			return 1;
		}
		return 0;
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x0003E2F8 File Offset: 0x0003C4F8
	private static string #=zPytHvg8GILM7(string #=zZQAkNI8=, int #=zaJaS1fI=)
	{
		if (#=zaJaS1fI= == 1)
		{
			return #=zZQAkNI8=.Substring(0, 1).ToUpper() + #=zZQAkNI8=.Substring(1).ToLower();
		}
		if (#=zaJaS1fI= == 2)
		{
			return #=zZQAkNI8=.ToUpper();
		}
		return #=zZQAkNI8=.ToLower();
	}

	// Token: 0x060007A7 RID: 1959 RVA: 0x0003E330 File Offset: 0x0003C530
	private static void #=z5R0cG87q2Sh6(Dictionary<string, string> #=zrnw7iZQ=, FileResources #=zD_0amNk=)
	{
		ReadFileManager readFileManager = new ReadFileManager(#=zD_0amNk=, true);
		while (readFileManager.NextLine())
		{
			string text = readFileManager.Read(null, 0);
			string value = readFileManager.Read(null, 1);
			if (!string.IsNullOrWhiteSpace(text) && !string.IsNullOrWhiteSpace(value))
			{
				#=zrnw7iZQ=[text] = value;
			}
		}
	}

	// Token: 0x04000484 RID: 1156
	private Dictionary<string, string> #=zFIbAD3A=;

	// Token: 0x02000130 RID: 304
	private sealed class #=zORWCK7yGKLJ4 : IComparable
	{
		// Token: 0x060007A9 RID: 1961 RVA: 0x0003E384 File Offset: 0x0003C584
		public int #=zAY1jOpC22BVU()
		{
			return this.#=z_lb89y8WQjmJVgoFhg==;
		}

		// Token: 0x060007AA RID: 1962 RVA: 0x0003E38C File Offset: 0x0003C58C
		public void #=zbrjKHU_JcYqa(int #=z$Ib9gYQ=)
		{
			this.#=z_lb89y8WQjmJVgoFhg== = #=z$Ib9gYQ=;
		}

		// Token: 0x060007AB RID: 1963 RVA: 0x0003E398 File Offset: 0x0003C598
		public string #=zm3q1j44=()
		{
			return this.#=zwpgklHEu4OzPnpOvVA==;
		}

		// Token: 0x060007AC RID: 1964 RVA: 0x0003E3A0 File Offset: 0x0003C5A0
		public void #=zJppFtmQ=(string #=z$Ib9gYQ=)
		{
			this.#=zwpgklHEu4OzPnpOvVA== = #=z$Ib9gYQ=;
		}

		// Token: 0x060007AD RID: 1965 RVA: 0x0003E3AC File Offset: 0x0003C5AC
		public string #=zQUce44Q=()
		{
			return this.#=z04kMZDI_mVpx0lkgqw==;
		}

		// Token: 0x060007AE RID: 1966 RVA: 0x0003E3B4 File Offset: 0x0003C5B4
		public void #=z0zk5M2Q=(string #=z$Ib9gYQ=)
		{
			this.#=z04kMZDI_mVpx0lkgqw== = #=z$Ib9gYQ=;
		}

		// Token: 0x060007AF RID: 1967 RVA: 0x0003E3C0 File Offset: 0x0003C5C0
		public int CompareTo(object #=zzHmvhNYN5X_r)
		{
			if (#=zzHmvhNYN5X_r is #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4)
			{
				return this.#=zAY1jOpC22BVU().CompareTo((#=zzHmvhNYN5X_r as #=zJj0TQiPUMlqYdLGsufIlGRV7sAHRGOu2$fpsykQ=.#=zORWCK7yGKLJ4).#=zAY1jOpC22BVU());
			}
			return -1;
		}

		// Token: 0x04000485 RID: 1157
		private int #=z_lb89y8WQjmJVgoFhg==;

		// Token: 0x04000486 RID: 1158
		private string #=zwpgklHEu4OzPnpOvVA==;

		// Token: 0x04000487 RID: 1159
		private string #=z04kMZDI_mVpx0lkgqw==;
	}
}
