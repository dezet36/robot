﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x0200011C RID: 284
internal class #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A== : AbstractType, IType, IIntID
{
	// Token: 0x060006DD RID: 1757 RVA: 0x00039C34 File Offset: 0x00037E34
	protected #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==(Entities #=z28tpVJA=) : base(#=z28tpVJA=)
	{
		this.#=zzdBW4vN6GeOP(new List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==>());
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x00039C48 File Offset: 0x00037E48
	protected #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==(Dictionary<string, object> #=z1YNp7IY=, Entities #=z28tpVJA=) : base(#=z1YNp7IY=, #=z28tpVJA=)
	{
		this.#=zzdBW4vN6GeOP(new List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==>());
		object[] array = JSONManager.GetArray(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060499));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== = new #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==((Dictionary<string, object>)array[i]);
				this.#=z2fOvUeiaHzR6().Add(#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==);
				if (!#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==.#=z_CUgG1uVO0_6ruY6OA==().ContainsKey(ResourceTypes.Schemas))
				{
					this.#=zSu9KeWYzFcmY5RKepg==(i + 1);
				}
			}
		}
	}

	// Token: 0x060006DF RID: 1759 RVA: 0x00039CBC File Offset: 0x00037EBC
	public List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==> #=z2fOvUeiaHzR6()
	{
		return this.#=z_c5$1iH1aVFBZJaO9ZRRwRQ=;
	}

	// Token: 0x060006E0 RID: 1760 RVA: 0x00039CC4 File Offset: 0x00037EC4
	public void #=zzdBW4vN6GeOP(List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==> #=z$Ib9gYQ=)
	{
		this.#=z_c5$1iH1aVFBZJaO9ZRRwRQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x060006E1 RID: 1761 RVA: 0x00039CD0 File Offset: 0x00037ED0
	public int #=zDpaLxYOl35uZaIePmg==()
	{
		return this.#=z$ArpdlFDidADVdFSIZFk6I4=;
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x00039CD8 File Offset: 0x00037ED8
	public void #=zSu9KeWYzFcmY5RKepg==(int #=z$Ib9gYQ=)
	{
		this.#=z$ArpdlFDidADVdFSIZFk6I4= = #=z$Ib9gYQ=;
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x00039CE4 File Offset: 0x00037EE4
	public int #=zaDKBEnk8Vsod()
	{
		return this.#=z2fOvUeiaHzR6().Count;
	}

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x060006E4 RID: 1764 RVA: 0x00039CF4 File Offset: 0x00037EF4
	public bool IsUpgradeable
	{
		get
		{
			return this.#=z2fOvUeiaHzR6().Count > 1;
		}
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x00039D04 File Offset: 0x00037F04
	public override List<ResourceTypes> RequireResources(int #=z5w6HcG4=)
	{
		List<ResourceTypes> list = new List<ResourceTypes>();
		if (this.#=z2fOvUeiaHzR6().Count < #=z5w6HcG4=)
		{
			return list;
		}
		#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== = this.#=z2fOvUeiaHzR6()[#=z5w6HcG4= - 1];
		foreach (ResourceTypes resourceTypes in #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==.#=z_CUgG1uVO0_6ruY6OA==().Keys)
		{
			if (#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==.#=z_CUgG1uVO0_6ruY6OA==()[resourceTypes] > 0)
			{
				list.Add(resourceTypes);
			}
		}
		return list;
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x00039D94 File Offset: 0x00037F94
	public TimeSpan #=zwX6NTlM=(int #=z5w6HcG4=)
	{
		if (this.#=z2fOvUeiaHzR6().Count >= #=z5w6HcG4=)
		{
			return this.#=z2fOvUeiaHzR6()[#=z5w6HcG4= - 1].#=zPHMvvJ8=();
		}
		return TimeSpan.Zero;
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x00039DC0 File Offset: 0x00037FC0
	internal new List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zdL$RcwsYpqvy()
	{
		if (this.#=z2fOvUeiaHzR6().Count > 0 && this.#=z2fOvUeiaHzR6()[0].#=z6Uo9D2yKen_Y().Count > 0)
		{
			return this.#=z2fOvUeiaHzR6()[0].#=z6Uo9D2yKen_Y();
		}
		return base.#=zdL$RcwsYpqvy();
	}

	// Token: 0x0400041A RID: 1050
	private List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==> #=z_c5$1iH1aVFBZJaO9ZRRwRQ=;

	// Token: 0x0400041B RID: 1051
	private int #=z$ArpdlFDidADVdFSIZFk6I4=;
}
