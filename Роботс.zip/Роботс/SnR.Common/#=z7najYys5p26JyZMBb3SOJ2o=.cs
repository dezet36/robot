﻿using System;

// Token: 0x02000097 RID: 151
internal sealed class #=z7najYys5p26JyZMBb3SOJ2o= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000413 RID: 1043 RVA: 0x000240B4 File Offset: 0x000222B4
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z6313TdZbrK_wqx0oeQ==;
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x000240BC File Offset: 0x000222BC
	internal override int #=zXiDCyaHY58$0()
	{
		return 4;
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x000240C0 File Offset: 0x000222C0
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871);
	}
}
