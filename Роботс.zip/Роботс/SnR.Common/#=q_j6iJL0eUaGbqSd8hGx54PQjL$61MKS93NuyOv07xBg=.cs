﻿using System;

// Token: 0x0200000F RID: 15
internal interface #=q_j6iJL0eUaGbqSd8hGx54PQjL$61MKS93NuyOv07xBg=<#=zm8PpuDU=> : #=qWIG9Q$RaV69Bu2dj8hDRy4SqXcgJ7fq5leQqIjDcou4=
{
	// Token: 0x06000035 RID: 53
	#=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<#=zm8PpuDU=> GetEnumerator();
}
