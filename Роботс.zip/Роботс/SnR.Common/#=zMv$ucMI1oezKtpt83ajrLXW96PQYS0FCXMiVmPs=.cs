﻿using System;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000166 RID: 358
internal sealed class #=zMv$ucMI1oezKtpt83ajrLXW96PQYS0FCXMiVmPs= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600098A RID: 2442 RVA: 0x0004E41C File Offset: 0x0004C61C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zJgBKL1dWlurwuFRt1A== = #=zuJjQ1XU=.#=z6IODMVzrU6HMa5LZg021HYs=();
	}

	// Token: 0x0600098B RID: 2443 RVA: 0x0004E438 File Offset: 0x0004C638
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==))
		{
			return;
		}
		#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== = this.#=zcDRV51Ut$7oP as #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==;
		MasterTask masterTask = #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.MasterTask;
		if ((#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.Options & TaskOptions.MasterIsSum) == TaskOptions.MasterIsSum && masterTask != null)
		{
			MasterTask obj = masterTask;
			lock (obj)
			{
				this.#=z165biSXmX9gR(#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==, masterTask);
				return;
			}
		}
		this.#=z165biSXmX9gR(#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==, masterTask);
	}

	// Token: 0x0600098C RID: 2444 RVA: 0x0004E4B8 File Offset: 0x0004C6B8
	private void #=z165biSXmX9gR(#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== #=zcTyyNys=, MasterTask #=zwcZwAIGe3vUR)
	{
		bool flag = (#=zcTyyNys=.Options & TaskOptions.MasterIsSum) == TaskOptions.MasterIsSum && #=zwcZwAIGe3vUR != null;
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031));
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961266), new object[]
		{
			#=zcTyyNys=.Details
		});
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy;
		if (flag)
		{
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy = (#=zwcZwAIGe3vUR.Task as #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==).#=z_tcU3ov4mZ9V().#=zTnMGkyA=();
		}
		else
		{
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy = #=zcTyyNys=.#=z_tcU3ov4mZ9V().#=zTnMGkyA=();
		}
		if (#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.#=z0zVhHqs=() <= 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961230), Array.Empty<object>());
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString(), Array.Empty<object>());
			return;
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961170), new object[]
		{
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.ToString()
		});
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.#=zcEn_SGQ=(this.#=z3yL5bKs=);
		if (#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.#=z0zVhHqs=() <= 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960889), Array.Empty<object>());
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString(), Array.Empty<object>());
			return;
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960849), new object[]
		{
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.ToString()
		});
		int num = this.#=zJgBKL1dWlurwuFRt1A==.#=zMbI49ITzPNVB();
		if (num <= 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960815), Array.Empty<object>());
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString(), Array.Empty<object>());
			return;
		}
		int num2 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zDDkQ_RdZgdNGO6OtyQ==();
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961009), new object[]
		{
			this.#=zJgBKL1dWlurwuFRt1A==.#=z1$GKSNmtfrzR(),
			num,
			num2
		});
		for (int i = #=zRq2AEW0okvKAl3LdOqWDdBwtgdy.Count - 1; i >= 0; i--)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[i];
			if (num > 0 && num2 > 0)
			{
				if (num < #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_())
				{
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(num);
				}
				if (num2 < #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_())
				{
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(num2);
				}
				num -= this.#=zJgBKL1dWlurwuFRt1A==.#=zC$WOVdQc1g7UCejyvB8Cj6s=(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_());
				num2 -= #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_();
			}
			else
			{
				#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.RemoveAt(i);
			}
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960943), new object[]
		{
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.ToString()
		});
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString(), Array.Empty<object>());
		if ((#=zcTyyNys=.Options & TaskOptions.MasterIsSum) != TaskOptions.MasterIsSum && (#=zcTyyNys=.Options & TaskOptions.PartialCompletionForbidden) == TaskOptions.PartialCompletionForbidden && #=zcTyyNys=.#=z_tcU3ov4mZ9V().#=z0zVhHqs=() > #=zRq2AEW0okvKAl3LdOqWDdBwtgdy.#=z0zVhHqs=())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962685), new object[]
			{
				#=zcTyyNys=.Details,
				#=zcTyyNys=.#=z_tcU3ov4mZ9V().ToString(),
				#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.ToString()
			});
			return;
		}
		for (int j = 0; j < #=zRq2AEW0okvKAl3LdOqWDdBwtgdy.Count; j++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2 = #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[j];
			string text = this.#=zBsXSanI=.#=zge7xsK2$r2DH(#=zcTyyNys=.#=zuFPZLKs=(), #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962583), new object[]
				{
					#=zcTyyNys=.Details,
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji(),
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_()
				});
				#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 = this.#=z3yL5bKs=;
				ResourceTypes #=zvRLj9WQ= = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zq2bPTdY=();
				#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2[#=zvRLj9WQ=] -= #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_();
				if (flag)
				{
					#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 = (#=zwcZwAIGe3vUR.Task as #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==).#=z_tcU3ov4mZ9V();
					#=zvRLj9WQ= = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zq2bPTdY=();
					#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2[#=zvRLj9WQ=] -= #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_();
				}
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962797), new object[]
				{
					#=zcTyyNys=.Details,
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji(),
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_(),
					JSONManager.Cut(text)
				});
			}
		}
	}

	// Token: 0x0400057F RID: 1407
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x04000580 RID: 1408
	private #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=zJgBKL1dWlurwuFRt1A==;
}
