﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000257 RID: 599
internal class #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU
{
	// Token: 0x06001220 RID: 4640 RVA: 0x0008B678 File Offset: 0x00089878
	public #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(int #=zAk8mKBk=, string #=z6QPrZ_4=)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zwXKUV2c=(#=z6QPrZ_4=);
		this.#=zl7MWJMmA$Ndn(false);
		this.#=zzbbVkXR8m6NtAvI_$w==(false);
		this.#=zX6Imgh3oJ9uf(0);
		this.#=zwThMQRtZmcVG(false);
	}

	// Token: 0x06001221 RID: 4641 RVA: 0x0008B6AC File Offset: 0x000898AC
	protected #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(int #=zAk8mKBk=, Dictionary<string, object> #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zwXKUV2c=(JSONManager.GetString(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071090), null));
		this.#=zl7MWJMmA$Ndn(false);
		this.#=zzbbVkXR8m6NtAvI_$w==(JSONManager.ExtractInt(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071080), 0) == 1);
		this.#=zX6Imgh3oJ9uf(JSONManager.GetInt(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071073), 0));
		this.#=zwThMQRtZmcVG(JSONManager.ExtractInt(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071071), 0) == 1);
	}

	// Token: 0x06001222 RID: 4642 RVA: 0x0008B730 File Offset: 0x00089930
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001223 RID: 4643 RVA: 0x0008B738 File Offset: 0x00089938
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001224 RID: 4644 RVA: 0x0008B744 File Offset: 0x00089944
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06001225 RID: 4645 RVA: 0x0008B74C File Offset: 0x0008994C
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001226 RID: 4646 RVA: 0x0008B758 File Offset: 0x00089958
	public bool #=zKHh25npqZrdn()
	{
		return this.#=zuJrwTMIp3ki63QX7Jg==;
	}

	// Token: 0x06001227 RID: 4647 RVA: 0x0008B760 File Offset: 0x00089960
	public void #=zl7MWJMmA$Ndn(bool #=z$Ib9gYQ=)
	{
		this.#=zuJrwTMIp3ki63QX7Jg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001228 RID: 4648 RVA: 0x0008B76C File Offset: 0x0008996C
	public bool #=zJVAdIDg9hSidub8$Uw==()
	{
		return this.#=z2pCOoSaXr7yChQZOEEnIpU4=;
	}

	// Token: 0x06001229 RID: 4649 RVA: 0x0008B774 File Offset: 0x00089974
	public void #=zzbbVkXR8m6NtAvI_$w==(bool #=z$Ib9gYQ=)
	{
		this.#=z2pCOoSaXr7yChQZOEEnIpU4= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600122A RID: 4650 RVA: 0x0008B780 File Offset: 0x00089980
	public int #=zgxqDXpkUbQpR()
	{
		return this.#=z7OUzlPc2VcO8k0Ul7bZ3yGg=;
	}

	// Token: 0x0600122B RID: 4651 RVA: 0x0008B788 File Offset: 0x00089988
	public void #=zX6Imgh3oJ9uf(int #=z$Ib9gYQ=)
	{
		this.#=z7OUzlPc2VcO8k0Ul7bZ3yGg= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600122C RID: 4652 RVA: 0x0008B794 File Offset: 0x00089994
	public bool #=z$NyihN71ouQU()
	{
		return this.#=zWnRK3yMmhs2e$R_lzg==;
	}

	// Token: 0x0600122D RID: 4653 RVA: 0x0008B79C File Offset: 0x0008999C
	public void #=zwThMQRtZmcVG(bool #=z$Ib9gYQ=)
	{
		this.#=zWnRK3yMmhs2e$R_lzg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600122E RID: 4654 RVA: 0x0008B7A8 File Offset: 0x000899A8
	public static #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zcBW$PBE=(int #=zAk8mKBk=, Dictionary<string, object> #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2)
	{
		#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = null;
		if (#=zAk8mKBk= >= 450 && #=zAk8mKBk= <= 459)
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = new #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2);
		}
		if (#=zAk8mKBk= >= 500 && #=zAk8mKBk= <= 599)
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = new #=zvCiVMNgNtjC2R7mKhkYRLd7k3BbU6ziltyIyIcjFonI1GENncUY65HY9xpgX(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2);
		}
		if (#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071060)))
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = new #=zP8oGWsB5Ry42JYXu8GYfc8JVNXPN8ynx1wb1krDoZ5nNMzEX$tV4FR0=(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2);
		}
		if (#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU != null)
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zl7MWJMmA$Ndn(true);
		}
		else
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = new #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2);
		}
		return #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU;
	}

	// Token: 0x0600122F RID: 4655 RVA: 0x0008B818 File Offset: 0x00089A18
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x04000A23 RID: 2595
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000A24 RID: 2596
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000A25 RID: 2597
	private bool #=zuJrwTMIp3ki63QX7Jg==;

	// Token: 0x04000A26 RID: 2598
	private bool #=z2pCOoSaXr7yChQZOEEnIpU4=;

	// Token: 0x04000A27 RID: 2599
	private int #=z7OUzlPc2VcO8k0Ul7bZ3yGg=;

	// Token: 0x04000A28 RID: 2600
	private bool #=zWnRK3yMmhs2e$R_lzg==;
}
