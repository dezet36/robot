﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

// Token: 0x020000B8 RID: 184
internal sealed class #=zA$x820juwG4ZcvMOSZ_0tW0xpc88JsipcA==<#=zQSoxQMk=> : BindingList<#=zQSoxQMk=>
{
	// Token: 0x060004DD RID: 1245 RVA: 0x00027F54 File Offset: 0x00026154
	public #=zA$x820juwG4ZcvMOSZ_0tW0xpc88JsipcA==() : base(new List<#=zQSoxQMk=>())
	{
		this.#=zdFcuY5qOSCbg3R8cng== = new Dictionary<Type, #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=>>();
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x00027F6C File Offset: 0x0002616C
	public #=zA$x820juwG4ZcvMOSZ_0tW0xpc88JsipcA==(IEnumerable<#=zQSoxQMk=> #=zDA$hi$I=) : base(new List<#=zQSoxQMk=>(#=zDA$hi$I=))
	{
		this.#=zdFcuY5qOSCbg3R8cng== = new Dictionary<Type, #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=>>();
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x060004DF RID: 1247 RVA: 0x00027F88 File Offset: 0x00026188
	protected override bool SupportsSortingCore
	{
		get
		{
			return true;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00027F8C File Offset: 0x0002618C
	protected override bool IsSortedCore
	{
		get
		{
			return this.#=zwKre7Ho=;
		}
	}

	// Token: 0x17000011 RID: 17
	// (get) Token: 0x060004E1 RID: 1249 RVA: 0x00027F94 File Offset: 0x00026194
	protected override PropertyDescriptor SortPropertyCore
	{
		get
		{
			return this.#=zOY$UO5o=;
		}
	}

	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00027F9C File Offset: 0x0002619C
	protected override ListSortDirection SortDirectionCore
	{
		get
		{
			return this.#=zhQESwX$hWQuE;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060004E3 RID: 1251 RVA: 0x00027FA4 File Offset: 0x000261A4
	protected override bool SupportsSearchingCore
	{
		get
		{
			return true;
		}
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x00027FA8 File Offset: 0x000261A8
	protected override void ApplySortCore(PropertyDescriptor #=zOWJ4bdA=, ListSortDirection #=zRGPJDz8=)
	{
		List<#=zQSoxQMk=> list = (List<#=zQSoxQMk=>)base.Items;
		Type propertyType = #=zOWJ4bdA=.PropertyType;
		#=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=> #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==;
		if (!this.#=zdFcuY5qOSCbg3R8cng==.TryGetValue(propertyType, out #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==))
		{
			#=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA== = new #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=>(#=zOWJ4bdA=, #=zRGPJDz8=);
			this.#=zdFcuY5qOSCbg3R8cng==.Add(propertyType, #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==);
		}
		#=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==.#=zgtrfwuEw1r5T(#=zOWJ4bdA=, #=zRGPJDz8=);
		list.Sort(#=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==);
		this.#=zOY$UO5o= = #=zOWJ4bdA=;
		this.#=zhQESwX$hWQuE = #=zRGPJDz8=;
		this.#=zwKre7Ho= = true;
		this.OnListChanged(new ListChangedEventArgs(ListChangedType.Reset, -1));
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x0002801C File Offset: 0x0002621C
	protected override void RemoveSortCore()
	{
		this.#=zwKre7Ho= = false;
		this.#=zOY$UO5o= = base.SortPropertyCore;
		this.#=zhQESwX$hWQuE = base.SortDirectionCore;
		this.OnListChanged(new ListChangedEventArgs(ListChangedType.Reset, -1));
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x0002804C File Offset: 0x0002624C
	protected override int FindCore(PropertyDescriptor #=zOWJ4bdA=, object #=zNraCe1Y=)
	{
		int count = base.Count;
		for (int i = 0; i < count; i++)
		{
			#=zQSoxQMk= #=zQSoxQMk= = base[i];
			if (#=zOWJ4bdA=.GetValue(#=zQSoxQMk=).Equals(#=zNraCe1Y=))
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x040001DD RID: 477
	private readonly Dictionary<Type, #=zdcwEfu5bVT_60S7G4oSdvplti5RK9BXlvA==<#=zQSoxQMk=>> #=zdFcuY5qOSCbg3R8cng==;

	// Token: 0x040001DE RID: 478
	private bool #=zwKre7Ho=;

	// Token: 0x040001DF RID: 479
	private ListSortDirection #=zhQESwX$hWQuE;

	// Token: 0x040001E0 RID: 480
	private PropertyDescriptor #=zOY$UO5o=;
}
