﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020000A9 RID: 169
internal sealed class #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== : IIntID
{
	// Token: 0x06000467 RID: 1127 RVA: 0x00025C8C File Offset: 0x00023E8C
	private #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==()
	{
		this.#=zJeGatw_CgS$C(null);
		this.#=z3y$Jd2Y9Ey5E((#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ==)0);
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x00025CA4 File Offset: 0x00023EA4
	public #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==(Dictionary<string, object> #=z$TDZW3l5UOpD, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		this.Id = JSONManager.ExtractInt(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
		this.#=zbGOyTZKS15Z7(new List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==>());
		object[] array = JSONManager.ExtractArray(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				this.#=zYzmhGhVKHiNP().Add(new #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==((#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM=)1, Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]), Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)])));
			}
		}
		this.#=zJeGatw_CgS$C(null);
		object[] array2 = JSONManager.ExtractArray(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
		if (array2 != null && array2.Length != 0)
		{
			this.#=zJeGatw_CgS$C(#=zlhLE8UQVU0AG.Find(Convert.ToInt32(array2[0])));
		}
		this.#=zwXKUV2c=(JSONManager.GetString(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		if (!string.IsNullOrEmpty(this.#=zkfqcY3I=()))
		{
			if (this.#=zkfqcY3I=().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060288)) && this.#=zUwo8b_GAemH0() != null)
			{
				this.#=zwXKUV2c=(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060260), this.#=zUwo8b_GAemH0().Name, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060244))));
			}
			else if (this.#=zkfqcY3I=().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062002)) && this.#=zUwo8b_GAemH0() != null)
			{
				this.#=zwXKUV2c=(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060260), this.#=zUwo8b_GAemH0().Name, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061980))));
			}
		}
		int num = JSONManager.ExtractInt(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), 0);
		this.#=z3y$Jd2Y9Ey5E((#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ==)((num >= 1 || num <= 3) ? num : 0));
		object[] array3 = JSONManager.ExtractArray(#=z$TDZW3l5UOpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
		this.#=zN$ZzBOHbXzEf(array3.Length);
		this.#=zpmbhfimGMj3U(new List<double>());
		foreach (Dictionary<string, object> dictionary2 in array3)
		{
			this.#=zjw43QGFcPyHH().Add(JSONManager.ExtractDouble(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), 0.0));
		}
	}

	// Token: 0x1700000E RID: 14
	// (get) Token: 0x06000469 RID: 1129 RVA: 0x00025EC8 File Offset: 0x000240C8
	// (set) Token: 0x0600046A RID: 1130 RVA: 0x00025ED0 File Offset: 0x000240D0
	public int Id
	{
		[CompilerGenerated]
		get
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = value;
		}
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x00025EDC File Offset: 0x000240DC
	public List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zYzmhGhVKHiNP()
	{
		return this.#=zaMYPAOK5yix6s1Xkew==;
	}

	// Token: 0x0600046C RID: 1132 RVA: 0x00025EE4 File Offset: 0x000240E4
	public void #=zbGOyTZKS15Z7(List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=z$Ib9gYQ=)
	{
		this.#=zaMYPAOK5yix6s1Xkew== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600046D RID: 1133 RVA: 0x00025EF0 File Offset: 0x000240F0
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00025EF8 File Offset: 0x000240F8
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600046F RID: 1135 RVA: 0x00025F04 File Offset: 0x00024104
	public int #=zaDKBEnk8Vsod()
	{
		return this.#=zvUGa2pYWJUtRMX01rHA$lx8=;
	}

	// Token: 0x06000470 RID: 1136 RVA: 0x00025F0C File Offset: 0x0002410C
	public void #=zN$ZzBOHbXzEf(int #=z$Ib9gYQ=)
	{
		this.#=zvUGa2pYWJUtRMX01rHA$lx8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000471 RID: 1137 RVA: 0x00025F18 File Offset: 0x00024118
	public UnitType #=zUwo8b_GAemH0()
	{
		return this.#=zuKh$S6mkKrHm45wV$A==;
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x00025F20 File Offset: 0x00024120
	public void #=zJeGatw_CgS$C(UnitType #=z$Ib9gYQ=)
	{
		this.#=zuKh$S6mkKrHm45wV$A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x00025F2C File Offset: 0x0002412C
	public #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ== #=zzasQXAPWhOif()
	{
		return this.#=zkanVdU4qSKZQX0s_fw==;
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x00025F34 File Offset: 0x00024134
	public void #=z3y$Jd2Y9Ey5E(#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ== #=z$Ib9gYQ=)
	{
		this.#=zkanVdU4qSKZQX0s_fw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000475 RID: 1141 RVA: 0x00025F40 File Offset: 0x00024140
	public List<double> #=zjw43QGFcPyHH()
	{
		return this.#=z$cjfMsOUZJUVVe7pGQ==;
	}

	// Token: 0x06000476 RID: 1142 RVA: 0x00025F48 File Offset: 0x00024148
	public void #=zpmbhfimGMj3U(List<double> #=z$Ib9gYQ=)
	{
		this.#=z$cjfMsOUZJUVVe7pGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x00025F54 File Offset: 0x00024154
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x040001A2 RID: 418
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040001A3 RID: 419
	private List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zaMYPAOK5yix6s1Xkew==;

	// Token: 0x040001A4 RID: 420
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040001A5 RID: 421
	private int #=zvUGa2pYWJUtRMX01rHA$lx8=;

	// Token: 0x040001A6 RID: 422
	private UnitType #=zuKh$S6mkKrHm45wV$A==;

	// Token: 0x040001A7 RID: 423
	private #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ== #=zkanVdU4qSKZQX0s_fw==;

	// Token: 0x040001A8 RID: 424
	private List<double> #=z$cjfMsOUZJUVVe7pGQ==;

	// Token: 0x020000AA RID: 170
	public enum #=z4wicdB5kowMyxyMssQ==
	{

	}
}
