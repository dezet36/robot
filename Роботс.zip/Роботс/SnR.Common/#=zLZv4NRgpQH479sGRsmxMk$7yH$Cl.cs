﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x0200014B RID: 331
internal sealed class #=zLZv4NRgpQH479sGRsmxMk$7yH$Cl
{
	// Token: 0x060008B2 RID: 2226
	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto, EntryPoint = "mouse_event")]
	private static extern void #=zG49dUVKBViH3(long #=zbYBHCz8=, long #=zK2auV_A=, long #=zOVVN9jE=, long #=zCJknCqY=, long #=zMf6J9$UUKzni);

	// Token: 0x060008B3 RID: 2227
	[DllImport("user32.dll", EntryPoint = "GetCursorPos")]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool #=zYprygYgOdTHD(out Point #=zlqk4epZzOL_0);

	// Token: 0x060008B4 RID: 2228
	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, EntryPoint = "SetCursorPos")]
	private static extern void #=zulvW624dHChD(int #=zun8AGdY=, int #=z3$DFSlM=);

	// Token: 0x060008B5 RID: 2229
	[DllImport("user32.dll", EntryPoint = "GetAsyncKeyState")]
	private static extern short #=zc4CIUOiSFXZD(ushort #=zwCWN4MKIyM4$);

	// Token: 0x060008B6 RID: 2230
	[DllImport("user32.dll", EntryPoint = "keybd_event")]
	public static extern void #=zH4vSF4y1TLQQvgWLDw==(Keys #=zXBWf8bg=, byte #=zHjygPI4=, uint #=zbYBHCz8=, IntPtr #=zMf6J9$UUKzni);

	// Token: 0x060008B7 RID: 2231 RVA: 0x0004525C File Offset: 0x0004345C
	public static void #=zPLItXsgUz88G()
	{
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zG49dUVKBViH3(2L, (long)Cursor.Position.X, (long)Cursor.Position.Y, 0L, 0L);
	}

	// Token: 0x060008B8 RID: 2232 RVA: 0x00045290 File Offset: 0x00043490
	public static void #=zo6ntM6yAH2Bd()
	{
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zG49dUVKBViH3(4L, (long)Cursor.Position.X, (long)Cursor.Position.Y, 0L, 0L);
	}

	// Token: 0x060008B9 RID: 2233 RVA: 0x000452C4 File Offset: 0x000434C4
	public static void #=z2iJ6iG4iXIPk()
	{
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zPLItXsgUz88G();
		Thread.Sleep(10);
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zo6ntM6yAH2Bd();
	}

	// Token: 0x060008BA RID: 2234 RVA: 0x000452D8 File Offset: 0x000434D8
	public static void #=znINu3Ds=(int #=zQrqFdos=, int #=zKFlJyLE=)
	{
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zulvW624dHChD(#=zQrqFdos=, #=zKFlJyLE=);
	}

	// Token: 0x060008BB RID: 2235 RVA: 0x000452E4 File Offset: 0x000434E4
	public static void #=zlpu4NA0=(string #=zNraCe1Y=)
	{
		#=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zH4vSF4y1TLQQvgWLDw==((Keys)((byte)char.ToUpper(#=zNraCe1Y=[0])), 0, 0U, IntPtr.Zero);
	}

	// Token: 0x060008BC RID: 2236 RVA: 0x00045300 File Offset: 0x00043500
	public static Point #=zqWBDCbloyCxV()
	{
		return Cursor.Position;
	}

	// Token: 0x060008BD RID: 2237 RVA: 0x00045308 File Offset: 0x00043508
	public static bool #=z3$DxRGbNgNar()
	{
		return #=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zc4CIUOiSFXZD(1) != 0;
	}

	// Token: 0x060008BE RID: 2238 RVA: 0x00045314 File Offset: 0x00043514
	public static bool #=zTaNgOi0gcSEB()
	{
		return #=zLZv4NRgpQH479sGRsmxMk$7yH$Cl.#=zc4CIUOiSFXZD(2) != 0;
	}
}
