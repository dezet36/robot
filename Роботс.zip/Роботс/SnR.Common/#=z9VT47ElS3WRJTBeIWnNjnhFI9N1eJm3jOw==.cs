﻿using System;
using System.Threading;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x020000B3 RID: 179
internal abstract class #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060004B2 RID: 1202 RVA: 0x00027658 File Offset: 0x00025858
	public Task #=zW3vCypudd9EC()
	{
		return this.#=zcDRV51Ut$7oP;
	}

	// Token: 0x060004B3 RID: 1203 RVA: 0x00027660 File Offset: 0x00025860
	public bool #=zAMo6bsJiXAdF()
	{
		return this.#=z2M2cw2q7wSj6LjFLkA==;
	}

	// Token: 0x060004B4 RID: 1204 RVA: 0x00027668 File Offset: 0x00025868
	private void #=z14XdfvhO2f8e(bool #=z$Ib9gYQ=)
	{
		this.#=z2M2cw2q7wSj6LjFLkA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x00027674 File Offset: 0x00025874
	public void #=znhayI43rZGmx(#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=z$Ib9gYQ=)
	{
		#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=zsIEBeRIWmuxA = this.#=zP_40nctu7wND;
		#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=zsIEBeRIWmuxA2;
		do
		{
			#=zsIEBeRIWmuxA2 = #=zsIEBeRIWmuxA;
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA value = (#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA)Delegate.Combine(#=zsIEBeRIWmuxA2, #=z$Ib9gYQ=);
			#=zsIEBeRIWmuxA = Interlocked.CompareExchange<#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA>(ref this.#=zP_40nctu7wND, value, #=zsIEBeRIWmuxA2);
		}
		while (#=zsIEBeRIWmuxA != #=zsIEBeRIWmuxA2);
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x000276AC File Offset: 0x000258AC
	public void #=zlX2W1eOIUgQN(#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=z$Ib9gYQ=)
	{
		#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=zsIEBeRIWmuxA = this.#=zP_40nctu7wND;
		#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=zsIEBeRIWmuxA2;
		do
		{
			#=zsIEBeRIWmuxA2 = #=zsIEBeRIWmuxA;
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA value = (#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA)Delegate.Remove(#=zsIEBeRIWmuxA2, #=z$Ib9gYQ=);
			#=zsIEBeRIWmuxA = Interlocked.CompareExchange<#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA>(ref this.#=zP_40nctu7wND, value, #=zsIEBeRIWmuxA2);
		}
		while (#=zsIEBeRIWmuxA != #=zsIEBeRIWmuxA2);
	}

	// Token: 0x060004B7 RID: 1207 RVA: 0x000276E4 File Offset: 0x000258E4
	public void #=zC68QI$8=(Task #=zI9YjZ6Url_ar, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=z7XHLyw43Uesm, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=, bool #=zCHbn2hfH3UKtUNPP0hes2P8=)
	{
		this.#=zcDRV51Ut$7oP = #=zI9YjZ6Url_ar;
		this.#=z8StzeqE= = #=z7XHLyw43Uesm.#=zQ4wZnctPyyRO();
		this.#=zG2wnL_q7IxpD = #=z7XHLyw43Uesm;
		this.#=zBsXSanI= = #=zuJjQ1XU=.#=z$2ijYGRf0FB5();
		this.#=z14XdfvhO2f8e(false);
		if ((this.#=zcDRV51Ut$7oP.Options & TaskOptions.NoDataRequired) != TaskOptions.NoDataRequired)
		{
			#=zuJjQ1XU=.#=zFgabd6AP3NvQ(#=zCHbn2hfH3UKtUNPP0hes2P8=);
			this.#=z20ohAjI=(#=zuJjQ1XU=);
		}
	}

	// Token: 0x060004B8 RID: 1208 RVA: 0x00027740 File Offset: 0x00025940
	public void #=zLdd2sonKJf6r(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z20ohAjI=(#=zuJjQ1XU=);
	}

	// Token: 0x060004B9 RID: 1209
	protected abstract void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=);

	// Token: 0x060004BA RID: 1210 RVA: 0x0002774C File Offset: 0x0002594C
	public void #=zryTcrns=()
	{
		if (this.#=zcDRV51Ut$7oP.Severity == TaskSeverities.Immediate)
		{
			try
			{
				this.#=zG2wnL_q7IxpD.#=zRzUen$zbM50ANV2TNA==(true);
				this.#=zvb5bnug=();
				goto IL_35;
			}
			finally
			{
				this.#=zG2wnL_q7IxpD.#=zRzUen$zbM50ANV2TNA==(false);
			}
		}
		this.#=zvb5bnug=();
		IL_35:
		this.#=z14XdfvhO2f8e(true);
	}

	// Token: 0x060004BB RID: 1211
	protected abstract void #=zvb5bnug=();

	// Token: 0x060004BC RID: 1212 RVA: 0x000277A8 File Offset: 0x000259A8
	protected void #=zL1HTbwC75LO$(string #=zQtK9D3Etaxd_)
	{
		this.#=zP_40nctu7wND(this, JSONManager.GetData(#=zQtK9D3Etaxd_), null);
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x000277C0 File Offset: 0x000259C0
	protected void #=zL1HTbwC75LO$(object #=zxheKPs0=)
	{
		this.#=zP_40nctu7wND(this, #=zxheKPs0=, null);
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x000277D0 File Offset: 0x000259D0
	protected void #=zgtwWGFUm$USb54cn9g==(string #=zRJiFeNQ=)
	{
		this.#=zP_40nctu7wND(this, null, #=zRJiFeNQ=);
	}

	// Token: 0x040001CA RID: 458
	protected Task #=zcDRV51Ut$7oP;

	// Token: 0x040001CB RID: 459
	protected #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x040001CC RID: 460
	protected #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD;

	// Token: 0x040001CD RID: 461
	protected #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=;

	// Token: 0x040001CE RID: 462
	private bool #=z2M2cw2q7wSj6LjFLkA==;

	// Token: 0x040001CF RID: 463
	private #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA #=zP_40nctu7wND;

	// Token: 0x020000B4 RID: 180
	// (Invoke) Token: 0x060004C0 RID: 1216
	public delegate void #=zsIEBeRIWmuxA(object #=zP95I7AY=, object #=zxheKPs0=, string #=zRJiFeNQ=);
}
