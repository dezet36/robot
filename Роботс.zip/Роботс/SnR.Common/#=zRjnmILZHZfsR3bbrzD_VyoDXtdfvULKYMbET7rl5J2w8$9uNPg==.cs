﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x02000193 RID: 403
internal sealed class #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg== : #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==
{
	// Token: 0x06000B8C RID: 2956 RVA: 0x000580CC File Offset: 0x000562CC
	public #=zRjnmILZHZfsR3bbrzD_VyoDXtdfvULKYMbET7rl5J2w8$9uNPg==(List<int> #=zXQMzb7mh2txD, DateTime #=zxSBcx18=) : base(TaskTypes.MassOccupation, #=zxSBcx18=)
	{
		this.#=zl_2MUhRMOgx1(#=zXQMzb7mh2txD);
		this.#=zVCFF8HtlCLvwqT1uMg==(new List<int>());
		this.#=zxWzbpjEcQs8w76rzkpX9Uij1bx7M(new List<int>());
		this.#=z3SeyW3eVI4x5(20);
		this.#=zEbGcWuqYeNLoFMwRyE9NV8NIDhJG(true);
		this.#=zXMiQx9iwgpDmvkKb$g==(-1);
	}

	// Token: 0x06000B8D RID: 2957 RVA: 0x0005810C File Offset: 0x0005630C
	public List<int> #=z1WDH323JMKY$()
	{
		return this.#=z5nFtxkBnNbS6AbUXwH0Wp3g=;
	}

	// Token: 0x06000B8E RID: 2958 RVA: 0x00058114 File Offset: 0x00056314
	public void #=zl_2MUhRMOgx1(List<int> #=z$Ib9gYQ=)
	{
		this.#=z5nFtxkBnNbS6AbUXwH0Wp3g= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B8F RID: 2959 RVA: 0x00058120 File Offset: 0x00056320
	public List<int> #=ziSW13U6hvpcgX8hDGQ==()
	{
		return this.#=zFSZusvSouK40SABxRUmf3kI=;
	}

	// Token: 0x06000B90 RID: 2960 RVA: 0x00058128 File Offset: 0x00056328
	public void #=zVCFF8HtlCLvwqT1uMg==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zFSZusvSouK40SABxRUmf3kI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B91 RID: 2961 RVA: 0x00058134 File Offset: 0x00056334
	public List<int> #=zq$FF1Xp_gWzjPg1dZmUhwxQ4W63k()
	{
		return this.#=zL4zjSX1FO4x2RZvYgeoKpY70Lb6a6qyHZA==;
	}

	// Token: 0x06000B92 RID: 2962 RVA: 0x0005813C File Offset: 0x0005633C
	public void #=zxWzbpjEcQs8w76rzkpX9Uij1bx7M(List<int> #=z$Ib9gYQ=)
	{
		this.#=zL4zjSX1FO4x2RZvYgeoKpY70Lb6a6qyHZA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B93 RID: 2963 RVA: 0x00058148 File Offset: 0x00056348
	public int #=zUR9k9kQY04fa()
	{
		return this.#=zoRqZZpbfrJAX$2XptgHzc9k=;
	}

	// Token: 0x06000B94 RID: 2964 RVA: 0x00058150 File Offset: 0x00056350
	public void #=z3SeyW3eVI4x5(int #=z$Ib9gYQ=)
	{
		this.#=zoRqZZpbfrJAX$2XptgHzc9k= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B95 RID: 2965 RVA: 0x0005815C File Offset: 0x0005635C
	public bool #=z7JFejtRJqjAeXQAJwSKlDTTnS2Bn()
	{
		return this.#=zwbhrFBLTy2lEUvCRUago4hYqgAEveK08P8CXPnk=;
	}

	// Token: 0x06000B96 RID: 2966 RVA: 0x00058164 File Offset: 0x00056364
	public void #=zEbGcWuqYeNLoFMwRyE9NV8NIDhJG(bool #=z$Ib9gYQ=)
	{
		this.#=zwbhrFBLTy2lEUvCRUago4hYqgAEveK08P8CXPnk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B97 RID: 2967 RVA: 0x00058170 File Offset: 0x00056370
	public int #=zwhK$$GndvTzZNGp_qw==()
	{
		return this.#=zkbN_X2KPX$jX9YO9qAFnh8o=;
	}

	// Token: 0x06000B98 RID: 2968 RVA: 0x00058178 File Offset: 0x00056378
	public void #=zXMiQx9iwgpDmvkKb$g==(int #=z$Ib9gYQ=)
	{
		this.#=zkbN_X2KPX$jX9YO9qAFnh8o= = #=z$Ib9gYQ=;
	}

	// Token: 0x0400063C RID: 1596
	private List<int> #=z5nFtxkBnNbS6AbUXwH0Wp3g=;

	// Token: 0x0400063D RID: 1597
	private List<int> #=zFSZusvSouK40SABxRUmf3kI=;

	// Token: 0x0400063E RID: 1598
	private List<int> #=zL4zjSX1FO4x2RZvYgeoKpY70Lb6a6qyHZA==;

	// Token: 0x0400063F RID: 1599
	private int #=zoRqZZpbfrJAX$2XptgHzc9k=;

	// Token: 0x04000640 RID: 1600
	private bool #=zwbhrFBLTy2lEUvCRUago4hYqgAEveK08P8CXPnk=;

	// Token: 0x04000641 RID: 1601
	private int #=zkbN_X2KPX$jX9YO9qAFnh8o=;
}
