﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x02000185 RID: 389
internal sealed class #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= : Dictionary<int, #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=>
{
	// Token: 0x1700002B RID: 43
	[IndexerName("#=zx6APBRk=")]
	public #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= this[int #=zKsBeX6RmAuZq]
	{
		get
		{
			if (base.ContainsKey(#=zKsBeX6RmAuZq))
			{
				return base[#=zKsBeX6RmAuZq];
			}
			return new #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=(#=zKsBeX6RmAuZq);
		}
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x000561F4 File Offset: 0x000543F4
	public void #=zU0JAE58=(#=zesBR9QdKGIBsSHNpxZRXyrToxyjs2cT1owEG06E= #=zPS7bOFE=)
	{
		#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=;
		if (!base.ContainsKey(#=zPS7bOFE=.#=z9$XFwTaUKMJD()))
		{
			#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= = new #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=(#=zPS7bOFE=.#=z9$XFwTaUKMJD());
			base.Add(#=zPS7bOFE=.#=z9$XFwTaUKMJD(), #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=);
		}
		else
		{
			#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= = this[#=zPS7bOFE=.#=z9$XFwTaUKMJD()];
		}
		#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=z48rEd0A=(#=zPS7bOFE=.#=zTmF_oj8L9Zp6(), #=zPS7bOFE=.#=z_0mmdVV3_scA());
	}
}
