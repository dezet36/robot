﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000035 RID: 53
internal sealed class #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=
{
	// Token: 0x060001BF RID: 447 RVA: 0x000125E4 File Offset: 0x000107E4
	public #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=(Dictionary<string, object> #=zdA6UEifL_mcyeC_FqVX5FR0=, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		this.#=zzQwUIEs=((#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs=)JSONManager.ExtractInt(#=zdA6UEifL_mcyeC_FqVX5FR0=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), -1));
		this.#=zLNM6_FpNs$Ws(new UnitSquadCollection());
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zdA6UEifL_mcyeC_FqVX5FR0=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970338));
		if (dictionary != null)
		{
			foreach (string text in dictionary.Keys)
			{
				this.#=zDy8wm$yKq8XD().AddUnits(text, Convert.ToInt32(dictionary[text]), #=zlhLE8UQVU0AG);
			}
		}
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x00012688 File Offset: 0x00010888
	public #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x00012690 File Offset: 0x00010890
	public void #=zzQwUIEs=(#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0001269C File Offset: 0x0001089C
	public UnitSquadCollection #=zDy8wm$yKq8XD()
	{
		return this.#=zH68$xslqIYbV8rfxLg==;
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x000126A4 File Offset: 0x000108A4
	public void #=zLNM6_FpNs$Ws(UnitSquadCollection #=z$Ib9gYQ=)
	{
		this.#=zH68$xslqIYbV8rfxLg== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000062 RID: 98
	private #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x04000063 RID: 99
	private UnitSquadCollection #=zH68$xslqIYbV8rfxLg==;

	// Token: 0x02000036 RID: 54
	public enum #=zArez$Gs=
	{

	}
}
