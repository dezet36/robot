﻿using System;

// Token: 0x02000038 RID: 56
internal sealed class #=z0oP_Gzwu3QY8IgOeVPcrdaUSYxh47naOYg==
{
	// Token: 0x060001CD RID: 461 RVA: 0x000127B8 File Offset: 0x000109B8
	public int #=zaDKBEnk8Vsod()
	{
		return this.#=zvUGa2pYWJUtRMX01rHA$lx8=;
	}

	// Token: 0x060001CE RID: 462 RVA: 0x000127C0 File Offset: 0x000109C0
	public void #=zN$ZzBOHbXzEf(int #=z$Ib9gYQ=)
	{
		this.#=zvUGa2pYWJUtRMX01rHA$lx8= = #=z$Ib9gYQ=;
	}

	// Token: 0x060001CF RID: 463 RVA: 0x000127CC File Offset: 0x000109CC
	public double #=zJYKibYVjSOeP()
	{
		return this.#=zenXSweNSr82Tj_mGqpKOFs8=;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x000127D4 File Offset: 0x000109D4
	public void #=zgBlL3_zh1lX8(double #=z$Ib9gYQ=)
	{
		this.#=zenXSweNSr82Tj_mGqpKOFs8= = #=z$Ib9gYQ=;
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x000127E0 File Offset: 0x000109E0
	public double #=z7oFO_AGnloVR()
	{
		return this.#=ziWjjCF2ON6c1TSFtcZclzXs=;
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x000127E8 File Offset: 0x000109E8
	public void #=zpnk5VVbxf0Sq(double #=z$Ib9gYQ=)
	{
		this.#=ziWjjCF2ON6c1TSFtcZclzXs= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000067 RID: 103
	private int #=zvUGa2pYWJUtRMX01rHA$lx8=;

	// Token: 0x04000068 RID: 104
	private double #=zenXSweNSr82Tj_mGqpKOFs8=;

	// Token: 0x04000069 RID: 105
	private double #=ziWjjCF2ON6c1TSFtcZclzXs=;
}
