﻿using System;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;
using NExcel.Read.Biff;

// Token: 0x02000074 RID: 116
internal sealed class #=z5jeE6bKUUm6$P8GX1rIIQpA= : CellValue
{
	// Token: 0x06000356 RID: 854 RVA: 0x0001ED94 File Offset: 0x0001CF94
	public #=z5jeE6bKUUm6$P8GX1rIIQpA=(Record #=zJce$Sys=, File #=zDI_c6jkXGlFD, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, SheetImpl #=z99eVqbg=, WorkbookSettings #=z4JisLog=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zD$g7FD8= = false;
		if ((IntegerHelper.getInt(data[14], data[15]) & 8) != 0)
		{
			this.#=zD$g7FD8= = true;
			if (data[6] == 0 && data[12] == -1 && data[13] == -1)
			{
				this.#=zdsV3iBbBdGzM = new SharedStringFormulaRecord(#=zJce$Sys=, #=zDI_c6jkXGlFD, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=, #=z4JisLog=);
				return;
			}
			double ieeedouble = DoubleHelper.getIEEEDouble(data, 6);
			this.#=zdsV3iBbBdGzM = new SharedNumberFormulaRecord(#=zJce$Sys=, #=zDI_c6jkXGlFD, ieeedouble, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
			return;
		}
		else
		{
			if (data[6] == 0 && data[12] == -1 && data[13] == -1)
			{
				this.#=zdsV3iBbBdGzM = new #=zwtugAe3xOrqZspXM80zce99afvKa(#=zJce$Sys=, #=zDI_c6jkXGlFD, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=, #=z4JisLog=);
				return;
			}
			if (data[6] == 1 && data[12] == -1 && data[13] == -1)
			{
				this.#=zdsV3iBbBdGzM = new #=zWtqvncUGnSJ_BQ4yLgYhygVKqw42(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
				return;
			}
			if (data[6] == 2 && data[12] == -1 && data[13] == -1)
			{
				this.#=zdsV3iBbBdGzM = new #=zVXBfuY4zvMANDSH8k_VnXPmMVn$_(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
				return;
			}
			this.#=zdsV3iBbBdGzM = new #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
			return;
		}
	}

	// Token: 0x06000357 RID: 855 RVA: 0x0001EEAC File Offset: 0x0001D0AC
	public #=z5jeE6bKUUm6$P8GX1rIIQpA=(Record #=zJce$Sys=, File #=zDI_c6jkXGlFD, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=z7xrpmUJWupDo #=zH2f5zJg=, SheetImpl #=z99eVqbg=, WorkbookSettings #=z4JisLog=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zD$g7FD8= = false;
		if (data[6] == 0 && data[12] == -1 && data[13] == -1)
		{
			this.#=zdsV3iBbBdGzM = new #=zwtugAe3xOrqZspXM80zce99afvKa(#=zJce$Sys=, #=zDI_c6jkXGlFD, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=, #=z4JisLog=);
			return;
		}
		if (data[6] == 1 && data[12] == -1 && data[13] == -1)
		{
			this.#=zdsV3iBbBdGzM = new #=zWtqvncUGnSJ_BQ4yLgYhygVKqw42(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
			return;
		}
		if (data[6] == 2 && data[12] == -1 && data[13] == -1)
		{
			this.#=zdsV3iBbBdGzM = new #=zVXBfuY4zvMANDSH8k_VnXPmMVn$_(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
			return;
		}
		this.#=zdsV3iBbBdGzM = new #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z(#=zJce$Sys=, #=zrRXQAB8=, #=z8MJaPcg=, #=z94tQSvc=, #=z99eVqbg=);
	}

	// Token: 0x06000358 RID: 856 RVA: 0x0001EF64 File Offset: 0x0001D164
	static #=z5jeE6bKUUm6$P8GX1rIIQpA=()
	{
		#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zJLdzGuI= = Logger.getLogger(typeof(#=z5jeE6bKUUm6$P8GX1rIIQpA=));
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x06000359 RID: 857 RVA: 0x0001EF84 File Offset: 0x0001D184
	public new string Contents
	{
		get
		{
			Assert.verify(false);
			return string.Empty;
		}
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600035A RID: 858 RVA: 0x0001EF94 File Offset: 0x0001D194
	public new CellType Type
	{
		get
		{
			Assert.verify(false);
			return CellType.EMPTY;
		}
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0001EFA4 File Offset: 0x0001D1A4
	internal CellValue #=zmUYpUBj2v7o$()
	{
		return this.#=zdsV3iBbBdGzM;
	}

	// Token: 0x0600035C RID: 860 RVA: 0x0001EFAC File Offset: 0x0001D1AC
	internal bool #=zXuAoZ_2JHdw6()
	{
		return this.#=zD$g7FD8=;
	}

	// Token: 0x0400012C RID: 300
	private static Logger #=zJLdzGuI=;

	// Token: 0x0400012D RID: 301
	private CellValue #=zdsV3iBbBdGzM;

	// Token: 0x0400012E RID: 302
	private bool #=zD$g7FD8=;

	// Token: 0x0400012F RID: 303
	public static readonly #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=z7xrpmUJWupDo #=zVg7jYRh8fpFz = new #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=z7xrpmUJWupDo();

	// Token: 0x02000075 RID: 117
	public sealed class #=z7xrpmUJWupDo
	{
	}
}
