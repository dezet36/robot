﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x0200022F RID: 559
internal sealed class #=ze_OEBfpX9a85CAhsSkIMRcc= : CellValue, NumberCell, Cell
{
	// Token: 0x06001120 RID: 4384 RVA: 0x000836E8 File Offset: 0x000818E8
	public #=ze_OEBfpX9a85CAhsSkIMRcc=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		int @int = IntegerHelper.getInt(data[6], data[7], data[8], data[9]);
		this.#=zaiKvawI= = #=z64XUyGjGhI3yrQ01k8oOgQI=.#=zeTioEPI=(@int);
		this.#=zL0TJcHA= = #=zrRXQAB8=.getNumberFormat(this.XFIndex);
		if (this.#=zL0TJcHA= == null)
		{
			this.#=zL0TJcHA= = #=ze_OEBfpX9a85CAhsSkIMRcc=.#=zk9NtXlk=;
		}
	}

	// Token: 0x17000050 RID: 80
	// (get) Token: 0x06001122 RID: 4386 RVA: 0x00083768 File Offset: 0x00081968
	public double DoubleValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000051 RID: 81
	// (get) Token: 0x06001123 RID: 4387 RVA: 0x00083770 File Offset: 0x00081970
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000052 RID: 82
	// (get) Token: 0x06001124 RID: 4388 RVA: 0x00083780 File Offset: 0x00081980
	public new string Contents
	{
		get
		{
			return string.Format(this.#=zL0TJcHA=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zaiKvawI=);
		}
	}

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x06001125 RID: 4389 RVA: 0x000837A4 File Offset: 0x000819A4
	public new CellType Type
	{
		get
		{
			return CellType.NUMBER;
		}
	}

	// Token: 0x17000054 RID: 84
	// (get) Token: 0x06001126 RID: 4390 RVA: 0x000837AC File Offset: 0x000819AC
	public NumberFormatInfo NumberFormat
	{
		get
		{
			return this.#=zL0TJcHA=;
		}
	}

	// Token: 0x04000945 RID: 2373
	private double #=zaiKvawI=;

	// Token: 0x04000946 RID: 2374
	private NumberFormatInfo #=zL0TJcHA=;

	// Token: 0x04000947 RID: 2375
	private static NumberFormatInfo #=zk9NtXlk= = new NumberFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077254));
}
