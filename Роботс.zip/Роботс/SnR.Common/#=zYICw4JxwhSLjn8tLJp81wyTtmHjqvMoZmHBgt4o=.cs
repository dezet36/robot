﻿using System;
using System.Collections.Generic;

// Token: 0x020001DB RID: 475
internal sealed class #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= : List<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=>
{
	// Token: 0x06000E5F RID: 3679 RVA: 0x000722DC File Offset: 0x000704DC
	public #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=(object[] #=zolrauWvq6MMq20Njog==)
	{
		this.#=zedEhxKvFLBN7(0);
		if (#=zolrauWvq6MMq20Njog== != null)
		{
			foreach (Dictionary<string, object> dictionary in #=zolrauWvq6MMq20Njog==)
			{
				int num = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053)]);
				if (num > 0)
				{
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = new #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=();
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zbsxKkj4=(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zedb$WwBQsoJF(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zFzGvi_S6jJhE(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zg8A$A1dlfoa2(num);
					#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=2 = #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=;
					if (#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=2.#=zMuFMjGQ=() > this.#=z67H61Z2JvfqL())
					{
						this.#=zedEhxKvFLBN7(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=2.#=zMuFMjGQ=());
					}
					base.Add(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=2);
				}
			}
		}
	}

	// Token: 0x06000E60 RID: 3680 RVA: 0x000723B4 File Offset: 0x000705B4
	public int #=z67H61Z2JvfqL()
	{
		return this.#=zGE98Bc6dRfzYRLEfmA==;
	}

	// Token: 0x06000E61 RID: 3681 RVA: 0x000723BC File Offset: 0x000705BC
	public void #=zedEhxKvFLBN7(int #=z$Ib9gYQ=)
	{
		this.#=zGE98Bc6dRfzYRLEfmA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040007FE RID: 2046
	private int #=zGE98Bc6dRfzYRLEfmA==;
}
