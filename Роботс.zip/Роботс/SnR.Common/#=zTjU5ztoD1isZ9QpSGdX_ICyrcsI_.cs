﻿using System;

// Token: 0x020001A4 RID: 420
internal interface #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000CBD RID: 3261
	int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=);
}
