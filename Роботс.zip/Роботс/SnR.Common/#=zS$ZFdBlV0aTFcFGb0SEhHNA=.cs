﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200019B RID: 411
internal sealed class #=zS$ZFdBlV0aTFcFGb0SEhHNA= : RecordData
{
	// Token: 0x06000BF6 RID: 3062 RVA: 0x00061CFC File Offset: 0x0005FEFC
	public #=zS$ZFdBlV0aTFcFGb0SEhHNA=(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		sbyte b = data[0];
		sbyte b2 = data[1];
		this.#=zi5aypbQ= = ((b2 & 2) != 0);
		this.#=zouPGUIZav$PP = ((b & 2) != 0);
		this.#=zr99CfiM9SICM = ((b & 16) != 0);
		this.#=zNhqs8blzy1aU = ((b & 8) != 0);
		this.#=z30PMzMKDxFNw = ((b2 & 1) != 0);
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x00061D5C File Offset: 0x0005FF5C
	public bool #=zorMnuW6fR23C()
	{
		return this.#=zi5aypbQ=;
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x00061D64 File Offset: 0x0005FF64
	public bool #=z6Okbw7uRmNbHB_lzMg==()
	{
		return this.#=zouPGUIZav$PP;
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x00061D6C File Offset: 0x0005FF6C
	public bool #=ztmCn$_skNFjwu5baZw==()
	{
		return this.#=zr99CfiM9SICM;
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x00061D74 File Offset: 0x0005FF74
	public bool #=zMJid0aWBDl5P()
	{
		return this.#=zNhqs8blzy1aU;
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x00061D7C File Offset: 0x0005FF7C
	public bool #=zbd8XKGnwOE3o()
	{
		return this.#=z30PMzMKDxFNw;
	}

	// Token: 0x040006EA RID: 1770
	private bool #=zi5aypbQ=;

	// Token: 0x040006EB RID: 1771
	private bool #=zouPGUIZav$PP;

	// Token: 0x040006EC RID: 1772
	private bool #=zr99CfiM9SICM;

	// Token: 0x040006ED RID: 1773
	private bool #=zNhqs8blzy1aU;

	// Token: 0x040006EE RID: 1774
	private bool #=z30PMzMKDxFNw;
}
