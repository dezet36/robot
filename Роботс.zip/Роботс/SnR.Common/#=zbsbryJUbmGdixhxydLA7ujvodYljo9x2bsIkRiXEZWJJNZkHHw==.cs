﻿using System;

// Token: 0x0200020D RID: 525
internal sealed class #=zbsbryJUbmGdixhxydLA7ujvodYljo9x2bsIkRiXEZWJJNZkHHw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001015 RID: 4117 RVA: 0x0007BF8C File Offset: 0x0007A18C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zHlPhtrw= = #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zKVN4CRU=();
		this.#=zHlPhtrw=.#=z20ohAjI=(#=zuJjQ1XU=);
	}

	// Token: 0x06001016 RID: 4118 RVA: 0x0007BFA8 File Offset: 0x0007A1A8
	protected override void #=zvb5bnug=()
	{
		this.#=zHlPhtrw=.#=zEGKDsXI=();
	}

	// Token: 0x040008DF RID: 2271
	private #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV #=zHlPhtrw=;
}
