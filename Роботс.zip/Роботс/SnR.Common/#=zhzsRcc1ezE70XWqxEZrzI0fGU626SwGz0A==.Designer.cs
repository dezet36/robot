﻿// Token: 0x02000258 RID: 600
internal sealed partial class #=zhzsRcc1ezE70XWqxEZrzI0fGU626SwGz0A== : global::System.Windows.Forms.Form
{
	// Token: 0x06001232 RID: 4658 RVA: 0x0008B87C File Offset: 0x00089A7C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000A2A RID: 2602
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
