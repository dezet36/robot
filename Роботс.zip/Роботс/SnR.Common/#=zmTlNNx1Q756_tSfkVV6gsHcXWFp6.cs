﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x02000289 RID: 649
internal class #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6 : EscherRecord
{
	// Token: 0x060013BA RID: 5050 RVA: 0x00097F18 File Offset: 0x00096118
	public #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
	}

	// Token: 0x060013BB RID: 5051 RVA: 0x00097F24 File Offset: 0x00096124
	protected internal #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6(EscherRecordType #=zvRLj9WQ=) : base(#=zvRLj9WQ=)
	{
	}

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060013BC RID: 5052 RVA: 0x00097F30 File Offset: 0x00096130
	public override sbyte[] Data
	{
		get
		{
			sbyte[] #=zdqSpY9Q= = new sbyte[0];
			return base.#=zkDlCfm_Lhg38(#=zdqSpY9Q=);
		}
	}
}
