﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;

// Token: 0x02000295 RID: 661
internal sealed class #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==
{
	// Token: 0x06001424 RID: 5156 RVA: 0x0009A2C8 File Offset: 0x000984C8
	private #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==(Dictionary<int, List<string>> #=zBqZJQcvCg4kC)
	{
		this.#=ztSZjqSp2NFqC(#=zBqZJQcvCg4kC);
	}

	// Token: 0x06001425 RID: 5157 RVA: 0x0009A2D8 File Offset: 0x000984D8
	public #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==(Dictionary<string, object> #=z1$25lUQ=)
	{
		this.#=ztSZjqSp2NFqC(new Dictionary<int, List<string>>());
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z1$25lUQ=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
		if (dictionary != null)
		{
			foreach (string text in dictionary.Keys)
			{
				int key;
				if (int.TryParse(text, out key))
				{
					object[] array = JSONManager.ExtractArray(dictionary, text);
					List<string> list = new List<string>();
					foreach (string item in array)
					{
						list.Add(item);
					}
					this.#=zrgkRa73Q1vyY()[key] = list;
				}
			}
		}
	}

	// Token: 0x06001426 RID: 5158 RVA: 0x0009A394 File Offset: 0x00098594
	public Dictionary<int, List<string>> #=zrgkRa73Q1vyY()
	{
		return this.#=zG$Vzk8djrg6XPfeAEpUVFIw=;
	}

	// Token: 0x06001427 RID: 5159 RVA: 0x0009A39C File Offset: 0x0009859C
	public void #=ztSZjqSp2NFqC(Dictionary<int, List<string>> #=z$Ib9gYQ=)
	{
		this.#=zG$Vzk8djrg6XPfeAEpUVFIw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001428 RID: 5160 RVA: 0x0009A3A8 File Offset: 0x000985A8
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		foreach (int key in this.#=zrgkRa73Q1vyY().Keys)
		{
			dictionary.Add(key.ToString(), JSONManager.ListToArr(this.#=zrgkRa73Q1vyY()[key]));
		}
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				dictionary
			}
		};
	}

	// Token: 0x06001429 RID: 5161 RVA: 0x0009A434 File Offset: 0x00098634
	public static #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=zi1hFJwI=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=)
	{
		Dictionary<int, List<string>> dictionary = new Dictionary<int, List<string>>();
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zhoOF5s8=.#=zol80P7TKoihZ())
		{
			List<string> list = new List<string>();
			list.AddRange(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.Tags);
			list.Remove(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ());
			dictionary.Add(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C(), list);
		}
		return new #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==(dictionary);
	}

	// Token: 0x0600142A RID: 5162 RVA: 0x0009A4B8 File Offset: 0x000986B8
	public List<string> #=zDjNT3rYo21p5()
	{
		if (this.#=zNFuwlVN9yPnP == null)
		{
			this.#=zNFuwlVN9yPnP = new List<string>();
			foreach (List<string> list in this.#=zrgkRa73Q1vyY().Values)
			{
				foreach (string item in list)
				{
					if (!this.#=zNFuwlVN9yPnP.Contains(item))
					{
						this.#=zNFuwlVN9yPnP.Add(item);
					}
				}
			}
		}
		return this.#=zNFuwlVN9yPnP;
	}

	// Token: 0x0600142B RID: 5163 RVA: 0x0009A574 File Offset: 0x00098774
	private static bool #=zloDul58=(#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=znDO_TqloIczN, #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zdbYdBaIe_8qx)
	{
		#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== = #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zi1hFJwI=(#=zdbYdBaIe_8qx);
		using (Dictionary<int, List<string>>.KeyCollection.Enumerator enumerator = #=znDO_TqloIczN.#=zrgkRa73Q1vyY().Keys.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zr_yosI_ImfoCYek4BdK6O1U= #=zr_yosI_ImfoCYek4BdK6O1U= = new #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zr_yosI_ImfoCYek4BdK6O1U=();
				#=zr_yosI_ImfoCYek4BdK6O1U=.#=zLeeSKrg= = enumerator.Current;
				if (#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zrgkRa73Q1vyY().ContainsKey(#=zr_yosI_ImfoCYek4BdK6O1U=.#=zLeeSKrg=))
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zdbYdBaIe_8qx.#=zol80P7TKoihZ().Find(new Predicate<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>(#=zr_yosI_ImfoCYek4BdK6O1U=.#=zpGy6NO9YvDRsGtJAAg==));
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== != null && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zq76JuU9WPIZn())
					{
						List<string> list = #=znDO_TqloIczN.#=zrgkRa73Q1vyY()[#=zr_yosI_ImfoCYek4BdK6O1U=.#=zLeeSKrg=];
						List<string> list2 = #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zrgkRa73Q1vyY()[#=zr_yosI_ImfoCYek4BdK6O1U=.#=zLeeSKrg=];
						foreach (string item in list)
						{
							if (!list2.Contains(item))
							{
								return false;
							}
							list2.Remove(item);
						}
						if (list2.Count > 0)
						{
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	// Token: 0x0600142C RID: 5164 RVA: 0x0009A69C File Offset: 0x0009889C
	private #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=zJKEEKc7$Kvqr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zdbYdBaIe_8qx)
	{
		Dictionary<int, List<string>> dictionary = new Dictionary<int, List<string>>();
		foreach (int key in this.#=zrgkRa73Q1vyY().Keys)
		{
			List<string> list = new List<string>();
			list.AddRange(this.#=zrgkRa73Q1vyY()[key]);
			dictionary.Add(key, list);
		}
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zdbYdBaIe_8qx.#=zol80P7TKoihZ())
		{
			List<string> list2 = new List<string>();
			list2.AddRange(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.Tags);
			list2.Remove(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zVTXNaO2wZJzQ());
			dictionary[#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C()] = list2;
		}
		return new #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==(dictionary);
	}

	// Token: 0x0600142D RID: 5165 RVA: 0x0009A788 File Offset: 0x00098988
	public static List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zQQQYPaZHedvo()
	{
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>();
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ == null)
		{
			return list;
		}
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY();
		if (list2 == null)
		{
			return list;
		}
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=();
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT == null)
		{
			return list;
		}
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list3 = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zOdy_aU_tk1aY();
		if (list3 == null)
		{
			return list;
		}
		GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
		GameApplicationData.Games games = GameApplicationData.#=zZ2dsDUeWDYAN();
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in list2)
		{
			#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = null;
			foreach (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2 in list3)
			{
				if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zCCvotbi$42tS() == #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe() && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=z7wsmjLWw49AC() == gameHosters && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2.#=zZ2dsDUeWDYAN() == games)
				{
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl2;
					break;
				}
			}
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl != null && !#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==.#=zloDul58=(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zc8qEfLcp5D1z(), #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==))
			{
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl3 = new #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl();
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl3.#=ze8TQhOAtefck(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCCvotbi$42tS());
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl4 = #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl3;
				#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl4.#=zojHCQcuGBXly(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zc8qEfLcp5D1z().#=zJKEEKc7$Kvqr(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==));
				list.Add(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl4);
			}
		}
		return list;
	}

	// Token: 0x04000B90 RID: 2960
	private Dictionary<int, List<string>> #=zG$Vzk8djrg6XPfeAEpUVFIw=;

	// Token: 0x04000B91 RID: 2961
	private List<string> #=zNFuwlVN9yPnP;

	// Token: 0x02000296 RID: 662
	private sealed class #=zr_yosI_ImfoCYek4BdK6O1U=
	{
		// Token: 0x0600142F RID: 5167 RVA: 0x0009A8D0 File Offset: 0x00098AD0
		internal bool #=zpGy6NO9YvDRsGtJAAg==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zYgvZuBwR$a1C() == this.#=zLeeSKrg=;
		}

		// Token: 0x04000B92 RID: 2962
		public int #=zLeeSKrg=;
	}
}
