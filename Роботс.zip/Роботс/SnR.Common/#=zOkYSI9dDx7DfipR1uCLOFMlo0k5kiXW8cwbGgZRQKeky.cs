﻿using System;
using System.Collections.Generic;

// Token: 0x02000172 RID: 370
internal sealed class #=zOkYSI9dDx7DfipR1uCLOFMlo0k5kiXW8cwbGgZRQKeky
{
	// Token: 0x060009EC RID: 2540 RVA: 0x00050024 File Offset: 0x0004E224
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060009ED RID: 2541 RVA: 0x0005002C File Offset: 0x0004E22C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009EE RID: 2542 RVA: 0x00050038 File Offset: 0x0004E238
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060009EF RID: 2543 RVA: 0x00050040 File Offset: 0x0004E240
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009F0 RID: 2544 RVA: 0x0005004C File Offset: 0x0004E24C
	public List<int> #=z0gRgrrIGr5L_()
	{
		return this.#=z6NiC1Ey8nUc03WUQig==;
	}

	// Token: 0x060009F1 RID: 2545 RVA: 0x00050054 File Offset: 0x0004E254
	public void #=z9Dz_ou4g$lCI(List<int> #=z$Ib9gYQ=)
	{
		this.#=z6NiC1Ey8nUc03WUQig== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009F2 RID: 2546 RVA: 0x00050060 File Offset: 0x0004E260
	public int #=zBzeaLS1hmg6bFYWHJA==()
	{
		return this.#=znpRNPncky$xeBEyIwPyYDgtt_wK3;
	}

	// Token: 0x060009F3 RID: 2547 RVA: 0x00050068 File Offset: 0x0004E268
	public void #=zeFwpq2vl2GrQM6lTEQ==(int #=z$Ib9gYQ=)
	{
		this.#=znpRNPncky$xeBEyIwPyYDgtt_wK3 = #=z$Ib9gYQ=;
	}

	// Token: 0x060009F4 RID: 2548 RVA: 0x00050074 File Offset: 0x0004E274
	public int #=zfvqZlK1NEWTQR1rpQxY5eLw=()
	{
		return this.#=zRCciz36Jc77s9PNy9Edp7tWQ1aImDH7IvA==;
	}

	// Token: 0x060009F5 RID: 2549 RVA: 0x0005007C File Offset: 0x0004E27C
	public void #=zGbsh0V8TjEsKv0I3qMat3rw=(int #=z$Ib9gYQ=)
	{
		this.#=zRCciz36Jc77s9PNy9Edp7tWQ1aImDH7IvA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040005B1 RID: 1457
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040005B2 RID: 1458
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040005B3 RID: 1459
	private List<int> #=z6NiC1Ey8nUc03WUQig==;

	// Token: 0x040005B4 RID: 1460
	private int #=znpRNPncky$xeBEyIwPyYDgtt_wK3;

	// Token: 0x040005B5 RID: 1461
	private int #=zRCciz36Jc77s9PNy9Edp7tWQ1aImDH7IvA==;
}
