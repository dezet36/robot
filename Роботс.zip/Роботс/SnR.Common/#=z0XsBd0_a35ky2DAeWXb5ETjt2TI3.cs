﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200002F RID: 47
internal sealed class #=z0XsBd0_a35ky2DAeWXb5ETjt2TI3 : RecordData
{
	// Token: 0x060000BD RID: 189 RVA: 0x00006C08 File Offset: 0x00004E08
	public #=z0XsBd0_a35ky2DAeWXb5ETjt2TI3(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		if (data.Length > 2)
		{
			this.#=zqD0Q2nU= = IntegerHelper.getInt(data[2], data[3]);
		}
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00006C3C File Offset: 0x00004E3C
	public int #=zOYKii9SVwU3a()
	{
		return this.#=zqD0Q2nU=;
	}

	// Token: 0x0400004D RID: 77
	private int #=zqD0Q2nU=;
}
