﻿using System;

// Token: 0x0200027F RID: 639
internal sealed class #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ
{
	// Token: 0x06001354 RID: 4948 RVA: 0x0009604C File Offset: 0x0009424C
	private #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(int #=ze7ZtytQ=, string #=zdqSpY9Q=)
	{
		this.#=zaiKvawI= = #=ze7ZtytQ=;
		this.#=zkL0PCoY= = #=zdqSpY9Q=;
		#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ[] array = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ[#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=.Length + 1];
		Array.Copy(#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=, 0, array, 0, #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=.Length);
		array[#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=.Length] = this;
		#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM= = array;
	}

	// Token: 0x06001355 RID: 4949 RVA: 0x000960A0 File Offset: 0x000942A0
	static #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ()
	{
		#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ[0];
	}

	// Token: 0x06001356 RID: 4950 RVA: 0x00096190 File Offset: 0x00094390
	public string #=zR0xs0zs=()
	{
		return this.#=zkL0PCoY=;
	}

	// Token: 0x06001357 RID: 4951 RVA: 0x00096198 File Offset: 0x00094398
	public int #=zVcIxe_4=()
	{
		return this.#=zaiKvawI=;
	}

	// Token: 0x06001358 RID: 4952 RVA: 0x000961A0 File Offset: 0x000943A0
	public static #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zJXisDTU=(int #=ze7ZtytQ=)
	{
		#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ result = #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zNUFwPq0=;
		for (int i = 0; i < #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=.Length; i++)
		{
			if (#=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=[i].#=zaiKvawI= == #=ze7ZtytQ=)
			{
				result = #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ.#=zC7NDbDM=[i];
				break;
			}
		}
		return result;
	}

	// Token: 0x04000B21 RID: 2849
	private int #=zaiKvawI=;

	// Token: 0x04000B22 RID: 2850
	private string #=zkL0PCoY=;

	// Token: 0x04000B23 RID: 2851
	private static #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ[] #=zC7NDbDM=;

	// Token: 0x04000B24 RID: 2852
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=z6dr_HB0= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(0, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075221));

	// Token: 0x04000B25 RID: 2853
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zNUFwPq0= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(1, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075514));

	// Token: 0x04000B26 RID: 2854
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zDiCx2j8= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075508));

	// Token: 0x04000B27 RID: 2855
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=z4PMXtE8= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075490));

	// Token: 0x04000B28 RID: 2856
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zSdSm3KcDQw63 = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075480));

	// Token: 0x04000B29 RID: 2857
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zw4mvnmN$mZRk = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(5, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075479));

	// Token: 0x04000B2A RID: 2858
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zmTMJva0= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(6, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075458));

	// Token: 0x04000B2B RID: 2859
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=z$l9GSn8= = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075704));

	// Token: 0x04000B2C RID: 2860
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zEw$RFyRlrcHA = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(32, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075702));

	// Token: 0x04000B2D RID: 2861
	public static readonly #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ #=zcfI1d6AmeYtw = new #=zlb9gf53MCWPhbmERQ_M9yS65hkFZ(255, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075682));
}
