﻿using System;

// Token: 0x0200007E RID: 126
internal sealed class #=z6PmcO0SIteE1PixFEiKF2bjL5K797SrMRgdEe0E=
{
	// Token: 0x0600038C RID: 908 RVA: 0x0001FBB0 File Offset: 0x0001DDB0
	public DateTime #=zQp7G$cHwa5_v()
	{
		return this.#=zC7QSHEKuCHguSFVrBluIiVE=;
	}

	// Token: 0x0600038D RID: 909 RVA: 0x0001FBB8 File Offset: 0x0001DDB8
	public void #=zSKWZcgJ7CUhZ(DateTime #=z$Ib9gYQ=)
	{
		this.#=zC7QSHEKuCHguSFVrBluIiVE= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600038E RID: 910 RVA: 0x0001FBC4 File Offset: 0x0001DDC4
	public string #=z_s$jh$GUqeKE()
	{
		return this.#=zX$0g$uvyyYb5ePVELA==;
	}

	// Token: 0x0600038F RID: 911 RVA: 0x0001FBCC File Offset: 0x0001DDCC
	public void #=zFzxbBjqRMsSC(string #=z$Ib9gYQ=)
	{
		this.#=zX$0g$uvyyYb5ePVELA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400013E RID: 318
	private DateTime #=zC7QSHEKuCHguSFVrBluIiVE=;

	// Token: 0x0400013F RID: 319
	private string #=zX$0g$uvyyYb5ePVELA==;
}
