﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.UserMeta;

// Token: 0x020000F4 RID: 244
internal sealed partial class #=zFfvixqA1aRfZpRx33abYUnll5YQJ8GcaFA== : Form
{
	// Token: 0x06000655 RID: 1621 RVA: 0x00032884 File Offset: 0x00030A84
	public #=zFfvixqA1aRfZpRx33abYUnll5YQJ8GcaFA==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf, ActionSettings #=zht1OJ$NiWOv1 = null)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zBMwJDJhgPcAP = #=zJUGTDqUtMnBf;
		this.#=ziCCh1Nq78$E3 = #=zht1OJ$NiWOv1;
		this.#=zgpzgXirqPT5_();
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(1, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030036)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909013192)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029744)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(8, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909004420)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(64, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029726)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(512, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029701)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(1024, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909005129)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(128, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029670)));
		list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(256, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909006826)));
		if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(this.#=zBMwJDJhgPcAP))
		{
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(1048576, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908985585)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(2097152, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908990440)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(4194304, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060112)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(8388608, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909036146)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(16777216, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909000359)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(33554432, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049404)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(67108864, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049237)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(134217728, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909035302)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(134217728, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909035393)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(268435456, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909035171)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(536870912, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909037107)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(1073741824, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909036868)));
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(524288, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909038449)));
		}
		this.#=z3xzi6FagVSy8.#=z20ohAjI=(list, true, true);
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
		this.#=zcIGb4QLv47ld.#=z20ohAjI=(this.#=zshVEGQI=.#=zol80P7TKoihZ());
		this.#=z40MnTxftey5E();
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00032B24 File Offset: 0x00030D24
	private void #=z40MnTxftey5E()
	{
		List<int> list = this.#=z0GxUXow=.#=zBziBGR4jZQ9z();
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list2 = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		for (int i = 0; i < this.#=zshVEGQI=.#=zol80P7TKoihZ().Count; i++)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[i];
			if (this.#=zcIGb4QLv47ld.#=zQLl7KKs=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==))
			{
				list2.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(i, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zdEt_WRHpdEMmGTK_3Q==(), #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z72grV1lsvZeM(), list.Contains(i)));
			}
		}
		this.#=z0GxUXow=.#=z20ohAjI=(list2, true, false);
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00032BAC File Offset: 0x00030DAC
	private void #=zUT6tK7gRZc7I(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			ActionSettings.SettingsParts settingsParts = ActionSettings.SettingsParts.None;
			foreach (int num in this.#=z3xzi6FagVSy8.#=zBziBGR4jZQ9z())
			{
				settingsParts |= (ActionSettings.SettingsParts)num;
			}
			foreach (int index in this.#=z0GxUXow=.#=zBziBGR4jZQ9z())
			{
				if (this.#=ziCCh1Nq78$E3 == null)
				{
					if (this.#=zshVEGQI=.#=zol80P7TKoihZ()[index] != this.#=zBMwJDJhgPcAP)
					{
						this.#=zBMwJDJhgPcAP.#=zv2Kyu17YrGOC().Copy(this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zv2Kyu17YrGOC(), settingsParts, this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zYgvZuBwR$a1C(), this.#=zBMwJDJhgPcAP.#=zYgvZuBwR$a1C());
						this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
					}
				}
				else
				{
					this.#=ziCCh1Nq78$E3.Copy(this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zv2Kyu17YrGOC(), settingsParts, this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zYgvZuBwR$a1C(), this.#=zBMwJDJhgPcAP.#=zYgvZuBwR$a1C());
					this.#=zshVEGQI=.#=zol80P7TKoihZ()[index].#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
				}
			}
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029635));
			base.Close();
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zBMwJDJhgPcAP.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x00032DA0 File Offset: 0x00030FA0
	private void #=zf5lddypEDGzml7of3A==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z40MnTxftey5E();
	}

	// Token: 0x0600065A RID: 1626 RVA: 0x00032DC8 File Offset: 0x00030FC8
	private void #=zgpzgXirqPT5_()
	{
		this.#=z3xzi6FagVSy8 = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=z0GxUXow= = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zftWnNnA= = new Button();
		this.#=zLVZn1UbnVZtw = new SplitContainer();
		this.#=zcIGb4QLv47ld = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		((ISupportInitialize)this.#=zLVZn1UbnVZtw).BeginInit();
		this.#=zLVZn1UbnVZtw.Panel1.SuspendLayout();
		this.#=zLVZn1UbnVZtw.Panel2.SuspendLayout();
		this.#=zLVZn1UbnVZtw.SuspendLayout();
		base.SuspendLayout();
		this.#=z3xzi6FagVSy8.BorderStyle = BorderStyle.FixedSingle;
		this.#=z3xzi6FagVSy8.Location = new Point(12, 12);
		this.#=z3xzi6FagVSy8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029863);
		this.#=z3xzi6FagVSy8.Size = new Size(200, 511);
		this.#=z3xzi6FagVSy8.TabIndex = 0;
		this.#=z0GxUXow=.AutoScroll = true;
		this.#=z0GxUXow=.AutoSize = true;
		this.#=z0GxUXow=.BorderStyle = BorderStyle.FixedSingle;
		this.#=z0GxUXow=.Dock = DockStyle.Fill;
		this.#=z0GxUXow=.Location = new Point(0, 0);
		this.#=z0GxUXow=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909030099);
		this.#=z0GxUXow=.Size = new Size(427, 564);
		this.#=z0GxUXow=.TabIndex = 0;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel1;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zftWnNnA=);
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=z3xzi6FagVSy8);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zLVZn1UbnVZtw);
		this.#=zByiHPAwyKD$Q.Size = new Size(939, 564);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 239;
		this.#=zByiHPAwyKD$Q.TabIndex = 2;
		this.#=zftWnNnA=.Location = new Point(67, 529);
		this.#=zftWnNnA=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029832);
		this.#=zftWnNnA=.Size = new Size(96, 23);
		this.#=zftWnNnA=.TabIndex = 1;
		this.#=zftWnNnA=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909084464);
		this.#=zftWnNnA=.UseVisualStyleBackColor = true;
		this.#=zftWnNnA=.Click += this.#=zUT6tK7gRZc7I;
		this.#=zLVZn1UbnVZtw.Dock = DockStyle.Fill;
		this.#=zLVZn1UbnVZtw.Location = new Point(0, 0);
		this.#=zLVZn1UbnVZtw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029889);
		this.#=zLVZn1UbnVZtw.Panel1.Controls.Add(this.#=z0GxUXow=);
		this.#=zLVZn1UbnVZtw.Panel2.Controls.Add(this.#=zcIGb4QLv47ld);
		this.#=zLVZn1UbnVZtw.Size = new Size(696, 564);
		this.#=zLVZn1UbnVZtw.SplitterDistance = 427;
		this.#=zLVZn1UbnVZtw.TabIndex = 1;
		this.#=zcIGb4QLv47ld.Dock = DockStyle.Fill;
		this.#=zcIGb4QLv47ld.Location = new Point(0, 0);
		this.#=zcIGb4QLv47ld.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091904);
		this.#=zcIGb4QLv47ld.Size = new Size(265, 564);
		this.#=zcIGb4QLv47ld.TabIndex = 0;
		this.#=zcIGb4QLv47ld.#=znoclypZSSO9V(new EventHandler(this.#=zf5lddypEDGzml7of3A==));
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(939, 564);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029817);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909029817);
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		this.#=zLVZn1UbnVZtw.Panel1.ResumeLayout(false);
		this.#=zLVZn1UbnVZtw.Panel1.PerformLayout();
		this.#=zLVZn1UbnVZtw.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zLVZn1UbnVZtw).EndInit();
		this.#=zLVZn1UbnVZtw.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x0400029E RID: 670
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x0400029F RID: 671
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zBMwJDJhgPcAP;

	// Token: 0x040002A0 RID: 672
	private ActionSettings #=ziCCh1Nq78$E3;

	// Token: 0x040002A2 RID: 674
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=z3xzi6FagVSy8;

	// Token: 0x040002A3 RID: 675
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=z0GxUXow=;

	// Token: 0x040002A4 RID: 676
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x040002A5 RID: 677
	private Button #=zftWnNnA=;

	// Token: 0x040002A6 RID: 678
	private SplitContainer #=zLVZn1UbnVZtw;

	// Token: 0x040002A7 RID: 679
	private #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g== #=zcIGb4QLv47ld;
}
