﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common;
using Skink.SnR.Common.Interface;
using Skink.SnR.Common.Managers;

// Token: 0x02000259 RID: 601
internal sealed partial class #=zhzsRcc1ezE70XWqxEZrzI6GrgAKW3puKZA== : Form
{
	// Token: 0x06001234 RID: 4660 RVA: 0x0008BC84 File Offset: 0x00089E84
	public #=zhzsRcc1ezE70XWqxEZrzI6GrgAKW3puKZA==()
	{
		this.#=zgpzgXirqPT5_();
		base.DialogResult = DialogResult.None;
		this.#=zegbyLruW1Ya2(null);
		this.#=zQYvGJ$wMbysm = 0;
		this.#=zDVOGw0J6MGXLgMbq6A== = new List<int>();
		this.#=zgHVWAkBykl2c();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001235 RID: 4661 RVA: 0x0008BCC0 File Offset: 0x00089EC0
	public string #=z37JbfhBQfNof()
	{
		return this.#=zU$cJ2IT6vqI12uxV7g==;
	}

	// Token: 0x06001236 RID: 4662 RVA: 0x0008BCC8 File Offset: 0x00089EC8
	public void #=zegbyLruW1Ya2(string #=z$Ib9gYQ=)
	{
		this.#=zU$cJ2IT6vqI12uxV7g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001237 RID: 4663 RVA: 0x0008BCD4 File Offset: 0x00089ED4
	private void #=zgHVWAkBykl2c()
	{
		try
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zf9StgC1$9ZxV());
			if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				this.#=zegbyLruW1Ya2(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
			}
			else
			{
				Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883));
				if (dictionary2 != null)
				{
					this.#=zh4A34P1zKnxh.Text = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty);
					this.#=zy$2lUN9Z_ZDO.Text = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094335), string.Empty);
					this.#=zdWP_yO1hX5VO.Text = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094324), string.Empty);
					this.#=zIKkwWpOCxG5A.#=z20ohAjI=(#=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw==.#=z2Z4nvgvUQZ3W(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053), 0)), false, false);
					this.#=zZ_J8a9DbQI5$$lOyQw==.#=z20ohAjI=(#=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw==.#=zLYnIpHUp4u4Ym463Hw==(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), 0)), false, false);
					this.#=zbSLhtDkqeUY2.Text = JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094317), string.Empty);
					this.#=zaF0ryKaY$_Z3_P3aM6TpW64= = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0);
					this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.Text = this.#=zaF0ryKaY$_Z3_P3aM6TpW64=.ToString();
					this.#=zOq_3mEIuXx28OFtJqw== = new PriceRule(JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094299), string.Empty));
					this.#=zVQBvR58rFhMD = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601), 0);
					this.#=z_b8Df7JCQW88T8BJSd6roa8= = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0);
					int num = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0);
					this.#=zz_L3utLXKNsuQEhuWQ==.Text = num.ToString();
					this.#=ziO2mCdoKTehYyXFaqw==.Text = num.ToString();
					DateTime value = JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094288), true);
					this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Value = value;
					this.#=z3VxhX4vmfkzAsIVU0Q==.Value = value;
					this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Text = this.#=zaF0ryKaY$_Z3_P3aM6TpW64=.ToString();
					this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.Text = this.#=zaF0ryKaY$_Z3_P3aM6TpW64=.ToString();
					this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Text = 0.ToString();
					this.#=zvEHrcVozHc8Rdq2R9g==.SelectedIndex = 0;
					this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.SelectedIndex = 0;
					this.#=zY5HQxiivZOshM9LQEQ== = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094281), 0);
					this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.Text = this.#=zY5HQxiivZOshM9LQEQ==.ToString();
					object[] array = JSONManager.ExtractArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094279));
					this.#=z4ypj1ynO7InLUUaszw==.Rows.Clear();
					foreach (Dictionary<string, object> dictionary3 in array)
					{
						this.#=z4ypj1ynO7InLUUaszw==.Rows.Add(new object[]
						{
							dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)],
							dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)],
							dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)]
						});
					}
				}
				this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(4);
				this.#=zTBCuih53k1kB(JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)));
				this.#=zMpFfcVfAexF8n_wYig== = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060495));
				this.#=zegbyLruW1Ya2(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), string.Empty));
				if ((this.#=z_b8Df7JCQW88T8BJSd6roa8= & 1) == 0)
				{
					this.#=z_$fdDq23wMGTTG6OS_j0LLE=.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094013));
					this.#=zn8JEATVYHa936iJluA==.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093931));
				}
				if ((this.#=z_b8Df7JCQW88T8BJSd6roa8= & 2) != 0)
				{
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(3);
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(2);
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(1);
					this.#=zk$I7hVWIUFJw.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094064));
				}
				else if ((this.#=z_b8Df7JCQW88T8BJSd6roa8= & 8) != 0)
				{
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(2);
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(1);
					this.#=zk$I7hVWIUFJw.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095791));
					this.#=zbSLhtDkqeUY2.ReadOnly = false;
					this.#=zkL8xlualzf7P.Visible = true;
				}
				else
				{
					this.#=zHjh18Ft3a4lU.TabPages.RemoveAt(3);
					this.#=zk$I7hVWIUFJw.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095714));
				}
			}
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
			base.Close();
		}
	}

	// Token: 0x06001238 RID: 4664 RVA: 0x0008C1A0 File Offset: 0x0008A3A0
	private void #=zTBCuih53k1kB(object[] #=zRI1bRp93od42)
	{
		foreach (Dictionary<string, object> dictionary in #=zRI1bRp93od42)
		{
			DateTime dateTime = JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), true);
			string text = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), string.Empty);
			string text2 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), string.Empty);
			this.#=zv49GNBxNYfa3.Rows.Add(new object[]
			{
				dateTime.ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095892)),
				string.IsNullOrEmpty(text) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095871) : text,
				text2
			});
			int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
			if (num > this.#=zQYvGJ$wMbysm)
			{
				this.#=zQYvGJ$wMbysm = num;
			}
			if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0) <= 1 && !string.IsNullOrEmpty(text) && !this.#=zDVOGw0J6MGXLgMbq6A==.Contains(num))
			{
				this.#=zDVOGw0J6MGXLgMbq6A==.Add(num);
			}
		}
		if (#=zRI1bRp93od42.Length != 0)
		{
			this.#=zv49GNBxNYfa3.FirstDisplayedScrollingRowIndex = this.#=zv49GNBxNYfa3.Rows.Count - 1;
		}
	}

	// Token: 0x06001239 RID: 4665 RVA: 0x0008C2CC File Offset: 0x0008A4CC
	private void #=z9AJXvFf9GaiEEPol0fHOTqcN3$jMPJZ7sQ==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		int months = this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.SelectedIndex + 1;
		int num = Convert.ToInt32(this.#=zz_L3utLXKNsuQEhuWQ==.Text);
		DateTime value = this.#=z3VxhX4vmfkzAsIVU0Q==.Value;
		int num2;
		int num3;
		PriceRule.GetPriceDiff(JSONManager.CurrentUTCDate(), num, value, this.#=zOq_3mEIuXx28OFtJqw==, num, PriceRule.ProlongKeyNewExpireDate(value, months), this.#=zOq_3mEIuXx28OFtJqw==, true, true, this.#=zVQBvR58rFhMD, out num2, out num3);
		this.#=z28VQqnF53EWYSHC9Hw==.Text = num3.ToString();
	}

	// Token: 0x0600123A RID: 4666 RVA: 0x0008C344 File Offset: 0x0008A544
	private void #=zB5BkP1nkYssbrDWeNg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=;
		try
		{
			string text = this.#=zh4A34P1zKnxh.Text;
			if (string.IsNullOrWhiteSpace(text))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093238));
				return;
			}
			if (!string.IsNullOrEmpty(this.#=zbSLhtDkqeUY2.Text) && !#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zrrJL63eTcjQB(this.#=zbSLhtDkqeUY2.Text))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093196));
				return;
			}
			string text2 = this.#=zy$2lUN9Z_ZDO.Text;
			string text3 = this.#=zdWP_yO1hX5VO.Text;
			int #=z84LHPL2J2FN = this.#=zIKkwWpOCxG5A.#=zqust6dSu_GiZ();
			int #=zSc7_kYiCqktH = this.#=zZ_J8a9DbQI5$$lOyQw==.#=zqust6dSu_GiZ();
			string #=zvq0$kQI= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zK$qD7CpO$n0s(text, text2, text3, #=z84LHPL2J2FN, #=zSc7_kYiCqktH, this.#=zbSLhtDkqeUY2.Text);
			#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
			bool flag;
			if (this.#=z2yvOA8frbEP0(#=zvq0$kQI=, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==, out flag))
			{
				#=zdBD5ZXA= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095850), Array.Empty<object>());
				base.DialogResult = DialogResult.Yes;
			}
			else
			{
				#=zdBD5ZXA= = #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
			}
		}
		catch (Exception ex)
		{
			#=zdBD5ZXA= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(ex.Message, Array.Empty<object>());
		}
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
	}

	// Token: 0x0600123B RID: 4667 RVA: 0x0008C458 File Offset: 0x0008A658
	private void #=zJVq6shVeOVaHhO_6fGQygm51vxM2gI6IeA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zjELnqk91QI3ekOlKzw==(this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.SelectedIndex + 1));
		if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
			return;
		}
		int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0);
		if (num <= 0)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095814));
			return;
		}
		PayForm payForm = new PayForm(num, (this.#=z_b8Df7JCQW88T8BJSd6roa8= & 1) == 0, this.#=zMpFfcVfAexF8n_wYig==, this.#=zY5HQxiivZOshM9LQEQ==);
		try
		{
			if (payForm.ShowDialog() == DialogResult.Yes)
			{
				string #=zvq0$kQI= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zh53_YUdjalU1Rlni_w==(this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.SelectedIndex + 1, payForm.PayType, payForm.PayDetails, payForm.IsPayWithBonusPoints);
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=;
				bool flag;
				if (this.#=z2yvOA8frbEP0(#=zvq0$kQI=, out #=zdBD5ZXA=, out flag))
				{
					if (flag)
					{
						#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zhZBY4XA=();
						#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095510));
						base.Close();
					}
					else
					{
						#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095458));
						base.Close();
					}
				}
				else
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
				}
			}
		}
		finally
		{
			((IDisposable)payForm).Dispose();
		}
	}

	// Token: 0x0600123C RID: 4668 RVA: 0x0008C590 File Offset: 0x0008A790
	private void #=za8Qsl85XuRoXl1RFKgzlJ10=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z12aNaH2rayZG();
	}

	// Token: 0x0600123D RID: 4669 RVA: 0x0008C598 File Offset: 0x0008A798
	private void #=zTXbCgwdWDyJrE$RqbuDI$GQ=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z12aNaH2rayZG();
	}

	// Token: 0x0600123E RID: 4670 RVA: 0x0008C5A0 File Offset: 0x0008A7A0
	private void #=z12aNaH2rayZG()
	{
		int num;
		int.TryParse(this.#=ziO2mCdoKTehYyXFaqw==.Text, out num);
		DateTime value = this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Value;
		if (num <= 0 || value < JSONManager.CurrentUTCDate())
		{
			this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Text = null;
			this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Text = null;
			return;
		}
		int num2;
		int num3;
		if ((this.#=z_b8Df7JCQW88T8BJSd6roa8= & 8) != 0)
		{
			PriceRule.GetPriceDiff(JSONManager.CurrentUTCDate(), 0, this.#=z3VxhX4vmfkzAsIVU0Q==.Value, this.#=zOq_3mEIuXx28OFtJqw==, num, value, this.#=zOq_3mEIuXx28OFtJqw==, true, true, this.#=zVQBvR58rFhMD, out num2, out num3);
		}
		else
		{
			PriceRule.GetPriceDiff(JSONManager.CurrentUTCDate(), Convert.ToInt32(this.#=zz_L3utLXKNsuQEhuWQ==.Text), this.#=z3VxhX4vmfkzAsIVU0Q==.Value, this.#=zOq_3mEIuXx28OFtJqw==, num, value, this.#=zOq_3mEIuXx28OFtJqw==, true, true, this.#=zVQBvR58rFhMD, out num2, out num3);
		}
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Text = num2.ToString();
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Text = num3.ToString();
	}

	// Token: 0x0600123F RID: 4671 RVA: 0x0008C698 File Offset: 0x0008A898
	private void #=zUqmt21WfVSO4()
	{
		int num;
		int.TryParse(this.#=z9D_PbwmyAStRTU$A0Q==.Text, out num);
		if (num <= 0)
		{
			this.#=zde24AxXdJ7G3O$14AdfzJnI=.Text = null;
			this.#=zWLMJV2cnqSbEPWcoAA==.Text = null;
			return;
		}
		int months = this.#=zvEHrcVozHc8Rdq2R9g==.SelectedIndex + 1;
		int num2;
		int num3;
		PriceRule.GetPriceDiff(JSONManager.CurrentUTCDate(), num, DateTime.Today, this.#=zOq_3mEIuXx28OFtJqw==, num, PriceRule.ProlongKeyNewExpireDate(DateTime.Today, months), this.#=zOq_3mEIuXx28OFtJqw==, true, true, this.#=zVQBvR58rFhMD, out num2, out num3);
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.Text = num2.ToString();
		this.#=zWLMJV2cnqSbEPWcoAA==.Text = num3.ToString();
	}

	// Token: 0x06001240 RID: 4672 RVA: 0x0008C73C File Offset: 0x0008A93C
	private void #=zfd$tx5gdjnV8Ce4Y2JdpH48=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		int num;
		int.TryParse(this.#=ziO2mCdoKTehYyXFaqw==.Text, out num);
		if (num <= 0)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095596));
			return;
		}
		DateTime value = this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Value;
		if (value < JSONManager.CurrentUTCDate())
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095292));
			return;
		}
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zjELnqk91QI3ekOlKzw==(num, value));
		if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
			return;
		}
		int num2 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0);
		int #=ziCCE9_QLT$ol = 0;
		string #=zCgD4QQxEzNdL = null;
		bool #=zdKHqacYNXPetqbNHJorQLKw= = false;
		if (num2 < -50)
		{
			if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095231), MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095200), new object[]
			{
				-num2
			}) != DialogResult.OK)
			{
				return;
			}
		}
		else if (num2 <= 0)
		{
			if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095231), MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095325), Array.Empty<object>()) != DialogResult.OK)
			{
				return;
			}
		}
		else
		{
			bool isImmediateChangeAllowed = (this.#=z_b8Df7JCQW88T8BJSd6roa8= & 1) == 0 && num2 <= this.#=zaF0ryKaY$_Z3_P3aM6TpW64=;
			PayForm payForm = new PayForm(num2, isImmediateChangeAllowed, this.#=zMpFfcVfAexF8n_wYig==, this.#=zY5HQxiivZOshM9LQEQ==);
			try
			{
				if (payForm.ShowDialog() != DialogResult.Yes)
				{
					return;
				}
				#=ziCCE9_QLT$ol = payForm.PayType;
				#=zCgD4QQxEzNdL = payForm.PayDetails;
				#=zdKHqacYNXPetqbNHJorQLKw= = payForm.IsPayWithBonusPoints;
			}
			finally
			{
				((IDisposable)payForm).Dispose();
			}
		}
		string #=zvq0$kQI= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z12aNaH2rayZG(num, value, #=ziCCE9_QLT$ol, #=zCgD4QQxEzNdL, #=zdKHqacYNXPetqbNHJorQLKw=);
		bool flag = num < #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY().Count;
		#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=;
		bool flag2;
		if (this.#=z2yvOA8frbEP0(#=zvq0$kQI=, out #=zdBD5ZXA=, out flag2))
		{
			if (flag2)
			{
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zhZBY4XA=();
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095007));
			}
			else
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094973));
			}
			if (flag)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095108));
			}
			base.Close();
			return;
		}
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
	}

	// Token: 0x06001241 RID: 4673 RVA: 0x0008C948 File Offset: 0x0008AB48
	private void #=z4sazvwj2uunsIHGDx6Gl$_4=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		int num;
		int.TryParse(this.#=z9D_PbwmyAStRTU$A0Q==.Text, out num);
		if (num <= 0)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095596));
			return;
		}
		DateTime dateTime = JSONManager.CurrentUTCDate().AddDays((double)(31 * (this.#=zvEHrcVozHc8Rdq2R9g==.SelectedIndex + 1)));
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zjELnqk91QI3ekOlKzw==(num, dateTime));
		if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
			return;
		}
		int num2 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0);
		if (num2 <= 0)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095814));
			return;
		}
		PayForm payForm = new PayForm(num2, false, this.#=zMpFfcVfAexF8n_wYig==, this.#=zY5HQxiivZOshM9LQEQ==);
		try
		{
			if (payForm.ShowDialog() == DialogResult.Yes)
			{
				int payType = payForm.PayType;
				string payDetails = payForm.PayDetails;
				bool isPayWithBonusPoints = payForm.IsPayWithBonusPoints;
				string #=zvq0$kQI= = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z12aNaH2rayZG(num, dateTime, payType, payDetails, isPayWithBonusPoints);
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=;
				bool flag;
				if (this.#=z2yvOA8frbEP0(#=zvq0$kQI=, out #=zdBD5ZXA=, out flag))
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094973));
					base.Close();
				}
				else
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zdBD5ZXA=);
				}
			}
		}
		finally
		{
			((IDisposable)payForm).Dispose();
		}
	}

	// Token: 0x06001242 RID: 4674 RVA: 0x0008CA94 File Offset: 0x0008AC94
	private bool #=z2yvOA8frbEP0(string #=zvq0$kQI=, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z143ZALc=, out bool #=ziL7W2mvuMm$_)
	{
		if (string.IsNullOrWhiteSpace(#=zvq0$kQI=))
		{
			#=z143ZALc= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096705), Array.Empty<object>());
			#=ziL7W2mvuMm$_ = false;
			return false;
		}
		if (#=zvq0$kQI=.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205)))
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zvq0$kQI=);
			if (JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), string.Empty) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201))
			{
				#=z143ZALc= = null;
				if (JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), string.Empty).EndsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070838)))
				{
					#=ziL7W2mvuMm$_ = false;
				}
				else
				{
					#=ziL7W2mvuMm$_ = true;
				}
				return true;
			}
			if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				#=z143ZALc= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), string.Empty), Array.Empty<object>());
				#=ziL7W2mvuMm$_ = false;
				return false;
			}
			#=z143ZALc= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(JSONManager.Cut(#=zvq0$kQI=), Array.Empty<object>());
			#=ziL7W2mvuMm$_ = false;
			return false;
		}
		else
		{
			if (#=zvq0$kQI= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096893))
			{
				#=z143ZALc= = null;
				#=ziL7W2mvuMm$_ = false;
				return true;
			}
			if (#=zvq0$kQI= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096873))
			{
				#=z143ZALc= = null;
				#=ziL7W2mvuMm$_ = true;
				return true;
			}
			#=z143ZALc= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096868), new object[]
			{
				JSONManager.Cut(#=zvq0$kQI=)
			});
			#=ziL7W2mvuMm$_ = false;
			return false;
		}
	}

	// Token: 0x06001243 RID: 4675 RVA: 0x0008CBE8 File Offset: 0x0008ADE8
	private void #=zWNmfUm3JqTsgNj3Pj7xCHgE=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zUqmt21WfVSO4();
	}

	// Token: 0x06001244 RID: 4676 RVA: 0x0008CBF0 File Offset: 0x0008ADF0
	private void #=z_JAQvMpPDyxrIxegqw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (this.#=zHjh18Ft3a4lU.SelectedTab.Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096574))
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zYt_eIZ4_tO7y(this.#=zQYvGJ$wMbysm));
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
				{
					this.#=zegbyLruW1Ya2(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
				}
				else
				{
					object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
					if (array != null)
					{
						this.#=zTBCuih53k1kB(array);
					}
					foreach (int #=z3hPMuug= in this.#=zDVOGw0J6MGXLgMbq6A==)
					{
						#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zEBRdQRVVATQG(#=z3hPMuug=);
					}
				}
			}
		}
		catch (Exception ex)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(ex);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
			this.#=zELv0raV1GVcf.Enabled = false;
		}
	}

	// Token: 0x06001245 RID: 4677 RVA: 0x0008CCF4 File Offset: 0x0008AEF4
	private void #=z$sDqQSzT8thv4$uwQg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (string.IsNullOrWhiteSpace(this.#=z6VmbAYc895KH.Text))
		{
			return;
		}
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zbKUEYvdUKPog(this.#=z6VmbAYc895KH.Text, this.#=zQYvGJ$wMbysm));
		if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			this.#=zegbyLruW1Ya2(Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]));
			return;
		}
		this.#=z6VmbAYc895KH.Text = string.Empty;
		object[] array = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891));
		if (array != null)
		{
			this.#=zTBCuih53k1kB(array);
		}
	}

	// Token: 0x06001246 RID: 4678 RVA: 0x0008CD90 File Offset: 0x0008AF90
	public void #=zGt$rFKwyPihG()
	{
		this.#=zHjh18Ft3a4lU.SelectTab(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096574));
	}

	// Token: 0x06001247 RID: 4679 RVA: 0x0008CDA8 File Offset: 0x0008AFA8
	private void #=zrbeG0l0GB_v1v4klqBB6aW9RzQsm(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zUqmt21WfVSO4();
	}

	// Token: 0x06001248 RID: 4680 RVA: 0x0008CDB0 File Offset: 0x0008AFB0
	private void #=zJkTp7s2AX6JvDknJ4g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zrrJL63eTcjQB(this.#=zbSLhtDkqeUY2.Text) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094492) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094789));
	}

	// Token: 0x0600124A RID: 4682 RVA: 0x0008CE00 File Offset: 0x0008B000
	private void #=zgpzgXirqPT5_()
	{
		this.#=zRWEHIqY= = new Container();
		DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
		this.#=zHjh18Ft3a4lU = new TabControl();
		this.#=zy4o$YK077C4d = new TabPage();
		this.#=zkL8xlualzf7P = new Button();
		this.#=zHizNmxAqiU8a = new Label();
		this.#=zQ$fRNX7$l$D8 = new Button();
		this.#=zZ_J8a9DbQI5$$lOyQw== = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zIKkwWpOCxG5A = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zulTJPbH8Sy1jOye98g== = new Label();
		this.#=zbSLhtDkqeUY2 = new TextBox();
		this.#=zdWP_yO1hX5VO = new TextBox();
		this.#=zy$2lUN9Z_ZDO = new TextBox();
		this.#=zh4A34P1zKnxh = new TextBox();
		this.#=zNVRUv5ZYgNJ7 = new Label();
		this.#=zk$I7hVWIUFJw = new Label();
		this.#=zl4FBxfXpZiJd = new Label();
		this.#=zD6a$h9woJe6b6K_9AA== = new Label();
		this.#=zAitLr626tg7W = new Label();
		this.#=z_GvTv94wzETO = new Label();
		this.#=z3XW3F7TvLOV4 = new Label();
		this.#=zhvjcx6HAi83ajmzN93Ps$jM= = new TabPage();
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d = new Button();
		this.#=z28VQqnF53EWYSHC9Hw== = new TextBox();
		this.#=z1Z7CJk9aeKqJ9o6pGw== = new Label();
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw= = new TextBox();
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr = new ComboBox();
		this.#=znecOE6MM5Ua7TTK7$A== = new Label();
		this.#=zZldHY7ZLB863nY$N8wcXmlM= = new Label();
		this.#=z_$fdDq23wMGTTG6OS_j0LLE= = new Label();
		this.#=zZP5GaR7JCy3BF5IDafZGXMk= = new Label();
		this.#=zZ4JrpNQLGWur = new TabPage();
		this.#=z3VxhX4vmfkzAsIVU0Q== = new DateTimePicker();
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc= = new DateTimePicker();
		this.#=zz_L3utLXKNsuQEhuWQ== = new TextBox();
		this.#=ziO2mCdoKTehYyXFaqw== = new TextBox();
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ= = new Button();
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ= = new TextBox();
		this.#=zJAngXo8= = new Label();
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1 = new TextBox();
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse = new TextBox();
		this.#=znI0IIBo= = new Label();
		this.#=zNufWClXIfVqnsUqFDw== = new Label();
		this.#=zn8JEATVYHa936iJluA== = new Label();
		this.#=zP54rRK3aAj4yTgWtyUtqnHs= = new Label();
		this.#=zUOTYnW10Q6yd3K3r$A== = new Label();
		this.#=z1ldt_ASfsMCR = new Label();
		this.#=zj9eTMBAprGTZ = new Label();
		this.#=zGa8QHA9k_S9k = new TabPage();
		this.#=z9D_PbwmyAStRTU$A0Q== = new TextBox();
		this.#=zb8FbnD5Z6QHf0$6pxw== = new Label();
		this.#=zxm$B6RXE4um$$SavRuRsIBM= = new Button();
		this.#=zWLMJV2cnqSbEPWcoAA== = new TextBox();
		this.#=zDSxgyRhIkdnWp$ILlA== = new Label();
		this.#=zde24AxXdJ7G3O$14AdfzJnI= = new TextBox();
		this.#=zvEHrcVozHc8Rdq2R9g== = new ComboBox();
		this.#=zzSueeGe2$Ao1jehiuOLf4uw= = new Label();
		this.#=zuLt4NU7InhRW7LZ$Pg== = new Label();
		this.#=ztgK$iuoNVx0EsgP46A== = new Label();
		this.#=zMYAIoremXPQW7foA1A== = new Label();
		this.#=zYJQRiQwaQ4kV = new TabPage();
		this.#=zqJyFyxsE2IJG = new DataGridView();
		this.#=zp92nVVYeFRKT = new DataGridViewTextBoxColumn();
		this.#=zPe_CiuiwxF9T = new DataGridViewTextBoxColumn();
		this.#=zVUoPFP21sbnH9Gy9Mg== = new DataGridViewTextBoxColumn();
		this.#=zwHJ2OKHYCqt4acADQw== = new DataGridViewTextBoxColumn();
		this.#=zomB2s17oIl4u = new DataGridViewTextBoxColumn();
		this.#=zZVD8EfXTOFxKO_do91qpM4Y= = new TabPage();
		this.#=zyW6tUg8x6X7Rtch_Og== = new SplitContainer();
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4 = new Label();
		this.#=z4ypj1ynO7InLUUaszw== = new DataGridView();
		this.#=zNtL4QxEBbpNZ = new DataGridViewTextBoxColumn();
		this.#=zGIgkGYpf0y2r = new DataGridViewTextBoxColumn();
		this.#=zq$9udy2O2B57 = new DataGridViewTextBoxColumn();
		this.#=zg4CxuGULGCNV = new TabPage();
		this.#=z_mKf6YD5PB4N = new SplitContainer();
		this.#=zv49GNBxNYfa3 = new DataGridView();
		this.#=zs6TItfWQTZa0 = new DataGridViewTextBoxColumn();
		this.#=zKFdUoSMADAPg = new DataGridViewTextBoxColumn();
		this.#=zbwDUKuPp7xt_ = new DataGridViewTextBoxColumn();
		this.#=z6VmbAYc895KH = new TextBox();
		this.#=zodZ_Q1M= = new Label();
		this.#=zkQprPmfCqtF4 = new Button();
		this.#=z8Mz_LUk7Ew$k = new Label();
		this.#=zELv0raV1GVcf = new Timer(this.#=zRWEHIqY=);
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O = new Label();
		this.#=zHjh18Ft3a4lU.SuspendLayout();
		this.#=zy4o$YK077C4d.SuspendLayout();
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.SuspendLayout();
		this.#=zZ4JrpNQLGWur.SuspendLayout();
		this.#=zGa8QHA9k_S9k.SuspendLayout();
		this.#=zYJQRiQwaQ4kV.SuspendLayout();
		((ISupportInitialize)this.#=zqJyFyxsE2IJG).BeginInit();
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.SuspendLayout();
		((ISupportInitialize)this.#=zyW6tUg8x6X7Rtch_Og==).BeginInit();
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel1.SuspendLayout();
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel2.SuspendLayout();
		this.#=zyW6tUg8x6X7Rtch_Og==.SuspendLayout();
		((ISupportInitialize)this.#=z4ypj1ynO7InLUUaszw==).BeginInit();
		this.#=zg4CxuGULGCNV.SuspendLayout();
		((ISupportInitialize)this.#=z_mKf6YD5PB4N).BeginInit();
		this.#=z_mKf6YD5PB4N.Panel1.SuspendLayout();
		this.#=z_mKf6YD5PB4N.Panel2.SuspendLayout();
		this.#=z_mKf6YD5PB4N.SuspendLayout();
		((ISupportInitialize)this.#=zv49GNBxNYfa3).BeginInit();
		base.SuspendLayout();
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zy4o$YK077C4d);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zhvjcx6HAi83ajmzN93Ps$jM=);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zZ4JrpNQLGWur);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zGa8QHA9k_S9k);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zYJQRiQwaQ4kV);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zZVD8EfXTOFxKO_do91qpM4Y=);
		this.#=zHjh18Ft3a4lU.Controls.Add(this.#=zg4CxuGULGCNV);
		this.#=zHjh18Ft3a4lU.Dock = DockStyle.Fill;
		this.#=zHjh18Ft3a4lU.Location = new Point(0, 0);
		this.#=zHjh18Ft3a4lU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096551);
		this.#=zHjh18Ft3a4lU.SelectedIndex = 0;
		this.#=zHjh18Ft3a4lU.Size = new Size(715, 532);
		this.#=zHjh18Ft3a4lU.TabIndex = 0;
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zkL8xlualzf7P);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zHizNmxAqiU8a);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zQ$fRNX7$l$D8);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zZ_J8a9DbQI5$$lOyQw==);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zIKkwWpOCxG5A);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zulTJPbH8Sy1jOye98g==);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zbSLhtDkqeUY2);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zdWP_yO1hX5VO);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zy$2lUN9Z_ZDO);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zh4A34P1zKnxh);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zNVRUv5ZYgNJ7);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zk$I7hVWIUFJw);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zl4FBxfXpZiJd);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zD6a$h9woJe6b6K_9AA==);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=zAitLr626tg7W);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=z_GvTv94wzETO);
		this.#=zy4o$YK077C4d.Controls.Add(this.#=z3XW3F7TvLOV4);
		this.#=zy4o$YK077C4d.Location = new Point(4, 22);
		this.#=zy4o$YK077C4d.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096533);
		this.#=zy4o$YK077C4d.Padding = new Padding(3);
		this.#=zy4o$YK077C4d.Size = new Size(707, 506);
		this.#=zy4o$YK077C4d.TabIndex = 1;
		this.#=zy4o$YK077C4d.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096510);
		this.#=zy4o$YK077C4d.UseVisualStyleBackColor = true;
		this.#=zkL8xlualzf7P.Location = new Point(402, 162);
		this.#=zkL8xlualzf7P.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094191);
		this.#=zkL8xlualzf7P.Size = new Size(75, 23);
		this.#=zkL8xlualzf7P.TabIndex = 10;
		this.#=zkL8xlualzf7P.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094166);
		this.#=zkL8xlualzf7P.UseVisualStyleBackColor = true;
		this.#=zkL8xlualzf7P.Visible = false;
		this.#=zkL8xlualzf7P.Click += this.#=zJkTp7s2AX6JvDknJ4g==;
		this.#=zHizNmxAqiU8a.AutoSize = true;
		this.#=zHizNmxAqiU8a.Location = new Point(8, 167);
		this.#=zHizNmxAqiU8a.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094151);
		this.#=zHizNmxAqiU8a.Size = new Size(107, 13);
		this.#=zHizNmxAqiU8a.TabIndex = 9;
		this.#=zHizNmxAqiU8a.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094383);
		this.#=zQ$fRNX7$l$D8.Location = new Point(13, 436);
		this.#=zQ$fRNX7$l$D8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096472);
		this.#=zQ$fRNX7$l$D8.Size = new Size(110, 23);
		this.#=zQ$fRNX7$l$D8.TabIndex = 3;
		this.#=zQ$fRNX7$l$D8.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112827);
		this.#=zQ$fRNX7$l$D8.UseVisualStyleBackColor = true;
		this.#=zQ$fRNX7$l$D8.Click += this.#=zB5BkP1nkYssbrDWeNg==;
		this.#=zZ_J8a9DbQI5$$lOyQw==.Location = new Point(372, 212);
		this.#=zZ_J8a9DbQI5$$lOyQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094581);
		this.#=zZ_J8a9DbQI5$$lOyQw==.Size = new Size(184, 183);
		this.#=zZ_J8a9DbQI5$$lOyQw==.TabIndex = 2;
		this.#=zIKkwWpOCxG5A.Location = new Point(109, 212);
		this.#=zIKkwWpOCxG5A.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094552);
		this.#=zIKkwWpOCxG5A.Size = new Size(184, 183);
		this.#=zIKkwWpOCxG5A.TabIndex = 2;
		this.#=zulTJPbH8Sy1jOye98g==.AutoSize = true;
		this.#=zulTJPbH8Sy1jOye98g==.Location = new Point(299, 212);
		this.#=zulTJPbH8Sy1jOye98g==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094543);
		this.#=zulTJPbH8Sy1jOye98g==.Size = new Size(49, 13);
		this.#=zulTJPbH8Sy1jOye98g==.TabIndex = 0;
		this.#=zulTJPbH8Sy1jOye98g==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094259);
		this.#=zbSLhtDkqeUY2.Location = new Point(147, 164);
		this.#=zbSLhtDkqeUY2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094209);
		this.#=zbSLhtDkqeUY2.ReadOnly = true;
		this.#=zbSLhtDkqeUY2.Size = new Size(250, 20);
		this.#=zbSLhtDkqeUY2.TabIndex = 1;
		this.#=zdWP_yO1hX5VO.Location = new Point(109, 138);
		this.#=zdWP_yO1hX5VO.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096448);
		this.#=zdWP_yO1hX5VO.Size = new Size(369, 20);
		this.#=zdWP_yO1hX5VO.TabIndex = 1;
		this.#=zy$2lUN9Z_ZDO.Location = new Point(108, 112);
		this.#=zy$2lUN9Z_ZDO.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096682);
		this.#=zy$2lUN9Z_ZDO.Size = new Size(369, 20);
		this.#=zy$2lUN9Z_ZDO.TabIndex = 1;
		this.#=zh4A34P1zKnxh.Location = new Point(108, 73);
		this.#=zh4A34P1zKnxh.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096668);
		this.#=zh4A34P1zKnxh.Size = new Size(369, 20);
		this.#=zh4A34P1zKnxh.TabIndex = 1;
		this.#=zNVRUv5ZYgNJ7.AutoSize = true;
		this.#=zNVRUv5ZYgNJ7.Location = new Point(9, 212);
		this.#=zNVRUv5ZYgNJ7.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094242);
		this.#=zNVRUv5ZYgNJ7.Size = new Size(39, 13);
		this.#=zNVRUv5ZYgNJ7.TabIndex = 0;
		this.#=zNVRUv5ZYgNJ7.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094230);
		this.#=zk$I7hVWIUFJw.AutoSize = true;
		this.#=zk$I7hVWIUFJw.Location = new Point(9, 34);
		this.#=zk$I7hVWIUFJw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096641);
		this.#=zk$I7hVWIUFJw.Size = new Size(90, 13);
		this.#=zk$I7hVWIUFJw.TabIndex = 0;
		this.#=zk$I7hVWIUFJw.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096641);
		this.#=zl4FBxfXpZiJd.AutoSize = true;
		this.#=zl4FBxfXpZiJd.Location = new Point(9, 12);
		this.#=zl4FBxfXpZiJd.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096616);
		this.#=zl4FBxfXpZiJd.Size = new Size(234, 13);
		this.#=zl4FBxfXpZiJd.TabIndex = 0;
		this.#=zl4FBxfXpZiJd.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096594);
		this.#=zD6a$h9woJe6b6K_9AA==.AutoSize = true;
		this.#=zD6a$h9woJe6b6K_9AA==.Location = new Point(39, 96);
		this.#=zD6a$h9woJe6b6K_9AA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096292);
		this.#=zD6a$h9woJe6b6K_9AA==.Size = new Size(431, 13);
		this.#=zD6a$h9woJe6b6K_9AA==.TabIndex = 0;
		this.#=zD6a$h9woJe6b6K_9AA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096257);
		this.#=zAitLr626tg7W.AutoSize = true;
		this.#=zAitLr626tg7W.Location = new Point(8, 141);
		this.#=zAitLr626tg7W.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096415);
		this.#=zAitLr626tg7W.Size = new Size(41, 13);
		this.#=zAitLr626tg7W.TabIndex = 0;
		this.#=zAitLr626tg7W.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096387);
		this.#=z_GvTv94wzETO.AutoSize = true;
		this.#=z_GvTv94wzETO.Location = new Point(8, 115);
		this.#=z_GvTv94wzETO.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096370);
		this.#=z_GvTv94wzETO.Size = new Size(47, 13);
		this.#=z_GvTv94wzETO.TabIndex = 0;
		this.#=z_GvTv94wzETO.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096358);
		this.#=z3XW3F7TvLOV4.AutoSize = true;
		this.#=z3XW3F7TvLOV4.Location = new Point(8, 76);
		this.#=z3XW3F7TvLOV4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096337);
		this.#=z3XW3F7TvLOV4.Size = new Size(63, 13);
		this.#=z3XW3F7TvLOV4.TabIndex = 0;
		this.#=z3XW3F7TvLOV4.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094639);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=z28VQqnF53EWYSHC9Hw==);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=z1Z7CJk9aeKqJ9o6pGw==);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=z3DnZaJENSmpLrdeYZ5r_yLw=);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=znecOE6MM5Ua7TTK7$A==);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=zZldHY7ZLB863nY$N8wcXmlM=);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=z_$fdDq23wMGTTG6OS_j0LLE=);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Controls.Add(this.#=zZP5GaR7JCy3BF5IDafZGXMk=);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Location = new Point(4, 22);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096324);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Padding = new Padding(3);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Size = new Size(707, 506);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.TabIndex = 0;
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096044);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.UseVisualStyleBackColor = true;
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.Location = new Point(97, 164);
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096020);
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.Size = new Size(126, 23);
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.TabIndex = 16;
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095990);
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.UseVisualStyleBackColor = true;
		this.#=z9E20iPCyjQmye2odFRDBUP9j2M1d.Click += this.#=zJVq6shVeOVaHhO_6fGQygm51vxM2gI6IeA==;
		this.#=z28VQqnF53EWYSHC9Hw==.Location = new Point(162, 96);
		this.#=z28VQqnF53EWYSHC9Hw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095975);
		this.#=z28VQqnF53EWYSHC9Hw==.ReadOnly = true;
		this.#=z28VQqnF53EWYSHC9Hw==.Size = new Size(100, 20);
		this.#=z28VQqnF53EWYSHC9Hw==.TabIndex = 14;
		this.#=z1Z7CJk9aeKqJ9o6pGw==.AutoSize = true;
		this.#=z1Z7CJk9aeKqJ9o6pGw==.Location = new Point(8, 99);
		this.#=z1Z7CJk9aeKqJ9o6pGw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095951);
		this.#=z1Z7CJk9aeKqJ9o6pGw==.Size = new Size(90, 13);
		this.#=z1Z7CJk9aeKqJ9o6pGw==.TabIndex = 15;
		this.#=z1Z7CJk9aeKqJ9o6pGw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096177);
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.Location = new Point(162, 30);
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096159);
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.ReadOnly = true;
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.Size = new Size(100, 20);
		this.#=z3DnZaJENSmpLrdeYZ5r_yLw=.TabIndex = 10;
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.FormattingEnabled = true;
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096133),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096125),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096117),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096109),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096101),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096093),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096085),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096077),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096069),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097842),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097835)
		});
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.Location = new Point(162, 69);
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097824);
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.Size = new Size(100, 21);
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.TabIndex = 8;
		this.#=zzz$wJnTwapNKOQdQC5fvzSzJXNkr.SelectedIndexChanged += this.#=z9AJXvFf9GaiEEPol0fHOTqcN3$jMPJZ7sQ==;
		this.#=znecOE6MM5Ua7TTK7$A==.AutoSize = true;
		this.#=znecOE6MM5Ua7TTK7$A==.Location = new Point(8, 53);
		this.#=znecOE6MM5Ua7TTK7$A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097804);
		this.#=znecOE6MM5Ua7TTK7$A==.Size = new Size(286, 13);
		this.#=znecOE6MM5Ua7TTK7$A==.TabIndex = 13;
		this.#=znecOE6MM5Ua7TTK7$A==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097780);
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.AutoSize = true;
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.Location = new Point(8, 72);
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097961);
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.Size = new Size(99, 13);
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.TabIndex = 12;
		this.#=zZldHY7ZLB863nY$N8wcXmlM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097942);
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.AutoSize = true;
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.Location = new Point(8, 14);
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097917);
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.Size = new Size(411, 13);
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.TabIndex = 11;
		this.#=z_$fdDq23wMGTTG6OS_j0LLE=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097880);
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.AutoSize = true;
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.Location = new Point(8, 33);
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097531);
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.Size = new Size(123, 13);
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.TabIndex = 9;
		this.#=zZP5GaR7JCy3BF5IDafZGXMk=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097507);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=z3VxhX4vmfkzAsIVU0Q==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zs1T9oEstBUZ9yRcBRXKFYkc=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zz_L3utLXKNsuQEhuWQ==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=ziO2mCdoKTehYyXFaqw==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zqp029NOgEAYCqhdV0JB1ZSQ=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zJAngXo8=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=znI0IIBo=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zNufWClXIfVqnsUqFDw==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zn8JEATVYHa936iJluA==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zP54rRK3aAj4yTgWtyUtqnHs=);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zUOTYnW10Q6yd3K3r$A==);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=z1ldt_ASfsMCR);
		this.#=zZ4JrpNQLGWur.Controls.Add(this.#=zj9eTMBAprGTZ);
		this.#=zZ4JrpNQLGWur.Location = new Point(4, 22);
		this.#=zZ4JrpNQLGWur.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097472);
		this.#=zZ4JrpNQLGWur.Size = new Size(707, 506);
		this.#=zZ4JrpNQLGWur.TabIndex = 2;
		this.#=zZ4JrpNQLGWur.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097707);
		this.#=zZ4JrpNQLGWur.UseVisualStyleBackColor = true;
		this.#=z3VxhX4vmfkzAsIVU0Q==.CustomFormat = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874);
		this.#=z3VxhX4vmfkzAsIVU0Q==.Enabled = false;
		this.#=z3VxhX4vmfkzAsIVU0Q==.Format = DateTimePickerFormat.Custom;
		this.#=z3VxhX4vmfkzAsIVU0Q==.ImeMode = ImeMode.NoControl;
		this.#=z3VxhX4vmfkzAsIVU0Q==.Location = new Point(342, 54);
		this.#=z3VxhX4vmfkzAsIVU0Q==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097682);
		this.#=z3VxhX4vmfkzAsIVU0Q==.Size = new Size(110, 20);
		this.#=z3VxhX4vmfkzAsIVU0Q==.TabIndex = 26;
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.CustomFormat = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874);
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Format = DateTimePickerFormat.Custom;
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.ImeMode = ImeMode.NoControl;
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Location = new Point(159, 54);
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097660);
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.Size = new Size(110, 20);
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.TabIndex = 26;
		this.#=zs1T9oEstBUZ9yRcBRXKFYkc=.ValueChanged += this.#=zTXbCgwdWDyJrE$RqbuDI$GQ=;
		this.#=zz_L3utLXKNsuQEhuWQ==.Location = new Point(342, 28);
		this.#=zz_L3utLXKNsuQEhuWQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097625);
		this.#=zz_L3utLXKNsuQEhuWQ==.ReadOnly = true;
		this.#=zz_L3utLXKNsuQEhuWQ==.Size = new Size(110, 20);
		this.#=zz_L3utLXKNsuQEhuWQ==.TabIndex = 25;
		this.#=ziO2mCdoKTehYyXFaqw==.Location = new Point(159, 28);
		this.#=ziO2mCdoKTehYyXFaqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097339);
		this.#=ziO2mCdoKTehYyXFaqw==.Size = new Size(110, 20);
		this.#=ziO2mCdoKTehYyXFaqw==.TabIndex = 25;
		this.#=ziO2mCdoKTehYyXFaqw==.TextChanged += this.#=za8Qsl85XuRoXl1RFKgzlJ10=;
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.Location = new Point(61, 159);
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097316);
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.Size = new Size(126, 23);
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.TabIndex = 24;
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095990);
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.UseVisualStyleBackColor = true;
		this.#=zIxZIAJwTRLq5Sg_upYnk2dQ=.Click += this.#=zfd$tx5gdjnV8Ce4Y2JdpH48=;
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Location = new Point(159, 106);
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097281);
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.ReadOnly = true;
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.Size = new Size(110, 20);
		this.#=zqp029NOgEAYCqhdV0JB1ZSQ=.TabIndex = 22;
		this.#=zJAngXo8=.AutoSize = true;
		this.#=zJAngXo8=.Location = new Point(12, 109);
		this.#=zJAngXo8=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		this.#=zJAngXo8=.Size = new Size(90, 13);
		this.#=zJAngXo8=.TabIndex = 23;
		this.#=zJAngXo8=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096177);
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.Location = new Point(342, 80);
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097251);
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.ReadOnly = true;
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.Size = new Size(110, 20);
		this.#=z7$hO76q0TBZAnysq_hXwnAdJZXo1.TabIndex = 19;
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Location = new Point(159, 80);
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097216);
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.ReadOnly = true;
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.Size = new Size(110, 20);
		this.#=zyX$NkZGHVVIzj6IzjYCAdELEllse.TabIndex = 19;
		this.#=znI0IIBo=.AutoSize = true;
		this.#=znI0IIBo=.Location = new Point(12, 83);
		this.#=znI0IIBo=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114426);
		this.#=znI0IIBo=.Size = new Size(123, 13);
		this.#=znI0IIBo=.TabIndex = 18;
		this.#=znI0IIBo=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097507);
		this.#=zNufWClXIfVqnsUqFDw==.AutoSize = true;
		this.#=zNufWClXIfVqnsUqFDw==.Location = new Point(12, 57);
		this.#=zNufWClXIfVqnsUqFDw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097440);
		this.#=zNufWClXIfVqnsUqFDw==.Size = new Size(61, 13);
		this.#=zNufWClXIfVqnsUqFDw==.TabIndex = 0;
		this.#=zNufWClXIfVqnsUqFDw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097417);
		this.#=zn8JEATVYHa936iJluA==.AutoSize = true;
		this.#=zn8JEATVYHa936iJluA==.Location = new Point(8, 12);
		this.#=zn8JEATVYHa936iJluA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097394);
		this.#=zn8JEATVYHa936iJluA==.Size = new Size(246, 13);
		this.#=zn8JEATVYHa936iJluA==.TabIndex = 0;
		this.#=zn8JEATVYHa936iJluA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097370);
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.AutoSize = true;
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.Location = new Point(275, 83);
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097056);
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.Size = new Size(75, 13);
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.TabIndex = 0;
		this.#=zP54rRK3aAj4yTgWtyUtqnHs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097027);
		this.#=zUOTYnW10Q6yd3K3r$A==.AutoSize = true;
		this.#=zUOTYnW10Q6yd3K3r$A==.Location = new Point(275, 57);
		this.#=zUOTYnW10Q6yd3K3r$A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097002);
		this.#=zUOTYnW10Q6yd3K3r$A==.Size = new Size(73, 13);
		this.#=zUOTYnW10Q6yd3K3r$A==.TabIndex = 0;
		this.#=zUOTYnW10Q6yd3K3r$A==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096983);
		this.#=z1ldt_ASfsMCR.AutoSize = true;
		this.#=z1ldt_ASfsMCR.Location = new Point(275, 31);
		this.#=z1ldt_ASfsMCR.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097209);
		this.#=z1ldt_ASfsMCR.Size = new Size(75, 13);
		this.#=z1ldt_ASfsMCR.TabIndex = 0;
		this.#=z1ldt_ASfsMCR.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097189);
		this.#=zj9eTMBAprGTZ.AutoSize = true;
		this.#=zj9eTMBAprGTZ.Location = new Point(12, 31);
		this.#=zj9eTMBAprGTZ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097167);
		this.#=zj9eTMBAprGTZ.Size = new Size(112, 13);
		this.#=zj9eTMBAprGTZ.TabIndex = 0;
		this.#=zj9eTMBAprGTZ.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097142);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=z9D_PbwmyAStRTU$A0Q==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zb8FbnD5Z6QHf0$6pxw==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zxm$B6RXE4um$$SavRuRsIBM=);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zWLMJV2cnqSbEPWcoAA==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zDSxgyRhIkdnWp$ILlA==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zde24AxXdJ7G3O$14AdfzJnI=);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zvEHrcVozHc8Rdq2R9g==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zzSueeGe2$Ao1jehiuOLf4uw=);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zuLt4NU7InhRW7LZ$Pg==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=ztgK$iuoNVx0EsgP46A==);
		this.#=zGa8QHA9k_S9k.Controls.Add(this.#=zMYAIoremXPQW7foA1A==);
		this.#=zGa8QHA9k_S9k.Location = new Point(4, 22);
		this.#=zGa8QHA9k_S9k.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097106);
		this.#=zGa8QHA9k_S9k.Size = new Size(707, 506);
		this.#=zGa8QHA9k_S9k.TabIndex = 5;
		this.#=zGa8QHA9k_S9k.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097707);
		this.#=zGa8QHA9k_S9k.UseVisualStyleBackColor = true;
		this.#=z9D_PbwmyAStRTU$A0Q==.Location = new Point(159, 60);
		this.#=z9D_PbwmyAStRTU$A0Q==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097094);
		this.#=z9D_PbwmyAStRTU$A0Q==.Size = new Size(110, 20);
		this.#=z9D_PbwmyAStRTU$A0Q==.TabIndex = 27;
		this.#=z9D_PbwmyAStRTU$A0Q==.TextChanged += this.#=zWNmfUm3JqTsgNj3Pj7xCHgE=;
		this.#=zb8FbnD5Z6QHf0$6pxw==.AutoSize = true;
		this.#=zb8FbnD5Z6QHf0$6pxw==.Location = new Point(8, 63);
		this.#=zb8FbnD5Z6QHf0$6pxw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098863);
		this.#=zb8FbnD5Z6QHf0$6pxw==.Size = new Size(112, 13);
		this.#=zb8FbnD5Z6QHf0$6pxw==.TabIndex = 26;
		this.#=zb8FbnD5Z6QHf0$6pxw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097142);
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.Location = new Point(221, 192);
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098838);
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.Size = new Size(126, 23);
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.TabIndex = 25;
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095990);
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.UseVisualStyleBackColor = true;
		this.#=zxm$B6RXE4um$$SavRuRsIBM=.Click += this.#=z4sazvwj2uunsIHGDx6Gl$_4=;
		this.#=zWLMJV2cnqSbEPWcoAA==.Location = new Point(159, 139);
		this.#=zWLMJV2cnqSbEPWcoAA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098813);
		this.#=zWLMJV2cnqSbEPWcoAA==.ReadOnly = true;
		this.#=zWLMJV2cnqSbEPWcoAA==.Size = new Size(110, 20);
		this.#=zWLMJV2cnqSbEPWcoAA==.TabIndex = 23;
		this.#=zDSxgyRhIkdnWp$ILlA==.AutoSize = true;
		this.#=zDSxgyRhIkdnWp$ILlA==.Location = new Point(8, 142);
		this.#=zDSxgyRhIkdnWp$ILlA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098779);
		this.#=zDSxgyRhIkdnWp$ILlA==.Size = new Size(90, 13);
		this.#=zDSxgyRhIkdnWp$ILlA==.TabIndex = 24;
		this.#=zDSxgyRhIkdnWp$ILlA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096177);
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.Location = new Point(159, 86);
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098755);
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.ReadOnly = true;
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.Size = new Size(110, 20);
		this.#=zde24AxXdJ7G3O$14AdfzJnI=.TabIndex = 19;
		this.#=zvEHrcVozHc8Rdq2R9g==.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zvEHrcVozHc8Rdq2R9g==.FormattingEnabled = true;
		this.#=zvEHrcVozHc8Rdq2R9g==.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096133),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096125),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096117),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096109),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096101),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096093),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096085),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096077),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096069),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097842),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097835)
		});
		this.#=zvEHrcVozHc8Rdq2R9g==.Location = new Point(159, 112);
		this.#=zvEHrcVozHc8Rdq2R9g==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098985);
		this.#=zvEHrcVozHc8Rdq2R9g==.Size = new Size(110, 21);
		this.#=zvEHrcVozHc8Rdq2R9g==.TabIndex = 17;
		this.#=zvEHrcVozHc8Rdq2R9g==.SelectedIndexChanged += this.#=zrbeG0l0GB_v1v4klqBB6aW9RzQsm;
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.AutoSize = true;
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.Location = new Point(8, 115);
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098961);
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.Size = new Size(99, 13);
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.TabIndex = 21;
		this.#=zzSueeGe2$Ao1jehiuOLf4uw=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097942);
		this.#=zuLt4NU7InhRW7LZ$Pg==.AutoSize = true;
		this.#=zuLt4NU7InhRW7LZ$Pg==.Location = new Point(8, 35);
		this.#=zuLt4NU7InhRW7LZ$Pg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098942);
		this.#=zuLt4NU7InhRW7LZ$Pg==.Size = new Size(433, 13);
		this.#=zuLt4NU7InhRW7LZ$Pg==.TabIndex = 20;
		this.#=zuLt4NU7InhRW7LZ$Pg==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098919);
		this.#=ztgK$iuoNVx0EsgP46A==.AutoSize = true;
		this.#=ztgK$iuoNVx0EsgP46A==.Location = new Point(8, 12);
		this.#=ztgK$iuoNVx0EsgP46A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098554);
		this.#=ztgK$iuoNVx0EsgP46A==.Size = new Size(314, 13);
		this.#=ztgK$iuoNVx0EsgP46A==.TabIndex = 20;
		this.#=ztgK$iuoNVx0EsgP46A==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098540);
		this.#=zMYAIoremXPQW7foA1A==.AutoSize = true;
		this.#=zMYAIoremXPQW7foA1A==.Location = new Point(8, 89);
		this.#=zMYAIoremXPQW7foA1A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098725);
		this.#=zMYAIoremXPQW7foA1A==.Size = new Size(123, 13);
		this.#=zMYAIoremXPQW7foA1A==.TabIndex = 18;
		this.#=zMYAIoremXPQW7foA1A==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097507);
		this.#=zYJQRiQwaQ4kV.Controls.Add(this.#=zqJyFyxsE2IJG);
		this.#=zYJQRiQwaQ4kV.Location = new Point(4, 22);
		this.#=zYJQRiQwaQ4kV.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098701);
		this.#=zYJQRiQwaQ4kV.Size = new Size(707, 506);
		this.#=zYJQRiQwaQ4kV.TabIndex = 3;
		this.#=zYJQRiQwaQ4kV.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098677);
		this.#=zYJQRiQwaQ4kV.UseVisualStyleBackColor = true;
		this.#=zqJyFyxsE2IJG.AllowUserToAddRows = false;
		this.#=zqJyFyxsE2IJG.AllowUserToDeleteRows = false;
		this.#=zqJyFyxsE2IJG.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zqJyFyxsE2IJG.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zp92nVVYeFRKT,
			this.#=zPe_CiuiwxF9T,
			this.#=zVUoPFP21sbnH9Gy9Mg==,
			this.#=zwHJ2OKHYCqt4acADQw==,
			this.#=zomB2s17oIl4u
		});
		this.#=zqJyFyxsE2IJG.Dock = DockStyle.Fill;
		this.#=zqJyFyxsE2IJG.Location = new Point(0, 0);
		this.#=zqJyFyxsE2IJG.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098653);
		this.#=zqJyFyxsE2IJG.ReadOnly = true;
		this.#=zqJyFyxsE2IJG.Size = new Size(707, 506);
		this.#=zqJyFyxsE2IJG.TabIndex = 0;
		this.#=zp92nVVYeFRKT.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098627);
		this.#=zp92nVVYeFRKT.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098364);
		this.#=zp92nVVYeFRKT.ReadOnly = true;
		this.#=zPe_CiuiwxF9T.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098337);
		this.#=zPe_CiuiwxF9T.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098320);
		this.#=zPe_CiuiwxF9T.ReadOnly = true;
		this.#=zVUoPFP21sbnH9Gy9Mg==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098299);
		this.#=zVUoPFP21sbnH9Gy9Mg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098286);
		this.#=zVUoPFP21sbnH9Gy9Mg==.ReadOnly = true;
		this.#=zwHJ2OKHYCqt4acADQw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098261);
		this.#=zwHJ2OKHYCqt4acADQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098490);
		this.#=zwHJ2OKHYCqt4acADQw==.ReadOnly = true;
		this.#=zomB2s17oIl4u.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110886);
		this.#=zomB2s17oIl4u.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098476);
		this.#=zomB2s17oIl4u.ReadOnly = true;
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.Controls.Add(this.#=zyW6tUg8x6X7Rtch_Og==);
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.Location = new Point(4, 22);
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098453);
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.Size = new Size(707, 506);
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.TabIndex = 6;
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098429);
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.UseVisualStyleBackColor = true;
		this.#=zyW6tUg8x6X7Rtch_Og==.Dock = DockStyle.Fill;
		this.#=zyW6tUg8x6X7Rtch_Og==.FixedPanel = FixedPanel.Panel1;
		this.#=zyW6tUg8x6X7Rtch_Og==.Location = new Point(0, 0);
		this.#=zyW6tUg8x6X7Rtch_Og==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098402);
		this.#=zyW6tUg8x6X7Rtch_Og==.Orientation = Orientation.Horizontal;
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel1.Controls.Add(this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O);
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel1.Controls.Add(this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4);
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel2.Controls.Add(this.#=z4ypj1ynO7InLUUaszw==);
		this.#=zyW6tUg8x6X7Rtch_Og==.Size = new Size(707, 506);
		this.#=zyW6tUg8x6X7Rtch_Og==.SplitterDistance = 28;
		this.#=zyW6tUg8x6X7Rtch_Og==.TabIndex = 0;
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.AutoSize = true;
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.Location = new Point(8, 9);
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098382);
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.Size = new Size(77, 13);
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.TabIndex = 0;
		this.#=z$Akl1OYubN3VpXrawRsLj2n4Q1C4.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098088);
		this.#=z4ypj1ynO7InLUUaszw==.AllowUserToAddRows = false;
		this.#=z4ypj1ynO7InLUUaszw==.AllowUserToDeleteRows = false;
		this.#=z4ypj1ynO7InLUUaszw==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z4ypj1ynO7InLUUaszw==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zNtL4QxEBbpNZ,
			this.#=zGIgkGYpf0y2r,
			this.#=zq$9udy2O2B57
		});
		this.#=z4ypj1ynO7InLUUaszw==.Dock = DockStyle.Fill;
		this.#=z4ypj1ynO7InLUUaszw==.Location = new Point(0, 0);
		this.#=z4ypj1ynO7InLUUaszw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098066);
		this.#=z4ypj1ynO7InLUUaszw==.ReadOnly = true;
		this.#=z4ypj1ynO7InLUUaszw==.Size = new Size(707, 474);
		this.#=z4ypj1ynO7InLUUaszw==.TabIndex = 0;
		this.#=zNtL4QxEBbpNZ.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zNtL4QxEBbpNZ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098049);
		this.#=zNtL4QxEBbpNZ.ReadOnly = true;
		this.#=zNtL4QxEBbpNZ.Width = 50;
		this.#=zGIgkGYpf0y2r.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zGIgkGYpf0y2r.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098025);
		this.#=zGIgkGYpf0y2r.ReadOnly = true;
		this.#=zGIgkGYpf0y2r.Width = 300;
		this.#=zq$9udy2O2B57.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110886);
		this.#=zq$9udy2O2B57.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098013);
		this.#=zq$9udy2O2B57.ReadOnly = true;
		this.#=zq$9udy2O2B57.Width = 150;
		this.#=zg4CxuGULGCNV.Controls.Add(this.#=z_mKf6YD5PB4N);
		this.#=zg4CxuGULGCNV.Location = new Point(4, 22);
		this.#=zg4CxuGULGCNV.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096574);
		this.#=zg4CxuGULGCNV.Size = new Size(707, 506);
		this.#=zg4CxuGULGCNV.TabIndex = 4;
		this.#=zg4CxuGULGCNV.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097991);
		this.#=zg4CxuGULGCNV.UseVisualStyleBackColor = true;
		this.#=z_mKf6YD5PB4N.Dock = DockStyle.Fill;
		this.#=z_mKf6YD5PB4N.FixedPanel = FixedPanel.Panel2;
		this.#=z_mKf6YD5PB4N.IsSplitterFixed = true;
		this.#=z_mKf6YD5PB4N.Location = new Point(0, 0);
		this.#=z_mKf6YD5PB4N.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098217);
		this.#=z_mKf6YD5PB4N.Orientation = Orientation.Horizontal;
		this.#=z_mKf6YD5PB4N.Panel1.Controls.Add(this.#=zv49GNBxNYfa3);
		this.#=z_mKf6YD5PB4N.Panel2.Controls.Add(this.#=z6VmbAYc895KH);
		this.#=z_mKf6YD5PB4N.Panel2.Controls.Add(this.#=zodZ_Q1M=);
		this.#=z_mKf6YD5PB4N.Panel2.Controls.Add(this.#=zkQprPmfCqtF4);
		this.#=z_mKf6YD5PB4N.Panel2.Controls.Add(this.#=z8Mz_LUk7Ew$k);
		this.#=z_mKf6YD5PB4N.Size = new Size(707, 506);
		this.#=z_mKf6YD5PB4N.SplitterDistance = 395;
		this.#=z_mKf6YD5PB4N.TabIndex = 0;
		this.#=zv49GNBxNYfa3.AllowUserToAddRows = false;
		this.#=zv49GNBxNYfa3.AllowUserToDeleteRows = false;
		this.#=zv49GNBxNYfa3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
		this.#=zv49GNBxNYfa3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
		this.#=zv49GNBxNYfa3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zv49GNBxNYfa3.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zs6TItfWQTZa0,
			this.#=zKFdUoSMADAPg,
			this.#=zbwDUKuPp7xt_
		});
		this.#=zv49GNBxNYfa3.Dock = DockStyle.Fill;
		this.#=zv49GNBxNYfa3.Location = new Point(0, 0);
		this.#=zv49GNBxNYfa3.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098186);
		this.#=zv49GNBxNYfa3.ReadOnly = true;
		this.#=zv49GNBxNYfa3.Size = new Size(707, 395);
		this.#=zv49GNBxNYfa3.TabIndex = 0;
		this.#=zs6TItfWQTZa0.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098627);
		this.#=zs6TItfWQTZa0.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098169);
		this.#=zs6TItfWQTZa0.ReadOnly = true;
		this.#=zs6TItfWQTZa0.Width = 61;
		this.#=zKFdUoSMADAPg.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098337);
		this.#=zKFdUoSMADAPg.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098145);
		this.#=zKFdUoSMADAPg.ReadOnly = true;
		this.#=zKFdUoSMADAPg.Width = 69;
		dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
		this.#=zbwDUKuPp7xt_.DefaultCellStyle = dataGridViewCellStyle;
		this.#=zbwDUKuPp7xt_.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909098127);
		this.#=zbwDUKuPp7xt_.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083512);
		this.#=zbwDUKuPp7xt_.ReadOnly = true;
		this.#=zbwDUKuPp7xt_.Width = 59;
		this.#=z6VmbAYc895KH.Location = new Point(167, 26);
		this.#=z6VmbAYc895KH.Multiline = true;
		this.#=z6VmbAYc895KH.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083488);
		this.#=z6VmbAYc895KH.Size = new Size(342, 61);
		this.#=z6VmbAYc895KH.TabIndex = 3;
		this.#=zodZ_Q1M=.AutoSize = true;
		this.#=zodZ_Q1M=.Location = new Point(8, 29);
		this.#=zodZ_Q1M=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114795);
		this.#=zodZ_Q1M=.Size = new Size(83, 13);
		this.#=zodZ_Q1M=.TabIndex = 2;
		this.#=zodZ_Q1M=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083477);
		this.#=zkQprPmfCqtF4.Location = new Point(526, 41);
		this.#=zkQprPmfCqtF4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083455);
		this.#=zkQprPmfCqtF4.Size = new Size(98, 33);
		this.#=zkQprPmfCqtF4.TabIndex = 1;
		this.#=zkQprPmfCqtF4.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102611);
		this.#=zkQprPmfCqtF4.UseVisualStyleBackColor = true;
		this.#=zkQprPmfCqtF4.Click += this.#=z$sDqQSzT8thv4$uwQg==;
		this.#=z8Mz_LUk7Ew$k.AutoSize = true;
		this.#=z8Mz_LUk7Ew$k.Location = new Point(8, 10);
		this.#=z8Mz_LUk7Ew$k.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083431);
		this.#=z8Mz_LUk7Ew$k.Size = new Size(452, 13);
		this.#=z8Mz_LUk7Ew$k.TabIndex = 0;
		this.#=z8Mz_LUk7Ew$k.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083407);
		this.#=zELv0raV1GVcf.Enabled = true;
		this.#=zELv0raV1GVcf.Interval = 10000;
		this.#=zELv0raV1GVcf.Tick += this.#=z_JAQvMpPDyxrIxegqw==;
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.AutoSize = true;
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.Location = new Point(100, 9);
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083553);
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.Size = new Size(13, 13);
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.TabIndex = 0;
		this.#=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(715, 532);
		base.Controls.Add(this.#=zHjh18Ft3a4lU);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083521);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083253);
		this.#=zHjh18Ft3a4lU.ResumeLayout(false);
		this.#=zy4o$YK077C4d.ResumeLayout(false);
		this.#=zy4o$YK077C4d.PerformLayout();
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.ResumeLayout(false);
		this.#=zhvjcx6HAi83ajmzN93Ps$jM=.PerformLayout();
		this.#=zZ4JrpNQLGWur.ResumeLayout(false);
		this.#=zZ4JrpNQLGWur.PerformLayout();
		this.#=zGa8QHA9k_S9k.ResumeLayout(false);
		this.#=zGa8QHA9k_S9k.PerformLayout();
		this.#=zYJQRiQwaQ4kV.ResumeLayout(false);
		((ISupportInitialize)this.#=zqJyFyxsE2IJG).EndInit();
		this.#=zZVD8EfXTOFxKO_do91qpM4Y=.ResumeLayout(false);
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel1.ResumeLayout(false);
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel1.PerformLayout();
		this.#=zyW6tUg8x6X7Rtch_Og==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zyW6tUg8x6X7Rtch_Og==).EndInit();
		this.#=zyW6tUg8x6X7Rtch_Og==.ResumeLayout(false);
		((ISupportInitialize)this.#=z4ypj1ynO7InLUUaszw==).EndInit();
		this.#=zg4CxuGULGCNV.ResumeLayout(false);
		this.#=z_mKf6YD5PB4N.Panel1.ResumeLayout(false);
		this.#=z_mKf6YD5PB4N.Panel2.ResumeLayout(false);
		this.#=z_mKf6YD5PB4N.Panel2.PerformLayout();
		((ISupportInitialize)this.#=z_mKf6YD5PB4N).EndInit();
		this.#=z_mKf6YD5PB4N.ResumeLayout(false);
		((ISupportInitialize)this.#=zv49GNBxNYfa3).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x04000A31 RID: 2609
	private PriceRule #=zOq_3mEIuXx28OFtJqw==;

	// Token: 0x04000A32 RID: 2610
	private int #=zaF0ryKaY$_Z3_P3aM6TpW64=;

	// Token: 0x04000A33 RID: 2611
	private int #=zVQBvR58rFhMD;

	// Token: 0x04000A34 RID: 2612
	private int #=z_b8Df7JCQW88T8BJSd6roa8=;

	// Token: 0x04000A35 RID: 2613
	private int #=zQYvGJ$wMbysm;

	// Token: 0x04000A36 RID: 2614
	private List<int> #=zDVOGw0J6MGXLgMbq6A==;

	// Token: 0x04000A37 RID: 2615
	private Dictionary<string, object> #=zMpFfcVfAexF8n_wYig==;

	// Token: 0x04000A38 RID: 2616
	private int #=zY5HQxiivZOshM9LQEQ==;

	// Token: 0x04000A39 RID: 2617
	private string #=zU$cJ2IT6vqI12uxV7g==;

	// Token: 0x04000A3B RID: 2619
	private TabControl #=zHjh18Ft3a4lU;

	// Token: 0x04000A3C RID: 2620
	private TabPage #=zy4o$YK077C4d;

	// Token: 0x04000A3D RID: 2621
	private TabPage #=zhvjcx6HAi83ajmzN93Ps$jM=;

	// Token: 0x04000A3E RID: 2622
	private TabPage #=zZ4JrpNQLGWur;

	// Token: 0x04000A3F RID: 2623
	private TextBox #=zh4A34P1zKnxh;

	// Token: 0x04000A40 RID: 2624
	private Label #=z3XW3F7TvLOV4;

	// Token: 0x04000A41 RID: 2625
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=zIKkwWpOCxG5A;

	// Token: 0x04000A42 RID: 2626
	private Label #=zNVRUv5ZYgNJ7;

	// Token: 0x04000A43 RID: 2627
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=zZ_J8a9DbQI5$$lOyQw==;

	// Token: 0x04000A44 RID: 2628
	private Label #=zulTJPbH8Sy1jOye98g==;

	// Token: 0x04000A45 RID: 2629
	private Button #=zQ$fRNX7$l$D8;

	// Token: 0x04000A46 RID: 2630
	private Label #=zl4FBxfXpZiJd;

	// Token: 0x04000A47 RID: 2631
	private TextBox #=z3DnZaJENSmpLrdeYZ5r_yLw=;

	// Token: 0x04000A48 RID: 2632
	private ComboBox #=zzz$wJnTwapNKOQdQC5fvzSzJXNkr;

	// Token: 0x04000A49 RID: 2633
	private Label #=znecOE6MM5Ua7TTK7$A==;

	// Token: 0x04000A4A RID: 2634
	private Label #=zZldHY7ZLB863nY$N8wcXmlM=;

	// Token: 0x04000A4B RID: 2635
	private Label #=z_$fdDq23wMGTTG6OS_j0LLE=;

	// Token: 0x04000A4C RID: 2636
	private Label #=zZP5GaR7JCy3BF5IDafZGXMk=;

	// Token: 0x04000A4D RID: 2637
	private TextBox #=z28VQqnF53EWYSHC9Hw==;

	// Token: 0x04000A4E RID: 2638
	private Label #=z1Z7CJk9aeKqJ9o6pGw==;

	// Token: 0x04000A4F RID: 2639
	private Button #=z9E20iPCyjQmye2odFRDBUP9j2M1d;

	// Token: 0x04000A50 RID: 2640
	private Label #=zNufWClXIfVqnsUqFDw==;

	// Token: 0x04000A51 RID: 2641
	private Label #=zj9eTMBAprGTZ;

	// Token: 0x04000A52 RID: 2642
	private Label #=zn8JEATVYHa936iJluA==;

	// Token: 0x04000A53 RID: 2643
	private TabPage #=zYJQRiQwaQ4kV;

	// Token: 0x04000A54 RID: 2644
	private TabPage #=zg4CxuGULGCNV;

	// Token: 0x04000A55 RID: 2645
	private Button #=zIxZIAJwTRLq5Sg_upYnk2dQ=;

	// Token: 0x04000A56 RID: 2646
	private TextBox #=zqp029NOgEAYCqhdV0JB1ZSQ=;

	// Token: 0x04000A57 RID: 2647
	private Label #=zJAngXo8=;

	// Token: 0x04000A58 RID: 2648
	private TextBox #=zyX$NkZGHVVIzj6IzjYCAdELEllse;

	// Token: 0x04000A59 RID: 2649
	private Label #=znI0IIBo=;

	// Token: 0x04000A5A RID: 2650
	private DateTimePicker #=zs1T9oEstBUZ9yRcBRXKFYkc=;

	// Token: 0x04000A5B RID: 2651
	private TextBox #=ziO2mCdoKTehYyXFaqw==;

	// Token: 0x04000A5C RID: 2652
	private SplitContainer #=z_mKf6YD5PB4N;

	// Token: 0x04000A5D RID: 2653
	private Label #=z8Mz_LUk7Ew$k;

	// Token: 0x04000A5E RID: 2654
	private TextBox #=z6VmbAYc895KH;

	// Token: 0x04000A5F RID: 2655
	private Label #=zodZ_Q1M=;

	// Token: 0x04000A60 RID: 2656
	private Button #=zkQprPmfCqtF4;

	// Token: 0x04000A61 RID: 2657
	private DataGridView #=zv49GNBxNYfa3;

	// Token: 0x04000A62 RID: 2658
	private DataGridView #=zqJyFyxsE2IJG;

	// Token: 0x04000A63 RID: 2659
	private DataGridViewTextBoxColumn #=zp92nVVYeFRKT;

	// Token: 0x04000A64 RID: 2660
	private DataGridViewTextBoxColumn #=zPe_CiuiwxF9T;

	// Token: 0x04000A65 RID: 2661
	private DataGridViewTextBoxColumn #=zVUoPFP21sbnH9Gy9Mg==;

	// Token: 0x04000A66 RID: 2662
	private DataGridViewTextBoxColumn #=zwHJ2OKHYCqt4acADQw==;

	// Token: 0x04000A67 RID: 2663
	private DataGridViewTextBoxColumn #=zomB2s17oIl4u;

	// Token: 0x04000A68 RID: 2664
	private DateTimePicker #=z3VxhX4vmfkzAsIVU0Q==;

	// Token: 0x04000A69 RID: 2665
	private TextBox #=zz_L3utLXKNsuQEhuWQ==;

	// Token: 0x04000A6A RID: 2666
	private TextBox #=z7$hO76q0TBZAnysq_hXwnAdJZXo1;

	// Token: 0x04000A6B RID: 2667
	private Label #=zP54rRK3aAj4yTgWtyUtqnHs=;

	// Token: 0x04000A6C RID: 2668
	private Label #=zUOTYnW10Q6yd3K3r$A==;

	// Token: 0x04000A6D RID: 2669
	private Label #=z1ldt_ASfsMCR;

	// Token: 0x04000A6E RID: 2670
	private TabPage #=zGa8QHA9k_S9k;

	// Token: 0x04000A6F RID: 2671
	private Button #=zxm$B6RXE4um$$SavRuRsIBM=;

	// Token: 0x04000A70 RID: 2672
	private TextBox #=zWLMJV2cnqSbEPWcoAA==;

	// Token: 0x04000A71 RID: 2673
	private Label #=zDSxgyRhIkdnWp$ILlA==;

	// Token: 0x04000A72 RID: 2674
	private TextBox #=zde24AxXdJ7G3O$14AdfzJnI=;

	// Token: 0x04000A73 RID: 2675
	private ComboBox #=zvEHrcVozHc8Rdq2R9g==;

	// Token: 0x04000A74 RID: 2676
	private Label #=zzSueeGe2$Ao1jehiuOLf4uw=;

	// Token: 0x04000A75 RID: 2677
	private Label #=ztgK$iuoNVx0EsgP46A==;

	// Token: 0x04000A76 RID: 2678
	private Label #=zMYAIoremXPQW7foA1A==;

	// Token: 0x04000A77 RID: 2679
	private TextBox #=z9D_PbwmyAStRTU$A0Q==;

	// Token: 0x04000A78 RID: 2680
	private Label #=zb8FbnD5Z6QHf0$6pxw==;

	// Token: 0x04000A79 RID: 2681
	private Label #=zuLt4NU7InhRW7LZ$Pg==;

	// Token: 0x04000A7A RID: 2682
	private Label #=zk$I7hVWIUFJw;

	// Token: 0x04000A7B RID: 2683
	private Timer #=zELv0raV1GVcf;

	// Token: 0x04000A7C RID: 2684
	private DataGridViewTextBoxColumn #=zs6TItfWQTZa0;

	// Token: 0x04000A7D RID: 2685
	private DataGridViewTextBoxColumn #=zKFdUoSMADAPg;

	// Token: 0x04000A7E RID: 2686
	private DataGridViewTextBoxColumn #=zbwDUKuPp7xt_;

	// Token: 0x04000A7F RID: 2687
	private TextBox #=zdWP_yO1hX5VO;

	// Token: 0x04000A80 RID: 2688
	private TextBox #=zy$2lUN9Z_ZDO;

	// Token: 0x04000A81 RID: 2689
	private Label #=zD6a$h9woJe6b6K_9AA==;

	// Token: 0x04000A82 RID: 2690
	private Label #=zAitLr626tg7W;

	// Token: 0x04000A83 RID: 2691
	private Label #=z_GvTv94wzETO;

	// Token: 0x04000A84 RID: 2692
	private TextBox #=zbSLhtDkqeUY2;

	// Token: 0x04000A85 RID: 2693
	private Button #=zkL8xlualzf7P;

	// Token: 0x04000A86 RID: 2694
	private Label #=zHizNmxAqiU8a;

	// Token: 0x04000A87 RID: 2695
	private TabPage #=zZVD8EfXTOFxKO_do91qpM4Y=;

	// Token: 0x04000A88 RID: 2696
	private SplitContainer #=zyW6tUg8x6X7Rtch_Og==;

	// Token: 0x04000A89 RID: 2697
	private Label #=z$Akl1OYubN3VpXrawRsLj2n4Q1C4;

	// Token: 0x04000A8A RID: 2698
	private DataGridView #=z4ypj1ynO7InLUUaszw==;

	// Token: 0x04000A8B RID: 2699
	private DataGridViewTextBoxColumn #=zNtL4QxEBbpNZ;

	// Token: 0x04000A8C RID: 2700
	private DataGridViewTextBoxColumn #=zGIgkGYpf0y2r;

	// Token: 0x04000A8D RID: 2701
	private DataGridViewTextBoxColumn #=zq$9udy2O2B57;

	// Token: 0x04000A8E RID: 2702
	private Label #=zfy96Q9C8GWsY3s9uRcVLUrwFWD3O;
}
