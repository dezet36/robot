﻿using System;
using System.Collections.Generic;

// Token: 0x020001B9 RID: 441
internal sealed class #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==
{
	// Token: 0x06000D36 RID: 3382 RVA: 0x000682D8 File Offset: 0x000664D8
	public #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==()
	{
		this.#=ztbawIJA= = new Dictionary<int, int>();
	}

	// Token: 0x06000D37 RID: 3383 RVA: 0x000682EC File Offset: 0x000664EC
	public int #=zM6O9jPw=(int #=zNraCe1Y=)
	{
		if (!this.#=ztbawIJA=.ContainsKey(#=zNraCe1Y=))
		{
			return 0;
		}
		return this.#=ztbawIJA=[#=zNraCe1Y=];
	}

	// Token: 0x06000D38 RID: 3384 RVA: 0x0006830C File Offset: 0x0006650C
	public void #=z48rEd0A=(int #=zNraCe1Y=, int #=z4UDysxM=)
	{
		if (#=z4UDysxM= != 0)
		{
			if (!this.#=ztbawIJA=.ContainsKey(#=zNraCe1Y=))
			{
				this.#=ztbawIJA=.Add(#=zNraCe1Y=, #=z4UDysxM=);
				return;
			}
			Dictionary<int, int> dictionary = this.#=ztbawIJA=;
			dictionary[#=zNraCe1Y=] += #=z4UDysxM=;
		}
	}

	// Token: 0x06000D39 RID: 3385 RVA: 0x00068354 File Offset: 0x00066554
	public void #=zZkwn0zY=(int #=zNraCe1Y=, int #=z4UDysxM=)
	{
		this.#=z48rEd0A=(#=zNraCe1Y=, -#=z4UDysxM=);
	}

	// Token: 0x040007A3 RID: 1955
	private Dictionary<int, int> #=ztbawIJA=;
}
