﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200018D RID: 397
internal sealed class #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
{
	// Token: 0x06000B56 RID: 2902 RVA: 0x000576AC File Offset: 0x000558AC
	public #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==(Dictionary<string, object> #=zvbjYUn62du2Z, #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=zY6BuiKQeE9Eb, bool #=zI4X9JLg=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zvbjYUn62du2Z, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zzQwUIEs=(#=zY6BuiKQeE9Eb.#=zd634hMCtcd$T(JSONManager.ExtractInt(#=zvbjYUn62du2Z, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0)));
		this.#=zFzGvi_S6jJhE(JSONManager.GetInt(#=zvbjYUn62du2Z, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073153), 0));
		if (#=zI4X9JLg=)
		{
			this.#=zlaFV2ewZfrpD(JSONManager.GetInt(#=zvbjYUn62du2Z, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059747), 0));
			return;
		}
		this.#=zlaFV2ewZfrpD(-1);
	}

	// Token: 0x06000B57 RID: 2903 RVA: 0x0005772C File Offset: 0x0005592C
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000B58 RID: 2904 RVA: 0x00057734 File Offset: 0x00055934
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B59 RID: 2905 RVA: 0x00057740 File Offset: 0x00055940
	public #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000B5A RID: 2906 RVA: 0x00057748 File Offset: 0x00055948
	public void #=zzQwUIEs=(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B5B RID: 2907 RVA: 0x00057754 File Offset: 0x00055954
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000B5C RID: 2908 RVA: 0x0005775C File Offset: 0x0005595C
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B5D RID: 2909 RVA: 0x00057768 File Offset: 0x00055968
	public int #=zx0VSW$qAY8R7()
	{
		return this.#=zQoLWHdkk8xlVAi_QKVpBOvY=;
	}

	// Token: 0x06000B5E RID: 2910 RVA: 0x00057770 File Offset: 0x00055970
	public void #=zlaFV2ewZfrpD(int #=z$Ib9gYQ=)
	{
		this.#=zQoLWHdkk8xlVAi_QKVpBOvY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B5F RID: 2911 RVA: 0x0005777C File Offset: 0x0005597C
	public bool #=z7BFVhqWl1c$0()
	{
		return this.#=zx0VSW$qAY8R7() > 0;
	}

	// Token: 0x06000B60 RID: 2912 RVA: 0x00057788 File Offset: 0x00055988
	public override string ToString()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070446), this.#=zq2bPTdY=().#=zTbtwDpWhYGtF(), this.#=zvnZc$RhG_1Du());
	}

	// Token: 0x0400061C RID: 1564
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400061D RID: 1565
	private #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400061E RID: 1566
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400061F RID: 1567
	private int #=zQoLWHdkk8xlVAi_QKVpBOvY=;
}
