﻿using System;
using System.Collections.Generic;
using System.Text;

// Token: 0x020000C7 RID: 199
internal sealed class #=zBNSjuxymwpzVeRYZu29JmEUUd7y_ZQcnPw== : List<#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==>
{
	// Token: 0x0600053A RID: 1338 RVA: 0x0002CF6C File Offset: 0x0002B16C
	public #=zBNSjuxymwpzVeRYZu29JmEUUd7y_ZQcnPw==()
	{
		this.#=zVCCSzXRqmeZT = DateTime.MinValue;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x0002CF80 File Offset: 0x0002B180
	public void #=zbPId9eg=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		foreach (#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ== #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ== in this)
		{
			if (#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==.#=zYgvZuBwR$a1C() == #=z8StzeqE=.#=zYgvZuBwR$a1C())
			{
				#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==.#=zbPId9eg=(#=z8StzeqE=);
				return;
			}
		}
		#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ== #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==2 = new #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==(#=z8StzeqE=.#=zYgvZuBwR$a1C());
		#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==2.#=zbPId9eg=(#=z8StzeqE=);
		base.Add(#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==2);
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0002CFF8 File Offset: 0x0002B1F8
	public string #=zYBbhgs8=()
	{
		if (this.#=zVCCSzXRqmeZT + TimeSpan.FromMinutes(1.0) > DateTime.Now)
		{
			return null;
		}
		StringBuilder stringBuilder = new StringBuilder();
		foreach (#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ== #=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ== in this)
		{
			#=zU5mPxY6VhkgeFFalBhvDwFABvxsapAm2AQ==.#=zYBbhgs8=(stringBuilder);
		}
		this.#=zVCCSzXRqmeZT = DateTime.Now;
		return stringBuilder.ToString();
	}

	// Token: 0x04000210 RID: 528
	private DateTime #=zVCCSzXRqmeZT;
}
