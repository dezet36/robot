﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200012B RID: 299
internal sealed class #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== : Task
{
	// Token: 0x0600075A RID: 1882 RVA: 0x0003CDF4 File Offset: 0x0003AFF4
	public #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==(TaskSeverities #=z_qaYpFQ=, DateTime #=zxSBcx18=, TimeSpan #=znDUPTRWa892r, DateTime #=zYMNSoNFx5mMf, int #=z40sk5mc=, string #=zQI5IZCs=, int #=zjGWCwY9U9$J6, int #=zqPbvLIemTN_E, int #=zF$4fV_rTrQYB, bool #=zNSQxICs=, bool #=z3pHBEimzAfir) : base(TaskSources.Manual, #=z_qaYpFQ=, TaskTypes.SendResources, #=zxSBcx18=, TimeSpan.Zero, #=znDUPTRWa892r, #=znDUPTRWa892r, #=zYMNSoNFx5mMf, false)
	{
		this.#=zmVXP3Bk= = #=z40sk5mc=;
		this.#=zZcIa_pE= = #=zQI5IZCs=;
		this.#=z4mcRNLw= = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		this.#=z4mcRNLw=[ResourceTypes.Lumber] = #=zjGWCwY9U9$J6;
		this.#=z4mcRNLw=[ResourceTypes.Bronze] = #=zqPbvLIemTN_E;
		this.#=z4mcRNLw=[ResourceTypes.Grain] = #=zF$4fV_rTrQYB;
		if (#=zNSQxICs=)
		{
			base.Options |= TaskOptions.MasterIsSum;
		}
		if (#=z3pHBEimzAfir)
		{
			base.Options |= TaskOptions.PartialCompletionForbidden;
		}
	}

	// Token: 0x0600075B RID: 1883 RVA: 0x0003CE80 File Offset: 0x0003B080
	public #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x0600075C RID: 1884 RVA: 0x0003CE90 File Offset: 0x0003B090
	public #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==(MasterTask #=zwcZwAIGe3vUR) : base(#=zwcZwAIGe3vUR)
	{
		#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A== = (#=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==)#=zwcZwAIGe3vUR.Task;
		this.#=zmVXP3Bk= = #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.#=zuFPZLKs=();
		this.#=zZcIa_pE= = #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.Details;
		this.#=z4mcRNLw= = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		for (int i = 0; i < #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.#=z_tcU3ov4mZ9V().Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = #=zJMbm$GqPm7ZcA1YGsAiGunJrNWmgnMwh7A==.#=z_tcU3ov4mZ9V()[i];
			this.#=z4mcRNLw=.Add(new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=(), #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_()));
		}
	}

	// Token: 0x0600075D RID: 1885 RVA: 0x0003CF14 File Offset: 0x0003B114
	public int #=zuFPZLKs=()
	{
		return this.#=zmVXP3Bk=;
	}

	// Token: 0x0600075E RID: 1886 RVA: 0x0003CF1C File Offset: 0x0003B11C
	public #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z_tcU3ov4mZ9V()
	{
		return this.#=z4mcRNLw=;
	}

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x0600075F RID: 1887 RVA: 0x0003CF24 File Offset: 0x0003B124
	public override string Details
	{
		get
		{
			return this.#=zZcIa_pE=;
		}
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x0003CF2C File Offset: 0x0003B12C
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zmVXP3Bk= = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875413), 0);
		this.#=zZcIa_pE= = JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875397), string.Empty);
		this.#=z4mcRNLw= = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		this.#=z4mcRNLw=[ResourceTypes.Lumber] = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875112) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z9OFonzM=(ResourceTypes.Lumber), 0);
		this.#=z4mcRNLw=[ResourceTypes.Bronze] = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875112) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z9OFonzM=(ResourceTypes.Bronze), 0);
		this.#=z4mcRNLw=[ResourceTypes.Grain] = JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875112) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z9OFonzM=(ResourceTypes.Grain), 0);
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x0003CFF0 File Offset: 0x0003B1F0
	public override void UpdateTask(Dictionary<string, object> #=z8e5z318=)
	{
		base.UpdateTask(#=z8e5z318=);
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x06000762 RID: 1890 RVA: 0x0003D000 File Offset: 0x0003B200
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874411);
		}
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x0003D00C File Offset: 0x0003B20C
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875413)] = this.#=zmVXP3Bk=;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875397)] = this.#=zZcIa_pE=;
		for (int i = 0; i < this.#=z4mcRNLw=.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = this.#=z4mcRNLw=[i];
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875112) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z69SHZCTwoPe0()] = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_();
		}
		return dictionary;
	}

	// Token: 0x06000764 RID: 1892 RVA: 0x0003D09C File Offset: 0x0003B29C
	public void #=zmeOF8bE=(#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zNvCMwussKumm)
	{
		this.#=z4mcRNLw= = #=zNvCMwussKumm;
	}

	// Token: 0x04000469 RID: 1129
	private int #=zmVXP3Bk=;

	// Token: 0x0400046A RID: 1130
	private string #=zZcIa_pE=;

	// Token: 0x0400046B RID: 1131
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z4mcRNLw=;
}
