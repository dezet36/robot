﻿using System;

// Token: 0x020001F2 RID: 498
internal sealed class #=z_9QeQX33e0ZIk3yCxt1JB0I= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000F17 RID: 3863 RVA: 0x0007887C File Offset: 0x00076A7C
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQjb3XO3PMRiZ;
	}

	// Token: 0x06000F18 RID: 3864 RVA: 0x00078884 File Offset: 0x00076A84
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x06000F19 RID: 3865 RVA: 0x00078888 File Offset: 0x00076A88
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077047);
	}
}
