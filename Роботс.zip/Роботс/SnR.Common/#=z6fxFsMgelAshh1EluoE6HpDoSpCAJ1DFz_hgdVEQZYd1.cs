﻿using System;

// Token: 0x02000083 RID: 131
internal sealed class #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1
{
	// Token: 0x060003A0 RID: 928 RVA: 0x00020044 File Offset: 0x0001E244
	public #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zuFPZLKs=()
	{
		return this.#=zBli65MnJh7hzwNOS3A==;
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x0002004C File Offset: 0x0001E24C
	public void #=z2QfEz18=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z$Ib9gYQ=)
	{
		this.#=zBli65MnJh7hzwNOS3A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x00020058 File Offset: 0x0001E258
	public int #=zCF7_RpkTiHMeBeLmww==()
	{
		return this.#=zGZY1DEDEhdKF5u4AgvhUahk=;
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00020060 File Offset: 0x0001E260
	public void #=z5orudSfDy4LNHEoQIA==(int #=z$Ib9gYQ=)
	{
		this.#=zGZY1DEDEhdKF5u4AgvhUahk= = #=z$Ib9gYQ=;
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x0002006C File Offset: 0x0001E26C
	public int #=zIDq8g$CbFZo_EGdo3A==()
	{
		return this.#=z3DxkOoMWVqOqqe93av_HfKs=;
	}

	// Token: 0x060003A5 RID: 933 RVA: 0x00020074 File Offset: 0x0001E274
	public void #=zfyXaQpV5Bsw7FHPLkQ==(int #=z$Ib9gYQ=)
	{
		this.#=z3DxkOoMWVqOqqe93av_HfKs= = #=z$Ib9gYQ=;
	}

	// Token: 0x060003A6 RID: 934 RVA: 0x00020080 File Offset: 0x0001E280
	public int #=zlOl3uc8MyINDqgsIig==()
	{
		return this.#=zGTbMePEHhyoBgYQyP0YYy0KBK_5_;
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x00020088 File Offset: 0x0001E288
	public void #=zWvoMErZxim4Z9kYMcA==(int #=z$Ib9gYQ=)
	{
		this.#=zGTbMePEHhyoBgYQyP0YYy0KBK_5_ = #=z$Ib9gYQ=;
	}

	// Token: 0x04000144 RID: 324
	private #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zBli65MnJh7hzwNOS3A==;

	// Token: 0x04000145 RID: 325
	private int #=zGZY1DEDEhdKF5u4AgvhUahk=;

	// Token: 0x04000146 RID: 326
	private int #=z3DxkOoMWVqOqqe93av_HfKs=;

	// Token: 0x04000147 RID: 327
	private int #=zGTbMePEHhyoBgYQyP0YYy0KBK_5_;
}
