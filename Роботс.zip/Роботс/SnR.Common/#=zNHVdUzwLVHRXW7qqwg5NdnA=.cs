﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000168 RID: 360
internal sealed class #=zNHVdUzwLVHRXW7qqwg5NdnA= : RecordData
{
	// Token: 0x06000990 RID: 2448 RVA: 0x0004EAB4 File Offset: 0x0004CCB4
	public #=zNHVdUzwLVHRXW7qqwg5NdnA=(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		this.#=zW1gxjYqG9W$P = IntegerHelper.getInt(data[0], data[1]);
		this.#=ztDqY1PE4O3ql = IntegerHelper.getInt(data[2], data[3]);
	}

	// Token: 0x06000991 RID: 2449 RVA: 0x0004EAF4 File Offset: 0x0004CCF4
	public int #=zASqj2TProeAC()
	{
		return this.#=ztDqY1PE4O3ql;
	}

	// Token: 0x06000992 RID: 2450 RVA: 0x0004EAFC File Offset: 0x0004CCFC
	public int #=zxgGTN5gtGbv1()
	{
		return this.#=zW1gxjYqG9W$P;
	}

	// Token: 0x04000582 RID: 1410
	private int #=ztDqY1PE4O3ql;

	// Token: 0x04000583 RID: 1411
	private int #=zW1gxjYqG9W$P;
}
