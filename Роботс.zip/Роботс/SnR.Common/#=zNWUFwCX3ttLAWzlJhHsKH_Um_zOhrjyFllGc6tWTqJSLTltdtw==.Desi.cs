﻿// Token: 0x0200016C RID: 364
internal sealed partial class #=zNWUFwCX3ttLAWzlJhHsKH_Um_zOhrjyFllGc6tWTqJSLTltdtw== : global::System.Windows.Forms.Form
{
	// Token: 0x060009A7 RID: 2471 RVA: 0x0004F534 File Offset: 0x0004D734
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000590 RID: 1424
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
