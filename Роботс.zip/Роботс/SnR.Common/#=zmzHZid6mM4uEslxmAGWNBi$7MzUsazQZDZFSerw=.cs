﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200028F RID: 655
internal sealed class #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=
{
	// Token: 0x060013F3 RID: 5107 RVA: 0x00099694 File Offset: 0x00097894
	public #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=(Dictionary<string, object> #=zENl6JBMcM_HT)
	{
		if (#=zENl6JBMcM_HT == null)
		{
			this.#=zOVs_3_I6zSaa((#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)(-2));
			return;
		}
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907));
		this.#=z66cm4lqCyr5R(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0));
		this.#=zi_6u0xRzKwtSBRaV1A==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102));
		if (dictionary2 == null)
		{
			this.#=zOVs_3_I6zSaa((#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)(-1));
		}
		else
		{
			this.#=zOVs_3_I6zSaa((#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
			#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns= #=z7cLRqns= = this.#=zUfTNWZidqO78();
			if (#=z7cLRqns= != (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)1)
			{
				if (#=z7cLRqns= != (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)6)
				{
					this.#=z$rnyBwwJ6puDd8s97tfF6W4=(DateTime.MinValue);
				}
				else
				{
					this.#=z$rnyBwwJ6puDd8s97tfF6W4=(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false));
				}
			}
			else
			{
				this.#=z$rnyBwwJ6puDd8s97tfF6W4=(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), false));
			}
			Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094));
			this.#=zwHSAkH1AtVc9NJUnOA==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070777), 0));
			this.#=zCYjHh0wCJqNL6p9H24auTiRZ7qAs(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070774), 0) > 0);
		}
		this.#=zmFFxdB$L5hSh(JSONManager.ExtractInt(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), 0));
		this.#=zzbNE6frMgo5LwQ8H4g==(new Dictionary<int, List<int>>());
		object[] array = JSONManager.ExtractArray(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875));
		for (int i = 0; i < array.Length; i++)
		{
			foreach (string s in JSONManager.ExtractDictionary((Dictionary<string, object>)array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899)).Keys)
			{
				int key;
				int.TryParse(s, out key);
				List<int> list;
				if (this.#=zYlSZ5YTp$oZ0OXZ$0w==().ContainsKey(key))
				{
					list = this.#=zYlSZ5YTp$oZ0OXZ$0w==()[key];
				}
				else
				{
					list = new List<int>();
					this.#=zYlSZ5YTp$oZ0OXZ$0w==()[key] = list;
				}
				list.Add(i);
			}
		}
		this.#=z9GOrNaDcYqisg3UG0w==(new List<int>());
		foreach (int item in JSONManager.ExtractArray(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)))
		{
			this.#=ziykhCXyTCZYpuxBoRw==().Add(item);
		}
		this.#=z1J_1k$DmBJQeE4kz6A==(new Dictionary<int, List<int>>());
		Dictionary<string, object> dictionary4 = JSONManager.ExtractDictionary(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
		foreach (string text in dictionary4.Keys)
		{
			int key2;
			int.TryParse(text, out key2);
			List<int> list2 = new List<int>();
			this.#=zJMXLuIzrpbV4vH1Qzg==()[key2] = list2;
			foreach (int item2 in JSONManager.ExtractArray(dictionary4, text))
			{
				list2.Add(item2);
			}
		}
		if (!this.#=zJMXLuIzrpbV4vH1Qzg==().ContainsKey(0))
		{
			this.#=zJMXLuIzrpbV4vH1Qzg==()[0] = new List<int>();
		}
		this.#=zu2sJifER3$yvNnErNg==(JSONManager.ExtractInt(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
		this.#=zoMtpQ87JQEiofNpUnj02InjxO478(new Dictionary<int, int>());
		Dictionary<string, object> dictionary5 = JSONManager.ExtractDictionary(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759));
		if (dictionary5 != null)
		{
			foreach (string text2 in dictionary5.Keys)
			{
				int key3;
				if (int.TryParse(text2, out key3))
				{
					this.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS()[key3] = Convert.ToInt32(dictionary5[text2]);
				}
			}
		}
		this.#=zO5_GFfDHwG2VodxMmQ==(JSONManager.ExtractDate(#=zENl6JBMcM_HT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), false));
	}

	// Token: 0x060013F4 RID: 5108 RVA: 0x00099A60 File Offset: 0x00097C60
	public int #=zuYDXlhIvRg6q()
	{
		return this.#=zCxrfSyyH8ZJ1iKXpMHDrJcc=;
	}

	// Token: 0x060013F5 RID: 5109 RVA: 0x00099A68 File Offset: 0x00097C68
	public void #=z66cm4lqCyr5R(int #=z$Ib9gYQ=)
	{
		this.#=zCxrfSyyH8ZJ1iKXpMHDrJcc= = #=z$Ib9gYQ=;
	}

	// Token: 0x060013F6 RID: 5110 RVA: 0x00099A74 File Offset: 0x00097C74
	public int #=z9Crk68wxKePsBQzwsQ==()
	{
		return this.#=z$u57NtYq2e$GpVGzGP1nvjE=;
	}

	// Token: 0x060013F7 RID: 5111 RVA: 0x00099A7C File Offset: 0x00097C7C
	public void #=zi_6u0xRzKwtSBRaV1A==(int #=z$Ib9gYQ=)
	{
		this.#=z$u57NtYq2e$GpVGzGP1nvjE= = #=z$Ib9gYQ=;
	}

	// Token: 0x060013F8 RID: 5112 RVA: 0x00099A88 File Offset: 0x00097C88
	public #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns= #=zUfTNWZidqO78()
	{
		return this.#=zp8BbYYdlk2Kw3Orpeg==;
	}

	// Token: 0x060013F9 RID: 5113 RVA: 0x00099A90 File Offset: 0x00097C90
	public void #=zOVs_3_I6zSaa(#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns= #=z$Ib9gYQ=)
	{
		this.#=zp8BbYYdlk2Kw3Orpeg== = #=z$Ib9gYQ=;
	}

	// Token: 0x060013FA RID: 5114 RVA: 0x00099A9C File Offset: 0x00097C9C
	public DateTime #=zOH9mjMBOuMo$K3kunK642NM=()
	{
		return this.#=zTJHD1g0temVR$gAEg1aRIXqvFpw6;
	}

	// Token: 0x060013FB RID: 5115 RVA: 0x00099AA4 File Offset: 0x00097CA4
	public void #=z$rnyBwwJ6puDd8s97tfF6W4=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zTJHD1g0temVR$gAEg1aRIXqvFpw6 = #=z$Ib9gYQ=;
	}

	// Token: 0x060013FC RID: 5116 RVA: 0x00099AB0 File Offset: 0x00097CB0
	public int #=zEhPgbEtIwmM2wLM7qw==()
	{
		return this.#=zUZdtSZOkN4x2WGyno4GGfpmZXWGa;
	}

	// Token: 0x060013FD RID: 5117 RVA: 0x00099AB8 File Offset: 0x00097CB8
	public void #=zwHSAkH1AtVc9NJUnOA==(int #=z$Ib9gYQ=)
	{
		this.#=zUZdtSZOkN4x2WGyno4GGfpmZXWGa = #=z$Ib9gYQ=;
	}

	// Token: 0x060013FE RID: 5118 RVA: 0x00099AC4 File Offset: 0x00097CC4
	public bool #=zBVxHZ5ncbjenzDEfd4ZwPmNJvcNP()
	{
		return this.#=z4BW5W3f5Pd04F0JekMh8jW$XHJcUACuTRQ==;
	}

	// Token: 0x060013FF RID: 5119 RVA: 0x00099ACC File Offset: 0x00097CCC
	public void #=zCYjHh0wCJqNL6p9H24auTiRZ7qAs(bool #=z$Ib9gYQ=)
	{
		this.#=z4BW5W3f5Pd04F0JekMh8jW$XHJcUACuTRQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001400 RID: 5120 RVA: 0x00099AD8 File Offset: 0x00097CD8
	public int #=zaYMx8G8s7kyr()
	{
		return this.#=zH70$4dEukzuiH7TtrQ==;
	}

	// Token: 0x06001401 RID: 5121 RVA: 0x00099AE0 File Offset: 0x00097CE0
	public void #=zmFFxdB$L5hSh(int #=z$Ib9gYQ=)
	{
		this.#=zH70$4dEukzuiH7TtrQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001402 RID: 5122 RVA: 0x00099AEC File Offset: 0x00097CEC
	public Dictionary<int, List<int>> #=zYlSZ5YTp$oZ0OXZ$0w==()
	{
		return this.#=zoYD$VW9rYhYajG2_24Ub32OXSUgX;
	}

	// Token: 0x06001403 RID: 5123 RVA: 0x00099AF4 File Offset: 0x00097CF4
	public void #=zzbNE6frMgo5LwQ8H4g==(Dictionary<int, List<int>> #=z$Ib9gYQ=)
	{
		this.#=zoYD$VW9rYhYajG2_24Ub32OXSUgX = #=z$Ib9gYQ=;
	}

	// Token: 0x06001404 RID: 5124 RVA: 0x00099B00 File Offset: 0x00097D00
	public List<int> #=ziykhCXyTCZYpuxBoRw==()
	{
		return this.#=zda01D8vbPbecOoMFegiz6rGNw8XU;
	}

	// Token: 0x06001405 RID: 5125 RVA: 0x00099B08 File Offset: 0x00097D08
	public void #=z9GOrNaDcYqisg3UG0w==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zda01D8vbPbecOoMFegiz6rGNw8XU = #=z$Ib9gYQ=;
	}

	// Token: 0x06001406 RID: 5126 RVA: 0x00099B14 File Offset: 0x00097D14
	public Dictionary<int, List<int>> #=zJMXLuIzrpbV4vH1Qzg==()
	{
		return this.#=zTeBhhA_rorJBcxyc4s6wm90w3Bog;
	}

	// Token: 0x06001407 RID: 5127 RVA: 0x00099B1C File Offset: 0x00097D1C
	public void #=z1J_1k$DmBJQeE4kz6A==(Dictionary<int, List<int>> #=z$Ib9gYQ=)
	{
		this.#=zTeBhhA_rorJBcxyc4s6wm90w3Bog = #=z$Ib9gYQ=;
	}

	// Token: 0x06001408 RID: 5128 RVA: 0x00099B28 File Offset: 0x00097D28
	public int #=zHmi8epYYj6am2QJ7Ag==()
	{
		return this.#=zmNGiQYmkWwREvxfzoEWKYAA=;
	}

	// Token: 0x06001409 RID: 5129 RVA: 0x00099B30 File Offset: 0x00097D30
	public void #=zu2sJifER3$yvNnErNg==(int #=z$Ib9gYQ=)
	{
		this.#=zmNGiQYmkWwREvxfzoEWKYAA= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600140A RID: 5130 RVA: 0x00099B3C File Offset: 0x00097D3C
	public Dictionary<int, int> #=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS()
	{
		return this.#=z2DA8fG7x93xq72Clfun4jTLDk6Hnb1Q4Hw==;
	}

	// Token: 0x0600140B RID: 5131 RVA: 0x00099B44 File Offset: 0x00097D44
	public void #=zoMtpQ87JQEiofNpUnj02InjxO478(Dictionary<int, int> #=z$Ib9gYQ=)
	{
		this.#=z2DA8fG7x93xq72Clfun4jTLDk6Hnb1Q4Hw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600140C RID: 5132 RVA: 0x00099B50 File Offset: 0x00097D50
	public DateTime #=zxudUqyzmC$NkR2g1FQ==()
	{
		return this.#=zHLwPYtkSKjW9Ek9Q9_rhvQY=;
	}

	// Token: 0x0600140D RID: 5133 RVA: 0x00099B58 File Offset: 0x00097D58
	public void #=zO5_GFfDHwG2VodxMmQ==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zHLwPYtkSKjW9Ek9Q9_rhvQY= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000B77 RID: 2935
	private int #=zCxrfSyyH8ZJ1iKXpMHDrJcc=;

	// Token: 0x04000B78 RID: 2936
	private int #=z$u57NtYq2e$GpVGzGP1nvjE=;

	// Token: 0x04000B79 RID: 2937
	private #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns= #=zp8BbYYdlk2Kw3Orpeg==;

	// Token: 0x04000B7A RID: 2938
	private DateTime #=zTJHD1g0temVR$gAEg1aRIXqvFpw6;

	// Token: 0x04000B7B RID: 2939
	private int #=zUZdtSZOkN4x2WGyno4GGfpmZXWGa;

	// Token: 0x04000B7C RID: 2940
	private bool #=z4BW5W3f5Pd04F0JekMh8jW$XHJcUACuTRQ==;

	// Token: 0x04000B7D RID: 2941
	private int #=zH70$4dEukzuiH7TtrQ==;

	// Token: 0x04000B7E RID: 2942
	private Dictionary<int, List<int>> #=zoYD$VW9rYhYajG2_24Ub32OXSUgX;

	// Token: 0x04000B7F RID: 2943
	private List<int> #=zda01D8vbPbecOoMFegiz6rGNw8XU;

	// Token: 0x04000B80 RID: 2944
	private Dictionary<int, List<int>> #=zTeBhhA_rorJBcxyc4s6wm90w3Bog;

	// Token: 0x04000B81 RID: 2945
	private int #=zmNGiQYmkWwREvxfzoEWKYAA=;

	// Token: 0x04000B82 RID: 2946
	private Dictionary<int, int> #=z2DA8fG7x93xq72Clfun4jTLDk6Hnb1Q4Hw==;

	// Token: 0x04000B83 RID: 2947
	private DateTime #=zHLwPYtkSKjW9Ek9Q9_rhvQY=;

	// Token: 0x02000290 RID: 656
	public enum #=z7cLRqns=
	{

	}
}
