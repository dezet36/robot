﻿using System;
using Skink.SnR.Common.Global;

// Token: 0x020001E9 RID: 489
internal sealed class #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==
{
	// Token: 0x06000EC2 RID: 3778 RVA: 0x00076390 File Offset: 0x00074590
	public #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==(#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zdkyd448=, ProxyInfo #=zsHG$Y6w=)
	{
		this.#=zTJ6ssLE=(#=zdkyd448=);
		this.#=z6RMo7wxjyrsN(#=zsHG$Y6w=);
		this.#=zyafBTh$NKNpViEtypQ==(DateTime.Now);
		this.#=zyWBsBtq34zLJ(null);
		this.#=zIsnh6OIR1zyxlKkRHg==(null);
	}

	// Token: 0x06000EC3 RID: 3779 RVA: 0x000763C0 File Offset: 0x000745C0
	public #=zkO3OALYBGNilukMF5u7j7K3EsP5C #=z71I1m7Q=()
	{
		return this.#=zSyezPIWB$DEkBJmqoQ==;
	}

	// Token: 0x06000EC4 RID: 3780 RVA: 0x000763C8 File Offset: 0x000745C8
	public void #=zTJ6ssLE=(#=zkO3OALYBGNilukMF5u7j7K3EsP5C #=z$Ib9gYQ=)
	{
		this.#=zSyezPIWB$DEkBJmqoQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EC5 RID: 3781 RVA: 0x000763D4 File Offset: 0x000745D4
	public ProxyInfo #=z9TrQaE7EBV1U()
	{
		return this.#=zdu3Q9I4CAurSGQhlHw==;
	}

	// Token: 0x06000EC6 RID: 3782 RVA: 0x000763DC File Offset: 0x000745DC
	public void #=z6RMo7wxjyrsN(ProxyInfo #=z$Ib9gYQ=)
	{
		this.#=zdu3Q9I4CAurSGQhlHw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EC7 RID: 3783 RVA: 0x000763E8 File Offset: 0x000745E8
	public DateTime #=zd_9JG1jlYf$ucbtc$g==()
	{
		return this.#=zrGeZWRAATpYce9SBgHz3caw=;
	}

	// Token: 0x06000EC8 RID: 3784 RVA: 0x000763F0 File Offset: 0x000745F0
	public void #=zyafBTh$NKNpViEtypQ==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zrGeZWRAATpYce9SBgHz3caw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EC9 RID: 3785 RVA: 0x000763FC File Offset: 0x000745FC
	public #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zVv$Po1OfBUuq()
	{
		return this.#=zvw$Q5KRy5fKppq$GKlLBp8c=;
	}

	// Token: 0x06000ECA RID: 3786 RVA: 0x00076404 File Offset: 0x00074604
	public void #=zyWBsBtq34zLJ(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=z$Ib9gYQ=)
	{
		this.#=zvw$Q5KRy5fKppq$GKlLBp8c= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000ECB RID: 3787 RVA: 0x00076410 File Offset: 0x00074610
	public #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zaktMlI6Lx5IGn58ypg==()
	{
		return this.#=zg_KgUd7KdzTiN3h0fDgK6KeVeRHJ;
	}

	// Token: 0x06000ECC RID: 3788 RVA: 0x00076418 File Offset: 0x00074618
	public void #=zIsnh6OIR1zyxlKkRHg==(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=z$Ib9gYQ=)
	{
		this.#=zg_KgUd7KdzTiN3h0fDgK6KeVeRHJ = #=z$Ib9gYQ=;
	}

	// Token: 0x0400083B RID: 2107
	private #=zkO3OALYBGNilukMF5u7j7K3EsP5C #=zSyezPIWB$DEkBJmqoQ==;

	// Token: 0x0400083C RID: 2108
	private ProxyInfo #=zdu3Q9I4CAurSGQhlHw==;

	// Token: 0x0400083D RID: 2109
	private DateTime #=zrGeZWRAATpYce9SBgHz3caw=;

	// Token: 0x0400083E RID: 2110
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zvw$Q5KRy5fKppq$GKlLBp8c=;

	// Token: 0x0400083F RID: 2111
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zg_KgUd7KdzTiN3h0fDgK6KeVeRHJ;
}
