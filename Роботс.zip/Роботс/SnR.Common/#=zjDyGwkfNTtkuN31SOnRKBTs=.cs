﻿using System;
using System.Text;

// Token: 0x02000266 RID: 614
internal sealed class #=zjDyGwkfNTtkuN31SOnRKBTs= : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600129C RID: 4764 RVA: 0x00091910 File Offset: 0x0008FB10
	public #=zjDyGwkfNTtkuN31SOnRKBTs=()
	{
	}

	// Token: 0x0600129D RID: 4765 RVA: 0x00091918 File Offset: 0x0008FB18
	public #=zjDyGwkfNTtkuN31SOnRKBTs=(string #=zWj7xLq8=)
	{
		this.#=zziO1gvU= = bool.Parse(#=zWj7xLq8=);
	}

	// Token: 0x0600129E RID: 4766 RVA: 0x0009192C File Offset: 0x0008FB2C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		return new sbyte[]
		{
			#=zwUe4tm5XLL76xe$ToMjBTwE=.#=zr7sVnrM=.#=zd$BbM3Y=(),
			(this.#=zziO1gvU= > false) ? 1 : 0
		};
	}

	// Token: 0x0600129F RID: 4767 RVA: 0x00091950 File Offset: 0x0008FB50
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zziO1gvU= = (#=zJ5GWysk=[#=z4J_G3VM=] == 1);
		return 1;
	}

	// Token: 0x060012A0 RID: 4768 RVA: 0x00091960 File Offset: 0x0008FB60
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zXvwCnz8=.Append(this.#=zziO1gvU=.ToString());
	}

	// Token: 0x04000ABA RID: 2746
	private bool #=zziO1gvU=;
}
