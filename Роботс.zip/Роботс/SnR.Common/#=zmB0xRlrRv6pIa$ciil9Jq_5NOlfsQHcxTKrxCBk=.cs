﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000286 RID: 646
internal sealed class #=zmB0xRlrRv6pIa$ciil9Jq_5NOlfsQHcxTKrxCBk= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600139C RID: 5020 RVA: 0x000970F0 File Offset: 0x000952F0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zy0tqKwE= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zatMRdFUxBCRS1oul8g== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJgBKL1dWlurwuFRt1A== = #=zuJjQ1XU=.#=z6IODMVzrU6HMa5LZg021HYs=();
	}

	// Token: 0x0600139D RID: 5021 RVA: 0x00097118 File Offset: 0x00095318
	protected override void #=zvb5bnug=()
	{
		List<#=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==> list = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.#=zn6YQInpyaKHd();
		ResourceTypes resourceTypes = ResourceTypes.Unknown;
		ResourceTypes resourceTypes2 = ResourceTypes.Unknown;
		double num = 1.0;
		int num2 = ((this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.SpecifiedCaravanVolume > 0) ? this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.SpecifiedCaravanVolume : this.#=zJgBKL1dWlurwuFRt1A==.#=zunVWVnmqJuqR()) * 2;
		int num3 = 0;
		for (int i = 0; i < list.Count; i++)
		{
			#=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ== #=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ== = list[i];
			int num4 = this.#=zy0tqKwE=[#=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==.#=ziXIUsXqcVZz_()] - this.#=zy0tqKwE=[#=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==.#=zfpJ8QMEsD58B()];
			if (num4 > num2 && num4 > num3)
			{
				resourceTypes = #=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==.#=zfpJ8QMEsD58B();
				resourceTypes2 = #=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==.#=ziXIUsXqcVZz_();
				num = #=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==.#=zisvlKsvs85jd();
				num3 = num4;
			}
		}
		if (resourceTypes == ResourceTypes.Unknown || resourceTypes2 == ResourceTypes.Unknown)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982153), Array.Empty<object>());
			return;
		}
		int j = this.#=zJgBKL1dWlurwuFRt1A==.#=z1$GKSNmtfrzR();
		if (num < 0.5 || num > 2.0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981860), new object[]
			{
				num
			});
			return;
		}
		if (j == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981778), Array.Empty<object>());
			return;
		}
		int num5;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.SpecifiedCaravanVolume > 0)
		{
			num5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.SpecifiedCaravanVolume / this.#=zJgBKL1dWlurwuFRt1A==.#=z2UCBrfce7z8r();
		}
		else
		{
			num5 = this.#=zJgBKL1dWlurwuFRt1A==.#=zGJTylv6IVXpT();
		}
		int num6 = j * num5;
		#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(resourceTypes2, num6);
		#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2 = new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(resourceTypes, (int)((double)num6 * num));
		foreach (Dictionary<string, object> dictionary in (object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=zoQ7ksjO8UdfACoZRDQ==(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zq2bPTdY=(), #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=(), 0, num6 * 2, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.OfferPriority)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)])
		{
			int @int = JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981987) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=z69SHZCTwoPe0(), 0);
			int int2 = JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981982) + #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z69SHZCTwoPe0(), 0);
			if ((double)@int / (double)int2 >= num && int2 <= num6)
			{
				string text = this.#=zBsXSanI=.#=ze1SOcCGAlsijvaxxkw==(dictionary);
				text = text.Trim(new char[1]);
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981973), new object[]
					{
						int2,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
						@int,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji()
					});
					int num7 = int2 / num5;
					if (num7 * num5 < int2)
					{
						num7++;
					}
					j -= num7;
					num6 -= num7 * num5;
					if (j > 0)
					{
						goto IL_427;
					}
				}
				else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981905)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981612), new object[]
					{
						int2,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
						@int,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji()
					});
				}
				else
				{
					if (text.Length > 1000)
					{
						text = text.Substring(0, 1000);
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981756), new object[]
					{
						int2,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
						@int,
						#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji(),
						text
					});
				}
				IL_61E:
				while (j > 0)
				{
					int num8;
					if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.MaxCreatedOfferAmount > 0)
					{
						num8 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ResExchangeRules.MaxCreatedOfferAmount;
					}
					else
					{
						num8 = 24000;
					}
					int num9 = (int)((double)(num8 / num5) / num);
					if (num9 == 0)
					{
						num9 = 1;
					}
					else if (num9 > j)
					{
						num9 = j;
					}
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(num9 * num5);
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zqoCq5j01dD5w((int)((double)(num9 * num5) * num));
					string text2 = this.#=zBsXSanI=.#=zJsknLhumcn07(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio, #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2);
					text2 = text2.Trim(new char[1]);
					if (text2.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981685), new object[]
						{
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji()
						});
						j -= num9;
						num6 -= num9 * num5;
					}
					else
					{
						if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981905)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981363), new object[]
							{
								#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_(),
								#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
								#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_(),
								#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji()
							});
							break;
						}
						if (text2.Length > 1000)
						{
							text2 = text2.Substring(0, 1000);
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981250), new object[]
						{
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_(),
							#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zyhMluFK2CBji(),
							text2
						});
						break;
					}
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981453), Array.Empty<object>());
				return;
			}
			IL_427:;
		}
		goto IL_61E;
	}

	// Token: 0x04000B53 RID: 2899
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zy0tqKwE=;

	// Token: 0x04000B54 RID: 2900
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==;

	// Token: 0x04000B55 RID: 2901
	private #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=zJgBKL1dWlurwuFRt1A==;
}
