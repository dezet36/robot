﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading.Tasks;

// Token: 0x02000271 RID: 625
internal static class #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=
{
	// Token: 0x060012EA RID: 4842 RVA: 0x0009295C File Offset: 0x00090B5C
	public static void #=z1jlGMrg=()
	{
		if (#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=z8tkBApM=)
		{
			return;
		}
		object obj = #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zRbZQdnqJYfRk;
		lock (obj)
		{
			if (!#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=z8tkBApM=)
			{
				#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zNXMxMQpDRktk();
				#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=z8tkBApM= = true;
			}
		}
	}

	// Token: 0x060012EB RID: 4843 RVA: 0x000929B4 File Offset: 0x00090BB4
	private static void #=zNXMxMQpDRktk()
	{
		#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zdlM_YR0=((Assembly.GetEntryAssembly() ?? Assembly.GetExecutingAssembly()).Location).Wait();
	}

	// Token: 0x060012EC RID: 4844 RVA: 0x000929D4 File Offset: 0x00090BD4
	private static string #=zJ0NQenGvgemM()
	{
		return Path.Combine(AppContext.BaseDirectory, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928296));
	}

	// Token: 0x060012ED RID: 4845 RVA: 0x000929EC File Offset: 0x00090BEC
	private static byte[] #=zgbMSfrPRNAEn()
	{
		string text = #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zJ0NQenGvgemM();
		if (!File.Exists(text))
		{
			#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928285));
		}
		return #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zURcpHdwV4uZD(text);
	}

	// Token: 0x060012EE RID: 4846 RVA: 0x00092A10 File Offset: 0x00090C10
	private static Task #=zdlM_YR0=(string #=zPkHZxKs=)
	{
		#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zGw6epy4akzwYuThffw== #=zGw6epy4akzwYuThffw==;
		#=zGw6epy4akzwYuThffw==.#=zeo9zh$k5CAim = AsyncTaskMethodBuilder.Create();
		#=zGw6epy4akzwYuThffw==.#=zPkHZxKs= = #=zPkHZxKs=;
		#=zGw6epy4akzwYuThffw==.#=zPufY3WHa_xCZ = -1;
		#=zGw6epy4akzwYuThffw==.#=zeo9zh$k5CAim.Start<#=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zGw6epy4akzwYuThffw==>(ref #=zGw6epy4akzwYuThffw==);
		return #=zGw6epy4akzwYuThffw==.#=zeo9zh$k5CAim.Task;
	}

	// Token: 0x060012EF RID: 4847 RVA: 0x00092A54 File Offset: 0x00090C54
	private static byte[] #=zURcpHdwV4uZD(string #=z0ONi4Bk=)
	{
		byte[] result;
		using (SHA256 sha = SHA256.Create())
		{
			using (FileStream fileStream = File.OpenRead(#=z0ONi4Bk=))
			{
				result = sha.ComputeHash(fileStream);
			}
		}
		return result;
	}

	// Token: 0x04000ADD RID: 2781
	private static bool #=z8tkBApM= = false;

	// Token: 0x04000ADE RID: 2782
	private static readonly object #=zRbZQdnqJYfRk = new object();

	// Token: 0x02000272 RID: 626
	[StructLayout(LayoutKind.Auto)]
	private struct #=zGw6epy4akzwYuThffw== : IAsyncStateMachine
	{
		// Token: 0x060012F0 RID: 4848 RVA: 0x00092AAC File Offset: 0x00090CAC
		void IAsyncStateMachine.MoveNext()
		{
			try
			{
				byte[] #=zt5PLcjEKUG_I = #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zURcpHdwV4uZD(this.#=zPkHZxKs=);
				byte[] #=zPZohVRG2lpLa = #=zkCArBGGwZRV3g8L$alM2Yw3qsO6CYj6BOAtjsd0=.#=zgbMSfrPRNAEn();
				if (!#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zjRJeiqafBpN5(#=zt5PLcjEKUG_I, #=zPZohVRG2lpLa))
				{
					#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928356));
				}
			}
			catch (Exception exception)
			{
				this.#=zPufY3WHa_xCZ = -2;
				this.#=zeo9zh$k5CAim.SetException(exception);
				return;
			}
			this.#=zPufY3WHa_xCZ = -2;
			this.#=zeo9zh$k5CAim.SetResult();
		}

		// Token: 0x060012F1 RID: 4849 RVA: 0x00092B20 File Offset: 0x00090D20
		[DebuggerHidden]
		void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine #=znmZn6fc=)
		{
			this.#=zeo9zh$k5CAim.SetStateMachine(#=znmZn6fc=);
		}

		// Token: 0x04000ADF RID: 2783
		public int #=zPufY3WHa_xCZ;

		// Token: 0x04000AE0 RID: 2784
		public AsyncTaskMethodBuilder #=zeo9zh$k5CAim;

		// Token: 0x04000AE1 RID: 2785
		public string #=zPkHZxKs=;
	}
}
