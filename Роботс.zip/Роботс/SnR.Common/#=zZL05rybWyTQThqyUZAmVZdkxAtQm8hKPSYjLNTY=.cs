﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Tasks;

// Token: 0x020001EF RID: 495
internal sealed partial class #=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY= : Form
{
	// Token: 0x06000EFE RID: 3838 RVA: 0x00076A90 File Offset: 0x00074C90
	public #=zZL05rybWyTQThqyUZAmVZdkxAtQm8hKPSYjLNTY=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zxro48GWsse8U = -1)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zXqKwUc4= = #=z8StzeqE=;
		this.#=zgpzgXirqPT5_();
		if (#=z8StzeqE= != null && #=z8StzeqE=.#=zjV_wsuvJ0R_B() != null)
		{
			this.#=z6xzTzpg=.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113420), new object[]
			{
				#=z8StzeqE=.#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(),
				#=z8StzeqE=.#=zh5Q$jgycqA15().#=zjWBl268nvo9O(),
				#=z8StzeqE=.#=zVTXNaO2wZJzQ(),
				#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(),
				#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==()
			});
		}
		if (#=zxro48GWsse8U >= 0)
		{
			this.#=zm6Ucn95_3oR4.SelectedIndex = #=zxro48GWsse8U;
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06000EFF RID: 3839 RVA: 0x00076B44 File Offset: 0x00074D44
	private void #=zs2xhEfw=(bool #=zJMyw7PI=)
	{
		int itemTypeId;
		switch (this.#=zm6Ucn95_3oR4.SelectedIndex)
		{
		case 0:
			itemTypeId = 17002;
			break;
		case 1:
			itemTypeId = 17001;
			break;
		case 2:
			itemTypeId = 17000;
			break;
		default:
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105214));
			return;
		}
		int amount;
		if (!int.TryParse(this.#=zZPpl2Wvkev4_pKpAYpNvK8k=.Text, out amount))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105175));
			return;
		}
		bool isBuyAndUse;
		bool isDontUsePartially;
		switch (this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.SelectedIndex)
		{
		case 0:
			isBuyAndUse = false;
			isDontUsePartially = false;
			break;
		case 1:
			isBuyAndUse = true;
			isDontUsePartially = false;
			break;
		case 2:
			isBuyAndUse = false;
			isDontUsePartially = true;
			break;
		default:
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105372));
			return;
		}
		TaskBlackMarketParams #=zHbX7HNM= = new TaskBlackMarketParams(itemTypeId, false, amount, 0.0, isBuyAndUse, true, isDontUsePartially);
		TaskSeverities #=z_qaYpFQ= = this.#=zi6JJp6JxTSok2adKCgJRe6s=.Checked ? TaskSeverities.UrgentNoRelogin : TaskSeverities.Background;
		if (!#=zJMyw7PI=)
		{
			Task #=zcTyyNys= = new #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(#=zHbX7HNM=, TaskSources.Manual, #=z_qaYpFQ=, TaskTypes.UseBlackMarketItem, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
			this.#=zXqKwUc4=.#=zeR3QFrc=(#=zcTyyNys=);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(this.#=zXqKwUc4=);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105310));
			base.Close();
			return;
		}
		#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== = new #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==(this.#=zshVEGQI=, this.#=zXqKwUc4=);
		try
		{
			if (#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.ShowDialog() == DialogResult.OK && #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==().Count > 0)
			{
				List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
				foreach (int index in #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==())
				{
					list.Add(this.#=zshVEGQI=.#=zol80P7TKoihZ()[index]);
				}
				foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in list)
				{
					Task #=zcTyyNys=2 = new #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(#=zHbX7HNM=, TaskSources.Manual, #=z_qaYpFQ=, TaskTypes.UseBlackMarketItem, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(#=zcTyyNys=2);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
				}
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105310));
				base.Close();
			}
		}
		finally
		{
			((IDisposable)#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==).Dispose();
		}
	}

	// Token: 0x06000F00 RID: 3840 RVA: 0x00076DB4 File Offset: 0x00074FB4
	private void #=zYtnfTR76rfXH(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zs2xhEfw=(false);
	}

	// Token: 0x06000F01 RID: 3841 RVA: 0x00076DC0 File Offset: 0x00074FC0
	private void #=zDLIpdNjG2crsj6qQQOjJVq8=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zs2xhEfw=(true);
	}

	// Token: 0x06000F02 RID: 3842 RVA: 0x00076DCC File Offset: 0x00074FCC
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x06000F04 RID: 3844 RVA: 0x00076DF4 File Offset: 0x00074FF4
	private void #=zgpzgXirqPT5_()
	{
		this.#=z8gpxqPJnq$E7 = new Label();
		this.#=zzEe1KZP3ZglDdMyyhimV8kM= = new Label();
		this.#=zsuIJszCiQhrQTcHwuA== = new Label();
		this.#=zZPpl2Wvkev4_pKpAYpNvK8k= = new TextBox();
		this.#=zgcqPI86kSGTVDruyOw== = new Label();
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8= = new ComboBox();
		this.#=zB6rlaNY= = new Button();
		this.#=zREX2B3IYLpHQIChYAA== = new Button();
		this.#=zm6Ucn95_3oR4 = new ComboBox();
		this.#=zHeAVXAs= = new Button();
		this.#=zi6JJp6JxTSok2adKCgJRe6s= = new CheckBox();
		this.#=z6xzTzpg= = new Label();
		base.SuspendLayout();
		this.#=z8gpxqPJnq$E7.AutoSize = true;
		this.#=z8gpxqPJnq$E7.Location = new Point(12, 66);
		this.#=z8gpxqPJnq$E7.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107048);
		this.#=z8gpxqPJnq$E7.Size = new Size(40, 13);
		this.#=z8gpxqPJnq$E7.TabIndex = 0;
		this.#=z8gpxqPJnq$E7.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107026);
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.AutoSize = true;
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.Location = new Point(12, 119);
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107020);
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.Size = new Size(79, 13);
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.TabIndex = 1;
		this.#=zzEe1KZP3ZglDdMyyhimV8kM=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106996);
		this.#=zsuIJszCiQhrQTcHwuA==.AutoSize = true;
		this.#=zsuIJszCiQhrQTcHwuA==.Location = new Point(12, 93);
		this.#=zsuIJszCiQhrQTcHwuA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106975);
		this.#=zsuIJszCiQhrQTcHwuA==.Size = new Size(53, 13);
		this.#=zsuIJszCiQhrQTcHwuA==.TabIndex = 2;
		this.#=zsuIJszCiQhrQTcHwuA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114688);
		this.#=zZPpl2Wvkev4_pKpAYpNvK8k=.Location = new Point(143, 90);
		this.#=zZPpl2Wvkev4_pKpAYpNvK8k=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106948);
		this.#=zZPpl2Wvkev4_pKpAYpNvK8k=.Size = new Size(121, 20);
		this.#=zZPpl2Wvkev4_pKpAYpNvK8k=.TabIndex = 3;
		this.#=zgcqPI86kSGTVDruyOw==.AutoSize = true;
		this.#=zgcqPI86kSGTVDruyOw==.Location = new Point(12, 31);
		this.#=zgcqPI86kSGTVDruyOw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107171);
		this.#=zgcqPI86kSGTVDruyOw==.Size = new Size(172, 13);
		this.#=zgcqPI86kSGTVDruyOw==.TabIndex = 6;
		this.#=zgcqPI86kSGTVDruyOw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107157);
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.FormattingEnabled = true;
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107116),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107086),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106806)
		});
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.Location = new Point(143, 116);
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106781);
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.Size = new Size(228, 21);
		this.#=z$Z0iJjr0_OVNflHp3gzZqY8=.TabIndex = 7;
		this.#=zB6rlaNY=.Location = new Point(15, 183);
		this.#=zB6rlaNY=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111166);
		this.#=zB6rlaNY=.Size = new Size(194, 23);
		this.#=zB6rlaNY=.TabIndex = 8;
		this.#=zB6rlaNY=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106744);
		this.#=zB6rlaNY=.UseVisualStyleBackColor = true;
		this.#=zB6rlaNY=.Click += this.#=zYtnfTR76rfXH;
		this.#=zREX2B3IYLpHQIChYAA==.Location = new Point(231, 183);
		this.#=zREX2B3IYLpHQIChYAA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106724);
		this.#=zREX2B3IYLpHQIChYAA==.Size = new Size(194, 23);
		this.#=zREX2B3IYLpHQIChYAA==.TabIndex = 8;
		this.#=zREX2B3IYLpHQIChYAA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106702);
		this.#=zREX2B3IYLpHQIChYAA==.UseVisualStyleBackColor = true;
		this.#=zREX2B3IYLpHQIChYAA==.Click += this.#=zDLIpdNjG2crsj6qQQOjJVq8=;
		this.#=zm6Ucn95_3oR4.DropDownStyle = ComboBoxStyle.DropDownList;
		this.#=zm6Ucn95_3oR4.FormattingEnabled = true;
		this.#=zm6Ucn95_3oR4.Items.AddRange(new object[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106923),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106916),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106897)
		});
		this.#=zm6Ucn95_3oR4.Location = new Point(143, 63);
		this.#=zm6Ucn95_3oR4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106883);
		this.#=zm6Ucn95_3oR4.Size = new Size(121, 21);
		this.#=zm6Ucn95_3oR4.TabIndex = 9;
		this.#=zHeAVXAs=.Location = new Point(350, 212);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 10;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.AutoSize = true;
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.Location = new Point(143, 143);
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106856);
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.Size = new Size(100, 17);
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.TabIndex = 11;
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106839);
		this.#=zi6JJp6JxTSok2adKCgJRe6s=.UseVisualStyleBackColor = true;
		this.#=z6xzTzpg=.AutoSize = true;
		this.#=z6xzTzpg=.Location = new Point(12, 9);
		this.#=z6xzTzpg=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114971);
		this.#=z6xzTzpg=.Size = new Size(16, 13);
		this.#=z6xzTzpg=.TabIndex = 23;
		this.#=z6xzTzpg=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114954);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(445, 260);
		base.Controls.Add(this.#=z6xzTzpg=);
		base.Controls.Add(this.#=zi6JJp6JxTSok2adKCgJRe6s=);
		base.Controls.Add(this.#=zHeAVXAs=);
		base.Controls.Add(this.#=zm6Ucn95_3oR4);
		base.Controls.Add(this.#=zREX2B3IYLpHQIChYAA==);
		base.Controls.Add(this.#=zB6rlaNY=);
		base.Controls.Add(this.#=z$Z0iJjr0_OVNflHp3gzZqY8=);
		base.Controls.Add(this.#=zgcqPI86kSGTVDruyOw==);
		base.Controls.Add(this.#=zZPpl2Wvkev4_pKpAYpNvK8k=);
		base.Controls.Add(this.#=zsuIJszCiQhrQTcHwuA==);
		base.Controls.Add(this.#=zzEe1KZP3ZglDdMyyhimV8kM=);
		base.Controls.Add(this.#=z8gpxqPJnq$E7);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106556);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106556);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400085A RID: 2138
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x0400085B RID: 2139
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zXqKwUc4=;

	// Token: 0x0400085D RID: 2141
	private Label #=z8gpxqPJnq$E7;

	// Token: 0x0400085E RID: 2142
	private Label #=zzEe1KZP3ZglDdMyyhimV8kM=;

	// Token: 0x0400085F RID: 2143
	private Label #=zsuIJszCiQhrQTcHwuA==;

	// Token: 0x04000860 RID: 2144
	private TextBox #=zZPpl2Wvkev4_pKpAYpNvK8k=;

	// Token: 0x04000861 RID: 2145
	private Label #=zgcqPI86kSGTVDruyOw==;

	// Token: 0x04000862 RID: 2146
	private ComboBox #=z$Z0iJjr0_OVNflHp3gzZqY8=;

	// Token: 0x04000863 RID: 2147
	private Button #=zB6rlaNY=;

	// Token: 0x04000864 RID: 2148
	private Button #=zREX2B3IYLpHQIChYAA==;

	// Token: 0x04000865 RID: 2149
	private ComboBox #=zm6Ucn95_3oR4;

	// Token: 0x04000866 RID: 2150
	private Button #=zHeAVXAs=;

	// Token: 0x04000867 RID: 2151
	private CheckBox #=zi6JJp6JxTSok2adKCgJRe6s=;

	// Token: 0x04000868 RID: 2152
	private Label #=z6xzTzpg=;
}
