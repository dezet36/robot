﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200006B RID: 107
internal sealed class #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=
{
	// Token: 0x06000314 RID: 788 RVA: 0x0001D4E4 File Offset: 0x0001B6E4
	public #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=(Dictionary<string, object> #=ztB1vrx7gnJdS1z8w$g==)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=ztB1vrx7gnJdS1z8w$g==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=z4Ttv8PHQXEZHb$2AtXrKvug=(new List<int>());
		object[] array = JSONManager.GetArray(#=ztB1vrx7gnJdS1z8w$g==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070401));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (!dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076598)))
				{
					int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0);
					object[] array2 = JSONManager.ExtractArray(#=ztB1vrx7gnJdS1z8w$g==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684));
					if (array2 != null)
					{
						int j = 0;
						while (j < array2.Length)
						{
							Dictionary<string, object> dictionary2 = (Dictionary<string, object>)array2[j];
							if (JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0) == num)
							{
								if (JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0) == 0)
								{
									this.#=zcdH4JVnr8AGe4boeg9Ke5Kw=().Add(num);
									break;
								}
								break;
							}
							else
							{
								j++;
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06000315 RID: 789 RVA: 0x0001D5DC File Offset: 0x0001B7DC
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000316 RID: 790 RVA: 0x0001D5E4 File Offset: 0x0001B7E4
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000317 RID: 791 RVA: 0x0001D5F0 File Offset: 0x0001B7F0
	public List<int> #=zcdH4JVnr8AGe4boeg9Ke5Kw=()
	{
		return this.#=z5XKsneO7raLP1rrV6b90MIyB37AEnweWyQ==;
	}

	// Token: 0x06000318 RID: 792 RVA: 0x0001D5F8 File Offset: 0x0001B7F8
	public void #=z4Ttv8PHQXEZHb$2AtXrKvug=(List<int> #=z$Ib9gYQ=)
	{
		this.#=z5XKsneO7raLP1rrV6b90MIyB37AEnweWyQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400011A RID: 282
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400011B RID: 283
	private List<int> #=z5XKsneO7raLP1rrV6b90MIyB37AEnweWyQ==;
}
