﻿using System;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x0200027C RID: 636
internal sealed class #=zlGgEEPoDqx7kgJsLy02l6i8stYZaMfTybmbscclFkFipwOJyQHZZT5526B9gB$pdew== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001333 RID: 4915 RVA: 0x00095AD0 File Offset: 0x00093CD0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06001334 RID: 4916 RVA: 0x00095AD4 File Offset: 0x00093CD4
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		UnitType unitType = UnitTypeCollection.Get().FindOrCreate(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().ItemTypeId);
		if (unitType.Id == GameApplicationData.#=zI_k8Duvk2CSYLouVdQ==())
		{
			unitType.Name = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924037));
		}
		string text = this.#=zBsXSanI=.#=zOM7cVZUPI8JhJvA$Ag==(unitType.Id, #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount);
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923954), new object[]
			{
				unitType.Name,
				#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount
			});
			return;
		}
		text = JSONManager.Cut(text);
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924146), new object[]
		{
			unitType.Name,
			#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount,
			text
		});
	}
}
