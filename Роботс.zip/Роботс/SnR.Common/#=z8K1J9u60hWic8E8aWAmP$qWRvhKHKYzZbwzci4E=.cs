﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020000A4 RID: 164
internal sealed class #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=
{
	// Token: 0x06000452 RID: 1106 RVA: 0x00024D0C File Offset: 0x00022F0C
	public #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zVNqezYTad3Gx, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z8StzeqE= = #=zVNqezYTad3Gx;
		this.#=zBsXSanI= = #=zuJjQ1XU=.#=z$2ijYGRf0FB5();
		this.#=zJuQW8gI= = #=zuJjQ1XU=.#=zZan5aKOWyPR5();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
	}

	// Token: 0x06000453 RID: 1107 RVA: 0x00024D40 File Offset: 0x00022F40
	public int #=z1$O687c1sZryMVkkgbGT0jU=(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==, int[] #=z1s4JRMC5r_O8, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD, bool #=zujsC92hIKHrW)
	{
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>();
		for (int i = 0; i < #=zatMRdFUxBCRS1oul8g==.Count; i++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zatMRdFUxBCRS1oul8g==[i];
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z5kpAZQpjT2b7())
			{
				list.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
			}
		}
		#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji speedUpBuildingsWithBoostersMode = (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpBuildingsWithBoostersMode;
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>();
		foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 in list)
		{
			if (speedUpBuildingsWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)1)
			{
				list2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn2);
			}
			else if (speedUpBuildingsWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)2 || speedUpBuildingsWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)3)
			{
				bool flag = false;
				foreach (BuildingPlanFrame buildingPlanFrame in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingPlan)
				{
					if (buildingPlanFrame.IsTimeBoost && buildingPlanFrame.Types.Contains(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFMDiymuLQ7_4()) && buildingPlanFrame.Level > #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zvnZc$RhG_1Du())
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					list2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn2);
				}
			}
		}
		if (list2.Count == 0 && speedUpBuildingsWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)3)
		{
			bool flag2 = false;
			bool flag3 = false;
			foreach (BuildingPlanFrame buildingPlanFrame2 in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingPlan)
			{
				HashSet<int> hashSet = new HashSet<int>(buildingPlanFrame2.Types);
				foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn3 in #=zatMRdFUxBCRS1oul8g==)
				{
					if (buildingPlanFrame2.IsTimeBoost && hashSet.Contains(#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4()) && buildingPlanFrame2.Level > #=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zvnZc$RhG_1Du())
					{
						if (#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zq2bPTdY=().World == Worlds.Default)
						{
							flag3 = true;
						}
						else if (#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zq2bPTdY=().World == Worlds.Elisium)
						{
							flag2 = true;
						}
					}
					if (flag2 && flag3)
					{
						break;
					}
					hashSet.Remove(#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4());
				}
				if (flag2 && flag3)
				{
					break;
				}
				if (hashSet.Count > 0)
				{
					#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
					foreach (int #=zAk8mKBk= in hashSet)
					{
						#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zAk8mKBk=);
						if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF != null && #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF, 1, this.#=z8StzeqE=, #=zatMRdFUxBCRS1oul8g==, #=zMEwuTGAUgTDD, #=zujsC92hIKHrW))
						{
							if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.World == Worlds.Default)
							{
								flag3 = true;
							}
							else if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.World == Worlds.Elisium)
							{
								flag2 = true;
							}
						}
					}
				}
			}
			if ((flag3 && #=z1s4JRMC5r_O8[0] == 0) || (flag2 && #=z1s4JRMC5r_O8[1] == 0))
			{
				DateTime t = DateTime.MaxValue;
				#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn4 = null;
				foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn5 in list)
				{
					if (flag3)
					{
						if (#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zq2bPTdY=().World == Worlds.Default && #=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zGhmoNZChgwf8() < t)
						{
							#=zO6457TajDDxDJIsKqS1bbzDMLckn4 = #=zO6457TajDDxDJIsKqS1bbzDMLckn5;
							t = #=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zGhmoNZChgwf8();
						}
					}
					else if (flag2 && #=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zq2bPTdY=().World == Worlds.Elisium && #=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zGhmoNZChgwf8() < t)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn4 = #=zO6457TajDDxDJIsKqS1bbzDMLckn5;
						t = #=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zGhmoNZChgwf8();
					}
				}
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn4 != null)
				{
					list2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn4);
				}
			}
		}
		int num = int.MaxValue;
		foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zdRsbMv2cNodA in list2)
		{
			int num2 = this.#=z_94OZiQ=(#=zdRsbMv2cNodA);
			if (num > num2)
			{
				num = num2;
			}
		}
		return num;
	}

	// Token: 0x06000454 RID: 1108 RVA: 0x00025188 File Offset: 0x00023388
	public int #=zbz5V76FSfPgyn3Ty$g==(#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD)
	{
		List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==> list = new List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>();
		for (int i = 0; i < #=zMEwuTGAUgTDD.Count; i++)
		{
			#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zMEwuTGAUgTDD[i];
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7())
			{
				list.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==);
			}
		}
		#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji speedUpResearchWithBoostersMode = (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode;
		List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==> list2 = new List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>();
		foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 in list)
		{
			if (speedUpResearchWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)1)
			{
				list2.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2);
			}
			else if ((speedUpResearchWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)2 || speedUpResearchWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)3) && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Get(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zMuFMjGQ=()).IsTimeBoost)
			{
				list2.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2);
			}
		}
		if (list2.Count == 0 && speedUpResearchWithBoostersMode == (#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zY5xZfq1_bxji)3)
		{
			List<#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=> list3 = new List<#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs=>();
			foreach (TechPlanFrame techPlanFrame in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan)
			{
				if (techPlanFrame.IsTimeBoost)
				{
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3 = #=zMEwuTGAUgTDD.#=zk$6QZNA=(techPlanFrame.TypeId);
					if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3 != null)
					{
						int num;
						if (techPlanFrame.UpgradeLevel > 0)
						{
							if (techPlanFrame.UpgradeLevel <= #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zq2bPTdY=().#=zaDKBEnk8Vsod())
							{
								num = techPlanFrame.UpgradeLevel;
							}
							else
							{
								num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zq2bPTdY=().#=zaDKBEnk8Vsod();
							}
						}
						else if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeTechsForSchemas)
						{
							num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zq2bPTdY=().#=zaDKBEnk8Vsod();
						}
						else
						{
							num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zq2bPTdY=().#=zDpaLxYOl35uZaIePmg==();
						}
						if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zvnZc$RhG_1Du() < num)
						{
							#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs= item = #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zhlj9a4JUzMiQ(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==3.#=zq2bPTdY=());
							if (!list3.Contains(item))
							{
								list3.Add(item);
							}
						}
					}
				}
			}
			if (list3.Count > 0)
			{
				foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==4 in list)
				{
					#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zArez$Gs= item2 = #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==.#=zhlj9a4JUzMiQ(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==4.#=zq2bPTdY=());
					if (list3.Contains(item2))
					{
						list2.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==4);
						list3.Remove(item2);
						if (list3.Count == 0)
						{
							break;
						}
					}
				}
			}
		}
		int num2 = int.MaxValue;
		foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zdRsbMv2cNodA in list2)
		{
			int num3 = this.#=z_94OZiQ=(#=zdRsbMv2cNodA);
			if (num2 > num3)
			{
				num2 = num3;
			}
		}
		return num2;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x00025440 File Offset: 0x00023640
	private int #=z_94OZiQ=(#=zLG6uk$Gz0HYsu5astWupkBlXmaty4YJdWIIUAcw= #=zdRsbMv2cNodA)
	{
		if (Math.Abs((this.#=zJuQW8gI= - DateTime.Now).TotalDays) > 1.0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964504), new object[]
			{
				this.#=zJuQW8gI=
			});
			return int.MaxValue;
		}
		TimeSpan timeSpan = #=zdRsbMv2cNodA.#=zGhmoNZChgwf8() - this.#=zJuQW8gI=;
		int num = (int)timeSpan.TotalSeconds;
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964183), new object[]
		{
			#=zdRsbMv2cNodA.#=zkfqcY3I=(),
			#=zdRsbMv2cNodA.#=zvnZc$RhG_1Du() + 1,
			timeSpan
		});
		if (num < 300)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964625), Array.Empty<object>());
			return num;
		}
		List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> list = new List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>();
		foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= in this.#=zCY4az9$WUjLsEJ7fgg==.Values)
		{
			if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)300 && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z$NyihN71ouQU() == (#=zdRsbMv2cNodA.#=zo4pctbtCxQ0d().World == Worlds.Elisium || #=zdRsbMv2cNodA.#=zo4pctbtCxQ0d().World == Worlds.Veor) && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zjw43QGFcPyHH() < (double)num)
			{
				list.Add(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=);
			}
		}
		list.Sort(new Comparison<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>(#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zyDNvciU=.#=zLkw0NRU=.#=zkGZDVD5eya4mLAS7oQ==));
		for (int i = 0; i < list.Count; i++)
		{
			#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = list[i];
			int num2 = num / (int)#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH();
			if (num2 > #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_())
			{
				num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
			}
			if (num2 > 0)
			{
				string text;
				if (#=zdRsbMv2cNodA is #=zO6457TajDDxDJIsKqS1bbzDMLckn)
				{
					text = this.#=zBsXSanI=.#=zkPJPpU_KgKJ3P1gzKw==(#=zdRsbMv2cNodA as #=zO6457TajDDxDJIsKqS1bbzDMLckn, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=(), num2);
				}
				else
				{
					if (!(#=zdRsbMv2cNodA is #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964105), new object[]
						{
							#=zdRsbMv2cNodA.GetType().FullName
						});
						return int.MaxValue;
					}
					text = this.#=zBsXSanI=.#=zoObeVpn9gW2BopkuHw==(#=zdRsbMv2cNodA as #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=(), num2);
				}
				if (text.Length <= 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964263), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zkfqcY3I=(),
						num2,
						#=zdRsbMv2cNodA.#=zkfqcY3I=(),
						#=zdRsbMv2cNodA.#=zvnZc$RhG_1Du() + 1,
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964313), new object[]
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zkfqcY3I=(),
					num2,
					#=zdRsbMv2cNodA.#=zkfqcY3I=(),
					#=zdRsbMv2cNodA.#=zvnZc$RhG_1Du() + 1
				});
				num -= (int)(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH() * (double)num2);
				if (num < 300)
				{
					break;
				}
			}
		}
		return num;
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x000257DC File Offset: 0x000239DC
	public int #=zooxTzWuNzmISknjjazw$BD4GOot5(List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zc1y0_hs=)
	{
		int num = int.MaxValue;
		for (int i = 0; i < #=zc1y0_hs=.Count; i++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = #=zc1y0_hs=[i];
			if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zdln9Op$NubUKpgj1nPP6ujU=())
			{
				int num2 = this.#=zsdLAp_lez_6r9TmIUuZIotA=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
				if (num > num2)
				{
					num = num2;
				}
			}
		}
		return num;
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x00025820 File Offset: 0x00023A20
	private int #=zsdLAp_lez_6r9TmIUuZIotA=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zdRsbMv2cNodA)
	{
		if (Math.Abs((this.#=zJuQW8gI= - DateTime.Now).TotalDays) > 1.0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964504), new object[]
			{
				this.#=zJuQW8gI=
			});
			return int.MaxValue;
		}
		TimeSpan timeSpan = #=zdRsbMv2cNodA.#=zgrEVFKh5HEEpwob8vA==() - this.#=zJuQW8gI=;
		int num = (int)timeSpan.TotalSeconds;
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963932), new object[]
		{
			#=zdRsbMv2cNodA,
			timeSpan
		});
		if (num < 300)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964625), Array.Empty<object>());
			return num;
		}
		List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> list = new List<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>();
		foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= in this.#=zCY4az9$WUjLsEJ7fgg==.Values)
		{
			if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)300 && !#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z$NyihN71ouQU() && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zjw43QGFcPyHH() < (double)num)
			{
				list.Add(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=);
			}
		}
		list.Sort(new Comparison<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>(#=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zyDNvciU=.#=zLkw0NRU=.#=zzsIIXxbOyY4rJgoeVF1E_OF3$yq3uH1B8g==));
		for (int i = 0; i < list.Count; i++)
		{
			#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = list[i];
			int num2 = num / (int)#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH();
			if (num2 > #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_())
			{
				num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
			}
			if (num2 > 0)
			{
				string text = this.#=zBsXSanI=.#=z8dvXiwU03gsnIHVe1mH4bYxt069R(#=zdRsbMv2cNodA, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=(), num2);
				if (text.Length <= 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964083), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zkfqcY3I=(),
						num2,
						#=zdRsbMv2cNodA,
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963876), new object[]
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zkfqcY3I=(),
					num2,
					#=zdRsbMv2cNodA
				});
				num -= (int)(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zq2bPTdY=().#=zjw43QGFcPyHH() * (double)num2);
				if (num < 300)
				{
					break;
				}
			}
		}
		return num;
	}

	// Token: 0x04000198 RID: 408
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000199 RID: 409
	private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=;

	// Token: 0x0400019A RID: 410
	private DateTime #=zJuQW8gI=;

	// Token: 0x0400019B RID: 411
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x020000A5 RID: 165
	public enum #=zY5xZfq1_bxji
	{

	}

	// Token: 0x020000A6 RID: 166
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600045A RID: 1114 RVA: 0x00025B00 File Offset: 0x00023D00
		internal int #=zkGZDVD5eya4mLAS7oQ==(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zm8PpuDU=, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zcltuPyw=)
		{
			return #=zcltuPyw=.#=zq2bPTdY=().#=zjw43QGFcPyHH().CompareTo(#=zm8PpuDU=.#=zq2bPTdY=().#=zjw43QGFcPyHH());
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00025B2C File Offset: 0x00023D2C
		internal int #=zzsIIXxbOyY4rJgoeVF1E_OF3$yq3uH1B8g==(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zm8PpuDU=, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zcltuPyw=)
		{
			return #=zcltuPyw=.#=zq2bPTdY=().#=zjw43QGFcPyHH().CompareTo(#=zm8PpuDU=.#=zq2bPTdY=().#=zjw43QGFcPyHH());
		}

		// Token: 0x0400019D RID: 413
		public static readonly #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zyDNvciU= #=zLkw0NRU= = new #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=.#=zyDNvciU=();

		// Token: 0x0400019E RID: 414
		public static Comparison<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> #=zLLcqwWqPPIJnz60lVA==;

		// Token: 0x0400019F RID: 415
		public static Comparison<#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=> #=z6kaS0hT02rVUCvrtZA==;
	}
}
