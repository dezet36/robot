﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000161 RID: 353
internal sealed class #=zM9NnqyNC9zqfCk7gu9NWKuRlQfWtMQ1tsAlvtB8bmNd0_MEev7iPnSXvWj55 : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000957 RID: 2391 RVA: 0x0004C2B4 File Offset: 0x0004A4B4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06000958 RID: 2392 RVA: 0x0004C2B8 File Offset: 0x0004A4B8
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM))
		{
			return;
		}
		#=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM = this.#=zcDRV51Ut$7oP as #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM;
		int #=zyTqdZlDghw6s = 0;
		int #=zrHVdHhXM0dTO = 0;
		int #=zyCCuOU4OBChxx9UP3Q== = 0;
		string text = string.Empty;
		int num = Math.Min(#=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=zAN1jhLGuHk65bjr1aA==(), #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zDDkQ_RdZgdNGO6OtyQ==());
		switch (#=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=z9F1kCyejOnmm())
		{
		case ResourceTypes.Grain:
			#=zyCCuOU4OBChxx9UP3Q== = num;
			break;
		case ResourceTypes.Bronze:
			#=zrHVdHhXM0dTO = num;
			break;
		case ResourceTypes.Lumber:
			#=zyTqdZlDghw6s = num;
			break;
		default:
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924897), Array.Empty<object>());
			return;
		}
		text = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=ziW1QRqvFMUe2(#=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=z9F1kCyejOnmm());
		int num2 = #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=zK5gF1KeGk_H_();
		string text2 = #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=zQC8i3zEav7GT();
		DateTime d = #=zbCDHO4CZKa5mbIHVXRU2g_YfaOCc9NpeERksOXkrEJKM.#=zPHMvvJ8=();
		if (d - TimeSpan.FromSeconds(5.0) < DateTime.Now)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924825), new object[]
			{
				text2
			});
			return;
		}
		DateTime t = d - TimeSpan.FromSeconds(20.0);
		while (t > DateTime.Now)
		{
			Thread.Sleep(1000);
		}
		this.#=zBsXSanI=.#=zF5F9PRZBGZrBbiy9ng==(true);
		string text3 = this.#=zBsXSanI=.#=zge7xsK2$r2DH(num2, #=zyTqdZlDghw6s, #=zrHVdHhXM0dTO, #=zyCCuOU4OBChxx9UP3Q==);
		if (text3.Length <= 1000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924257), new object[]
			{
				text2,
				num,
				text,
				JSONManager.Cut(text3)
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924527), new object[]
		{
			text2,
			num,
			text
		});
		object[] array = JSONManager.GetArray(JSONManager.GetData(text3), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
		int num3 = 0;
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601)) && Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]) == num2)
				{
					num3 = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
					break;
				}
			}
		}
		if (num3 <= 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924586), new object[]
			{
				text2
			});
			return;
		}
		DateTime t2 = d + TimeSpan.FromSeconds(10.0);
		while (t2 > DateTime.Now)
		{
			Thread.Sleep(1000);
		}
		this.#=zBsXSanI=.#=zF5F9PRZBGZrBbiy9ng==(true);
		text3 = this.#=zBsXSanI=.#=zMV_fZC22CEHViE8g4A==(num3, false);
		if (text3.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924478), new object[]
			{
				text2
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924654), new object[]
		{
			text2,
			(text3.Length > 1010) ? text3.Substring(0, 1000) : text3
		});
	}
}
