﻿using System;
using System.Collections.Generic;
using System.Linq;
using Skink.SnR.Common.Managers;

// Token: 0x020001D5 RID: 469
internal sealed class #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=
{
	// Token: 0x06000E14 RID: 3604 RVA: 0x00071490 File Offset: 0x0006F690
	public #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(int #=zAk8mKBk=, string #=z6QPrZ_4=, int #=zJpNBs7NQDzQC, int #=zlOnJ95eZiBVA)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zwXKUV2c=(#=z6QPrZ_4=);
		this.#=zHD9M6IxBLboIezSsHQ==(#=zJpNBs7NQDzQC);
		this.#=z2WdNm_CMtqBR6ukyUw==(#=zlOnJ95eZiBVA);
		this.#=zkfEktKY= = string.Empty;
		this.#=zp0wcrTDVPUwj(DateTime.MinValue);
	}

	// Token: 0x06000E15 RID: 3605 RVA: 0x000714CC File Offset: 0x0006F6CC
	public #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=(Dictionary<string, object> #=zzCusQ6s=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050285), -1));
		this.#=zwXKUV2c=(JSONManager.ExtractString(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108019), string.Empty));
		this.#=zHD9M6IxBLboIezSsHQ==(JSONManager.ExtractInt(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
		this.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.ExtractInt(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
		this.#=zAsCgbAN02olKpq2GjA==(JSONManager.ExtractInt(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939649), 0));
		this.#=z6AhOmwNDely78tSumg==(JSONManager.ExtractString(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873374), string.Empty));
		this.#=zkfEktKY= = JSONManager.ExtractString(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076656), string.Empty);
		this.#=zp0wcrTDVPUwj(JSONManager.ExtractDate(#=zzCusQ6s=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873355), false));
		if (string.IsNullOrEmpty(this.#=zkfqcY3I=()))
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=z8StzeqE=, this.#=zMuFMjGQ=().ToString(), true, #=zSJY$s3o=);
			if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null)
			{
				this.#=zwXKUV2c=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=());
				this.#=zHD9M6IxBLboIezSsHQ==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zfTB62qendhk_VEy8rw==());
				this.#=z2WdNm_CMtqBR6ukyUw==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zY0soxphmGIACbOHy6A==());
				return;
			}
			this.#=zwXKUV2c=(this.#=zMuFMjGQ=().ToString());
		}
	}

	// Token: 0x06000E16 RID: 3606 RVA: 0x00071604 File Offset: 0x0006F804
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000E17 RID: 3607 RVA: 0x0007160C File Offset: 0x0006F80C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E18 RID: 3608 RVA: 0x00071618 File Offset: 0x0006F818
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06000E19 RID: 3609 RVA: 0x00071620 File Offset: 0x0006F820
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E1A RID: 3610 RVA: 0x0007162C File Offset: 0x0006F82C
	public int #=zfTB62qendhk_VEy8rw==()
	{
		return this.#=zuCoBS22$SHwioNCsSm1KoiA=;
	}

	// Token: 0x06000E1B RID: 3611 RVA: 0x00071634 File Offset: 0x0006F834
	public void #=zHD9M6IxBLboIezSsHQ==(int #=z$Ib9gYQ=)
	{
		this.#=zuCoBS22$SHwioNCsSm1KoiA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x00071640 File Offset: 0x0006F840
	public int #=zY0soxphmGIACbOHy6A==()
	{
		return this.#=zAZaEN2rHjtRHI7RjIU6YTJk=;
	}

	// Token: 0x06000E1D RID: 3613 RVA: 0x00071648 File Offset: 0x0006F848
	public void #=z2WdNm_CMtqBR6ukyUw==(int #=z$Ib9gYQ=)
	{
		this.#=zAZaEN2rHjtRHI7RjIU6YTJk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E1E RID: 3614 RVA: 0x00071654 File Offset: 0x0006F854
	public int #=zO1FX6YkNZlqlvFZqJg==()
	{
		return this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x0007165C File Offset: 0x0006F85C
	public void #=zAsCgbAN02olKpq2GjA==(int #=z$Ib9gYQ=)
	{
		this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x00071668 File Offset: 0x0006F868
	public string #=zj661vGqZTMsoJ4JrPg==()
	{
		return this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1;
	}

	// Token: 0x06000E21 RID: 3617 RVA: 0x00071670 File Offset: 0x0006F870
	public void #=z6AhOmwNDely78tSumg==(string #=z$Ib9gYQ=)
	{
		this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E22 RID: 3618 RVA: 0x0007167C File Offset: 0x0006F87C
	public string #=zTbtwDpWhYGtF()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070458), this.#=zkfqcY3I=(), this.#=zfTB62qendhk_VEy8rw==(), this.#=zY0soxphmGIACbOHy6A==());
	}

	// Token: 0x06000E23 RID: 3619 RVA: 0x000716AC File Offset: 0x0006F8AC
	public DateTime #=zmj4J_vTRu57u()
	{
		return this.#=zrdcJEzFTcrPzxoKj2zj8ypo=;
	}

	// Token: 0x06000E24 RID: 3620 RVA: 0x000716B4 File Offset: 0x0006F8B4
	public void #=zp0wcrTDVPUwj(DateTime #=z$Ib9gYQ=)
	{
		this.#=zrdcJEzFTcrPzxoKj2zj8ypo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E25 RID: 3621 RVA: 0x000716C0 File Offset: 0x0006F8C0
	private bool #=zJZkDBc_9xNqf(char #=zNraCe1Y=)
	{
		return Enumerable.Contains<char>(this.#=zkfEktKY=, #=zNraCe1Y=);
	}

	// Token: 0x06000E26 RID: 3622 RVA: 0x000716D0 File Offset: 0x0006F8D0
	private void #=z_WT4TJoNDSeY(char #=zNraCe1Y=, bool #=z$Ib9gYQ=)
	{
		if (#=z$Ib9gYQ=)
		{
			if (!Enumerable.Contains<char>(this.#=zkfEktKY=, #=zNraCe1Y=))
			{
				this.#=zkfEktKY= += #=zNraCe1Y=.ToString();
				return;
			}
		}
		else
		{
			this.#=zkfEktKY= = this.#=zkfEktKY=.Replace(#=zNraCe1Y=.ToString(), string.Empty);
		}
	}

	// Token: 0x06000E27 RID: 3623 RVA: 0x00071724 File Offset: 0x0006F924
	public bool #=zu_rEcX_K9l9O()
	{
		return this.#=zJZkDBc_9xNqf('m');
	}

	// Token: 0x06000E28 RID: 3624 RVA: 0x00071730 File Offset: 0x0006F930
	public void #=zGHLCYJmbc1Pd(bool #=z$Ib9gYQ=)
	{
		this.#=z_WT4TJoNDSeY('m', #=z$Ib9gYQ=);
	}

	// Token: 0x06000E29 RID: 3625 RVA: 0x0007173C File Offset: 0x0006F93C
	public bool #=zsVa4US_DOpbi()
	{
		return this.#=zJZkDBc_9xNqf('e');
	}

	// Token: 0x06000E2A RID: 3626 RVA: 0x00071748 File Offset: 0x0006F948
	public void #=zu2gIox_y5kvk(bool #=z$Ib9gYQ=)
	{
		this.#=z_WT4TJoNDSeY('e', #=z$Ib9gYQ=);
	}

	// Token: 0x06000E2B RID: 3627 RVA: 0x00071754 File Offset: 0x0006F954
	public bool #=zSL$CHR_zajMs()
	{
		return this.#=zJZkDBc_9xNqf('d');
	}

	// Token: 0x06000E2C RID: 3628 RVA: 0x00071760 File Offset: 0x0006F960
	public void #=z5ktH1NpFood7(bool #=z$Ib9gYQ=)
	{
		this.#=z_WT4TJoNDSeY('d', #=z$Ib9gYQ=);
	}

	// Token: 0x06000E2D RID: 3629 RVA: 0x0007176C File Offset: 0x0006F96C
	public bool #=zG2Z_XuNYkfx2nMs5QRPfY68=()
	{
		return this.#=zu_rEcX_K9l9O();
	}

	// Token: 0x06000E2E RID: 3630 RVA: 0x00071774 File Offset: 0x0006F974
	public bool #=zAQ1RVL2qRBaU()
	{
		return this.#=zu_rEcX_K9l9O();
	}

	// Token: 0x06000E2F RID: 3631 RVA: 0x0007177C File Offset: 0x0006F97C
	public bool #=zfoY4YQm8_Ygr()
	{
		return this.#=zu_rEcX_K9l9O();
	}

	// Token: 0x06000E30 RID: 3632 RVA: 0x00071784 File Offset: 0x0006F984
	public bool #=zxWEtbaIh9mLk()
	{
		return this.#=zu_rEcX_K9l9O();
	}

	// Token: 0x06000E31 RID: 3633 RVA: 0x0007178C File Offset: 0x0006F98C
	public bool #=zosa3YqZaOFWz8xhtVw==()
	{
		return this.#=zu_rEcX_K9l9O();
	}

	// Token: 0x06000E32 RID: 3634 RVA: 0x00071794 File Offset: 0x0006F994
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050285)] = this.#=zMuFMjGQ=();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108019)] = this.#=zkfqcY3I=();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)] = this.#=zfTB62qendhk_VEy8rw==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)] = this.#=zY0soxphmGIACbOHy6A==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939649)] = this.#=zO1FX6YkNZlqlvFZqJg==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873374)] = this.#=zj661vGqZTMsoJ4JrPg==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076656)] = this.#=zkfEktKY=;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873355)] = JSONManager.EncodeTime(this.#=zmj4J_vTRu57u(), false);
		return dictionary;
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x00071870 File Offset: 0x0006FA70
	public override string ToString()
	{
		return string.Join(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051837), new string[]
		{
			this.#=zMuFMjGQ=().ToString(),
			this.#=zkfqcY3I=().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051837), string.Empty).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939112), string.Empty),
			this.#=zfTB62qendhk_VEy8rw==().ToString(),
			this.#=zY0soxphmGIACbOHy6A==().ToString(),
			this.#=zkfEktKY=,
			JSONManager.DateToUserString(this.#=zmj4J_vTRu57u())
		});
	}

	// Token: 0x040007E5 RID: 2021
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040007E6 RID: 2022
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040007E7 RID: 2023
	private int #=zuCoBS22$SHwioNCsSm1KoiA=;

	// Token: 0x040007E8 RID: 2024
	private int #=zAZaEN2rHjtRHI7RjIU6YTJk=;

	// Token: 0x040007E9 RID: 2025
	private int #=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;

	// Token: 0x040007EA RID: 2026
	private string #=zmNuFeIk1PExEPxrcVomfAICh_vk1;

	// Token: 0x040007EB RID: 2027
	private DateTime #=zrdcJEzFTcrPzxoKj2zj8ypo=;

	// Token: 0x040007EC RID: 2028
	private string #=zkfEktKY=;
}
