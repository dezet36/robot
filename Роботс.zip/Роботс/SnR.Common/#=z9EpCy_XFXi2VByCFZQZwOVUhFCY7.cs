﻿using System;
using System.Collections;
using System.Text;

// Token: 0x020000B1 RID: 177
internal abstract class #=z9EpCy_XFXi2VByCFZQZwOVUhFCY7 : #=zrACqpkJvpkMu2ypmK4UXXdQ=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600049C RID: 1180 RVA: 0x00026C9C File Offset: 0x00024E9C
	public #=z9EpCy_XFXi2VByCFZQZwOVUhFCY7()
	{
	}

	// Token: 0x0600049D RID: 1181 RVA: 0x00026CA4 File Offset: 0x00024EA4
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = this.#=zb$ssayA=()[0].#=ztbIWLuVjfGLU();
		sbyte[] array2 = new sbyte[array.Length + 1];
		Array.Copy(array, 0, array2, 0, array.Length);
		array2[array.Length] = this.#=znmVMpDg=().#=zd$BbM3Y=();
		return array2;
	}

	// Token: 0x0600049E RID: 1182
	internal abstract #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=();

	// Token: 0x0600049F RID: 1183 RVA: 0x00026CE8 File Offset: 0x00024EE8
	public virtual int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		return 0;
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x00026CEC File Offset: 0x00024EEC
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4= = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
		this.#=zdJYbEvQ=(#=zpvGJrv4=);
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x00026D0C File Offset: 0x00024F0C
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		#=zXvwCnz8=.Append(this.#=ze3HB9kQ=());
		array[0].#=zSpOkW5A=(#=zXvwCnz8=);
	}

	// Token: 0x060004A2 RID: 1186 RVA: 0x00026D2C File Offset: 0x00024F2C
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		this.#=zb$ssayA=()[0].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
	}

	// Token: 0x060004A3 RID: 1187 RVA: 0x00026D40 File Offset: 0x00024F40
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zb$ssayA=()[0].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x00026D54 File Offset: 0x00024F54
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zb$ssayA=()[0].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x00026D68 File Offset: 0x00024F68
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zb$ssayA=()[0].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x00026D7C File Offset: 0x00024F7C
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zb$ssayA=()[0].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x060004A7 RID: 1191
	public abstract string #=ze3HB9kQ=();
}
