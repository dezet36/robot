﻿using System;
using System.Threading;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000049 RID: 73
internal sealed class #=z2gAz25B09ZkzeYrE18YsAzD83SwNkovB4LeS7_AErSt9VevB_Kw$wzI= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600023D RID: 573 RVA: 0x000150C4 File Offset: 0x000132C4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zkdGdpYZ7Wpxf = #=zuJjQ1XU=.#=zoSyVTLOhKIN4();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
	}

	// Token: 0x0600023E RID: 574 RVA: 0x000150F8 File Offset: 0x000132F8
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=))
		{
			return;
		}
		if (this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zKJKWakAT6jUi5ml5CkFAYR8=().#=zVcIxe_4=())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930058), Array.Empty<object>());
			return;
		}
		#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= = this.#=zcDRV51Ut$7oP as #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=;
		#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg= #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2 = (#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=)#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.MasterTask.Task;
		int num = Math.Min(this.#=z1pahAF0JqdFM8mgjDQ==.#=zxZCerbvcGABMaw4jNA==(), this.#=z1pahAF0JqdFM8mgjDQ==.#=zhv46JpQA_A2R328PYqjpCx8=());
		int openResPackAddGrain = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OpenResPackAddGrain;
		for (int i = 1; i <= 20; i++)
		{
			int num2;
			if (#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zLjm$kaoe2AbnoVRBfg==())
			{
				num2 = num - openResPackAddGrain * 2;
			}
			else
			{
				num2 = this.#=z3yL5bKs=.#=z$QpPChdewFHO(new ResourceTypes[]
				{
					ResourceTypes.Bronze,
					ResourceTypes.Lumber,
					ResourceTypes.Grain
				});
			}
			if (num2 < 10000 || num2 < openResPackAddGrain * 2)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930255), Array.Empty<object>());
				return;
			}
			num2 = num2 / 10000 * 10000;
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930192), new object[]
			{
				#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zg$iaM0kytTEf(),
				#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zBm2rcaHKqpSf(),
				num2
			});
			int num3 = #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=z$IzzkOA=(num2);
			try
			{
				if (num3 <= 0)
				{
					if (#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zBm2rcaHKqpSf() <= 0)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931911), new object[]
						{
							#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==()
						});
						break;
					}
					Thread.Sleep((int)(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zxZUNpQr446iF4sFzC4IllHyNkuAk() * 10000.0));
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908932093), new object[]
					{
						#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
						i,
						num3
					});
					if (#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zLjm$kaoe2AbnoVRBfg==())
					{
						int num4 = (int)Math.Ceiling((double)(num3 + openResPackAddGrain * 2) / 10000.0) * 10000;
						if (num4 > num)
						{
							num4 = num;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931996), new object[]
						{
							this.#=z3yL5bKs=.#=z$QpPChdewFHO(new ResourceTypes[]
							{
								ResourceTypes.Bronze,
								ResourceTypes.Lumber,
								ResourceTypes.Grain
							}),
							num4
						});
						#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zWySAjNcqrbmr = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2
						{
							new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes.Grain, num4),
							new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes.Lumber, num4),
							new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes.Bronze, num4)
						};
						object #=zxheKPs0= = #=zuwGCAxWx_QT6N5zYtvZwG8RczV_Wh1HraY2LEBhJG29A1LgHDa1XlX_oOhXIxC8FHg==.#=zoNe7kz3y_QsgC4GBBmVRFTE=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=zCY4az9$WUjLsEJ7fgg==, this.#=z3yL5bKs=, #=zWySAjNcqrbmr, #=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zxiTIzLO4JHjcG2ddqw==(), true);
						base.#=zL1HTbwC75LO$(#=zxheKPs0=);
					}
					int num5 = this.#=z3yL5bKs=.#=z$QpPChdewFHO(new ResourceTypes[]
					{
						ResourceTypes.Bronze,
						ResourceTypes.Lumber,
						ResourceTypes.Grain
					});
					if (num5 < openResPackAddGrain * 2 && num5 < num3 / 2)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908930255), Array.Empty<object>());
						break;
					}
					int num6 = num5 / 1000 * 1000 - openResPackAddGrain;
					if (num6 > num3)
					{
						num6 = num3;
					}
					if (num6 < 0)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931680), new object[]
						{
							#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
							num6
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931599), new object[]
						{
							#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
							num6
						});
						string text = this.#=zBsXSanI=.#=z48QmpulFh35B(#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zxI3h$5i_fx2h(), num6);
						text = text.Trim();
						if (text.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931784), new object[]
							{
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
								num6
							});
							base.#=zL1HTbwC75LO$(text);
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931737), new object[]
							{
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zg$iaM0kytTEf(),
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zBm2rcaHKqpSf(),
								num3,
								num6
							});
							#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zZFZo118=(num6);
							if (num3 > num6)
							{
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3 - num6);
							}
						}
						else
						{
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931362)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931342), new object[]
								{
									#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
									num6
								});
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3);
								break;
							}
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931483)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931198), new object[]
								{
									#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
									num6
								});
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3);
								this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zKJKWakAT6jUi5ml5CkFAYR8=().#=zKTAVzhk=(true);
								break;
							}
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931111)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931077), new object[]
								{
									#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
									num6
								});
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3);
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zNZkkiPc=();
								break;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908931247), new object[]
							{
								#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=.#=zMmwKnVQRjotIACC$jA==(),
								num6,
								JSONManager.Cut(text)
							});
							#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3);
						}
					}
				}
			}
			catch
			{
				#=zdluXsBWo9WFUlpfBvQiGV6HDJ_tuWiLjFhqAjTg=2.#=zQgGl73U=(num3);
				throw;
			}
		}
	}

	// Token: 0x040000AD RID: 173
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x040000AE RID: 174
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x040000AF RID: 175
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zkdGdpYZ7Wpxf;

	// Token: 0x040000B0 RID: 176
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;
}
