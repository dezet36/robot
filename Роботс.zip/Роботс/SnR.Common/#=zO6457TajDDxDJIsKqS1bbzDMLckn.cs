﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x0200016F RID: 367
internal sealed class #=zO6457TajDDxDJIsKqS1bbzDMLckn : #=zLG6uk$Gz0HYsu5astWupkBlXmaty4YJdWIIUAcw=
{
	// Token: 0x060009C0 RID: 2496 RVA: 0x0004FD54 File Offset: 0x0004DF54
	[CompilerGenerated]
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x060009C1 RID: 2497 RVA: 0x0004FD5C File Offset: 0x0004DF5C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009C2 RID: 2498 RVA: 0x0004FD68 File Offset: 0x0004DF68
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060009C3 RID: 2499 RVA: 0x0004FD70 File Offset: 0x0004DF70
	public void #=zzQwUIEs=(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009C4 RID: 2500 RVA: 0x0004FD7C File Offset: 0x0004DF7C
	public #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A== #=zo4pctbtCxQ0d()
	{
		return this.#=zq2bPTdY=();
	}

	// Token: 0x060009C5 RID: 2501 RVA: 0x0004FD84 File Offset: 0x0004DF84
	[CompilerGenerated]
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x060009C6 RID: 2502 RVA: 0x0004FD8C File Offset: 0x0004DF8C
	public void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009C7 RID: 2503 RVA: 0x0004FD98 File Offset: 0x0004DF98
	public string #=zkfqcY3I=()
	{
		if (this.#=zq2bPTdY=() == null)
		{
			return this.#=zFMDiymuLQ7_4().ToString();
		}
		return this.#=zq2bPTdY=().Name;
	}

	// Token: 0x060009C8 RID: 2504 RVA: 0x0004FDC8 File Offset: 0x0004DFC8
	[CompilerGenerated]
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x060009C9 RID: 2505 RVA: 0x0004FDD0 File Offset: 0x0004DFD0
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009CA RID: 2506 RVA: 0x0004FDDC File Offset: 0x0004DFDC
	public int #=zfTB62qendhk_VEy8rw==()
	{
		return this.#=zuCoBS22$SHwioNCsSm1KoiA=;
	}

	// Token: 0x060009CB RID: 2507 RVA: 0x0004FDE4 File Offset: 0x0004DFE4
	public void #=zHD9M6IxBLboIezSsHQ==(int #=z$Ib9gYQ=)
	{
		this.#=zuCoBS22$SHwioNCsSm1KoiA= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009CC RID: 2508 RVA: 0x0004FDF0 File Offset: 0x0004DFF0
	public int #=zY0soxphmGIACbOHy6A==()
	{
		return this.#=zAZaEN2rHjtRHI7RjIU6YTJk=;
	}

	// Token: 0x060009CD RID: 2509 RVA: 0x0004FDF8 File Offset: 0x0004DFF8
	public void #=z2WdNm_CMtqBR6ukyUw==(int #=z$Ib9gYQ=)
	{
		this.#=zAZaEN2rHjtRHI7RjIU6YTJk= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009CE RID: 2510 RVA: 0x0004FE04 File Offset: 0x0004E004
	public int #=zlSY2GGkBa6S3MkHuDQ==()
	{
		return this.#=zyOG_0QKBW4ErDBQOsBmwL5A=;
	}

	// Token: 0x060009CF RID: 2511 RVA: 0x0004FE0C File Offset: 0x0004E00C
	public void #=zNzS1JlWmGn84_d6f9A==(int #=z$Ib9gYQ=)
	{
		this.#=zyOG_0QKBW4ErDBQOsBmwL5A= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009D0 RID: 2512 RVA: 0x0004FE18 File Offset: 0x0004E018
	public bool #=zAdM$oWHPKFC_gx1bYQ==()
	{
		return this.#=za4NVqhanJyE1AJ79hmCohGc=;
	}

	// Token: 0x060009D1 RID: 2513 RVA: 0x0004FE20 File Offset: 0x0004E020
	public void #=zSIKgNs5Taw6RyqqQZw==(bool #=z$Ib9gYQ=)
	{
		this.#=za4NVqhanJyE1AJ79hmCohGc= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009D2 RID: 2514 RVA: 0x0004FE2C File Offset: 0x0004E02C
	public int #=z_ffm9$kcf9Y8EY_3cw==()
	{
		return this.#=zosW6N3NYnkaWO3ZvYh3JkOI=;
	}

	// Token: 0x060009D3 RID: 2515 RVA: 0x0004FE34 File Offset: 0x0004E034
	public void #=zQx7wBUdkq1I088Sg0Q==(int #=z$Ib9gYQ=)
	{
		this.#=zosW6N3NYnkaWO3ZvYh3JkOI= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009D4 RID: 2516 RVA: 0x0004FE40 File Offset: 0x0004E040
	[CompilerGenerated]
	public DateTime #=zGhmoNZChgwf8()
	{
		return this.#=zrJWzUSI7ettVti1bB38Mz8I=;
	}

	// Token: 0x060009D5 RID: 2517 RVA: 0x0004FE48 File Offset: 0x0004E048
	public void #=zdU1a9B$ueh_3(DateTime #=z$Ib9gYQ=)
	{
		this.#=zrJWzUSI7ettVti1bB38Mz8I= = #=z$Ib9gYQ=;
	}

	// Token: 0x060009D6 RID: 2518 RVA: 0x0004FE54 File Offset: 0x0004E054
	public bool #=zH9V7bObvvn_m()
	{
		return this.#=zb$yK65pf$UAncniFOA==;
	}

	// Token: 0x060009D7 RID: 2519 RVA: 0x0004FE5C File Offset: 0x0004E05C
	public void #=z6zRvpPP_$ZVF(bool #=z$Ib9gYQ=)
	{
		this.#=zb$yK65pf$UAncniFOA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060009D8 RID: 2520 RVA: 0x0004FE68 File Offset: 0x0004E068
	public bool #=z5kpAZQpjT2b7()
	{
		return this.#=zGhmoNZChgwf8() != DateTime.MinValue;
	}

	// Token: 0x060009D9 RID: 2521 RVA: 0x0004FE7C File Offset: 0x0004E07C
	public int #=zr4Y9pMX2tLmdnCGRJw==()
	{
		return this.#=zRIgkYHfvXRxODqImfWStjJj8zJDu;
	}

	// Token: 0x060009DA RID: 2522 RVA: 0x0004FE84 File Offset: 0x0004E084
	public void #=zpN8az$GdxbPzdnDtHg==(int #=z$Ib9gYQ=)
	{
		this.#=zRIgkYHfvXRxODqImfWStjJj8zJDu = #=z$Ib9gYQ=;
	}

	// Token: 0x060009DB RID: 2523 RVA: 0x0004FE90 File Offset: 0x0004E090
	public int #=zjw43QGFcPyHH()
	{
		if (this.#=zq2bPTdY=() == null)
		{
			return 0;
		}
		if (this.#=zq2bPTdY=().#=zjw43QGFcPyHH() == null)
		{
			return 0;
		}
		if (this.#=zq2bPTdY=().#=zjw43QGFcPyHH().Length > this.#=zvnZc$RhG_1Du() - 1)
		{
			return this.#=zq2bPTdY=().#=zjw43QGFcPyHH()[this.#=zvnZc$RhG_1Du() - 1];
		}
		return this.#=zq2bPTdY=().#=zjw43QGFcPyHH()[this.#=zq2bPTdY=().#=zjw43QGFcPyHH().Length - 1];
	}

	// Token: 0x060009DC RID: 2524 RVA: 0x0004FF00 File Offset: 0x0004E100
	public #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng== #=zJtclDBkKCg12()
	{
		if (this.#=zq2bPTdY=() == null)
		{
			return new #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==();
		}
		return this.#=zq2bPTdY=().#=zJtclDBkKCg12().#=zS9T3RUESmMfO(this.#=zvnZc$RhG_1Du());
	}

	// Token: 0x040005A0 RID: 1440
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040005A1 RID: 1441
	private #=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040005A2 RID: 1442
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x040005A3 RID: 1443
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x040005A4 RID: 1444
	private int #=zuCoBS22$SHwioNCsSm1KoiA=;

	// Token: 0x040005A5 RID: 1445
	private int #=zAZaEN2rHjtRHI7RjIU6YTJk=;

	// Token: 0x040005A6 RID: 1446
	private int #=zyOG_0QKBW4ErDBQOsBmwL5A=;

	// Token: 0x040005A7 RID: 1447
	private bool #=za4NVqhanJyE1AJ79hmCohGc=;

	// Token: 0x040005A8 RID: 1448
	private int #=zosW6N3NYnkaWO3ZvYh3JkOI=;

	// Token: 0x040005A9 RID: 1449
	private DateTime #=zrJWzUSI7ettVti1bB38Mz8I=;

	// Token: 0x040005AA RID: 1450
	private bool #=zb$yK65pf$UAncniFOA==;

	// Token: 0x040005AB RID: 1451
	private int #=zRIgkYHfvXRxODqImfWStjJj8zJDu;
}
