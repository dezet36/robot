﻿using System;
using System.Collections;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x02000212 RID: 530
internal sealed class #=zc9TLR46Rk96PBThDLpIiZ1s62lIL : #=zZ$R16GhWBF9T3o7$kk5QJk8=
{
	// Token: 0x0600103E RID: 4158 RVA: 0x0007CF6C File Offset: 0x0007B16C
	public #=zc9TLR46Rk96PBThDLpIiZ1s62lIL(sbyte[] #=zJ5GWysk=, Cell #=zQUn_5_A=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, WorkbookSettings #=z4JisLog=)
	{
		this.#=zCMwF7nk= = #=zJ5GWysk=;
		this.#=z4J_G3VM= = 0;
		this.#=zq07FqDs= = #=zQUn_5_A=;
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
		this.#=zwGB7DOCdDCwf = new Stack();
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x06001040 RID: 4160 RVA: 0x0007CFC4 File Offset: 0x0007B1C4
	public string #=zmUYpUBj2v7o$()
	{
		StringBuilder stringBuilder = new StringBuilder();
		this.#=zUQxuxX4=.#=zSpOkW5A=(stringBuilder);
		return stringBuilder.ToString();
	}

	// Token: 0x06001041 RID: 4161 RVA: 0x0007CFEC File Offset: 0x0007B1EC
	public sbyte[] #=ztbIWLuVjfGLU()
	{
		return this.#=zUQxuxX4=.#=ztbIWLuVjfGLU();
	}

	// Token: 0x06001042 RID: 4162 RVA: 0x0007CFFC File Offset: 0x0007B1FC
	public void #=zGgEMxSM=()
	{
		this.#=zqWkh9oica3zJ(this.#=zCMwF7nk=.Length);
		this.#=zUQxuxX4= = (#=zoImewjUBfkPyF1oU_G4atTk=)this.#=zwGB7DOCdDCwf.Pop();
		Assert.verify(this.#=zwGB7DOCdDCwf.Count <= 0);
	}

	// Token: 0x06001043 RID: 4163 RVA: 0x0007D038 File Offset: 0x0007B238
	private void #=zqWkh9oica3zJ(int #=zZBlusgI=)
	{
		Stack stack = new Stack();
		int num = this.#=z4J_G3VM= + #=zZBlusgI=;
		while (this.#=z4J_G3VM= < num)
		{
			int num2 = (int)this.#=zCMwF7nk=[this.#=z4J_G3VM=];
			this.#=z4J_G3VM=++;
			#=zwUe4tm5XLL76xe$ToMjBTwE= #=zwUe4tm5XLL76xe$ToMjBTwE= = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z6dTlGvc=(num2);
			if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zNUFwPq0=)
			{
				throw new FormulaException(FormulaException.#=zbgCVA5q175lpq6RcX3t3JgA=, num2);
			}
			Assert.verify(#=zwUe4tm5XLL76xe$ToMjBTwE= != #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zNUFwPq0=);
			if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=ztzoFLYo=)
			{
				#=zmIoOMk5gpONjUdFBWMzEoSA= #=zmIoOMk5gpONjUdFBWMzEoSA= = new #=zmIoOMk5gpONjUdFBWMzEoSA=(this.#=zq07FqDs=);
				this.#=z4J_G3VM= += #=zmIoOMk5gpONjUdFBWMzEoSA=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zmIoOMk5gpONjUdFBWMzEoSA=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zIl3$Cb6JX0pi)
			{
				#=zM0skyyV8WafUvIlFnkIs4er6wYjP #=zM0skyyV8WafUvIlFnkIs4er6wYjP = new #=zM0skyyV8WafUvIlFnkIs4er6wYjP(this.#=zq07FqDs=);
				this.#=z4J_G3VM= += #=zM0skyyV8WafUvIlFnkIs4er6wYjP.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zM0skyyV8WafUvIlFnkIs4er6wYjP);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zHPI6sEfaHA0e)
			{
				#=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r = new #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r(this.#=zq07FqDs=, this.#=zJY$tXiAJ_$AzbtOFtg==);
				this.#=z4J_G3VM= += #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQ_CaaLVcHjOz)
			{
				#=zRFbnANRws$wumebgXSXu5QM= #=zRFbnANRws$wumebgXSXu5QM= = new #=zRFbnANRws$wumebgXSXu5QM=();
				this.#=z4J_G3VM= += #=zRFbnANRws$wumebgXSXu5QM=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zRFbnANRws$wumebgXSXu5QM=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zL5ATr8YSaGk1)
			{
				#=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C #=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C = new #=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C(this.#=zq07FqDs=);
				this.#=z4J_G3VM= += #=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zBz2h_SaFiBiyIEuV6g0VGnBJ6v_C);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zGsPufWW4LYcC)
			{
				#=zYRBp8JHHiG6gkn2KPveD3dKfi4vU #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU = new #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU(this.#=zJY$tXiAJ_$AzbtOFtg==);
				this.#=z4J_G3VM= += #=zYRBp8JHHiG6gkn2KPveD3dKfi4vU.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zYRBp8JHHiG6gkn2KPveD3dKfi4vU);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zb1ci1Cs=)
			{
				#=zyZ$0rvWBBMzwFggHGFOpi9A= #=zyZ$0rvWBBMzwFggHGFOpi9A= = new #=zyZ$0rvWBBMzwFggHGFOpi9A=();
				this.#=z4J_G3VM= += #=zyZ$0rvWBBMzwFggHGFOpi9A=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zyZ$0rvWBBMzwFggHGFOpi9A=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zqLZK5Kk1neIF5Bq2Rg==)
			{
				#=zzkkz5GqKdd1$GYR0wrrLVuI= #=zzkkz5GqKdd1$GYR0wrrLVuI= = new #=zzkkz5GqKdd1$GYR0wrrLVuI=(this.#=zLJGAifU=);
				this.#=z4J_G3VM= += #=zzkkz5GqKdd1$GYR0wrrLVuI=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zzkkz5GqKdd1$GYR0wrrLVuI=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zXReq9uA=)
			{
				#=ztehYPOx2oo__hagJu3exMP4= #=ztehYPOx2oo__hagJu3exMP4= = new #=ztehYPOx2oo__hagJu3exMP4=();
				this.#=z4J_G3VM= += #=ztehYPOx2oo__hagJu3exMP4=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=ztehYPOx2oo__hagJu3exMP4=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zOnKjUs92eTFw)
			{
				#=zINqPaypOVANwYlpJtujz4xc= #=zINqPaypOVANwYlpJtujz4xc= = new #=zINqPaypOVANwYlpJtujz4xc=();
				this.#=z4J_G3VM= += #=zINqPaypOVANwYlpJtujz4xc=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zINqPaypOVANwYlpJtujz4xc=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zr7sVnrM=)
			{
				#=zjDyGwkfNTtkuN31SOnRKBTs= #=zjDyGwkfNTtkuN31SOnRKBTs= = new #=zjDyGwkfNTtkuN31SOnRKBTs=();
				this.#=z4J_G3VM= += #=zjDyGwkfNTtkuN31SOnRKBTs=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zjDyGwkfNTtkuN31SOnRKBTs=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z8ozxU5g=)
			{
				#=zPA0EJTEsxNJBLwMFiQxjO9Y= #=zPA0EJTEsxNJBLwMFiQxjO9Y= = new #=zPA0EJTEsxNJBLwMFiQxjO9Y=(this.#=z6bRJXNQ=);
				this.#=z4J_G3VM= += #=zPA0EJTEsxNJBLwMFiQxjO9Y=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zPA0EJTEsxNJBLwMFiQxjO9Y=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zfHGMuN402kM5)
			{
				#=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk #=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk = new #=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk();
				this.#=z4J_G3VM= += #=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zwGB7DOCdDCwf.Push(#=zX7EwVDMHjj_eWHXMb0Fa_hJxDZpk);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zWdXRcUXGRn8Kng0PVQ==)
			{
				#=zcryzuJdqHJDm55mRqseDxWYoSP9$ #=zcryzuJdqHJDm55mRqseDxWYoSP9$ = new #=zcryzuJdqHJDm55mRqseDxWYoSP9$();
				this.#=z4J_G3VM= += #=zcryzuJdqHJDm55mRqseDxWYoSP9$.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zcryzuJdqHJDm55mRqseDxWYoSP9$);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zX_PPthewR8yJjLyF0w==)
			{
				#=zYJAiLFGrYu7ExtOxWlwZzHledAAC #=zYJAiLFGrYu7ExtOxWlwZzHledAAC = new #=zYJAiLFGrYu7ExtOxWlwZzHledAAC();
				this.#=z4J_G3VM= += #=zYJAiLFGrYu7ExtOxWlwZzHledAAC.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zYJAiLFGrYu7ExtOxWlwZzHledAAC);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z2Pqb24mFSKCf)
			{
				#=zsKSj37x8j6Lm5u5FfXCFIlU= #=zsKSj37x8j6Lm5u5FfXCFIlU= = new #=zsKSj37x8j6Lm5u5FfXCFIlU=();
				this.#=z4J_G3VM= += #=zsKSj37x8j6Lm5u5FfXCFIlU=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zsKSj37x8j6Lm5u5FfXCFIlU=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z6313TdZbrK_wqx0oeQ==)
			{
				#=z7najYys5p26JyZMBb3SOJ2o= #=z7najYys5p26JyZMBb3SOJ2o= = new #=z7najYys5p26JyZMBb3SOJ2o=();
				this.#=z4J_G3VM= += #=z7najYys5p26JyZMBb3SOJ2o=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=z7najYys5p26JyZMBb3SOJ2o=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z35BEnJ8=)
			{
				#=zgJ0MGdKW7_OcG_XAvb6i$58= #=zgJ0MGdKW7_OcG_XAvb6i$58= = new #=zgJ0MGdKW7_OcG_XAvb6i$58=();
				this.#=z4J_G3VM= += #=zgJ0MGdKW7_OcG_XAvb6i$58=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zgJ0MGdKW7_OcG_XAvb6i$58=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zeXig7da_G152sdRShw==)
			{
				#=z26PVQ4L5c6_XrCwJa_YmAEM= #=z26PVQ4L5c6_XrCwJa_YmAEM= = new #=z26PVQ4L5c6_XrCwJa_YmAEM=();
				this.#=z4J_G3VM= += #=z26PVQ4L5c6_XrCwJa_YmAEM=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=z26PVQ4L5c6_XrCwJa_YmAEM=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQjb3XO3PMRiZ)
			{
				#=z_9QeQX33e0ZIk3yCxt1JB0I= #=z_9QeQX33e0ZIk3yCxt1JB0I= = new #=z_9QeQX33e0ZIk3yCxt1JB0I=();
				this.#=z4J_G3VM= += #=z_9QeQX33e0ZIk3yCxt1JB0I=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=z_9QeQX33e0ZIk3yCxt1JB0I=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zhovzSfs8pQ7Q)
			{
				#=zUf7AkUo_mcA$WAagIXOMiDs= #=zUf7AkUo_mcA$WAagIXOMiDs= = new #=zUf7AkUo_mcA$WAagIXOMiDs=();
				this.#=z4J_G3VM= += #=zUf7AkUo_mcA$WAagIXOMiDs=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zUf7AkUo_mcA$WAagIXOMiDs=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zCh3653M=)
			{
				#=zgY_zr6wDt9bP7AOP6CgynKs= #=zgY_zr6wDt9bP7AOP6CgynKs= = new #=zgY_zr6wDt9bP7AOP6CgynKs=();
				this.#=z4J_G3VM= += #=zgY_zr6wDt9bP7AOP6CgynKs=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zgY_zr6wDt9bP7AOP6CgynKs=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zIFRl8bAAVcfa)
			{
				#=zGVg9b0SNNZXoUNlnSbs$HHqhofDU #=zGVg9b0SNNZXoUNlnSbs$HHqhofDU = new #=zGVg9b0SNNZXoUNlnSbs$HHqhofDU();
				this.#=z4J_G3VM= += #=zGVg9b0SNNZXoUNlnSbs$HHqhofDU.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zGVg9b0SNNZXoUNlnSbs$HHqhofDU);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z9XNVesDtacWkkDWqMw==)
			{
				#=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg #=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg = new #=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg();
				this.#=z4J_G3VM= += #=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=znMz8Ci8jZh5sHs0lQwLFyk$Qd7Yg);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zU1NYwIqXXdrZ)
			{
				#=zFG8YXHlzLmur6XFABoDqKLuZrFFV #=zFG8YXHlzLmur6XFABoDqKLuZrFFV = new #=zFG8YXHlzLmur6XFABoDqKLuZrFFV();
				this.#=z4J_G3VM= += #=zFG8YXHlzLmur6XFABoDqKLuZrFFV.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zFG8YXHlzLmur6XFABoDqKLuZrFFV);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zQDVO67WHVcIJN5ZZsQ==)
			{
				#=z78caHtrDngQtuhh0PBKp6o927wP3 #=z78caHtrDngQtuhh0PBKp6o927wP = new #=z78caHtrDngQtuhh0PBKp6o927wP3();
				this.#=z4J_G3VM= += #=z78caHtrDngQtuhh0PBKp6o927wP.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=z78caHtrDngQtuhh0PBKp6o927wP);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zV9NILhXukjVlJQslzg==)
			{
				#=z$NEwNZR20jcfgsC228hQqoE= #=z$NEwNZR20jcfgsC228hQqoE= = new #=z$NEwNZR20jcfgsC228hQqoE=();
				this.#=z4J_G3VM= += #=z$NEwNZR20jcfgsC228hQqoE=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=z$NEwNZR20jcfgsC228hQqoE=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zaLxBrgGRq_lk)
			{
				#=zoQbOOfZXwfMAZDEEMnMU6Dc= #=zoQbOOfZXwfMAZDEEMnMU6Dc= = new #=zoQbOOfZXwfMAZDEEMnMU6Dc=();
				this.#=z4J_G3VM= += #=zoQbOOfZXwfMAZDEEMnMU6Dc=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zoQbOOfZXwfMAZDEEMnMU6Dc=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z6PwcgG$cka3iBn9Q3Q==)
			{
				#=ztrvdaaecFaDOU3dtdEtTmfs= #=ztrvdaaecFaDOU3dtdEtTmfs= = new #=ztrvdaaecFaDOU3dtdEtTmfs=();
				this.#=z4J_G3VM= += #=ztrvdaaecFaDOU3dtdEtTmfs=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=ztrvdaaecFaDOU3dtdEtTmfs=);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=)
			{
				#=zKtn4_SrRtk6XXy4d83LlFV0= #=zKtn4_SrRtk6XXy4d83LlFV0= = new #=zKtn4_SrRtk6XXy4d83LlFV0=(this.#=z6bRJXNQ=);
				this.#=z4J_G3VM= += #=zKtn4_SrRtk6XXy4d83LlFV0=.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				if (#=zKtn4_SrRtk6XXy4d83LlFV0=.#=zFslVfpdTyVHi())
				{
					this.#=zdP$1bW4=(#=zKtn4_SrRtk6XXy4d83LlFV0=);
				}
				else if (#=zKtn4_SrRtk6XXy4d83LlFV0=.#=z0bYFz5k=())
				{
					stack.Push(#=zKtn4_SrRtk6XXy4d83LlFV0=);
				}
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zWIdvAhk=)
			{
				#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_ #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_ = new #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_(this.#=z6bRJXNQ=);
				this.#=z4J_G3VM= += #=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				this.#=zdP$1bW4=(#=zeIJ_22LF4iTwzl3_uiHJ20ny$xV_);
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zgIROC21YZTQqCTzn6i884to=)
			{
				#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q = new #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1(this.#=z6bRJXNQ=);
				this.#=z4J_G3VM= += #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				if (#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q.#=zZOFUOewkm7ea() != #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zk80xNLY=)
				{
					this.#=zdP$1bW4=(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q);
				}
				else
				{
					#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q.#=zb$ssayA=(this.#=zwGB7DOCdDCwf);
					#=zKtn4_SrRtk6XXy4d83LlFV0= #=zKtn4_SrRtk6XXy4d83LlFV0=2;
					if (stack.Count <= 0)
					{
						#=zKtn4_SrRtk6XXy4d83LlFV0=2 = new #=zKtn4_SrRtk6XXy4d83LlFV0=(this.#=z6bRJXNQ=);
					}
					else
					{
						#=zKtn4_SrRtk6XXy4d83LlFV0=2 = (#=zKtn4_SrRtk6XXy4d83LlFV0=)stack.Pop();
					}
					#=zKtn4_SrRtk6XXy4d83LlFV0=2.#=zVy1K$GX42gsg(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q);
					this.#=zwGB7DOCdDCwf.Push(#=zKtn4_SrRtk6XXy4d83LlFV0=2);
				}
			}
			else if (#=zwUe4tm5XLL76xe$ToMjBTwE= == #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zMK8dwE0VjgfQ)
			{
				#=zaEU5e8fIH09jC12g2axA$gvvF8By #=zaEU5e8fIH09jC12g2axA$gvvF8By = new #=zaEU5e8fIH09jC12g2axA$gvvF8By();
				this.#=z4J_G3VM= += #=zaEU5e8fIH09jC12g2axA$gvvF8By.#=zJjGe$TU=(this.#=zCMwF7nk=, this.#=z4J_G3VM=);
				Stack stack2 = this.#=zwGB7DOCdDCwf;
				this.#=zwGB7DOCdDCwf = new Stack();
				this.#=zqWkh9oica3zJ(#=zaEU5e8fIH09jC12g2axA$gvvF8By.#=zrHdsTiWu3oZX());
				#=zoImewjUBfkPyF1oU_G4atTk=[] array = new #=zoImewjUBfkPyF1oU_G4atTk=[this.#=zwGB7DOCdDCwf.Count];
				int num3 = 0;
				while (this.#=zwGB7DOCdDCwf.Count > 0)
				{
					array[num3] = (#=zoImewjUBfkPyF1oU_G4atTk=)this.#=zwGB7DOCdDCwf.Pop();
					num3++;
				}
				#=zaEU5e8fIH09jC12g2axA$gvvF8By.#=zLA7MgNl4ghKz(array);
				this.#=zwGB7DOCdDCwf = stack2;
				this.#=zwGB7DOCdDCwf.Push(#=zaEU5e8fIH09jC12g2axA$gvvF8By);
			}
		}
	}

	// Token: 0x06001044 RID: 4164 RVA: 0x0007D9E0 File Offset: 0x0007BBE0
	private void #=zdP$1bW4=(#=zrACqpkJvpkMu2ypmK4UXXdQ= #=zCTSet$w=)
	{
		#=zCTSet$w=.#=zb$ssayA=(this.#=zwGB7DOCdDCwf);
		this.#=zwGB7DOCdDCwf.Push(#=zCTSet$w=);
	}

	// Token: 0x06001045 RID: 4165 RVA: 0x0007D9FC File Offset: 0x0007BBFC
	public void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		this.#=zUQxuxX4=.#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
	}

	// Token: 0x06001046 RID: 4166 RVA: 0x0007DA0C File Offset: 0x0007BC0C
	public void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06001047 RID: 4167 RVA: 0x0007DA1C File Offset: 0x0007BC1C
	public void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06001048 RID: 4168 RVA: 0x0007DA2C File Offset: 0x0007BC2C
	public void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x06001049 RID: 4169 RVA: 0x0007DA3C File Offset: 0x0007BC3C
	public void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		this.#=zUQxuxX4=.#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
	}

	// Token: 0x040008E7 RID: 2279
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zc9TLR46Rk96PBThDLpIiZ1s62lIL));

	// Token: 0x040008E8 RID: 2280
	private sbyte[] #=zCMwF7nk=;

	// Token: 0x040008E9 RID: 2281
	private Cell #=zq07FqDs=;

	// Token: 0x040008EA RID: 2282
	private int #=z4J_G3VM=;

	// Token: 0x040008EB RID: 2283
	private #=zoImewjUBfkPyF1oU_G4atTk= #=zUQxuxX4=;

	// Token: 0x040008EC RID: 2284
	private Stack #=zwGB7DOCdDCwf;

	// Token: 0x040008ED RID: 2285
	private ExternalSheet #=zJY$tXiAJ_$AzbtOFtg==;

	// Token: 0x040008EE RID: 2286
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x040008EF RID: 2287
	private WorkbookSettings #=z6bRJXNQ=;
}
