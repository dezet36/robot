﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;

// Token: 0x0200012E RID: 302
internal sealed class #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==
{
	// Token: 0x0600076F RID: 1903 RVA: 0x0003D3A4 File Offset: 0x0003B5A4
	public #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zhoOF5s8=, int #=z0$tDJkI=)
	{
		this.#=zb87pU$r8o93u(#=zhoOF5s8=);
		this.#=z7sFyKMdSV8sU(new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>());
		this.#=zRgURr0PDCRpk(false);
		this.#=zJz$BeuY2bs5T(false);
		this.#=zrnhdUThpGANffM4yZw==(new List<string>());
		if (GameApplicationData.#=z7wsmjLWw49AC() == GameApplicationData.GameHosters.MyMail)
		{
			this.#=zniPhYP4=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876304));
		}
		this.#=zZjKvLhjJMNEz(#=z0$tDJkI=);
		this.#=zVn0b0PBG7G9QZAhLIwbeLLYXSFEb(0);
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x0003D414 File Offset: 0x0003B614
	public #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zh5Q$jgycqA15()
	{
		return this.#=zJs7cfn_SMDCu_edV$g==;
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x0003D41C File Offset: 0x0003B61C
	private void #=zb87pU$r8o93u(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=z$Ib9gYQ=)
	{
		this.#=zJs7cfn_SMDCu_edV$g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x0003D428 File Offset: 0x0003B628
	public string #=zCCBXDJ5n_DGghKXXmA==()
	{
		return this.#=zykGsrZJmqCXLHcuY6wu6ae$3pc8R;
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x0003D430 File Offset: 0x0003B630
	public void #=z9l$gimR8dkJhDCQJAw==(string #=z$Ib9gYQ=)
	{
		this.#=zykGsrZJmqCXLHcuY6wu6ae$3pc8R = #=z$Ib9gYQ=;
	}

	// Token: 0x06000774 RID: 1908 RVA: 0x0003D43C File Offset: 0x0003B63C
	public string #=zG96rwfOikL5q()
	{
		return this.#=zb18L3taWjCk7fMWAi$udOx8=;
	}

	// Token: 0x06000775 RID: 1909 RVA: 0x0003D444 File Offset: 0x0003B644
	public void #=zPzFoe9Yoa4Jh(string #=z$Ib9gYQ=)
	{
		this.#=zb18L3taWjCk7fMWAi$udOx8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000776 RID: 1910 RVA: 0x0003D450 File Offset: 0x0003B650
	public string #=zxSNRMjqS3yCO()
	{
		return this.#=zMMPTNHCCooti3jEqT6Piz0M=;
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0003D458 File Offset: 0x0003B658
	public void #=zchs2LGrZFGl4(string #=z$Ib9gYQ=)
	{
		this.#=zMMPTNHCCooti3jEqT6Piz0M= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x0003D464 File Offset: 0x0003B664
	public string #=zbfOGJA_8wt3H()
	{
		return this.#=zWc1UIOZJ5PmgFnozwA==;
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x0003D46C File Offset: 0x0003B66C
	public void #=zpVBlD$IJ4abR(string #=z$Ib9gYQ=)
	{
		this.#=zWc1UIOZJ5PmgFnozwA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600077A RID: 1914 RVA: 0x0003D478 File Offset: 0x0003B678
	public string #=zjWBl268nvo9O()
	{
		return this.#=zYAhDTIRU_6yBHTTppg==;
	}

	// Token: 0x0600077B RID: 1915 RVA: 0x0003D480 File Offset: 0x0003B680
	public void #=zVOkdnwLzxOWf(string #=z$Ib9gYQ=)
	{
		this.#=zYAhDTIRU_6yBHTTppg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600077C RID: 1916 RVA: 0x0003D48C File Offset: 0x0003B68C
	public string #=zSByqmFV12x0z()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070446), this.#=zbfOGJA_8wt3H(), this.#=zjWBl268nvo9O());
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x0003D4AC File Offset: 0x0003B6AC
	public string #=zUBdNbQEy4rFD()
	{
		return this.#=zusW6oIlXQ5kf;
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x0003D4B4 File Offset: 0x0003B6B4
	public void #=zhWr8WM11sNyG(string #=z$Ib9gYQ=)
	{
		this.#=zusW6oIlXQ5kf = #=z$Ib9gYQ=;
		if (this.#=zusW6oIlXQ5kf.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876542)))
		{
			this.#=zusW6oIlXQ5kf = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876535) + this.#=zusW6oIlXQ5kf;
		}
	}

	// Token: 0x0600077F RID: 1919 RVA: 0x0003D4F0 File Offset: 0x0003B6F0
	public string #=znOgAsLixEItF()
	{
		return this.#=zstAC$ao9brYrjuz$FQ==;
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x0003D4F8 File Offset: 0x0003B6F8
	public void #=zBFXSZ$Hu_V5Z(string #=z$Ib9gYQ=)
	{
		this.#=zstAC$ao9brYrjuz$FQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x0003D504 File Offset: 0x0003B704
	public string #=z$V9uwJPAniCv()
	{
		return this.#=zL_XkuI3WHV150ALrXQ==;
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x0003D50C File Offset: 0x0003B70C
	public void #=zZJbepNH_IDuQ(string #=z$Ib9gYQ=)
	{
		this.#=zL_XkuI3WHV150ALrXQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x0003D518 File Offset: 0x0003B718
	public string #=zBy_Rtgu6pzWv()
	{
		return this.#=z4K$pKNXYvbjUN8X2cA==;
	}

	// Token: 0x06000784 RID: 1924 RVA: 0x0003D520 File Offset: 0x0003B720
	public void #=zsFXnaqjXugcU(string #=z$Ib9gYQ=)
	{
		this.#=z4K$pKNXYvbjUN8X2cA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000785 RID: 1925 RVA: 0x0003D52C File Offset: 0x0003B72C
	public string #=zw3M1PzX18p_r()
	{
		return this.#=zWfpvD9BnR6bgDDqZfMa6$_I=;
	}

	// Token: 0x06000786 RID: 1926 RVA: 0x0003D534 File Offset: 0x0003B734
	public void #=zpeAmYAKx8nem(string #=z$Ib9gYQ=)
	{
		this.#=zWfpvD9BnR6bgDDqZfMa6$_I= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000787 RID: 1927 RVA: 0x0003D540 File Offset: 0x0003B740
	public string #=zg3LzOtbX7Rdo()
	{
		return this.#=z8YDSoaBGW8RcSPxx80lC1ug=;
	}

	// Token: 0x06000788 RID: 1928 RVA: 0x0003D548 File Offset: 0x0003B748
	public void #=zpo4eyll_HX97(string #=z$Ib9gYQ=)
	{
		this.#=z8YDSoaBGW8RcSPxx80lC1ug= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000789 RID: 1929 RVA: 0x0003D554 File Offset: 0x0003B754
	public string #=z9Yordw6ZFjQe()
	{
		return this.#=zh5Q$jgycqA15().#=zCCvotbi$42tS();
	}

	// Token: 0x0600078A RID: 1930 RVA: 0x0003D564 File Offset: 0x0003B764
	public List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zol80P7TKoihZ()
	{
		return this.#=zCmQ5j$D5xcC3kCQxVQ==;
	}

	// Token: 0x0600078B RID: 1931 RVA: 0x0003D56C File Offset: 0x0003B76C
	private void #=z7sFyKMdSV8sU(List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=z$Ib9gYQ=)
	{
		this.#=zCmQ5j$D5xcC3kCQxVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600078C RID: 1932 RVA: 0x0003D578 File Offset: 0x0003B778
	public List<string> #=z0I9lfENpa60boKog9g==()
	{
		return this.#=zxmNi1979NZDOEBeqIJAwJoo=;
	}

	// Token: 0x0600078D RID: 1933 RVA: 0x0003D580 File Offset: 0x0003B780
	private void #=zrnhdUThpGANffM4yZw==(List<string> #=z$Ib9gYQ=)
	{
		this.#=zxmNi1979NZDOEBeqIJAwJoo= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600078E RID: 1934 RVA: 0x0003D58C File Offset: 0x0003B78C
	public int #=z5KSZXEKT20zU()
	{
		return this.#=zinVdXe6Bwhzli8ikUg==;
	}

	// Token: 0x0600078F RID: 1935 RVA: 0x0003D594 File Offset: 0x0003B794
	public void #=zZjKvLhjJMNEz(int #=z$Ib9gYQ=)
	{
		this.#=zinVdXe6Bwhzli8ikUg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000790 RID: 1936 RVA: 0x0003D5A0 File Offset: 0x0003B7A0
	public int #=z2ZE0cltcIoE3IY7EAQ==()
	{
		return this.#=z5KSZXEKT20zU() + 1;
	}

	// Token: 0x06000791 RID: 1937 RVA: 0x0003D5AC File Offset: 0x0003B7AC
	public void #=zy_08NmbJwFOpcdclQw==(int #=z$Ib9gYQ=)
	{
		this.#=zZjKvLhjJMNEz(#=z$Ib9gYQ= - 1);
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x0003D5B8 File Offset: 0x0003B7B8
	public int #=zTvv00UNStlgLec8wAKQUeKGOQNz3()
	{
		return this.#=zG_CnTnJ28RHO0sqkFYrXmgOPQpLEZNaCQQ==;
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x0003D5C0 File Offset: 0x0003B7C0
	public void #=zVn0b0PBG7G9QZAhLIwbeLLYXSFEb(int #=z$Ib9gYQ=)
	{
		this.#=zG_CnTnJ28RHO0sqkFYrXmgOPQpLEZNaCQQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x0003D5CC File Offset: 0x0003B7CC
	public bool #=zJO5XMrsPugGq()
	{
		if (this.#=z$kkAC8YSPjrH && DateTime.Now >= this.#=zwiAqM3aNHwss)
		{
			this.#=z$kkAC8YSPjrH = false;
		}
		return this.#=z$kkAC8YSPjrH;
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0003D5F8 File Offset: 0x0003B7F8
	public void #=zRgURr0PDCRpk(bool #=z$Ib9gYQ=)
	{
		this.#=z$kkAC8YSPjrH = #=z$Ib9gYQ=;
		if (#=z$Ib9gYQ=)
		{
			this.#=zwiAqM3aNHwss = DateTime.Now + TimeSpan.FromMinutes(7.0);
		}
	}

	// Token: 0x06000796 RID: 1942 RVA: 0x0003D624 File Offset: 0x0003B824
	public bool #=zObGzldk_Y5$c()
	{
		return !string.IsNullOrEmpty(this.#=zG96rwfOikL5q());
	}

	// Token: 0x06000797 RID: 1943 RVA: 0x0003D634 File Offset: 0x0003B834
	public bool #=zhOb_1T8Tx25V()
	{
		if (this.#=zD36p2AdVsgJ6 && DateTime.Now >= this.#=zGrRJUyFOZcAGFT_o9A==)
		{
			this.#=zD36p2AdVsgJ6 = false;
		}
		return this.#=zD36p2AdVsgJ6;
	}

	// Token: 0x06000798 RID: 1944 RVA: 0x0003D660 File Offset: 0x0003B860
	public void #=zJz$BeuY2bs5T(bool #=z$Ib9gYQ=)
	{
		this.#=zD36p2AdVsgJ6 = #=z$Ib9gYQ=;
		if (#=z$Ib9gYQ=)
		{
			double value;
			switch (this.#=zrSnzA6iUU18S)
			{
			case 0:
				value = 1.0;
				break;
			case 1:
				value = 2.0;
				break;
			case 2:
				value = 3.0;
				break;
			case 3:
				value = 6.0;
				break;
			case 4:
				value = 12.0;
				break;
			default:
				value = 72.0;
				break;
			}
			this.#=zGrRJUyFOZcAGFT_o9A== = DateTime.Now + TimeSpan.FromHours(value);
			this.#=zrSnzA6iUU18S++;
			return;
		}
		this.#=zrSnzA6iUU18S = 0;
	}

	// Token: 0x06000799 RID: 1945 RVA: 0x0003D710 File Offset: 0x0003B910
	public void #=zPTupsH$DyeN5(DateTime #=zYMNSoNFx5mMf)
	{
		this.#=zD36p2AdVsgJ6 = true;
		this.#=zGrRJUyFOZcAGFT_o9A== = #=zYMNSoNFx5mMf;
		this.#=zrSnzA6iUU18S++;
	}

	// Token: 0x0600079A RID: 1946 RVA: 0x0003D730 File Offset: 0x0003B930
	public void #=z_CMx39SmGb4B(bool #=zec4cIRRcWlOt)
	{
		if (#=zec4cIRRcWlOt || !string.IsNullOrEmpty(this.#=zG96rwfOikL5q()))
		{
			int num = this.#=zTvv00UNStlgLec8wAKQUeKGOQNz3();
			this.#=zVn0b0PBG7G9QZAhLIwbeLLYXSFEb(num + 1);
		}
		if (#=zec4cIRRcWlOt)
		{
			this.#=zBFXSZ$Hu_V5Z(null);
		}
		this.#=zPzFoe9Yoa4Jh(null);
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0003D770 File Offset: 0x0003B970
	public void #=zWpG0NaGTW6ZT()
	{
		this.#=zPzFoe9Yoa4Jh(null);
	}

	// Token: 0x0600079C RID: 1948 RVA: 0x0003D77C File Offset: 0x0003B97C
	public bool #=zuR5zw_sJCTHxOMTEFqrQXeg=()
	{
		return this.#=zdphl9OEY6L9f74kgB0t3k90t38ZO;
	}

	// Token: 0x0600079D RID: 1949 RVA: 0x0003D784 File Offset: 0x0003B984
	public void #=zRLeFQtMdiDrAX8$cReiX0f4=(bool #=z$Ib9gYQ=)
	{
		this.#=zdphl9OEY6L9f74kgB0t3k90t38ZO = #=z$Ib9gYQ=;
	}

	// Token: 0x0600079E RID: 1950 RVA: 0x0003D790 File Offset: 0x0003B990
	public void #=zNmZpyTRuIxka(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, LogTypes #=zvRLj9WQ=, string #=zx9NCziM=, object[] #=zlP66l7Q4Pzmc)
	{
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zol80P7TKoihZ())
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z48rEd0A=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(#=zG2wnL_q7IxpD, #=zvRLj9WQ=, #=zx9NCziM=, #=zlP66l7Q4Pzmc));
		}
	}

	// Token: 0x0600079F RID: 1951 RVA: 0x0003D7F0 File Offset: 0x0003B9F0
	public void #=zniPhYP4=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zEbj_$wr_awLH)
	{
		this.#=zniPhYP4=(#=zEbj_$wr_awLH.#=zCCBXDJ5n_DGghKXXmA==());
	}

	// Token: 0x060007A0 RID: 1952 RVA: 0x0003D800 File Offset: 0x0003BA00
	public void #=zniPhYP4=(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=zEbj_$wr_awLH)
	{
		this.#=zniPhYP4=(#=zEbj_$wr_awLH.#=zsmHAU_GQ9ylR());
	}

	// Token: 0x060007A1 RID: 1953 RVA: 0x0003D810 File Offset: 0x0003BA10
	public void #=zniPhYP4=(string #=zthZn3mixvx1u)
	{
		if (string.IsNullOrEmpty(#=zthZn3mixvx1u))
		{
			return;
		}
		if (this.#=zCCBXDJ5n_DGghKXXmA==() != null && #=zthZn3mixvx1u.EndsWith(this.#=zCCBXDJ5n_DGghKXXmA==()))
		{
			return;
		}
		if (!#=zthZn3mixvx1u.StartsWith(GameApplicationData.#=z0Jq5DpdI2gB$()))
		{
			#=zthZn3mixvx1u = GameApplicationData.#=z0Jq5DpdI2gB$() + #=zthZn3mixvx1u;
		}
		object obj = this.#=zJ$oXZmdtyOrY;
		lock (obj)
		{
			if (!this.#=z0I9lfENpa60boKog9g==().Contains(#=zthZn3mixvx1u))
			{
				this.#=z0I9lfENpa60boKog9g==().Add(#=zthZn3mixvx1u);
			}
		}
	}

	// Token: 0x060007A2 RID: 1954 RVA: 0x0003D8A4 File Offset: 0x0003BAA4
	public void #=zUvrxU4BElRg_WEPM3Q==()
	{
		string[] array = null;
		GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
		if (gameHosters != GameApplicationData.GameHosters.MyMail)
		{
			if (gameHosters != GameApplicationData.GameHosters.PlariumRu)
			{
				if (gameHosters == GameApplicationData.GameHosters.PlariumEn)
				{
					array = new string[]
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877388),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877375),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877358),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877337),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877320),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877563),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877546),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877541),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877524),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877511),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877494),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877473),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877456),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877443),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877170),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877165),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877148),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877135),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877118),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877097),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877080),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877067),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877306),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877301),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877284),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877271),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877254),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877233),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877216),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877203),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877186),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876925),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876908),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876895),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876878),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876857),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876840),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876827),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876810),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876805),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877044),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877031),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877014),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876993),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876976),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876963),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876946),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876941),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862332),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862319)
					};
				}
			}
			else
			{
				array = new string[]
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877388),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877375),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877358),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877337),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877320),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877563),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877546),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877541),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877524),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877511),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877494),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877473),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877456),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877443),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877170),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877165),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877148),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877135),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877118),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877097),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877080),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877067),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877306),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877301),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877284),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877271),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877254),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877233),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877216),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877203),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877186),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876925),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876908),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876895),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876878),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876857),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876840),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876827),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876810),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876805),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877044),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877031),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877014),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876993),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876976),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876963),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876946),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876941),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862332),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862319)
				};
			}
		}
		else
		{
			array = new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876512),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876494),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876469),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876432),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876158),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876133),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876096),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876079),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876053),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876275),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876254),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876229),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876204),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876171),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875889),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875870),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875845),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875808),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875790),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876021),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875984),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875967),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875930),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875905),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877679),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877652),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877619),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877592),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877575),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877805),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877771),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877750),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877725),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877434),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877409)
			};
		}
		if (array != null)
		{
			foreach (string #=zthZn3mixvx1u in array)
			{
				if (this.#=z0I9lfENpa60boKog9g==().Count >= 35)
				{
					break;
				}
				this.#=zniPhYP4=(#=zthZn3mixvx1u);
			}
		}
	}

	// Token: 0x0400046D RID: 1133
	private #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zJs7cfn_SMDCu_edV$g==;

	// Token: 0x0400046E RID: 1134
	private string #=zykGsrZJmqCXLHcuY6wu6ae$3pc8R;

	// Token: 0x0400046F RID: 1135
	private string #=zb18L3taWjCk7fMWAi$udOx8=;

	// Token: 0x04000470 RID: 1136
	private string #=zMMPTNHCCooti3jEqT6Piz0M=;

	// Token: 0x04000471 RID: 1137
	private string #=zWc1UIOZJ5PmgFnozwA==;

	// Token: 0x04000472 RID: 1138
	private string #=zYAhDTIRU_6yBHTTppg==;

	// Token: 0x04000473 RID: 1139
	private string #=zusW6oIlXQ5kf;

	// Token: 0x04000474 RID: 1140
	private string #=zstAC$ao9brYrjuz$FQ==;

	// Token: 0x04000475 RID: 1141
	private string #=zL_XkuI3WHV150ALrXQ==;

	// Token: 0x04000476 RID: 1142
	private string #=z4K$pKNXYvbjUN8X2cA==;

	// Token: 0x04000477 RID: 1143
	private string #=zWfpvD9BnR6bgDDqZfMa6$_I=;

	// Token: 0x04000478 RID: 1144
	private string #=z8YDSoaBGW8RcSPxx80lC1ug=;

	// Token: 0x04000479 RID: 1145
	private List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zCmQ5j$D5xcC3kCQxVQ==;

	// Token: 0x0400047A RID: 1146
	private List<string> #=zxmNi1979NZDOEBeqIJAwJoo=;

	// Token: 0x0400047B RID: 1147
	private int #=zinVdXe6Bwhzli8ikUg==;

	// Token: 0x0400047C RID: 1148
	private int #=zG_CnTnJ28RHO0sqkFYrXmgOPQpLEZNaCQQ==;

	// Token: 0x0400047D RID: 1149
	public object #=zJ$oXZmdtyOrY = new object();

	// Token: 0x0400047E RID: 1150
	private bool #=z$kkAC8YSPjrH;

	// Token: 0x0400047F RID: 1151
	private DateTime #=zwiAqM3aNHwss;

	// Token: 0x04000480 RID: 1152
	private bool #=zD36p2AdVsgJ6;

	// Token: 0x04000481 RID: 1153
	private int #=zrSnzA6iUU18S;

	// Token: 0x04000482 RID: 1154
	private DateTime #=zGrRJUyFOZcAGFT_o9A==;

	// Token: 0x04000483 RID: 1155
	private bool #=zdphl9OEY6L9f74kgB0t3k90t38ZO;
}
