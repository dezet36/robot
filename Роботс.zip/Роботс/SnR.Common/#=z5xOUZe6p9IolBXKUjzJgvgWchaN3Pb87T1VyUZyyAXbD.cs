﻿using System;

// Token: 0x02000077 RID: 119
internal sealed class #=z5xOUZe6p9IolBXKUjzJgvgWchaN3Pb87T1VyUZyyAXbD : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000360 RID: 864 RVA: 0x0001EFD4 File Offset: 0x0001D1D4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
	}

	// Token: 0x06000361 RID: 865 RVA: 0x0001EFE4 File Offset: 0x0001D1E4
	protected override void #=zvb5bnug=()
	{
		#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = null;
		foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 in this.#=z1pahAF0JqdFM8mgjDQ==)
		{
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFMDiymuLQ7_4() == 800)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zO6457TajDDxDJIsKqS1bbzDMLckn2;
				break;
			}
		}
		if (#=zO6457TajDDxDJIsKqS1bbzDMLckn != null && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().UpgradeHermesMaxLevel && !#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z5kpAZQpjT2b7())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962169), new object[]
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1
			});
			string text = this.#=zBsXSanI=.#=zgMfGw_J9m6OAub_Oqw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962133), new object[]
				{
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908962087), new object[]
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1,
				text
			});
		}
	}

	// Token: 0x04000130 RID: 304
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;
}
