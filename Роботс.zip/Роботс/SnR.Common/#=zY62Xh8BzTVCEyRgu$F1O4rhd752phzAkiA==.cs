﻿using System;
using System.Collections.Generic;

// Token: 0x020001D8 RID: 472
internal sealed class #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==
{
	// Token: 0x06000E41 RID: 3649 RVA: 0x00071F34 File Offset: 0x00070134
	public #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==()
	{
		this.#=zPlIhfsI= = new Dictionary<string, #=zFK1EpQeH6KJD0Ki59YPGY91j162R>();
	}

	// Token: 0x06000E42 RID: 3650 RVA: 0x00071F48 File Offset: 0x00070148
	public int #=zKh04cf8=()
	{
		return this.#=zPlIhfsI=.Count;
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x00071F58 File Offset: 0x00070158
	public void #=z48rEd0A=(#=zFK1EpQeH6KJD0Ki59YPGY91j162R #=zycxjQhk=)
	{
		this.#=zPlIhfsI=[#=zycxjQhk=.#=zrsHDyhs=] = #=zycxjQhk=;
	}

	// Token: 0x06000E44 RID: 3652 RVA: 0x00071F6C File Offset: 0x0007016C
	public void #=zghsJ8VM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z88V33U9I4DoN)
	{
		foreach (#=zFK1EpQeH6KJD0Ki59YPGY91j162R #=zFK1EpQeH6KJD0Ki59YPGY91j162R in #=z88V33U9I4DoN.#=zPlIhfsI=.Values)
		{
			this.#=zPlIhfsI=[#=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zrsHDyhs=] = #=zFK1EpQeH6KJD0Ki59YPGY91j162R;
		}
	}

	// Token: 0x06000E45 RID: 3653 RVA: 0x00071FD0 File Offset: 0x000701D0
	public Dictionary<string, #=zFK1EpQeH6KJD0Ki59YPGY91j162R> #=ztjK2jmKh1KjY()
	{
		return this.#=zPlIhfsI=;
	}

	// Token: 0x06000E46 RID: 3654 RVA: 0x00071FD8 File Offset: 0x000701D8
	public List<#=zFK1EpQeH6KJD0Ki59YPGY91j162R> #=zNyDVWg8=()
	{
		List<#=zFK1EpQeH6KJD0Ki59YPGY91j162R> list = new List<#=zFK1EpQeH6KJD0Ki59YPGY91j162R>();
		foreach (#=zFK1EpQeH6KJD0Ki59YPGY91j162R item in this.#=zPlIhfsI=.Values)
		{
			list.Add(item);
		}
		return list;
	}

	// Token: 0x040007F5 RID: 2037
	private Dictionary<string, #=zFK1EpQeH6KJD0Ki59YPGY91j162R> #=zPlIhfsI=;
}
