﻿using System;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;
using NExcel.Read.Biff;

// Token: 0x020001BE RID: 446
internal sealed class #=zVXBfuY4zvMANDSH8k_VnXPmMVn$_ : CellValue, ErrorCell, Cell, FormulaData, ErrorFormulaCell, FormulaCell
{
	// Token: 0x06000D4C RID: 3404 RVA: 0x00068654 File Offset: 0x00066854
	public #=zVXBfuY4zvMANDSH8k_VnXPmMVn$_(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		this.#=z$qdebj6dfyrP = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
		this.#=zJ5GWysk= = this.getRecord().Data;
		Assert.verify(this.#=zJ5GWysk=[6] == 2);
		this.#=zwemACYQ= = (int)this.#=zJ5GWysk=[8];
	}

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x06000D4D RID: 3405 RVA: 0x000686AC File Offset: 0x000668AC
	public int ErrorCode
	{
		get
		{
			return this.#=zwemACYQ=;
		}
	}

	// Token: 0x1700003A RID: 58
	// (get) Token: 0x06000D4E RID: 3406 RVA: 0x000686B4 File Offset: 0x000668B4
	public new string Contents
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068262) + this.#=zwemACYQ=.ToString();
		}
	}

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x06000D4F RID: 3407 RVA: 0x000686D0 File Offset: 0x000668D0
	public new CellType Type
	{
		get
		{
			return CellType.FORMULA_ERROR;
		}
	}

	// Token: 0x1700003C RID: 60
	// (get) Token: 0x06000D50 RID: 3408 RVA: 0x000686D8 File Offset: 0x000668D8
	public string Formula
	{
		get
		{
			if (this.#=z06z1muCn8UNxP0yekw== == null)
			{
				sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 22];
				Array.Copy(this.#=zJ5GWysk=, 22, array, 0, array.Length);
				FormulaParser formulaParser = new FormulaParser(array, this, this.#=z$qdebj6dfyrP, this.#=zLJGAifU=, this.Sheet.#=znmG_kF0igveL8fwbqw==().Settings);
				formulaParser.parse();
				this.#=z06z1muCn8UNxP0yekw== = formulaParser.Formula;
			}
			return this.#=z06z1muCn8UNxP0yekw==;
		}
	}

	// Token: 0x06000D51 RID: 3409 RVA: 0x0006874C File Offset: 0x0006694C
	public sbyte[] getFormulaData()
	{
		sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 6];
		Array.Copy(this.#=zJ5GWysk=, 6, array, 0, this.#=zJ5GWysk=.Length - 6);
		return array;
	}

	// Token: 0x040007A7 RID: 1959
	private int #=zwemACYQ=;

	// Token: 0x040007A8 RID: 1960
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x040007A9 RID: 1961
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x040007AA RID: 1962
	private string #=z06z1muCn8UNxP0yekw==;

	// Token: 0x040007AB RID: 1963
	private sbyte[] #=zJ5GWysk=;
}
