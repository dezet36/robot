﻿using System;
using System.Security.Cryptography;
using System.Text;

// Token: 0x020000E6 RID: 230
internal sealed class #=zEUBS1i3F2YjLKP$jPmnwi_fM9U4u
{
	// Token: 0x06000615 RID: 1557 RVA: 0x00031904 File Offset: 0x0002FB04
	public static string #=zoFZMcJzdKf_O(string #=zbQH8$K1oK6N5, bool #=zw1Hf3YsXEhBf)
	{
		if (#=zw1Hf3YsXEhBf)
		{
			#=zbQH8$K1oK6N5 = #=zbQH8$K1oK6N5.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070282), string.Empty).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944448), string.Empty).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051860), string.Empty).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031), string.Empty);
		}
		HashAlgorithm hashAlgorithm = new MD5CryptoServiceProvider();
		byte[] bytes = Encoding.UTF8.GetBytes(#=zbQH8$K1oK6N5);
		byte[] array = hashAlgorithm.ComputeHash(bytes);
		StringBuilder stringBuilder = new StringBuilder();
		foreach (byte b in array)
		{
			stringBuilder.Append(b.ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944440)).ToLower());
		}
		return stringBuilder.ToString();
	}
}
