﻿using System;
using System.Globalization;

// Token: 0x020001E7 RID: 487
internal static class #=zYoOaqJq4B7Cs4WSCE_Ah3tPG2YcA6zoN2KBtT2_yjTwb
{
	// Token: 0x06000EBC RID: 3772 RVA: 0x000762E8 File Offset: 0x000744E8
	private static bool #=zpnytNcGjwgepdY48WIsiXZk=(bool #=zm8PpuDU=)
	{
		DateTime t = DateTime.Parse(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076242), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
		DateTime utcNow = DateTime.UtcNow;
		if (utcNow > t || utcNow < t.AddDays(-12345671000.0))
		{
			string name = typeof(#=zYoOaqJq4B7Cs4WSCE_Ah3tPG2YcA6zoN2KBtT2_yjTwb).Assembly.GetName().Name;
			string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074881), name);
			return true;
		}
		return true;
	}

	// Token: 0x06000EBD RID: 3773 RVA: 0x00076364 File Offset: 0x00074564
	public static bool #=zu4gHUnA=()
	{
		return #=zYoOaqJq4B7Cs4WSCE_Ah3tPG2YcA6zoN2KBtT2_yjTwb.#=zpnytNcGjwgepdY48WIsiXZk=(false);
	}

	// Token: 0x06000EBE RID: 3774 RVA: 0x0007636C File Offset: 0x0007456C
	public static void #=zJX82GlMOip55()
	{
		#=zYoOaqJq4B7Cs4WSCE_Ah3tPG2YcA6zoN2KBtT2_yjTwb.#=zpnytNcGjwgepdY48WIsiXZk=(true);
	}
}
