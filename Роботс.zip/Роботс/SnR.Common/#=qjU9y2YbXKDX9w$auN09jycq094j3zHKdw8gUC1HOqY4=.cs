﻿using System;

// Token: 0x02000019 RID: 25
internal interface #=qjU9y2YbXKDX9w$auN09jycq094j3zHKdw8gUC1HOqY4=
{
	// Token: 0x0600004D RID: 77
	void #=zXVKTZd7T7qKoxpenUPk6ayEmbY9Om$Ec7B0m5cxARitAbwiE$vtsuXxtRawok0wSkgFZdAWmmx0E0NaW5WbdhqXhg0lr();
}
