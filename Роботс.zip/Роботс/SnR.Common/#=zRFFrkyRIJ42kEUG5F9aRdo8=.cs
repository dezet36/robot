﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Format;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x02000190 RID: 400
internal sealed class #=zRFFrkyRIJ42kEUG5F9aRdo8= : NumberCell, Cell
{
	// Token: 0x06000B6B RID: 2923 RVA: 0x00057B30 File Offset: 0x00055D30
	public #=zRFFrkyRIJ42kEUG5F9aRdo8=(int #=zihyUFzs=, int #=zQUn_5_A=, double #=ze7ZtytQ=, int #=zPZu1Eq8=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=)
	{
		this.#=zg9A8_dw= = #=zihyUFzs=;
		this.#=zEh1wLVk= = #=zQUn_5_A=;
		this.#=zaiKvawI= = #=ze7ZtytQ=;
		this.#=zL0TJcHA= = #=zRFFrkyRIJ42kEUG5F9aRdo8=.#=zk9NtXlk=;
		this.#=zJqpM8PY= = #=zPZu1Eq8=;
		this.#=zwKQa9tCrbbw$ = #=zrRXQAB8=;
		this.#=zNEZ0SGey$A9J = #=z99eVqbg=;
		this.#=zQqR9G48= = false;
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000B6D RID: 2925 RVA: 0x00057B9C File Offset: 0x00055D9C
	public int Row
	{
		get
		{
			return this.#=zg9A8_dw=;
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000B6E RID: 2926 RVA: 0x00057BA4 File Offset: 0x00055DA4
	public int Column
	{
		get
		{
			return this.#=zEh1wLVk=;
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000B6F RID: 2927 RVA: 0x00057BAC File Offset: 0x00055DAC
	public double DoubleValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x06000B70 RID: 2928 RVA: 0x00057BB4 File Offset: 0x00055DB4
	public object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x06000B71 RID: 2929 RVA: 0x00057BC4 File Offset: 0x00055DC4
	public string Contents
	{
		get
		{
			return string.Format(this.#=zL0TJcHA=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zaiKvawI=);
		}
	}

	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000B72 RID: 2930 RVA: 0x00057BE8 File Offset: 0x00055DE8
	public CellType Type
	{
		get
		{
			return CellType.NUMBER;
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x06000B73 RID: 2931 RVA: 0x00057BF0 File Offset: 0x00055DF0
	public NExcel.Format.CellFormat CellFormat
	{
		get
		{
			if (!this.#=zQqR9G48=)
			{
				this.#=zz4pSDjg= = this.#=zwKQa9tCrbbw$.getXFRecord(this.#=zJqpM8PY=);
				this.#=zQqR9G48= = true;
			}
			return this.#=zz4pSDjg=;
		}
	}

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x06000B74 RID: 2932 RVA: 0x00057C20 File Offset: 0x00055E20
	public bool Hidden
	{
		get
		{
			ColumnInfoRecord columnInfo = this.#=zNEZ0SGey$A9J.getColumnInfo(this.#=zEh1wLVk=);
			if (columnInfo != null && columnInfo.Width == 0)
			{
				return true;
			}
			RowRecord rowRecord = this.#=zNEZ0SGey$A9J.#=zSzfF9oQ=(this.#=zg9A8_dw=);
			return rowRecord != null && (rowRecord.RowHeight == 0 || rowRecord.isCollapsed());
		}
	}

	// Token: 0x06000B75 RID: 2933 RVA: 0x00057C74 File Offset: 0x00055E74
	internal void #=z_6Yn4EGfIqYe(NumberFormatInfo #=zTRA8u0c=)
	{
		if (#=zTRA8u0c= != null)
		{
			this.#=zL0TJcHA= = #=zTRA8u0c=;
		}
	}

	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000B76 RID: 2934 RVA: 0x00057C80 File Offset: 0x00055E80
	public NumberFormatInfo NumberFormat
	{
		get
		{
			return this.#=zL0TJcHA=;
		}
	}

	// Token: 0x04000627 RID: 1575
	private int #=zg9A8_dw=;

	// Token: 0x04000628 RID: 1576
	private int #=zEh1wLVk=;

	// Token: 0x04000629 RID: 1577
	private double #=zaiKvawI=;

	// Token: 0x0400062A RID: 1578
	private NumberFormatInfo #=zL0TJcHA=;

	// Token: 0x0400062B RID: 1579
	private NExcel.Format.CellFormat #=zz4pSDjg=;

	// Token: 0x0400062C RID: 1580
	private int #=zJqpM8PY=;

	// Token: 0x0400062D RID: 1581
	private FormattingRecords #=zwKQa9tCrbbw$;

	// Token: 0x0400062E RID: 1582
	private bool #=zQqR9G48=;

	// Token: 0x0400062F RID: 1583
	private SheetImpl #=zNEZ0SGey$A9J;

	// Token: 0x04000630 RID: 1584
	private static NumberFormatInfo #=zk9NtXlk= = new NumberFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077254));
}
