﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;

// Token: 0x0200006A RID: 106
internal sealed class #=z4D$ECR7YZvHgryv3YAxotORKEv4IvQ9qHs5rS3Bgcbpv1YA$VslIQRE= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600030F RID: 783 RVA: 0x0001C6A0 File Offset: 0x0001A8A0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zbkd1_SL26Bt5 = #=zuJjQ1XU=.#=zTbkv095gWozyg_xVnw==();
		this.#=zkTFDbK1WLBVA = #=zuJjQ1XU=.#=zuMXv8DnEbNVrFpFzVw==();
		this.#=znmyDeS0OacNZwPmJ6YZ$l6Y= = #=zuJjQ1XU=.#=zIQDLqtJxqgZWX88MoNdeTR0k5rMf();
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=zY5j036GBN4QD = new #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE=(this.#=z8StzeqE=, #=zuJjQ1XU=);
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode > 0)
		{
			this.#=zZKzdsPms7IDM = new #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=(this.#=z8StzeqE=, #=zuJjQ1XU=);
		}
	}

	// Token: 0x06000310 RID: 784 RVA: 0x0001C72C File Offset: 0x0001A92C
	protected override void #=zvb5bnug=()
	{
		#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A== #=zoXiLUP8= = new #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A==(this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA);
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960404));
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960397));
		TimeSpan timeSpan = TimeSpan.MaxValue;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsResearchTechs)
		{
			#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zY8OsuiRtmAK$ = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
			this.#=z3RGYHFG$tXPH1DnrapnNpK8=(#=zY8OsuiRtmAK$);
			string #=zQtK9D3Etaxd_;
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = this.#=zbEs1qG1UHSl_SajRO2LP4nI=(#=zY8OsuiRtmAK$, #=zoXiLUP8=, out #=zQtK9D3Etaxd_);
			if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== != null)
			{
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode > 0)
				{
					base.#=zL1HTbwC75LO$(#=zQtK9D3Etaxd_);
				}
				else
				{
					timeSpan = #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=zwX6NTlM=(1);
				}
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeTechs)
		{
			string #=zQtK9D3Etaxd_2;
			#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = this.#=z_XgeVm1QuF5E(#=zoXiLUP8=, out #=zQtK9D3Etaxd_2);
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null)
			{
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode > 0)
				{
					base.#=zL1HTbwC75LO$(#=zQtK9D3Etaxd_2);
				}
				else
				{
					timeSpan = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().#=zwX6NTlM=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1);
				}
			}
		}
		if (this.#=zZKzdsPms7IDM != null)
		{
			timeSpan = TimeSpan.FromSeconds((double)this.#=zZKzdsPms7IDM.#=zbz5V76FSfPgyn3Ty$g==(this.#=zJF2YTStZkxdpBvijgveKmkY=));
		}
		if (timeSpan < this.#=zcDRV51Ut$7oP.RepeatDelayMax)
		{
			this.#=zcDRV51Ut$7oP.NextExecutionTime = DateTime.Now + timeSpan + TimeSpan.FromSeconds(180.0);
		}
	}

	// Token: 0x06000311 RID: 785 RVA: 0x0001C888 File Offset: 0x0001AA88
	private void #=z3RGYHFG$tXPH1DnrapnNpK8=(#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zY8OsuiRtmAK$)
	{
		#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== = this.#=zJF2YTStZkxdpBvijgveKmkY=;
		#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= = this.#=zbkd1_SL26Bt5;
		#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = null;
		for (int i = 0; i < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechBuyForGloryIds.Count; i++)
		{
			int num = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechBuyForGloryIds[i];
			bool flag = false;
			using (List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>.Enumerator enumerator = #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.#=zMuFMjGQ=() == num)
					{
						flag = true;
						break;
					}
				}
			}
			if (!flag)
			{
				#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 = null;
				foreach (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3 in #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=)
				{
					if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3.#=zq2bPTdY=().Id == num)
					{
						#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==3;
						break;
					}
				}
				if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 == null)
				{
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 = new #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==();
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=zzQwUIEs=(#=zY8OsuiRtmAK$.#=zk$6QZNA=(num));
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=z9cbTL9Fte7ios6efTw==(new Dictionary<int, int>());
				}
				if (!#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=z_ePdViDI7p1r5Oy9Eg==())
				{
					if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=zq2bPTdY=().#=z6ZIr13K_h_d4() * GameApplicationData.#=zZP$yVdxrXoWp3tYZivezbYlEzmGc() <= this.#=z3yL5bKs=[ResourceTypes.Glory])
					{
						#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2;
						break;
					}
					break;
				}
			}
		}
		if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== != null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960122), new object[]
			{
				#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().Name
			});
			for (int j = 0; j < #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().#=z6ZIr13K_h_d4(); j++)
			{
				if (!#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(j))
				{
					string text = this.#=zBsXSanI=.#=zjIOixtU6nn$Kt5RoUw==(#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=(), j);
					text = text.Trim();
					if (text.Length < 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924322), new object[]
						{
							#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().Name,
							text
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924370), new object[]
						{
							#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=().Name,
							j + 1
						});
					}
				}
			}
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960054), Array.Empty<object>());
	}

	// Token: 0x06000312 RID: 786 RVA: 0x0001CB08 File Offset: 0x0001AD08
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zbEs1qG1UHSl_SajRO2LP4nI=(#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zY8OsuiRtmAK$, #=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A== #=zoXiLUP8=, out string #=zIapFsKF23kqB)
	{
		#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== result = null;
		#=zIapFsKF23kqB = null;
		#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== = this.#=zJF2YTStZkxdpBvijgveKmkY=;
		#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= = this.#=zbkd1_SL26Bt5;
		List<#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==> list = new List<#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==>();
		foreach (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== in #=zY8OsuiRtmAK$)
		{
			if (!#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.IsHidden)
			{
				bool flag = false;
				using (List<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>.Enumerator enumerator2 = #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==.GetEnumerator())
				{
					while (enumerator2.MoveNext())
					{
						if (enumerator2.Current.#=zMuFMjGQ=() == #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id)
						{
							flag = true;
							break;
						}
					}
				}
				if (!flag && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Get(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id).IsResearch && #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==, 1, this.#=z8StzeqE=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA))
				{
					if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.#=z6ZIr13K_h_d4() == 0)
					{
						list.Add(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
					}
					else
					{
						#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = null;
						foreach (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2 in #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=)
						{
							if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2.#=zq2bPTdY=().Id == #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id)
							{
								#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==2;
								break;
							}
						}
						if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== != null && #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=z_ePdViDI7p1r5Oy9Eg==())
						{
							list.Add(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
						}
					}
				}
			}
		}
		int num = 5;
		for (int i = 0; i < list.Count; i++)
		{
			#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2 = list[i];
			if (#=zoXiLUP8=.#=z0vSd8LyXizI7(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2))
			{
				if (!this.#=z8StzeqE=.#=zkXsxKS4OL0sN(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.RequireResources(1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960404), this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForResearch))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960193), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name
					});
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.RequireResources(1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960404));
				}
				else
				{
					if (num-- <= 0)
					{
						break;
					}
					#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== #=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== = this.#=zY5j036GBN4QD.#=zAXaL0AbspmvA(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2, 1, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForResearch, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyResPackIfNoResForResearch);
					if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq().Count > 0)
					{
						if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zfYEVQUtPgwVj0BONZA==().Count == 0)
						{
							string text = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960404));
							if (!string.IsNullOrEmpty(text))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960143), new object[]
								{
									#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name,
									text
								});
							}
						}
					}
					else
					{
						string text2 = this.#=zBsXSanI=.#=z20Op8NOLzKmH5WBHiP4ZLPs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2, false);
						text2 = text2.Trim();
						if (text2.Length >= 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969259), new object[]
							{
								#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name
							});
							#=zoXiLUP8=.#=zR__3$vI=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2);
							string text3 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960404));
							if (!string.IsNullOrEmpty(text3))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961644), new object[]
								{
									text3
								});
							}
							result = #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2;
							#=zIapFsKF23kqB = text2;
							break;
						}
						if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959811), new object[]
							{
								#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name
							});
						}
						else
						{
							if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959982), new object[]
								{
									#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name
								});
								#=zoXiLUP8=.#=zR__3$vI=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2);
								break;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959896), new object[]
							{
								#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.Name,
								text2
							});
						}
					}
				}
			}
		}
		return result;
	}

	// Token: 0x06000313 RID: 787 RVA: 0x0001CFB0 File Offset: 0x0001B1B0
	private #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z_XgeVm1QuF5E(#=z1Yuowbsexo2tKq_o8FtRjQuwMkPx7CAS6A== #=zoXiLUP8=, out string #=zIapFsKF23kqB)
	{
		#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== result = null;
		#=zIapFsKF23kqB = null;
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Init(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechToUpgradeIds);
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Count > 0)
		{
			#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = null;
			TimeSpan t = TimeSpan.Zero;
			foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2 in this.#=zJF2YTStZkxdpBvijgveKmkY=)
			{
				TechPlanFrame techPlanFrame = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Get(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zMuFMjGQ=());
				if (techPlanFrame.IsUpgrade)
				{
					int num;
					if (techPlanFrame.UpgradeLevel > 0)
					{
						if (techPlanFrame.UpgradeLevel <= #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=().#=zaDKBEnk8Vsod())
						{
							num = techPlanFrame.UpgradeLevel;
						}
						else
						{
							num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=().#=zaDKBEnk8Vsod();
						}
					}
					else if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeTechsForSchemas)
					{
						num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=().#=zaDKBEnk8Vsod();
					}
					else
					{
						num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=().#=zDpaLxYOl35uZaIePmg==();
					}
					if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zvnZc$RhG_1Du() < num)
					{
						TimeSpan timeSpan = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=().#=zwX6NTlM=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zvnZc$RhG_1Du() + 1);
						if ((this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode == 2 || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpResearchWithBoostersMode == 3) && techPlanFrame.IsTimeBoost)
						{
							timeSpan = TimeSpan.FromMilliseconds(timeSpan.TotalHours);
						}
						if ((t > timeSpan || #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== == null) && #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zq2bPTdY=(), #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2.#=zvnZc$RhG_1Du() + 1, this.#=z8StzeqE=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA) && #=zoXiLUP8=.#=z0vSd8LyXizI7(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2))
						{
							#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==2;
							t = timeSpan;
						}
					}
				}
			}
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null)
			{
				if (!this.#=z8StzeqE=.#=zkXsxKS4OL0sN(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().RequireResources(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960397), this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForResearch))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961580), new object[]
					{
						#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().Name
					});
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().RequireResources(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960397));
					return result;
				}
				#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== #=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== = this.#=zY5j036GBN4QD.#=zAXaL0AbspmvA(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=(), #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForResearch, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyResPackIfNoResForResearch);
				if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq().Count > 0)
				{
					if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zfYEVQUtPgwVj0BONZA==().Count == 0)
					{
						string text = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960397));
						if (!string.IsNullOrEmpty(text))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961755), new object[]
							{
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().Name,
								text
							});
						}
					}
				}
				else
				{
					string text2 = this.#=zBsXSanI=.#=zqf$ER4kgqRjhLlVT9Q==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, false);
					text2 = text2.Trim();
					if (text2.Length < 10000)
					{
						if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961694), new object[]
							{
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1
							});
						}
						else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961344), new object[]
							{
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1
							});
							#=zoXiLUP8=.#=zR__3$vI=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==);
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961512), new object[]
							{
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
								#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1,
								text2
							});
						}
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961448), new object[]
						{
							#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zkfqcY3I=(),
							#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1
						});
						#=zoXiLUP8=.#=zR__3$vI=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==);
						string text3 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960397));
						if (!string.IsNullOrEmpty(text3))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961138), new object[]
							{
								text3
							});
						}
						result = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==;
						#=zIapFsKF23kqB = text2;
					}
				}
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908961085), Array.Empty<object>());
			}
		}
		return result;
	}

	// Token: 0x04000112 RID: 274
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x04000113 RID: 275
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x04000114 RID: 276
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zbkd1_SL26Bt5;

	// Token: 0x04000115 RID: 277
	private bool #=zkTFDbK1WLBVA;

	// Token: 0x04000116 RID: 278
	private List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=znmyDeS0OacNZwPmJ6YZ$l6Y=;

	// Token: 0x04000117 RID: 279
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x04000118 RID: 280
	private #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE= #=zY5j036GBN4QD;

	// Token: 0x04000119 RID: 281
	private #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E= #=zZKzdsPms7IDM;
}
