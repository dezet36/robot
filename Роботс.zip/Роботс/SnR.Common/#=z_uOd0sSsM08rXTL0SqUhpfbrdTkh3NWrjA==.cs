﻿using System;
using System.Collections.Generic;

// Token: 0x020001F6 RID: 502
internal sealed class #=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA==
{
	// Token: 0x06000F34 RID: 3892 RVA: 0x00078CB4 File Offset: 0x00076EB4
	public #=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA==()
	{
		this.#=zk1kdFTl$XJruuowrJK81wZ8=(new #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD());
		this.#=zvJZXE7pqfo64YF9_P29UAI8=(new #=zxEcyaTM74b5po9YECXR2wyD1xbUygMS0NY1H8Zl8evef());
		this.#=zCGYRbDZhjQsZlXPt1dXBsQM=(new #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool>(TimeSpan.FromMinutes(60.0), false, false));
		this.#=zuGvzZzWjmxxsQeny2A==(null);
		this.#=z0pIXP08duuZesLwoFfQ35Ks=(new #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<List<int>>(TimeSpan.FromHours(48.0), true, null));
	}

	// Token: 0x06000F35 RID: 3893 RVA: 0x00078D1C File Offset: 0x00076F1C
	public #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD #=zgcfxUHbZmytORt2N3GObk4o=()
	{
		return this.#=zVMoQyrBDe6NHUMY9FgZuy8ULM$B4nJq_4g==;
	}

	// Token: 0x06000F36 RID: 3894 RVA: 0x00078D24 File Offset: 0x00076F24
	private void #=zk1kdFTl$XJruuowrJK81wZ8=(#=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD #=z$Ib9gYQ=)
	{
		this.#=zVMoQyrBDe6NHUMY9FgZuy8ULM$B4nJq_4g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F37 RID: 3895 RVA: 0x00078D30 File Offset: 0x00076F30
	public #=zxEcyaTM74b5po9YECXR2wyD1xbUygMS0NY1H8Zl8evef #=zS5BpZBs_LT3sEKeDeobrTyM=()
	{
		return this.#=ztnGCY8TvRNC4EmkD8t7CbrC8mCJD;
	}

	// Token: 0x06000F38 RID: 3896 RVA: 0x00078D38 File Offset: 0x00076F38
	private void #=zvJZXE7pqfo64YF9_P29UAI8=(#=zxEcyaTM74b5po9YECXR2wyD1xbUygMS0NY1H8Zl8evef #=z$Ib9gYQ=)
	{
		this.#=ztnGCY8TvRNC4EmkD8t7CbrC8mCJD = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F39 RID: 3897 RVA: 0x00078D44 File Offset: 0x00076F44
	public #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=zKJKWakAT6jUi5ml5CkFAYR8=()
	{
		return this.#=z6thw2rNiFCgD7N2uG5084y5CIIV6O3ExNQ==;
	}

	// Token: 0x06000F3A RID: 3898 RVA: 0x00078D4C File Offset: 0x00076F4C
	private void #=zCGYRbDZhjQsZlXPt1dXBsQM=(#=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=z$Ib9gYQ=)
	{
		this.#=z6thw2rNiFCgD7N2uG5084y5CIIV6O3ExNQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F3B RID: 3899 RVA: 0x00078D58 File Offset: 0x00076F58
	public object[] #=zJwqmcdMgqCCbmR3NGQ==()
	{
		return this.#=zzrImP4ZCRq1c$g8HSCPbguVHXdsk;
	}

	// Token: 0x06000F3C RID: 3900 RVA: 0x00078D60 File Offset: 0x00076F60
	public void #=zuGvzZzWjmxxsQeny2A==(object[] #=z$Ib9gYQ=)
	{
		this.#=zzrImP4ZCRq1c$g8HSCPbguVHXdsk = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F3D RID: 3901 RVA: 0x00078D6C File Offset: 0x00076F6C
	public #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<List<int>> #=zpNxB4dFKltIiFxvtTnzTdPw=()
	{
		return this.#=zrVPZhfPF_D5lRYEgS5q$wSmh6AEV6dtk$g==;
	}

	// Token: 0x06000F3E RID: 3902 RVA: 0x00078D74 File Offset: 0x00076F74
	private void #=z0pIXP08duuZesLwoFfQ35Ks=(#=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<List<int>> #=z$Ib9gYQ=)
	{
		this.#=zrVPZhfPF_D5lRYEgS5q$wSmh6AEV6dtk$g== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000879 RID: 2169
	private #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD #=zVMoQyrBDe6NHUMY9FgZuy8ULM$B4nJq_4g==;

	// Token: 0x0400087A RID: 2170
	private #=zxEcyaTM74b5po9YECXR2wyD1xbUygMS0NY1H8Zl8evef #=ztnGCY8TvRNC4EmkD8t7CbrC8mCJD;

	// Token: 0x0400087B RID: 2171
	private #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=z6thw2rNiFCgD7N2uG5084y5CIIV6O3ExNQ==;

	// Token: 0x0400087C RID: 2172
	private object[] #=zzrImP4ZCRq1c$g8HSCPbguVHXdsk;

	// Token: 0x0400087D RID: 2173
	private #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<List<int>> #=zrVPZhfPF_D5lRYEgS5q$wSmh6AEV6dtk$g==;
}
