﻿using System;

// Token: 0x02000194 RID: 404
internal sealed class #=zRl61TBSNfLrgIyYfRA==
{
	// Token: 0x06000B99 RID: 2969 RVA: 0x00058184 File Offset: 0x00056384
	private #=zRl61TBSNfLrgIyYfRA==()
	{
	}

	// Token: 0x06000B9A RID: 2970 RVA: 0x0005818C File Offset: 0x0005638C
	public static byte[] #=zhg1f_CEyF7Jk(sbyte[] #=zew602Gc5$aOZ)
	{
		byte[] array = new byte[#=zew602Gc5$aOZ.Length];
		for (int i = 0; i < #=zew602Gc5$aOZ.Length; i++)
		{
			array[i] = (byte)#=zew602Gc5$aOZ[i];
		}
		return array;
	}

	// Token: 0x06000B9B RID: 2971 RVA: 0x000581B8 File Offset: 0x000563B8
	public static byte[] #=zhg1f_CEyF7Jk(string #=zMN4QVxk=)
	{
		byte[] array = new byte[#=zMN4QVxk=.Length];
		for (int i = 0; i < #=zMN4QVxk=.Length; i++)
		{
			array[i] = (byte)#=zMN4QVxk=[i];
		}
		return array;
	}

	// Token: 0x06000B9C RID: 2972 RVA: 0x000581F0 File Offset: 0x000563F0
	public static byte[] #=zhg1f_CEyF7Jk(object[] #=zajKwA_UirifY)
	{
		byte[] array = new byte[#=zajKwA_UirifY.Length];
		for (int i = 0; i < #=zajKwA_UirifY.Length; i++)
		{
			array[i] = (byte)#=zajKwA_UirifY[i];
		}
		return array;
	}

	// Token: 0x06000B9D RID: 2973 RVA: 0x00058220 File Offset: 0x00056420
	public static sbyte[] #=zbXr_C7LxAZdD(byte[] #=zqFvApcI=)
	{
		sbyte[] array = new sbyte[#=zqFvApcI=.Length];
		for (int i = 0; i < #=zqFvApcI=.Length; i++)
		{
			array[i] = (sbyte)#=zqFvApcI=[i];
		}
		return array;
	}

	// Token: 0x06000B9E RID: 2974 RVA: 0x0005824C File Offset: 0x0005644C
	public static char[] #=zhYXm8L7UMnjW(sbyte[] #=z$xZMBsFTiqhR)
	{
		char[] array = new char[#=z$xZMBsFTiqhR.Length];
		#=z$xZMBsFTiqhR.CopyTo(array, 0);
		return array;
	}

	// Token: 0x06000B9F RID: 2975 RVA: 0x0005826C File Offset: 0x0005646C
	public static char[] #=zhYXm8L7UMnjW(byte[] #=zqFvApcI=)
	{
		char[] array = new char[#=zqFvApcI=.Length];
		#=zqFvApcI=.CopyTo(array, 0);
		return array;
	}
}
