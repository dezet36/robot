﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200020B RID: 523
internal sealed class #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX : RecordData
{
	// Token: 0x0600100F RID: 4111 RVA: 0x0007BEB0 File Offset: 0x0007A0B0
	public #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		int @int = IntegerHelper.getInt(data[0], data[1]);
		int num = 2;
		this.#=zF5g$dZZQGSkT = new int[@int];
		for (int i = 0; i < @int; i++)
		{
			this.#=zF5g$dZZQGSkT[i] = IntegerHelper.getInt(data[num], data[num + 1]);
			num += 6;
		}
	}

	// Token: 0x06001010 RID: 4112 RVA: 0x0007BF0C File Offset: 0x0007A10C
	public #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX(Record #=zJce$Sys=, #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		int @int = IntegerHelper.getInt(data[0], data[1]);
		int num = 2;
		this.#=zF5g$dZZQGSkT = new int[@int];
		for (int i = 0; i < @int; i++)
		{
			num += 2;
			this.#=zF5g$dZZQGSkT[i] = IntegerHelper.getInt(data[num], data[num + 1]);
		}
	}

	// Token: 0x06001012 RID: 4114 RVA: 0x0007BF74 File Offset: 0x0007A174
	public int[] #=zOmAd$eG7cqZo()
	{
		return this.#=zF5g$dZZQGSkT;
	}

	// Token: 0x040008DD RID: 2269
	private int[] #=zF5g$dZZQGSkT;

	// Token: 0x040008DE RID: 2270
	public static #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz = new #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX.#=zlfjpmgW14u47();

	// Token: 0x0200020C RID: 524
	public sealed class #=zlfjpmgW14u47
	{
	}
}
