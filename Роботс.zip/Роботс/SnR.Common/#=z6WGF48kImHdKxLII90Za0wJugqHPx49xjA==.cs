﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000080 RID: 128
internal sealed class #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== : List<#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==>
{
	// Token: 0x06000392 RID: 914 RVA: 0x0001FC6C File Offset: 0x0001DE6C
	public #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==(bool #=z3Iab7tAe67TJ)
	{
		this.#=zqyRsI9UHymjy(#=z3Iab7tAe67TJ);
		this.#=znJrRw1EBkkyl$lYF_3YJ7qg=(false);
	}

	// Token: 0x06000393 RID: 915 RVA: 0x0001FC84 File Offset: 0x0001DE84
	public bool #=zXiEDRhrBz88L()
	{
		return this.#=zO0PPFRkltonpaqr14qM1e7w=;
	}

	// Token: 0x06000394 RID: 916 RVA: 0x0001FC8C File Offset: 0x0001DE8C
	public void #=zqyRsI9UHymjy(bool #=z$Ib9gYQ=)
	{
		this.#=zO0PPFRkltonpaqr14qM1e7w= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000395 RID: 917 RVA: 0x0001FC98 File Offset: 0x0001DE98
	public bool #=zHp_H9kjso26frPfu2USZhi4=()
	{
		return this.#=zpR_PlHOtJOWyjdVG3i8qeQDR6w0N;
	}

	// Token: 0x06000396 RID: 918 RVA: 0x0001FCA0 File Offset: 0x0001DEA0
	public void #=znJrRw1EBkkyl$lYF_3YJ7qg=(bool #=z$Ib9gYQ=)
	{
		this.#=zpR_PlHOtJOWyjdVG3i8qeQDR6w0N = #=z$Ib9gYQ=;
	}

	// Token: 0x06000397 RID: 919 RVA: 0x0001FCAC File Offset: 0x0001DEAC
	public static #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== #=zErO$$v4=(Dictionary<string, object> #=zJ5GWysk=)
	{
		if (#=zJ5GWysk= == null)
		{
			return null;
		}
		bool #=z3Iab7tAe67TJ = JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0) == 1;
		object[] array = JSONManager.ExtractArray(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237));
		if (array == null)
		{
			return null;
		}
		#=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== = new #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==(#=z3Iab7tAe67TJ);
		object[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg== #=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg== = #=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==.#=zErO$$v4=((Dictionary<string, object>)array2[i]);
			if (#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg== != null)
			{
				#=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==.Add(#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==);
			}
		}
		if (#=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==.Count == 0)
		{
			return null;
		}
		return #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==;
	}

	// Token: 0x06000398 RID: 920 RVA: 0x0001FD28 File Offset: 0x0001DF28
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		object[] array = new object[base.Count];
		for (int i = 0; i < base.Count; i++)
		{
			array[i] = base[i].#=zhv7OhlM=();
		}
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				(this.#=zXiEDRhrBz88L() > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				array
			}
		};
	}

	// Token: 0x06000399 RID: 921 RVA: 0x0001FD98 File Offset: 0x0001DF98
	public #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== #=zTnMGkyA=()
	{
		#=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA== = new #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==(this.#=zXiEDRhrBz88L());
		foreach (#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg== #=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg== in this)
		{
			#=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==.Add(#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==.#=zTnMGkyA=());
		}
		return #=z6WGF48kImHdKxLII90Za0wJugqHPx49xjA==;
	}

	// Token: 0x0600039A RID: 922 RVA: 0x0001FDF8 File Offset: 0x0001DFF8
	public bool #=zM4ts4Mc=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		bool flag;
		if (base.Count == 0)
		{
			flag = true;
		}
		else
		{
			if (this.#=zXiEDRhrBz88L())
			{
				flag = false;
				using (List<#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==>.Enumerator enumerator = base.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (enumerator.Current.#=zM4ts4Mc=(#=zuJjQ1XU=))
						{
							flag = true;
							break;
						}
					}
					goto IL_82;
				}
			}
			flag = true;
			using (List<#=zwu_XorSyKlrMi33utAd4ExHTU$uYpeBXqg==>.Enumerator enumerator = base.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (!enumerator.Current.#=zM4ts4Mc=(#=zuJjQ1XU=))
					{
						flag = false;
						break;
					}
				}
			}
		}
		IL_82:
		this.#=znJrRw1EBkkyl$lYF_3YJ7qg=(flag);
		return flag;
	}

	// Token: 0x04000141 RID: 321
	private bool #=zO0PPFRkltonpaqr14qM1e7w=;

	// Token: 0x04000142 RID: 322
	private bool #=zpR_PlHOtJOWyjdVG3i8qeQDR6w0N;
}
