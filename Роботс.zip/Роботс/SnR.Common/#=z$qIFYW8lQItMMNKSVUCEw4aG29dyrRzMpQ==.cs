﻿using System;

// Token: 0x02000021 RID: 33
internal sealed class #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==
{
	// Token: 0x06000066 RID: 102 RVA: 0x00003DF8 File Offset: 0x00001FF8
	public #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==(int #=zbwrJfOI=, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=z40sk5mc=, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP, int #=zNvCMwussKumm)
	{
		this.#=zWIeOkE0$UPjN(#=zbwrJfOI=);
		this.#=z2QfEz18=(#=z40sk5mc=);
		this.#=z3y$Jd2Y9Ey5E(#=zrneKYItKkdXP);
		this.#=zqoCq5j01dD5w(#=zNvCMwussKumm);
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00003E20 File Offset: 0x00002020
	public #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zpz2EEduGaShz, int #=zNvCMwussKumm)
	{
		this.#=zWIeOkE0$UPjN(#=zpz2EEduGaShz.#=zK5gF1KeGk_H_());
		this.#=z2QfEz18=(#=zpz2EEduGaShz.#=zuFPZLKs=());
		this.#=z3y$Jd2Y9Ey5E(#=zpz2EEduGaShz.#=zzasQXAPWhOif());
		this.#=zqoCq5j01dD5w(#=zNvCMwussKumm);
	}

	// Token: 0x06000068 RID: 104 RVA: 0x00003E54 File Offset: 0x00002054
	public int #=zK5gF1KeGk_H_()
	{
		return this.#=z$PjuEd9p6uF7ftQ3QA==;
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00003E5C File Offset: 0x0000205C
	public void #=zWIeOkE0$UPjN(int #=z$Ib9gYQ=)
	{
		this.#=z$PjuEd9p6uF7ftQ3QA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00003E68 File Offset: 0x00002068
	public #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zuFPZLKs=()
	{
		return this.#=zBli65MnJh7hzwNOS3A==;
	}

	// Token: 0x0600006B RID: 107 RVA: 0x00003E70 File Offset: 0x00002070
	public void #=z2QfEz18=(#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=z$Ib9gYQ=)
	{
		this.#=zBli65MnJh7hzwNOS3A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600006C RID: 108 RVA: 0x00003E7C File Offset: 0x0000207C
	public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zzasQXAPWhOif()
	{
		return this.#=zkanVdU4qSKZQX0s_fw==;
	}

	// Token: 0x0600006D RID: 109 RVA: 0x00003E84 File Offset: 0x00002084
	public void #=z3y$Jd2Y9Ey5E(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=z$Ib9gYQ=)
	{
		this.#=zkanVdU4qSKZQX0s_fw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600006E RID: 110 RVA: 0x00003E90 File Offset: 0x00002090
	public int #=zlIXJ9$NfUZc_()
	{
		return this.#=zxojFZYWVfXhu329mAA==;
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00003E98 File Offset: 0x00002098
	public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
	{
		this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0400001B RID: 27
	private int #=z$PjuEd9p6uF7ftQ3QA==;

	// Token: 0x0400001C RID: 28
	private #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zBli65MnJh7hzwNOS3A==;

	// Token: 0x0400001D RID: 29
	private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zkanVdU4qSKZQX0s_fw==;

	// Token: 0x0400001E RID: 30
	private int #=zxojFZYWVfXhu329mAA==;
}
