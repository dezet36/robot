﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000041 RID: 65
internal sealed class #=z2$7JhsUL6fqHJpYg7cvlnb$3s7Fkn2OaGQ1UGT4qF9jbAovfUw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000214 RID: 532 RVA: 0x00014084 File Offset: 0x00012284
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zq5dpakjDAowz = #=zuJjQ1XU=.#=zLpfQR4rCsLNX6jyhnw==();
	}

	// Token: 0x06000215 RID: 533 RVA: 0x00014094 File Offset: 0x00012294
	protected override void #=zvb5bnug=()
	{
		if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)(-2) || DateTime.Now > this.#=zq5dpakjDAowz.#=zxudUqyzmC$NkR2g1FQ==())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952034), Array.Empty<object>());
			return;
		}
		if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)(-1))
		{
			string text = this.#=zBsXSanI=.#=zVGRfhAGBsIPXPgnBAA==();
			if (text.Length <= 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951960), new object[]
				{
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952004), Array.Empty<object>());
			base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
		}
		DateTime dateTime = DateTime.MinValue;
		DateTime t = DateTime.Now + TimeSpan.FromMinutes(10.0);
		while (DateTime.Now < t)
		{
			bool flag = (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDiceGameUseImmediate || DateTime.Now > this.#=zq5dpakjDAowz.#=zxudUqyzmC$NkR2g1FQ==() - TimeSpan.FromMinutes(120.0)) && this.#=zq5dpakjDAowz.#=zuYDXlhIvRg6q() > 0;
			if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)1)
			{
				if (this.#=zq5dpakjDAowz.#=zEhPgbEtIwmM2wLM7qw==() <= 0)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951658), Array.Empty<object>());
				}
				else if (this.#=zq5dpakjDAowz.#=zOH9mjMBOuMo$K3kunK642NM=() + TimeSpan.FromMinutes(120.0) > DateTime.Now)
				{
					if (!flag)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951720), Array.Empty<object>());
						dateTime = this.#=zq5dpakjDAowz.#=zOH9mjMBOuMo$K3kunK642NM=() + TimeSpan.FromMinutes(120.0);
						break;
					}
					string text = this.#=zBsXSanI=.#=zob$EjVWom9M5tkUnVB1yEVI=(true);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951604), Array.Empty<object>());
						base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
						continue;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951795), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
				else
				{
					string text = this.#=zBsXSanI=.#=zob$EjVWom9M5tkUnVB1yEVI=(false);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953452), Array.Empty<object>());
						base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
						continue;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953400), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)6)
			{
				if (this.#=zq5dpakjDAowz.#=zOH9mjMBOuMo$K3kunK642NM=() + TimeSpan.FromMinutes(120.0) > DateTime.Now)
				{
					if (!flag)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953479), Array.Empty<object>());
						dateTime = this.#=zq5dpakjDAowz.#=zOH9mjMBOuMo$K3kunK642NM=() + TimeSpan.FromMinutes(120.0);
						break;
					}
					string text = this.#=zBsXSanI=.#=zob$EjVWom9M5tkUnVB1yEVI=(true);
					if (text.Length <= 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953551), new object[]
						{
							JSONManager.Cut(text)
						});
						break;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953350), Array.Empty<object>());
					base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953162), Array.Empty<object>());
				}
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)4)
			{
				if (!this.#=zq5dpakjDAowz.#=zBVxHZ5ncbjenzDEfd4ZwPmNJvcNP())
				{
					string text = this.#=zBsXSanI=.#=zob$EjVWom9M5tkUnVB1yEVI=(false);
					if (text.Length <= 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953315), new object[]
						{
							JSONManager.Cut(text)
						});
						break;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953127), Array.Empty<object>());
					base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953127), Array.Empty<object>());
				}
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)7)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953242), Array.Empty<object>());
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)3)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952949), Array.Empty<object>());
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)2)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952882), Array.Empty<object>());
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)8)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952844), Array.Empty<object>());
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)5)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953039), Array.Empty<object>());
			}
			else if (this.#=zq5dpakjDAowz.#=zUfTNWZidqO78() == (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=.#=z7cLRqns=)0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952983), Array.Empty<object>());
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952684), new object[]
				{
					(int)this.#=zq5dpakjDAowz.#=zUfTNWZidqO78()
				});
			}
			if (this.#=zq5dpakjDAowz.#=z9Crk68wxKePsBQzwsQ==() <= 0)
			{
				if (this.#=zq5dpakjDAowz.#=zuYDXlhIvRg6q() <= 0)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952639), Array.Empty<object>());
					break;
				}
				string text = this.#=zBsXSanI=.#=zNZBrA6sD0AEwfLHhNQ==();
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952786), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952598), new object[]
				{
					this.#=zq5dpakjDAowz.#=zuYDXlhIvRg6q() - 1
				});
				base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
			}
			if (this.#=zq5dpakjDAowz.#=z9Crk68wxKePsBQzwsQ==() > 0)
			{
				string text = this.#=zBsXSanI=.#=zFxTk7J4J8rCbppGdRg==();
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954482), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952740), Array.Empty<object>());
				base.#=zL1HTbwC75LO$(JSONManager.GetData(text));
			}
		}
		foreach (int num in this.#=zq5dpakjDAowz.#=ziykhCXyTCZYpuxBoRw==())
		{
			for (int i = 0; i <= 0; i++)
			{
				if (this.#=zq5dpakjDAowz.#=zYlSZ5YTp$oZ0OXZ$0w==().ContainsKey(i) && this.#=zq5dpakjDAowz.#=zYlSZ5YTp$oZ0OXZ$0w==()[i].Contains(num))
				{
					bool flag2 = false;
					if (this.#=zq5dpakjDAowz.#=zJMXLuIzrpbV4vH1Qzg==().ContainsKey(i) && this.#=zq5dpakjDAowz.#=zJMXLuIzrpbV4vH1Qzg==()[i].Contains(num))
					{
						flag2 = true;
					}
					if (!flag2)
					{
						string text = this.#=zBsXSanI=.#=z8rJ9A6vyYfDOlq5fzLmt43MQYLJARtatAQ==(i, num);
						if (text.Length <= 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954385), new object[]
							{
								num + 1,
								JSONManager.Cut(text)
							});
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954439), new object[]
						{
							num + 1
						});
					}
				}
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDiceGameBuyInShop && this.#=zq5dpakjDAowz.#=zHmi8epYYj6am2QJ7Ag==() > 0)
		{
			#=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zvyC00Y_9es8lCV0e9ILz5yw=();
			bool flag3 = true;
			while (flag3)
			{
				flag3 = false;
				for (int j = 0; j < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DiceGamePurchaseIds.Count; j++)
				{
					int num2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DiceGamePurchaseIds[j];
					#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh = #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$.#=zMCBxPjMHuu3i(num2);
					if (#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh != null && #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zisvlKsvs85jd() <= this.#=zq5dpakjDAowz.#=zHmi8epYYj6am2QJ7Ag==())
					{
						int num3;
						if (this.#=zq5dpakjDAowz.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS().ContainsKey(num2))
						{
							num3 = this.#=zq5dpakjDAowz.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS()[num2];
						}
						else
						{
							num3 = 0;
						}
						if (#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zzQest3wYXw6v() > num3)
						{
							string text = this.#=zBsXSanI=.#=zMlPtwEXwBKqO4dCd7e1o3U8=(num2);
							if (text.Length > 10000)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954589), new object[]
								{
									#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh
								});
								this.#=zq5dpakjDAowz.#=zu2sJifER3$yvNnErNg==(this.#=zq5dpakjDAowz.#=zHmi8epYYj6am2QJ7Ag==() - #=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh.#=zisvlKsvs85jd());
								if (!this.#=zq5dpakjDAowz.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS().ContainsKey(num2))
								{
									this.#=zq5dpakjDAowz.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS().Add(num2, 0);
								}
								Dictionary<int, int> dictionary = this.#=zq5dpakjDAowz.#=zbVr7SZA$PZYx0j1VTu8eHjAX_GtS();
								int key = num2;
								dictionary[key]++;
								flag3 = true;
								break;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954545), new object[]
							{
								#=zOiWE_lc$VjCy6yogLwLJk_3LL3M7CsOkWSG3aSDaH$Fh,
								JSONManager.Cut(text)
							});
							break;
						}
					}
				}
			}
		}
		if (dateTime == DateTime.MinValue)
		{
			if (DateTime.Now > t)
			{
				dateTime = DateTime.Now + TimeSpan.FromMinutes(3.0);
			}
			else if (DateTime.Now > this.#=zq5dpakjDAowz.#=zxudUqyzmC$NkR2g1FQ==() - TimeSpan.FromMinutes(120.0) && DateTime.Now < this.#=zq5dpakjDAowz.#=zxudUqyzmC$NkR2g1FQ==() - TimeSpan.FromMinutes(30.0))
			{
				dateTime = DateTime.Now + TimeSpan.FromMinutes(30.0);
			}
		}
		if (dateTime > DateTime.Now + TimeSpan.FromMinutes(30.0) && DateTime.Now < DateTime.Now + TimeSpan.FromMinutes(30.0))
		{
			dateTime = DateTime.Now + TimeSpan.FromMinutes(30.0);
		}
		if (dateTime != DateTime.MinValue)
		{
			base.#=zW3vCypudd9EC().NextExecutionTime = dateTime;
		}
	}

	// Token: 0x0400009D RID: 157
	private #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw= #=zq5dpakjDAowz;
}
