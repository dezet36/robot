﻿using System;
using System.Collections.Generic;
using System.Text;

// Token: 0x020000DB RID: 219
internal sealed class #=zD3QqiXZS0rGfIouxlaV9u5JKFmZkFOCHqw== : List<#=zo0xM9Yh84PPUvmstyPOlAl83hN9T>
{
	// Token: 0x060005DD RID: 1501 RVA: 0x000305B4 File Offset: 0x0002E7B4
	public void #=z20ohAjI=(#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zm92199OybSmIl9Uefw==)
	{
		this.#=z20ohAjI=(#=zm92199OybSmIl9Uefw==, null);
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x000305C0 File Offset: 0x0002E7C0
	public void #=z20ohAjI=(#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zm92199OybSmIl9Uefw==, Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=> #=zqmKEDy$bzDiM)
	{
		if (#=zqmKEDy$bzDiM == null)
		{
			#=zqmKEDy$bzDiM = new Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=>();
			for (int i = 0; i < base.Count; i++)
			{
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T = base[i];
				if (#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=z9ZHUN$Y=() != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0)
				{
					#=zqmKEDy$bzDiM[#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zMuFMjGQ=()] = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=z9ZHUN$Y=();
				}
			}
		}
		base.Clear();
		for (int j = 0; j < #=zm92199OybSmIl9Uefw==.Count; j++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = #=zm92199OybSmIl9Uefw==[j];
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=z$Ib9gYQ=;
			if (#=zqmKEDy$bzDiM.ContainsKey(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
			{
				#=z$Ib9gYQ= = #=zqmKEDy$bzDiM[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()];
			}
			else
			{
				#=z$Ib9gYQ= = (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0;
			}
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2 = new #=zo0xM9Yh84PPUvmstyPOlAl83hN9T();
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zbsxKkj4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zedb$WwBQsoJF(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zI74NzG$2ecMvvw_Hiw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zMU3h5OahHKt6(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zFzGvi_S6jJhE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zB6wj1d$M7SYT(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVm_gjb4pLtQN());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zpmbhfimGMj3U((int)(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=() * 50.0));
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zlMZ1R0P0SMkC(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zPEhDdtHVGNHR());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zbrtvpkQ=(#=z$Ib9gYQ=);
			base.Add(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2);
		}
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x000306D0 File Offset: 0x0002E8D0
	public void #=zh9Hvpsvdmk9S(#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zm92199OybSmIl9Uefw==, Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=> #=zqmKEDy$bzDiM)
	{
		if (#=zqmKEDy$bzDiM == null)
		{
			#=zqmKEDy$bzDiM = new Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=>();
			for (int i = 0; i < base.Count; i++)
			{
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T = base[i];
				if (#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=z9ZHUN$Y=() != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0)
				{
					#=zqmKEDy$bzDiM[#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zMuFMjGQ=()] = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=z9ZHUN$Y=();
				}
			}
		}
		base.Clear();
		for (int j = 0; j < #=zm92199OybSmIl9Uefw==.Count; j++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = #=zm92199OybSmIl9Uefw==[j];
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=z$Ib9gYQ=;
			if (#=zqmKEDy$bzDiM.ContainsKey(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
			{
				#=z$Ib9gYQ= = #=zqmKEDy$bzDiM[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()];
			}
			else
			{
				#=z$Ib9gYQ= = (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0;
			}
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T2 = new #=zo0xM9Yh84PPUvmstyPOlAl83hN9T();
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zbsxKkj4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zedb$WwBQsoJF(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zI74NzG$2ecMvvw_Hiw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zMU3h5OahHKt6(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zFzGvi_S6jJhE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zB6wj1d$M7SYT(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVm_gjb4pLtQN());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zpmbhfimGMj3U((int)(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=() * 50.0));
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zlMZ1R0P0SMkC(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zPEhDdtHVGNHR());
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2.#=zbrtvpkQ=(#=z$Ib9gYQ=);
			base.Add(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T2);
		}
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x000307E0 File Offset: 0x0002E9E0
	public string #=zKjxpeZXEbqufx39jhxAXfMk=(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zC7NDbDM=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		int i = 0;
		while (i < base.Count)
		{
			#=zo0xM9Yh84PPUvmstyPOlAl83hN9T #=zo0xM9Yh84PPUvmstyPOlAl83hN9T = base[i];
			#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG = #=zC7NDbDM=.#=zk$6QZNA=(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zFMDiymuLQ7_4());
			if (i > 0)
			{
				stringBuilder.Append(Environment.NewLine);
			}
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061114), new object[]
			{
				(#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG != null) ? #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG.Name : #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zFMDiymuLQ7_4().ToString(),
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zaKAy47_E$9SRuF6oiw==(),
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=ztj93y6niVpCR(),
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zvnZc$RhG_1Du(),
				(#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zVm_gjb4pLtQN() > 0) ? (#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077047) + #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zVm_gjb4pLtQN().ToString()) : string.Empty,
				#=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=zNTEClmggtyu4()
			});
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zY9gFTlM= = #=zo0xM9Yh84PPUvmstyPOlAl83hN9T.#=z9ZHUN$Y=();
			string #=zcpJ6bUA=;
			if (#=zY9gFTlM= <= (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10)
			{
				switch (#=zY9gFTlM=)
				{
				case (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1:
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061092);
					break;
				case (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)2:
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061079);
					break;
				case (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)3:
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061052);
					break;
				default:
					if (#=zY9gFTlM= != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10)
					{
						goto IL_163;
					}
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061026);
					break;
				}
			}
			else if (#=zY9gFTlM= != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20)
			{
				if (#=zY9gFTlM= != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21)
				{
					if (#=zY9gFTlM= != (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)30)
					{
						goto IL_163;
					}
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060693);
				}
				else
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060712);
				}
			}
			else
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061012);
			}
			IL_16E:
			stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zcpJ6bUA=));
			i++;
			continue;
			IL_163:
			#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060667);
			goto IL_16E;
		}
		return stringBuilder.ToString();
	}
}
