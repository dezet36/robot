﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x02000294 RID: 660
internal sealed class #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= : List<#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=>
{
	// Token: 0x0600141F RID: 5151 RVA: 0x00099CCC File Offset: 0x00097ECC
	public static #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=zi1hFJwI=()
	{
		if (#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr == null)
		{
			object obj = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr == null)
				{
					try
					{
						Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> dictionary = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zkUUmwSA23UXVOIFutxPsL6ZrnvCf();
						if (dictionary == null)
						{
							dictionary = new Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU>();
						}
						#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr = new #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=();
						ReadFileManager readFileManager = new ReadFileManager(FileResources.Items, true);
						while (readFileManager.NextLine())
						{
							int num = readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0);
							if (dictionary.ContainsKey(num) || dictionary.Count == 0)
							{
								#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zJ5GWysk=;
								if (dictionary.ContainsKey(num))
								{
									#=zJ5GWysk= = dictionary[num];
								}
								else
								{
									#=zJ5GWysk= = new #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(num, string.Format(readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315), 6), readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071310), 2)));
								}
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zJ5GWysk=);
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zIaGGDzQ=(readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071291), 1));
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)0);
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes.Unknown);
								string[] array = #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zd$BbM3Y=().Split(new char[]
								{
									'.'
								}, StringSplitOptions.RemoveEmptyEntries);
								string a = array[0];
								if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071286)))
								{
									if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071276)))
									{
										if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071258)))
										{
											if (a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071248))
											{
												string a2 = array[1];
												if (!(a2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070952)))
												{
													if (!(a2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070950)))
													{
														if (a2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070940))
														{
															#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11700);
														}
													}
													else
													{
														#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11511);
													}
												}
												else
												{
													#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11507);
												}
											}
										}
										else
										{
											string a2 = array[1];
											if (!(a2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071236)))
											{
												if (a2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070962))
												{
													#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11100);
												}
											}
											else
											{
												#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)11100);
											}
										}
									}
									else
									{
										#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)2010);
										#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zUc__ZG6ylFtKBI4BAQ==(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zsJJ$G_g=(array[1].ToLower()));
									}
								}
								else if (array[1] == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071246))
								{
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)500);
								}
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zpmbhfimGMj3U(readFileManager.ReadDouble(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071310), 2));
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z2a_u_nRabC8z(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070922), 3));
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zW$nvWxUdcXuzAEErVw==(ResourceTypes.Unknown);
								string a3 = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070918), 4);
								foreach (object obj2 in typeof(ResourceTypes).GetEnumValues())
								{
									ResourceTypes resourceTypes = (ResourceTypes)obj2;
									if (a3 == #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z9OFonzM=(resourceTypes))
									{
										#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zW$nvWxUdcXuzAEErVw==(resourceTypes);
										break;
									}
								}
								a = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070897), 5);
								if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070895)))
								{
									if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070884)))
									{
										if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070866)))
										{
											if (!(a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070857)))
											{
												#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)0);
											}
											else
											{
												#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)4);
											}
										}
										else
										{
											#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)3);
										}
									}
									else
									{
										#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)1);
									}
								}
								else
								{
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)2);
								}
								#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr.Add(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=);
							}
						}
						foreach (#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU in dictionary.Values)
						{
							if (#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zgxqDXpkUbQpR() > 0 && !#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zKHh25npqZrdn())
							{
								if (#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr.#=zk$6QZNA=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zMuFMjGQ=()) == null)
								{
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2 = new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU);
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zIaGGDzQ=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070852));
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=z_PEN4Dg=((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)300);
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zUc__ZG6ylFtKBI4BAQ==(ResourceTypes.Unknown);
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zpmbhfimGMj3U((double)#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zgxqDXpkUbQpR());
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=z2a_u_nRabC8z(0);
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zW$nvWxUdcXuzAEErVw==(ResourceTypes.Unknown);
									#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)5);
									#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr.Add(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2);
								}
							}
							else if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zhcdDwgYfw_ImvQmMXQ==.Contains(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zMuFMjGQ=()) && #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr.#=zk$6QZNA=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zMuFMjGQ=()) == null)
							{
								#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= item = new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU);
								#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr.Add(item);
							}
						}
					}
					catch (Exception #=zN_s5Z5A=)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
					}
				}
			}
		}
		return #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zOHvkTyexIHpr;
	}

	// Token: 0x06001420 RID: 5152 RVA: 0x0009A1F0 File Offset: 0x000983F0
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= in this)
		{
			if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=;
			}
		}
		return null;
	}

	// Token: 0x06001421 RID: 5153 RVA: 0x0009A248 File Offset: 0x00098448
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zk$6QZNA=(string #=zAk8mKBk=)
	{
		int #=zAk8mKBk=2;
		if (int.TryParse(#=zAk8mKBk=, out #=zAk8mKBk=2))
		{
			return this.#=zk$6QZNA=(#=zAk8mKBk=2);
		}
		return null;
	}

	// Token: 0x06001422 RID: 5154 RVA: 0x0009A268 File Offset: 0x00098468
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zd634hMCtcd$T(int #=zAk8mKBk=)
	{
		#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = this.#=zk$6QZNA=(#=zAk8mKBk=);
		if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= == null)
		{
			#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zhDfo7Dc=(#=zAk8mKBk=);
		}
		return #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=;
	}

	// Token: 0x06001423 RID: 5155 RVA: 0x0009A288 File Offset: 0x00098488
	public static #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zhDfo7Dc=(int #=zAk8mKBk=)
	{
		#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = null;
		Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> dictionary = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zkUUmwSA23UXVOIFutxPsL6ZrnvCf();
		if (dictionary != null && dictionary.ContainsKey(#=zAk8mKBk=))
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = dictionary[#=zAk8mKBk=];
		}
		if (#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU == null)
		{
			#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU = new #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(#=zAk8mKBk=, #=zAk8mKBk=.ToString());
		}
		return new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(#=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU);
	}

	// Token: 0x04000B8E RID: 2958
	private static #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=zOHvkTyexIHpr = null;

	// Token: 0x04000B8F RID: 2959
	private static object #=zSV4$mlFB34WM = new object();
}
