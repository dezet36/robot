﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020001F0 RID: 496
internal sealed class #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000F07 RID: 3847 RVA: 0x0007759C File Offset: 0x0007579C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zUStZ$u339$E1 = #=zuJjQ1XU=.#=zqm6T_XR3NwZ2();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
	}

	// Token: 0x06000F08 RID: 3848 RVA: 0x000775B8 File Offset: 0x000757B8
	protected override void #=zvb5bnug=()
	{
		#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zPeypy81OWeno();
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup.Init();
		List<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=> #=zLV1hR7kIVoe7iHIQHQ== = #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zE8ImpupfsUOI();
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975759), Array.Empty<object>());
			return;
		}
		this.#=zQjM1mV0$VeF6();
		bool flag = this.#=zfPIOLYqwptZtY7OinA==();
		bool flag2;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeAllGems)
		{
			flag2 = this.#=zKVSeAtR4_MC4QsM3mg==();
		}
		else
		{
			flag2 = this.#=zhjM8KDHkpKCr(#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==);
		}
		if (flag || flag2)
		{
			this.#=zcDRV51Ut$7oP.NextExecutionTime = DateTime.Now + TimeSpan.FromSeconds(60.0);
			return;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ActivateGemTypes.Count > 0)
		{
			List<int> list = new List<int>();
			for (int i = 1; i < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[0].#=zosM5VihpD8f9NO4ZyA==(); i++)
			{
				list.Add(i);
			}
			int num = 0;
			for (int j = 0; j < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup.Count; j++)
			{
				GemsSetupFrame gemsSetupFrame = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[j];
				if (gemsSetupFrame.IsActivate)
				{
					for (int k = (gemsSetupFrame.MinActLvl > num + 1) ? gemsSetupFrame.MinActLvl : (num + 1); k <= gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==(); k++)
					{
						list.Add(k);
					}
				}
				num = gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==();
			}
			Dictionary<int, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> dictionary = new Dictionary<int, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>();
			Dictionary<int, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> dictionary2 = new Dictionary<int, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>();
			for (int l = 0; l < this.#=zUStZ$u339$E1.Count; l++)
			{
				#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = this.#=zUStZ$u339$E1[l];
				if (list.Contains(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du()))
				{
					if (!dictionary.ContainsKey(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()))
					{
						dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()] = #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==;
					}
					else if (dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()].#=zvnZc$RhG_1Du() < #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du())
					{
						dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()] = #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==;
					}
				}
				if (#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zx0VSW$qAY8R7() > 0)
				{
					dictionary2[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()] = #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==;
				}
			}
			Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>> dictionary3 = new Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>>();
			for (int m = 0; m < #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==.Count; m++)
			{
				#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== = #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==[m];
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ActivateGemTypes.Contains(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()))
				{
					List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list2;
					if (dictionary3.ContainsKey(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zWxFFEucRtmR7()))
					{
						list2 = dictionary3[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zWxFFEucRtmR7()];
					}
					else
					{
						list2 = new List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>();
						dictionary3[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zWxFFEucRtmR7()] = list2;
					}
					if (dictionary2.ContainsKey(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()) && dictionary.ContainsKey(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()) && dictionary2[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()].#=zvnZc$RhG_1Du() >= dictionary[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()].#=zvnZc$RhG_1Du())
					{
						dictionary[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()] = dictionary2[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()];
					}
					if (dictionary.ContainsKey(#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()))
					{
						list2.Add(dictionary[#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=()]);
					}
				}
			}
			Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>> dictionary4 = new Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>>();
			foreach (Worlds worlds in dictionary3.Keys)
			{
				List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list3 = dictionary3[worlds];
				int num2 = ((Worlds)this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE().Length > worlds) ? this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE()[(int)worlds] : 0;
				list3.Sort(new Comparison<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>(#=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zyDNvciU=.#=zLkw0NRU=.#=zA9Lc_X2EKLNnsMpm4A==));
				List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list4 = new List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>();
				while (list4.Count < num2 && list4.Count < list3.Count)
				{
					list4.Add(list3[list4.Count]);
				}
				if (list4.Count > 0)
				{
					dictionary4[worlds] = list4;
				}
			}
			List<int> list5 = new List<int>();
			StringBuilder stringBuilder = new StringBuilder();
			foreach (List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list6 in dictionary4.Values)
			{
				for (int n = 0; n < list6.Count; n++)
				{
					#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2 = list6[n];
					list5.Add(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zMuFMjGQ=());
					if (stringBuilder.Length > 0)
					{
						stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
					}
					stringBuilder.Append(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.ToString());
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975459), new object[]
			{
				stringBuilder
			});
			Dictionary<Worlds, List<int>> #=zc7k1Mr1Fmtav = this.#=z3R6NsB8Y$gFd(dictionary4);
			this.#=z3EVDZaQFsgE7(dictionary2, list5, #=zc7k1Mr1Fmtav, #=zLV1hR7kIVoe7iHIQHQ==);
			this.#=ztjWVIPZj6U4s(dictionary4, #=zc7k1Mr1Fmtav);
		}
	}

	// Token: 0x06000F09 RID: 3849 RVA: 0x00077AFC File Offset: 0x00075CFC
	private void #=zQjM1mV0$VeF6()
	{
		int num = this.#=zCY4az9$WUjLsEJ7fgg==.#=z2cw4dd0=(800);
		int num2 = 0;
		while (num2 < num && num2 < 3 - this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE()[0])
		{
			string text = this.#=zBsXSanI=.#=zQ013NVEMj501das89A==();
			if (text.Length <= 1000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975399), new object[]
				{
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975437), Array.Empty<object>());
			this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE()[0]++;
			num2++;
		}
	}

	// Token: 0x06000F0A RID: 3850 RVA: 0x00077BC4 File Offset: 0x00075DC4
	private bool #=zfPIOLYqwptZtY7OinA==()
	{
		bool result = false;
		for (int i = 400; i <= 429; i++)
		{
			if (this.#=zCY4az9$WUjLsEJ7fgg==.#=z2cw4dd0=(i) > 0)
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[i];
				string text = this.#=zBsXSanI=.#=z8MWHQ2xuSrU2(i);
				if (text.Length <= 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975570), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_(),
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975595), new object[]
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_()
				});
				result = true;
			}
		}
		return result;
	}

	// Token: 0x06000F0B RID: 3851 RVA: 0x00077CBC File Offset: 0x00075EBC
	private Dictionary<Worlds, List<int>> #=z3R6NsB8Y$gFd(Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>> #=zZT2vdvPsfONg9YhB9Q==)
	{
		Dictionary<Worlds, List<int>> dictionary = new Dictionary<Worlds, List<int>>();
		foreach (Worlds worlds in #=zZT2vdvPsfONg9YhB9Q==.Keys)
		{
			if (#=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zTRUUbiNmRer2.ContainsKey(worlds))
			{
				int num = ((Worlds)this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE().Length > worlds) ? this.#=zUStZ$u339$E1.#=zi0n5Dw6d6LiE()[(int)worlds] : 0;
				int num2 = #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zTRUUbiNmRer2[worlds];
				List<int> list = new List<int>();
				for (int i = 0; i < num; i++)
				{
					list.Add(i + num2);
				}
				dictionary[worlds] = list;
			}
		}
		return dictionary;
	}

	// Token: 0x06000F0C RID: 3852 RVA: 0x00077D74 File Offset: 0x00075F74
	private void #=z3EVDZaQFsgE7(Dictionary<int, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> #=ztmhZebHIfBxu, List<int> #=zwNhyXgQxxEoBLzoR6u03b3s=, Dictionary<Worlds, List<int>> #=zc7k1Mr1Fmtav, List<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=> #=zLV1hR7kIVoe7iHIQHQ==)
	{
		foreach (int key in #=ztmhZebHIfBxu.Keys)
		{
			#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = #=ztmhZebHIfBxu[key];
			if (!#=zwNhyXgQxxEoBLzoR6u03b3s=.Contains(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zMuFMjGQ=()))
			{
				bool flag = true;
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = null;
				if (#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du() >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[0].#=zosM5VihpD8f9NO4ZyA==())
				{
					int num = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[0].#=zosM5VihpD8f9NO4ZyA==() - 1;
					int i = 0;
					while (i < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup.Count)
					{
						GemsSetupFrame gemsSetupFrame = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[i];
						if (#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du() > num && #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du() <= gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==())
						{
							if (!gemsSetupFrame.IsExtract)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975231), new object[]
								{
									#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
								});
								flag = false;
								break;
							}
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[gemsSetupFrame.ExTypeId];
							if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= == null || #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() == 0)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975543), new object[]
								{
									#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
								});
								flag = false;
								break;
							}
							break;
						}
						else
						{
							num = gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==();
							i++;
						}
					}
				}
				if (flag)
				{
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
					{
						string text = this.#=zBsXSanI=.#=zEHDGCfYrIW0Z(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zMuFMjGQ=(), #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zMuFMjGQ=());
						if (text.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975173), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==,
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=()
							});
							#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zlaFV2ewZfrpD(-1);
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
							int num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(num2 - 1);
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975135), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==,
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
								JSONManager.Cut(text)
							});
						}
					}
					else
					{
						string text2 = this.#=zBsXSanI=.#=zVA3X4OVyWzvJ(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zMuFMjGQ=());
						if (text2.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975331), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
							});
							#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zlaFV2ewZfrpD(-1);
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975308), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==,
								JSONManager.Cut(text2)
							});
						}
					}
				}
			}
			if (#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=z7BFVhqWl1c$0() && #=zc7k1Mr1Fmtav.ContainsKey(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zWxFFEucRtmR7()))
			{
				#=zc7k1Mr1Fmtav[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zWxFFEucRtmR7()].Remove(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zx0VSW$qAY8R7());
			}
		}
	}

	// Token: 0x06000F0D RID: 3853 RVA: 0x000780B8 File Offset: 0x000762B8
	private void #=ztjWVIPZj6U4s(Dictionary<Worlds, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>> #=zZT2vdvPsfONg9YhB9Q==, Dictionary<Worlds, List<int>> #=zc7k1Mr1Fmtav)
	{
		foreach (Worlds key in #=zZT2vdvPsfONg9YhB9Q==.Keys)
		{
			List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list = #=zZT2vdvPsfONg9YhB9Q==[key];
			List<int> list2 = #=zc7k1Mr1Fmtav[key];
			for (int i = 0; i < list.Count; i++)
			{
				#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = list[i];
				if (!#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=z7BFVhqWl1c$0())
				{
					if (list2.Count == 0)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975259), new object[]
						{
							#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
						});
						break;
					}
					int num = list2[0];
					string text = this.#=zBsXSanI=.#=zArLzi_RjnbNk(num, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zMuFMjGQ=());
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960618), new object[]
						{
							#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==
						});
						list2.Remove(num);
						#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zlaFV2ewZfrpD(num);
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960599), new object[]
						{
							#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==,
							JSONManager.Cut(text)
						});
					}
				}
			}
		}
	}

	// Token: 0x06000F0E RID: 3854 RVA: 0x00078228 File Offset: 0x00076428
	private bool #=zKVSeAtR4_MC4QsM3mg==()
	{
		Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>();
		bool result = false;
		for (int i = 0; i < this.#=zUStZ$u339$E1.Count; i++)
		{
			#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = this.#=zUStZ$u339$E1[i];
			if (!dictionary.ContainsKey(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()))
			{
				dictionary.Add(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=(), new List<int>
				{
					#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du()
				});
			}
			else
			{
				List<int> list = dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zq2bPTdY=().#=zMuFMjGQ=()];
				if (!list.Contains(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du()))
				{
					list.Add(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du());
				}
				else
				{
					string text = this.#=zBsXSanI=.#=zKVSeAtR4_MC4QsM3mg==();
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960547), Array.Empty<object>());
						result = true;
						break;
					}
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960513)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960737), Array.Empty<object>());
						break;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960648), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
			}
		}
		return result;
	}

	// Token: 0x06000F0F RID: 3855 RVA: 0x00078384 File Offset: 0x00076584
	private bool #=zhjM8KDHkpKCr(#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=zY6BuiKQeE9Eb)
	{
		bool result = false;
		DateTime t = DateTime.Now + TimeSpan.FromMinutes(5.0);
		foreach (#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== in #=zY6BuiKQeE9Eb)
		{
			int num = 0;
			Dictionary<int, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>> dictionary = new Dictionary<int, List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>>();
			#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = null;
			for (int i = 0; i < this.#=zUStZ$u339$E1.Count; i++)
			{
				#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2 = this.#=zUStZ$u339$E1[i];
				if (#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zq2bPTdY=().#=zMuFMjGQ=() == #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==.#=zMuFMjGQ=())
				{
					if (!#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=z7BFVhqWl1c$0())
					{
						num += #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zQJDZ$Ecbkows(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zvnZc$RhG_1Du());
						List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list;
						if (dictionary.ContainsKey(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zvnZc$RhG_1Du()))
						{
							list = dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zvnZc$RhG_1Du()];
						}
						else
						{
							list = new List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==>();
							dictionary[#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2.#=zvnZc$RhG_1Du()] = list;
						}
						list.Add(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2);
					}
					else
					{
						#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== = #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==2;
					}
				}
			}
			int num2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[0].#=zosM5VihpD8f9NO4ZyA==() - 1;
			List<int> list2 = new List<int>
			{
				num2
			};
			int num3 = 0;
			int num4 = 0;
			for (int j = 0; j < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup.Count; j++)
			{
				GemsSetupFrame gemsSetupFrame = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GemsSetup[j];
				int num5 = 0;
				for (int k = gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==(); k > num2; k--)
				{
					int num6 = #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zQJDZ$Ecbkows(k);
					if (num3 + num6 <= num)
					{
						num5 = k;
						num3 += num6;
						list2.Add(num5);
						break;
					}
				}
				if (num5 == 0)
				{
					break;
				}
				num4 = num5;
				num2 = gemsSetupFrame.#=zpYwEYSjujexlDiPY1A==();
			}
			for (int l = 1; l < num4; l++)
			{
				if (dictionary.ContainsKey(l))
				{
					List<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> list3 = dictionary[l];
					bool flag = list2.Contains(l);
					if (flag && #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== != null && #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==.#=zvnZc$RhG_1Du() == l)
					{
						flag = false;
					}
					int m = flag ? 2 : 1;
					while (m < list3.Count)
					{
						#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3 = list3[m - 1];
						#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==4 = list3[m];
						string text = this.#=zBsXSanI=.#=zABmNT2M02ssR(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zMuFMjGQ=(), #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==4.#=zMuFMjGQ=());
						if (text.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960344), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zq2bPTdY=().#=zkfqcY3I=(),
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zvnZc$RhG_1Du() + 1
							});
							result = true;
							if (DateTime.Now >= t)
							{
								return result;
							}
							m += 2;
						}
						else
						{
							if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960297)))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960277), new object[]
								{
									#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zq2bPTdY=().#=zkfqcY3I=(),
									#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zvnZc$RhG_1Du(),
									#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909036868))
								});
								break;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908960454), new object[]
							{
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zq2bPTdY=().#=zkfqcY3I=(),
								#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==3.#=zvnZc$RhG_1Du(),
								JSONManager.Cut(text)
							});
							break;
						}
					}
				}
			}
		}
		return result;
	}

	// Token: 0x06000F10 RID: 3856 RVA: 0x00078730 File Offset: 0x00076930
	private static int #=zQJDZ$Ecbkows(int #=zXQyYUAsDSdwz)
	{
		return (int)Math.Pow(2.0, (double)(#=zXQyYUAsDSdwz - 1));
	}

	// Token: 0x06000F11 RID: 3857 RVA: 0x00078748 File Offset: 0x00076948
	public static List<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=> #=zE8ImpupfsUOI()
	{
		Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> dictionary = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zkUUmwSA23UXVOIFutxPsL6ZrnvCf();
		List<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=> list = new List<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=>();
		for (int i = 450; i <= 459; i++)
		{
			if (dictionary.ContainsKey(i))
			{
				#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= = dictionary[i] as #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=;
				if (#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= != null)
				{
					list.Add(#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=);
				}
			}
		}
		list.Sort(new Comparison<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=>(#=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zyDNvciU=.#=zLkw0NRU=.#=zEguOG8ICZsw2y8aIeiIeBT8=));
		return list;
	}

	// Token: 0x04000869 RID: 2153
	private static Dictionary<Worlds, int> #=zTRUUbiNmRer2 = new Dictionary<Worlds, int>
	{
		{
			Worlds.Default,
			1
		},
		{
			Worlds.Elisium,
			10
		}
	};

	// Token: 0x0400086A RID: 2154
	private #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew== #=zUStZ$u339$E1;

	// Token: 0x0400086B RID: 2155
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x020001F1 RID: 497
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000F14 RID: 3860 RVA: 0x000787D0 File Offset: 0x000769D0
		internal int #=zA9Lc_X2EKLNnsMpm4A==(#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zm8PpuDU=, #=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g== #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zrHi0fK8=(new int[]
			{
				#=zm8PpuDU=.#=zvnZc$RhG_1Du().CompareTo(#=zcltuPyw=.#=zvnZc$RhG_1Du()),
				#=zm8PpuDU=.#=z7BFVhqWl1c$0().CompareTo(#=zcltuPyw=.#=z7BFVhqWl1c$0()),
				#=zm8PpuDU=.#=zq2bPTdY=().#=zMuFMjGQ=().CompareTo(#=zcltuPyw=.#=zq2bPTdY=().#=zMuFMjGQ=()),
				#=zm8PpuDU=.#=zMuFMjGQ=().CompareTo(#=zcltuPyw=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x06000F15 RID: 3861 RVA: 0x00078850 File Offset: 0x00076A50
		internal int #=zEguOG8ICZsw2y8aIeiIeBT8=(#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= #=zm8PpuDU=, #=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zFGv2TEt4Pg1fjr57ew==().CompareTo(#=zcltuPyw=.#=zFGv2TEt4Pg1fjr57ew==());
		}

		// Token: 0x0400086C RID: 2156
		public static readonly #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zyDNvciU= #=zLkw0NRU= = new #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO.#=zyDNvciU=();

		// Token: 0x0400086D RID: 2157
		public static Comparison<#=zQs1PH3g6Ph$o1Yvl18ZV92tDHdcWf8QW$g==> #=zd0BKI0I4rEEqgEDUZw==;

		// Token: 0x0400086E RID: 2158
		public static Comparison<#=zRbkMjlAm9SBC3nXeF6sN9B8yG2ommfVaNh1JFVEqmTgQfnAUWO0X1zs=> #=zfV8g$Yh_4F6VtTApcA==;
	}
}
