﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000081 RID: 129
internal sealed class #=z6Z3CifoDYyM1Rk78zE65mz368HEFGeMFjTFcUYYY18Dvml3O0Q== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600039C RID: 924 RVA: 0x0001FEB4 File Offset: 0x0001E0B4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z5Brzjn2N6vZ8JSBpY6qSYIrNlM_C = #=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=zwJ6drvwPG76Tqli7tzW6AYSBlcCm();
	}

	// Token: 0x0600039D RID: 925 RVA: 0x0001FEC8 File Offset: 0x0001E0C8
	protected override void #=zvb5bnug=()
	{
		object[] array = (object[])JSONManager.GetData(this.#=z5Brzjn2N6vZ8JSBpY6qSYIrNlM_C);
		int num = 0;
		foreach (Dictionary<string, object> obj in array)
		{
			if (JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958441), 0) == 0)
			{
				int @int = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958439), 0);
				object[] array2 = (object[])JSONManager.GetData(this.#=zBsXSanI=.#=zxg40d0O4ierUILFqqfU_MwM=(@int));
				List<int> list = new List<int>();
				for (int j = 0; j < array2.Length; j++)
				{
					Dictionary<string, object> dictionary = JSONManager.ExtractDictionary((Dictionary<string, object>)array2[j], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053));
					if (dictionary != null && JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), -1) == 0)
					{
						list.Add(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
					}
				}
				if (list.Count > 0)
				{
					this.#=zBsXSanI=.#=zW9BgawRdvCy$(list);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958429), new object[]
					{
						@int
					});
					num++;
				}
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958373), new object[]
		{
			array.Length,
			num
		});
	}

	// Token: 0x04000143 RID: 323
	private string #=z5Brzjn2N6vZ8JSBpY6qSYIrNlM_C;
}
