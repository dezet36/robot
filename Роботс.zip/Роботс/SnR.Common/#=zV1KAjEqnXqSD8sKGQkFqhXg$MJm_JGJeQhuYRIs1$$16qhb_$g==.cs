﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x020001BA RID: 442
internal sealed class #=zV1KAjEqnXqSD8sKGQkFqhXg$MJm_JGJeQhuYRIs1$$16qhb_$g== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000D3B RID: 3387 RVA: 0x00068368 File Offset: 0x00066568
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06000D3C RID: 3388 RVA: 0x0006836C File Offset: 0x0006656C
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=))
		{
			return;
		}
		#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k= #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k= = this.#=zcDRV51Ut$7oP as #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=;
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2() == null)
		{
			return;
		}
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2().Length != 2)
		{
			return;
		}
		int #=zvPiOyGQ=;
		int.TryParse(#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[0], out #=zvPiOyGQ=);
		string text = #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[1];
		string text2 = this.#=zBsXSanI=.#=zAA0VkBXDdKegEnGR4K3arhKmn1Ho(#=zvPiOyGQ=);
		if (text2.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973945), new object[]
			{
				text
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974066), new object[]
		{
			text,
			JSONManager.Cut(text2)
		});
	}
}
