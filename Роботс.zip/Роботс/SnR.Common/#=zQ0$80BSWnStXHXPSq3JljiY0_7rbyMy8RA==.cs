﻿using System;
using System.IO;
using System.Text;

// Token: 0x02000187 RID: 391
internal sealed class #=zQ0$80BSWnStXHXPSq3JljiY0_7rbyMy8RA==
{
	// Token: 0x06000B28 RID: 2856 RVA: 0x00056334 File Offset: 0x00054534
	public static int #=zPMfJtLxrx9HD(int #=zXHTER4Q=, int #=zGyL$Taw=)
	{
		return (int)((uint)#=zXHTER4Q= >> #=zGyL$Taw=);
	}

	// Token: 0x06000B29 RID: 2857 RVA: 0x0005633C File Offset: 0x0005453C
	public static int #=z4qjVIng=(TextReader #=zOi4vFqbwM_vU, byte[] #=z40sk5mc=, int #=z1qaC5B0=, int #=z4UDysxM=)
	{
		if (#=z40sk5mc=.Length == 0)
		{
			return 0;
		}
		char[] array = new char[#=z40sk5mc=.Length];
		int num = #=zOi4vFqbwM_vU.Read(array, #=z1qaC5B0=, #=z4UDysxM=);
		if (num == 0)
		{
			return -1;
		}
		for (int i = #=z1qaC5B0=; i < #=z1qaC5B0= + num; i++)
		{
			#=z40sk5mc=[i] = (byte)array[i];
		}
		return num;
	}

	// Token: 0x06000B2A RID: 2858 RVA: 0x00056380 File Offset: 0x00054580
	internal static byte[] #=zhg1f_CEyF7Jk(string #=zMN4QVxk=)
	{
		return Encoding.UTF8.GetBytes(#=zMN4QVxk=);
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x00056390 File Offset: 0x00054590
	internal static char[] #=zhYXm8L7UMnjW(byte[] #=zqFvApcI=)
	{
		return Encoding.UTF8.GetChars(#=zqFvApcI=);
	}
}
