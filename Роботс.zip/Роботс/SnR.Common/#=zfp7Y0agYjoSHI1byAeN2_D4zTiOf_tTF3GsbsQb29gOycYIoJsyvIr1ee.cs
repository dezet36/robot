﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x0200023C RID: 572
internal sealed class #=zfp7Y0agYjoSHI1byAeN2_D4zTiOf_tTF3GsbsQb29gOycYIoJsyvIr1eexZweqf1J2LNWTU= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600118D RID: 4493 RVA: 0x000881A4 File Offset: 0x000863A4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z4URhuAh2aIP_ = #=zuJjQ1XU=.#=zH7Kyf1cf3kepnPM4Mg==();
	}

	// Token: 0x0600118E RID: 4494 RVA: 0x000881B4 File Offset: 0x000863B4
	protected override void #=zvb5bnug=()
	{
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		UnitSquadCollection unitSquadCollection2 = new UnitSquadCollection();
		foreach (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ= #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ= in this.#=z4URhuAh2aIP_)
		{
			if (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zq2bPTdY=() == (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs=)1)
			{
				unitSquadCollection.AddUnits(#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zDy8wm$yKq8XD());
			}
			else if (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zq2bPTdY=() == (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs=)2)
			{
				unitSquadCollection2.AddUnits(#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zDy8wm$yKq8XD());
			}
		}
		if (unitSquadCollection.Count > 0)
		{
			string text = this.#=zBsXSanI=.#=zHvbL9Hjs84B2naQl3g$aUP4=(unitSquadCollection);
			text = text.Trim();
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925438), new object[]
				{
					unitSquadCollection.ToStringLabels()
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925385), new object[]
				{
					unitSquadCollection.ToStringLabels(),
					JSONManager.Cut(text)
				});
			}
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925336), Array.Empty<object>());
		}
		if (unitSquadCollection2.Count <= 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924942), Array.Empty<object>());
			return;
		}
		string text2 = this.#=zBsXSanI=.#=zufJ8wE3mcy$qi6zRYxtTYTKDWg8PrwHSOg==(unitSquadCollection2);
		text2 = text2.Trim();
		if (text2.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925040), new object[]
			{
				unitSquadCollection2.ToStringLabels()
			});
			return;
		}
		if (text2.Length > 1000)
		{
			text2 = text2.Substring(0, 1000);
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924997), new object[]
		{
			unitSquadCollection2.ToStringLabels(),
			text2
		});
	}

	// Token: 0x040009CE RID: 2510
	private List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> #=z4URhuAh2aIP_;
}
