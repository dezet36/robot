﻿using System;
using System.Collections.Generic;

// Token: 0x0200026B RID: 619
internal sealed class #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==
{
	// Token: 0x060012AC RID: 4780 RVA: 0x00091A30 File Offset: 0x0008FC30
	public #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==()
	{
		this.#=znXEbLZdw8Xfk(DateTime.MinValue);
		this.#=zmJundSCPROht1yhMEpQS3VI=(0);
		this.#=zwWswYwKvKrX$(new int[4]);
		this.#=zPrx1lcmr9M5YR2wNkA==(0);
		this.#=z3QIAoZP5RnQT0w8FiY3ZWEs=(0);
		this.#=zDPLqTFcZyIVOTZ3wMeAz690=(0);
		this.#=zNuh$yjjtubGUVC9KFccfXhJRGVhk = 0;
		this.#=zdcPg9XzngrqwJb3$MRCZoHs=(null);
	}

	// Token: 0x060012AE RID: 4782 RVA: 0x00091A90 File Offset: 0x0008FC90
	public DateTime #=zNIn_Syjo_kgd()
	{
		return this.#=z49LOn5uSrI2QR5fGINZpGIE=;
	}

	// Token: 0x060012AF RID: 4783 RVA: 0x00091A98 File Offset: 0x0008FC98
	private void #=znXEbLZdw8Xfk(DateTime #=z$Ib9gYQ=)
	{
		this.#=z49LOn5uSrI2QR5fGINZpGIE= = #=z$Ib9gYQ=;
	}

	// Token: 0x060012B0 RID: 4784 RVA: 0x00091AA4 File Offset: 0x0008FCA4
	public int #=zQL4EHGcDV4pf7jtVF80gtmE=()
	{
		return this.#=z24D5KrJZ422vZ34LfNoz8p5Mfymc;
	}

	// Token: 0x060012B1 RID: 4785 RVA: 0x00091AAC File Offset: 0x0008FCAC
	public void #=zmJundSCPROht1yhMEpQS3VI=(int #=z$Ib9gYQ=)
	{
		this.#=z24D5KrJZ422vZ34LfNoz8p5Mfymc = #=z$Ib9gYQ=;
	}

	// Token: 0x060012B2 RID: 4786 RVA: 0x00091AB8 File Offset: 0x0008FCB8
	public int[] #=zbMJWMku61G$Q()
	{
		return this.#=ztoF84BDSmCE87Guq2Q==;
	}

	// Token: 0x060012B3 RID: 4787 RVA: 0x00091AC0 File Offset: 0x0008FCC0
	public void #=zwWswYwKvKrX$(int[] #=z$Ib9gYQ=)
	{
		this.#=ztoF84BDSmCE87Guq2Q== = #=z$Ib9gYQ=;
	}

	// Token: 0x060012B4 RID: 4788 RVA: 0x00091ACC File Offset: 0x0008FCCC
	public int #=zHVllBBIHynsrMuvepQ==()
	{
		return this.#=zY_MCQgbgQAWs1mf5_ULWTAUatG8d;
	}

	// Token: 0x060012B5 RID: 4789 RVA: 0x00091AD4 File Offset: 0x0008FCD4
	public void #=zPrx1lcmr9M5YR2wNkA==(int #=z$Ib9gYQ=)
	{
		this.#=zY_MCQgbgQAWs1mf5_ULWTAUatG8d = #=z$Ib9gYQ=;
	}

	// Token: 0x060012B6 RID: 4790 RVA: 0x00091AE0 File Offset: 0x0008FCE0
	public int #=zGh87EDc1C$LIh14MJDCD1Pw=()
	{
		return this.#=zbt3zjdtzbxwn33vGxFVgUdpwxwmB_Khbvw==;
	}

	// Token: 0x060012B7 RID: 4791 RVA: 0x00091AE8 File Offset: 0x0008FCE8
	public void #=z3QIAoZP5RnQT0w8FiY3ZWEs=(int #=z$Ib9gYQ=)
	{
		this.#=zbt3zjdtzbxwn33vGxFVgUdpwxwmB_Khbvw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060012B8 RID: 4792 RVA: 0x00091AF4 File Offset: 0x0008FCF4
	public int #=znUIObFoF49PcXO7XFHzcPag=()
	{
		return this.#=zpVo0fgefPGinLwe16B0CgxoODRGM;
	}

	// Token: 0x060012B9 RID: 4793 RVA: 0x00091AFC File Offset: 0x0008FCFC
	public void #=zDPLqTFcZyIVOTZ3wMeAz690=(int #=z$Ib9gYQ=)
	{
		this.#=zpVo0fgefPGinLwe16B0CgxoODRGM = #=z$Ib9gYQ=;
	}

	// Token: 0x060012BA RID: 4794 RVA: 0x00091B08 File Offset: 0x0008FD08
	public int #=zsSDs77$0W5eVd$WfMCPFH5o=()
	{
		return this.#=zE_2XDI6GRazGpAR7WvUVpSLP8NMa;
	}

	// Token: 0x060012BB RID: 4795 RVA: 0x00091B10 File Offset: 0x0008FD10
	public void #=zrS59ZtEbgkeqtjvPO76sazQ=(int #=z$Ib9gYQ=)
	{
		this.#=zE_2XDI6GRazGpAR7WvUVpSLP8NMa = #=z$Ib9gYQ=;
	}

	// Token: 0x060012BC RID: 4796 RVA: 0x00091B1C File Offset: 0x0008FD1C
	public DateTime #=zUz3LnE0a7XpsUPo31iaa2Uk=()
	{
		return this.#=zGtLArBpSjrA_4TvyrX64rYzIw61T;
	}

	// Token: 0x060012BD RID: 4797 RVA: 0x00091B24 File Offset: 0x0008FD24
	public void #=zxSSEmYWmFdenM$$xeEU8Txk=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zGtLArBpSjrA_4TvyrX64rYzIw61T = #=z$Ib9gYQ=;
	}

	// Token: 0x060012BE RID: 4798 RVA: 0x00091B30 File Offset: 0x0008FD30
	public List<#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==> #=z4sXt66V1ZksHjpTHIZIhgos=()
	{
		return this.#=zcDcKNSrYY5knWGyglhaAW531A6KqJ$p1eg==;
	}

	// Token: 0x060012BF RID: 4799 RVA: 0x00091B38 File Offset: 0x0008FD38
	public void #=zdcPg9XzngrqwJb3$MRCZoHs=(List<#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==> #=z$Ib9gYQ=)
	{
		this.#=zcDcKNSrYY5knWGyglhaAW531A6KqJ$p1eg== = #=z$Ib9gYQ=;
	}

	// Token: 0x060012C0 RID: 4800 RVA: 0x00091B44 File Offset: 0x0008FD44
	public void #=zsRV1Asc=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		try
		{
			this.#=zmJundSCPROht1yhMEpQS3VI=(#=zuJjQ1XU=.#=ztY2Wai5zsO_u1Ct5WFVJPR0=());
			int[] array = #=zuJjQ1XU=.#=z5bKdgpPzNS6dKj$3ew==();
			this.#=zbMJWMku61G$Q()[0] = #=zuJjQ1XU=.#=z9XuZ7IMaxkRw();
			this.#=zbMJWMku61G$Q()[1] = #=zuJjQ1XU=.#=z9XuZ7IMaxkRw() - array[0];
			this.#=zbMJWMku61G$Q()[2] = #=zuJjQ1XU=.#=zxGBLmFv_i0a2$PP1Jw==();
			this.#=zbMJWMku61G$Q()[3] = #=zuJjQ1XU=.#=zxGBLmFv_i0a2$PP1Jw==() - array[1];
			List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = #=zuJjQ1XU=.#=zn3lmtbueoIUfikFOI78eK$8=();
			if (this.#=z4sXt66V1ZksHjpTHIZIhgos=() != null)
			{
				for (int i = this.#=z4sXt66V1ZksHjpTHIZIhgos=().Count - 1; i >= 0; i--)
				{
					if (this.#=z4sXt66V1ZksHjpTHIZIhgos=()[i].#=zdCLobkmOr3TR() != (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2)
					{
						this.#=z4sXt66V1ZksHjpTHIZIhgos=().RemoveAt(i);
					}
				}
			}
			int num = #=zuJjQ1XU=.#=zI7RuwYzM63XbHtSFc9y0Q831FDC2();
			if (num != this.#=zNuh$yjjtubGUVC9KFccfXhJRGVhk)
			{
				object[] array2 = #=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=z_WwoAi$Ptgio();
				for (int j = 0; j < array2.Length; j++)
				{
					#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== = #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zi1hFJwI=((Dictionary<string, object>)array2[j]);
					if (#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==() == #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zhw2gpAK2vADM() == #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zPHMvvJ8=() >= DateTime.Now - TimeSpan.FromMinutes((double)#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zWX$wxDSpl8I34r377OFpICFEu4zI) && (#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4 || #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)6))
					{
						bool flag = false;
						if (this.#=z4sXt66V1ZksHjpTHIZIhgos=() != null)
						{
							for (int k = 0; k < this.#=z4sXt66V1ZksHjpTHIZIhgos=().Count; k++)
							{
								if (this.#=z4sXt66V1ZksHjpTHIZIhgos=()[k].#=zMuFMjGQ=() == #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zMuFMjGQ=())
								{
									flag = true;
									break;
								}
							}
						}
						if (!flag)
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z8qXL1ylUPNMf9r2mDQ== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=zuJjQ1XU=.#=zQ4wZnctPyyRO(), #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z9OkNmQe3tJa6tN2MkA==().ToString(), true, #=zuJjQ1XU=.#=z$2ijYGRf0FB5());
							#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== item = new #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==(#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zMuFMjGQ=(), (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2, #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zPHMvvJ8=(), #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zzasQXAPWhOif(), #=z8qXL1ylUPNMf9r2mDQ==);
							if (this.#=z4sXt66V1ZksHjpTHIZIhgos=() == null)
							{
								this.#=zdcPg9XzngrqwJb3$MRCZoHs=(new List<#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==>());
							}
							this.#=z4sXt66V1ZksHjpTHIZIhgos=().Add(item);
						}
					}
				}
				this.#=zNuh$yjjtubGUVC9KFccfXhJRGVhk = num;
			}
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in list)
			{
				#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=zRJow$Yqgnkyr = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() == DateTime.MinValue) ? ((#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)0) : ((#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)1);
				#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== item2 = new #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=(), #=zRJow$Yqgnkyr, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==(), #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif(), #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zM_$fq$IfjkuY());
				if (this.#=z4sXt66V1ZksHjpTHIZIhgos=() == null)
				{
					this.#=zdcPg9XzngrqwJb3$MRCZoHs=(new List<#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==>());
				}
				this.#=z4sXt66V1ZksHjpTHIZIhgos=().Add(item2);
			}
			if (this.#=z4sXt66V1ZksHjpTHIZIhgos=() != null)
			{
				if (this.#=z4sXt66V1ZksHjpTHIZIhgos=().Count == 0)
				{
					this.#=zdcPg9XzngrqwJb3$MRCZoHs=(null);
				}
				else
				{
					this.#=z4sXt66V1ZksHjpTHIZIhgos=().Sort();
				}
			}
			this.#=zu7T_8nF2JRsQdbFe5A==(#=zuJjQ1XU=);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zY$pvpstqHPJzppOpm5pa2HJPtuI4(#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B(), #=zuJjQ1XU=.#=zQ4wZnctPyyRO(), #=zuJjQ1XU=.#=z$2ijYGRf0FB5());
			this.#=znXEbLZdw8Xfk(DateTime.Now);
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
	}

	// Token: 0x060012C1 RID: 4801 RVA: 0x00091E88 File Offset: 0x00090088
	internal void #=zu7T_8nF2JRsQdbFe5A==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		int #=z$Ib9gYQ=;
		int #=z$Ib9gYQ=2;
		int #=z$Ib9gYQ=3;
		#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zu7T_8nF2JRsQdbFe5A==(#=zuJjQ1XU=, out #=z$Ib9gYQ=, out #=z$Ib9gYQ=2, out #=z$Ib9gYQ=3);
		this.#=zPrx1lcmr9M5YR2wNkA==(#=z$Ib9gYQ=);
		this.#=z3QIAoZP5RnQT0w8FiY3ZWEs=(#=z$Ib9gYQ=2);
		this.#=zDPLqTFcZyIVOTZ3wMeAz690=(#=z$Ib9gYQ=3);
	}

	// Token: 0x060012C2 RID: 4802 RVA: 0x00091EB8 File Offset: 0x000900B8
	private static void #=zu7T_8nF2JRsQdbFe5A==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=, out int #=zkUUQjX4q7JO$qHGaUw==, out int #=zOBHQHABXd2oGkFfbeuZaoXg=, out int #=zdcQ2txPVdCiwP0fbeQ==)
	{
		#=zkUUQjX4q7JO$qHGaUw== = #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxLocationLevel;
		#=zOBHQHABXd2oGkFfbeuZaoXg= = #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxFutureLocationLevel;
		#=zdcQ2txPVdCiwP0fbeQ== = #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxTeamLocationLevel;
		foreach (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV in #=zuJjQ1XU=.#=zR7HYJ3$A4H5B().#=zCrb91gPnuXNh())
		{
			if (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Attack || #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Defense)
			{
				if (#=zkUUQjX4q7JO$qHGaUw== < #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du())
				{
					#=zkUUQjX4q7JO$qHGaUw== = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du();
				}
			}
			else if ((#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackFuture || #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseFuture) && #=zOBHQHABXd2oGkFfbeuZaoXg= < #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du())
			{
				#=zOBHQHABXd2oGkFfbeuZaoXg= = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du();
			}
		}
		if (#=zuJjQ1XU=.#=zRuSBNTbcss_PPA9pNg==().#=zdr5FzsyK0qvK() > 0)
		{
			int num = 1;
			bool flag = false;
			foreach (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2 in #=zuJjQ1XU=.#=zR7HYJ3$A4H5B().#=zmtBGC_gcapNu())
			{
				if ((#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackTeam || #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseTeam) && num <= #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2.#=zvnZc$RhG_1Du())
				{
					if (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2.#=zTC2S$D65wv_r() > DateTime.Now - TimeSpan.FromDays(21.0))
					{
						num = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV2.#=zvnZc$RhG_1Du() + 1;
					}
					else
					{
						flag = true;
					}
				}
			}
			if (num > 1 || flag)
			{
				#=zdcQ2txPVdCiwP0fbeQ== = num;
			}
		}
		else
		{
			#=zdcQ2txPVdCiwP0fbeQ== = 0;
		}
		if (#=zkUUQjX4q7JO$qHGaUw== != #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxLocationLevel)
		{
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxLocationLevel = #=zkUUQjX4q7JO$qHGaUw==;
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
		}
		if (#=zOBHQHABXd2oGkFfbeuZaoXg= != #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxFutureLocationLevel)
		{
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxFutureLocationLevel = #=zOBHQHABXd2oGkFfbeuZaoXg=;
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
		}
		if (#=zdcQ2txPVdCiwP0fbeQ== != #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxTeamLocationLevel)
		{
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxTeamLocationLevel = #=zdcQ2txPVdCiwP0fbeQ==;
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
		}
	}

	// Token: 0x060012C3 RID: 4803 RVA: 0x000920E4 File Offset: 0x000902E4
	internal static void #=zhxkCgoMhDoMmRxUjA5MfY_g=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
		int i = 0;
		while (i < list.Count)
		{
			#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== = list[i];
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zd$BbM3Y=() > 40000 && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zd$BbM3Y=() < 41000)
			{
				if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zd$BbM3Y=() - 40000 < #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxLocationLevel)
				{
					#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxLocationLevel = 1;
					#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxFutureLocationLevel = 1;
					#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().MaxTeamLocationLevel = 1;
					int num;
					int num2;
					int num3;
					#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zu7T_8nF2JRsQdbFe5A==(#=zuJjQ1XU=, out num, out num2, out num3);
					return;
				}
				break;
			}
			else
			{
				i++;
			}
		}
	}

	// Token: 0x04000ABF RID: 2751
	public static int #=zWX$wxDSpl8I34r377OFpICFEu4zI = 15;

	// Token: 0x04000AC0 RID: 2752
	private DateTime #=z49LOn5uSrI2QR5fGINZpGIE=;

	// Token: 0x04000AC1 RID: 2753
	private int #=z24D5KrJZ422vZ34LfNoz8p5Mfymc;

	// Token: 0x04000AC2 RID: 2754
	private int[] #=ztoF84BDSmCE87Guq2Q==;

	// Token: 0x04000AC3 RID: 2755
	private int #=zY_MCQgbgQAWs1mf5_ULWTAUatG8d;

	// Token: 0x04000AC4 RID: 2756
	private int #=zbt3zjdtzbxwn33vGxFVgUdpwxwmB_Khbvw==;

	// Token: 0x04000AC5 RID: 2757
	private int #=zpVo0fgefPGinLwe16B0CgxoODRGM;

	// Token: 0x04000AC6 RID: 2758
	private int #=zE_2XDI6GRazGpAR7WvUVpSLP8NMa;

	// Token: 0x04000AC7 RID: 2759
	private DateTime #=zGtLArBpSjrA_4TvyrX64rYzIw61T;

	// Token: 0x04000AC8 RID: 2760
	private int #=zNuh$yjjtubGUVC9KFccfXhJRGVhk;

	// Token: 0x04000AC9 RID: 2761
	private List<#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==> #=zcDcKNSrYY5knWGyglhaAW531A6KqJ$p1eg==;

	// Token: 0x0200026C RID: 620
	internal sealed class #=zcvzmwA_SR1dxtNktUQ== : IComparable
	{
		// Token: 0x060012C4 RID: 4804 RVA: 0x00092190 File Offset: 0x00090390
		public #=zcvzmwA_SR1dxtNktUQ==(int #=zAk8mKBk=, #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=zRJow$Yqgnkyr, DateTime #=z7iJcLPfMecrfYDQL0w==, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zvRLj9WQ=, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z8qXL1ylUPNMf9r2mDQ==)
		{
			this.#=zbsxKkj4=(#=zAk8mKBk=);
			this.#=zBtGwB9YO2NAg(#=zRJow$Yqgnkyr);
			this.#=zLkO3VEKrN2mHIZiieQ==(#=z7iJcLPfMecrfYDQL0w==);
			this.#=zzQwUIEs=(#=zvRLj9WQ=);
			this.#=zxIFzblctriXEHbOrkQ==(#=z8qXL1ylUPNMf9r2mDQ==);
		}

		// Token: 0x060012C5 RID: 4805 RVA: 0x000921C0 File Offset: 0x000903C0
		public int #=zMuFMjGQ=()
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}

		// Token: 0x060012C6 RID: 4806 RVA: 0x000921C8 File Offset: 0x000903C8
		public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
		}

		// Token: 0x060012C7 RID: 4807 RVA: 0x000921D4 File Offset: 0x000903D4
		public #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=zdCLobkmOr3TR()
		{
			return this.#=zqLDTtWRMOzZp7BRSQw==;
		}

		// Token: 0x060012C8 RID: 4808 RVA: 0x000921DC File Offset: 0x000903DC
		public void #=zBtGwB9YO2NAg(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=z$Ib9gYQ=)
		{
			this.#=zqLDTtWRMOzZp7BRSQw== = #=z$Ib9gYQ=;
		}

		// Token: 0x060012C9 RID: 4809 RVA: 0x000921E8 File Offset: 0x000903E8
		public DateTime #=zL4D9WC8RTH921DofgQ==()
		{
			return this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;
		}

		// Token: 0x060012CA RID: 4810 RVA: 0x000921F0 File Offset: 0x000903F0
		public void #=zLkO3VEKrN2mHIZiieQ==(DateTime #=z$Ib9gYQ=)
		{
			this.#=znkGjlUwqxSsB6YjdnQGfI4LZ68VD = #=z$Ib9gYQ=;
		}

		// Token: 0x060012CB RID: 4811 RVA: 0x000921FC File Offset: 0x000903FC
		public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zq2bPTdY=()
		{
			return this.#=zmgOIL9ya65ae7QIXVQ==;
		}

		// Token: 0x060012CC RID: 4812 RVA: 0x00092204 File Offset: 0x00090404
		public void #=zzQwUIEs=(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=z$Ib9gYQ=)
		{
			this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x060012CD RID: 4813 RVA: 0x00092210 File Offset: 0x00090410
		public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zuq_UHDkYFBLsH2rvOw==()
		{
			return this.#=zYvOeVf7rA37mTVOjG$UCaby52HP_;
		}

		// Token: 0x060012CE RID: 4814 RVA: 0x00092218 File Offset: 0x00090418
		public void #=zxIFzblctriXEHbOrkQ==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z$Ib9gYQ=)
		{
			this.#=zYvOeVf7rA37mTVOjG$UCaby52HP_ = #=z$Ib9gYQ=;
		}

		// Token: 0x060012CF RID: 4815 RVA: 0x00092224 File Offset: 0x00090424
		public int CompareTo(object #=zaC5KqYXd0EezDxDmkA==)
		{
			if (!(#=zaC5KqYXd0EezDxDmkA== is #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==))
			{
				return 0;
			}
			#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ== #=zcvzmwA_SR1dxtNktUQ== = #=zaC5KqYXd0EezDxDmkA== as #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==;
			if (this.#=zdCLobkmOr3TR() != #=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR())
			{
				return this.#=zdCLobkmOr3TR().CompareTo(#=zcvzmwA_SR1dxtNktUQ==.#=zdCLobkmOr3TR());
			}
			if (this.#=zdCLobkmOr3TR() == (#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz)2)
			{
				return -this.#=zL4D9WC8RTH921DofgQ==().CompareTo(#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==());
			}
			return this.#=zL4D9WC8RTH921DofgQ==().CompareTo(#=zcvzmwA_SR1dxtNktUQ==.#=zL4D9WC8RTH921DofgQ==());
		}

		// Token: 0x04000ACA RID: 2762
		private int #=zdw4aIlzRxu5LWjlGFw==;

		// Token: 0x04000ACB RID: 2763
		private #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zcvzmwA_SR1dxtNktUQ==.#=zBp8AqDWk_wpz #=zqLDTtWRMOzZp7BRSQw==;

		// Token: 0x04000ACC RID: 2764
		private DateTime #=znkGjlUwqxSsB6YjdnQGfI4LZ68VD;

		// Token: 0x04000ACD RID: 2765
		private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zmgOIL9ya65ae7QIXVQ==;

		// Token: 0x04000ACE RID: 2766
		private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zYvOeVf7rA37mTVOjG$UCaby52HP_;

		// Token: 0x0200026D RID: 621
		internal enum #=zBp8AqDWk_wpz
		{

		}
	}
}
