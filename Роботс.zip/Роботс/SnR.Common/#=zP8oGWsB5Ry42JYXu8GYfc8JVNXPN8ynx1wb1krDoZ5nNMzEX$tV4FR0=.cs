﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000176 RID: 374
internal sealed class #=zP8oGWsB5Ry42JYXu8GYfc8JVNXPN8ynx1wb1krDoZ5nNMzEX$tV4FR0= : #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU
{
	// Token: 0x06000A0B RID: 2571 RVA: 0x00050664 File Offset: 0x0004E864
	public #=zP8oGWsB5Ry42JYXu8GYfc8JVNXPN8ynx1wb1krDoZ5nNMzEX$tV4FR0=(int #=zAk8mKBk=, Dictionary<string, object> #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2) : base(#=zAk8mKBk=, #=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z4gtQ2tO_qwcBOWpWuNN70yaNuNa2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071060));
		this.#=zIaGGDzQ=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0));
		this.#=zKHQ0BifFBUDT(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		base.#=zX6Imgh3oJ9uf(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071037), 0));
	}

	// Token: 0x06000A0C RID: 2572 RVA: 0x000506D0 File Offset: 0x0004E8D0
	public int #=zd$BbM3Y=()
	{
		return this.#=z7Xrwc11cWxGe$3RbFQ==;
	}

	// Token: 0x06000A0D RID: 2573 RVA: 0x000506D8 File Offset: 0x0004E8D8
	public void #=zIaGGDzQ=(int #=z$Ib9gYQ=)
	{
		this.#=z7Xrwc11cWxGe$3RbFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A0E RID: 2574 RVA: 0x000506E4 File Offset: 0x0004E8E4
	public int #=zLEh48lU$jhVz()
	{
		return this.#=z4HE6wN4t$YNNAL52hA==;
	}

	// Token: 0x06000A0F RID: 2575 RVA: 0x000506EC File Offset: 0x0004E8EC
	public void #=zKHQ0BifFBUDT(int #=z$Ib9gYQ=)
	{
		this.#=z4HE6wN4t$YNNAL52hA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040005BF RID: 1471
	private int #=z7Xrwc11cWxGe$3RbFQ==;

	// Token: 0x040005C0 RID: 1472
	private int #=z4HE6wN4t$YNNAL52hA==;
}
