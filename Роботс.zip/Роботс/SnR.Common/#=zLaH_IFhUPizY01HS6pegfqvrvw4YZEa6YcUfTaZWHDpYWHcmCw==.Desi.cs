﻿// Token: 0x0200014C RID: 332
internal sealed partial class #=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw== : global::System.Windows.Forms.Form
{
	// Token: 0x060008C3 RID: 2243 RVA: 0x0004570C File Offset: 0x0004390C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040004F9 RID: 1273
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
