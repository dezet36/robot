﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x0200025F RID: 607
internal sealed class #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs : Task
{
	// Token: 0x0600126D RID: 4717 RVA: 0x00090DFC File Offset: 0x0008EFFC
	public #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs(List<string> #=zqr6PrORW_Q9B, string #=z1TUMLauEf$RC, int #=zal_uGJDR5j5ksiE7zg==, int #=zYDryoE5$d7O9RvuX64iLPUwnHC3U, bool #=zCqp9NoPHnIY1LuLW$A==) : base(TaskSources.Manual, TaskSeverities.Urgent, TaskTypes.MassAttackManage, DateTime.Now, TimeSpan.Zero, TimeSpan.FromMinutes(1.0), TimeSpan.FromMinutes(1.0), DateTime.MaxValue, true)
	{
		this.#=zFKyxw$KrE1EN(0);
		this.#=z_P6x_cdpCxhG2xtleA==(#=zqr6PrORW_Q9B);
		this.#=zBhuazCp6A6yf(#=z1TUMLauEf$RC);
		this.#=zDe2mWQn$XLBy_f2Amg==(#=zal_uGJDR5j5ksiE7zg==);
		this.#=zHk5LCqw6IYuuRFa2nI9D12zd8Icg(#=zYDryoE5$d7O9RvuX64iLPUwnHC3U);
		this.#=z6KWfAINr62j$x2MK9A==(#=zCqp9NoPHnIY1LuLW$A== ? ((#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)1) : ((#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)0));
		this.#=ze2PfKFMEWDtV(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>());
		this.#=zKrwD_u4diGwvCHJVdQ==(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i>());
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x00090E88 File Offset: 0x0008F088
	public #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x00090E98 File Offset: 0x0008F098
	public int #=zBRFMv9W0kxd2()
	{
		return this.#=zVgVxzbZ4Z0hTc98zaA==;
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x00090EA0 File Offset: 0x0008F0A0
	public void #=zFKyxw$KrE1EN(int #=z$Ib9gYQ=)
	{
		this.#=zVgVxzbZ4Z0hTc98zaA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x00090EAC File Offset: 0x0008F0AC
	public List<string> #=zOre4g_jCK$pTWlVosQ==()
	{
		return this.#=z6TIK5dwXYas0A2cxRPo19Qt6uker;
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x00090EB4 File Offset: 0x0008F0B4
	public void #=z_P6x_cdpCxhG2xtleA==(List<string> #=z$Ib9gYQ=)
	{
		this.#=z6TIK5dwXYas0A2cxRPo19Qt6uker = #=z$Ib9gYQ=;
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x00090EC0 File Offset: 0x0008F0C0
	public string #=zI0JHwt8spVuO()
	{
		return this.#=z2O2MhpvvUNon9_T9JD0h7fQ=;
	}

	// Token: 0x06001274 RID: 4724 RVA: 0x00090EC8 File Offset: 0x0008F0C8
	public void #=zBhuazCp6A6yf(string #=z$Ib9gYQ=)
	{
		this.#=z2O2MhpvvUNon9_T9JD0h7fQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001275 RID: 4725 RVA: 0x00090ED4 File Offset: 0x0008F0D4
	public int #=zi0WaUTfkdjJMIVEyAg==()
	{
		return this.#=z1fr59c70m___V0lbIRKrI1aGWDp4;
	}

	// Token: 0x06001276 RID: 4726 RVA: 0x00090EDC File Offset: 0x0008F0DC
	public void #=zDe2mWQn$XLBy_f2Amg==(int #=z$Ib9gYQ=)
	{
		this.#=z1fr59c70m___V0lbIRKrI1aGWDp4 = #=z$Ib9gYQ=;
	}

	// Token: 0x06001277 RID: 4727 RVA: 0x00090EE8 File Offset: 0x0008F0E8
	public int #=z3i_XNDE9Pwkn5y0M30IZRnJ145cm()
	{
		return this.#=z6t8GFVJVpnZ$h1yE$goh6Xd9BqVsIK0C8pl_DP4=;
	}

	// Token: 0x06001278 RID: 4728 RVA: 0x00090EF0 File Offset: 0x0008F0F0
	public void #=zHk5LCqw6IYuuRFa2nI9D12zd8Icg(int #=z$Ib9gYQ=)
	{
		this.#=z6t8GFVJVpnZ$h1yE$goh6Xd9BqVsIK0C8pl_DP4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001279 RID: 4729 RVA: 0x00090EFC File Offset: 0x0008F0FC
	public #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr #=zs3hM4e6_G31KBZ9flA==()
	{
		return this.#=zspf3cQi0BNKnO_hZqgCaylE=;
	}

	// Token: 0x0600127A RID: 4730 RVA: 0x00090F04 File Offset: 0x0008F104
	public void #=z6KWfAINr62j$x2MK9A==(#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr #=z$Ib9gYQ=)
	{
		this.#=zspf3cQi0BNKnO_hZqgCaylE= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600127B RID: 4731 RVA: 0x00090F10 File Offset: 0x0008F110
	public List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zDj2G6j0D0dzY()
	{
		return this.#=zps14KQCe4f38XfWnppmKvEM=;
	}

	// Token: 0x0600127C RID: 4732 RVA: 0x00090F18 File Offset: 0x0008F118
	public void #=ze2PfKFMEWDtV(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=z$Ib9gYQ=)
	{
		this.#=zps14KQCe4f38XfWnppmKvEM= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600127D RID: 4733 RVA: 0x00090F24 File Offset: 0x0008F124
	public List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z9lg8rYEayWFsMkjAqA==()
	{
		return this.#=zeUFISYl60Q_JSAoZfA2$CXU=;
	}

	// Token: 0x0600127E RID: 4734 RVA: 0x00090F2C File Offset: 0x0008F12C
	public void #=zKrwD_u4diGwvCHJVdQ==(List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=z$Ib9gYQ=)
	{
		this.#=zeUFISYl60Q_JSAoZfA2$CXU= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600127F RID: 4735 RVA: 0x00090F38 File Offset: 0x0008F138
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		this.#=zFKyxw$KrE1EN(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875572), 0));
		this.#=z_P6x_cdpCxhG2xtleA==(new List<string>());
		object[] array = JSONManager.ExtractArray(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875559));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				this.#=zOre4g_jCK$pTWlVosQ==().Add(Convert.ToString(array[i]));
			}
		}
		this.#=zBhuazCp6A6yf(JSONManager.ExtractString(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875543), string.Empty));
		this.#=zDe2mWQn$XLBy_f2Amg==(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875526), 0));
		this.#=zHk5LCqw6IYuuRFa2nI9D12zd8Icg(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875761), 0));
		this.#=z6KWfAINr62j$x2MK9A==((#=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr)JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875748), 0));
		this.#=ze2PfKFMEWDtV(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>());
		object[] array2 = JSONManager.ExtractArray(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875729));
		for (int j = 0; j < array2.Length; j++)
		{
			this.#=zDj2G6j0D0dzY().Add(this.#=zQIw3Q_PNqroL((Dictionary<string, object>)array2[j]));
		}
		this.#=zKrwD_u4diGwvCHJVdQ==(new List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i>());
		foreach (object[] array4 in JSONManager.ExtractArray(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875715)))
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i(Array.Empty<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=>());
			this.#=z9lg8rYEayWFsMkjAqA==().Add(#=zis3YTWs9V96i);
			for (int l = 0; l < array4.Length; l++)
			{
				#=zis3YTWs9V96i.Add(this.#=zQIw3Q_PNqroL((Dictionary<string, object>)array4[l]));
			}
		}
	}

	// Token: 0x06001280 RID: 4736 RVA: 0x000910BC File Offset: 0x0008F2BC
	public override void UpdateTask(Dictionary<string, object> #=z8e5z318=)
	{
		base.UpdateTask(#=z8e5z318=);
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x1700005A RID: 90
	// (get) Token: 0x06001281 RID: 4737 RVA: 0x000910CC File Offset: 0x0008F2CC
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874444);
		}
	}

	// Token: 0x06001282 RID: 4738 RVA: 0x000910D8 File Offset: 0x0008F2D8
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875572)] = this.#=zBRFMv9W0kxd2();
		object[] array = new object[this.#=zOre4g_jCK$pTWlVosQ==().Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = this.#=zOre4g_jCK$pTWlVosQ==()[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875559)] = array;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875543)] = this.#=zI0JHwt8spVuO();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875526)] = this.#=zi0WaUTfkdjJMIVEyAg==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875761)] = this.#=z3i_XNDE9Pwkn5y0M30IZRnJ145cm();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875748)] = (int)this.#=zs3hM4e6_G31KBZ9flA==();
		object[] array2 = new object[this.#=zDj2G6j0D0dzY().Count];
		for (int j = 0; j < array2.Length; j++)
		{
			array2[j] = this.#=zRQyx2rPmdYXK(this.#=zDj2G6j0D0dzY()[j]);
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875729)] = array2;
		object[] array3 = new object[this.#=z9lg8rYEayWFsMkjAqA==().Count];
		for (int k = 0; k < array3.Length; k++)
		{
			#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i #=zis3YTWs9V96i = this.#=z9lg8rYEayWFsMkjAqA==()[k];
			object[] array4 = new object[#=zis3YTWs9V96i.Count];
			for (int l = 0; l < array4.Length; l++)
			{
				array4[l] = this.#=zRQyx2rPmdYXK(#=zis3YTWs9V96i[l]);
			}
			array3[k] = array4;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875715)] = array3;
		return dictionary;
	}

	// Token: 0x06001283 RID: 4739 RVA: 0x00091278 File Offset: 0x0008F478
	private Dictionary<string, object> #=zRQyx2rPmdYXK(#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=z1_H9FhQ=)
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z1_H9FhQ=.#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z1_H9FhQ=.#=zCCvotbi$42tS()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z1_H9FhQ=.#=zkfqcY3I=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070020),
				#=z1_H9FhQ=.#=zO1FX6YkNZlqlvFZqJg==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875699),
				#=z1_H9FhQ=.#=zj661vGqZTMsoJ4JrPg==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951484),
				#=z1_H9FhQ=.#=zw10jEpGax3aM3DGZDfjgXOQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				#=z1_H9FhQ=.#=zfTB62qendhk_VEy8rw==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
				#=z1_H9FhQ=.#=zY0soxphmGIACbOHy6A==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				#=z1_H9FhQ=.#=zDy8wm$yKq8XD().ToDictionary()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875688),
				#=z1_H9FhQ=.#=zuPMhw87glikS()
			}
		};
	}

	// Token: 0x06001284 RID: 4740 RVA: 0x0009138C File Offset: 0x0008F58C
	private #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zQIw3Q_PNqroL(Dictionary<string, object> #=zJ5GWysk=)
	{
		#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0= #=zBbLKsV0= = new #=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=();
		#=zBbLKsV0=.#=zbsxKkj4=(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		#=zBbLKsV0=.#=ze8TQhOAtefck(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), string.Empty));
		#=zBbLKsV0=.#=zwXKUV2c=(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty));
		#=zBbLKsV0=.#=zAsCgbAN02olKpq2GjA==(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070020), 0));
		#=zBbLKsV0=.#=z6AhOmwNDely78tSumg==(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875699), string.Empty));
		#=zBbLKsV0=.#=zL1nSSuED6_G9CQfsch1Gzg0=(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951484), 0));
		#=zBbLKsV0=.#=zHD9M6IxBLboIezSsHQ==(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
		#=zBbLKsV0=.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
		#=zBbLKsV0=.#=zLNM6_FpNs$Ws(UnitSquadCollection.FromDictionary(JSONManager.ExtractDictionary(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759))));
		#=zBbLKsV0=.#=zQs2eT6ebSpBF(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875688), 0));
		return #=zBbLKsV0=;
	}

	// Token: 0x04000AA3 RID: 2723
	private int #=zVgVxzbZ4Z0hTc98zaA==;

	// Token: 0x04000AA4 RID: 2724
	private List<string> #=z6TIK5dwXYas0A2cxRPo19Qt6uker;

	// Token: 0x04000AA5 RID: 2725
	private string #=z2O2MhpvvUNon9_T9JD0h7fQ=;

	// Token: 0x04000AA6 RID: 2726
	private int #=z1fr59c70m___V0lbIRKrI1aGWDp4;

	// Token: 0x04000AA7 RID: 2727
	private int #=z6t8GFVJVpnZ$h1yE$goh6Xd9BqVsIK0C8pl_DP4=;

	// Token: 0x04000AA8 RID: 2728
	private #=ziYOToYx1Dm4jrpygBfsGluh7jMSUTfzmn75uo0ZRRcqs.#=zUPTPpCQ5cYOr #=zspf3cQi0BNKnO_hZqgCaylE=;

	// Token: 0x04000AA9 RID: 2729
	private List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zBbLKsV0=> #=zps14KQCe4f38XfWnppmKvEM=;

	// Token: 0x04000AAA RID: 2730
	private List<#=zL1gmIyB50yt5dl8Lh9VQZ97gW5Xn1nYrVnu615M$YldV.#=zis3YTWs9V96i> #=zeUFISYl60Q_JSAoZfA2$CXU=;

	// Token: 0x02000260 RID: 608
	public enum #=zUPTPpCQ5cYOr
	{

	}
}
