﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x0200001E RID: 30
internal sealed class #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= : Task
{
	// Token: 0x06000057 RID: 87 RVA: 0x00003BCC File Offset: 0x00001DCC
	public #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=() : base(TaskSources.ManualNotSavable, TaskSeverities.Background, TaskTypes.AutoRobberyTargetsAdd, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false)
	{
		this.#=z8acNyAFALj4Q_Y$LCw==(new List<int[]>());
		this.#=zi8F0nzW98_9V(new List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=>());
		this.#=z2DpfkbUCtA9w(new List<int>());
	}

	// Token: 0x06000058 RID: 88 RVA: 0x00003C24 File Offset: 0x00001E24
	public List<int[]> #=zJeSQPOW6HtWntjFp2g==()
	{
		return this.#=zp4XwYEc52jt4m8OSu88XIvvzT$qZ;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x00003C2C File Offset: 0x00001E2C
	public void #=z8acNyAFALj4Q_Y$LCw==(List<int[]> #=z$Ib9gYQ=)
	{
		this.#=zp4XwYEc52jt4m8OSu88XIvvzT$qZ = #=z$Ib9gYQ=;
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00003C38 File Offset: 0x00001E38
	public List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=> #=znu1Q2M7dE$X2()
	{
		return this.#=zyYHFITdCdMHUDacKHrwXtUM=;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00003C40 File Offset: 0x00001E40
	public void #=zi8F0nzW98_9V(List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=> #=z$Ib9gYQ=)
	{
		this.#=zyYHFITdCdMHUDacKHrwXtUM= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003C4C File Offset: 0x00001E4C
	public List<int> #=zoCWPowk7whj_()
	{
		return this.#=z_MrbE5ND_Ng8vIbWxH6IJM8=;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00003C54 File Offset: 0x00001E54
	public void #=z2DpfkbUCtA9w(List<int> #=z$Ib9gYQ=)
	{
		this.#=z_MrbE5ND_Ng8vIbWxH6IJM8= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000018 RID: 24
	private List<int[]> #=zp4XwYEc52jt4m8OSu88XIvvzT$qZ;

	// Token: 0x04000019 RID: 25
	private List<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=> #=zyYHFITdCdMHUDacKHrwXtUM=;

	// Token: 0x0400001A RID: 26
	private List<int> #=z_MrbE5ND_Ng8vIbWxH6IJM8=;
}
