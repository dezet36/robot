﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000132 RID: 306
internal sealed class #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== : #=zLG6uk$Gz0HYsu5astWupkBlXmaty4YJdWIIUAcw=
{
	// Token: 0x060007BA RID: 1978 RVA: 0x0003E5E0 File Offset: 0x0003C7E0
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060007BB RID: 1979 RVA: 0x0003E5E8 File Offset: 0x0003C7E8
	public void #=zzQwUIEs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007BC RID: 1980 RVA: 0x0003E5F4 File Offset: 0x0003C7F4
	public #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A== #=zo4pctbtCxQ0d()
	{
		return this.#=zq2bPTdY=();
	}

	// Token: 0x060007BD RID: 1981 RVA: 0x0003E5FC File Offset: 0x0003C7FC
	[CompilerGenerated]
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x060007BE RID: 1982 RVA: 0x0003E604 File Offset: 0x0003C804
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060007BF RID: 1983 RVA: 0x0003E610 File Offset: 0x0003C810
	public int #=zMuFMjGQ=()
	{
		return this.#=zq2bPTdY=().Id;
	}

	// Token: 0x060007C0 RID: 1984 RVA: 0x0003E620 File Offset: 0x0003C820
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=zq2bPTdY=().Id;
	}

	// Token: 0x060007C1 RID: 1985 RVA: 0x0003E630 File Offset: 0x0003C830
	public string #=zkfqcY3I=()
	{
		return this.#=zq2bPTdY=().Name;
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x0003E640 File Offset: 0x0003C840
	[CompilerGenerated]
	public DateTime #=zGhmoNZChgwf8()
	{
		return this.#=zrJWzUSI7ettVti1bB38Mz8I=;
	}

	// Token: 0x060007C3 RID: 1987 RVA: 0x0003E648 File Offset: 0x0003C848
	public void #=zdU1a9B$ueh_3(DateTime #=z$Ib9gYQ=)
	{
		this.#=zrJWzUSI7ettVti1bB38Mz8I= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007C4 RID: 1988 RVA: 0x0003E654 File Offset: 0x0003C854
	public bool #=z5kpAZQpjT2b7()
	{
		return this.#=zGhmoNZChgwf8() != DateTime.MinValue;
	}

	// Token: 0x0400048A RID: 1162
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400048B RID: 1163
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x0400048C RID: 1164
	private DateTime #=zrJWzUSI7ettVti1bB38Mz8I=;
}
