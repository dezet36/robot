﻿using System;

// Token: 0x020002A2 RID: 674
internal sealed class #=zoQbOOfZXwfMAZDEEMnMU6Dc= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06001487 RID: 5255 RVA: 0x0009C8C8 File Offset: 0x0009AAC8
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zaLxBrgGRq_lk;
	}

	// Token: 0x06001488 RID: 5256 RVA: 0x0009C8D0 File Offset: 0x0009AAD0
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06001489 RID: 5257 RVA: 0x0009C8D4 File Offset: 0x0009AAD4
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077039);
	}
}
