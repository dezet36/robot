﻿using System;
using System.Collections.Generic;

// Token: 0x020000A8 RID: 168
internal sealed class #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 : List<#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW>
{
	// Token: 0x06000462 RID: 1122 RVA: 0x00025BA0 File Offset: 0x00023DA0
	public void #=z20ohAjI=(object[] #=zeJY$3yxiRLlf)
	{
		if (#=zeJY$3yxiRLlf != null)
		{
			for (int i = 0; i < #=zeJY$3yxiRLlf.Length; i++)
			{
				#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW = new #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW((Dictionary<string, object>)#=zeJY$3yxiRLlf[i]);
				if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW.#=zMuFMjGQ=() != 1000)
				{
					base.Add(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW);
				}
			}
		}
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x00025BE4 File Offset: 0x00023DE4
	public static #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=zi1hFJwI=()
	{
		return #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zvQRf_STy5v8Sm5tuw7Xh278usASc();
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x00025BEC File Offset: 0x00023DEC
	public #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		foreach (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW in this)
		{
			if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW.#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW;
			}
		}
		return null;
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x00025C44 File Offset: 0x00023E44
	public #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=zk$6QZNA=(string #=zAk8mKBk=)
	{
		int #=zAk8mKBk=2;
		if (int.TryParse(#=zAk8mKBk=, out #=zAk8mKBk=2))
		{
			return this.#=zk$6QZNA=(#=zAk8mKBk=2);
		}
		return null;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x00025C64 File Offset: 0x00023E64
	public string #=zC6JIMv4=(int #=zp13pRNQ=)
	{
		#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW = this.#=zk$6QZNA=(#=zp13pRNQ=);
		if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW != null)
		{
			return #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW.#=zkfqcY3I=();
		}
		return #=zp13pRNQ=.ToString();
	}
}
