﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001FB RID: 507
internal sealed class #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==
{
	// Token: 0x06000F9E RID: 3998 RVA: 0x0007A290 File Offset: 0x00078490
	public #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==(Dictionary<string, object> #=z$F_AnZE=)
	{
		this.#=zGxbyCacxZW228T6nRj04llE=(new Dictionary<int, long>());
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=z$F_AnZE=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102));
		if (dictionary != null)
		{
			foreach (string text in dictionary.Keys)
			{
				this.#=zRBNVKQNrlBEoV8o9ZEa1KTQ=()[Convert.ToInt32(text)] = JSONManager.ExtractLong(dictionary, text, 0L);
			}
		}
		this.#=zww1bIAfDoHsKh685NQ==(new Dictionary<string, Dictionary<int, long>>());
		foreach (string key in #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060298).Split(new char[]
		{
			','
		}))
		{
			Dictionary<int, long> dictionary2 = new Dictionary<int, long>();
			this.#=zUhBOqiJ4WrnVpOYYfw==()[key] = dictionary2;
			Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(#=z$F_AnZE=, key);
			if (dictionary3 != null)
			{
				foreach (string text2 in dictionary3.Keys)
				{
					dictionary2[Convert.ToInt32(text2)] = JSONManager.ExtractLong(dictionary3, text2, 0L);
				}
			}
		}
		this.#=zJZN_Lo8LIosxG9yztg==(new Dictionary<int, List<int>>());
		Dictionary<string, object> dictionary4 = JSONManager.ExtractDictionary(#=z$F_AnZE=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
		if (dictionary4 != null)
		{
			foreach (string text3 in dictionary4.Keys)
			{
				object[] array2 = JSONManager.ExtractArray(dictionary4, text3);
				int key2 = Convert.ToInt32(text3);
				List<int> list;
				if (this.#=z93_hvEh1P1n9Glhkxw==().ContainsKey(key2))
				{
					list = this.#=z93_hvEh1P1n9Glhkxw==()[key2];
				}
				else
				{
					list = new List<int>();
					this.#=z93_hvEh1P1n9Glhkxw==().Add(key2, list);
				}
				for (int j = 0; j < array2.Length; j++)
				{
					list.Add(Convert.ToInt32(array2[j]));
				}
			}
		}
	}

	// Token: 0x06000F9F RID: 3999 RVA: 0x0007A4A0 File Offset: 0x000786A0
	public Dictionary<int, long> #=zRBNVKQNrlBEoV8o9ZEa1KTQ=()
	{
		return this.#=zNV6RTolMsGJ9LAWV7r0UK01bwcCL;
	}

	// Token: 0x06000FA0 RID: 4000 RVA: 0x0007A4A8 File Offset: 0x000786A8
	public void #=zGxbyCacxZW228T6nRj04llE=(Dictionary<int, long> #=z$Ib9gYQ=)
	{
		this.#=zNV6RTolMsGJ9LAWV7r0UK01bwcCL = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FA1 RID: 4001 RVA: 0x0007A4B4 File Offset: 0x000786B4
	public Dictionary<string, Dictionary<int, long>> #=zUhBOqiJ4WrnVpOYYfw==()
	{
		return this.#=zEZTlL1dJ3sAMkLZR2r97rRU=;
	}

	// Token: 0x06000FA2 RID: 4002 RVA: 0x0007A4BC File Offset: 0x000786BC
	public void #=zww1bIAfDoHsKh685NQ==(Dictionary<string, Dictionary<int, long>> #=z$Ib9gYQ=)
	{
		this.#=zEZTlL1dJ3sAMkLZR2r97rRU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FA3 RID: 4003 RVA: 0x0007A4C8 File Offset: 0x000786C8
	public Dictionary<int, List<int>> #=z93_hvEh1P1n9Glhkxw==()
	{
		return this.#=zZ9aCIePsKa7fhwryePzVSZ_xvsB7;
	}

	// Token: 0x06000FA4 RID: 4004 RVA: 0x0007A4D0 File Offset: 0x000786D0
	public void #=zJZN_Lo8LIosxG9yztg==(Dictionary<int, List<int>> #=z$Ib9gYQ=)
	{
		this.#=zZ9aCIePsKa7fhwryePzVSZ_xvsB7 = #=z$Ib9gYQ=;
	}

	// Token: 0x040008A7 RID: 2215
	private Dictionary<int, long> #=zNV6RTolMsGJ9LAWV7r0UK01bwcCL;

	// Token: 0x040008A8 RID: 2216
	private Dictionary<string, Dictionary<int, long>> #=zEZTlL1dJ3sAMkLZR2r97rRU=;

	// Token: 0x040008A9 RID: 2217
	private Dictionary<int, List<int>> #=zZ9aCIePsKa7fhwryePzVSZ_xvsB7;
}
