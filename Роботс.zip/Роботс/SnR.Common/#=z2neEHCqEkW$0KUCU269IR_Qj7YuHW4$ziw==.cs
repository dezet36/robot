﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x0200004B RID: 75
internal sealed class #=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw==
{
	// Token: 0x06000244 RID: 580 RVA: 0x000157C0 File Offset: 0x000139C0
	public #=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw==(Dictionary<string, object> #=zSC7PxCoMyjeX$u0GmA==, Dictionary<string, object> #=z$P12ZiX0waGODqRr2IYFD6Y=)
	{
		this.#=zmvJTBCw= = null;
		Dictionary<string, #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==> dictionary = new Dictionary<string, #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==>();
		foreach (string text in #=zSC7PxCoMyjeX$u0GmA==.Keys)
		{
			#=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA== value = new #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==(#=zSC7PxCoMyjeX$u0GmA==, text);
			dictionary.Add(text, value);
			if (this.#=zmvJTBCw= == null)
			{
				this.#=zmvJTBCw= = value;
			}
		}
		this.#=zPlIhfsI= = new Dictionary<int, #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==>();
		foreach (string text2 in #=z$P12ZiX0waGODqRr2IYFD6Y=.Keys)
		{
			int key;
			if (int.TryParse(text2, out key))
			{
				string key2 = Convert.ToString(#=z$P12ZiX0waGODqRr2IYFD6Y=[text2]);
				if (dictionary.ContainsKey(key2))
				{
					this.#=zPlIhfsI=.Add(key, dictionary[key2]);
				}
			}
		}
	}

	// Token: 0x17000003 RID: 3
	[IndexerName("#=zx6APBRk=")]
	public #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA== this[int #=zp13pRNQ=]
	{
		get
		{
			if (this.#=zPlIhfsI=.ContainsKey(#=zp13pRNQ=))
			{
				return this.#=zPlIhfsI=[#=zp13pRNQ=];
			}
			return this.#=zmvJTBCw=;
		}
	}

	// Token: 0x040000B3 RID: 179
	private Dictionary<int, #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA==> #=zPlIhfsI=;

	// Token: 0x040000B4 RID: 180
	private #=zD3QqiXZS0rGfIouxlaV9u$qwLRDHnzC6ZA== #=zmvJTBCw=;
}
