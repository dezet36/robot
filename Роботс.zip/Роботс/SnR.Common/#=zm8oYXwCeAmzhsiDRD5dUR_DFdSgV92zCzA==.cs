﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000285 RID: 645
internal sealed class #=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA==
{
	// Token: 0x06001391 RID: 5009 RVA: 0x00096E98 File Offset: 0x00095098
	public #=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA==(Dictionary<string, object> #=zqWOIwOOgOxLPSbOq1A==)
	{
		this.#=z7pWqDe37KAVG(0);
		this.#=z$4RR7hl0Xqo6(0);
		this.#=zlW_2qAYYgoNXYEyoeA==(false);
		this.#=z2q6xaW8yX4z$bAXuRV9VLZM=(new List<#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy>());
		object[] array = JSONManager.ExtractArray(#=zqWOIwOOgOxLPSbOq1A==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077461));
		if (array != null && array.Length != 0)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)array[array.Length - 1];
			this.#=z7pWqDe37KAVG(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0));
			this.#=z$4RR7hl0Xqo6(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
			this.#=zlW_2qAYYgoNXYEyoeA==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), 0) == 1);
			object[] array2 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061831));
			if (array2 != null)
			{
				foreach (Dictionary<string, object> dictionary2 in array2)
				{
					List<#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy> list = this.#=ziW$yrPvr3I7bo8z5SGvdvTM=();
					#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy #=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy = new #=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy();
					#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy.#=z$4RR7hl0Xqo6(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
					#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy.#=zIR9Xlcg=(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false));
					list.Add(#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy);
				}
			}
		}
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x00096FB0 File Offset: 0x000951B0
	public int #=zQhfndSBYub_c()
	{
		return this.#=zw$imIywZnMmEsuV8ew==;
	}

	// Token: 0x06001393 RID: 5011 RVA: 0x00096FB8 File Offset: 0x000951B8
	public void #=z7pWqDe37KAVG(int #=z$Ib9gYQ=)
	{
		this.#=zw$imIywZnMmEsuV8ew== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x00096FC4 File Offset: 0x000951C4
	public int #=zdr5FzsyK0qvK()
	{
		return this.#=zXTmqRsy_1tm5q_RBgQ==;
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x00096FCC File Offset: 0x000951CC
	public void #=z$4RR7hl0Xqo6(int #=z$Ib9gYQ=)
	{
		this.#=zXTmqRsy_1tm5q_RBgQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x00096FD8 File Offset: 0x000951D8
	public bool #=zmrl6eqcWZUWRULPwOA==()
	{
		return this.#=zwLJMaUQvHQewPFLDRACwTqY=;
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x00096FE0 File Offset: 0x000951E0
	public void #=zlW_2qAYYgoNXYEyoeA==(bool #=z$Ib9gYQ=)
	{
		this.#=zwLJMaUQvHQewPFLDRACwTqY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x00096FEC File Offset: 0x000951EC
	public List<#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy> #=ziW$yrPvr3I7bo8z5SGvdvTM=()
	{
		return this.#=zXQmtbDqPnio_HrmCi6gi10xcYt16;
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x00096FF4 File Offset: 0x000951F4
	public void #=z2q6xaW8yX4z$bAXuRV9VLZM=(List<#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy> #=z$Ib9gYQ=)
	{
		this.#=zXQmtbDqPnio_HrmCi6gi10xcYt16 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x00097000 File Offset: 0x00095200
	public static List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV> #=zv7Rwm9Fcng7g(List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV> #=zrXP4STawIGF7)
	{
		Dictionary<int, List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV>> dictionary = new Dictionary<int, List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV>>();
		int num = 0;
		foreach (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV in #=zrXP4STawIGF7)
		{
			if (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackTeam || #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseTeam)
			{
				if (!dictionary.ContainsKey(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du()))
				{
					dictionary[#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du()] = new List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV>
					{
						#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV
					};
				}
				else
				{
					dictionary[#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du()].Add(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV);
				}
				if (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du() > num)
				{
					num = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zvnZc$RhG_1Du();
				}
			}
		}
		List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV> result = new List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV>();
		for (int i = 1; i <= num; i++)
		{
			if (dictionary.ContainsKey(i) && dictionary[i].Count == 2)
			{
				result = dictionary[i];
				break;
			}
		}
		return result;
	}

	// Token: 0x04000B4F RID: 2895
	private int #=zw$imIywZnMmEsuV8ew==;

	// Token: 0x04000B50 RID: 2896
	private int #=zXTmqRsy_1tm5q_RBgQ==;

	// Token: 0x04000B51 RID: 2897
	private bool #=zwLJMaUQvHQewPFLDRACwTqY=;

	// Token: 0x04000B52 RID: 2898
	private List<#=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy> #=zXQmtbDqPnio_HrmCi6gi10xcYt16;
}
