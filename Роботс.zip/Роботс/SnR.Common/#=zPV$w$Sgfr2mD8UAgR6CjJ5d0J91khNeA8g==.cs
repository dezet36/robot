﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000182 RID: 386
internal sealed class #=zPV$w$Sgfr2mD8UAgR6CjJ5d0J91khNeA8g== : RecordData
{
	// Token: 0x06000AFF RID: 2815 RVA: 0x000554E8 File Offset: 0x000536E8
	public #=zPV$w$Sgfr2mD8UAgR6CjJ5d0J91khNeA8g==(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=z8snpwsaw$imRxg6cFA== = (data[0] == 1);
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x00055514 File Offset: 0x00053714
	public bool #=z$u5NZDTmzb6Y()
	{
		return this.#=z8snpwsaw$imRxg6cFA==;
	}

	// Token: 0x040005E1 RID: 1505
	private bool #=z8snpwsaw$imRxg6cFA==;
}
