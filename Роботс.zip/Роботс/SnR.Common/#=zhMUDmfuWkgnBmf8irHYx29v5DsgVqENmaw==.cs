﻿using System;
using System.Collections.Generic;

// Token: 0x02000252 RID: 594
internal sealed class #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== : Dictionary<int, #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==>
{
	// Token: 0x06001200 RID: 4608 RVA: 0x0008A71C File Offset: 0x0008891C
	public void #=zLikmsNA=(#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zdPovgAA=)
	{
		int count = base.Count;
		foreach (#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== in #=zdPovgAA=.Values)
		{
			if (base.ContainsKey(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_()))
			{
				#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2 = base[#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_()];
				#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2.#=zqoCq5j01dD5w(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==2.#=zlIXJ9$NfUZc_() + #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zlIXJ9$NfUZc_());
			}
			else
			{
				base[#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_()] = new #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_(), #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zuFPZLKs=(), #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zzasQXAPWhOif(), #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zlIXJ9$NfUZc_());
			}
		}
	}
}
