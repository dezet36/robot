﻿using System;
using System.Collections.Generic;
using System.Linq;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x0200014E RID: 334
internal sealed class #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=
{
	// Token: 0x060008CD RID: 2253 RVA: 0x00045DE0 File Offset: 0x00043FE0
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zSJCXgrtDT$p4yz2CyjK3UsF4gylz = false;
		this.#=zefqXUipXk_kZ = false;
		this.#=zyNa48o$QnCSAP$EskIOIm0M= = false;
		this.#=zm2oSGGagu94wBmQRHpr0kCWxYA0bE$fjRA== = null;
		this.#=z80Ienm4pN63RdJiXkosEq$4= = null;
		this.#=zZ3V8UwudWrFd = null;
		this.#=z9aXV16k7tKjznITfJQ== = new List<int>();
		this.#=zkr0fQ5KhviB40pIlEgkA6VU= = new List<int>();
	}

	// Token: 0x060008CF RID: 2255 RVA: 0x00045E48 File Offset: 0x00044048
	private static int #=zz4YK2yA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zYgvZuBwR$a1C() * 100000000 + #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=();
	}

	// Token: 0x060008D0 RID: 2256 RVA: 0x00045E64 File Offset: 0x00044064
	public static #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=z0l3cFRQ=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		if (#=z8StzeqE=.#=zjV_wsuvJ0R_B() == null)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984217), Array.Empty<object>());
		}
		object obj;
		if (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85 == null)
		{
			obj = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85 == null)
				{
					#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85 = new Dictionary<int, #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=>();
				}
			}
		}
		int key = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zz4YK2yA=(#=z8StzeqE=);
		if (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85.ContainsKey(key))
		{
			return #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85[key];
		}
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=(#=z8StzeqE=);
		obj = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zSV4$mlFB34WM;
		lock (obj)
		{
			if (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85.ContainsKey(key))
			{
				#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85[key];
			}
			else
			{
				#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85[key] = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=;
			}
		}
		return #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=;
	}

	// Token: 0x060008D1 RID: 2257 RVA: 0x00045F4C File Offset: 0x0004414C
	public static void #=z1Wntp_4=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		object obj = #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zSV4$mlFB34WM;
		lock (obj)
		{
			if (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85 != null)
			{
				#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zRg2AoLvWNf85.Remove(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zz4YK2yA=(#=z8StzeqE=));
			}
		}
	}

	// Token: 0x060008D2 RID: 2258 RVA: 0x00045FA0 File Offset: 0x000441A0
	private static bool #=zVqWUo1dHlOLVzsObjA==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zQhApCGmlHqRA)
	{
		return #=zQhApCGmlHqRA.#=znqqYiI0yKfELaxv8MQ==() != ProphecyTypes.NotProphecy || #=zQhApCGmlHqRA.#=zXuw1agBmq5jc() != DateTime.MinValue;
	}

	// Token: 0x060008D3 RID: 2259 RVA: 0x00045FC4 File Offset: 0x000441C4
	private static bool #=za7$3VpLfPDzHJOtHHQ==(int #=zp13pRNQ=, int #=z4UDysxM=)
	{
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=().#=zk$6QZNA=(#=zp13pRNQ=);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF != null)
		{
			TimeSpan t = #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zwX6NTlM=(1);
			if (t != TimeSpan.Zero)
			{
				return t <= TimeSpan.FromMinutes(5.0);
			}
		}
		return true;
	}

	// Token: 0x060008D4 RID: 2260 RVA: 0x0004600C File Offset: 0x0004420C
	private static bool #=zID6YLkwkuPSyn6$GYqZha4w=(int #=zp13pRNQ=, int #=z5w6HcG4=, int #=z4UDysxM=)
	{
		return #=zp13pRNQ= == 152 && #=z5w6HcG4= == 2;
	}

	// Token: 0x060008D5 RID: 2261 RVA: 0x0004601C File Offset: 0x0004421C
	private static bool #=zG2qBwWzYTYUiTr7WqsrBtOvqoXAzzn1Teg==(int #=zp13pRNQ=, int #=z5w6HcG4=)
	{
		if (#=z5w6HcG4= == 1)
		{
			return new List<int>
			{
				1050,
				1051,
				1052,
				1072,
				1076,
				1058,
				1059,
				1060
			}.Contains(#=zp13pRNQ=);
		}
		return #=z5w6HcG4= == 2 && #=zp13pRNQ= == 1059;
	}

	// Token: 0x060008D6 RID: 2262 RVA: 0x000460A0 File Offset: 0x000442A0
	private static bool #=z0El3lx1wuS$i4_c93RbTbcA=(int #=zp13pRNQ=, int #=z4UDysxM=)
	{
		return new List<int>
		{
			1,
			2,
			13,
			17
		}.Contains(#=zp13pRNQ=) && #=z4UDysxM= == 1;
	}

	// Token: 0x060008D7 RID: 2263 RVA: 0x000460D4 File Offset: 0x000442D4
	private static bool #=zjq24X9495Nqe4b9gWin4DOGnyh7Q(int #=z5w6HcG4=, Dictionary<string, object> #=zol$M4yYkxrZTgJ6LIA==)
	{
		return #=z5w6HcG4= <= 5 && !#=zol$M4yYkxrZTgJ6LIA==.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)) && !#=zol$M4yYkxrZTgJ6LIA==.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094));
	}

	// Token: 0x060008D8 RID: 2264 RVA: 0x00046104 File Offset: 0x00044304
	private bool #=zQUqkQ$zzR07hdRyxnAiejJg=()
	{
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = this.#=zeYLQo2n2g2lR;
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i].#=zd$BbM3Y=() == 900)
			{
				return false;
			}
		}
		#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = this.#=zJF2YTStZkxdpBvijgveKmkY=.#=zk$6QZNA=(1076);
		return #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null && #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() > 0;
	}

	// Token: 0x060008D9 RID: 2265 RVA: 0x00046160 File Offset: 0x00044360
	public void #=z20ohAjI=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zVNqezYTad3Gx, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z8StzeqE= = #=zVNqezYTad3Gx;
		this.#=zBsXSanI= = #=zuJjQ1XU=.#=z$2ijYGRf0FB5();
		this.#=zG2wnL_q7IxpD = this.#=zBsXSanI=.#=zI4J7zo5ZdOzg();
		this.#=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		this.#=zJuQW8gI= = #=zuJjQ1XU=.#=zZan5aKOWyPR5();
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zJHP2CeDqtLIN = #=zuJjQ1XU=.#=z5bKdgpPzNS6dKj$3ew==();
		this.#=zeYLQo2n2g2lR = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
		this.#=zvPVvZaDW5sGehlg4AA== = #=zuJjQ1XU=.#=zOo2ORcNoE4PzlDAS9fQ8Rc8=();
		this.#=zCCdwo8AGZiustnyqjw8wZSs= = #=zuJjQ1XU=.#=zVB$f6ofgIEHftVz7HWepTzs=();
		this.#=zXi9vZ5Ltb$swzaKUNQ== = #=zuJjQ1XU=.#=zH7Kyf1cf3kepnPM4Mg==();
		this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq = #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru();
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=z3yL5bKs= = #=zuJjQ1XU=.#=z_tcU3ov4mZ9V();
		this.#=z6Bha1HM= = #=zuJjQ1XU=.#=z6Kl4FbeUhsIC();
		this.#=zbGFpMLw= = #=zuJjQ1XU=.#=zR7HYJ3$A4H5B();
		this.#=zF5ZHDos= = #=zuJjQ1XU=.#=z0jPLsvetj9_C();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=ztiB995TsnwxE = #=zuJjQ1XU=.#=zFRCk0rwJNk$_();
		this.#=zbkd1_SL26Bt5 = #=zuJjQ1XU=.#=zTbkv095gWozyg_xVnw==();
	}

	// Token: 0x060008DA RID: 2266 RVA: 0x0004628C File Offset: 0x0004448C
	public void #=zPp7Q6VI=(out bool #=zMkyGpF0=)
	{
		this.#=zefqXUipXk_kZ = (this.#=zJHP2CeDqtLIN[0] == 0);
		this.#=zyNa48o$QnCSAP$EskIOIm0M= = (Enumerable.Count<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>(this.#=zJF2YTStZkxdpBvijgveKmkY=, new Func<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, bool>(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=.#=zLkw0NRU=.#=zCGuIpYkw2u_u$oXlGQ==)) > 0);
		#=zMkyGpF0= = !this.#=zEppqk7hICtTubqryAg==();
	}

	// Token: 0x060008DB RID: 2267 RVA: 0x000462E8 File Offset: 0x000444E8
	private bool #=zEppqk7hICtTubqryAg==()
	{
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = this.#=zeYLQo2n2g2lR;
		bool flag = false;
		bool flag2 = false;
		for (int i = 0; i < list.Count; i++)
		{
			#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== = list[i];
			if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zVqWUo1dHlOLVzsObjA==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==))
			{
				try
				{
					if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=() > 0)
					{
						if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zosN4hoVyBAOs())
						{
							this.#=zBsXSanI=.#=z5zbVlDidbmAsW3XxUg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=());
							this.#=zRFJsn75_agg2(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==);
							flag = true;
						}
						else if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zLg_4gHQfENBn() == 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983882), new object[]
							{
								#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
							});
							this.#=zBsXSanI=.#=z5zbVlDidbmAsW3XxUg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=());
							this.#=zBsXSanI=.#=zEoRJ9iFCtj0AXzcGqw==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=());
						}
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
				}
			}
		}
		if (flag)
		{
			return true;
		}
		for (int j = 0; j < list.Count; j++)
		{
			#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2 = list[j];
			try
			{
				if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zVqWUo1dHlOLVzsObjA==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2))
				{
					if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zRTKkIHydRtAD().Count > 0)
					{
						bool flag3 = true;
						for (int k = 0; k < #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zRTKkIHydRtAD().Count; k++)
						{
							#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4= #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4= = #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zRTKkIHydRtAD()[k];
							#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE= #=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE= = #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zq2bPTdY=();
							#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=ztIeE$PLGQDn;
							switch (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)
							{
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)1:
								#=ztIeE$PLGQDn = this.#=zxu4d6zR58PTTCnBCQw==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2, #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=);
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)2:
								if (#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du() == 1)
								{
									if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=za7$3VpLfPDzHJOtHHQ==(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=()))
									{
										#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
									}
									else
									{
										#=ztIeE$PLGQDn = this.#=zE2KNY_74G2UnhjaQhg==(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=(), false);
									}
								}
								else if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zID6YLkwkuPSyn6$GYqZha4w=(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=()))
								{
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								else
								{
									#=ztIeE$PLGQDn = this.#=zHHRavnCMJCruk4jadQ==(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=());
								}
								if (#=ztIeE$PLGQDn == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1)
								{
									this.#=zefqXUipXk_kZ = true;
								}
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)3:
								if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zG2qBwWzYTYUiTr7WqsrBtOvqoXAzzn1Teg==(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du()))
								{
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								else
								{
									#=ztIeE$PLGQDn = this.#=zpLdQfRUBazX9CEFOoYPp7YwdL22R(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du());
								}
								if (#=ztIeE$PLGQDn == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1)
								{
									this.#=zyNa48o$QnCSAP$EskIOIm0M= = true;
								}
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)4:
								if (!#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=z0El3lx1wuS$i4_c93RbTbcA=(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=()))
								{
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								else
								{
									#=ztIeE$PLGQDn = this.#=znqoJ3OqpnIL6CsHLdfgFcHk=(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), this.#=zlhLE8UQVU0AG);
								}
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)5:
								if (#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du() > 5)
								{
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								else
								{
									#=ztIeE$PLGQDn = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du());
								}
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)6:
								#=ztIeE$PLGQDn = this.#=zhwIPDZYrXdkNuPPycw==((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4());
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)7:
								#=ztIeE$PLGQDn = this.#=zsE_ICZcUqsrpxGEQax4PCgD3lUiY(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=z52UEjEjaH4e3(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zKh04cf8=());
								break;
							case (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)8:
								#=ztIeE$PLGQDn = this.#=z0Z2CahuxInzwkHHXKeZpzKs=(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zvnZc$RhG_1Du());
								break;
							default:
								if (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE= != (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)99)
								{
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								else
								{
									int num = #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zFMDiymuLQ7_4();
									if (num <= 20)
									{
										if (num == 1)
										{
											this.#=z$EftBNisn1Ir();
											#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
											break;
										}
										switch (num)
										{
										case 11:
											this.#=zjbuCOMhpd_irbLsxRXs9G80=();
											#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
											goto IL_39D;
										case 12:
											#=ztIeE$PLGQDn = this.#=zmkepM5vE$xtKMyz13rAaU6vy1y0vs01r$A==(this.#=zlhLE8UQVU0AG);
											goto IL_39D;
										case 13:
										case 14:
											break;
										case 15:
											this.#=zhkBVzZjlpeZdR6YmNHTrwBE=();
											#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
											goto IL_39D;
										default:
											if (num == 20)
											{
												#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
												goto IL_39D;
											}
											break;
										}
									}
									else if (num <= 27)
									{
										if (num == 21)
										{
											this.#=zj$gEnjsgsOnRt28WPoJRSR0=();
											#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
											break;
										}
										if (num == 27)
										{
											#=ztIeE$PLGQDn = this.#=zwv8V1LCmiaPSFlMFIdFmHDTmcacR();
											break;
										}
									}
									else
									{
										if (num == 28)
										{
											#=ztIeE$PLGQDn = this.#=zdLliXMcJpDKNpWJKtuSjMfSdD4Zk();
											flag2 = true;
											break;
										}
										if (num == 46)
										{
											#=ztIeE$PLGQDn = this.#=zXkcPWxscCFNzwNlTECNtj7pd1u5V();
											break;
										}
									}
									#=ztIeE$PLGQDn = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								}
								break;
							}
							IL_39D:
							if (#=ztIeE$PLGQDn != (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2)
							{
								flag3 = false;
							}
							if (#=ztIeE$PLGQDn == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1 || #=ztIeE$PLGQDn == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2 || #=ztIeE$PLGQDn == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3)
							{
								flag = true;
							}
						}
						if (flag3)
						{
							this.#=zRFJsn75_agg2(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2);
						}
					}
					else
					{
						int num = #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zd$BbM3Y=();
						#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=ztIeE$PLGQDn2;
						if (num <= 47)
						{
							switch (num)
							{
							case 28:
							case 31:
								#=ztIeE$PLGQDn2 = this.#=zE2KNY_74G2UnhjaQhg==(200, 1, true);
								goto IL_513;
							case 29:
							case 32:
								#=ztIeE$PLGQDn2 = this.#=zE2KNY_74G2UnhjaQhg==(201, 1, true);
								goto IL_513;
							case 30:
							case 33:
								#=ztIeE$PLGQDn2 = this.#=zE2KNY_74G2UnhjaQhg==(202, 1, true);
								goto IL_513;
							case 34:
							case 35:
							case 36:
							case 37:
							case 38:
							case 40:
							case 41:
							case 43:
								goto IL_511;
							case 39:
							case 42:
								#=ztIeE$PLGQDn2 = this.#=zE2KNY_74G2UnhjaQhg==(122, 1, true);
								goto IL_513;
							case 44:
								break;
							default:
								if (num != 47)
								{
									goto IL_511;
								}
								break;
							}
							#=ztIeE$PLGQDn2 = this.#=zE2KNY_74G2UnhjaQhg==(121, 1, true);
							goto IL_513;
						}
						switch (num)
						{
						case 40001:
							#=ztIeE$PLGQDn2 = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(1);
							goto IL_513;
						case 40002:
							#=ztIeE$PLGQDn2 = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(2);
							goto IL_513;
						case 40003:
							#=ztIeE$PLGQDn2 = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(3);
							goto IL_513;
						case 40004:
							#=ztIeE$PLGQDn2 = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(4);
							goto IL_513;
						case 40005:
							#=ztIeE$PLGQDn2 = this.#=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(5);
							goto IL_513;
						default:
							if (num == 70710)
							{
								if (!this.#=zSJCXgrtDT$p4yz2CyjK3UsF4gylz)
								{
									this.#=zljlEs436K4MuCk8KfQiyLbE=();
									this.#=zSJCXgrtDT$p4yz2CyjK3UsF4gylz = true;
									#=ztIeE$PLGQDn2 = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
									goto IL_513;
								}
								#=ztIeE$PLGQDn2 = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
								goto IL_513;
							}
							break;
						}
						IL_511:
						#=ztIeE$PLGQDn2 = (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
						IL_513:
						if (#=ztIeE$PLGQDn2 == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1 || #=ztIeE$PLGQDn2 == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2 || #=ztIeE$PLGQDn2 == (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3)
						{
							flag = true;
						}
					}
				}
			}
			catch (Exception #=zN_s5Z5A=2)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=2);
			}
		}
		if (!flag2)
		{
			this.#=zBZ6GKhT5mSR_gq0yqw==();
		}
		this.#=z0h8mMpAw4aShhTLMuA==();
		return flag || !this.#=zQUqkQ$zzR07hdRyxnAiejJg=();
	}

	// Token: 0x060008DC RID: 2268 RVA: 0x0004689C File Offset: 0x00044A9C
	private void #=zBZ6GKhT5mSR_gq0yqw==()
	{
		if (this.#=zZ3V8UwudWrFd != null)
		{
			foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == this.#=zZ3V8UwudWrFd.#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0 && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5))
				{
					string text = this.#=zBsXSanI=.#=z2VXbeg3zTNXbJ4Pc71BOktpzGzg4(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_(), #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD(), new object[0]);
					if (text.Length > 1200)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983853), new object[]
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().ToStringLabels()
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983820), new object[]
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().ToStringLabels(),
							JSONManager.Cut(text)
						});
					}
				}
			}
		}
	}

	// Token: 0x060008DD RID: 2269 RVA: 0x000469F4 File Offset: 0x00044BF4
	private void #=z0h8mMpAw4aShhTLMuA==()
	{
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy = this.#=z3yL5bKs=;
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = this.#=z1pahAF0JqdFM8mgjDQ==;
		if ((#=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Bronze] > 1250 || #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Lumber] > 1250) && #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Bronze] > 500 && #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Lumber] > 500 && #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Grain] > 500)
		{
			int num = Enumerable.Count<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==, new Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool>(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=.#=zLkw0NRU=.#=zALKs6dQL4rpYk$TtfXTPnC0docpk));
			if (num < 3)
			{
				this.#=zE2KNY_74G2UnhjaQhg==(108, num + 1, false);
			}
		}
		if (#=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Grain] > 1250 && #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Bronze] > 500 && #=zRq2AEW0okvKAl3LdOqWDdBwtgdy[ResourceTypes.Lumber] > 500)
		{
			int num2 = Enumerable.Count<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==, new Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool>(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=.#=zLkw0NRU=.#=zpru33SxWZNb4IHDsttWK6D$uLu1q));
			if (num2 < 3)
			{
				this.#=zE2KNY_74G2UnhjaQhg==(109, num2 + 1, false);
			}
		}
	}

	// Token: 0x060008DE RID: 2270 RVA: 0x00046AF0 File Offset: 0x00044CF0
	private void #=zUl35jA88F31D()
	{
		this.#=z2JzhoqBG$123(100);
		this.#=z2JzhoqBG$123(119);
		this.#=z2JzhoqBG$123(123);
	}

	// Token: 0x060008DF RID: 2271 RVA: 0x00046B10 File Offset: 0x00044D10
	private void #=zRFJsn75_agg2(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zQhApCGmlHqRA)
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908984017), new object[]
		{
			#=zQhApCGmlHqRA.#=zMuFMjGQ=(),
			#=zQhApCGmlHqRA.#=zkfqcY3I=()
		});
		string text = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zQhApCGmlHqRA.#=zMuFMjGQ=(), null);
		if (text.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983962), new object[]
			{
				#=zQhApCGmlHqRA.#=zkfqcY3I=()
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983941), new object[]
		{
			#=zQhApCGmlHqRA.#=zkfqcY3I=(),
			JSONManager.Cut(text)
		});
	}

	// Token: 0x060008E0 RID: 2272 RVA: 0x00046BE4 File Offset: 0x00044DE4
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zxu4d6zR58PTTCnBCQw==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zQhApCGmlHqRA, #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4= #=zYWPK2cjGtJPo)
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983645), new object[]
		{
			#=zQhApCGmlHqRA.#=zMuFMjGQ=(),
			#=zQhApCGmlHqRA.#=zkfqcY3I=(),
			#=zYWPK2cjGtJPo.#=zTMf9qdrogFIA(),
			#=zYWPK2cjGtJPo.#=zBdOCtomEQ60B()
		});
		string text = this.#=zBsXSanI=.#=zyICOXIdaKrjpxaeVOw==(#=zYWPK2cjGtJPo.#=zTMf9qdrogFIA(), #=zYWPK2cjGtJPo.#=zBdOCtomEQ60B());
		if (text.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983564), new object[]
			{
				#=zQhApCGmlHqRA.#=zkfqcY3I=()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983781), new object[]
		{
			#=zQhApCGmlHqRA.#=zkfqcY3I=(),
			JSONManager.Cut(text)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008E1 RID: 2273 RVA: 0x00046CDC File Offset: 0x00044EDC
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z3TrxKisw7nyXMkOe5PjuvHk=()
	{
		if (this.#=z80Ienm4pN63RdJiXkosEq$4= == null || this.#=zm2oSGGagu94wBmQRHpr0kCWxYA0bE$fjRA== != this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords)
		{
			this.#=z80Ienm4pN63RdJiXkosEq$4= = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z3TrxKisw7nyXMkOe5PjuvHk=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords, true);
			this.#=zm2oSGGagu94wBmQRHpr0kCWxYA0bE$fjRA== = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords;
		}
		return this.#=z80Ienm4pN63RdJiXkosEq$4=;
	}

	// Token: 0x060008E2 RID: 2274 RVA: 0x00046D54 File Offset: 0x00044F54
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zFke0rAlePLN5()
	{
		if (this.#=zZ3V8UwudWrFd == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983722), Array.Empty<object>());
			#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw== = new #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==(TaskTypes.Initiation);
			for (int i = 0; i < 100; i++)
			{
				int num = #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zf0e9blCCGf6ut3r1Nw==() + this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==();
				int num2 = #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zbRWovF5fxGmOqm7gAQ==() + this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==();
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983423), new object[]
				{
					num,
					num2
				});
				foreach (Dictionary<string, object> dictionary in Enumerable.ToArray<object>(Enumerable.OrderBy<object, double>((object[])((Dictionary<string, object>)JSONManager.GetData(this.#=zBsXSanI=.#=zpeSgyDU=(num, num2)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)], new Func<object, double>(this.#=zJUD_Lfh7vlfISsFPfGjBKlk=))))
				{
					int item = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
					if (!this.#=z9aXV16k7tKjznITfJQ==.Contains(item))
					{
						int num3 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0);
						string text = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), string.Empty);
						if (num3 > 0 && num3 < 20 && !string.IsNullOrEmpty(text) && !text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983380)) && !dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)) && !dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)))
						{
							int num4;
							string value;
							DateTime d = this.#=zBsXSanI=.#=zi6E$PtAmGSYg(text, out num4, out value);
							bool flag = false;
							if (string.IsNullOrEmpty(value))
							{
								if ((this.#=zJuQW8gI= - d).TotalDays > 3.0)
								{
									flag = true;
								}
							}
							else if (num4 == 2)
							{
								flag = true;
							}
							if (flag)
							{
								this.#=zZ3V8UwudWrFd = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zT$2iWxnv3qme(dictionary);
							}
						}
						this.#=z9aXV16k7tKjznITfJQ==.Add(item);
					}
				}
				if (this.#=zZ3V8UwudWrFd != null)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983363), new object[]
					{
						this.#=zZ3V8UwudWrFd.#=zkfqcY3I=(),
						this.#=zZ3V8UwudWrFd.#=zfTB62qendhk_VEy8rw==(),
						this.#=zZ3V8UwudWrFd.#=zY0soxphmGIACbOHy6A==()
					});
					break;
				}
				#=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==.#=zrYsCATIY3Mmo();
			}
			if (this.#=zZ3V8UwudWrFd == null)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983325), Array.Empty<object>());
				this.#=zZ3V8UwudWrFd = new #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==(0, #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983488)), 0, 0);
			}
		}
		return this.#=zZ3V8UwudWrFd;
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x00047050 File Offset: 0x00045250
	private void #=zwxdW_E9OYDwZ()
	{
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(this.#=zbllFtOCOo5oBXpvMGTpHNRc=));
		for (int i = 0; i < list.Count; i++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = list[i];
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFzGvi_S6jJhE(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1);
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zdU1a9B$ueh_3(DateTime.MinValue);
			this.#=zefqXUipXk_kZ = false;
		}
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x000470AC File Offset: 0x000452AC
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zE2KNY_74G2UnhjaQhg==(int #=zp13pRNQ=, int #=z4UDysxM=, bool #=zX0g5PrbeVW3y)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zkPAWP9vm2C_zB9mRkOPLv2g= #=zkPAWP9vm2C_zB9mRkOPLv2g= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zkPAWP9vm2C_zB9mRkOPLv2g=();
		#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ= = #=zp13pRNQ=;
		if (this.#=zkr0fQ5KhviB40pIlEgkA6VU=.Contains(#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=))
		{
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
		}
		this.#=zwxdW_E9OYDwZ();
		Dictionary<int, int> dictionary = #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zFHkCBp9mRlgs();
		#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
		if (dictionary.ContainsKey(#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=))
		{
			int num = dictionary[#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=];
			if (#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(num) != null)
			{
				return this.#=zYm5wcP2UlE0KhTjhLg==(num, #=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=, #=z4UDysxM=);
			}
		}
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF == null)
		{
			if (#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ= == 122 && (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Konflikt || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Sparta || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Nords))
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF2 = new #=zZ4TczVhhqPd03VvEaufX1hUlE1pF();
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Id = #=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=;
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983478));
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4);
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zZ4TczVhhqPd03VvEaufX1hUlE1pF2;
			}
			else
			{
				if (!#=zX0g5PrbeVW3y)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908983456), new object[]
					{
						#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968816), new object[]
				{
					#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=
				});
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF = new #=zZ4TczVhhqPd03VvEaufX1hUlE1pF
				{
					Id = #=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=,
					Name = #=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zp13pRNQ=.ToString()
				};
			}
		}
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=zpgENx28vSQq7Ng5jIAqfaQI=));
		if (list.Count >= #=z4UDysxM=)
		{
			if (Enumerable.Count<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(list, new Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool>(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=.#=zLkw0NRU=.#=zdqLMa8o0iaam3f1zWluoKYN6CDd4)) >= #=z4UDysxM=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968790), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
					#=z4UDysxM=
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968753), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
				#=z4UDysxM=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		else
		{
			if (this.#=zefqXUipXk_kZ)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968939), Array.Empty<object>());
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968869), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
				#=z4UDysxM=
			});
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = this.#=z3TrxKisw7nyXMkOe5PjuvHk=();
			if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== == null)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968839), Array.Empty<object>());
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			string text;
			#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zFY9ihF5o2BCdfI$ovxZVFdA=(this.#=z8StzeqE=, this.#=zBsXSanI=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==, this.#=z6Bha1HM=, this.#=z1pahAF0JqdFM8mgjDQ==, out text);
			List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zkPAWP9vm2C_zB9mRkOPLv2g=.#=ze_Jv5RvwFr_28CCN7Kzh0T8=));
			#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ== comparer = new #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==((#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)1);
			list2.Sort(comparer);
			list.Sort(comparer);
			if (list2.Count <= list.Count)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968524), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
					list2.Count,
					#=z4UDysxM=
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = list2[list.Count];
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() == null)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zzQwUIEs=(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF);
			}
			string text2;
			return this.#=ztc5Kxc8=(#=zO6457TajDDxDJIsKqS1bbzDMLckn, out text2);
		}
	}

	// Token: 0x060008E5 RID: 2277 RVA: 0x00047448 File Offset: 0x00045648
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=ztc5Kxc8=(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zwTatGRABiBcSRHA9hg==, out string #=zAvji2fxf2UT1H5u_sw==)
	{
		if (!this.#=z2JzhoqBG$123(#=zwTatGRABiBcSRHA9hg==.#=zlSY2GGkBa6S3MkHuDQ==()))
		{
			#=zAvji2fxf2UT1H5u_sw== = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968654));
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		#=zAvji2fxf2UT1H5u_sw== = this.#=zBsXSanI=.#=zQ3GmQEFE_q6Y(#=zwTatGRABiBcSRHA9hg==, false);
		if (#=zAvji2fxf2UT1H5u_sw==.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978849), new object[]
			{
				#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		if (#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968609)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968590), new object[]
			{
				#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		if (#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968276), new object[]
			{
				#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		if (#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968200), new object[]
			{
				#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		if (!#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968413)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968062), new object[]
			{
				#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=(),
				#=zAvji2fxf2UT1H5u_sw==
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968376), new object[]
		{
			#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=(),
			#=zAvji2fxf2UT1H5u_sw==
		});
		if (#=zwTatGRABiBcSRHA9hg==.#=zFMDiymuLQ7_4() == 1000)
		{
			this.#=zkr0fQ5KhviB40pIlEgkA6VU=.Add(#=zwTatGRABiBcSRHA9hg==.#=zFMDiymuLQ7_4());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
		}
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008E6 RID: 2278 RVA: 0x00047630 File Offset: 0x00045830
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zYm5wcP2UlE0KhTjhLg==(int #=zIuEJkTTJgsiu, int #=z_XBD5so=, int #=z4UDysxM=)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zJXkI3Wfktnp0arl_cNmU3XA= #=zJXkI3Wfktnp0arl_cNmU3XA= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zJXkI3Wfktnp0arl_cNmU3XA=();
		#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zIuEJkTTJgsiu = #=zIuEJkTTJgsiu;
		#=zJXkI3Wfktnp0arl_cNmU3XA=.#=z_XBD5so= = #=z_XBD5so=;
		#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zlJSAjfPMVf41 = this;
		#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zIuEJkTTJgsiu);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968816), new object[]
			{
				#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zIuEJkTTJgsiu
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF2 = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=z_XBD5so=);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2 == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968816), new object[]
			{
				#=zJXkI3Wfktnp0arl_cNmU3XA=.#=z_XBD5so=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zsvVZR2TQoDiVSnh2yL96YLh1rchV));
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zkTfIrhtlOCuoXPzvoZZJFiQjPe23));
		if (list2.Count + list.Count >= #=z4UDysxM=)
		{
			if (list2.Count + Enumerable.Count<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(list, new Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool>(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=zVvHqoQ9_lZvzuwC8Xl5UqJBnFGSL)) >= #=z4UDysxM=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968790), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name,
					#=z4UDysxM=
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968753), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name,
				#=z4UDysxM=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		else
		{
			if (this.#=zefqXUipXk_kZ)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968939), Array.Empty<object>());
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968869), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF2.Name,
				#=z4UDysxM=
			});
			List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list3 = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zJXkI3Wfktnp0arl_cNmU3XA=.#=z_YFNq2Qk_yt2t62zPSCX0ykICy_r));
			if (list3.Count == 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968014), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA== = list3[0];
			string text;
			return this.#=z6_3g4m5XOzSr(#=zUOCbBE7lBfRpv5tNuA==, out text);
		}
	}

	// Token: 0x060008E7 RID: 2279 RVA: 0x00047894 File Offset: 0x00045A94
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zHHRavnCMJCruk4jadQ==(int #=zp13pRNQ=, int #=z5w6HcG4=, int #=z4UDysxM=)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zIhomNoRZtUK0acfKJxHzBKo= #=zIhomNoRZtUK0acfKJxHzBKo= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zIhomNoRZtUK0acfKJxHzBKo=();
		#=zIhomNoRZtUK0acfKJxHzBKo=.#=zp13pRNQ= = #=zp13pRNQ=;
		#=zIhomNoRZtUK0acfKJxHzBKo=.#=z5w6HcG4= = #=z5w6HcG4=;
		this.#=zwxdW_E9OYDwZ();
		#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=().#=zk$6QZNA=(#=zIhomNoRZtUK0acfKJxHzBKo=.#=zp13pRNQ=);
		if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968816), new object[]
			{
				#=zIhomNoRZtUK0acfKJxHzBKo=.#=zp13pRNQ=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zIhomNoRZtUK0acfKJxHzBKo=.#=zBo3gw5Bu1pAlxhsqyWLFXvI5rUNk));
		if (list.Count < #=z4UDysxM=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967971), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
				#=z4UDysxM=,
				list.Count
			});
			this.#=zE2KNY_74G2UnhjaQhg==(#=zIhomNoRZtUK0acfKJxHzBKo=.#=zp13pRNQ=, #=z4UDysxM=, false);
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = list.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zIhomNoRZtUK0acfKJxHzBKo=.#=zabYejfBRRBnfzTgy6AbVK2LWMhCt));
		if (list2.Count >= #=z4UDysxM=)
		{
			if (Enumerable.Count<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(list2, new Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool>(#=zIhomNoRZtUK0acfKJxHzBKo=.#=znyh2lSQ11J3tGHKjW$dAo$0KzQzd)) >= #=z4UDysxM=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968149), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
					#=z4UDysxM=,
					#=zIhomNoRZtUK0acfKJxHzBKo=.#=z5w6HcG4=
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968100), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
				#=z4UDysxM=,
				#=zIhomNoRZtUK0acfKJxHzBKo=.#=z5w6HcG4=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		else
		{
			if (this.#=zefqXUipXk_kZ)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968939), Array.Empty<object>());
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969819), new object[]
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name,
				#=z4UDysxM=,
				#=zIhomNoRZtUK0acfKJxHzBKo=.#=z5w6HcG4=
			});
			List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list3 = list.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zIhomNoRZtUK0acfKJxHzBKo=.#=zt7TrR8KRsPE$G4tVbqusk2Ap6jr1));
			if (list3.Count == 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969780), new object[]
				{
					#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Name
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA== = list3[0];
			string text;
			return this.#=z6_3g4m5XOzSr(#=zUOCbBE7lBfRpv5tNuA==, out text);
		}
	}

	// Token: 0x060008E8 RID: 2280 RVA: 0x00047B18 File Offset: 0x00045D18
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=z6_3g4m5XOzSr(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==, out string #=zAvji2fxf2UT1H5u_sw==)
	{
		#=zAvji2fxf2UT1H5u_sw== = this.#=zBsXSanI=.#=zDqCpkITFJ_yR(#=zUOCbBE7lBfRpv5tNuA==, false);
		if (#=zAvji2fxf2UT1H5u_sw==.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978303), new object[]
			{
				#=zUOCbBE7lBfRpv5tNuA==.#=zkfqcY3I=(),
				#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		if (#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969977), new object[]
			{
				#=zUOCbBE7lBfRpv5tNuA==.#=zkfqcY3I=(),
				#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		if (#=zAvji2fxf2UT1H5u_sw==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969900), new object[]
			{
				#=zUOCbBE7lBfRpv5tNuA==.#=zkfqcY3I=(),
				#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978240), new object[]
		{
			#=zUOCbBE7lBfRpv5tNuA==.#=zkfqcY3I=(),
			#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1,
			JSONManager.Cut(#=zAvji2fxf2UT1H5u_sw==)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008E9 RID: 2281 RVA: 0x00047C78 File Offset: 0x00045E78
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zpLdQfRUBazX9CEFOoYPp7YwdL22R(int #=zAk8mKBk=, int #=z5w6HcG4=)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zUm441WjjSSkl1AZpGW_pWgE= #=zUm441WjjSSkl1AZpGW_pWgE= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zUm441WjjSSkl1AZpGW_pWgE=();
		#=zUm441WjjSSkl1AZpGW_pWgE=.#=zAk8mKBk= = #=zAk8mKBk=;
		#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=().#=zk$6QZNA=(#=zUm441WjjSSkl1AZpGW_pWgE=.#=zAk8mKBk=);
		if (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969572), new object[]
			{
				#=zUm441WjjSSkl1AZpGW_pWgE=.#=zAk8mKBk=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = this.#=zJF2YTStZkxdpBvijgveKmkY=.Find(new Predicate<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>(#=zUm441WjjSSkl1AZpGW_pWgE=.#=zB5EXrdfNdwx0JgLdVUsnHOpMtwxdkYxflwfQPY8=));
		if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== != null && (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() >= #=z5w6HcG4= || (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() == #=z5w6HcG4= - 1 && #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7())))
		{
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() >= #=z5w6HcG4= || (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=z5kpAZQpjT2b7() && #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zGhmoNZChgwf8() < this.#=zJuQW8gI=))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969531), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
					#=z5w6HcG4=
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969501), new object[]
			{
				#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
				#=z5w6HcG4=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		else
		{
			if (this.#=zyNa48o$QnCSAP$EskIOIm0M=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969687), Array.Empty<object>());
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969615), new object[]
			{
				#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
				#=z5w6HcG4=
			});
			TechPlanFrame techPlanFrame = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TechUpgradePlan.Get(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id);
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== == null)
			{
				if (!techPlanFrame.IsResearch)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969308), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
				}
				string text = this.#=zBsXSanI=.#=z20Op8NOLzKmH5WBHiP4ZLPs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==, false);
				if (text.Length > 1200)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969259), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969218), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
					JSONManager.Cut(text)
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			else
			{
				if (!techPlanFrame.IsUpgrade || (techPlanFrame.UpgradeLevel > 0 && techPlanFrame.UpgradeLevel <= #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du()) || #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() >= #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().#=zDpaLxYOl35uZaIePmg==())
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969438), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
						#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() + 1
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)0;
				}
				string text2 = this.#=zBsXSanI=.#=zqf$ER4kgqRjhLlVT9Q==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, false);
				if (text2.Length > 1200)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969380), new object[]
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969078), new object[]
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name,
					JSONManager.Cut(text2)
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
		}
	}

	// Token: 0x060008EA RID: 2282 RVA: 0x00047FFC File Offset: 0x000461FC
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=znqoJ3OqpnIL6CsHLdfgFcHk=(int #=zp13pRNQ=, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		int num = 1;
		UnitType unitType = #=zlhLE8UQVU0AG.Find(#=zp13pRNQ=);
		if (unitType == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969029), new object[]
			{
				#=zp13pRNQ=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		if (!this.#=zaG$soXg=(unitType.#=zdL$RcwsYpqvy()))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908968996), new object[]
			{
				unitType.Name
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		bool flag = false;
		DateTime t = this.#=zCCdwo8AGZiustnyqjw8wZSs=.#=zaZ1MPAebHsWq$PlROg==(#=zp13pRNQ=);
		if (t > DateTime.MinValue)
		{
			if (t < this.#=zJuQW8gI=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969146), new object[]
				{
					unitType.Name
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
			}
			flag = true;
		}
		if (flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908969102), new object[]
			{
				unitType.Name
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970837), new object[]
		{
			unitType.Name
		});
		string text = this.#=zBsXSanI=.#=zoO8X4UjQ2pwEKUcTrw==(unitType, num);
		if (text.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970782), new object[]
			{
				num,
				unitType.Name
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971006), new object[]
		{
			num,
			unitType.Name,
			JSONManager.Cut(text)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008EB RID: 2283 RVA: 0x000481E0 File Offset: 0x000463E0
	private bool #=zaG$soXg=(List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zVL9JLxq$0pEZRzin7xAxrpg=)
	{
		for (int i = 0; i < #=zVL9JLxq$0pEZRzin7xAxrpg=.Count; i++)
		{
			#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zsKs89uXrpN5bf2Plh7eZaXM= #=zsKs89uXrpN5bf2Plh7eZaXM= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zsKs89uXrpN5bf2Plh7eZaXM=();
			#=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4= = #=zVL9JLxq$0pEZRzin7xAxrpg=[i];
			if (#=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zq2bPTdY=() != null)
			{
				Entities entity = #=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zq2bPTdY=().Entity;
				if (entity != Entities.Building)
				{
					if (entity == Entities.Technology)
					{
						if (!this.#=zJF2YTStZkxdpBvijgveKmkY=.Exists(new Predicate<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>(#=zsKs89uXrpN5bf2Plh7eZaXM=.#=ztTdee6kBNtxjD1L$Ug==)))
						{
							this.#=zpLdQfRUBazX9CEFOoYPp7YwdL22R(#=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zFMDiymuLQ7_4(), #=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zvnZc$RhG_1Du());
							return false;
						}
					}
				}
				else if (!this.#=z1pahAF0JqdFM8mgjDQ==.Exists(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zsKs89uXrpN5bf2Plh7eZaXM=.#=z_7YXSb7o1hzOsOY0iw==)))
				{
					this.#=zHHRavnCMJCruk4jadQ==(#=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zFMDiymuLQ7_4(), #=zsKs89uXrpN5bf2Plh7eZaXM=.#=zDMC3L_4=.#=zvnZc$RhG_1Du(), 1);
					return false;
				}
			}
		}
		return true;
	}

	// Token: 0x060008EC RID: 2284 RVA: 0x000482B4 File Offset: 0x000464B4
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zycOCEFvlCAG1jgjWl1MghnKP6IQ$(int #=z5w6HcG4=)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zVA5DTxsop0DII4nixnWcIFQ= #=zVA5DTxsop0DII4nixnWcIFQ= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zVA5DTxsop0DII4nixnWcIFQ=();
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4= = #=z5w6HcG4=;
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=zlJSAjfPMVf41 = this;
		List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV> list = this.#=zbGFpMLw=.#=zCrb91gPnuXNh();
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=zs$RCjxM2v6ZUHz8M0w== = list.Find(new Predicate<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV>(#=zVA5DTxsop0DII4nixnWcIFQ=.#=zpG4eKe2Qn$8l7PVKlX6967JqJNwTKXkaHiBubQ0=));
		if (#=zVA5DTxsop0DII4nixnWcIFQ=.#=zs$RCjxM2v6ZUHz8M0w== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970645), new object[]
			{
				#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list2 = this.#=zVG1EPv1OUDdyLeGHGQ==.FindAll(new Predicate<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>(#=zVA5DTxsop0DII4nixnWcIFQ=.#=zeFebRgSqk6Hp$XLhqA4GMAlSQm6mmYv0bRZA_HA=));
		if (list2.Count > 0)
		{
			for (int i = 0; i < list2.Count; i++)
			{
				if (list2[i].#=zL4D9WC8RTH921DofgQ==() < this.#=zJuQW8gI=)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970954), new object[]
					{
						#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4=
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970603), new object[]
			{
				#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		UnitSquadCollection unitSquadCollection;
		UnitSquadCollection unitSquadCollection2;
		int num;
		#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970527), this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out unitSquadCollection, out unitSquadCollection2, out num);
		UnitSquadCollection unitSquadCollection3 = new UnitSquadCollection();
		unitSquadCollection3.AddUnits(unitSquadCollection);
		unitSquadCollection3.AddUnits(unitSquadCollection2);
		string text = unitSquadCollection3.ToStringLabels();
		string text2 = this.#=zBsXSanI=.#=zCM8rb8eNLj3u(#=zVA5DTxsop0DII4nixnWcIFQ=.#=zs$RCjxM2v6ZUHz8M0w==.#=zMuFMjGQ=(), true, unitSquadCollection, unitSquadCollection2, 0);
		if (text2.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970502), new object[]
			{
				text,
				#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4=
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970698), new object[]
		{
			text,
			#=zVA5DTxsop0DII4nixnWcIFQ=.#=z5w6HcG4=,
			JSONManager.Cut(text2)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008ED RID: 2285 RVA: 0x000484DC File Offset: 0x000466DC
	private void #=zJ7N$mtWnCwBTrEhOn1hRDIQ=()
	{
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = this.#=zFke0rAlePLN5();
		object[] array = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
		if (array == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908934751), Array.Empty<object>());
		}
		object[] array2 = array;
		int i = 0;
		while (i < array2.Length)
		{
			Dictionary<string, object> obj = (Dictionary<string, object>)JSONManager.GetObject((Dictionary<string, object>)array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
			int @int = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
			if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=() == @int)
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970338));
				if (dictionary != null && dictionary.Count > 0)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970328), new object[]
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zfTB62qendhk_VEy8rw==(),
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zY0soxphmGIACbOHy6A==()
					});
					this.#=z9aXV16k7tKjznITfJQ==.Add(this.#=zZ3V8UwudWrFd.#=zMuFMjGQ=());
					this.#=zZ3V8UwudWrFd = null;
					return;
				}
				break;
			}
			else
			{
				i++;
			}
		}
	}

	// Token: 0x060008EE RID: 2286 RVA: 0x00048608 File Offset: 0x00046808
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zhwIPDZYrXdkNuPPycw==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP)
	{
		#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=znLzWnCgdrMN3$mQUGdCybHA= #=znLzWnCgdrMN3$mQUGdCybHA= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=znLzWnCgdrMN3$mQUGdCybHA=();
		#=znLzWnCgdrMN3$mQUGdCybHA=.#=zlJSAjfPMVf41 = this;
		#=znLzWnCgdrMN3$mQUGdCybHA=.#=zrneKYItKkdXP = #=zrneKYItKkdXP;
		this.#=zJ7N$mtWnCwBTrEhOn1hRDIQ=();
		#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk = this.#=zFke0rAlePLN5();
		if (#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zMuFMjGQ=() == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970480), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		string text;
		string #=zsGkziQH4l9Fpi_2cMg==;
		switch (#=znLzWnCgdrMN3$mQUGdCybHA=.#=zrneKYItKkdXP)
		{
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2:
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970459));
			#=zsGkziQH4l9Fpi_2cMg== = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970452);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3:
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970429));
			#=zsGkziQH4l9Fpi_2cMg== = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970413);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4:
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970095));
			#=zsGkziQH4l9Fpi_2cMg== = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970076);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5:
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970383));
			#=zsGkziQH4l9Fpi_2cMg== = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970097);
			break;
		default:
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970057), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zVG1EPv1OUDdyLeGHGQ==.FindAll(new Predicate<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>(#=znLzWnCgdrMN3$mQUGdCybHA=.#=z8G6sn$xZK_TgElDEzPAzE04MZZ7_));
		if (list.Count > 0)
		{
			DateTime dateTime = DateTime.MaxValue;
			for (int i = 0; i < list.Count; i++)
			{
				DateTime dateTime2 = list[i].#=zL4D9WC8RTH921DofgQ==();
				if (dateTime2 < this.#=zJuQW8gI=)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970029), new object[]
					{
						text,
						#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zkfqcY3I=(),
						#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zfTB62qendhk_VEy8rw==(),
						#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zY0soxphmGIACbOHy6A==()
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
				}
				if (dateTime2 < dateTime)
				{
					dateTime = dateTime2;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970202), new object[]
			{
				text,
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zkfqcY3I=(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zfTB62qendhk_VEy8rw==(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zY0soxphmGIACbOHy6A==(),
				(int)(dateTime - this.#=zJuQW8gI=).TotalSeconds
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		UnitSquadCollection unitSquadCollection;
		UnitSquadCollection unitSquadCollection2;
		int num;
		#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(#=zsGkziQH4l9Fpi_2cMg==, this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out unitSquadCollection, out unitSquadCollection2, out num);
		UnitSquadCollection unitSquadCollection3 = new UnitSquadCollection();
		unitSquadCollection3.AddUnits(unitSquadCollection);
		unitSquadCollection3.AddUnits(unitSquadCollection2);
		string text2 = unitSquadCollection3.ToStringLabels();
		if (unitSquadCollection3.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971880), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		string text3;
		switch (#=znLzWnCgdrMN3$mQUGdCybHA=.#=zrneKYItKkdXP)
		{
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2:
			text3 = this.#=zBsXSanI=.#=zow1rctFaF6MDmvemZw==(#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zMuFMjGQ=(), unitSquadCollection, unitSquadCollection2, 0);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3:
			text3 = this.#=zBsXSanI=.#=ztRSQy0HcRHKziQrWOA==(#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zMuFMjGQ=(), unitSquadCollection, unitSquadCollection2, 0);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4:
			text3 = this.#=zBsXSanI=.#=zs39vp3mWzzdw(#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zMuFMjGQ=(), unitSquadCollection, unitSquadCollection2, 0);
			break;
		case (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5:
			text3 = this.#=zBsXSanI=.#=zWYvEC7HhMxBOcSI89TZRLg0=(#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zMuFMjGQ=(), unitSquadCollection, unitSquadCollection2, 0);
			break;
		default:
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970057), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
		}
		if (text3.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971853), new object[]
			{
				text,
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zkfqcY3I=(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zfTB62qendhk_VEy8rw==(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zY0soxphmGIACbOHy6A==(),
				text2
			});
			this.#=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq.RemoveUnits(unitSquadCollection);
			this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==.RemoveUnits(unitSquadCollection);
			this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection2);
			this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection2);
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)1;
		}
		if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971792)) || text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971779)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972010), new object[]
			{
				text,
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zkfqcY3I=(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zfTB62qendhk_VEy8rw==(),
				#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zY0soxphmGIACbOHy6A==(),
				text2
			});
			this.#=z9aXV16k7tKjznITfJQ==.Add(this.#=zZ3V8UwudWrFd.#=zMuFMjGQ=());
			this.#=zZ3V8UwudWrFd = null;
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908921209)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971922), new object[]
			{
				text,
				JSONManager.Cut(text3)
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971569), new object[]
		{
			text,
			#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zkfqcY3I=(),
			#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zfTB62qendhk_VEy8rw==(),
			#=znLzWnCgdrMN3$mQUGdCybHA=.#=zI60pd6o84hZk.#=zY0soxphmGIACbOHy6A==(),
			text2,
			JSONManager.Cut(text3)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008EF RID: 2287 RVA: 0x00048BB0 File Offset: 0x00046DB0
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zdLliXMcJpDKNpWJKtuSjMfSdD4Zk()
	{
		List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> list = this.#=zF5ZHDos=;
		int i = 0;
		while (i < list.Count)
		{
			#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ== #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ== = list[i];
			TimeSpan t = #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==.#=z0qIeBNbFCDl6() - this.#=zJuQW8gI= + TimeSpan.FromMinutes(10.0);
			if (t <= TimeSpan.Zero)
			{
				string text = this.#=zBsXSanI=.#=zPqLTAl9NPKhi7JX8uLKz7Q8R7E_B(#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==.#=zMuFMjGQ=());
				if (text.Length > 1200)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971751), Array.Empty<object>());
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971687), new object[]
				{
					JSONManager.Cut(text)
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971362), new object[]
				{
					t.TotalSeconds
				});
				i++;
			}
		}
		if (list.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971281), Array.Empty<object>());
			this.#=zhwIPDZYrXdkNuPPycw==((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3);
		}
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
	}

	// Token: 0x060008F0 RID: 2288 RVA: 0x00048CFC File Offset: 0x00046EFC
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zsE_ICZcUqsrpxGEQax4PCgD3lUiY(List<int> #=zmcx0ajmFeT$P, int #=zNvCMwussKumm)
	{
		#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= = this.#=zCY4az9$WUjLsEJ7fgg==;
		foreach (int num in #=zmcx0ajmFeT$P)
		{
			if (#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(num) >= #=zNvCMwussKumm)
			{
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = new #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=(new #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU(num, num.ToString()));
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zYFVB57ja3aZW((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)0);
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zHIedO$w= = #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=;
				#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=zHIedO$w=, #=zNvCMwussKumm);
				if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 1200)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971481), new object[]
					{
						num,
						#=zNvCMwussKumm
					});
					return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971429), new object[]
				{
					num,
					#=zNvCMwussKumm,
					JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
				});
				return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
			}
		}
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008F1 RID: 2289 RVA: 0x00048E24 File Offset: 0x00047024
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zXkcPWxscCFNzwNlTECNtj7pd1u5V()
	{
		string text = this.#=zBsXSanI=.#=zWQq1w59y6TrDBgKtgduXvwI=(1);
		if (text.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971098), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971064), new object[]
		{
			JSONManager.Cut(text)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008F2 RID: 2290 RVA: 0x00048EA4 File Offset: 0x000470A4
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zwv8V1LCmiaPSFlMFIdFmHDTmcacR()
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.AddRange(this.#=z1pahAF0JqdFM8mgjDQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=.#=zLkw0NRU=.#=zrrlG236YsCCMb0qM93iabW8Wt0uNDu8a3cOEeqTcTKpU)));
		string text = this.#=zBsXSanI=.#=zvKSBsqfaroQezK0jE98NEtE=(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==);
		if (text.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980850), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971019), new object[]
		{
			JSONManager.Cut(text)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008F3 RID: 2291 RVA: 0x00048F58 File Offset: 0x00047158
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=z0Z2CahuxInzwkHHXKeZpzKs=(int #=zZwdr0o2T$Cdz, int #=zrjon8Kw=)
	{
		#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=().#=zgGkIlWWkq3Ly(#=zZwdr0o2T$Cdz);
		string text = (#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== != null) ? #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Name : #=zZwdr0o2T$Cdz.ToString();
		string text2 = this.#=zBsXSanI=.#=z1COIqFtmolRsi49XRA==(#=zZwdr0o2T$Cdz, #=zrjon8Kw=);
		if (text2.Length > 1200)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971216), new object[]
			{
				text,
				#=zrjon8Kw= + 1
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971165), new object[]
		{
			text,
			#=zrjon8Kw= + 1,
			JSONManager.Cut(text2)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008F4 RID: 2292 RVA: 0x00049018 File Offset: 0x00047218
	private #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1 #=zmkepM5vE$xtKMyz13rAaU6vy1y0vs01r$A==(UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		List<int> list = new List<int>
		{
			1,
			2,
			3,
			4,
			17,
			18,
			19,
			20
		};
		List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> list2 = this.#=zXi9vZ5Ltb$swzaKUNQ==;
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		foreach (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ= #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ= in list2)
		{
			if (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zq2bPTdY=() == (#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zArez$Gs=)0)
			{
				foreach (UnitSquad unitSquad in #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=.#=zDy8wm$yKq8XD())
				{
					if (list.Contains(unitSquad.Type.Id))
					{
						unitSquadCollection.AddUnits(unitSquad.Type, 1);
						break;
					}
				}
				if (unitSquadCollection.Count > 0)
				{
					break;
				}
			}
		}
		if (unitSquadCollection.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972909), Array.Empty<object>());
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)3;
		}
		string text = this.#=zBsXSanI=.#=z5Lzucng7Dc2NMPpAc8e4$U4=(unitSquadCollection);
		text = text.Trim();
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972846), new object[]
			{
				unitSquadCollection.ToStringLabels()
			});
			return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)2;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972800), new object[]
		{
			unitSquadCollection.ToStringLabels(),
			JSONManager.Cut(text)
		});
		return (#=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=ztIeE$PLGQDn1)4;
	}

	// Token: 0x060008F5 RID: 2293 RVA: 0x000491DC File Offset: 0x000473DC
	public bool #=z2JzhoqBG$123(int #=z8jtWTGapMiVLRkNqOA==)
	{
		if (!GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=())
		{
			return true;
		}
		List<int> list = this.#=ztiB995TsnwxE;
		if (list.Count == 0)
		{
			return true;
		}
		for (int i = 0; i < list.Count; i++)
		{
			if (list[i] == #=z8jtWTGapMiVLRkNqOA==)
			{
				return true;
			}
		}
		List<List<int>> list2 = new List<List<int>>
		{
			new List<int>
			{
				100,
				113,
				114,
				115,
				134
			},
			new List<int>
			{
				119,
				122,
				127,
				128,
				129
			},
			new List<int>
			{
				123,
				124,
				125,
				126,
				135
			},
			new List<int>
			{
				109,
				110,
				112,
				137
			},
			new List<int>
			{
				116,
				120,
				121,
				136
			}
		};
		int j = 0;
		while (j < list2.Count)
		{
			List<int> list3 = list2[j];
			if (list3.Contains(#=z8jtWTGapMiVLRkNqOA==))
			{
				object[] array = new object[list3.Count];
				for (int k = 0; k < array.Length; k++)
				{
					array[k] = list3[k];
				}
				string text = this.#=zBsXSanI=.#=zY59gu_lFZnDu9HO$jJ9ew2SJpU6t(array);
				if (text.Length > 1200)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973018), Array.Empty<object>());
					return true;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972990), new object[]
				{
					JSONManager.Cut(text)
				});
				return false;
			}
			else
			{
				j++;
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972949), Array.Empty<object>());
		return false;
	}

	// Token: 0x060008F6 RID: 2294 RVA: 0x00049424 File Offset: 0x00047624
	private bool #=zljlEs436K4MuCk8KfQiyLbE=()
	{
		if (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==() > 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972625), Array.Empty<object>());
			return true;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972578), Array.Empty<object>());
		if (string.IsNullOrWhiteSpace(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationAllianceCityCoords))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972771), Array.Empty<object>());
			return false;
		}
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (!#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zpFuBGU_pbGgs(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationAllianceCityCoords, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972734), Array.Empty<object>());
			return false;
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(this.#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, this.#=zBsXSanI=);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972673), Array.Empty<object>());
			return false;
		}
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==() <= 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972390), Array.Empty<object>());
			return false;
		}
		bool result;
		try
		{
			string text = this.#=zBsXSanI=.#=zcMzsxux2PNxUE9oteQcj1JR6QFos(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==());
			if (#=zDQJuiDzV7frl3AP2cTATd6w_y1fmnPyLvUV8aCnHkP7nva7tPC5251B4PMz_.#=z2D7syGj03O9k(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zO1FX6YkNZlqlvFZqJg==(), text))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929248), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==()
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972337), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==(),
					(text.Length > 1010) ? text.Substring(0, 1000) : text
				});
			}
			result = true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x060008F7 RID: 2295 RVA: 0x0004965C File Offset: 0x0004785C
	public bool #=zhp_aikH5diw4gr0E2g==()
	{
		foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== in this.#=zeYLQo2n2g2lR)
		{
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zRTKkIHydRtAD().Count == 1)
			{
				#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4= #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4= = #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zRTKkIHydRtAD()[0];
				if (#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zq2bPTdY=() == (#=zrv_Zlym3R6_K74dWQFVn27rf0z2uOoWs3i0P6gE=)1)
				{
					this.#=zBsXSanI=.#=zyICOXIdaKrjpxaeVOw==(#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zTMf9qdrogFIA(), #=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zBdOCtomEQ60B());
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972528), new object[]
					{
						#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=(),
						#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zTMf9qdrogFIA(),
						#=zvCiVMNgNtjC2R7mKhkYRLY3$kBeRUdS83oIaEy4=.#=zBdOCtomEQ60B()
					});
				}
			}
		}
		return true;
	}

	// Token: 0x060008F8 RID: 2296 RVA: 0x00049738 File Offset: 0x00047938
	private bool #=zhkBVzZjlpeZdR6YmNHTrwBE=()
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972147), Array.Empty<object>());
		string text = this.#=zBsXSanI=.#=zJsknLhumcn07(new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes.Bronze, 20), new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes.Lumber, 20));
		bool flag = false;
		if (text.Length < 1000)
		{
			try
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetData(text);
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)) && dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] is int)
				{
					this.#=zBsXSanI=.#=ztNr$6f$4jFpqECtQlA==(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)]));
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972110), Array.Empty<object>());
					flag = true;
				}
			}
			catch
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, text, Array.Empty<object>());
			}
			if (!flag && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032151)))
			{
				flag = true;
			}
		}
		else
		{
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071575));
			if (array != null)
			{
				foreach (Dictionary<string, object> dictionary2 in array)
				{
					if (!this.#=zBsXSanI=.#=ztNr$6f$4jFpqECtQlA==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)])).Contains(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)].ToString()))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972110), Array.Empty<object>());
						flag = true;
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972070), Array.Empty<object>());
					}
				}
			}
		}
		return flag;
	}

	// Token: 0x060008F9 RID: 2297 RVA: 0x00049940 File Offset: 0x00047B40
	private bool #=zjbuCOMhpd_irbLsxRXs9G80=()
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972284), Array.Empty<object>());
		#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = null;
		int num = -1;
		#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= = this.#=zbkd1_SL26Bt5;
		for (int i = 0; i < #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=.Count; i++)
		{
			if (#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=[i].#=zo4gR$B4ZVFdYTDxEaw==().Count > 0)
			{
				foreach (int num2 in #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=[i].#=zo4gR$B4ZVFdYTDxEaw==().Keys)
				{
					if (#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=[i].#=zo4gR$B4ZVFdYTDxEaw==()[num2] > 0)
					{
						num = num2;
						break;
					}
				}
				if (num >= 0)
				{
					#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=[i];
					break;
				}
			}
		}
		if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972229), Array.Empty<object>());
			return false;
		}
		string text = this.#=zBsXSanI=.#=z15ymRssaWFeH(#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=(), (num == 0) ? 1 : 0, num);
		bool flag = false;
		if (text.Length < 1000)
		{
			try
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetData(text);
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)) && dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] is int)
				{
					this.#=zBsXSanI=.#=ztNr$6f$4jFpqECtQlA==(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)]));
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972110), Array.Empty<object>());
					flag = true;
				}
			}
			catch
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, text, Array.Empty<object>());
			}
			if (!flag && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032151)))
			{
				flag = true;
			}
		}
		else
		{
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071575));
			if (array != null)
			{
				foreach (Dictionary<string, object> dictionary2 in array)
				{
					if (!this.#=zBsXSanI=.#=ztNr$6f$4jFpqECtQlA==(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)])).Contains(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)].ToString()))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972110), Array.Empty<object>());
						flag = true;
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972070), Array.Empty<object>());
					}
				}
			}
		}
		return flag;
	}

	// Token: 0x060008FA RID: 2298 RVA: 0x00049C28 File Offset: 0x00047E28
	private bool #=z2FpJ1SW6HSfTFAIK7HCNPyM=()
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972207), Array.Empty<object>());
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (!#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zpFuBGU_pbGgs(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationAllianceCityCoords, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972734), Array.Empty<object>());
			return false;
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(this.#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, this.#=zBsXSanI=);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972673), Array.Empty<object>());
			return false;
		}
		bool result;
		try
		{
			string text = this.#=zBsXSanI=.#=zAA0VkBXDdKegEnGR4K3arhKmn1Ho(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=());
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973945), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
				});
				this.#=zhp_aikH5diw4gr0E2g==();
				text = this.#=zBsXSanI=.#=zLc07sTIa9KaKh4gk_pmHRZw1_oOs(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=());
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973905), new object[]
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973870), new object[]
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
						(text.Length > 1010) ? text.Substring(0, 1000) : text
					});
				}
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974066), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
					(text.Length > 1010) ? text.Substring(0, 1000) : text
				});
			}
			result = true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x060008FB RID: 2299 RVA: 0x00049E6C File Offset: 0x0004806C
	private bool #=zj$gEnjsgsOnRt28WPoJRSR0=()
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974010), Array.Empty<object>());
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = null;
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zpFuBGU_pbGgs(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationAllianceCityCoords, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(this.#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, this.#=zBsXSanI=);
		}
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = this.#=zFke0rAlePLN5();
		}
		bool result;
		try
		{
			string text = this.#=zBsXSanI=.#=zge7xsK2$r2DH(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=(), 0, 0, 1);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973972), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
				});
				this.#=zhp_aikH5diw4gr0E2g==();
				object[] array = JSONManager.GetArray(JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
				int num = 0;
				if (array != null)
				{
					foreach (Dictionary<string, object> dictionary in array)
					{
						if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601)) && Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]) == #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=())
						{
							num = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
						}
					}
				}
				if (num > 0)
				{
					text = this.#=zBsXSanI=.#=zMV_fZC22CEHViE8g4A==(num, false);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973686), new object[]
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973641), new object[]
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
							(text.Length > 1010) ? text.Substring(0, 1000) : text
						});
					}
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973586), new object[]
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
					});
				}
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973782), new object[]
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
					(text.Length > 1010) ? text.Substring(0, 1000) : text
				});
			}
			result = true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x060008FC RID: 2300 RVA: 0x0004A124 File Offset: 0x00048324
	private void #=z$EftBNisn1Ir()
	{
		string text;
		if (!string.IsNullOrWhiteSpace(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName))
		{
			text = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName;
		}
		else
		{
			text = this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H();
		}
		this.#=zBsXSanI=.#=zLbAeSYCTLemU(text);
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973741), new object[]
		{
			text
		});
	}

	// Token: 0x060008FD RID: 2301 RVA: 0x0004A1A4 File Offset: 0x000483A4
	private bool #=zU545SRtbghxF()
	{
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973697), Array.Empty<object>());
		int #=zhfS69jI= = 0;
		int #=zmWD8vxE= = 0;
		if (!#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zpFuBGU_pbGgs(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationAllianceCityCoords, out #=zhfS69jI=, out #=zmWD8vxE=))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972734), Array.Empty<object>());
			return false;
		}
		#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(this.#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, this.#=zBsXSanI=);
		if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908972673), Array.Empty<object>());
			return false;
		}
		bool result;
		try
		{
			this.#=zBsXSanI=.#=zOpP1dT8=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=());
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973412), new object[]
			{
				#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=()
			});
			this.#=zhp_aikH5diw4gr0E2g==();
			result = true;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x060008FE RID: 2302 RVA: 0x0004A2D8 File Offset: 0x000484D8
	private double #=zJUD_Lfh7vlfISsFPfGjBKlk=(object #=zsbwXxuA=)
	{
		Dictionary<string, object> dictionary = (Dictionary<string, object>)#=zsbwXxuA=;
		if (JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)) == null)
		{
			return 100000000.0;
		}
		int num = this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() - JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0);
		int num2 = this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() - JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0);
		return Math.Sqrt((double)(num * num + num2 * num2));
	}

	// Token: 0x060008FF RID: 2303 RVA: 0x0004A35C File Offset: 0x0004855C
	private bool #=zbllFtOCOo5oBXpvMGTpHNRc=(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
	{
		return #=zQrqFdos=.#=z5kpAZQpjT2b7() && #=zQrqFdos=.#=zGhmoNZChgwf8() < this.#=zJuQW8gI=;
	}

	// Token: 0x04000505 RID: 1285
	private static Dictionary<int, #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=> #=zRg2AoLvWNf85 = null;

	// Token: 0x04000506 RID: 1286
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000507 RID: 1287
	private bool #=zSJCXgrtDT$p4yz2CyjK3UsF4gylz;

	// Token: 0x04000508 RID: 1288
	private bool #=zefqXUipXk_kZ;

	// Token: 0x04000509 RID: 1289
	private bool #=zyNa48o$QnCSAP$EskIOIm0M=;

	// Token: 0x0400050A RID: 1290
	private string #=zm2oSGGagu94wBmQRHpr0kCWxYA0bE$fjRA==;

	// Token: 0x0400050B RID: 1291
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z80Ienm4pN63RdJiXkosEq$4=;

	// Token: 0x0400050C RID: 1292
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zZ3V8UwudWrFd;

	// Token: 0x0400050D RID: 1293
	private List<int> #=z9aXV16k7tKjznITfJQ==;

	// Token: 0x0400050E RID: 1294
	private List<int> #=zkr0fQ5KhviB40pIlEgkA6VU=;

	// Token: 0x0400050F RID: 1295
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000510 RID: 1296
	private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=;

	// Token: 0x04000511 RID: 1297
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD;

	// Token: 0x04000512 RID: 1298
	private UnitTypeCollection #=zlhLE8UQVU0AG;

	// Token: 0x04000513 RID: 1299
	private DateTime #=zJuQW8gI=;

	// Token: 0x04000514 RID: 1300
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x04000515 RID: 1301
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x04000516 RID: 1302
	private int[] #=zJHP2CeDqtLIN;

	// Token: 0x04000517 RID: 1303
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zeYLQo2n2g2lR;

	// Token: 0x04000518 RID: 1304
	private #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= #=zvPVvZaDW5sGehlg4AA==;

	// Token: 0x04000519 RID: 1305
	private #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8= #=zCCdwo8AGZiustnyqjw8wZSs=;

	// Token: 0x0400051A RID: 1306
	private List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> #=zXi9vZ5Ltb$swzaKUNQ==;

	// Token: 0x0400051B RID: 1307
	private UnitSquadCollection #=zDRdwTJDnt_rXZgSZ5Nm$Zqngz6iq;

	// Token: 0x0400051C RID: 1308
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x0400051D RID: 1309
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x0400051E RID: 1310
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x0400051F RID: 1311
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x04000520 RID: 1312
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;

	// Token: 0x04000521 RID: 1313
	private int #=z6Bha1HM=;

	// Token: 0x04000522 RID: 1314
	private #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO #=zbGFpMLw=;

	// Token: 0x04000523 RID: 1315
	private List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> #=zF5ZHDos=;

	// Token: 0x04000524 RID: 1316
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x04000525 RID: 1317
	private List<int> #=ztiB995TsnwxE;

	// Token: 0x04000526 RID: 1318
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zbkd1_SL26Bt5;

	// Token: 0x0200014F RID: 335
	private sealed class #=zIhomNoRZtUK0acfKJxHzBKo=
	{
		// Token: 0x06000901 RID: 2305 RVA: 0x0004A384 File Offset: 0x00048584
		internal bool #=zBo3gw5Bu1pAlxhsqyWLFXvI5rUNk(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zp13pRNQ=;
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0004A394 File Offset: 0x00048594
		internal bool #=zabYejfBRRBnfzTgy6AbVK2LWMhCt(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=z5w6HcG4= || (#=zQrqFdos=.#=zvnZc$RhG_1Du() == this.#=z5w6HcG4= - 1 && #=zQrqFdos=.#=z5kpAZQpjT2b7());
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0004A3C0 File Offset: 0x000485C0
		internal bool #=znyh2lSQ11J3tGHKjW$dAo$0KzQzd(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=z5w6HcG4=;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0004A3D4 File Offset: 0x000485D4
		internal bool #=zt7TrR8KRsPE$G4tVbqusk2Ap6jr1(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du() < this.#=z5w6HcG4= && !#=zQrqFdos=.#=z5kpAZQpjT2b7();
		}

		// Token: 0x04000527 RID: 1319
		public int #=zp13pRNQ=;

		// Token: 0x04000528 RID: 1320
		public int #=z5w6HcG4=;
	}

	// Token: 0x02000150 RID: 336
	private sealed class #=zJXkI3Wfktnp0arl_cNmU3XA=
	{
		// Token: 0x06000906 RID: 2310 RVA: 0x0004A3F8 File Offset: 0x000485F8
		internal bool #=zsvVZR2TQoDiVSnh2yL96YLh1rchV(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zIuEJkTTJgsiu && #=zQrqFdos=.#=z5kpAZQpjT2b7();
		}

		// Token: 0x06000907 RID: 2311 RVA: 0x0004A410 File Offset: 0x00048610
		internal bool #=zkTfIrhtlOCuoXPzvoZZJFiQjPe23(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=z_XBD5so=;
		}

		// Token: 0x06000908 RID: 2312 RVA: 0x0004A420 File Offset: 0x00048620
		internal bool #=zVvHqoQ9_lZvzuwC8Xl5UqJBnFGSL(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zGhmoNZChgwf8() < this.#=zlJSAjfPMVf41.#=zJuQW8gI=;
		}

		// Token: 0x06000909 RID: 2313 RVA: 0x0004A438 File Offset: 0x00048638
		internal bool #=z_YFNq2Qk_yt2t62zPSCX0ykICy_r(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zIuEJkTTJgsiu && !#=zQrqFdos=.#=z5kpAZQpjT2b7();
		}

		// Token: 0x04000529 RID: 1321
		public int #=zIuEJkTTJgsiu;

		// Token: 0x0400052A RID: 1322
		public int #=z_XBD5so=;

		// Token: 0x0400052B RID: 1323
		public #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=zlJSAjfPMVf41;
	}

	// Token: 0x02000151 RID: 337
	private sealed class #=zUm441WjjSSkl1AZpGW_pWgE=
	{
		// Token: 0x0600090B RID: 2315 RVA: 0x0004A45C File Offset: 0x0004865C
		internal bool #=zB5EXrdfNdwx0JgLdVUsnHOpMtwxdkYxflwfQPY8=(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == this.#=zAk8mKBk=;
		}

		// Token: 0x0400052C RID: 1324
		public int #=zAk8mKBk=;
	}

	// Token: 0x02000152 RID: 338
	private sealed class #=zVA5DTxsop0DII4nixnWcIFQ=
	{
		// Token: 0x0600090D RID: 2317 RVA: 0x0004A474 File Offset: 0x00048674
		internal bool #=zpG4eKe2Qn$8l7PVKlX6967JqJNwTKXkaHiBubQ0=(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zq2bPTdY=() == #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Attack && #=zQrqFdos=.#=zvnZc$RhG_1Du() == this.#=z5w6HcG4=;
		}

		// Token: 0x0600090E RID: 2318 RVA: 0x0004A490 File Offset: 0x00048690
		internal bool #=zeFebRgSqk6Hp$XLhqA4GMAlSQm6mmYv0bRZA_HA=(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zK5gF1KeGk_H_() == this.#=zs$RCjxM2v6ZUHz8M0w==.#=zMuFMjGQ=() && #=zQrqFdos=.#=zVVorJLug3m2L() == this.#=zlJSAjfPMVf41.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=();
		}

		// Token: 0x0400052D RID: 1325
		public int #=z5w6HcG4=;

		// Token: 0x0400052E RID: 1326
		public #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zs$RCjxM2v6ZUHz8M0w==;

		// Token: 0x0400052F RID: 1327
		public #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=zlJSAjfPMVf41;
	}

	// Token: 0x02000153 RID: 339
	private sealed class #=zkPAWP9vm2C_zB9mRkOPLv2g=
	{
		// Token: 0x06000910 RID: 2320 RVA: 0x0004A4CC File Offset: 0x000486CC
		internal bool #=zpgENx28vSQq7Ng5jIAqfaQI=(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zp13pRNQ=;
		}

		// Token: 0x06000911 RID: 2321 RVA: 0x0004A4DC File Offset: 0x000486DC
		internal bool #=ze_Jv5RvwFr_28CCN7Kzh0T8=(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zp13pRNQ=;
		}

		// Token: 0x04000530 RID: 1328
		public int #=zp13pRNQ=;
	}

	// Token: 0x02000154 RID: 340
	private sealed class #=znLzWnCgdrMN3$mQUGdCybHA=
	{
		// Token: 0x06000913 RID: 2323 RVA: 0x0004A4F4 File Offset: 0x000486F4
		internal bool #=z8G6sn$xZK_TgElDEzPAzE04MZZ7_(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zK5gF1KeGk_H_() == this.#=zI60pd6o84hZk.#=zMuFMjGQ=() && #=zQrqFdos=.#=zVVorJLug3m2L() == this.#=zlJSAjfPMVf41.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=zQrqFdos=.#=zzasQXAPWhOif() == this.#=zrneKYItKkdXP && #=zQrqFdos=.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1;
		}

		// Token: 0x04000531 RID: 1329
		public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zI60pd6o84hZk;

		// Token: 0x04000532 RID: 1330
		public #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs= #=zlJSAjfPMVf41;

		// Token: 0x04000533 RID: 1331
		public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP;
	}

	// Token: 0x02000155 RID: 341
	private sealed class #=zsKs89uXrpN5bf2Plh7eZaXM=
	{
		// Token: 0x06000915 RID: 2325 RVA: 0x0004A554 File Offset: 0x00048754
		internal bool #=z_7YXSb7o1hzOsOY0iw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zDMC3L_4=.#=zFMDiymuLQ7_4() && #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=zDMC3L_4=.#=zvnZc$RhG_1Du();
		}

		// Token: 0x06000916 RID: 2326 RVA: 0x0004A584 File Offset: 0x00048784
		internal bool #=ztTdee6kBNtxjD1L$Ug==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zq2bPTdY=().Id == this.#=zDMC3L_4=.#=zFMDiymuLQ7_4() && #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=zDMC3L_4=.#=zvnZc$RhG_1Du();
		}

		// Token: 0x04000534 RID: 1332
		public #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=zDMC3L_4=;
	}

	// Token: 0x02000156 RID: 342
	private enum #=ztIeE$PLGQDn1
	{

	}

	// Token: 0x02000157 RID: 343
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000919 RID: 2329 RVA: 0x0004A5CC File Offset: 0x000487CC
		internal bool #=zCGuIpYkw2u_u$oXlGQ==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=z5kpAZQpjT2b7();
		}

		// Token: 0x0600091A RID: 2330 RVA: 0x0004A5D4 File Offset: 0x000487D4
		internal bool #=zALKs6dQL4rpYk$TtfXTPnC0docpk(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == 108 && #=zQrqFdos=.#=zvnZc$RhG_1Du() > 0;
		}

		// Token: 0x0600091B RID: 2331 RVA: 0x0004A5EC File Offset: 0x000487EC
		internal bool #=zpru33SxWZNb4IHDsttWK6D$uLu1q(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == 109 && #=zQrqFdos=.#=zvnZc$RhG_1Du() > 0;
		}

		// Token: 0x0600091C RID: 2332 RVA: 0x0004A604 File Offset: 0x00048804
		internal bool #=zdqLMa8o0iaam3f1zWluoKYN6CDd4(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du() > 0;
		}

		// Token: 0x0600091D RID: 2333 RVA: 0x0004A610 File Offset: 0x00048810
		internal bool #=zrrlG236YsCCMb0qM93iabW8Wt0uNDu8a3cOEeqTcTKpU(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == 102 || #=zQrqFdos=.#=zFMDiymuLQ7_4() == 104;
		}

		// Token: 0x04000536 RID: 1334
		public static readonly #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU= #=zLkw0NRU= = new #=zLicknSqk4oZ$$HGCM50mCn_afuaV0CghH_RsdRs=.#=zyDNvciU=();

		// Token: 0x04000537 RID: 1335
		public static Func<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==, bool> #=zs33owmHLqq38TUjIyQ==;

		// Token: 0x04000538 RID: 1336
		public static Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool> #=zBpZPvCnDEsmjo40n$A==;

		// Token: 0x04000539 RID: 1337
		public static Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool> #=zw9eVTqKOLHpRbKGXkw==;

		// Token: 0x0400053A RID: 1338
		public static Func<#=zO6457TajDDxDJIsKqS1bbzDMLckn, bool> #=z8VZJeAeLcjxV366X$w==;

		// Token: 0x0400053B RID: 1339
		public static Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=zb4VLEhRcaQn9AW4bdg==;
	}
}
