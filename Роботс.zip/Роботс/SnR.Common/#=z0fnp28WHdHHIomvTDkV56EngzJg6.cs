﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000033 RID: 51
internal sealed class #=z0fnp28WHdHHIomvTDkV56EngzJg6
{
	// Token: 0x060000CD RID: 205 RVA: 0x000076A0 File Offset: 0x000058A0
	public #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD)
	{
		this.#=zQmveeqwfZtWH = #=zG2wnL_q7IxpD;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x000076B0 File Offset: 0x000058B0
	public #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		this.#=zQmveeqwfZtWH = new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(null, true, #=z8StzeqE=);
	}

	// Token: 0x060000CF RID: 207 RVA: 0x000076C8 File Offset: 0x000058C8
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQ4wZnctPyyRO()
	{
		return this.#=zQmveeqwfZtWH.#=zQ4wZnctPyyRO();
	}

	// Token: 0x060000D0 RID: 208 RVA: 0x000076D8 File Offset: 0x000058D8
	public #=zAjO7I84RW8RKI9PeCopgq9B$x73y #=z2fpO5C$YR90A()
	{
		return this.#=zXVLOfqSwzcUlJH29NqIIeM8=;
	}

	// Token: 0x060000D1 RID: 209 RVA: 0x000076E0 File Offset: 0x000058E0
	public void #=zfhU9lZN1BewC(#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=z$Ib9gYQ=)
	{
		this.#=zXVLOfqSwzcUlJH29NqIIeM8= = #=z$Ib9gYQ=;
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x000076EC File Offset: 0x000058EC
	public #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zI4J7zo5ZdOzg()
	{
		return this.#=zQmveeqwfZtWH;
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x000076F4 File Offset: 0x000058F4
	public bool #=zq76JuU9WPIZn()
	{
		return this.#=zQ4wZnctPyyRO().#=zq76JuU9WPIZn();
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x00007704 File Offset: 0x00005904
	public ProxyInfo #=z9TrQaE7EBV1U()
	{
		return this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U();
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x00007714 File Offset: 0x00005914
	public bool #=zkRQ4B7_fFmH0IMmfEQ==()
	{
		return this.#=zxosIuqq9MKrki8GPgrBvDKg=;
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x0000771C File Offset: 0x0000591C
	public void #=zF5F9PRZBGZrBbiy9ng==(bool #=z$Ib9gYQ=)
	{
		this.#=zxosIuqq9MKrki8GPgrBvDKg= = #=z$Ib9gYQ=;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00007728 File Offset: 0x00005928
	private Dictionary<string, object> #=zNazfdtw=(bool #=z1LiYjQy5vMJH, long #=zGcMUnK0tFuhw)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		long num = (#=zGcMUnK0tFuhw > 0L) ? #=zGcMUnK0tFuhw : JSONManager.EncodeTimeInt(DateTime.Now, false);
		if (num < this.#=zQ4wZnctPyyRO().#=zc3DeoTSaHY6p5yNLew==())
		{
			num = this.#=zQ4wZnctPyyRO().#=zc3DeoTSaHY6p5yNLew==() + (long)new Random().Next(100);
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045)] = num - this.#=zQ4wZnctPyyRO().#=zc3DeoTSaHY6p5yNLew==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946390)] = Convert.ToInt32(#=z1LiYjQy5vMJH);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946383)] = 0;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399)] = new object[0];
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899)] = this.#=zQ4wZnctPyyRO().#=zk0_Y$SJ_d1Er() - 1;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				1
			}
		};
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946372)] = new object[0];
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)] = num;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = this.#=zQ4wZnctPyyRO().#=zc3DeoTSaHY6p5yNLew==();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)] = null;
		return dictionary;
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x0000794C File Offset: 0x00005B4C
	private Dictionary<string, object> #=zr3QqntDzkElh()
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				1
			}
		};
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946365)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				this.#=zQ4wZnctPyyRO().#=zBVDBY_3gDr2hDFDdywwrWdQ=()
			}
		};
		if (this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B() != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946351)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
					this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==().ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)) ? this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==()[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] : 0L
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
					new object[]
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946330) + (this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==().ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946323)) ? this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==()[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] : 25L).ToString(),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946313) + this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString(),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946310) + this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString()
					}
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==().ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)) ? this.#=zQ4wZnctPyyRO().#=zhr1zOD1HSV5DW11Dog==()[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] : 0L
				}
			};
		}
		return dictionary;
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x00007B58 File Offset: 0x00005D58
	public string #=zMmyIB6$viHz8()
	{
		Dictionary<string, object> data = this.#=zr3QqntDzkElh();
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104048), JSONManager.SerializeData(data));
	}

	// Token: 0x060000DA RID: 218 RVA: 0x00007B84 File Offset: 0x00005D84
	public string #=zzrC2GSZBc9MG(List<int> #=zJcrsD5cc4l4C)
	{
		if (#=zJcrsD5cc4l4C.Count == 0)
		{
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946047));
		}
		int[] array = new int[#=zJcrsD5cc4l4C.Count];
		#=zJcrsD5cc4l4C.CopyTo(array);
		Dictionary<string, object> dictionary = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945996),
				new object[0]
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						100
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
						1
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				this.#=zQ4wZnctPyyRO().#=zk0_Y$SJ_d1Er() - 1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				new object[0]
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945989),
				new object[0]
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				array
			}
		};
		string text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945970), JSONManager.SerializeData(dictionary), -1, true, false);
		if (!text.Contains(#=zJcrsD5cc4l4C[0].ToString()))
		{
			return text;
		}
		dictionary = this.#=zr3QqntDzkElh();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976)] = array;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104048), JSONManager.SerializeData(dictionary), -1, true, false);
	}

	// Token: 0x060000DB RID: 219 RVA: 0x00007CF8 File Offset: 0x00005EF8
	public string #=z88KXN9YQlR89lG4bcw==(string #=zXuGeJQbVMolHLiENIA==, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zb0xp8Jxb2kam)
	{
		int #=z$Ib9gYQ= = (#=zb0xp8Jxb2kam != null) ? #=zb0xp8Jxb2kam.#=zxWJWBWxyVjKWhkQ0ywNvzKs=() : 0;
		string text = this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945947), #=zXuGeJQbVMolHLiENIA==, ref #=z$Ib9gYQ=, true, 0);
		if (!string.IsNullOrEmpty(text) && #=zb0xp8Jxb2kam != null)
		{
			#=zb0xp8Jxb2kam.#=zZSkNRUgj8yXAH6_cQElO$6Y=(#=z$Ib9gYQ=);
		}
		return text;
	}

	// Token: 0x060000DC RID: 220 RVA: 0x00007D3C File Offset: 0x00005F3C
	public string #=zXTTYoqGLxWmVM2mBWQ==(string #=zXuGeJQbVMolHLiENIA==, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zb0xp8Jxb2kam)
	{
		int #=z$Ib9gYQ= = (#=zb0xp8Jxb2kam != null) ? #=zb0xp8Jxb2kam.#=zxWJWBWxyVjKWhkQ0ywNvzKs=() : 0;
		string text = this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945929), #=zXuGeJQbVMolHLiENIA==, ref #=z$Ib9gYQ=, false, 0);
		if (!string.IsNullOrEmpty(text) && #=zb0xp8Jxb2kam != null)
		{
			#=zb0xp8Jxb2kam.#=zZSkNRUgj8yXAH6_cQElO$6Y=(#=z$Ib9gYQ=);
		}
		return text;
	}

	// Token: 0x060000DD RID: 221 RVA: 0x00007D80 File Offset: 0x00005F80
	public string #=z25ZMSNzHGIdZYvzzQw==()
	{
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				1
			}
		});
		int #=z$Ib9gYQ= = this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zxWJWBWxyVjKWhkQ0ywNvzKs=();
		string text = this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946173), #=zWC15sHaiwX4N, ref #=z$Ib9gYQ=, true, 0);
		if (!string.IsNullOrEmpty(text))
		{
			this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zZSkNRUgj8yXAH6_cQElO$6Y=(#=z$Ib9gYQ=);
		}
		return text;
	}

	// Token: 0x060000DE RID: 222 RVA: 0x00007E14 File Offset: 0x00006014
	public string #=zd47NNCPsuiuL(int #=zCHPchKE=, List<string> #=z5TVtvjkeL9ZT)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < #=z5TVtvjkeL9ZT.Count; i++)
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(',');
			}
			stringBuilder.Append(#=z5TVtvjkeL9ZT[i]);
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946148), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946126) + stringBuilder.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946107), #=zCHPchKE=, false, false);
	}

	// Token: 0x060000DF RID: 223 RVA: 0x00007E8C File Offset: 0x0000608C
	public string #=zpeSgyDU=(int #=zQrqFdos=, int #=zKFlJyLE=)
	{
		string text = (#=zQrqFdos= / 20).ToString();
		string text2 = (#=zQrqFdos= / 20 + ((#=zQrqFdos= > 0) ? 1 : -1)).ToString();
		string text3 = (#=zKFlJyLE= / 20).ToString();
		string text4 = (#=zKFlJyLE= / 20 + ((#=zKFlJyLE= > 0) ? 1 : -1)).ToString();
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946096), string.Concat(new string[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946093),
			text3,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946067),
			text,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946063),
			text3,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946067),
			text2,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946063),
			text4,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946067),
			text,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946063),
			text4,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946067),
			text2,
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945785)
		}));
	}

	// Token: 0x060000E0 RID: 224 RVA: 0x00007F9C File Offset: 0x0000619C
	public string #=z$F1M_0mTucCE(string #=zvPiOyGQ=)
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945783), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945754) + #=zvPiOyGQ= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945751));
	}

	// Token: 0x060000E1 RID: 225 RVA: 0x00007FC8 File Offset: 0x000061C8
	public string #=z$F1M_0mTucCE(List<int> #=zuGuBk_XthqCr)
	{
		object[] array = new object[#=zuGuBk_XthqCr.Count];
		for (int i = 0; i < #=zuGuBk_XthqCr.Count; i++)
		{
			array[i] = #=zuGuBk_XthqCr[i];
		}
		return this.#=z$F1M_0mTucCE(array);
	}

	// Token: 0x060000E2 RID: 226 RVA: 0x00008008 File Offset: 0x00006208
	public string #=z$F1M_0mTucCE(int[] #=zuGuBk_XthqCr)
	{
		object[] array = new object[#=zuGuBk_XthqCr.Length];
		for (int i = 0; i < #=zuGuBk_XthqCr.Length; i++)
		{
			array[i] = #=zuGuBk_XthqCr[i];
		}
		return this.#=z$F1M_0mTucCE(array);
	}

	// Token: 0x060000E3 RID: 227 RVA: 0x00008040 File Offset: 0x00006240
	private string #=z$F1M_0mTucCE(object[] #=zSKjgFL4dOimr)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				#=zSKjgFL4dOimr
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				new object[0]
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945783), JSONManager.SerializeData(data));
	}

	// Token: 0x060000E4 RID: 228 RVA: 0x00008090 File Offset: 0x00006290
	public string #=z$V2EKEDsMxpw(string #=zb2sTXDc=)
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945735), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945710) + #=zb2sTXDc= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946107));
	}

	// Token: 0x060000E5 RID: 229 RVA: 0x000080BC File Offset: 0x000062BC
	public string #=z$V2EKEDsMxpw(List<int> #=zrfC66YNK2QgA)
	{
		object[] array = new object[#=zrfC66YNK2QgA.Count];
		for (int i = 0; i < #=zrfC66YNK2QgA.Count; i++)
		{
			array[i] = #=zrfC66YNK2QgA[i];
		}
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945735), JSONManager.SerializeData(data));
	}

	// Token: 0x060000E6 RID: 230 RVA: 0x00008124 File Offset: 0x00006324
	public string #=zOpP1dT8=(int #=zvPiOyGQ=)
	{
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zvPiOyGQ=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			}
		});
		int num = 0;
		return this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945691), #=zWC15sHaiwX4N, ref num, true, 100);
	}

	// Token: 0x060000E7 RID: 231 RVA: 0x00008190 File Offset: 0x00006390
	public string #=zqFcfGSuWw3TYeNCEHw==(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=zFr$kLmfy4Pwedaa8jg==)
	{
		return this.#=zqFcfGSuWw3TYeNCEHw==(#=z3v_Pt336Xf0A, #=zFr$kLmfy4Pwedaa8jg==, -1);
	}

	// Token: 0x060000E8 RID: 232 RVA: 0x0000819C File Offset: 0x0000639C
	public string #=zqFcfGSuWw3TYeNCEHw==(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=zFr$kLmfy4Pwedaa8jg==, int #=zwDZRfep46qev)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				4
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				new object[]
				{
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
							#=zwDZRfep46qev
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=z3v_Pt336Xf0A.#=ziV0Qa4zwZEC4()
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				new object[]
				{
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
							#=zFr$kLmfy4Pwedaa8jg==
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=z3v_Pt336Xf0A.#=ziV0Qa4zwZEC4()
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				5
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945672), JSONManager.SerializeData(data));
	}

	// Token: 0x060000E9 RID: 233 RVA: 0x00008388 File Offset: 0x00006588
	public string #=zoQ7ksjO8UdfACoZRDQ==(ResourceTypes #=ztF2uQho=, ResourceTypes #=zrA0ofbIqFhAA, int #=zvTk1l7IdwA$d, int #=z6IsiaXDyfiLs, ResExchangeRules.OfferPriorityTypes #=zttmyLQ0=)
	{
		int num;
		switch (#=ztF2uQho=)
		{
		case ResourceTypes.Grain:
			num = 3;
			break;
		case ResourceTypes.Bronze:
			num = 2;
			break;
		case ResourceTypes.Lumber:
			num = 1;
			break;
		default:
			num = 5;
			break;
		}
		int num2;
		switch (#=zrA0ofbIqFhAA)
		{
		case ResourceTypes.Grain:
			num2 = 3;
			break;
		case ResourceTypes.Bronze:
			num2 = 2;
			break;
		case ResourceTypes.Lumber:
			num2 = 1;
			break;
		default:
			num2 = 5;
			break;
		}
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				#=z6IsiaXDyfiLs
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zvTk1l7IdwA$d
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				200
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				2
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				(#=zttmyLQ0= == ResExchangeRules.OfferPriorityTypes.BySpeed) ? 1 : 3
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				num
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				100
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				num2
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				24
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945672), JSONManager.SerializeData(data));
	}

	// Token: 0x060000EA RID: 234 RVA: 0x0000854C File Offset: 0x0000674C
	public string #=z15GmD71PK0sWv37WvSM2Ya4hh7Qpaon7JN3p6eg=(int #=zW51GUCKxoEZiSmQgnw==, int #=zQ1CibsU1OwZU)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				4
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				100
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				5
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
				#=zW51GUCKxoEZiSmQgnw==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
				#=zQ1CibsU1OwZU
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945672), JSONManager.SerializeData(data));
	}

	// Token: 0x060000EB RID: 235 RVA: 0x000086B4 File Offset: 0x000068B4
	public string #=zLNDNAVTQHosqz4Uifw==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945898), JSONManager.SerializeData(data));
	}

	// Token: 0x060000EC RID: 236 RVA: 0x000086E4 File Offset: 0x000068E4
	public object[] #=z_WwoAi$Ptgio()
	{
		object data = JSONManager.GetData(this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945970), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945874)));
		if (!(data is object[]))
		{
			return null;
		}
		return (object[])data;
	}

	// Token: 0x060000ED RID: 237 RVA: 0x00008724 File Offset: 0x00006924
	public string #=zUqoz8aR4mJrU(int #=z1lwIce2YhvXU)
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945840), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945822) + #=z1lwIce2YhvXU.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945802));
	}

	// Token: 0x060000EE RID: 238 RVA: 0x00008758 File Offset: 0x00006958
	public string #=zi3Aa1spKVns7()
	{
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L));
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945794), #=zWC15sHaiwX4N);
	}

	// Token: 0x060000EF RID: 239 RVA: 0x00008788 File Offset: 0x00006988
	public string #=zwJ6drvwPG76Tqli7tzW6AYSBlcCm()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945524), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945492));
	}

	// Token: 0x060000F0 RID: 240 RVA: 0x000087A4 File Offset: 0x000069A4
	public string #=zxg40d0O4ierUILFqqfU_MwM=(int #=zvPiOyGQ=)
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945485), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945452) + #=zvPiOyGQ=.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945437));
	}

	// Token: 0x060000F1 RID: 241 RVA: 0x000087D8 File Offset: 0x000069D8
	public string #=zW9BgawRdvCy$(List<int> #=zhwKol3marK68)
	{
		Dictionary<string, object> dictionary = this.#=zr3QqntDzkElh();
		object[] array = new object[#=zhwKol3marK68.Count];
		for (int i = 0; i < #=zhwKol3marK68.Count; i++)
		{
			array[i] = #=zhwKol3marK68[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] = array;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104048), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060000F2 RID: 242 RVA: 0x00008840 File Offset: 0x00006A40
	private string #=zmWojNA8rwnqNDtfROg==(int #=zbwrJfOI=, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP, UnitSquadCollection #=zIzeO7X$TAdP_KrQ03A==, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw=, object[] #=z1GUSQNlTLrYB)
	{
		return this.#=zL9LdMuFPkGmsiBCBZA==(this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), #=zbwrJfOI=, 0, #=zrneKYItKkdXP, #=zIzeO7X$TAdP_KrQ03A==, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000F3 RID: 243 RVA: 0x00008870 File Offset: 0x00006A70
	private string #=zL9LdMuFPkGmsiBCBZA==(int #=zL7SBQTg=, int #=zbwrJfOI=, int #=z4qhBKas=, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP, UnitSquadCollection #=zIzeO7X$TAdP_KrQ03A==, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw=, object[] #=z1GUSQNlTLrYB)
	{
		object[] array;
		if (#=zzFbIudPbcByFmBe_wslCCsw= != null)
		{
			array = new object[#=zzFbIudPbcByFmBe_wslCCsw=.Count];
			int num = 0;
			using (Dictionary<int, UnitSquadCollection>.KeyCollection.Enumerator enumerator = #=zzFbIudPbcByFmBe_wslCCsw=.Keys.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					int num2 = enumerator.Current;
					array[num] = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
							num2
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zvdQCggY0zXH7LE9EiA==(#=zzFbIudPbcByFmBe_wslCCsw=[num2])
						}
					};
					num++;
				}
				goto IL_8B;
			}
		}
		array = null;
		IL_8B:
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = dictionary;
		string key = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684);
		Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), null);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945418), null);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), #=zL7SBQTg=);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), #=zbwrJfOI=);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), #=z4qhBKas=);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), null);
		string key2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981);
		Dictionary<string, object> dictionary4 = new Dictionary<string, object>();
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), (int)#=zrneKYItKkdXP);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), array);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060495), false);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069661), null);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), null);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zvdQCggY0zXH7LE9EiA==(#=zIzeO7X$TAdP_KrQ03A==));
		string key3 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045);
		object value;
		if (#=z1GUSQNlTLrYB == null || #=z1GUSQNlTLrYB.Length == 0)
		{
			value = null;
		}
		else
		{
			(value = new Dictionary<string, object>()).Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), #=z1GUSQNlTLrYB);
		}
		dictionary4.Add(key3, value);
		dictionary3.Add(key2, dictionary4);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945411), #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zvdQCggY0zXH7LE9EiA==(#=zL5HENIqQVsI0YcTj6XQHBQM=));
		dictionary2[key] = dictionary3;
		string text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945656), JSONManager.SerializeData(dictionary));
		if (text.Length < 1000 && text.ToLower().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909081981)) && #=z1GUSQNlTLrYB != null)
		{
			text = this.#=zL9LdMuFPkGmsiBCBZA==(#=zL7SBQTg=, #=zbwrJfOI=, #=z4qhBKas=, #=zrneKYItKkdXP, #=zIzeO7X$TAdP_KrQ03A==, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, null);
		}
		return text;
	}

	// Token: 0x060000F4 RID: 244 RVA: 0x00008AD8 File Offset: 0x00006CD8
	private static Dictionary<string, object> #=zvdQCggY0zXH7LE9EiA==(UnitSquadCollection #=zxHIOVSaavkpE)
	{
		if (#=zxHIOVSaavkpE == null)
		{
			return null;
		}
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zxHIOVSaavkpE.ToDictionary()
			}
		};
	}

	// Token: 0x060000F5 RID: 245 RVA: 0x00008AFC File Offset: 0x00006CFC
	public string #=zj6mJJFZU84bVSPLgcS8vCmc=(UnitSquadCollection #=zxHIOVSaavkpE)
	{
		return this.#=zmWojNA8rwnqNDtfROg==(this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)7, #=zxHIOVSaavkpE, null, null, null);
	}

	// Token: 0x060000F6 RID: 246 RVA: 0x00008B1C File Offset: 0x00006D1C
	public string #=zf6Rj4tTeYocpS$xPAy8PT6s=(UnitSquadCollection #=zxHIOVSaavkpE)
	{
		return this.#=zmWojNA8rwnqNDtfROg==(this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)9, #=zxHIOVSaavkpE, null, null, null);
	}

	// Token: 0x060000F7 RID: 247 RVA: 0x00008B3C File Offset: 0x00006D3C
	public string #=zWYvEC7HhMxBOcSI89TZRLg0=(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000F8 RID: 248 RVA: 0x00008B6C File Offset: 0x00006D6C
	public string #=z2VXbeg3zTNXbJ4Pc71BOktpzGzg4(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, object[] #=z1GUSQNlTLrYB)
	{
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)9, #=zxHIOVSaavkpE, null, null, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00008B7C File Offset: 0x00006D7C
	public string #=zWicondYgaCG3plz5xLOBBmOFiSAU(int #=zoFcaLQI=, UnitSquadCollection #=zxHIOVSaavkpE, object[] #=z1GUSQNlTLrYB)
	{
		return this.#=zL9LdMuFPkGmsiBCBZA==(#=zoFcaLQI=, this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), 0, (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)9, #=zxHIOVSaavkpE, null, null, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00008BA8 File Offset: 0x00006DA8
	public string #=zMV_fZC22CEHViE8g4A==(int #=zNXxl4XZUXyGh, bool #=zYUqVvxv987VkXtyZ5Dh9jkY=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		if (#=zYUqVvxv987VkXtyZ5Dh9jkY=)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zNXxl4XZUXyGh
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
					10000
				}
			};
		}
		else
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zNXxl4XZUXyGh
				}
			};
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945643), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060000FB RID: 251 RVA: 0x00008C4C File Offset: 0x00006E4C
	public string #=zZgTEjjDG86v_(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP, int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000FC RID: 252 RVA: 0x00008C80 File Offset: 0x00006E80
	public string #=zow1rctFaF6MDmvemZw==(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000FD RID: 253 RVA: 0x00008CB0 File Offset: 0x00006EB0
	public void #=zCRHsHQoSr4MUrXWztNGwnihzEjWz(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zhKuEROYUOEZ7x$o7oJeG97Y=, #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zyfyFTf4=)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zCRHsHQoSr4MUrXWztNGwnihzEjWz(this, #=zQhs6iYQ=, #=zxHIOVSaavkpE, #=zhKuEROYUOEZ7x$o7oJeG97Y=, #=zyfyFTf4=);
	}

	// Token: 0x060000FE RID: 254 RVA: 0x00008CC0 File Offset: 0x00006EC0
	public string #=ztRSQy0HcRHKziQrWOA==(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x060000FF RID: 255 RVA: 0x00008CF0 File Offset: 0x00006EF0
	public string #=ztRSQy0HcRHKziQrWOA==(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000100 RID: 256 RVA: 0x00008D24 File Offset: 0x00006F24
	public string #=zNc1Djl6$0nfPKGm71TpvFgM=(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)1;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000101 RID: 257 RVA: 0x00008D54 File Offset: 0x00006F54
	public string #=zNc1Djl6$0nfPKGm71TpvFgM=(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)1;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000102 RID: 258 RVA: 0x00008D88 File Offset: 0x00006F88
	public string #=zs39vp3mWzzdw(int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zQhs6iYQ=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000103 RID: 259 RVA: 0x00008DB8 File Offset: 0x00006FB8
	public string #=zCM8rb8eNLj3u(int #=zGJE03EA=, bool #=zGjrFyHs=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		int #=zL7SBQTg= = this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=();
		int #=z4qhBKas= = 1;
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP = #=zGjrFyHs= ? ((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2) : ((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5);
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zL9LdMuFPkGmsiBCBZA==(#=zL7SBQTg=, #=zGJE03EA=, #=z4qhBKas=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000104 RID: 260 RVA: 0x00008E00 File Offset: 0x00007000
	public string #=zrOsS4uPdgCzmsIi3DSpcKVM=(int #=zOnUs4$6va9K4, #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zrneKYItKkdXP, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, int #=zTH01DjU=)
	{
		int #=zbwrJfOI= = -#=zOnUs4$6va9K4;
		Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw= = null;
		object #=z1GUSQNlTLrYB;
		if (#=zTH01DjU= <= 0)
		{
			#=z1GUSQNlTLrYB = null;
		}
		else
		{
			(#=z1GUSQNlTLrYB = new object[1])[0] = #=zTH01DjU=;
		}
		return this.#=zmWojNA8rwnqNDtfROg==(#=zbwrJfOI=, #=zrneKYItKkdXP, #=zxHIOVSaavkpE, #=zL5HENIqQVsI0YcTj6XQHBQM=, #=zzFbIudPbcByFmBe_wslCCsw=, #=z1GUSQNlTLrYB);
	}

	// Token: 0x06000105 RID: 261 RVA: 0x00008E34 File Offset: 0x00007034
	public string #=zByObLAOc9qc_xCEn1A==(int #=zQhs6iYQ=, UnitSquadCollection #=zhfGv7gMp_RY6u9ayNw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945418),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						5
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069661),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
						6
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945624),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zvdQCggY0zXH7LE9EiA==(#=zhfGv7gMp_RY6u9ayNw==)
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945617),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zQhs6iYQ=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945411),
				null
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945656), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000106 RID: 262 RVA: 0x00008FDC File Offset: 0x000071DC
	public string #=zge7xsK2$r2DH(int #=zbwrJfOI=, #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zTUPCAHg=)
	{
		switch (#=zTUPCAHg=.#=zq2bPTdY=())
		{
		case ResourceTypes.Grain:
			return this.#=zge7xsK2$r2DH(#=zbwrJfOI=, 0, 0, #=zTUPCAHg=.#=zlIXJ9$NfUZc_());
		case ResourceTypes.Bronze:
			return this.#=zge7xsK2$r2DH(#=zbwrJfOI=, 0, #=zTUPCAHg=.#=zlIXJ9$NfUZc_(), 0);
		case ResourceTypes.Lumber:
			return this.#=zge7xsK2$r2DH(#=zbwrJfOI=, #=zTUPCAHg=.#=zlIXJ9$NfUZc_(), 0, 0);
		default:
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945614), new object[]
			{
				#=zTUPCAHg=.#=zyhMluFK2CBji()
			});
		}
	}

	// Token: 0x06000107 RID: 263 RVA: 0x00009054 File Offset: 0x00007254
	public string #=zge7xsK2$r2DH(int #=zbwrJfOI=, int #=zyTqdZlDghw6s, int #=zrHVdHhXM0dTO, int #=zyCCuOU4OBChxx9UP3Q==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945617),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zbwrJfOI=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945411),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945418),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
								#=zyTqdZlDghw6s
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								#=zrHVdHhXM0dTO
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								#=zyCCuOU4OBChxx9UP3Q==
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
								0
							}
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945656), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000108 RID: 264 RVA: 0x00009270 File Offset: 0x00007470
	public string #=zM0a73Ky1Wph_OsGGRtca10obKG17(int #=zbwrJfOI=, int #=zEhF62so=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945617),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zbwrJfOI=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945411),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945418),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
						#=zEhF62so=
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945656), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000109 RID: 265 RVA: 0x000093C0 File Offset: 0x000075C0
	public string #=zjvkC2AJLgQ7VwVU_2A==(int #=zbwrJfOI=, #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=zrjon8Kw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945617),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zbwrJfOI=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945411),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945418),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
								#=zrjon8Kw=
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								#=z3v_Pt336Xf0A.#=ziV0Qa4zwZEC4()
							}
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945656), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600010A RID: 266 RVA: 0x00009530 File Offset: 0x00007730
	public string #=zFUjrYLmBgtGt(int #=zsn3Pamg=, int #=zNvCMwussKumm, bool #=z4pwo5VWS$9bQ)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				(#=z4pwo5VWS$9bQ > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zNvCMwussKumm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				#=z4pwo5VWS$9bQ
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zsn3Pamg=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945567), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600010B RID: 267 RVA: 0x000095E0 File Offset: 0x000077E0
	public #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zju79dCyB4r7u(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zHIedO$w=, int #=zNvCMwussKumm)
	{
		if (#=zNvCMwussKumm <= 0)
		{
			return new #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945541)));
		}
		int num = 0;
		string text = null;
		while (#=zNvCMwussKumm > 0)
		{
			Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
			bool flag;
			switch (#=zHIedO$w=.#=z_hmItAwnEING())
			{
			case (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)0:
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						#=zNvCMwussKumm
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
						false
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zHIedO$w=.#=zMuFMjGQ=()
					}
				};
				text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947301), JSONManager.SerializeData(dictionary));
				flag = (#=zNvCMwussKumm > 1);
				break;
			case (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)1:
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						new object[]
						{
							new Dictionary<string, object>
							{
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
									#=zNvCMwussKumm
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
									false
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
									false
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
									#=zHIedO$w=.#=zMuFMjGQ=()
								}
							}
						}
					}
				};
				text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947268), JSONManager.SerializeData(dictionary));
				flag = (#=zNvCMwussKumm > 1);
				break;
			case (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)2:
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zHIedO$w=.#=zMuFMjGQ=()
					}
				};
				text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947236), JSONManager.SerializeData(dictionary));
				flag = false;
				break;
			case (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)3:
				goto IL_268;
			case (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)4:
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						false
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						true
					}
				};
				text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947455), JSONManager.SerializeData(dictionary));
				flag = false;
				break;
			default:
				goto IL_268;
			}
			if (flag)
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = null;
				try
				{
					object data = JSONManager.GetData(text);
					if (data != null)
					{
						Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684));
						object[] array = JSONManager.GetArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
						if (array != null && array.Length != 0)
						{
							dictionary2 = (Dictionary<string, object>)array[0];
						}
						int num2 = JSONManager.ExtractIntSafe(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0);
						int num3 = JSONManager.ExtractIntSafe(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0);
						if (#=zHIedO$w=.#=zMuFMjGQ=() == num2 && num3 > 0)
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zHIedO$w=, num3);
						}
						else if (#=zHIedO$w=.#=zd$BbM3Y=() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947398) && JSONManager.GetInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947376), 0) > 0)
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zHIedO$w=, num3);
						}
					}
				}
				catch
				{
				}
				if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
				{
					num += #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
					#=zNvCMwussKumm -= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
					continue;
				}
				break;
			}
			else
			{
				if (text.Length > 10000)
				{
					num++;
					#=zNvCMwussKumm--;
					continue;
				}
				break;
			}
			IL_268:
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947438), Array.Empty<object>());
		}
		return new #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=((num > 0) ? new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zHIedO$w=, num) : null, text);
	}

	// Token: 0x0600010C RID: 268 RVA: 0x00009994 File Offset: 0x00007B94
	public string #=z8MWHQ2xuSrU2(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947301), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600010D RID: 269 RVA: 0x00009A2C File Offset: 0x00007C2C
	public string #=zzRaqor_c0Nlx8w$KJg==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947372), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x0600010E RID: 270 RVA: 0x00009A4C File Offset: 0x00007C4C
	public string #=zeoI_JM$qmO3Jp7VRURuP390=()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947332), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x0600010F RID: 271 RVA: 0x00009A6C File Offset: 0x00007C6C
	public string #=zmCoo1cf$wbnyUGo_O$bDNY8=(int #=zgffFRY8PRwg8wZpZ_w==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgffFRY8PRwg8wZpZ_w==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				1
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947053), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000110 RID: 272 RVA: 0x00009ADC File Offset: 0x00007CDC
	public string #=zPqLTAl9NPKhi7JX8uLKz7Q8R7E_B(int #=z2bq3T_YJoHv4aL_3Uw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				#=z2bq3T_YJoHv4aL_3Uw==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947018), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000111 RID: 273 RVA: 0x00009B34 File Offset: 0x00007D34
	public string #=zvKSBsqfaroQezK0jE98NEtE=(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==)
	{
		List<object> list = new List<object>();
		foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in #=zatMRdFUxBCRS1oul8g==)
		{
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() != null && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zr4Y9pMX2tLmdnCGRJw==() > 0)
			{
				this.#=zQ4wZnctPyyRO().#=zPGfL4rgl8WkG(this.#=zQ4wZnctPyyRO().#=zd_DW0ufJYCod() + 1);
				Dictionary<string, object> item = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						this.#=zQ4wZnctPyyRO().#=zd_DW0ufJYCod()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Id == 104) ? #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zr4Y9pMX2tLmdnCGRJw==() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
								(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Id == 102) ? #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zr4Y9pMX2tLmdnCGRJw==() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082),
								(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Id == 810) ? #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zr4Y9pMX2tLmdnCGRJw==() : 0
							}
						}
					}
				};
				list.Add(item);
			}
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		object[] array = new object[list.Count];
		for (int i = 0; i < list.Count; i++)
		{
			array[i] = list[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)] = array;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946984), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000112 RID: 274 RVA: 0x00009D8C File Offset: 0x00007F8C
	public string #=zQ3GmQEFE_q6Y(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==, bool #=z2oXmOW4ggLUbJDvHZA==)
	{
		bool flag = false;
		bool flag2 = false;
		if (#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=() != null)
		{
			if (#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4)
			{
				flag = true;
			}
			else if (#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)2 || #=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)3)
			{
				flag2 = true;
			}
		}
		string text = this.#=zQ3GmQEFE_q6Y(#=zUOCbBE7lBfRpv5tNuA==, #=z2oXmOW4ggLUbJDvHZA==, flag);
		if (text.Length < 1000 && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946965)) && !flag && flag2)
		{
			text = this.#=zQ3GmQEFE_q6Y(#=zUOCbBE7lBfRpv5tNuA==, #=z2oXmOW4ggLUbJDvHZA==, true);
		}
		return text;
	}

	// Token: 0x06000113 RID: 275 RVA: 0x00009E14 File Offset: 0x00008014
	private string #=zQ3GmQEFE_q6Y(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==, bool #=z2oXmOW4ggLUbJDvHZA==, bool #=zCv_PQKyIFH1OcH135qdLKIw=)
	{
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		if (#=zCv_PQKyIFH1OcH135qdLKIw=)
		{
			dictionary.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), false);
		}
		Dictionary<string, object> dictionary2 = this.#=zNazfdtw=(false, 0L);
		dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z2oXmOW4ggLUbJDvHZA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						dictionary
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						-1
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zUOCbBE7lBfRpv5tNuA==.#=zFMDiymuLQ7_4()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								0
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								#=zUOCbBE7lBfRpv5tNuA==.#=zAdM$oWHPKFC_gx1bYQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								#=zUOCbBE7lBfRpv5tNuA==.#=zfTB62qendhk_VEy8rw==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								#=zUOCbBE7lBfRpv5tNuA==.#=zY0soxphmGIACbOHy6A==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								#=zUOCbBE7lBfRpv5tNuA==.#=zlSY2GGkBa6S3MkHuDQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
								#=zUOCbBE7lBfRpv5tNuA==.#=z_ffm9$kcf9Y8EY_3cw==()
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary2));
	}

	// Token: 0x06000114 RID: 276 RVA: 0x0000A02C File Offset: 0x0000822C
	public string #=zDqCpkITFJ_yR(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==, bool #=z2oXmOW4ggLUbJDvHZA==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z2oXmOW4ggLUbJDvHZA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						new Dictionary<string, object>()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zUOCbBE7lBfRpv5tNuA==.#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zUOCbBE7lBfRpv5tNuA==.#=zFMDiymuLQ7_4()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du()
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								#=zUOCbBE7lBfRpv5tNuA==.#=zAdM$oWHPKFC_gx1bYQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								#=zUOCbBE7lBfRpv5tNuA==.#=zfTB62qendhk_VEy8rw==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								#=zUOCbBE7lBfRpv5tNuA==.#=zY0soxphmGIACbOHy6A==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								#=zUOCbBE7lBfRpv5tNuA==.#=zlSY2GGkBa6S3MkHuDQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
								#=zUOCbBE7lBfRpv5tNuA==.#=z_ffm9$kcf9Y8EY_3cw==()
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000115 RID: 277 RVA: 0x0000A234 File Offset: 0x00008434
	public string #=zgMfGw_J9m6OAub_Oqw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
								false
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zUOCbBE7lBfRpv5tNuA==.#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zUOCbBE7lBfRpv5tNuA==.#=zFMDiymuLQ7_4()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du()
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								#=zUOCbBE7lBfRpv5tNuA==.#=zAdM$oWHPKFC_gx1bYQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								#=zUOCbBE7lBfRpv5tNuA==.#=zfTB62qendhk_VEy8rw==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								#=zUOCbBE7lBfRpv5tNuA==.#=zY0soxphmGIACbOHy6A==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								#=zUOCbBE7lBfRpv5tNuA==.#=zlSY2GGkBa6S3MkHuDQ==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
								#=zUOCbBE7lBfRpv5tNuA==.#=z_ffm9$kcf9Y8EY_3cw==()
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000116 RID: 278 RVA: 0x0000A450 File Offset: 0x00008650
	public string #=zkPJPpU_KgKJ3P1gzKw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==, #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zUOCbBE7lBfRpv5tNuA==.#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		if (#=zsQeD_TZk1UIL != null)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = #=zsQeD_TZk1UIL.#=zMuFMjGQ=();
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)] = #=z2jQo5wXKwIqT;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)] = false;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947175), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000117 RID: 279 RVA: 0x0000A570 File Offset: 0x00008770
	public string #=zoObeVpn9gW2BopkuHw==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z3v_Pt336Xf0A, #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z3v_Pt336Xf0A.#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z3v_Pt336Xf0A.#=zvnZc$RhG_1Du() + 1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		if (#=zsQeD_TZk1UIL != null)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = #=zsQeD_TZk1UIL.#=zMuFMjGQ=();
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)] = #=z2jQo5wXKwIqT;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)] = false;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947175), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000118 RID: 280 RVA: 0x0000A690 File Offset: 0x00008890
	public string #=z8dvXiwU03gsnIHVe1mH4bYxt069R(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zsbwXxuA=, #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zsbwXxuA=.Id
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				14
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		if (#=zsQeD_TZk1UIL != null)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = #=zsQeD_TZk1UIL.#=zMuFMjGQ=();
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)] = #=z2jQo5wXKwIqT;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)] = false;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947175), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000119 RID: 281 RVA: 0x0000A794 File Offset: 0x00008994
	public string #=zSRf8OroOie0MQIf$sUvr9h8sDkBD(int #=z1z2$mZ8=, #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z1z2$mZ8=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				2
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		if (#=zsQeD_TZk1UIL != null)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = #=zsQeD_TZk1UIL.#=zMuFMjGQ=();
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)] = #=z2jQo5wXKwIqT;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)] = false;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947175), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600011A RID: 282 RVA: 0x0000A890 File Offset: 0x00008A90
	public string #=zVSOFFl8S57mfjUWwurka0gCfUJeRlNwwRg==(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		return this.#=zJhW0gfPIqK6804QBv4u_08mYsMJB(1008, #=zsQeD_TZk1UIL, #=z2jQo5wXKwIqT);
	}

	// Token: 0x0600011B RID: 283 RVA: 0x0000A8A0 File Offset: 0x00008AA0
	public string #=zJhW0gfPIqK6804QBv4u_08mYsMJB(int #=zkTISB$I=, #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zsQeD_TZk1UIL, int #=z2jQo5wXKwIqT)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zkTISB$I=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				6
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		if (#=zsQeD_TZk1UIL != null)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = #=zsQeD_TZk1UIL.#=zMuFMjGQ=();
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)] = #=z2jQo5wXKwIqT;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)] = false;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947175), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600011C RID: 284 RVA: 0x0000A99C File Offset: 0x00008B9C
	public string #=zutWyipbKPQEafObbDw0Ln2j4Kbf_(int #=zffwYkHH06XVNJGHz$w==)
	{
		return this.#=zDmmhhFCoUdd$5gm9YosZR5k=(1, #=zffwYkHH06XVNJGHz$w==);
	}

	// Token: 0x0600011D RID: 285 RVA: 0x0000A9A8 File Offset: 0x00008BA8
	public string #=zkL0DRKZzpfXQzDW0CFREuEP$MASM(int #=zZwdr0o2T$Cdz)
	{
		return this.#=zDmmhhFCoUdd$5gm9YosZR5k=(7, #=zZwdr0o2T$Cdz);
	}

	// Token: 0x0600011E RID: 286 RVA: 0x0000A9B4 File Offset: 0x00008BB4
	public string #=z9o2Xc2CHIVqQ539$4ruwoXK54hif(int #=zgFRCQLw=)
	{
		return this.#=zDmmhhFCoUdd$5gm9YosZR5k=(8, #=zgFRCQLw=);
	}

	// Token: 0x0600011F RID: 287 RVA: 0x0000A9C0 File Offset: 0x00008BC0
	private string #=zDmmhhFCoUdd$5gm9YosZR5k=(int #=zymvppcg=, int #=zAk8mKBk=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				#=zAk8mKBk=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zymvppcg=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947158), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000120 RID: 288 RVA: 0x0000AA30 File Offset: 0x00008C30
	public string #=zHqy4LJE9kQMrV6mkZEE9d$ImV5TRj7cdDQ==(List<int> #=zNfFFi3wz9S8y)
	{
		object[] array = new object[#=zNfFFi3wz9S8y.Count];
		for (int i = 0; i < #=zNfFFi3wz9S8y.Count; i++)
		{
			array[i] = #=zNfFFi3wz9S8y[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947120), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000121 RID: 289 RVA: 0x0000AAB0 File Offset: 0x00008CB0
	public string #=zoO8X4UjQ2pwEKUcTrw==(UnitType #=z9C46aFM=, int #=zNvCMwussKumm)
	{
		Worlds world = #=z9C46aFM=.World;
		#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=;
		if (world != Worlds.Elisium)
		{
			if (world != Worlds.Veor)
			{
				#=zZnwdOIE= = (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0;
			}
			else if (!this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsVeorHireTroopsAsUsual || !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=zQ4wZnctPyyRO()))
			{
				#=zZnwdOIE= = (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)8;
			}
			else
			{
				#=zZnwdOIE= = (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0;
			}
		}
		else
		{
			#=zZnwdOIE= = (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)1;
		}
		return this.#=zoO8X4UjQ2pwEKUcTrw==(#=z9C46aFM=, #=zNvCMwussKumm, #=zZnwdOIE=, 0L);
	}

	// Token: 0x06000122 RID: 290 RVA: 0x0000AB08 File Offset: 0x00008D08
	public string #=zoO8X4UjQ2pwEKUcTrw==(UnitType #=z9C46aFM=, int #=zNvCMwussKumm, #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zZnwdOIE=, long #=zJ18gw4E=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, #=zJ18gw4E=);
		int num = (int)((#=z9C46aFM=.World == Worlds.Veor && this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsVeorHireTroopsAsUsual && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=zQ4wZnctPyyRO())) ? Worlds.Default : #=z9C46aFM=.World);
		Dictionary<string, object> dictionary2 = dictionary;
		string key = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684);
		Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), false);
		dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), false);
		string key2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684);
		Dictionary<string, object> dictionary4 = new Dictionary<string, object>();
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750), null);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				0
			}
		});
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), null);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518), new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
				num
			}
		});
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), -1);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), #=z9C46aFM=.Id);
		dictionary4.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187), null);
		string key3 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981);
		Dictionary<string, object> value;
		if (#=zZnwdOIE= == (#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0)
		{
			(value = new Dictionary<string, object>()).Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), #=zNvCMwussKumm);
		}
		else
		{
			Dictionary<string, object> dictionary5 = new Dictionary<string, object>();
			dictionary5.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399), (int)#=zZnwdOIE=);
			value = dictionary5;
			dictionary5.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), #=zNvCMwussKumm);
		}
		dictionary4.Add(key3, value);
		dictionary3.Add(key2, dictionary4);
		dictionary2[key] = dictionary3;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000123 RID: 291 RVA: 0x0000AD74 File Offset: 0x00008F74
	public string #=zWq3hIVYHfyXQRKWBjA==(int #=zKsBeX6RmAuZq, int #=zNvCMwussKumm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								0
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						-1
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								0
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zKsBeX6RmAuZq
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								#=zNvCMwussKumm
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000124 RID: 292 RVA: 0x0000AF68 File Offset: 0x00009168
	public string #=zNwKl4C0t1_Uqpx$Qfw==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947082), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000125 RID: 293 RVA: 0x0000AF88 File Offset: 0x00009188
	public string #=zk14vkNE3V4h7qbnyDQ==(UnitType #=z9C46aFM=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=z9C46aFM=.Id
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946794), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000AFE8 File Offset: 0x000091E8
	public string #=zlu7Wj0q8OoY7$hX_HQLiajH2kKe8(UnitType #=z9C46aFM=, int #=zDRjp8jA9_8Ki, int #=zPox8jFFIFeXU, int #=zOFOu07B$hnix, int #=zAUnNXt1EfIJw)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=z9C46aFM=.Id
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zDRjp8jA9_8Ki
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				#=zPox8jFFIFeXU
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zOFOu07B$hnix
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zAUnNXt1EfIJw
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946773), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000B0B8 File Offset: 0x000092B8
	public string #=zjIOixtU6nn$Kt5RoUw==(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=zMSTgMo4=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z3v_Pt336Xf0A.Id + 100
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zMSTgMo4=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946734), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000B144 File Offset: 0x00009344
	public string #=z1COIqFtmolRsi49XRA==(int #=zZwdr0o2T$Cdz, int #=zrjon8Kw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zZwdr0o2T$Cdz
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zrjon8Kw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946734), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000129 RID: 297 RVA: 0x0000B1C8 File Offset: 0x000093C8
	public string #=z20Op8NOLzKmH5WBHiP4ZLPs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, bool #=z2oXmOW4ggLUbJDvHZA==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z2oXmOW4ggLUbJDvHZA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						new Dictionary<string, object>()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						-1
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=z3v_Pt336Xf0A.Id
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								0
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								0
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000B394 File Offset: 0x00009594
	public string #=zqf$ER4kgqRjhLlVT9Q==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=z3v_Pt336Xf0A, bool #=z2oXmOW4ggLUbJDvHZA==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z2oXmOW4ggLUbJDvHZA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
						new Dictionary<string, object>()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						-1
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=z3v_Pt336Xf0A.#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
								#=z3v_Pt336Xf0A.#=zvnZc$RhG_1Du()
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								false
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								0
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947177), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012B RID: 299 RVA: 0x0000B568 File Offset: 0x00009768
	public string #=zEoRJ9iFCtj0AXzcGqw==(int #=zZe01zHKivUKm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zZe01zHKivUKm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946704), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012C RID: 300 RVA: 0x0000B5D8 File Offset: 0x000097D8
	public string #=z5zbVlDidbmAsW3XxUg==(int #=zZe01zHKivUKm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zZe01zHKivUKm;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946689), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012D RID: 301 RVA: 0x0000B61C File Offset: 0x0000981C
	public string #=zyICOXIdaKrjpxaeVOw==(int #=zroKrBeYDJV4ofIRPkQ==, int #=z6Q8LaXo=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zroKrBeYDJV4ofIRPkQ==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=z6Q8LaXo=
			}
		};
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] = new object[]
		{
			3
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946913), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000B6AC File Offset: 0x000098AC
	public string #=zyICOXIdaKrjpxaeVOw==(Dictionary<string, object> #=zmy8rz1oPoEe8)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		foreach (string key in #=zmy8rz1oPoEe8.Keys)
		{
			dictionary[key] = #=zmy8rz1oPoEe8[key];
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946913), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000B728 File Offset: 0x00009928
	public string #=zV6M29KZ6UHBruxlfRg==(int #=zZe01zHKivUKm, List<int> #=zIW7brOF2S2t3ioMOYQ==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = dictionary2;
		dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)] = #=zZe01zHKivUKm;
		if (#=zIW7brOF2S2t3ioMOYQ== != null && #=zIW7brOF2S2t3ioMOYQ==.Count > 0)
		{
			object[] array = new object[#=zIW7brOF2S2t3ioMOYQ==.Count];
			for (int i = 0; i < #=zIW7brOF2S2t3ioMOYQ==.Count; i++)
			{
				array[i] = #=zIW7brOF2S2t3ioMOYQ==[i];
			}
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = array;
		}
		else
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907)] = null;
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946888), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000130 RID: 304 RVA: 0x0000B7E0 File Offset: 0x000099E0
	public string #=zPGdAfjp1ACpVyjjsrA==(List<int> #=zBUqU62ZuG26r)
	{
		object[] array = new object[#=zBUqU62ZuG26r.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zBUqU62ZuG26r[i]
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
					null
				}
			};
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946873), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000131 RID: 305 RVA: 0x0000B884 File Offset: 0x00009A84
	public string #=zmBQ$tkaoMKnhtoID9pPrpvw=(int #=zb2sTXDc=, int #=zE8DYNNgLzKZ4)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=zb2sTXDc=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				#=zE8DYNNgLzKZ4
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946863), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000132 RID: 306 RVA: 0x0000B8F4 File Offset: 0x00009AF4
	public string #=zJ1FwoaaqOFkpVB2rfr0dJxT1h7gUiw4BmoUT1zQ=(int #=z5R$fD$afxfDSRv3zrw==, int #=zem3LngI=, int #=zrJPCplU=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zem3LngI=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=z5R$fD$afxfDSRv3zrw==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zrJPCplU=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946555), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000133 RID: 307 RVA: 0x0000B978 File Offset: 0x00009B78
	public string #=z8LWNGrA1C1FBGjTFm81QLCsdQOhAL_0iDyrEmse0LL7A(int #=z5R$fD$afxfDSRv3zrw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z5R$fD$afxfDSRv3zrw==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946512), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000134 RID: 308 RVA: 0x0000B9E8 File Offset: 0x00009BE8
	public string #=ze1SOcCGAlsijvaxxkw==(Dictionary<string, object> #=zrA0ofbIqFhAA)
	{
		Dictionary<string, object> value = (Dictionary<string, object>)#=zrA0ofbIqFhAA[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)];
		Dictionary<string, object> value2 = (Dictionary<string, object>)#=zrA0ofbIqFhAA[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)];
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						#=zrA0ofbIqFhAA[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						value2
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zrA0ofbIqFhAA[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zrA0ofbIqFhAA[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
						value
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946467), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000135 RID: 309 RVA: 0x0000BAF0 File Offset: 0x00009CF0
	public string #=ze1SOcCGAlsijvaxxkw==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zrA0ofbIqFhAA)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						#=zrA0ofbIqFhAA.#=zVVorJLug3m2L()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
								#=zrA0ofbIqFhAA.#=zTyB2FIk29LkISjxh3Q==()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								null
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						#=zrA0ofbIqFhAA.#=zMuFMjGQ=()
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						JSONManager.EncodeTime(#=zrA0ofbIqFhAA.#=z8zMIXPnMfdS3(), false)
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
								#=zrA0ofbIqFhAA.#=zcJnW9C5gbycS()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								#=zrA0ofbIqFhAA.#=zokCzXrV0ersD0W_QcNKZ29M=()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
								#=zrA0ofbIqFhAA.#=zbDGFGfruzAcP()
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
								null
							}
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946467), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000136 RID: 310 RVA: 0x0000BC74 File Offset: 0x00009E74
	public string #=z15ymRssaWFeH(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=zFr$kLmfy4Pwedaa8jg==, int #=zwDZRfep46qev)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
								#=zFr$kLmfy4Pwedaa8jg==
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								#=z3v_Pt336Xf0A.#=ziV0Qa4zwZEC4()
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				-1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
								#=zwDZRfep46qev
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								#=z3v_Pt336Xf0A.#=ziV0Qa4zwZEC4()
							}
						}
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946435), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000137 RID: 311 RVA: 0x0000BE34 File Offset: 0x0000A034
	public string #=z9G8TWGA3__vMTTEtScyGHxo=(int #=zW51GUCKxoEZiSmQgnw==, int #=zQ1CibsU1OwZU)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
						#=zW51GUCKxoEZiSmQgnw==
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				-1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
						#=zQ1CibsU1OwZU
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						null
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946435), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000138 RID: 312 RVA: 0x0000BFB4 File Offset: 0x0000A1B4
	public string #=zJsknLhumcn07(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zrA0ofbIqFhAA, #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=z1z8Una0=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								(#=z1z8Una0=.#=zq2bPTdY=() == ResourceTypes.Grain) ? #=z1z8Una0=.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								(#=z1z8Una0=.#=zq2bPTdY=() == ResourceTypes.Bronze) ? #=z1z8Una0=.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
								(#=z1z8Una0=.#=zq2bPTdY=() == ResourceTypes.Lumber) ? #=z1z8Una0=.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
								0
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				-1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						null
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
						new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
								(#=zrA0ofbIqFhAA.#=zq2bPTdY=() == ResourceTypes.Grain) ? #=zrA0ofbIqFhAA.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
								(#=zrA0ofbIqFhAA.#=zq2bPTdY=() == ResourceTypes.Bronze) ? #=zrA0ofbIqFhAA.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
								(#=zrA0ofbIqFhAA.#=zq2bPTdY=() == ResourceTypes.Lumber) ? #=zrA0ofbIqFhAA.#=zlIXJ9$NfUZc_() : 0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
								0
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
								0
							}
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946435), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000139 RID: 313 RVA: 0x0000C2D8 File Offset: 0x0000A4D8
	public string #=ztNr$6f$4jFpqECtQlA==(int #=zTgxc8FPtK7T2)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zTgxc8FPtK7T2;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946668), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600013A RID: 314 RVA: 0x0000C31C File Offset: 0x0000A51C
	public string #=zLbAeSYCTLemU(string #=zOyAA_$w=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zOyAA_$w=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946636), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600013B RID: 315 RVA: 0x0000C35C File Offset: 0x0000A55C
	public string #=zUrWP6WtFzA3_fYlCeQ==(#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z6AmP3gh_MGVh)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z6AmP3gh_MGVh.#=zMuFMjGQ=()
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946608), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600013C RID: 316 RVA: 0x0000C3BC File Offset: 0x0000A5BC
	public string #=zPKNDQsiNl280jCmI9A==()
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				1
			}
		};
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946599)] = 1;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946588), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600013D RID: 317 RVA: 0x0000C42C File Offset: 0x0000A62C
	public string #=zFo2XPpZtgBNRmKX_gg==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948344), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x0600013E RID: 318 RVA: 0x0000C44C File Offset: 0x0000A64C
	public string #=zrS14yt$Txd4pewSVwcZQ1JaFO7U$nnDS4g==(int #=zzIIs5J4Cw6Awl3gzQw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zzIIs5J4Cw6Awl3gzQw==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948315), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600013F RID: 319 RVA: 0x0000C4A4 File Offset: 0x0000A6A4
	public string #=zLWZRJ6GAUW7RYgV1qGPDspvOoW_8(int[] #=zk8EFBPGQlOiyeoffDQ==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zk8EFBPGQlOiyeoffDQ==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948295), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000140 RID: 320 RVA: 0x0000C4F8 File Offset: 0x0000A6F8
	public string #=zew8mYj9PXteE(int #=zF1NBmwI=, int #=zngOxJ5v7eAP2XtgNEQ==, bool #=zS2SWSrCJ2IW8)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062075),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062064),
				0
			}
		};
		if (!#=zS2SWSrCJ2IW8)
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = 50;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)] = 50;
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] = 50;
		}
		else
		{
			dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045)] = 500;
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				null
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				dictionary2
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
				#=zF1NBmwI=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				#=zngOxJ5v7eAP2XtgNEQ==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948258), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000141 RID: 321 RVA: 0x0000C6FC File Offset: 0x0000A8FC
	public string #=zY59gu_lFZnDu9HO$jJ9ew2SJpU6t(object[] #=zVmHaWqy$65pX)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zVmHaWqy$65pX
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
				true
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948241), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000142 RID: 322 RVA: 0x0000C768 File Offset: 0x0000A968
	public string #=z48QmpulFh35B(int #=zYv8W575ANOZV, int #=zqVe7fs07MCxu)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zYv8W575ANOZV
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
						#=zqVe7fs07MCxu
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zqVe7fs07MCxu
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						#=zqVe7fs07MCxu
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948472), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000143 RID: 323 RVA: 0x0000C888 File Offset: 0x0000AA88
	public string #=zcI6mp1i6rJdF(int #=zYv8W575ANOZV, int #=znvBd5uua9aYB)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zYv8W575ANOZV
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
						#=znvBd5uua9aYB
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						0
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948472), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000144 RID: 324 RVA: 0x0000C9A8 File Offset: 0x0000ABA8
	public string #=z5Lzucng7Dc2NMPpAc8e4$U4=(UnitSquadCollection #=zZ0NLbUc=)
	{
		string text = this.#=z5Lzucng7Dc2NMPpAc8e4$U4=(#=zZ0NLbUc=, 1);
		if (text.Length < 1000 && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948454)))
		{
			try
			{
				int #=zndAN8uUXb5qH = Convert.ToInt32(JSONManager.FindString(JSONManager.FindString(text, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948408), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945802)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948395), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002)));
				text = this.#=z5Lzucng7Dc2NMPpAc8e4$U4=(#=zZ0NLbUc=, #=zndAN8uUXb5qH);
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=zN_s5Z5A=);
			}
		}
		return text;
	}

	// Token: 0x06000145 RID: 325 RVA: 0x0000CA4C File Offset: 0x0000AC4C
	public string #=z5Lzucng7Dc2NMPpAc8e4$U4=(UnitSquadCollection #=zZ0NLbUc=, int #=zndAN8uUXb5qH)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zZ0NLbUc=.ToDictionary()
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
						#=zndAN8uUXb5qH
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						0
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
						0
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948388), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000146 RID: 326 RVA: 0x0000CC04 File Offset: 0x0000AE04
	public string #=zHvbL9Hjs84B2naQl3g$aUP4=(UnitSquadCollection #=zZ0NLbUc=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zZ0NLbUc=.ToDictionary()
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				1
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948388), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000147 RID: 327 RVA: 0x0000CCCC File Offset: 0x0000AECC
	public string #=zufJ8wE3mcy$qi6zRYxtTYTKDWg8PrwHSOg==(UnitSquadCollection #=zZ0NLbUc=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						#=zZ0NLbUc=.ToDictionary()
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				2
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948388), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000148 RID: 328 RVA: 0x0000CD68 File Offset: 0x0000AF68
	public string #=z9rhZL8t_81pulIM3nQm23Zk=()
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				true
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948354), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000149 RID: 329 RVA: 0x0000CDC0 File Offset: 0x0000AFC0
	public string #=zirw3IP8CnV_2uWHlKxidmHA=()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948084), JSONManager.SerializeData(data));
	}

	// Token: 0x0600014A RID: 330 RVA: 0x0000CDF0 File Offset: 0x0000AFF0
	public string #=zkyXJDGdwr3KP7QLLxCFfGxU=(int #=zAk8mKBk=, int #=z5w6HcG4=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z5w6HcG4=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zAk8mKBk=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948054), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600014B RID: 331 RVA: 0x0000CE60 File Offset: 0x0000B060
	public string #=zR5GQ63w5iPhVqI0akQ==(int #=zTgxc8FPtK7T2)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zTgxc8FPtK7T2
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948024), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600014C RID: 332 RVA: 0x0000CEB8 File Offset: 0x0000B0B8
	public string #=zVfLKoA6fqQLEhdmJIXuWxRk=(int #=zTgxc8FPtK7T2, int #=zORvXtHs=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zTgxc8FPtK7T2
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				#=zORvXtHs=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947999), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600014D RID: 333 RVA: 0x0000CF28 File Offset: 0x0000B128
	public string #=z5g42B6QiMvfs(string #=zKJA8IWQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zKJA8IWQ=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948203), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600014E RID: 334 RVA: 0x0000CF68 File Offset: 0x0000B168
	public string #=zOM7cVZUPI8JhJvA$Ag==(int #=zKsBeX6RmAuZq, int #=zNvCMwussKumm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zKsBeX6RmAuZq
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=zNvCMwussKumm
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946734), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600014F RID: 335 RVA: 0x0000CFEC File Offset: 0x0000B1EC
	public string #=zOG8qr40$$plMtBgMrA==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948187), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000150 RID: 336 RVA: 0x0000D00C File Offset: 0x0000B20C
	public string #=zTf4iXOM9uYoCQZbsEw==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948167), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000151 RID: 337 RVA: 0x0000D02C File Offset: 0x0000B22C
	public string #=z8DuONse9WzaXcgQy4g==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948137), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000152 RID: 338 RVA: 0x0000D04C File Offset: 0x0000B24C
	public string #=zzPpW3KlyDM2m32M5rSYBhI_UOzn0(int #=zAk8mKBk=, int #=z5w6HcG4=, int #=zvRLj9WQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z5w6HcG4=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zvRLj9WQ=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zAk8mKBk=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948105), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000153 RID: 339 RVA: 0x0000D0D0 File Offset: 0x0000B2D0
	public string #=zmWZB1t3AwP$x4klaVkNyWs0=(int #=zAk8mKBk=, int #=z5w6HcG4=, int #=zvRLj9WQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=z5w6HcG4=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zvRLj9WQ=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zAk8mKBk=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947816), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000154 RID: 340 RVA: 0x0000D154 File Offset: 0x0000B354
	public string #=zhwgh54lqF5JKyx_npzDhhsk=(int #=zORvXtHs=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zORvXtHs=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947779), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000155 RID: 341 RVA: 0x0000D198 File Offset: 0x0000B398
	public string #=zyAtnVC2oxHMxT3LlQpajx5k=()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947736), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000156 RID: 342 RVA: 0x0000D1B8 File Offset: 0x0000B3B8
	public string #=zWQq1w59y6TrDBgKtgduXvwI=(int #=zAk8mKBk=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zAk8mKBk=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947957), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000157 RID: 343 RVA: 0x0000D210 File Offset: 0x0000B410
	public string #=zgWMOJlZrOA0vlQ$PLg==(int #=z_SvM9QNznv_3)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z_SvM9QNznv_3
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947923), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000158 RID: 344 RVA: 0x0000D268 File Offset: 0x0000B468
	public string #=zZ0VX_xVvl2XnTNDMuv9ENIiLf14YkrfrVA==()
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zqNyrB2FzTjiIQP_Ize9NK318odoy()
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947887), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000159 RID: 345 RVA: 0x0000D2C4 File Offset: 0x0000B4C4
	public string #=zJgCJ_EK6JfhYhkCNaprcWQJSFUx1_0VsF18MX0M=(int #=zJTk4iEA=, int #=zeFkjISA=, List<int> #=zXSH7YhbDcytV)
	{
		object[] array = new object[#=zXSH7YhbDcytV.Count];
		for (int i = 0; i < #=zXSH7YhbDcytV.Count; i++)
		{
			array[i] = #=zXSH7YhbDcytV[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				new object[]
				{
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
							#=zJTk4iEA=
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399),
							#=zeFkjISA=
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							array
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947841), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600015A RID: 346 RVA: 0x0000D390 File Offset: 0x0000B590
	public string #=zjTAJ4bi8c3jyZmIvtFQtdh9b9yzy(List<int> #=zISOKFGs=)
	{
		object[] array = new object[#=zISOKFGs=.Count];
		for (int i = 0; i < #=zISOKFGs=.Count; i++)
		{
			array[i] = #=zISOKFGs=[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zISOKFGs=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947547), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600015B RID: 347 RVA: 0x0000D410 File Offset: 0x0000B610
	public string #=z9gt_vrw7_liVtNKTVBCx$4WdTPXcPhBQGw==(List<int> #=zISOKFGs=, int #=zjJ5c3IujbThZ)
	{
		object[] array = new object[#=zISOKFGs=.Count];
		for (int i = 0; i < #=zISOKFGs=.Count; i++)
		{
			array[i] = #=zISOKFGs=[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				new object[]
				{
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							array
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=zjJ5c3IujbThZ
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947525), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600015C RID: 348 RVA: 0x0000D4C8 File Offset: 0x0000B6C8
	public string #=zQ013NVEMj501das89A==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947482), JSONManager.SerializeData(data));
	}

	// Token: 0x0600015D RID: 349 RVA: 0x0000D4F8 File Offset: 0x0000B6F8
	public string #=zArLzi_RjnbNk(int #=zuYY$1pg=, int #=zmaN9m784tLUC)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zuYY$1pg=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zmaN9m784tLUC
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947467), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600015E RID: 350 RVA: 0x0000D568 File Offset: 0x0000B768
	public string #=zVA3X4OVyWzvJ(int #=zmaN9m784tLUC)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zmaN9m784tLUC
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947705), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600015F RID: 351 RVA: 0x0000D5C0 File Offset: 0x0000B7C0
	public string #=zEHDGCfYrIW0Z(int #=zmaN9m784tLUC, int #=zOXetsjIWOzneYfELcg==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zmaN9m784tLUC
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zOXetsjIWOzneYfELcg==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947688), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000160 RID: 352 RVA: 0x0000D630 File Offset: 0x0000B830
	public string #=zABmNT2M02ssR(int #=zEyHWmEfrDphH, int #=zCIqWfoZMjdhk)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				new object[]
				{
					#=zEyHWmEfrDphH,
					#=zCIqWfoZMjdhk
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947672), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000161 RID: 353 RVA: 0x0000D69C File Offset: 0x0000B89C
	public string #=zKVSeAtR4_MC4QsM3mg==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947657), JSONManager.SerializeData(data));
	}

	// Token: 0x06000162 RID: 354 RVA: 0x0000D6CC File Offset: 0x0000B8CC
	public string #=z4qXabI0pe3LvAtCBGZ$bSBCQBI0$_7CbUQ==(int #=zRBfn0jU_PsJwh9BBFq5PcVU=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zRBfn0jU_PsJwh9BBFq5PcVU=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947634), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000163 RID: 355 RVA: 0x0000D710 File Offset: 0x0000B910
	public string #=zalB6bH$XAqaFZVzivG8KkfQt0H0k()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947607), JSONManager.SerializeData(data));
	}

	// Token: 0x06000164 RID: 356 RVA: 0x0000D740 File Offset: 0x0000B940
	public string #=zgBGzAD4pD1A6r8zlGQ==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949355), JSONManager.SerializeData(data));
	}

	// Token: 0x06000165 RID: 357 RVA: 0x0000D770 File Offset: 0x0000B970
	public string #=z_7p5vRiirljDfHALeiFkc8A2Dv92(int #=zXvC4Mk_r8oLY)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zXvC4Mk_r8oLY
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949323), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000166 RID: 358 RVA: 0x0000D7C8 File Offset: 0x0000B9C8
	public string #=zf_kcxgfuggif6HMgUQ==(List<int> #=zsO$OS4RSzyTD)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		object[] array = new object[#=zsO$OS4RSzyTD.Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = #=zsO$OS4RSzyTD[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949295), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000167 RID: 359 RVA: 0x0000D844 File Offset: 0x0000BA44
	public string #=zBFMwXTCbiAkiK1ozVZeA4AVU6biK()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949269), JSONManager.SerializeData(data));
	}

	// Token: 0x06000168 RID: 360 RVA: 0x0000D874 File Offset: 0x0000BA74
	public string #=zL9J09_U8DSoYFcWIzg==(string #=z45VNGlE=, int[] #=znfju_5Z$Ly2x)
	{
		object[] array = new object[#=znfju_5Z$Ly2x.Length];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = #=znfju_5Z$Ly2x[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759),
				array
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				#=z45VNGlE=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949493), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000169 RID: 361 RVA: 0x0000D910 File Offset: 0x0000BB10
	public string #=ztKdpaiTyOBlo_LSGnw==(int #=zU$NNAgI=, int #=zMR11HNA=)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new object[]
				{
					#=zU$NNAgI=
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zMR11HNA=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949468), JSONManager.SerializeData(data));
	}

	// Token: 0x0600016A RID: 362 RVA: 0x0000D970 File Offset: 0x0000BB70
	public string #=zJjJ1QddGSeIZiJHntWTxI6U=(int #=zU$NNAgI=, int #=zMR11HNA=, DateTime #=zboqre6$2y0cWQNGBng==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zMR11HNA=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				JSONManager.EncodeTimeInt(#=zboqre6$2y0cWQNGBng==, false)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zU$NNAgI=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949445), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600016B RID: 363 RVA: 0x0000DA28 File Offset: 0x0000BC28
	public string #=zVGRfhAGBsIPXPgnBAA==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949402), JSONManager.SerializeData(data));
	}

	// Token: 0x0600016C RID: 364 RVA: 0x0000DA58 File Offset: 0x0000BC58
	public string #=zNZBrA6sD0AEwfLHhNQ==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949388), JSONManager.SerializeData(data));
	}

	// Token: 0x0600016D RID: 365 RVA: 0x0000DA88 File Offset: 0x0000BC88
	public string #=zFxTk7J4J8rCbppGdRg==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949105), JSONManager.SerializeData(data));
	}

	// Token: 0x0600016E RID: 366 RVA: 0x0000DAB8 File Offset: 0x0000BCB8
	public string #=zob$EjVWom9M5tkUnVB1yEVI=(bool #=zd52UiSMKHwB41Yz$1g==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		if (#=zd52UiSMKHwB41Yz$1g==)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
					true
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					0
				}
			};
		}
		else
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					0
				}
			};
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949093), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600016F RID: 367 RVA: 0x0000DB58 File Offset: 0x0000BD58
	public string #=z8rJ9A6vyYfDOlq5fzLmt43MQYLJARtatAQ==(int #=ziw_YNuP0S1c2rlCgRg==, int #=zDoucPIAsoVrQ)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				new object[]
				{
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							#=zDoucPIAsoVrQ
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
							#=ziw_YNuP0S1c2rlCgRg==
						}
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949065), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000170 RID: 368 RVA: 0x0000DBE8 File Offset: 0x0000BDE8
	public string #=zMlPtwEXwBKqO4dCd7e1o3U8=(int #=zZb1kbGFaNrK7sclnqw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zZb1kbGFaNrK7sclnqw==;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949038), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000171 RID: 369 RVA: 0x0000DC2C File Offset: 0x0000BE2C
	public string #=zE0lnPt6FIBXHBw7iSDUBjzhGGk6v()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949011), JSONManager.SerializeData(data));
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000DC5C File Offset: 0x0000BE5C
	public string #=zrubomKMHLTWSVi5XnHCD8Lc=(int #=zTH01DjU=, int #=z4c0OorrvoR6tbAr3_w==, int #=zUKPtCdiiWlHVIqUjfw==)
	{
		long #=zGcMUnK0tFuhw;
		if (this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsGeneralUpgradeSuperSpeed && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=zQ4wZnctPyyRO()))
		{
			#=zGcMUnK0tFuhw = JSONManager.EncodeTimeInt(DateTime.Now, false) - 15000L;
		}
		else
		{
			#=zGcMUnK0tFuhw = 0L;
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, #=zGcMUnK0tFuhw);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				#=z4c0OorrvoR6tbAr3_w==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zUKPtCdiiWlHVIqUjfw==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949235), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000173 RID: 371 RVA: 0x0000DD18 File Offset: 0x0000BF18
	public string #=zvAuYc1qDKy78zWIQjw==(int #=zTH01DjU=, object[] #=zYMO8gWjmf6HKBSt4wA==, object[] #=zhrE5Jf$LuHjFqS4xEmdTcn69FaW4)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949214),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949207),
				#=zYMO8gWjmf6HKBSt4wA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949196),
				#=zhrE5Jf$LuHjFqS4xEmdTcn69FaW4
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949189), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000174 RID: 372 RVA: 0x0000DD94 File Offset: 0x0000BF94
	public string #=zF7PK0Lub1Dzd(int #=zTH01DjU=, object[] #=zYMO8gWjmf6HKBSt4wA==, object[] #=zhrE5Jf$LuHjFqS4xEmdTcn69FaW4)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949214),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949207),
				#=zYMO8gWjmf6HKBSt4wA==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949196),
				#=zhrE5Jf$LuHjFqS4xEmdTcn69FaW4
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949155), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000175 RID: 373 RVA: 0x0000DE10 File Offset: 0x0000C010
	public string #=z8svVNUU2uXef(int #=zTH01DjU=, int #=zpYmsudrDmAF9WIA$Cw==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
				#=zpYmsudrDmAF9WIA$Cw==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949142), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000176 RID: 374 RVA: 0x0000DE80 File Offset: 0x0000C080
	public string #=zE5VuNRZp3jma7rvkFkPylqamaD1D(int #=zTH01DjU=, int #=zm02Iv8cOna42, int #=zVP$k$BoiWDNh)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zVP$k$BoiWDNh
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zm02Iv8cOna42
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948858), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000177 RID: 375 RVA: 0x0000DF04 File Offset: 0x0000C104
	public string #=zkgEmpmeJHa1b2dv2Uw==()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948832), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000178 RID: 376 RVA: 0x0000DF24 File Offset: 0x0000C124
	public string #=z4GJvhwZUxjZK0q17hPwA0iP5zgBd()
	{
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948823), JSONManager.SerializeData(this.#=zNazfdtw=(false, 0L)));
	}

	// Token: 0x06000179 RID: 377 RVA: 0x0000DF44 File Offset: 0x0000C144
	public string #=zz76ciiSOrlyTX_GJslAUF2WRi$Rh(int #=zTH01DjU=, int #=z4c0OorrvoR6tbAr3_w==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				#=zTH01DjU=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
				#=z4c0OorrvoR6tbAr3_w==
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948794), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600017A RID: 378 RVA: 0x0000DFB4 File Offset: 0x0000C1B4
	public string #=zFzgnyFG5jZhbZNE1nHNAXh0=(int #=zk_4E_3muViYC, int #=zPCiKde6piIcy)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		if (#=zPCiKde6piIcy > 0)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
					#=zk_4E_3muViYC
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zPCiKde6piIcy
				}
			};
		}
		else
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
					#=zk_4E_3muViYC
				}
			};
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948773), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600017B RID: 379 RVA: 0x0000E054 File Offset: 0x0000C254
	public string #=zDXci15F7pdyeXydMqENhPDY=(int #=zR2LDrFH66VVP)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zR2LDrFH66VVP;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948977), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600017C RID: 380 RVA: 0x0000E098 File Offset: 0x0000C298
	public string #=zH4JeD1tMoszPBpV$jAOs758=(int #=zTCUmmTn2H_xvnScc3Q==, int #=zMj7zeMJkZxEgRnYnsQ==)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				#=zTCUmmTn2H_xvnScc3Q==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==()
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948935), JSONManager.SerializeData(data), #=zMj7zeMJkZxEgRnYnsQ==, false, false);
	}

	// Token: 0x0600017D RID: 381 RVA: 0x0000E124 File Offset: 0x0000C324
	public string #=zs2E35D6TWS3QWmfmVA==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=znxJtsu3HJWMj)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		if (#=znxJtsu3HJWMj != null)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
					#=znxJtsu3HJWMj.#=zMuFMjGQ=()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zU4TPzxM=.#=zMuFMjGQ=()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
					#=zU4TPzxM=.#=z$NyihN71ouQU()
				}
			};
		}
		else
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zU4TPzxM=.#=zMuFMjGQ=()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
					#=zU4TPzxM=.#=z$NyihN71ouQU()
				}
			};
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948888), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600017E RID: 382 RVA: 0x0000E208 File Offset: 0x0000C408
	public string #=zFdQTSOSm7vkNJwHo$g==(int #=zVeVmuVM=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zVeVmuVM=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948866), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600017F RID: 383 RVA: 0x0000E24C File Offset: 0x0000C44C
	public string #=zWiOs0kkTWW95mMbc8JNhN1o2lvNPcO5jjA==(int #=zZe01zHKivUKm, List<int> #=z1GUSQNlTLrYB)
	{
		object[] array = new object[#=z1GUSQNlTLrYB.Count];
		for (int i = 0; i < #=z1GUSQNlTLrYB.Count; i++)
		{
			array[i] = #=z1GUSQNlTLrYB[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zZe01zHKivUKm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948597), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000180 RID: 384 RVA: 0x0000E2F8 File Offset: 0x0000C4F8
	public string #=zcwlPp9PZeHF6Y7rAf9X9a538lI31awXBcA==(int #=zZe01zHKivUKm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zZe01zHKivUKm;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948565), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000181 RID: 385 RVA: 0x0000E33C File Offset: 0x0000C53C
	public string #=zEcPV97n7bWfJ8XLR7uS8FwMBcFho(List<int> #=z1GUSQNlTLrYB)
	{
		object[] array = new object[#=z1GUSQNlTLrYB.Count];
		for (int i = 0; i < #=z1GUSQNlTLrYB.Count; i++)
		{
			array[i] = #=z1GUSQNlTLrYB[i];
		}
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883),
				true
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				array
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948533), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000182 RID: 386 RVA: 0x0000E3D4 File Offset: 0x0000C5D4
	public string #=zAzdmylt$nfrth5Cvd6K20aIutKfZjV9JnbkeiV0=(int #=zNvCMwussKumm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zNvCMwussKumm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
				10 * #=zNvCMwussKumm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				false
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				29000
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948502), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000183 RID: 387 RVA: 0x0000E478 File Offset: 0x0000C678
	public string #=zvXKYDXUsyUlB8R7AwvmeEUE2bd3D(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				null
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948719), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000184 RID: 388 RVA: 0x0000E4E4 File Offset: 0x0000C6E4
	public string #=zf1Ph8ErZxXPwLzTYiu0wtRQ=(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948693), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000185 RID: 389 RVA: 0x0000E53C File Offset: 0x0000C73C
	public string #=zt5Y3ZLShoZgj7hxathmKRvEfUC7i(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948656), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0000E594 File Offset: 0x0000C794
	public string #=zwVGSk0x9RWfpaK5p7n7$X4c=(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948638), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000187 RID: 391 RVA: 0x0000E5EC File Offset: 0x0000C7EC
	public string #=zQCyQnxaR4rpCWqnksHJELNl5x9F5(int #=zgFRCQLw=, int #=zcxQmAKs=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zcxQmAKs=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908948612), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000188 RID: 392 RVA: 0x0000E65C File Offset: 0x0000C85C
	public string #=zoM5fsPTicZqKM1FOfYPYRug8ZNKf(int #=zgFRCQLw=, int #=zcxQmAKs=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zgFRCQLw=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=zcxQmAKs=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950361), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0000E6CC File Offset: 0x0000C8CC
	public string #=zAGw__qiYN$H8QTo_aAKo9xk=(int #=zRcaTMxk=, int #=ztoKJ9EQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zRcaTMxk=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				#=ztoKJ9EQ=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950333), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600018A RID: 394 RVA: 0x0000E73C File Offset: 0x0000C93C
	public string #=zJ4zfSLLM3eKI_fyYRcmtYsl1yUYZ()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950298), JSONManager.SerializeData(data));
	}

	// Token: 0x0600018B RID: 395 RVA: 0x0000E76C File Offset: 0x0000C96C
	public string #=znCgHepLSCEKUYbcI2g==(int #=zgFRCQLw=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zgFRCQLw=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950277), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600018C RID: 396 RVA: 0x0000E7B0 File Offset: 0x0000C9B0
	public string #=z11$G8mg_WFbDvfiFECVnGIQ=(int #=zbg6hik8uxFYa)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zbg6hik8uxFYa
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950497), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600018D RID: 397 RVA: 0x0000E808 File Offset: 0x0000CA08
	public string #=zEi$_BOHBK5pT(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==, int #=zIgt60A6qs8ln)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		object[] array = new object[#=zatMRdFUxBCRS1oul8g==.Count];
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
						#=zIgt60A6qs8ln
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
						#=zIgt60A6qs8ln
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
						array
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
				new object[0]
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060495),
				false
			}
		};
		for (int i = 0; i < #=zatMRdFUxBCRS1oul8g==.Count; i++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zatMRdFUxBCRS1oul8g==[i];
			Dictionary<string, object> dictionary2 = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750),
					new Dictionary<string, object>()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908947187),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zMuFMjGQ=()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							null
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
							false
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
							null
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du()
						}
					}
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518),
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zAdM$oWHPKFC_gx1bYQ==()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zfTB62qendhk_VEy8rw==()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zY0soxphmGIACbOHy6A==()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zlSY2GGkBa6S3MkHuDQ==()
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z_ffm9$kcf9Y8EY_3cw==()
						}
					}
				}
			};
			array[i] = dictionary2;
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950469), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600018E RID: 398 RVA: 0x0000EA88 File Offset: 0x0000CC88
	public string #=z1YjXUn05Ndtn(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zKqd2w$3lpzQlDswauA==, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z4xl2DHYn_KeXWgxDyQ==)
	{
		StringBuilder stringBuilder = new StringBuilder();
		foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in #=z4xl2DHYn_KeXWgxDyQ==)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 = null;
			foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn3 in #=zKqd2w$3lpzQlDswauA==)
			{
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4())
				{
					#=zO6457TajDDxDJIsKqS1bbzDMLckn2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn3;
					#=zKqd2w$3lpzQlDswauA==.Remove(#=zO6457TajDDxDJIsKqS1bbzDMLckn3);
					break;
				}
			}
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2 == null)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn;
			}
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(',');
			}
			stringBuilder.Append(string.Concat(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950453),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zMuFMjGQ=().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950420),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950142),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950080),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zfTB62qendhk_VEy8rw==().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950061),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zlSY2GGkBa6S3MkHuDQ==().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950041),
				#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zY0soxphmGIACbOHy6A==().ToString(),
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945437)
			}));
		}
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950469), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950037) + stringBuilder.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950211));
	}

	// Token: 0x0600018F RID: 399 RVA: 0x0000EC6C File Offset: 0x0000CE6C
	public string #=zcMzsxux2PNxUE9oteQcj1JR6QFos(int #=zuip2jhc6oeXCWxswzQ==)
	{
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zuip2jhc6oeXCWxswzQ==
			}
		});
		int num = 0;
		return this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949886), #=zWC15sHaiwX4N, ref num, false, 0);
	}

	// Token: 0x06000190 RID: 400 RVA: 0x0000ECB4 File Offset: 0x0000CEB4
	public string #=z0sb_hDoHi3y3UT4$gvmU2Vyh96kwPFmAew==(int #=zuip2jhc6oeXCWxswzQ==)
	{
		string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zuip2jhc6oeXCWxswzQ==
			}
		});
		int num = 0;
		return this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949860), #=zWC15sHaiwX4N, ref num, false, 0);
	}

	// Token: 0x06000191 RID: 401 RVA: 0x0000ECFC File Offset: 0x0000CEFC
	public string #=zAOb$cs_A61B707qbrY1kYGvsDAwUtSn96A==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949827), JSONManager.SerializeData(data));
	}

	// Token: 0x06000192 RID: 402 RVA: 0x0000ED2C File Offset: 0x0000CF2C
	public string #=zUqlWG8t4c68SrGqGGw==(int #=zuip2jhc6oeXCWxswzQ==)
	{
		string #=zWC15sHaiwX4N = #=zuip2jhc6oeXCWxswzQ==.ToString();
		int num = 0;
		return this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949792), #=zWC15sHaiwX4N, ref num, false, 0);
	}

	// Token: 0x06000193 RID: 403 RVA: 0x0000ED58 File Offset: 0x0000CF58
	public string #=z8fSxejFvXLJ80rgf3$8DkdQ=(int #=zuip2jhc6oeXCWxswzQ==, int #=zNvCMwussKumm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				#=zuip2jhc6oeXCWxswzQ==
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zNvCMwussKumm
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949780), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000194 RID: 404 RVA: 0x0000EDC8 File Offset: 0x0000CFC8
	public string #=zvm6NPNxHyfQ2tOa18pVUVuqwNwUy(long #=zxU8KUjoxD5MA, int #=zSPvulj53LD$T, int #=zUzu7nv2oECpw)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
						true
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
						#=zSPvulj53LD$T
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875),
						#=zxU8KUjoxD5MA
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
						#=zUzu7nv2oECpw
					}
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950000), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000195 RID: 405 RVA: 0x0000EE78 File Offset: 0x0000D078
	public string #=zAA0VkBXDdKegEnGR4K3arhKmn1Ho(int #=zvPiOyGQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zvPiOyGQ=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949960), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000196 RID: 406 RVA: 0x0000EEBC File Offset: 0x0000D0BC
	public string #=zRM9HIk7pc5abAsmYSCgFenpedBmq(int #=zvPiOyGQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zvPiOyGQ=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949950), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000197 RID: 407 RVA: 0x0000EF00 File Offset: 0x0000D100
	public string #=zLc07sTIa9KaKh4gk_pmHRZw1_oOs(int #=zvPiOyGQ=)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zvPiOyGQ=;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949932), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x06000198 RID: 408 RVA: 0x0000EF44 File Offset: 0x0000D144
	public string #=zBFslCXZIXSbSx_Ghqw==(#=zghPTD5$lUO9N9xUnV1U2l11qlHVvpuLW87xsWjg= #=zWwApao_qIo3DfsAEKw==, int #=zKsBeX6RmAuZq, int #=zNbEXm6$XZzYf)
	{
		Dictionary<string, object> data = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						new Dictionary<string, object>
						{
							{
								#=zKsBeX6RmAuZq.ToString(),
								#=zNbEXm6$XZzYf
							}
						}
					}
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				#=zWwApao_qIo3DfsAEKw==.#=zMuFMjGQ=()
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949906), JSONManager.SerializeData(data), #=zWwApao_qIo3DfsAEKw==.#=z3FoeVNn2CiyhA1ZyUw==(), false, false);
	}

	// Token: 0x06000199 RID: 409 RVA: 0x0000EFD0 File Offset: 0x0000D1D0
	public string #=z7_iTRVW2Kudd3w0oka6ezlS8jCNw()
	{
		int #=z$Ib9gYQ= = (this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B() != null) ? this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zxWJWBWxyVjKWhkQ0ywNvzKs=() : 0;
		string text = this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949889), string.Empty, ref #=z$Ib9gYQ=, true, 0);
		if (!string.IsNullOrEmpty(text) && this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B() != null)
		{
			this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zZSkNRUgj8yXAH6_cQElO$6Y=(#=z$Ib9gYQ=);
		}
		return text;
	}

	// Token: 0x0600019A RID: 410 RVA: 0x0000F040 File Offset: 0x0000D240
	public string #=zZkc$1nfnnSfgazpoY8HuNpaS2Hl19mNKrQ==()
	{
		int #=z$Ib9gYQ= = (this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B() != null) ? this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zxWJWBWxyVjKWhkQ0ywNvzKs=() : 0;
		string text = this.#=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949602), string.Empty, ref #=z$Ib9gYQ=, true, 0);
		if (!string.IsNullOrEmpty(text) && this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B() != null)
		{
			this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zZSkNRUgj8yXAH6_cQElO$6Y=(#=z$Ib9gYQ=);
		}
		return text;
	}

	// Token: 0x0600019B RID: 411 RVA: 0x0000F0B0 File Offset: 0x0000D2B0
	public string #=zSSYmqrBg2RGnnvCg9Q==(int #=zjQz2Zyw=, int #=zTgxc8FPtK7T2)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684),
				new object[]
				{
					#=zTgxc8FPtK7T2
				}
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				#=zjQz2Zyw=
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949574), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600019C RID: 412 RVA: 0x0000F12C File Offset: 0x0000D32C
	public string #=zFxqhqkKXyNkUkgA5YTRdXHXQ749CYmWj4KhlfF0=(int #=zjaB3oNg=, int #=zDoucPIAsoVrQ)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zjaB3oNg=
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=zDoucPIAsoVrQ
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949543), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600019D RID: 413 RVA: 0x0000F1B0 File Offset: 0x0000D3B0
	public string #=zI6O4fQIGazCsBd4Xo7TskzfXF8gSZzTGRA==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949509), JSONManager.SerializeData(data));
	}

	// Token: 0x0600019E RID: 414 RVA: 0x0000F1E0 File Offset: 0x0000D3E0
	public string #=zbk_MxlunfqRdmn4jAmcb4Sdu_jv7bAVo$w==(int #=zKsBeX6RmAuZq)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				new object[]
				{
					#=zKsBeX6RmAuZq
				}
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949719), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x0600019F RID: 415 RVA: 0x0000F244 File Offset: 0x0000D444
	public string #=zI4t7DnP8v0BkMohlFQ==(int #=zjJ5c3IujbThZ)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zjJ5c3IujbThZ;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949681), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x0000F288 File Offset: 0x0000D488
	public string #=zaYnKuPIPg5ylCSGiiAStYNQ=(int #=zfWacXIOEukFR)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zfWacXIOEukFR;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908949660), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x0000F2CC File Offset: 0x0000D4CC
	public string #=znnVDFcgfmLU4n1Atpg==()
	{
		Dictionary<string, object> data = this.#=zNazfdtw=(false, 0L);
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951422), JSONManager.SerializeData(data));
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x0000F2FC File Offset: 0x0000D4FC
	public string #=zM5DUhGnEb$kAQsXWzoO8fzSXuPUWYzguZ7LFOag=(int #=zTAUVJpdftyKlj1zRMg==)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = #=zTAUVJpdftyKlj1zRMg==;
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951397), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x0000F340 File Offset: 0x0000D540
	public string #=zptAZzuHtK5QZ$of_Phiy_6wMqxKK(int #=z1aJ2rmG4VuJn, int #=zNvCMwussKumm)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
				#=zNvCMwussKumm
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				#=z1aJ2rmG4VuJn
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951345), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x0000F3B0 File Offset: 0x0000D5B0
	public string #=zl7tg4r$_74DekNHgbBuX4zU=(int #=zZwdr0o2T$Cdz)
	{
		Dictionary<string, object> dictionary = this.#=zNazfdtw=(false, 0L);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)] = new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				#=zZwdr0o2T$Cdz
			}
		};
		return this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951320), JSONManager.SerializeData(dictionary));
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x0000F408 File Offset: 0x0000D608
	public Dictionary<string, object> #=zuq1FOz8SJbyH()
	{
		return this.#=zuq1FOz8SJbyH(false);
	}

	// Token: 0x060001A6 RID: 422 RVA: 0x0000F414 File Offset: 0x0000D614
	private Dictionary<string, object> #=zuq1FOz8SJbyH(bool #=zygBOoqY=)
	{
		Dictionary<string, object> result;
		try
		{
			if (!#=zygBOoqY=)
			{
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951301), Array.Empty<object>());
			}
			else
			{
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951523), Array.Empty<object>());
			}
			this.#=zQ4wZnctPyyRO().#=zXBCeOAAyIMED(true);
			object[] array = new object[this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z0I9lfENpa60boKog9g==().Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z0I9lfENpa60boKog9g==()[i];
			}
			Dictionary<string, object> dictionary = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067396),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
					this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zSByqmFV12x0z()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951488)
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951484),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951477),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069987),
					false
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951458),
					false
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951451),
					0
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951440),
					new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
							false
						}
					}
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
					0
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951433),
					false
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951430),
					null
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					GameApplicationData.#=z0Jq5DpdI2gB$() + this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==()
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
					true
				}
			};
			GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
			Dictionary<string, object> value;
			if (gameHosters <= GameApplicationData.GameHosters.VKontakte)
			{
				switch (gameHosters)
				{
				case GameApplicationData.GameHosters.MyMail:
				{
					int num = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe().IndexOf('@');
					if (num <= 0)
					{
						throw new Exception(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951164), new object[]
						{
							this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()
						}).ToString());
					}
					string arg = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe().Substring(0, num);
					string arg2 = JSONManager.FindString(this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075522), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067993));
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951119), arg2, arg).ToLower();
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951085), arg2, arg, this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zUBdNbQEy4rFD()).ToLower();
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951280), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zjWBl268nvo9O()).ToLower();
					value = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
							1
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951252)
						}
					};
					goto IL_8BC;
				}
				case GameApplicationData.GameHosters.GamesMail:
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = null;
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zUBdNbQEy4rFD().ToLower();
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951234);
					value = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
							1
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951252)
						}
					};
					goto IL_8BC;
				case (GameApplicationData.GameHosters)3:
					break;
				case GameApplicationData.GameHosters.Odnoklassniki:
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951221), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==());
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zUBdNbQEy4rFD().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053451), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077055)));
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951234);
					dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094335)] = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907),
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596)
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
							true
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
							false
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951189)
						}
					};
					value = new Dictionary<string, object>
					{
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
							1
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951252)
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951170),
							null
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
							1920
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
							1080
						},
						{
							#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950907),
							null
						}
					};
					goto IL_8BC;
				default:
					if (gameHosters == GameApplicationData.GameHosters.VKontakte)
					{
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = null;
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zUBdNbQEy4rFD().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053451), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077055)));
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950897), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zjWBl268nvo9O());
						dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950877);
						value = new Dictionary<string, object>
						{
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
								1
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951252)
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951170),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
								1920
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
								1080
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950907),
								null
							},
							{
								#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950859),
								null
							}
						};
						goto IL_8BC;
					}
					break;
				}
			}
			else if (gameHosters == GameApplicationData.GameHosters.PlariumRu || gameHosters == GameApplicationData.GameHosters.PlariumEn)
			{
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)] = null;
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)] = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zUBdNbQEy4rFD();
				dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)] = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950848), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(), this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zjWBl268nvo9O()).ToLower();
				value = new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950829),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950811)
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827),
						1920
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669),
						1080
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950907),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909096133)
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
						5
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950801),
						false
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951252)
					},
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951170),
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950799)
					}
				};
				goto IL_8BC;
			}
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951024), Array.Empty<object>());
			IL_8BC:
			string #=zWC15sHaiwX4N = JSONManager.SerializeData(new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951015)
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086),
					array
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
					dictionary
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581),
					value
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908945989),
					string.Empty
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
					-180
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
					this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zG96rwfOikL5q()
				}
			});
			string text = this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950994), #=zWC15sHaiwX4N, -1, false, true);
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950991), Array.Empty<object>());
			if (text.Length < 1000)
			{
				string text2 = text.ToLower();
				string arg3 = GameApplicationData.#=za4LDzr6$43pL(this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C(), this.#=zQ4wZnctPyyRO().#=zKHqHudNIb2os()).Segments[1].Trim(new char[]
				{
					'/'
				}).ToLower();
				if (text2.Contains(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950953), arg3)))
				{
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950940), Array.Empty<object>());
					if (!#=zygBOoqY=)
					{
						this.#=zQ4wZnctPyyRO().#=zW2Vlp5vytS40(Convert.ToInt32(JSONManager.FindString(text2, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950953), arg3), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909027418))));
						return this.#=zuq1FOz8SJbyH(true);
					}
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950918), new object[]
					{
						text
					});
				}
			}
			Dictionary<string, object> dictionary2 = (Dictionary<string, object>)JSONManager.GetData(text);
			this.#=zQ4wZnctPyyRO().#=zgi8txbeKnNhG(JSONManager.GetString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), null));
			int @int = JSONManager.GetInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950619), 0);
			string @string = JSONManager.GetString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950609), null);
			Dictionary<string, object> dictionary3 = (Dictionary<string, object>)JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950605));
			if (dictionary3 == null)
			{
				dictionary3 = new Dictionary<string, object>();
				dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), -1);
				dictionary3.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), -1);
			}
			this.#=zQ4wZnctPyyRO().#=zUg$cyyC$uyqZ(new #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==(@int, @string, JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0), JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0)));
			this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zFzGvi_S6jJhE(Convert.ToInt32(JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950591))));
			object[] array2 = (object[])JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
			if (array2 != null)
			{
				foreach (Dictionary<string, object> dictionary4 in array2)
				{
					if (dictionary4.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)))
					{
						this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zAsCgbAN02olKpq2GjA==(Convert.ToInt32(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)]));
					}
					if (dictionary4.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)))
					{
						this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zBtU0oqFKR8zKww67yQxSBhTpjdEV(Convert.ToInt32(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
					}
				}
			}
			if (this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==() <= 0)
			{
				this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zAsCgbAN02olKpq2GjA==(JSONManager.GetInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950569), 0));
			}
			int #=z$Ib9gYQ=;
			if (int.TryParse(JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950552)).ToString(), out #=z$Ib9gYQ=))
			{
				this.#=zQ4wZnctPyyRO().#=zPGfL4rgl8WkG(#=z$Ib9gYQ=);
			}
			this.#=zQ4wZnctPyyRO().#=zWqunoVP8Im4d(Convert.ToInt32(JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950539))));
			this.#=zQ4wZnctPyyRO().#=zw85sRUw9UHM7(Convert.ToInt64(JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958))));
			this.#=zQ4wZnctPyyRO().#=zBvCSQJJWCsSAL_vReA==(this.#=zQ4wZnctPyyRO().#=zd7Gjkk3oclDR());
			this.#=zQ4wZnctPyyRO().#=zYNBRw$1JagVG(Convert.ToInt32(JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950535))));
			this.#=zQ4wZnctPyyRO().#=z9EbNx80uMOzwrg3lZ6219kM=(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950774), 0));
			this.#=zQ4wZnctPyyRO().#=zWwACCeJ9QQhNyL6$Hg==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zsO0UOz85fFukCr4OAg==(this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), JSONManager.GetObject(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)), this.#=zQmveeqwfZtWH));
			this.#=zQ4wZnctPyyRO().#=zL15kcYKKrFqK(new #=zy9zQtVcRsBCeOmSjzVQDdfAWHUpOtVU5GQ==(dictionary2));
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950764), Array.Empty<object>());
			this.#=zdJL1sbOUBC7O(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950731), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950727) + GameApplicationData.#=z0Jq5DpdI2gB$() + this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950705), 0, false, true);
			this.#=zQ4wZnctPyyRO().#=zr$jBMnVxcqHqLBq76A==(DateTime.Now);
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950703), Array.Empty<object>());
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
			if (!#=zxMOyT4mqlNEbNbr2evcJByuLqWmY66ZEzw==.#=zR75Bpho=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zZ7bll7yjWibZ()))
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zMBoy07_HlGOR(#=zxMOyT4mqlNEbNbr2evcJByuLqWmY66ZEzw==.#=zi1hFJwI=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zZ7bll7yjWibZ(), dictionary2));
			}
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=z4r1Y$wYr4xSL(this.#=zQ4wZnctPyyRO());
			this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zVn0b0PBG7G9QZAhLIwbeLLYXSFEb(0);
			this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zsFXnaqjXugcU(this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z$V9uwJPAniCv());
			this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zpo4eyll_HX97(this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zw3M1PzX18p_r());
			result = dictionary2;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=), Array.Empty<object>());
			throw;
		}
		finally
		{
			this.#=zQ4wZnctPyyRO().#=zXBCeOAAyIMED(false);
		}
		return result;
	}

	// Token: 0x060001A7 RID: 423 RVA: 0x0001032C File Offset: 0x0000E52C
	public string #=zNDs2uEY=(string #=z1vcRUAMD40W2)
	{
		return #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zNDs2uEY=(#=z1vcRUAMD40W2, this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C(), this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U());
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x0001034C File Offset: 0x0000E54C
	public static string #=zNDs2uEY=(string #=z1vcRUAMD40W2, int #=zLeeSKrg=, ProxyInfo #=zsHG$Y6w=)
	{
		int #=zNV$UbAD4cIgs = GameApplicationData.#=z6KvP4MGoQFDo();
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(GameApplicationData.#=za4LDzr6$43pL(#=zLeeSKrg=, 0).ToString());
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWP6h8M9Cec$M(httpWebRequest, #=zsHG$Y6w=);
		httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
		httpWebRequest.Method = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108880);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950679)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936059);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108328)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936042);
		httpWebRequest.UserAgent = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936008);
		httpWebRequest.ContentType = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936145);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936129)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936104);
		httpWebRequest.Accept = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936072);
		httpWebRequest.Referer = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936070);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108291)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935715);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108253)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935703);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935898)] = #=zNV$UbAD4cIgs.ToString();
		string #=zWC15sHaiwX4N = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935883), #=z1vcRUAMD40W2);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935877)] = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zwd5JFOw6sl8u(httpWebRequest, #=zWC15sHaiwX4N);
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zTvO8aG2BI37U(httpWebRequest, #=zWC15sHaiwX4N);
		return #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zdJL1sbOUBC7O(httpWebRequest, #=zNV$UbAD4cIgs, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936059), null, #=zsHG$Y6w=);
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x000104D8 File Offset: 0x0000E6D8
	public DateTime #=zi6E$PtAmGSYg(string #=z1vcRUAMD40W2, out int #=zvkUJZwE=, out string #=zcdC9Wnk=)
	{
		DateTime result;
		try
		{
			string text = this.#=zNDs2uEY=(#=z1vcRUAMD40W2);
			int num = text.IndexOf('!');
			if (num > 0)
			{
				DateTime dateTime = JSONManager.DecodeTime(text.Substring(0, num), false);
				#=zvkUJZwE= = 0;
				#=zcdC9Wnk= = null;
				result = dateTime;
			}
			else
			{
				object dataCalm = JSONManager.GetDataCalm(text);
				if (JSONManager.GetInt(dataCalm, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0) == -3)
				{
					#=zcdC9Wnk= = JSONManager.GetString(JSONManager.GetDataCalm(JSONManager.GetString(dataCalm, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), null)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), null);
					if (!string.IsNullOrEmpty(#=zcdC9Wnk=))
					{
						#=zvkUJZwE= = 2;
						#=zcdC9Wnk= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935861), new object[]
						{
							#=z1vcRUAMD40W2,
							#=zcdC9Wnk=
						}).ToString();
						return DateTime.MinValue;
					}
				}
				if (text.Length > 1000)
				{
					text = text.Substring(0, 1000);
				}
				#=zvkUJZwE= = 1;
				#=zcdC9Wnk= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935544), new object[]
				{
					#=z1vcRUAMD40W2,
					text
				}).ToString();
				result = DateTime.MaxValue;
			}
		}
		catch (Exception ex)
		{
			if (ex is #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K && (ex as #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K).#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)10)
			{
				#=zvkUJZwE= = 2;
				#=zcdC9Wnk= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935474), new object[]
				{
					#=z1vcRUAMD40W2,
					ex.Message
				}).ToString();
				result = DateTime.MinValue;
			}
			else
			{
				#=zvkUJZwE= = 1;
				#=zcdC9Wnk= = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935433), new object[]
				{
					#=z1vcRUAMD40W2,
					ex.Message
				}).ToString();
				result = DateTime.MaxValue;
			}
		}
		return result;
	}

	// Token: 0x060001AA RID: 426 RVA: 0x00010674 File Offset: 0x0000E874
	private string #=zDsS3ZV3CP4kM$DG3HMr$pdDtAs_E(string #=zNXGeRys=, string #=zWC15sHaiwX4N, ref int #=zCHPchKE=, bool #=zWJp7dyF48jevG83pA01rWMc=, int #=zt6uECLopKXZR)
	{
		int num = GameApplicationData.#=zdmZ8JO4ttdMN(this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C());
		int num2 = 5;
		string text = string.Empty;
		int i = 0;
		while (i < num + num2)
		{
			bool flag = true;
			try
			{
				text = this.#=zdJL1sbOUBC7O(#=zNXGeRys=, #=zWC15sHaiwX4N, #=zCHPchKE=, true, false);
			}
			catch
			{
				flag = false;
			}
			if (flag && #=zWJp7dyF48jevG83pA01rWMc= && text.Length < 1000 && (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935628)) || (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935614)) && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935593)))))
			{
				flag = false;
			}
			if (flag && text.Length < 1000 && (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935579)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935283))))
			{
				flag = false;
			}
			if (flag && #=zt6uECLopKXZR > 0 && text.Length < #=zt6uECLopKXZR)
			{
				flag = false;
			}
			if (!flag)
			{
				if (i < num - 1)
				{
					#=zCHPchKE=++;
					if (#=zCHPchKE= >= num)
					{
						#=zCHPchKE= = 0;
					}
				}
				else
				{
					#=zCHPchKE= = i + 1;
				}
				i++;
			}
			else
			{
				if (#=zCHPchKE= + 1 > num)
				{
					GameApplicationData.#=zYx6HaROVSgQR(this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C(), #=zCHPchKE= + 1);
					break;
				}
				break;
			}
		}
		return text;
	}

	// Token: 0x060001AB RID: 427 RVA: 0x000107AC File Offset: 0x0000E9AC
	private string #=zdJL1sbOUBC7O(string #=zNXGeRys=, string #=zWC15sHaiwX4N)
	{
		return this.#=zdJL1sbOUBC7O(#=zNXGeRys=, #=zWC15sHaiwX4N, -1, false, false);
	}

	// Token: 0x060001AC RID: 428 RVA: 0x000107BC File Offset: 0x0000E9BC
	private string #=zdJL1sbOUBC7O(string #=zNXGeRys=, string #=zWC15sHaiwX4N, int #=z0t13Ul6cwOQV, bool #=zba2UXxbDPGC$, bool #=zNPujBfk2r$2u)
	{
		#=zWC15sHaiwX4N = #=zWC15sHaiwX4N.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935259), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077055));
		if (this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().State != ProxyStates.Ok && this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().State != ProxyStates.Disabled)
		{
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935252), new object[]
			{
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().ProxyKey,
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().StateRu
			});
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935252), new object[]
			{
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().ProxyKey,
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().StateRu
			});
		}
		if (this.#=zQ4wZnctPyyRO().#=ziYbj9IsgzGRe7374EQ==() > DateTime.Now)
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)12, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935211), Array.Empty<object>());
		}
		if (!this.#=zkRQ4B7_fFmH0IMmfEQ==())
		{
			if (this.#=zQmveeqwfZtWH.#=zZhtNEVG9mdJh() != null)
			{
				int num = 0;
				if (!#=zNPujBfk2r$2u)
				{
					while (this.#=zQmveeqwfZtWH.#=z9$ebnKOpXUdG())
					{
						Thread.Sleep(1000);
						num++;
						if (num > 600)
						{
							throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)11, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935168), Array.Empty<object>());
						}
						if (GameApplicationData.#=zv3f1uqjnJC$0())
						{
							break;
						}
					}
				}
				if (!this.#=zQmveeqwfZtWH.#=zmV5ijznC$olBuQ$vDQ==())
				{
					DateTime dateTime = this.#=zQmveeqwfZtWH.#=zZhtNEVG9mdJh().#=zd_9JG1jlYf$ucbtc$g==() + TimeSpan.FromSeconds(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC() + (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zxZUNpQr446iF4sFzC4IllHyNkuAk() - #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zxMqWLjBM_xQfC2XbxMxlIDdPVncC()) * new Random().NextDouble());
					DateTime dateTime2 = this.#=z9TrQaE7EBV1U().#=z3YtB02S6CjKY().#=zfDLoU$fv2a3A(this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C(), #=zNXGeRys=);
					if (dateTime < dateTime2)
					{
						dateTime = dateTime2;
					}
					while (DateTime.Now < dateTime)
					{
						Thread.Sleep(100);
						if (GameApplicationData.#=zv3f1uqjnJC$0())
						{
							break;
						}
					}
				}
				this.#=zQmveeqwfZtWH.#=zZhtNEVG9mdJh().#=zyafBTh$NKNpViEtypQ==(DateTime.Now);
			}
		}
		else
		{
			this.#=zF5F9PRZBGZrBbiy9ng==(false);
		}
		while (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z14zJFR90Z1eo() > DateTime.Now)
		{
			Thread.Sleep(100);
			if (GameApplicationData.#=zv3f1uqjnJC$0())
			{
				break;
			}
		}
		if (GameApplicationData.#=zv3f1uqjnJC$0())
		{
			throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)8, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935379), Array.Empty<object>());
		}
		string result;
		try
		{
			int #=zNV$UbAD4cIgs = GameApplicationData.#=z6KvP4MGoQFDo();
			string text = null;
			int num2 = 1;
			int num3 = 2;
			while (text == null)
			{
				try
				{
					HttpWebRequest #=zjZWhv$4= = this.#=zLjQNkpk=(#=zNXGeRys=, #=zWC15sHaiwX4N, #=z0t13Ul6cwOQV, #=zNV$UbAD4cIgs);
					this.#=zfhU9lZN1BewC(new #=zAjO7I84RW8RKI9PeCopgq9B$x73y(#=zjZWhv$4=, #=zWC15sHaiwX4N));
					text = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zdJL1sbOUBC7O(#=zjZWhv$4=, #=zNV$UbAD4cIgs, #=zNXGeRys=, this.#=zQ4wZnctPyyRO(), this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U());
				}
				catch (WebException ex)
				{
					WebExceptionStatus status = ex.Status;
					if (status - 2 > 3 && status != 8 && status != 14)
					{
						throw;
					}
					if (num2 >= num3)
					{
						throw;
					}
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935348), new object[]
					{
						ex.Message,
						ex.Status
					});
					num2++;
				}
			}
			this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().SetSuccessful();
			this.#=zqK4R43PWR_mY(#=zNXGeRys=, text);
			result = text;
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6)
			{
				if (this.#=zQmveeqwfZtWH != null)
				{
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937079), new object[]
					{
						this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().ProxyKey,
						this.#=zQ4wZnctPyyRO().#=zdEt_WRHpdEMmGTK_3Q==(),
						#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
					});
					this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().#=zFpoTiuNQADk3AApu7g==(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
				}
			}
			else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)12 && this.#=zQ4wZnctPyyRO().#=ziYbj9IsgzGRe7374EQ==() <= DateTime.Now)
			{
				this.#=zQ4wZnctPyyRO().#=z6dCrRf67ci4JJjZe0A==(DateTime.Now + TimeSpan.FromMinutes(15.0));
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937005), new object[]
				{
					this.#=zQ4wZnctPyyRO().#=ziYbj9IsgzGRe7374EQ==()
				});
			}
			throw;
		}
		catch (UriFormatException)
		{
			if (this.#=zQmveeqwfZtWH != null)
			{
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().State = ProxyStates.Unworking;
			}
			throw;
		}
		catch (WebException ex2)
		{
			if (#=zba2UXxbDPGC$)
			{
				throw;
			}
			if (ex2.Message.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937214)) && this.#=zQ4wZnctPyyRO().#=ziYbj9IsgzGRe7374EQ==() <= DateTime.Now)
			{
				if (#=zNXGeRys= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950994))
				{
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937194), Array.Empty<object>());
					this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z_CMx39SmGb4B(false);
				}
				else
				{
					int num4 = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zpxNt6CS3$Hsx();
					if (num4 != 1)
					{
						if (num4 == 2)
						{
							this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937194), Array.Empty<object>());
							this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z_CMx39SmGb4B(false);
						}
					}
					else
					{
						this.#=zQ4wZnctPyyRO().#=z6dCrRf67ci4JJjZe0A==(DateTime.Now + TimeSpan.FromMinutes(15.0));
						this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, ex2);
						this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937005), new object[]
						{
							this.#=zQ4wZnctPyyRO().#=ziYbj9IsgzGRe7374EQ==()
						});
					}
				}
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)12, ex2.Message, Array.Empty<object>());
			}
			if (this.#=zQmveeqwfZtWH != null && this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U() != null)
			{
				this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().SetFailed();
				if (this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
				{
					string #=zx9NCziM= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937136);
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=zx9NCziM=, new object[]
					{
						this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().ProxyKey,
						ex2.Message
					});
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Exception, #=zx9NCziM=, new object[]
					{
						this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U().ProxyKey,
						ex2.Message
					});
				}
			}
			throw;
		}
		return result;
	}

	// Token: 0x060001AD RID: 429 RVA: 0x00010EAC File Offset: 0x0000F0AC
	private static string #=zdJL1sbOUBC7O(HttpWebRequest #=zjZWhv$4=, int #=zNV$UbAD4cIgs, string #=zNXGeRys=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, ProxyInfo #=zsHG$Y6w=)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(#=zjZWhv$4=, false);
		if (!string.IsNullOrEmpty(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof()))
		{
			throw new Exception(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof());
		}
		string text = #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2();
		#=zLdas1G0kAAODvaqZgJo9xEujgDGZ #=zLdas1G0kAAODvaqZgJo9xEujgDGZ = #=zsHG$Y6w=.#=z3YtB02S6CjKY().#=z48rEd0A=(#=z8StzeqE=, #=zNXGeRys=, text);
		if (#=zLdas1G0kAAODvaqZgJo9xEujgDGZ != null)
		{
			throw #=zLdas1G0kAAODvaqZgJo9xEujgDGZ;
		}
		if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936813)))
		{
			text = text.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936813), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936782));
		}
		if (text.Length < 10000)
		{
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936764)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936737)))
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936714), Array.Empty<object>());
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936917)) && Regex.Matches(text, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936882)).Count == 1)
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)4, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936714), Array.Empty<object>());
			}
			if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936843)))
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936555), new object[]
				{
					Environment.NewLine,
					text
				});
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936524)))
			{
				GameApplicationData.#=z6CrVp3FDpDar(#=zNV$UbAD4cIgs);
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)1, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936489), Array.Empty<object>());
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936461)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936695)) || text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936650)))
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936628), new object[]
				{
					JSONManager.Cut(text)
				});
			}
			if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936584)))
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)10, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936312), new object[]
					{
						JSONManager.Cut(text)
					});
				}
				if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936283)))
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)12, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936264), new object[]
					{
						JSONManager.Cut(text)
					});
				}
				if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936239)))
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936211), new object[]
					{
						JSONManager.Cut(text)
					});
				}
			}
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936433)) && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936429)))
			{
				throw new WebException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936409) + JSONManager.Cut(text), 16);
			}
		}
		return text;
	}

	// Token: 0x060001AE RID: 430 RVA: 0x00011158 File Offset: 0x0000F358
	private HttpWebRequest #=zLjQNkpk=(string #=zNXGeRys=, string #=zWC15sHaiwX4N, int #=z0t13Ul6cwOQV, int #=zNV$UbAD4cIgs)
	{
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(this.#=zQ4wZnctPyyRO().#=z5qDil6s=(#=z0t13Ul6cwOQV));
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWP6h8M9Cec$M(httpWebRequest, this.#=zQmveeqwfZtWH.#=z9TrQaE7EBV1U());
		httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
		httpWebRequest.Method = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108880);
		httpWebRequest.ProtocolVersion = HttpVersion.Version10;
		httpWebRequest.UserAgent = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936367);
		httpWebRequest.Accept = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936072);
		httpWebRequest.Referer = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938036);
		httpWebRequest.ContentType = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936145);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108253)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935703);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108291)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938193);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908936129)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938180);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938148)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951488);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108328)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938122);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102317)] = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zxSNRMjqS3yCO();
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102103)] = GameApplicationData.#=z0Jq5DpdI2gB$() + this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==();
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102331)] = this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zG96rwfOikL5q();
		this.#=zYiUuRdffJT3rLMXN3Q==(httpWebRequest);
		if (#=zNXGeRys= != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950994))
		{
			if (string.IsNullOrEmpty(this.#=zQ4wZnctPyyRO().#=z87XIzK7RTgT1()))
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102337), Array.Empty<object>());
			}
			httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102114)] = this.#=zQ4wZnctPyyRO().#=z87XIzK7RTgT1();
		}
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935898)] = #=zNV$UbAD4cIgs.ToString();
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937835)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588);
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950679)] = #=zNXGeRys=;
		httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935877)] = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zwd5JFOw6sl8u(httpWebRequest, #=zWC15sHaiwX4N);
		httpWebRequest.KeepAlive = true;
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zTvO8aG2BI37U(httpWebRequest, #=zWC15sHaiwX4N);
		return httpWebRequest;
	}

	// Token: 0x060001AF RID: 431 RVA: 0x000113E4 File Offset: 0x0000F5E4
	private void #=zYiUuRdffJT3rLMXN3Q==(HttpWebRequest #=zjZWhv$4=)
	{
		if (GameApplicationData.#=z7wsmjLWw49AC() == GameApplicationData.GameHosters.GamesMail && this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zxSNRMjqS3yCO() == GameApplicationData.#=z0Jq5DpdI2gB$() + this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==())
		{
			#=zjZWhv$4=.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937817)] = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909097835);
		}
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x0001144C File Offset: 0x0000F64C
	private static string #=zwd5JFOw6sl8u(HttpWebRequest #=zjZWhv$4=, string #=zWC15sHaiwX4N)
	{
		string text = (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Nords) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937775) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937795);
		return #=zEUBS1i3F2YjLKP$jPmnwi_fM9U4u.#=zoFZMcJzdKf_O(string.Concat(new string[]
		{
			text,
			#=zWC15sHaiwX4N,
			#=zjZWhv$4=.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950679)],
			#=zjZWhv$4=.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102103)],
			#=zjZWhv$4=.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102317)]
		}), false);
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x000114DC File Offset: 0x0000F6DC
	private void #=zqK4R43PWR_mY(string #=zNXGeRys=, string #=zTjOzXkk=)
	{
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x000114E0 File Offset: 0x0000F6E0
	public string #=zePOCaV_cBDyl(string #=zNXGeRys=, string #=zWC15sHaiwX4N)
	{
		HttpWebRequest httpWebRequest = this.#=zLjQNkpk=(#=zNXGeRys=, #=zWC15sHaiwX4N, -1, GameApplicationData.#=z6KvP4MGoQFDo());
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937734), this.#=zQ4wZnctPyyRO().#=zKHqHudNIb2os()));
		foreach (string text in httpWebRequest.Headers.AllKeys)
		{
			if (text != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937929))
			{
				stringBuilder.AppendLine(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070981) + httpWebRequest.Headers[text].ToString());
			}
		}
		stringBuilder.AppendLine();
		stringBuilder.AppendLine(#=zWC15sHaiwX4N);
		stringBuilder.AppendLine(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937914));
		stringBuilder.AppendLine();
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937910) + this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString());
		return stringBuilder.ToString();
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x000115E0 File Offset: 0x0000F7E0
	public static #=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zIXHGARF4HWoZ(string #=zgFysrZ8=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, CookieContainer #=z1aqYQax9jqUB, ProxyInfo #=zsHG$Y6w=)
	{
		string text;
		string text2;
		if (#=zgFysrZ8=.Contains(Environment.NewLine + Environment.NewLine))
		{
			text = #=zgFysrZ8=.Substring(0, #=zgFysrZ8=.IndexOf(Environment.NewLine + Environment.NewLine));
			text2 = #=zgFysrZ8=.Substring(#=zgFysrZ8=.IndexOf(Environment.NewLine + Environment.NewLine), #=zgFysrZ8=.Length - text.Length).Trim();
		}
		else if (#=zgFysrZ8=.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205)))
		{
			text = #=zgFysrZ8=.Substring(0, #=zgFysrZ8=.IndexOf('{'));
			text2 = #=zgFysrZ8=.Substring(#=zgFysrZ8=.IndexOf('{'), #=zgFysrZ8=.Length - text.Length);
		}
		else
		{
			text = #=zgFysrZ8=;
			text2 = string.Empty;
		}
		string[] array = text.Split(new string[]
		{
			Environment.NewLine
		}, StringSplitOptions.RemoveEmptyEntries);
		if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937914)))
		{
			text2 = text2.Substring(0, text2.IndexOf(Environment.NewLine + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937914)));
		}
		string text3 = null;
		string text4 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108880);
		int num = -1;
		if (#=z8StzeqE= != null)
		{
			text3 = #=z8StzeqE=.#=z5qDil6s=(-1);
		}
		else
		{
			for (int i = 0; i < array.Length; i++)
			{
				string text5 = array[i];
				if (text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937882)) && text5.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937878)))
				{
					text3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937858), text5.Substring(6), JSONManager.FindString(array[0], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937878), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937590)));
					num = i;
					break;
				}
				if (text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083293)) || text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909083279)))
				{
					text3 = text5;
					num = i;
					break;
				}
				if (text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937878)) || text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937570)) || text5.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937561)))
				{
					text4 = text5.Substring(0, text5.IndexOf(' '));
					text3 = text5.Substring(text5.IndexOf(' ') + 1);
					if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944517)))
					{
						text3 = text3.Substring(0, text3.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944517))).Trim();
					}
					num = i;
					break;
				}
			}
		}
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(text3);
		httpWebRequest.Method = text4;
		httpWebRequest.ServicePoint.Expect100Continue = false;
		if (#=z1aqYQax9jqUB != null)
		{
			httpWebRequest.CookieContainer = #=z1aqYQax9jqUB;
		}
		else
		{
			httpWebRequest.CookieContainer = new CookieContainer();
		}
		bool flag = false;
		bool flag2 = false;
		for (int j = 0; j < array.Length; j++)
		{
			string text6 = array[j];
			if (text6.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074)) && j != num)
			{
				string text7 = text6.Substring(0, text6.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074))).Trim();
				string text8 = text6.Substring(text7.Length + 1).Trim();
				if (#=z8StzeqE= != null)
				{
					if (!(text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102114)))
					{
						if (!(text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102103)))
						{
							if (!(text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102331)))
							{
								if (text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102317))
								{
									text8 = #=z8StzeqE=.#=zh5Q$jgycqA15().#=zxSNRMjqS3yCO();
								}
							}
							else
							{
								text8 = #=z8StzeqE=.#=zh5Q$jgycqA15().#=zG96rwfOikL5q();
							}
						}
						else
						{
							text8 = GameApplicationData.#=z0Jq5DpdI2gB$() + #=z8StzeqE=.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==();
						}
					}
					else
					{
						text8 = #=z8StzeqE=.#=z87XIzK7RTgT1();
					}
				}
				if (text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935877))
				{
					flag = true;
				}
				if (text7 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937556))
				{
					#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWP6h8M9Cec$M(httpWebRequest, text8, ProxyFormats.IpPortLoginPassword);
					flag2 = true;
				}
				else
				{
					#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zE2fpVUDtCZmG(httpWebRequest, text7, text8);
				}
			}
		}
		if (#=z8StzeqE= != null || flag)
		{
			httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935877)] = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zwd5JFOw6sl8u(httpWebRequest, text2);
		}
		if (!flag2)
		{
			#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWP6h8M9Cec$M(httpWebRequest, #=zsHG$Y6w=);
		}
		if (text4 != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937536))
		{
			#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zTvO8aG2BI37U(httpWebRequest, text2);
		}
		return new #=zAjO7I84RW8RKI9PeCopgq9B$x73y(httpWebRequest, text2);
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x00011A20 File Offset: 0x0000FC20
	public static string #=z0vCXuEah_ZW$(string #=zgFysrZ8=)
	{
		return #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=z0vCXuEah_ZW$(#=zgFysrZ8=, null, false);
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x00011A2C File Offset: 0x0000FC2C
	public static string #=z0vCXuEah_ZW$(string #=zgFysrZ8=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, bool #=zPoayIeNty8qU)
	{
		return #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zME6c59mcU_6Y(#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(#=zgFysrZ8=, #=z8StzeqE=, null, null).#=zJgvbqC5Kxvxk(), true));
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x00011A48 File Offset: 0x0000FC48
	public static string #=zdKHhrpikgPKG(string #=zgFysrZ8=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string b = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908950679);
		string b2 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937534);
		string b3 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908935628);
		string b4 = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937556);
		int num = #=z8StzeqE=.#=zKHqHudNIb2os();
		#=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw== #=zofFle5Q= = null;
		int num2 = 0;
		string text;
		string text2;
		if (#=zgFysrZ8=.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205)))
		{
			text = #=zgFysrZ8=.Substring(0, #=zgFysrZ8=.IndexOf('{'));
			text2 = #=zgFysrZ8=.Substring(#=zgFysrZ8=.IndexOf('{'), #=zgFysrZ8=.Length - text.Length);
		}
		else if (#=zgFysrZ8=.Contains(Environment.NewLine + Environment.NewLine))
		{
			text = #=zgFysrZ8=.Substring(0, #=zgFysrZ8=.IndexOf(Environment.NewLine + Environment.NewLine));
			text2 = #=zgFysrZ8=.Substring(#=zgFysrZ8=.IndexOf(Environment.NewLine + Environment.NewLine), #=zgFysrZ8=.Length - text.Length).Trim();
		}
		else
		{
			text = #=zgFysrZ8=;
			text2 = string.Empty;
		}
		string[] array = text.Split(new string[]
		{
			Environment.NewLine
		}, StringSplitOptions.RemoveEmptyEntries);
		if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937914)))
		{
			text2 = text2.Substring(0, text2.IndexOf(Environment.NewLine + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937914)));
		}
		string #=zNXGeRys= = null;
		foreach (string text3 in array)
		{
			if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074)))
			{
				string text4 = text3.Substring(0, text3.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074))).Trim();
				string text5 = text3.Substring(text4.Length + 1).Trim();
				if (text4 == b)
				{
					#=zNXGeRys= = text5;
				}
				else if (text4 == b2)
				{
					int.TryParse(text5, out num2);
				}
				else if (text4 == b3)
				{
					num = Convert.ToInt32(text5);
				}
				else if (text4 == b4)
				{
					string[] array3 = text5.Split(new char[]
					{
						':',
						'\t'
					});
					if (array3.Length >= 2)
					{
						string ip = array3[0];
						int port;
						if (int.TryParse(array3[1], out port))
						{
							if (array3.Length == 2)
							{
								#=zofFle5Q= = new #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==(new #=zkO3OALYBGNilukMF5u7j7K3EsP5C(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)), new ProxyInfo(ProxyTypes.DynamicManual, ip, port));
							}
							else if (array3.Length >= 4)
							{
								string login = array3[2];
								string password = array3[3];
								#=zofFle5Q= = new #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==(new #=zkO3OALYBGNilukMF5u7j7K3EsP5C(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)), new ProxyInfo(ProxyTypes.DynamicManual, ip, port, login, password));
							}
						}
					}
				}
			}
		}
		string #=zWC15sHaiwX4N = text2;
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(#=zofFle5Q=, true, #=z8StzeqE=));
		if (num2 > 0)
		{
			Dictionary<string, object> dictionary;
			if (num2 == 2)
			{
				dictionary = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zr3QqntDzkElh();
			}
			else
			{
				dictionary = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zNazfdtw=(false, 0L);
			}
			if (!string.IsNullOrEmpty(text2))
			{
				Dictionary<string, object> dictionary2 = (Dictionary<string, object>)JSONManager.DeserializeData(text2);
				if (dictionary2 != null)
				{
					foreach (string key in dictionary2.Keys)
					{
						dictionary[key] = dictionary2[key];
					}
				}
			}
			#=zWC15sHaiwX4N = JSONManager.SerializeData(dictionary);
		}
		else
		{
			#=zWC15sHaiwX4N = text2;
		}
		string result = null;
		try
		{
			result = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zdJL1sbOUBC7O(#=zNXGeRys=, #=zWC15sHaiwX4N, num, false, false);
		}
		catch
		{
			num = ((num == 0) ? 1 : 0);
			result = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=zdJL1sbOUBC7O(#=zNXGeRys=, #=zWC15sHaiwX4N, num, false, false);
		}
		return result;
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x00011DC8 File Offset: 0x0000FFC8
	public string #=zSAwLs9LsNTnH()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937515), this.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().RequestUri.ToString(), DateTime.Now, Environment.NewLine);
		foreach (object obj in this.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers.Keys)
		{
			string text = (string)obj;
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946289), text, this.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers[text], Environment.NewLine);
		}
		stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937474), this.#=z2fpO5C$YR90A().#=ziywd55xwWd2r(), Environment.NewLine);
		return stringBuilder.ToString();
	}

	// Token: 0x04000059 RID: 89
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zQmveeqwfZtWH;

	// Token: 0x0400005A RID: 90
	private #=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zXVLOfqSwzcUlJH29NqIIeM8=;

	// Token: 0x0400005B RID: 91
	private bool #=zxosIuqq9MKrki8GPgrBvDKg=;

	// Token: 0x02000034 RID: 52
	private sealed class #=zz$ym0QKheUjjo08sOQ==
	{
		// Token: 0x060001B8 RID: 440 RVA: 0x00011EB8 File Offset: 0x000100B8
		private #=zz$ym0QKheUjjo08sOQ==(#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zj$N29zE=, int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zVIAkeHHVFEEIr9OdYg==, #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zyfyFTf4=)
		{
			this.#=zSJY$s3o= = #=zj$N29zE=;
			this.#=z5WXCqGI= = #=zQhs6iYQ=;
			this.#=zP3P9itgnlF6q = #=zxHIOVSaavkpE;
			this.#=zBxy4qL6GIR1_Ew2jAA== = #=zVIAkeHHVFEEIr9OdYg==;
			this.#=zaqKJHQ02ultk = new List<int>[10];
			for (int i = 0; i < 10; i++)
			{
				this.#=zaqKJHQ02ultk[i] = null;
			}
			this.#=zaRZk5Gg= = #=zyfyFTf4=;
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x00011F14 File Offset: 0x00010114
		public static void #=zCRHsHQoSr4MUrXWztNGwnihzEjWz(#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zj$N29zE=, int #=zQhs6iYQ=, UnitSquadCollection #=zxHIOVSaavkpE, UnitSquadCollection #=zVIAkeHHVFEEIr9OdYg==, #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zyfyFTf4=)
		{
			JSONManager.GetData(#=zj$N29zE=.#=zMmyIB6$viHz8());
			DateTime t = DateTime.Now + TimeSpan.FromMinutes(2.5);
			DateTime t2 = DateTime.Now + TimeSpan.FromMinutes(5.0);
			#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zz$ym0QKheUjjo08sOQ== = new #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==(#=zj$N29zE=, #=zQhs6iYQ=, #=zxHIOVSaavkpE, #=zVIAkeHHVFEEIr9OdYg==, #=zyfyFTf4=);
			for (int i = 0; i < 10; i++)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=z$2GtEJMHog4KZs9zMg==(#=zz$ym0QKheUjjo08sOQ==, i);
			}
			List<int> list;
			while (DateTime.Now < t)
			{
				bool flag = true;
				for (int j = 0; j < 10; j++)
				{
					if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[j] == null)
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					list = #=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[0];
					bool flag2 = false;
					for (int k = 1; k < 10; k++)
					{
						if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[k].Count == 0)
						{
							flag2 = true;
						}
						else if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[k].Count > list.Count)
						{
							list = #=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[k];
						}
					}
					if (#=zxHIOVSaavkpE == #=zVIAkeHHVFEEIr9OdYg==)
					{
						int num = list[0];
						for (int l = 1; l < list.Count; l++)
						{
							if (list[l] > num)
							{
								num = list[l];
							}
						}
						using (List<int>.Enumerator enumerator = list.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								int num2 = enumerator.Current;
								if (num2 != num || flag2)
								{
									#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zhRTBRHmDAQOfihER$w==(#=zz$ym0QKheUjjo08sOQ==, num2);
								}
							}
							return;
						}
					}
					if (!flag2)
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zow1rctFaF6MDmvemZw==(#=zz$ym0QKheUjjo08sOQ==.#=z5WXCqGI=, null, #=zz$ym0QKheUjjo08sOQ==.#=zP3P9itgnlF6q, 0);
					}
					foreach (int #=zF26RrcjLS0Z in list)
					{
						#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zhRTBRHmDAQOfihER$w==(#=zz$ym0QKheUjjo08sOQ==, #=zF26RrcjLS0Z);
					}
					return;
				}
				Thread.Sleep(1000);
			}
			list = #=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[0];
			for (int m = 1; m < 10; m++)
			{
				if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[m].Count > list.Count)
				{
					list = #=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[m];
				}
			}
			for (int n = 0; n < 10; n++)
			{
				#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[n] = null;
			}
			if (list.Count >= 10)
			{
				list.RemoveAt(9);
			}
			using (List<int>.Enumerator enumerator = list.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					int #=zF26RrcjLS0Z2 = enumerator.Current;
					#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zhRTBRHmDAQOfihER$w==(#=zz$ym0QKheUjjo08sOQ==, #=zF26RrcjLS0Z2);
				}
				goto IL_2BA;
			}
			IL_262:
			for (int num3 = 0; num3 < 10; num3++)
			{
				if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[num3] != null)
				{
					foreach (int #=zF26RrcjLS0Z3 in #=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[num3])
					{
						#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zhRTBRHmDAQOfihER$w==(#=zz$ym0QKheUjjo08sOQ==, #=zF26RrcjLS0Z3);
					}
				}
			}
			IL_2BA:
			if (!(DateTime.Now < t2))
			{
				return;
			}
			goto IL_262;
		}

		// Token: 0x060001BA RID: 442 RVA: 0x00012220 File Offset: 0x00010420
		private static void #=z$2GtEJMHog4KZs9zMg==(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zaB2hNp8=, int #=zWi378UT_GMuL)
		{
			new Thread(new ParameterizedThreadStart(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zYTsZD6bK_UXihApMFA==)).Start(new object[]
			{
				#=zaB2hNp8=,
				#=zWi378UT_GMuL
			});
		}

		// Token: 0x060001BB RID: 443 RVA: 0x0001224C File Offset: 0x0001044C
		private static void #=zYTsZD6bK_UXihApMFA==(object #=zCchlrwY1jp8k)
		{
			object[] array = (object[])#=zCchlrwY1jp8k;
			if (array != null && array.Length == 2)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zz$ym0QKheUjjo08sOQ== = (#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==)array[0];
				int num = Convert.ToInt32(array[1]);
				try
				{
					#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zXKGLUAZMToPRN$WrZw==(#=zz$ym0QKheUjjo08sOQ==, num);
				}
				catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
				{
					bool flag;
					#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zQ4wZnctPyyRO(), #=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), out flag);
					if (flag)
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zuq1FOz8SJbyH();
						#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zXKGLUAZMToPRN$WrZw==(#=zz$ym0QKheUjjo08sOQ==, num);
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=zbbu$0jU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zQmveeqwfZtWH, #=zN_s5Z5A=);
					if (#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[num] == null)
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zaqKJHQ02ultk[num] = new List<int>();
					}
				}
			}
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00012310 File Offset: 0x00010510
		private static void #=zXKGLUAZMToPRN$WrZw==(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zaB2hNp8=, int #=zWi378UT_GMuL)
		{
			string text = #=zaB2hNp8=.#=zSJY$s3o=.#=zow1rctFaF6MDmvemZw==(#=zaB2hNp8=.#=z5WXCqGI=, null, #=zaB2hNp8=.#=zBxy4qL6GIR1_Ew2jAA==, 0);
			if (text.Length < 1000)
			{
				#=zaB2hNp8=.#=zaRZk5Gg=.#=z9tn1xKU=(#=zaB2hNp8=.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), text, Array.Empty<object>());
			}
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
			List<int> list = new List<int>();
			StringBuilder stringBuilder = new StringBuilder();
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]) == #=zaB2hNp8=.#=z5WXCqGI=)
				{
					list.Add(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
					if (stringBuilder.Length > 0)
					{
						stringBuilder.Append(',');
					}
					stringBuilder.Append(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
				}
			}
			#=zaB2hNp8=.#=zaqKJHQ02ultk[#=zWi378UT_GMuL] = list;
			#=zaB2hNp8=.#=zaRZk5Gg=.#=z9tn1xKU=(#=zaB2hNp8=.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946190), new object[]
			{
				stringBuilder.ToString()
			});
		}

		// Token: 0x060001BD RID: 445 RVA: 0x00012440 File Offset: 0x00010640
		private static void #=zhRTBRHmDAQOfihER$w==(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zaB2hNp8=, int #=zF26RrcjLS0Z4)
		{
			new Thread(new ParameterizedThreadStart(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==.#=zGcOX67o9GuY6bunQDQ==)).Start(new object[]
			{
				#=zaB2hNp8=,
				#=zF26RrcjLS0Z4
			});
		}

		// Token: 0x060001BE RID: 446 RVA: 0x0001246C File Offset: 0x0001066C
		private static void #=zGcOX67o9GuY6bunQDQ==(object #=zCchlrwY1jp8k)
		{
			object[] array = (object[])#=zCchlrwY1jp8k;
			if (array != null && array.Length == 2)
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ== #=zz$ym0QKheUjjo08sOQ== = (#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zz$ym0QKheUjjo08sOQ==)array[0];
				int #=zNXxl4XZUXyGh = -1;
				try
				{
					#=zNXxl4XZUXyGh = Convert.ToInt32(array[1]);
					string text = #=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zMV_fZC22CEHViE8g4A==(#=zNXxl4XZUXyGh, false);
					if (text.Length < 1000)
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=z9tn1xKU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), text, Array.Empty<object>());
					}
					else
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=z9tn1xKU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946420), new object[]
						{
							#=zNXxl4XZUXyGh.ToString()
						});
					}
				}
				catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
				{
					bool flag;
					#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zQ4wZnctPyyRO(), #=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), out flag);
					if (flag)
					{
						#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zuq1FOz8SJbyH();
						string text2 = #=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zMV_fZC22CEHViE8g4A==(#=zNXxl4XZUXyGh, false);
						if (text2.Length < 1000)
						{
							#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=z9tn1xKU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), text2, Array.Empty<object>());
						}
						else
						{
							#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=z9tn1xKU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946420), new object[]
							{
								#=zNXxl4XZUXyGh.ToString()
							});
						}
					}
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zz$ym0QKheUjjo08sOQ==.#=zaRZk5Gg=.#=zbbu$0jU=(#=zz$ym0QKheUjjo08sOQ==.#=zSJY$s3o=.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
				}
			}
		}

		// Token: 0x0400005C RID: 92
		private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o=;

		// Token: 0x0400005D RID: 93
		private int #=z5WXCqGI=;

		// Token: 0x0400005E RID: 94
		private UnitSquadCollection #=zP3P9itgnlF6q;

		// Token: 0x0400005F RID: 95
		private UnitSquadCollection #=zBxy4qL6GIR1_Ew2jAA==;

		// Token: 0x04000060 RID: 96
		private List<int>[] #=zaqKJHQ02ultk;

		// Token: 0x04000061 RID: 97
		private #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=zaRZk5Gg=;
	}
}
