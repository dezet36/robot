﻿// Token: 0x0200028D RID: 653
internal sealed partial class #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== : global::System.Windows.Forms.Form
{
	// Token: 0x060013EC RID: 5100 RVA: 0x0009914C File Offset: 0x0009734C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000B70 RID: 2928
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
