﻿using System;
using System.Collections.Generic;

// Token: 0x020001E1 RID: 481
internal sealed class #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 : List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=>
{
	// Token: 0x06000E9C RID: 3740 RVA: 0x00075B38 File Offset: 0x00073D38
	public #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95()
	{
		this.#=zaYB$PK9UGSU7(0);
		this.#=zx26R3IFca56HGRaIcw==(0);
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x00075B50 File Offset: 0x00073D50
	public int #=zyowZ9U1Cgv5d()
	{
		return this.#=zAbf9COKE0GA5JZBFLxG1tmc=;
	}

	// Token: 0x06000E9E RID: 3742 RVA: 0x00075B58 File Offset: 0x00073D58
	private void #=zaYB$PK9UGSU7(int #=z$Ib9gYQ=)
	{
		this.#=zAbf9COKE0GA5JZBFLxG1tmc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E9F RID: 3743 RVA: 0x00075B64 File Offset: 0x00073D64
	public int #=z40n214Sx3_pCHbGMNg==()
	{
		return this.#=zuL23bAV1bimF3EZSH7ymqNvz2lme;
	}

	// Token: 0x06000EA0 RID: 3744 RVA: 0x00075B6C File Offset: 0x00073D6C
	private void #=zx26R3IFca56HGRaIcw==(int #=z$Ib9gYQ=)
	{
		this.#=zuL23bAV1bimF3EZSH7ymqNvz2lme = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EA1 RID: 3745 RVA: 0x00075B78 File Offset: 0x00073D78
	public static #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zi1hFJwI=()
	{
		return #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zvw0rWruSYIHsC4FAUwsBgMo=();
	}

	// Token: 0x06000EA2 RID: 3746 RVA: 0x00075B80 File Offset: 0x00073D80
	public void #=z48rEd0A=(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= #=zsbwXxuA=)
	{
		base.Add(#=zsbwXxuA=);
		if (#=zsbwXxuA=.#=zVaUA5_qegiur() > this.#=zyowZ9U1Cgv5d())
		{
			this.#=zaYB$PK9UGSU7(#=zsbwXxuA=.#=zVaUA5_qegiur());
		}
		if (#=zsbwXxuA=.#=zaKAy47_E$9SRuF6oiw==() > this.#=z40n214Sx3_pCHbGMNg==())
		{
			this.#=zx26R3IFca56HGRaIcw==(#=zsbwXxuA=.#=zaKAy47_E$9SRuF6oiw==());
		}
	}

	// Token: 0x06000EA3 RID: 3747 RVA: 0x00075BC0 File Offset: 0x00073DC0
	public #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= #=zd634hMCtcd$T(int #=zAk8mKBk=)
	{
		#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95.#=zr_yosI_ImfoCYek4BdK6O1U= #=zr_yosI_ImfoCYek4BdK6O1U= = new #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95.#=zr_yosI_ImfoCYek4BdK6O1U=();
		#=zr_yosI_ImfoCYek4BdK6O1U=.#=zAk8mKBk= = #=zAk8mKBk=;
		#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= = base.Find(new Predicate<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=>(#=zr_yosI_ImfoCYek4BdK6O1U=.#=zhl9cVWDJkLGBpgzcIw==));
		if (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= == null)
		{
			#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= = new #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=(#=zr_yosI_ImfoCYek4BdK6O1U=.#=zAk8mKBk=, 0, 0);
		}
		return #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=;
	}

	// Token: 0x0400082B RID: 2091
	private int #=zAbf9COKE0GA5JZBFLxG1tmc=;

	// Token: 0x0400082C RID: 2092
	private int #=zuL23bAV1bimF3EZSH7ymqNvz2lme;

	// Token: 0x020001E2 RID: 482
	private sealed class #=zr_yosI_ImfoCYek4BdK6O1U=
	{
		// Token: 0x06000EA5 RID: 3749 RVA: 0x00075C08 File Offset: 0x00073E08
		internal bool #=zhl9cVWDJkLGBpgzcIw==(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= #=zQrqFdos=)
		{
			return #=zQrqFdos=.Id == this.#=zAk8mKBk=;
		}

		// Token: 0x0400082D RID: 2093
		public int #=zAk8mKBk=;
	}
}
