﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200009C RID: 156
internal sealed class #=z7vgLvoK30HM177elyIfaTsOYLkcz7QZ7VlrBDUY= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600042B RID: 1067 RVA: 0x000244FC File Offset: 0x000226FC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z3ux88oRnHej1Gx9MrQ== = #=zuJjQ1XU=.#=zlHORuxrRT9tH();
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x0002450C File Offset: 0x0002270C
	protected override void #=zvb5bnug=()
	{
		for (int i = this.#=z3ux88oRnHej1Gx9MrQ==.Count - 1; i >= 0; i--)
		{
			#=z7vgLvoK30HM177elyIfaTsOYLkcz7QZ7VlrBDUY=.#=zV_Jaipud2OIj6AvV0w== #=zV_Jaipud2OIj6AvV0w== = new #=z7vgLvoK30HM177elyIfaTsOYLkcz7QZ7VlrBDUY=.#=zV_Jaipud2OIj6AvV0w==();
			#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg= = this.#=z3ux88oRnHej1Gx9MrQ==[i];
			if (#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zi66ZCDXN_8bo() == (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw=)1 && #=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zM9ux$svU_qlRnylQMQ==() != DateTime.MinValue && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ArtifactsMoveToStorageIds.Contains(#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zq2bPTdY=().Id) && this.#=z3ux88oRnHej1Gx9MrQ==.FindAll(new Predicate<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV>(#=zV_Jaipud2OIj6AvV0w==.#=z8ROWZYlEsQJ5)).Count < #=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zsDT9OIOutcCTJVL9cA==)
			{
				string text = this.#=zBsXSanI=.#=znCgHepLSCEKUYbcI2g==(#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zMuFMjGQ=());
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977705), new object[]
					{
						#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zkfqcY3I=(),
						JSONManager.Cut(text)
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977766), new object[]
				{
					#=zV_Jaipud2OIj6AvV0w==.#=zw95ILqg=.#=zkfqcY3I=()
				});
			}
		}
	}

	// Token: 0x04000185 RID: 389
	private List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=z3ux88oRnHej1Gx9MrQ==;

	// Token: 0x0200009D RID: 157
	private sealed class #=zV_Jaipud2OIj6AvV0w==
	{
		// Token: 0x0600042E RID: 1070 RVA: 0x0002466C File Offset: 0x0002286C
		internal bool #=z8ROWZYlEsQJ5(#=zF_m$qwkni_ep$nCra3nSOCYbdgBV #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == this.#=zw95ILqg=.#=zMuFMjGQ=() && (#=zQrqFdos=.#=zi66ZCDXN_8bo() == (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw=)0 || #=zQrqFdos=.#=zi66ZCDXN_8bo() == (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw=)2);
		}

		// Token: 0x04000186 RID: 390
		public #=zF_m$qwkni_ep$nCra3nSOCYbdgBV #=zw95ILqg=;
	}
}
