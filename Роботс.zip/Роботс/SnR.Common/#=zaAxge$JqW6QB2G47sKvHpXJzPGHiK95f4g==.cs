﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;
using Skink.SnR.Common.UserMeta;

// Token: 0x020001F9 RID: 505
internal sealed class #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== : ITagged
{
	// Token: 0x06000F47 RID: 3911 RVA: 0x00079AA8 File Offset: 0x00077CA8
	public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, int #=zLeeSKrg=)
	{
		this.#=zb87pU$r8o93u(#=zhoOF5s8=);
		this.#=zdMaX3XaC3vQm(new ActionSettings());
		this.#=zzGqrqB9edvMs(new ActionSettings());
		this.#=zTuZcc2ZYifoC(new #=z23sS9NhIcGaTj3irAlB1lVH1yUQC(false));
		this.#=zIalBwzemtrej9gdwGQ==(new #=z23sS9NhIcGaTj3irAlB1lVH1yUQC(true));
		this.#=z_YIPwP9WJYl7(new #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==());
		this.#=zSYGTieA=(null);
		this.#=zMPjMQLIQx0cS(new #=ze$wRqZvk4IFxxkyZrijhYK$eX_La(JSONManager.FixStringForFileName(#=zhoOF5s8=.#=z9Yordw6ZFjQe()), #=zLeeSKrg=));
		this.#=zkTWuAQxYldlmcsjOEzKncho=(new #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=(ResourceTypes.Grain));
		this.#=zr$jBMnVxcqHqLBq76A==(DateTime.MinValue);
		this.#=zpAIjRlo0AKmKYNY3$g==(DateTime.MinValue);
		this.#=zfHO$ZGpgI$6H5Ku14A==(DateTime.MinValue);
		this.#=z8hJHIKFp6jOv(#=zLeeSKrg=);
		this.#=zW2Vlp5vytS40(0);
		this.#=zZO602PMT5c9U = null;
		this.#=zanAiGPgJfu$CHYZMKmKLNeg= = DateTime.MaxValue;
		this.#=zBENwKCkTvw3nABAn9$QvZl2_afFQO6vtkkdQOCA=(0);
		this.#=z6dCrRf67ci4JJjZe0A==(DateTime.MinValue);
		this.#=zBRIfl6d1u1sanKjCjA==(new #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool>(TimeSpan.FromMinutes(60.0), false, false));
		this.#=zFBWuiUIYIGpO(new #=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA==());
		this.#=zmcY73rPax7QTB6q_YQ==(new Dictionary<string, long>());
	}

	// Token: 0x06000F48 RID: 3912 RVA: 0x00079BAC File Offset: 0x00077DAC
	public #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zh5Q$jgycqA15()
	{
		return this.#=zJs7cfn_SMDCu_edV$g==;
	}

	// Token: 0x06000F49 RID: 3913 RVA: 0x00079BB4 File Offset: 0x00077DB4
	private void #=zb87pU$r8o93u(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=z$Ib9gYQ=)
	{
		this.#=zJs7cfn_SMDCu_edV$g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F4A RID: 3914 RVA: 0x00079BC0 File Offset: 0x00077DC0
	public int #=zYgvZuBwR$a1C()
	{
		return this.#=z$eM7GpXgW_KO8hkYHQ==;
	}

	// Token: 0x06000F4B RID: 3915 RVA: 0x00079BC8 File Offset: 0x00077DC8
	public void #=z8hJHIKFp6jOv(int #=z$Ib9gYQ=)
	{
		this.#=z$eM7GpXgW_KO8hkYHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F4C RID: 3916 RVA: 0x00079BD4 File Offset: 0x00077DD4
	public int #=zKHqHudNIb2os()
	{
		return this.#=z5gRv1_smzqub_tRhzg==;
	}

	// Token: 0x06000F4D RID: 3917 RVA: 0x00079BDC File Offset: 0x00077DDC
	public void #=zW2Vlp5vytS40(int #=z$Ib9gYQ=)
	{
		this.#=z5gRv1_smzqub_tRhzg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F4E RID: 3918 RVA: 0x00079BE8 File Offset: 0x00077DE8
	public string #=z5qDil6s=(int #=z1IfIAIy7EDpV)
	{
		int #=zCHPchKE= = (#=z1IfIAIy7EDpV >= 0) ? #=z1IfIAIy7EDpV : this.#=zKHqHudNIb2os();
		return GameApplicationData.#=za4LDzr6$43pL(this.#=zYgvZuBwR$a1C(), #=zCHPchKE=).ToString();
	}

	// Token: 0x06000F4F RID: 3919 RVA: 0x00079C14 File Offset: 0x00077E14
	public string #=zVTXNaO2wZJzQ()
	{
		return GameApplicationData.#=zq64$9ho=(this.#=zYgvZuBwR$a1C());
	}

	// Token: 0x06000F50 RID: 3920 RVA: 0x00079C24 File Offset: 0x00077E24
	public string #=z87XIzK7RTgT1()
	{
		if (this.#=zanAiGPgJfu$CHYZMKmKLNeg= <= DateTime.Now)
		{
			this.#=zZO602PMT5c9U = null;
			this.#=zanAiGPgJfu$CHYZMKmKLNeg= = DateTime.MaxValue;
		}
		return this.#=zZO602PMT5c9U;
	}

	// Token: 0x06000F51 RID: 3921 RVA: 0x00079C50 File Offset: 0x00077E50
	public void #=zgi8txbeKnNhG(string #=z$Ib9gYQ=)
	{
		this.#=zZO602PMT5c9U = #=z$Ib9gYQ=;
		this.#=z_OReq$2Fp1WgvhSEAt7Hh6E=();
	}

	// Token: 0x06000F52 RID: 3922 RVA: 0x00079C60 File Offset: 0x00077E60
	public void #=z_OReq$2Fp1WgvhSEAt7Hh6E=()
	{
		this.#=zanAiGPgJfu$CHYZMKmKLNeg= = DateTime.MaxValue;
		if (!string.IsNullOrEmpty(this.#=zZO602PMT5c9U))
		{
			double value;
			if (this.#=zv2Kyu17YrGOC() != null && this.#=zv2Kyu17YrGOC().InitExpireHours > 0.0)
			{
				value = this.#=zv2Kyu17YrGOC().InitExpireHours;
			}
			else
			{
				value = 12.0;
			}
			this.#=zanAiGPgJfu$CHYZMKmKLNeg= = DateTime.Now + TimeSpan.FromHours(value);
		}
	}

	// Token: 0x06000F53 RID: 3923 RVA: 0x00079CD4 File Offset: 0x00077ED4
	public bool #=zQ$VqUtt$6rBX()
	{
		return this.#=zDJTdPdgYOaokr2T5FVwTdJA=;
	}

	// Token: 0x06000F54 RID: 3924 RVA: 0x00079CDC File Offset: 0x00077EDC
	public void #=zXBCeOAAyIMED(bool #=z$Ib9gYQ=)
	{
		this.#=zDJTdPdgYOaokr2T5FVwTdJA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F55 RID: 3925 RVA: 0x00079CE8 File Offset: 0x00077EE8
	public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zjV_wsuvJ0R_B()
	{
		return this.#=z25WeO8El96KyUqJvv7Xus2Q=;
	}

	// Token: 0x06000F56 RID: 3926 RVA: 0x00079CF0 File Offset: 0x00077EF0
	public void #=zUg$cyyC$uyqZ(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z$Ib9gYQ=)
	{
		this.#=z25WeO8El96KyUqJvv7Xus2Q= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F57 RID: 3927 RVA: 0x00079CFC File Offset: 0x00077EFC
	public string #=zdEt_WRHpdEMmGTK_3Q==()
	{
		if (!string.IsNullOrEmpty(this.#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H()))
		{
			return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862184), new object[]
			{
				this.#=zh5Q$jgycqA15().#=z2ZE0cltcIoE3IY7EAQ==(),
				this.#=zh5Q$jgycqA15().#=zbfOGJA_8wt3H(),
				this.#=zh5Q$jgycqA15().#=zjWBl268nvo9O(),
				this.#=zVTXNaO2wZJzQ()
			});
		}
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862161), this.#=zh5Q$jgycqA15().#=z2ZE0cltcIoE3IY7EAQ==(), this.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe(), this.#=zVTXNaO2wZJzQ());
	}

	// Token: 0x06000F58 RID: 3928 RVA: 0x00079D9C File Offset: 0x00077F9C
	public bool #=zq76JuU9WPIZn()
	{
		return !string.IsNullOrEmpty(this.#=zZO602PMT5c9U);
	}

	// Token: 0x06000F59 RID: 3929 RVA: 0x00079DAC File Offset: 0x00077FAC
	public ActionSettings #=zv2Kyu17YrGOC()
	{
		return this.#=zpYcaE67pPl3DD$xZ4A==;
	}

	// Token: 0x06000F5A RID: 3930 RVA: 0x00079DB4 File Offset: 0x00077FB4
	private void #=zdMaX3XaC3vQm(ActionSettings #=z$Ib9gYQ=)
	{
		this.#=zpYcaE67pPl3DD$xZ4A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F5B RID: 3931 RVA: 0x00079DC0 File Offset: 0x00077FC0
	public ActionSettings #=zaudlwXG$FEcN()
	{
		return this.#=z1dGTFAwSvZeuxtwFg7TiUHo=;
	}

	// Token: 0x06000F5C RID: 3932 RVA: 0x00079DC8 File Offset: 0x00077FC8
	private void #=zzGqrqB9edvMs(ActionSettings #=z$Ib9gYQ=)
	{
		this.#=z1dGTFAwSvZeuxtwFg7TiUHo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F5D RID: 3933 RVA: 0x00079DD4 File Offset: 0x00077FD4
	public #=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=zGQl3yUpez1XJ()
	{
		return this.#=zxFsHf28lG_yG1aq1DnXLAZA=;
	}

	// Token: 0x06000F5E RID: 3934 RVA: 0x00079DDC File Offset: 0x00077FDC
	private void #=zTuZcc2ZYifoC(#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z$Ib9gYQ=)
	{
		this.#=zxFsHf28lG_yG1aq1DnXLAZA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F5F RID: 3935 RVA: 0x00079DE8 File Offset: 0x00077FE8
	public #=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=zzia5edbZiDd_52XM1A==()
	{
		return this.#=z112q2kKqK3_a7JtRJBTavmqrfiOB;
	}

	// Token: 0x06000F60 RID: 3936 RVA: 0x00079DF0 File Offset: 0x00077FF0
	private void #=zIalBwzemtrej9gdwGQ==(#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z$Ib9gYQ=)
	{
		this.#=z112q2kKqK3_a7JtRJBTavmqrfiOB = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F61 RID: 3937 RVA: 0x00079DFC File Offset: 0x00077FFC
	public #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=z5Fxa9o9ygZWU()
	{
		return this.#=zLD7EcP5kxfmGyafr0w==;
	}

	// Token: 0x06000F62 RID: 3938 RVA: 0x00079E04 File Offset: 0x00078004
	private void #=z_YIPwP9WJYl7(#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=z$Ib9gYQ=)
	{
		this.#=zLD7EcP5kxfmGyafr0w== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F63 RID: 3939 RVA: 0x00079E10 File Offset: 0x00078010
	public #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zDZReNK0=()
	{
		return this.#=zIMMjA4KhtGkvHGzNFA==;
	}

	// Token: 0x06000F64 RID: 3940 RVA: 0x00079E18 File Offset: 0x00078018
	private void #=zSYGTieA=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=z$Ib9gYQ=)
	{
		this.#=zIMMjA4KhtGkvHGzNFA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F65 RID: 3941 RVA: 0x00079E24 File Offset: 0x00078024
	public #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=z3YtB02S6CjKY()
	{
		return this.#=z39cqI53Dlel9n4LBEQ==;
	}

	// Token: 0x06000F66 RID: 3942 RVA: 0x00079E2C File Offset: 0x0007802C
	private void #=zMPjMQLIQx0cS(#=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=z$Ib9gYQ=)
	{
		this.#=z39cqI53Dlel9n4LBEQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F67 RID: 3943 RVA: 0x00079E38 File Offset: 0x00078038
	public #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI= #=zfgnLN9jbKv4ZyrxNJg3Xr78=()
	{
		return this.#=zMBXBfuMHOJPNx_10AOKcvP9QCgIy;
	}

	// Token: 0x06000F68 RID: 3944 RVA: 0x00079E40 File Offset: 0x00078040
	private void #=zkTWuAQxYldlmcsjOEzKncho=(#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI= #=z$Ib9gYQ=)
	{
		this.#=zMBXBfuMHOJPNx_10AOKcvP9QCgIy = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F69 RID: 3945 RVA: 0x00079E4C File Offset: 0x0007804C
	public UnitSquadCollection[] #=zye4p0LD68zfCQCgzAg==()
	{
		return this.#=z9Vn0IgjvIUN3PsgDjMydkxk=;
	}

	// Token: 0x06000F6A RID: 3946 RVA: 0x00079E54 File Offset: 0x00078054
	public void #=zWwACCeJ9QQhNyL6$Hg==(UnitSquadCollection[] #=z$Ib9gYQ=)
	{
		this.#=z9Vn0IgjvIUN3PsgDjMydkxk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F6B RID: 3947 RVA: 0x00079E60 File Offset: 0x00078060
	public #=zy9zQtVcRsBCeOmSjzVQDdfAWHUpOtVU5GQ== #=zHk2CSHOH76iz()
	{
		return this.#=ziBbrRyUWh3JPkOgTMg==;
	}

	// Token: 0x06000F6C RID: 3948 RVA: 0x00079E68 File Offset: 0x00078068
	public void #=zL15kcYKKrFqK(#=zy9zQtVcRsBCeOmSjzVQDdfAWHUpOtVU5GQ== #=z$Ib9gYQ=)
	{
		this.#=ziBbrRyUWh3JPkOgTMg== = #=z$Ib9gYQ=;
	}

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000F6D RID: 3949 RVA: 0x00079E74 File Offset: 0x00078074
	public List<string> Tags
	{
		get
		{
			List<string> list = new List<string>();
			if (GameApplicationData.#=zMD9IS3VDVH4f() > 1)
			{
				list.Add(this.#=zVTXNaO2wZJzQ());
			}
			if (this.#=zjV_wsuvJ0R_B() != null)
			{
				list.Add(this.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==());
			}
			list.AddRange(this.#=zv2Kyu17YrGOC().CustomTagsList);
			return list;
		}
	}

	// Token: 0x06000F6E RID: 3950 RVA: 0x00079EC8 File Offset: 0x000780C8
	public string #=z72grV1lsvZeM()
	{
		StringBuilder stringBuilder = new StringBuilder();
		if (GameApplicationData.#=zMD9IS3VDVH4f() > 1)
		{
			stringBuilder.Append(this.#=zVTXNaO2wZJzQ());
		}
		if (this.#=zjV_wsuvJ0R_B() != null && !string.IsNullOrEmpty(this.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==()))
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
			}
			stringBuilder.Append(this.#=zjV_wsuvJ0R_B().#=zj661vGqZTMsoJ4JrPg==());
		}
		for (int i = 0; i < this.#=zv2Kyu17YrGOC().CustomTagsList.Count; i++)
		{
			if (stringBuilder.Length > 0)
			{
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
			}
			stringBuilder.Append(this.#=zv2Kyu17YrGOC().CustomTagsList[i]);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000F6F RID: 3951 RVA: 0x00079F8C File Offset: 0x0007818C
	public DateTime #=zueZ$FCyRT_UZyAN7rg==()
	{
		return this.#=zeoN60l3u0TkwaNmqwge2TVk=;
	}

	// Token: 0x06000F70 RID: 3952 RVA: 0x00079F94 File Offset: 0x00078194
	public void #=zr$jBMnVxcqHqLBq76A==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zeoN60l3u0TkwaNmqwge2TVk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F71 RID: 3953 RVA: 0x00079FA0 File Offset: 0x000781A0
	public DateTime #=zxF$r5QndSVMh6QFdUw==()
	{
		return this.#=z$Zzy81nW8bTDBdjRjKT7sKw=;
	}

	// Token: 0x06000F72 RID: 3954 RVA: 0x00079FA8 File Offset: 0x000781A8
	public void #=zpAIjRlo0AKmKYNY3$g==(DateTime #=z$Ib9gYQ=)
	{
		this.#=z$Zzy81nW8bTDBdjRjKT7sKw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F73 RID: 3955 RVA: 0x00079FB4 File Offset: 0x000781B4
	public DateTime #=zXxfySY3M3ahisYYNUw==()
	{
		return this.#=zXZmFjhc50xeCKD5lGR8VcDU=;
	}

	// Token: 0x06000F74 RID: 3956 RVA: 0x00079FBC File Offset: 0x000781BC
	public void #=zfHO$ZGpgI$6H5Ku14A==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zXZmFjhc50xeCKD5lGR8VcDU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F75 RID: 3957 RVA: 0x00079FC8 File Offset: 0x000781C8
	public DateTime #=z5CQ3MMGT7KZ6NzsrOA==()
	{
		return this.#=zIfPiAeLOVycv9UiR8Y4b7eg=;
	}

	// Token: 0x06000F76 RID: 3958 RVA: 0x00079FD0 File Offset: 0x000781D0
	public void #=z_5FJXkan3koNCP1yRA==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zIfPiAeLOVycv9UiR8Y4b7eg= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F77 RID: 3959 RVA: 0x00079FDC File Offset: 0x000781DC
	public DateTime #=zXhmu8wtI1QFueNwTW0lbj2Q=()
	{
		return this.#=z90Ch0cCZYIBRvqI121q$8vsIsakZ;
	}

	// Token: 0x06000F78 RID: 3960 RVA: 0x00079FE4 File Offset: 0x000781E4
	public void #=zbdyC5WKGPSBd2ERB$laIbwI=(DateTime #=z$Ib9gYQ=)
	{
		this.#=z90Ch0cCZYIBRvqI121q$8vsIsakZ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F79 RID: 3961 RVA: 0x00079FF0 File Offset: 0x000781F0
	public DateTime #=ziYbj9IsgzGRe7374EQ==()
	{
		return this.#=zbeMmnckoTdrVsLvT1p4CQ3k=;
	}

	// Token: 0x06000F7A RID: 3962 RVA: 0x00079FF8 File Offset: 0x000781F8
	public void #=z6dCrRf67ci4JJjZe0A==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zbeMmnckoTdrVsLvT1p4CQ3k= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F7B RID: 3963 RVA: 0x0007A004 File Offset: 0x00078204
	public #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=zEv2Z7dPcJ0blSeJTDQ==()
	{
		return this.#=ztltiUfQGfgSTwZg$7Cu2JE4=;
	}

	// Token: 0x06000F7C RID: 3964 RVA: 0x0007A00C File Offset: 0x0007820C
	public void #=zBRIfl6d1u1sanKjCjA==(#=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=z$Ib9gYQ=)
	{
		this.#=ztltiUfQGfgSTwZg$7Cu2JE4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F7D RID: 3965 RVA: 0x0007A018 File Offset: 0x00078218
	public #=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA== #=z2qORYNmMpSU7()
	{
		return this.#=zEBC76LV1KgRUcOYoXcXf7Bk=;
	}

	// Token: 0x06000F7E RID: 3966 RVA: 0x0007A020 File Offset: 0x00078220
	private void #=zFBWuiUIYIGpO(#=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA== #=z$Ib9gYQ=)
	{
		this.#=zEBC76LV1KgRUcOYoXcXf7Bk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F7F RID: 3967 RVA: 0x0007A02C File Offset: 0x0007822C
	public DateTime #=z5WD8BTn54npdaX13Rg==()
	{
		return this.#=zW5PqgB2zqyiuzBplT_svBR8=;
	}

	// Token: 0x06000F80 RID: 3968 RVA: 0x0007A034 File Offset: 0x00078234
	public void #=zW3LvHA20HtNnpfcb9g==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zW5PqgB2zqyiuzBplT_svBR8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F81 RID: 3969 RVA: 0x0007A040 File Offset: 0x00078240
	public int #=zk0_Y$SJ_d1Er()
	{
		return this.#=z_hOBian5ANLp2FdcOw==;
	}

	// Token: 0x06000F82 RID: 3970 RVA: 0x0007A048 File Offset: 0x00078248
	public void #=zWqunoVP8Im4d(int #=z$Ib9gYQ=)
	{
		this.#=z_hOBian5ANLp2FdcOw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F83 RID: 3971 RVA: 0x0007A054 File Offset: 0x00078254
	public int #=zd_DW0ufJYCod()
	{
		return this.#=zCG0j4QatqGIRUXi4HoN4qKw=;
	}

	// Token: 0x06000F84 RID: 3972 RVA: 0x0007A05C File Offset: 0x0007825C
	public void #=zPGfL4rgl8WkG(int #=z$Ib9gYQ=)
	{
		this.#=zCG0j4QatqGIRUXi4HoN4qKw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F85 RID: 3973 RVA: 0x0007A068 File Offset: 0x00078268
	public long #=zd7Gjkk3oclDR()
	{
		return this.#=zNhcq7G1VXXddqswUaHTN$s4=;
	}

	// Token: 0x06000F86 RID: 3974 RVA: 0x0007A070 File Offset: 0x00078270
	public void #=zw85sRUw9UHM7(long #=z$Ib9gYQ=)
	{
		this.#=zNhcq7G1VXXddqswUaHTN$s4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F87 RID: 3975 RVA: 0x0007A07C File Offset: 0x0007827C
	public long #=zc3DeoTSaHY6p5yNLew==()
	{
		return this.#=zQOGJXS1Oh4UaH_G9AYvAls4=;
	}

	// Token: 0x06000F88 RID: 3976 RVA: 0x0007A084 File Offset: 0x00078284
	public void #=zBvCSQJJWCsSAL_vReA==(long #=z$Ib9gYQ=)
	{
		this.#=zQOGJXS1Oh4UaH_G9AYvAls4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F89 RID: 3977 RVA: 0x0007A090 File Offset: 0x00078290
	public int #=zKplt9fghze5O()
	{
		return this.#=zYk_j_AwSdqx9XuA0Fw==;
	}

	// Token: 0x06000F8A RID: 3978 RVA: 0x0007A098 File Offset: 0x00078298
	public void #=zYNBRw$1JagVG(int #=z$Ib9gYQ=)
	{
		this.#=zYk_j_AwSdqx9XuA0Fw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F8B RID: 3979 RVA: 0x0007A0A4 File Offset: 0x000782A4
	public int #=zBVDBY_3gDr2hDFDdywwrWdQ=()
	{
		return this.#=zeQ6Q5db0V29aZrCpNM0k9sJ6PUgg;
	}

	// Token: 0x06000F8C RID: 3980 RVA: 0x0007A0AC File Offset: 0x000782AC
	public void #=z9EbNx80uMOzwrg3lZ6219kM=(int #=z$Ib9gYQ=)
	{
		this.#=zeQ6Q5db0V29aZrCpNM0k9sJ6PUgg = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F8D RID: 3981 RVA: 0x0007A0B8 File Offset: 0x000782B8
	public Dictionary<string, long> #=zhr1zOD1HSV5DW11Dog==()
	{
		return this.#=zuiGiz9zWSPg62b3q8r9jp9o=;
	}

	// Token: 0x06000F8E RID: 3982 RVA: 0x0007A0C0 File Offset: 0x000782C0
	public void #=zmcY73rPax7QTB6q_YQ==(Dictionary<string, long> #=z$Ib9gYQ=)
	{
		this.#=zuiGiz9zWSPg62b3q8r9jp9o= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F8F RID: 3983 RVA: 0x0007A0CC File Offset: 0x000782CC
	public int #=zOHjQnymy_Z90w6eDb8LcZGkt6fW2QsRIYzB9SIw=()
	{
		return this.#=z8so5P9rUc_$spzAa$4ycMKmYBNidplYJVmyLm9gWqVtHkiGlYQ==;
	}

	// Token: 0x06000F90 RID: 3984 RVA: 0x0007A0D4 File Offset: 0x000782D4
	public void #=zBENwKCkTvw3nABAn9$QvZl2_afFQO6vtkkdQOCA=(int #=z$Ib9gYQ=)
	{
		this.#=z8so5P9rUc_$spzAa$4ycMKmYBNidplYJVmyLm9gWqVtHkiGlYQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F91 RID: 3985 RVA: 0x0007A0E0 File Offset: 0x000782E0
	public void #=z7PpXELDatYLR(ActionSettings #=z6bRJXNQ=)
	{
		this.#=zdMaX3XaC3vQm(#=z6bRJXNQ=);
	}

	// Token: 0x06000F92 RID: 3986 RVA: 0x0007A0EC File Offset: 0x000782EC
	public void #=zddKXe6nWZmil()
	{
		this.#=zzGqrqB9edvMs(this.#=zv2Kyu17YrGOC().CopyToRecent());
	}

	// Token: 0x06000F93 RID: 3987 RVA: 0x0007A100 File Offset: 0x00078300
	public void #=zeR3QFrc=(Task #=zcTyyNys=)
	{
		if (#=zcTyyNys=.Severity == TaskSeverities.Background)
		{
			this.#=zGQl3yUpez1XJ().Add(#=zcTyyNys=);
			return;
		}
		this.#=zzia5edbZiDd_52XM1A==().Add(#=zcTyyNys=);
	}

	// Token: 0x06000F94 RID: 3988 RVA: 0x0007A124 File Offset: 0x00078324
	public void #=zsyjyZeg=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		if (!#=zuJjQ1XU=.#=zbhjPyxLDEPBD())
		{
			return;
		}
		this.#=z5Fxa9o9ygZWU().#=zsRV1Asc=(#=zuJjQ1XU=);
		if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zoB_PPwnFbKCa())
		{
			if (this.#=zDZReNK0=() == null)
			{
				this.#=zSYGTieA=(new #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==());
			}
			this.#=zDZReNK0=().#=zsRV1Asc=(#=zuJjQ1XU=);
		}
		else if (this.#=zDZReNK0=() != null)
		{
			this.#=zSYGTieA=(null);
		}
		if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zgr_b3nv857lLfLmFjw==() && this.#=zDZReNK0=() != null)
		{
			this.#=zDZReNK0=().#=zX58ScsagA3OP(#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zfkMjd4$nuTc4l5SAG5VXdaY=(#=zuJjQ1XU=.#=zQ4wZnctPyyRO(), #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==(), #=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru(), #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==(), #=zuJjQ1XU=.#=zzDosIddISk1$()));
		}
		this.#=zfgnLN9jbKv4ZyrxNJg3Xr78=().#=zK7_p5R0=(#=zuJjQ1XU=.#=zZan5aKOWyPR5(), #=zuJjQ1XU=.#=z_tcU3ov4mZ9V());
	}

	// Token: 0x06000F95 RID: 3989 RVA: 0x0007A1DC File Offset: 0x000783DC
	public bool #=zkXsxKS4OL0sN(List<ResourceTypes> #=zy0tqKwE=, string #=z4C$TCDU=, bool #=zs3fMkpz5tDM2XcAtmg==)
	{
		return this.#=zv2Kyu17YrGOC().CheckResourcePriority(#=zy0tqKwE=, #=z4C$TCDU=, this.#=zfgnLN9jbKv4ZyrxNJg3Xr78=().#=zcPDeKMQFl$$_(), #=zs3fMkpz5tDM2XcAtmg==);
	}

	// Token: 0x04000883 RID: 2179
	private #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJs7cfn_SMDCu_edV$g==;

	// Token: 0x04000884 RID: 2180
	private int #=z$eM7GpXgW_KO8hkYHQ==;

	// Token: 0x04000885 RID: 2181
	private int #=z5gRv1_smzqub_tRhzg==;

	// Token: 0x04000886 RID: 2182
	private string #=zZO602PMT5c9U;

	// Token: 0x04000887 RID: 2183
	private DateTime #=zanAiGPgJfu$CHYZMKmKLNeg=;

	// Token: 0x04000888 RID: 2184
	private bool #=zDJTdPdgYOaokr2T5FVwTdJA=;

	// Token: 0x04000889 RID: 2185
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z25WeO8El96KyUqJvv7Xus2Q=;

	// Token: 0x0400088A RID: 2186
	private ActionSettings #=zpYcaE67pPl3DD$xZ4A==;

	// Token: 0x0400088B RID: 2187
	private ActionSettings #=z1dGTFAwSvZeuxtwFg7TiUHo=;

	// Token: 0x0400088C RID: 2188
	private #=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=zxFsHf28lG_yG1aq1DnXLAZA=;

	// Token: 0x0400088D RID: 2189
	private #=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=z112q2kKqK3_a7JtRJBTavmqrfiOB;

	// Token: 0x0400088E RID: 2190
	private #=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA== #=zLD7EcP5kxfmGyafr0w==;

	// Token: 0x0400088F RID: 2191
	private #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zIMMjA4KhtGkvHGzNFA==;

	// Token: 0x04000890 RID: 2192
	private #=ze$wRqZvk4IFxxkyZrijhYK$eX_La #=z39cqI53Dlel9n4LBEQ==;

	// Token: 0x04000891 RID: 2193
	private #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI= #=zMBXBfuMHOJPNx_10AOKcvP9QCgIy;

	// Token: 0x04000892 RID: 2194
	private UnitSquadCollection[] #=z9Vn0IgjvIUN3PsgDjMydkxk=;

	// Token: 0x04000893 RID: 2195
	private #=zy9zQtVcRsBCeOmSjzVQDdfAWHUpOtVU5GQ== #=ziBbrRyUWh3JPkOgTMg==;

	// Token: 0x04000894 RID: 2196
	private DateTime #=zeoN60l3u0TkwaNmqwge2TVk=;

	// Token: 0x04000895 RID: 2197
	private DateTime #=z$Zzy81nW8bTDBdjRjKT7sKw=;

	// Token: 0x04000896 RID: 2198
	private DateTime #=zXZmFjhc50xeCKD5lGR8VcDU=;

	// Token: 0x04000897 RID: 2199
	private DateTime #=zIfPiAeLOVycv9UiR8Y4b7eg=;

	// Token: 0x04000898 RID: 2200
	private DateTime #=z90Ch0cCZYIBRvqI121q$8vsIsakZ;

	// Token: 0x04000899 RID: 2201
	private DateTime #=zbeMmnckoTdrVsLvT1p4CQ3k=;

	// Token: 0x0400089A RID: 2202
	private #=zgkTlhahQGP9$hAfYi4Jtjb6SidGjHTqNPwDAvt0=<bool> #=ztltiUfQGfgSTwZg$7Cu2JE4=;

	// Token: 0x0400089B RID: 2203
	private #=z_uOd0sSsM08rXTL0SqUhpfbrdTkh3NWrjA== #=zEBC76LV1KgRUcOYoXcXf7Bk=;

	// Token: 0x0400089C RID: 2204
	private DateTime #=zW5PqgB2zqyiuzBplT_svBR8=;

	// Token: 0x0400089D RID: 2205
	private int #=z_hOBian5ANLp2FdcOw==;

	// Token: 0x0400089E RID: 2206
	private int #=zCG0j4QatqGIRUXi4HoN4qKw=;

	// Token: 0x0400089F RID: 2207
	private long #=zNhcq7G1VXXddqswUaHTN$s4=;

	// Token: 0x040008A0 RID: 2208
	private long #=zQOGJXS1Oh4UaH_G9AYvAls4=;

	// Token: 0x040008A1 RID: 2209
	private int #=zYk_j_AwSdqx9XuA0Fw==;

	// Token: 0x040008A2 RID: 2210
	private int #=zeQ6Q5db0V29aZrCpNM0k9sJ6PUgg;

	// Token: 0x040008A3 RID: 2211
	private Dictionary<string, long> #=zuiGiz9zWSPg62b3q8r9jp9o=;

	// Token: 0x040008A4 RID: 2212
	private int #=z8so5P9rUc_$spzAa$4ycMKmYBNidplYJVmyLm9gWqVtHkiGlYQ==;
}
