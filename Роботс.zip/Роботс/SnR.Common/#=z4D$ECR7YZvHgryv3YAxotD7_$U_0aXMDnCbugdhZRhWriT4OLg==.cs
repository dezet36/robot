﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x0200005E RID: 94
internal sealed class #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060002C2 RID: 706 RVA: 0x00016FAC File Offset: 0x000151AC
	public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==()
	{
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00016FB4 File Offset: 0x000151B4
	public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zncmSfpzM1Gv8, string #=zLFMf594Zu9zV93gwpg==)
	{
		this.#=z8StzeqE= = #=zncmSfpzM1Gv8.#=zQ4wZnctPyyRO();
		this.#=zG2wnL_q7IxpD = #=zncmSfpzM1Gv8;
		this.#=zBsXSanI= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zncmSfpzM1Gv8);
		this.#=zm92199OybSmIl9Uefw== = #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.#=zx5vCqcUFWsBk(#=zLFMf594Zu9zV93gwpg==);
		this.#=z9NIv67WFQ8g8Cs8ekA== = new #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=(new object[0]);
		this.#=zlhbZ30IOYw$h$EOR3Q== = new #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI=();
		this.#=zJxfgWpOiQEkVffms$_L1sXM= = 50;
		this.#=zn29IPVKYXuGYsOi4mOtk3oQ= = 500;
		this.#=zJuJOGd$r9zprxxNhlVfqNto= = new List<int>();
		this.#=zCY4az9$WUjLsEJ7fgg== = new #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=();
		this.#=zVG1EPv1OUDdyLeGHGQ== = new List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>();
		this.#=zeYLQo2n2g2lR = new List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>();
		this.#=z1L5EVM5jSO3xd$DrZn2dfAI= = new #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=(new object[0]);
		this.#=z5RRcbP0wotIN = null;
		this.#=zM4AChhv$H1IU = null;
		this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A== = null;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x00017074 File Offset: 0x00015274
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zm92199OybSmIl9Uefw== = #=zuJjQ1XU=.#=zdz_5DLjhAG09Q78wOA==();
		this.#=z9NIv67WFQ8g8Cs8ekA== = #=zuJjQ1XU=.#=zXtdX41TcXB7KvgMdHw==();
		this.#=zlhbZ30IOYw$h$EOR3Q== = #=zuJjQ1XU=.#=zwfEE1b14gF5xTRSrkA==();
		this.#=zJxfgWpOiQEkVffms$_L1sXM= = #=zuJjQ1XU=.#=zpvsaXyw82VkgOoZDJ1UnGfgei5Rf();
		this.#=zn29IPVKYXuGYsOi4mOtk3oQ= = #=zuJjQ1XU=.#=zK2B3D5hNXDwHR1pT1hpYeOQ=();
		this.#=zJuJOGd$r9zprxxNhlVfqNto= = #=zuJjQ1XU=.#=zMYCcUNQPbrHkLN3oUFTD9SU=();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		if (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zekU8dWv_Vlc3PL2OB4V85kksA7By(this.#=z8StzeqE=))
		{
			this.#=zeYLQo2n2g2lR = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
		}
		else
		{
			this.#=zeYLQo2n2g2lR = new List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>();
		}
		this.#=z1L5EVM5jSO3xd$DrZn2dfAI= = #=zuJjQ1XU=.#=zJt$4JjFDRj2sHIQvVXpOBcTazZMs();
		this.#=zcS6EjrRHjirK = #=zuJjQ1XU=.#=zN$_0ciN4j1M9Es9_zg==();
		this.#=z5RRcbP0wotIN = new #=zsXHWUPT57npsJ0h0q$KoR2cvphBjbYrLqGF_iQjBZHmR(this.#=z8StzeqE=, #=zuJjQ1XU=);
		this.#=zM4AChhv$H1IU = null;
		this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A== = null;
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x00017140 File Offset: 0x00015340
	protected override void #=zvb5bnug=()
	{
		if (this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zgcfxUHbZmytORt2N3GObk4o=().#=zR5pc2qgJfKgf(this.#=zm92199OybSmIl9Uefw==))
		{
			this.#=z8StzeqE=.#=zEv2Z7dPcJ0blSeJTDQ==().#=zKTAVzhk=(true);
		}
		this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zgcfxUHbZmytORt2N3GObk4o=().#=zm7nSMZ8=();
		if (this.#=z8StzeqE=.#=zEv2Z7dPcJ0blSeJTDQ==().#=zVcIxe_4=())
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882521), Array.Empty<object>());
			return;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsTower && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck <= DateTime.Now)
		{
			this.#=z01svGUf_$gU0uF_sG9_mbU8=();
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgrade)
		{
			if (!this.#=zv63Ga0Rf9HluVcTAB6ZCt24HJ2p_())
			{
				this.#=zPp7Q6VI=(false);
			}
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsQuests)
			{
				this.#=zHnqt7Q2SvpE77_mIJNjEk7E=();
			}
		}
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00017238 File Offset: 0x00015438
	private #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=zM4AChhv$H1IU == null)
		{
			this.#=zJA1zmO6YC9XY();
		}
		if (this.#=zM4AChhv$H1IU.ContainsKey(#=zU4TPzxM=.#=zMuFMjGQ=()))
		{
			return this.#=zM4AChhv$H1IU[#=zU4TPzxM=.#=zMuFMjGQ=()];
		}
		return (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0;
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x00017270 File Offset: 0x00015470
	private bool #=zTNy_G8M=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=[] #=zL00bZxVTIHUg6zKCRg==)
	{
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zY9gFTlM= = this.#=zbMDj$Y4=(#=zU4TPzxM=);
		for (int i = 0; i < #=zL00bZxVTIHUg6zKCRg==.Length; i++)
		{
			if (#=zL00bZxVTIHUg6zKCRg==[i] == #=zY9gFTlM=)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060002C8 RID: 712 RVA: 0x0001729C File Offset: 0x0001549C
	private void #=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zViv_PBQ=)
	{
		if (this.#=zM4AChhv$H1IU != null)
		{
			this.#=zM4AChhv$H1IU[#=zU4TPzxM=.#=zMuFMjGQ=()] = #=zViv_PBQ=;
		}
	}

	// Token: 0x060002C9 RID: 713 RVA: 0x000172B8 File Offset: 0x000154B8
	private bool #=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw== == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		return #=zU4TPzxM=.#=zi2a1Q$EWsrif() || this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw==.Contains(#=zU4TPzxM=.#=zMuFMjGQ=());
	}

	// Token: 0x060002CA RID: 714 RVA: 0x000172E4 File Offset: 0x000154E4
	private bool #=zpBYA1bhTG_f_(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=zRT1x$yoZiY5y4Z$sjNrd1vml12rpAACRC18t_P4= == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		return this.#=zRT1x$yoZiY5y4Z$sjNrd1vml12rpAACRC18t_P4=.Contains(#=zU4TPzxM=.#=zMuFMjGQ=());
	}

	// Token: 0x060002CB RID: 715 RVA: 0x00017308 File Offset: 0x00015508
	private bool #=zj_RULOkSJy6BjegQMw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		return this.#=zDgJiXLE=(#=zU4TPzxM=) || this.#=zJuJOGd$r9zprxxNhlVfqNto=.Contains(#=zU4TPzxM=.#=zMuFMjGQ=());
	}

	// Token: 0x060002CC RID: 716 RVA: 0x00017328 File Offset: 0x00015528
	private bool #=zDgJiXLE=(#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns= #=z5iQBCwKizwUEgvTrUw==)
	{
		if (this.#=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg== == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		return this.#=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg==.Contains(#=z5iQBCwKizwUEgvTrUw==.#=zMuFMjGQ=());
	}

	// Token: 0x060002CD RID: 717 RVA: 0x0001734C File Offset: 0x0001554C
	private void #=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw== == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw==.Add(#=zU4TPzxM=.#=zMuFMjGQ=());
	}

	// Token: 0x060002CE RID: 718 RVA: 0x00017370 File Offset: 0x00015570
	private void #=zM5vpWhdth4THSACoR3QyHJk=(#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns= #=z5iQBCwKizwUEgvTrUw==)
	{
		if (this.#=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg== == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		this.#=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg==.Add(#=z5iQBCwKizwUEgvTrUw==.#=zMuFMjGQ=());
	}

	// Token: 0x060002CF RID: 719 RVA: 0x00017394 File Offset: 0x00015594
	private bool #=zDgJiXLE=(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zC8Myo$XJkAPD)
	{
		if (this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A== == null)
		{
			this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		}
		return this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A==.Contains(#=zC8Myo$XJkAPD.#=zMuFMjGQ=());
	}

	// Token: 0x060002D0 RID: 720 RVA: 0x000173B8 File Offset: 0x000155B8
	private int #=z3687gj3eCey26lcJGjvksiiezE17(int #=zk_4E_3muViYC)
	{
		for (int i = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsNumberByType.Count - 2; i >= 0; i -= 2)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsNumberByType[i] == #=zk_4E_3muViYC)
			{
				return this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsNumberByType[i + 1];
			}
		}
		return 1;
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x0001741C File Offset: 0x0001561C
	public void #=zPp7Q6VI=(bool #=zopLv24c=)
	{
		if (this.#=zm92199OybSmIl9Uefw==.Count == 0 && !#=zopLv24c=)
		{
			this.#=z5RRcbP0wotIN.#=zhp_aikH5diw4gr0E2g==();
			return;
		}
		this.#=zm92199OybSmIl9Uefw==.Sort(new #=zqII3ZIVy1$iuelenykucuBTnVTDod4GcSQ==(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules));
		this.#=zJA1zmO6YC9XY();
		this.#=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==();
		if (this.#=z8StzeqE=.#=zDZReNK0=() != null)
		{
			this.#=z8StzeqE=.#=zDZReNK0=().#=zdz_5DLjhAG09Q78wOA==().#=zh9Hvpsvdmk9S(this.#=zm92199OybSmIl9Uefw==, this.#=zM4AChhv$H1IU);
		}
		if (!#=zopLv24c=)
		{
			this.#=zUBiHA1DLZS3V3G0r3Ghnw2c=(false);
			this.#=zMS$$UTrXW0NA();
			this.#=z4B66sSIz3BT8();
			this.#=zftEWtkew0ISQTMNEew==();
			this.#=zWppZPDMMEapK67$UYdFi4q0=();
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsJoinAndAmuletNextCheck <= DateTime.Now)
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsJoinAndAmuletNextCheck = DateTime.Now + TimeSpan.FromHours(1.0);
				this.#=zz22eei$X86rOSc_Pnw==();
				this.#=zXeuUS5od9ixgZ12trePxOLM=();
			}
		}
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x00017514 File Offset: 0x00015714
	private bool #=zPvPV29uCs8GIVUNPYd1$9jI=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (#=zU4TPzxM=.#=zYS6NXcO7DUmh())
		{
			return false;
		}
		if (#=zU4TPzxM=.#=ztP$zSGbniHTJ() && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDontUpgradeLockedGenerals)
		{
			return false;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontSendOnMonster, #=zU4TPzxM=))
		{
			return false;
		}
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zY9gFTlM= = this.#=zbMDj$Y4=(#=zU4TPzxM=);
		return (#=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)2 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)3 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21) && !this.#=zDgJiXLE=(#=zU4TPzxM=);
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x00017590 File Offset: 0x00015790
	private void #=zftEWtkew0ISQTMNEew==()
	{
		int num = -1;
		int num2 = 80;
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeBuyEnergy && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeRefillEnergy)
		{
			num = 10;
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck < DateTime.Now + TimeSpan.FromMinutes(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerCheckPeriod + 5.0))
			{
				num = 20;
			}
		}
		int num3 = this.#=zJxfgWpOiQEkVffms$_L1sXM=;
		if (num3 < num)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882445), new object[]
			{
				num3,
				num
			});
			return;
		}
		List<int> #=zErUbQv7u8Ay8A1q4e8mL5O4= = new List<int>();
		bool flag = false;
		bool flag2 = false;
		#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=zPMmTEU1PaAp0b$oySQ== = this.#=z9NIv67WFQ8g8Cs8ekA==;
		this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zS5BpZBs_LT3sEKeDeobrTyM=().#=zG64pC7Y=(#=zPMmTEU1PaAp0b$oySQ==);
		for (int i = 0; i < this.#=zm92199OybSmIl9Uefw==.Count; i++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zm92199OybSmIl9Uefw==[i];
			if (this.#=zPvPV29uCs8GIVUNPYd1$9jI=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
			{
				flag = true;
				bool flag3 = false;
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du() == 1 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z5iePdUZjnAHd() == 0.0 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeFullCycle && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDontGeneralsUpgradeVictimExp && !flag2)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = null;
					for (int j = 0; j < this.#=zm92199OybSmIl9Uefw==.Count; j++)
					{
						#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3 = this.#=zm92199OybSmIl9Uefw==[j];
						if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=ztj93y6niVpCR() == 1 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zvnZc$RhG_1Du() == 1 && this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)30 && !this.#=zj_RULOkSJy6BjegQMw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3) && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3))
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3;
							break;
						}
					}
					if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 != null)
					{
						string text = this.#=zBsXSanI=.#=zF7PK0Lub1Dzd(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=(), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=()
						}, new object[0]);
						if (text.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882603), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(),
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF()
							});
							this.#=zm92199OybSmIl9Uefw==.Remove(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2);
							flag3 = true;
						}
						else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032084)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882251), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(),
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF()
							});
							flag2 = true;
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882378), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(),
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2);
						}
					}
				}
				if (!flag3 && (this.#=z59cxMYGOBtLMM97LEQ==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$, #=zPMmTEU1PaAp0b$oySQ==, #=zErUbQv7u8Ay8A1q4e8mL5O4=, false, ref num3) || (num > 0 && num3 < num)))
				{
					break;
				}
			}
		}
		if (!flag && num3 > num2 && this.#=zm92199OybSmIl9Uefw==.Count > 0)
		{
			this.#=z59cxMYGOBtLMM97LEQ==(this.#=zm92199OybSmIl9Uefw==[0], #=zPMmTEU1PaAp0b$oySQ==, #=zErUbQv7u8Ay8A1q4e8mL5O4=, true, ref num3);
		}
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x00017904 File Offset: 0x00015B04
	private bool #=z59cxMYGOBtLMM97LEQ==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=zPMmTEU1PaAp0b$oySQ==, List<int> #=zErUbQv7u8Ay8A1q4e8mL5O4=, bool #=zjn8zmZ7bOcT4MVQ_bEKjq3k=, ref int #=zQgjdARD65cjQYC3fqyeFPaw=)
	{
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zoHB7AuaUwS0ptNO1CfLCyWI= #=zoHB7AuaUwS0ptNO1CfLCyWI= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zoHB7AuaUwS0ptNO1CfLCyWI=();
		#=zoHB7AuaUwS0ptNO1CfLCyWI=.#=zqA$P993_7f9soaIprQ== = (#=zU4TPzxM=.#=zvnZc$RhG_1Du() - 1) / 2 + 1;
		if (!#=zErUbQv7u8Ay8A1q4e8mL5O4=.Contains(#=zoHB7AuaUwS0ptNO1CfLCyWI=.#=zqA$P993_7f9soaIprQ==))
		{
			#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = #=zPMmTEU1PaAp0b$oySQ==.Find(new Predicate<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=>(#=zoHB7AuaUwS0ptNO1CfLCyWI=.#=zMhNJ0Oe8TdP3sScFZi03kXKXw_UX));
			if (#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= == null && this.#=zm92199OybSmIl9Uefw==.Count <= 3 && #=zPMmTEU1PaAp0b$oySQ==.Count > 0)
			{
				#=zPMmTEU1PaAp0b$oySQ==.Sort(new Comparison<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zKpf8gWzxDegS54BCSqV9yZ_PdoBR));
				#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = #=zPMmTEU1PaAp0b$oySQ==[#=zPMmTEU1PaAp0b$oySQ==.Count - 1];
			}
			if (#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= != null)
			{
				if (this.#=zDgJiXLE=(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=))
				{
					#=zErUbQv7u8Ay8A1q4e8mL5O4=.Add(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du());
					return false;
				}
				string text = this.#=zBsXSanI=.#=zrubomKMHLTWSVi5XnHCD8Lc=(#=zU4TPzxM=.#=zMuFMjGQ=(), #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zMuFMjGQ=(), #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zFMDiymuLQ7_4());
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882046), new object[]
					{
						#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
						#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du()
					});
					#=zErUbQv7u8Ay8A1q4e8mL5O4=.Add(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du());
					this.#=z2_T$I1RhbXCE(#=zU4TPzxM=);
					this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zS5BpZBs_LT3sEKeDeobrTyM=().#=z5Na$ACfA2q4HsviKqw==(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=);
					#=zQgjdARD65cjQYC3fqyeFPaw= -= 10;
					this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zgcfxUHbZmytORt2N3GObk4o=().#=zZJ6fWCM=(#=zU4TPzxM=);
				}
				else
				{
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908881993)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908881963), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du(),
							JSONManager.Cut(text)
						});
						return true;
					}
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882130)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882116), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du()
						});
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883821)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883797), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du()
						});
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883952)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883928), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du()
						});
						#=zErUbQv7u8Ay8A1q4e8mL5O4=.Add(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du());
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883578)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883564), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du()
						});
						#=zErUbQv7u8Ay8A1q4e8mL5O4=.Add(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du());
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883468)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883684), Array.Empty<object>());
						if (#=zjn8zmZ7bOcT4MVQ_bEKjq3k=)
						{
							return true;
						}
						if (!this.#=z7HJMWn$luDrY_PsTVnx85D4=(ref #=zQgjdARD65cjQYC3fqyeFPaw=))
						{
							return true;
						}
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883637), new object[]
						{
							#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zvnZc$RhG_1Du(),
							text
						});
					}
				}
			}
		}
		return false;
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x00017CC0 File Offset: 0x00015EC0
	private bool #=z7HJMWn$luDrY_PsTVnx85D4=(ref int #=zQgjdARD65cjQYC3fqyeFPaw=)
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeRefillEnergy || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeBuyEnergy)
		{
			#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[17010];
			if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883317), Array.Empty<object>());
				#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), 1);
				if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883268), Array.Empty<object>());
					#=zQgjdARD65cjQYC3fqyeFPaw= = 100;
					return true;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883215), new object[]
				{
					JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
				});
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeBuyEnergy)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883396), Array.Empty<object>());
			string text = this.#=zBsXSanI=.#=z4GJvhwZUxjZK0q17hPwA0iP5zgBd();
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883358), Array.Empty<object>());
				#=zQgjdARD65cjQYC3fqyeFPaw= = 100;
				return true;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883052), new object[]
			{
				text
			});
		}
		return false;
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00017E6C File Offset: 0x0001606C
	private void #=zJA1zmO6YC9XY()
	{
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zbNDPf$Hd8gYrHkOOd7T_3VE= #=zbNDPf$Hd8gYrHkOOd7T_3VE= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zbNDPf$Hd8gYrHkOOd7T_3VE=();
		#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zlJSAjfPMVf41 = this;
		this.#=zM4AChhv$H1IU = new Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=>();
		#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
		#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g== #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g== = new #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==();
		for (int i = 0; i < #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Count; i++)
		{
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zVIyf3uKMUPb9lnp7FtSr638= #=zVIyf3uKMUPb9lnp7FtSr638= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zVIyf3uKMUPb9lnp7FtSr638=();
			#=zVIyf3uKMUPb9lnp7FtSr638=.#=zQi6$ZU4= = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==[i];
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list = this.#=zm92199OybSmIl9Uefw==.FindAll(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zVIyf3uKMUPb9lnp7FtSr638=.#=z7kbTiK7osjpxa1BQfHfQ30A=));
			int num = this.#=z3687gj3eCey26lcJGjvksiiezE17(#=zVIyf3uKMUPb9lnp7FtSr638=.#=zQi6$ZU4=.Id);
			if (num > list.Count)
			{
				num = list.Count;
			}
			list.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zZhNwwlVgmFfP4Y5NnYg6yX8=));
			#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g== #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==2 = new #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==();
			for (int j = 0; j < num; j++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = list[j];
				this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1);
				#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==2.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==(), 5 - #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVm_gjb4pLtQN());
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z$SLcm8wly5I$())
				{
					#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR());
				}
			}
			list.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=z3ZN3eaJsdyq6M47arM0SRTs=));
			for (int k = 0; k < num; k++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM= = list[k];
				if (this.#=zbMDj$Y4=(#=zU4TPzxM=) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0)
				{
					this.#=zXCt1$q4=(#=zU4TPzxM=, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)2);
				}
			}
			list.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zeAND3kd$AVDwRoAYCuViwrc=));
			for (int l = 0; l < list.Count; l++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = list[l];
				if (this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0 && #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==2.#=zM6O9jPw=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==()) > 0 && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForJoin, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2) && (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() != 5 || #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zVm_gjb4pLtQN() <= 0))
				{
					this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10);
					#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==2.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==(), 1);
				}
			}
		}
		int num2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode ? 4 : 2;
		#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g== #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==3 = new #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==();
		int num3 = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==[0].#=zBhjHkv0$tplT().#=z$SLcm8wly5I$();
		#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= = num3 - 1;
		while (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= >= 1)
		{
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list2 = this.#=zm92199OybSmIl9Uefw==;
			Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> match;
			if ((match = #=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zR_c6jW5wZ06o) == null)
			{
				match = (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zR_c6jW5wZ06o = new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=zdoq9GX0MRqKtVhGIja1IOOI=));
			}
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list3 = list2.FindAll(match);
			if (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= == num3 - 1)
			{
				for (int m = 0; m < list3.Count; m++)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3 = list3[m];
					if (!#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=ztP$zSGbniHTJ() && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3))
					{
						this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21);
						#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=ztj93y6niVpCR(), 1);
					}
				}
			}
			else
			{
				for (int n = 0; n < list3.Count; n++)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4 = list3[n];
					if (!#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=ztP$zSGbniHTJ() && ((#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= < num2 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=zvnZc$RhG_1Du() > 1) || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4)))
					{
						this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20);
						#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=ztj93y6niVpCR(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=ztj93y6niVpCR());
					}
				}
				for (int num4 = 0; num4 < list3.Count; num4++)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$5 = list3[num4];
					if (!#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=ztP$zSGbniHTJ() && (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zVm_gjb4pLtQN() > 0 || (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= >= 4 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zaKAy47_E$9SRuF6oiw==() > 1)) && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$5))
					{
						this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21);
						#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=ztj93y6niVpCR(), 1);
					}
				}
				for (int num5 = 0; num5 < list3.Count; num5++)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6 = list3[num5];
					if (this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0 && !#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztP$zSGbniHTJ())
					{
						if (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= >= num2)
						{
							if (#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zM6O9jPw=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR()) > 0 && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6))
							{
								this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21);
								#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR(), 1);
								if (#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= >= 5 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zVm_gjb4pLtQN() == 0)
								{
									#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==3.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zFMDiymuLQ7_4() + #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zaKAy47_E$9SRuF6oiw==(), 1);
								}
							}
							else
							{
								this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20);
								#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR());
							}
						}
						else if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zvnZc$RhG_1Du() > 1)
						{
							this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20);
							#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR());
						}
						else if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR() == 1 && #=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==3.#=zM6O9jPw=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zFMDiymuLQ7_4() + #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zaKAy47_E$9SRuF6oiw==()) > 0)
						{
							this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10);
							#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==3.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zFMDiymuLQ7_4() + #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=zaKAy47_E$9SRuF6oiw==(), 1);
						}
						else if (#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zM6O9jPw=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR()) > 0)
						{
							this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)30);
							#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=zZkwn0zY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR(), 1);
						}
						else
						{
							this.#=zXCt1$q4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6, (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20);
							#=zV13nF17ddgayuxocROdDpTzU59VOE2yL7g==.#=z48rEd0A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$6.#=ztj93y6niVpCR());
						}
					}
				}
			}
			int #=z0i3iSog= = #=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog=;
			#=zbNDPf$Hd8gYrHkOOd7T_3VE=.#=z0i3iSog= = #=z0i3iSog= - 1;
		}
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00018404 File Offset: 0x00016604
	private void #=z9x0LJpfl4iQ0y96O21YzCeVwcQhpAzi$jg==()
	{
		this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw== = new List<int>();
		this.#=zRT1x$yoZiY5y4Z$sjNrd1vml12rpAACRC18t_P4= = new List<int>();
		this.#=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg== = new List<int>();
		this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A== = new List<int>();
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zVG1EPv1OUDdyLeGHGQ==;
		for (int i = 0; i < list.Count; i++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = list[i];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT() != null)
			{
				for (int j = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT().Count - 1; j >= 0; j--)
				{
					this.#=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw==.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT()[j]);
					if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0)
					{
						this.#=zRT1x$yoZiY5y4Z$sjNrd1vml12rpAACRC18t_P4=.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT()[j]);
					}
					if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)11 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1)
					{
						this.#=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A==.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_());
					}
				}
			}
		}
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x000184F8 File Offset: 0x000166F8
	private void #=zUBiHA1DLZS3V3G0r3Ghnw2c=(bool #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==)
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralSlotsNumMaxImmediateOpen)
		{
			while (this.#=zn29IPVKYXuGYsOi4mOtk3oQ= + 10 <= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsNumMax)
			{
				int num = this.#=z55EZavmmWsrJqg1HZA==();
				if (num <= 0)
				{
					break;
				}
				this.#=zn29IPVKYXuGYsOi4mOtk3oQ= += num;
			}
		}
		bool flag = false;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsBuyAndUseFragmentary)
		{
			int num2 = this.#=zCY4az9$WUjLsEJ7fgg==.#=z2cw4dd0=(29000);
			int num3 = num2;
			while (this.#=zcS6EjrRHjirK >= 10)
			{
				string text = this.#=zBsXSanI=.#=zAzdmylt$nfrth5Cvd6K20aIutKfZjV9JnbkeiV0=(1);
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883179), new object[]
					{
						text
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882999), Array.Empty<object>());
				num3++;
				this.#=zcS6EjrRHjirK -= 10;
			}
			if (num3 != num2 && this.#=zCY4az9$WUjLsEJ7fgg==[29000] == null)
			{
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=().#=zk$6QZNA=(29000);
				if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= != null)
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= value = new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=, num3);
					this.#=zCY4az9$WUjLsEJ7fgg==.Add(29000, value);
				}
			}
			int num4 = 0;
			bool flag2 = this.#=zCrK$j9y4jgJWL7tT8be7SgDf2PWM(29000, new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883133), Array.Empty<object>()), #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==, true, ref num4);
			flag = (num4 > 0 || !flag2);
		}
		bool #=zno_nfoBhQVsS = false;
		bool flag3;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeFullCycle && !flag)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode)
			{
				flag3 = false;
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[17000];
				if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
				{
					int num5 = this.#=zn29IPVKYXuGYsOi4mOtk3oQ= - this.#=zm92199OybSmIl9Uefw==.Count - this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsReserved;
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() >= num5 && num5 >= 5)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883108), Array.Empty<object>());
						flag3 = true;
						#=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw== = true;
						#=zno_nfoBhQVsS = true;
					}
				}
			}
			else
			{
				flag3 = true;
			}
		}
		else
		{
			flag3 = false;
		}
		if (flag3)
		{
			int num6 = 0;
			bool flag4 = true;
			if (flag4 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralUpgradeScrollsUsageType <= 0)
			{
				flag4 = this.#=zCrK$j9y4jgJWL7tT8be7SgDf2PWM(17002, new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884805), Array.Empty<object>()), #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==, #=zno_nfoBhQVsS, ref num6);
			}
			if (flag4 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralUpgradeScrollsUsageType <= 1)
			{
				flag4 = this.#=zCrK$j9y4jgJWL7tT8be7SgDf2PWM(17001, new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884789), Array.Empty<object>()), #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==, #=zno_nfoBhQVsS, ref num6);
			}
			if (flag4 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralUpgradeScrollsUsageType <= 2)
			{
				flag4 = this.#=zCrK$j9y4jgJWL7tT8be7SgDf2PWM(17000, new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884773), Array.Empty<object>()), #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==, #=zno_nfoBhQVsS, ref num6);
			}
		}
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x00018800 File Offset: 0x00016A00
	private bool #=zCrK$j9y4jgJWL7tT8be7SgDf2PWM(int #=zJ4eKPZD10NuQ, #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zuNbfat_EDPQg, bool #=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==, bool #=zno_nfoBhQVsS, ref int #=zYDufLO4ACoP_ah$Y8X9l0p44OyAy)
	{
		#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[#=zJ4eKPZD10NuQ];
		int num = this.#=zn29IPVKYXuGYsOi4mOtk3oQ= - this.#=zm92199OybSmIl9Uefw==.Count - #=zYDufLO4ACoP_ah$Y8X9l0p44OyAy - this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsReserved;
		bool flag = false;
		if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
		{
			int num2 = (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() >= 10 && num >= 10) ? 10 : 1;
			#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zC7NDbDM= = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
			while (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0)
			{
				if ((num2 > 1 && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() < num2) || num < num2)
				{
					num2 = 1;
				}
				bool flag2 = num >= num2;
				if (flag2)
				{
					#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), num2);
					if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 10000)
					{
						StringBuilder stringBuilder = new StringBuilder();
						object data = JSONManager.GetData(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC());
						object[] array = JSONManager.GetArray(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884746));
						if (array == null)
						{
							Dictionary<string, object> dictionary = JSONManager.GetDictionary(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884742));
							if (dictionary != null)
							{
								array = new object[]
								{
									dictionary
								};
							}
						}
						if (array != null)
						{
							for (int i = 0; i < array.Length; i++)
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = new #=zrDcgv9ny10MzDWIXXLpHLoin_0n$((Dictionary<string, object>)array[i], #=zC7NDbDM=, #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zLhrZP_oyOsqr());
								if (stringBuilder.Length > 0)
								{
									stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
								}
								stringBuilder.Append(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF());
							}
						}
						if (num2 > 1)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884978), new object[]
							{
								#=zuNbfat_EDPQg,
								stringBuilder,
								num2
							});
						}
						else if (stringBuilder.Length > 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884933), new object[]
							{
								#=zuNbfat_EDPQg,
								stringBuilder
							});
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884874), new object[]
							{
								#=zuNbfat_EDPQg
							});
						}
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() - num2);
						#=zYDufLO4ACoP_ah$Y8X9l0p44OyAy += num2;
						num -= num2;
					}
					else if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884581)))
					{
						flag2 = false;
					}
					else
					{
						if (!#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884548)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884690), new object[]
							{
								JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
							});
							return true;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884496), Array.Empty<object>());
						num2 = 1;
					}
				}
				if (!flag2)
				{
					if (num2 > 1)
					{
						num2 = 1;
					}
					else
					{
						if (#=zno_nfoBhQVsS)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884661), Array.Empty<object>());
							return false;
						}
						if (!#=zUsscHvNJNb5_B3cMUiC3eNsGTKcC9Xq3tw==)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884611), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zHY7OBLKxXqKK()
							});
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode = true;
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
							this.#=zJA1zmO6YC9XY();
							return false;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884296), new object[]
						{
							this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsNumMax,
							this.#=zm92199OybSmIl9Uefw==.Count,
							#=zYDufLO4ACoP_ah$Y8X9l0p44OyAy,
							this.#=zn29IPVKYXuGYsOi4mOtk3oQ=
						});
						if (flag)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884386), Array.Empty<object>());
							return false;
						}
						if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsNumMax <= 0 || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSlotsNumMax >= this.#=zm92199OybSmIl9Uefw==.Count + #=zYDufLO4ACoP_ah$Y8X9l0p44OyAy + 10)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884067), Array.Empty<object>());
							flag = true;
							int num3 = this.#=z55EZavmmWsrJqg1HZA==();
							if (num3 <= 0)
							{
								return false;
							}
							num += num3;
						}
						else
						{
							if (#=zYDufLO4ACoP_ah$Y8X9l0p44OyAy > 0)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884027), new object[]
								{
									#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zHY7OBLKxXqKK()
								});
								this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode = true;
								this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
								this.#=zJA1zmO6YC9XY();
								return false;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883972), Array.Empty<object>());
							return false;
						}
					}
				}
			}
		}
		return true;
	}

	// Token: 0x060002DA RID: 730 RVA: 0x00018CEC File Offset: 0x00016EEC
	private int #=z55EZavmmWsrJqg1HZA==()
	{
		string text = this.#=zBsXSanI=.#=zkgEmpmeJHa1b2dv2Uw==();
		if (text.Length > 10000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884144), Array.Empty<object>());
			return 10;
		}
		if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909032084)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908884100), Array.Empty<object>());
			return 0;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885799), new object[]
		{
			text
		});
		return 0;
	}

	// Token: 0x060002DB RID: 731 RVA: 0x00018DA0 File Offset: 0x00016FA0
	private void #=zMS$$UTrXW0NA()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeFullCycle)
		{
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
			for (int i = 0; i < this.#=zm92199OybSmIl9Uefw==.Count; i++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zm92199OybSmIl9Uefw==[i];
				#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zY9gFTlM= = this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
				if ((#=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)3 || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)20) && (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z$SLcm8wly5I$() - 1 || !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUpgradeToMaxRank, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$)) && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUpgradeRank, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$) && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z$SLcm8wly5I$() && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zYS6NXcO7DUmh() && !this.#=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
				{
					list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
				}
			}
			list.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(this.#=zWno7CqHs1cgJ2vls3ZaVzHRxDFy8));
			bool flag = false;
			for (int j = 0; j < list.Count; j++)
			{
				#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zB1S9ASeEJWvz86OjP9N7sh4= #=zB1S9ASeEJWvz86OjP9N7sh4= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zB1S9ASeEJWvz86OjP9N7sh4=();
				#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zlJSAjfPMVf41 = this;
				#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM= = list[j];
				if (!this.#=zDgJiXLE=(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=))
				{
					int num = #=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=ztj93y6niVpCR();
					List<#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns=> list2 = this.#=zlhbZ30IOYw$h$EOR3Q==.FindAll(new Predicate<#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns=>(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zYWwBOvFGnm6EAag$vLDky78=));
					if (list2.Count > num)
					{
						list2.RemoveRange(num, list2.Count - num);
					}
					num -= list2.Count;
					List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list3 = this.#=zm92199OybSmIl9Uefw==.FindAll(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zuUrixzVtj0X3ZPmAz5ez1c4=));
					list3.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zGMMDQaseeeFN55oab99pwxS0ZzlT));
					if (list3.Count > num)
					{
						list3.RemoveRange(num, list3.Count - num);
					}
					if (list3.Count == num)
					{
						object[] array = new object[list3.Count];
						object[] array2 = new object[list2.Count];
						StringBuilder stringBuilder = new StringBuilder();
						for (int k = 0; k < list3.Count; k++)
						{
							array[k] = list3[k].#=zMuFMjGQ=();
							if (k > 0)
							{
								stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
							}
							stringBuilder.Append(list3[k].#=zTbtwDpWhYGtF());
						}
						for (int l = 0; l < list2.Count; l++)
						{
							array2[l] = list2[l].#=zMuFMjGQ=();
							if (l > 0 || list3.Count > 0)
							{
								stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
							}
							stringBuilder.Append(list2[l].#=zTbtwDpWhYGtF());
						}
						string text = this.#=zBsXSanI=.#=zvAuYc1qDKy78zWIQjw==(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zMuFMjGQ=(), array, array2);
						if (text.Length > 10000)
						{
							#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zN8K4D6MLtfWt();
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							flag = true;
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908886015), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zh3RXM2eC0gtG(),
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==(),
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=ztj93y6niVpCR(),
								stringBuilder
							});
							for (int m = 0; m < list3.Count; m++)
							{
								this.#=z2_T$I1RhbXCE(list3[m]);
							}
							for (int n = 0; n < list2.Count; n++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[n]);
							}
						}
						else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882130)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885914), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885572), new object[]
							{
								stringBuilder
							});
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							for (int num2 = 0; num2 < list3.Count; num2++)
							{
								this.#=z2_T$I1RhbXCE(list3[num2]);
							}
							for (int num3 = 0; num3 < list2.Count; num3++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[num3]);
							}
						}
						else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883821)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885531), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885572), new object[]
							{
								stringBuilder
							});
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							for (int num4 = 0; num4 < list3.Count; num4++)
							{
								this.#=z2_T$I1RhbXCE(list3[num4]);
							}
							for (int num5 = 0; num5 < list2.Count; num5++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[num5]);
							}
						}
						else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885707)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885683), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885572), new object[]
							{
								stringBuilder
							});
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							for (int num6 = 0; num6 < list3.Count; num6++)
							{
								this.#=z2_T$I1RhbXCE(list3[num6]);
							}
							for (int num7 = 0; num7 < list2.Count; num7++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[num7]);
							}
						}
						else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885332)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885310), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885572), new object[]
							{
								stringBuilder
							});
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							for (int num8 = 0; num8 < list3.Count; num8++)
							{
								this.#=z2_T$I1RhbXCE(list3[num8]);
							}
							for (int num9 = 0; num9 < list2.Count; num9++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[num9]);
							}
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885468), new object[]
							{
								#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
								text
							});
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885572), new object[]
							{
								stringBuilder
							});
							this.#=z2_T$I1RhbXCE(#=zB1S9ASeEJWvz86OjP9N7sh4=.#=zU4TPzxM=);
							for (int num10 = 0; num10 < list3.Count; num10++)
							{
								this.#=z2_T$I1RhbXCE(list3[num10]);
							}
							for (int num11 = 0; num11 < list2.Count; num11++)
							{
								this.#=zM5vpWhdth4THSACoR3QyHJk=(list2[num11]);
							}
						}
					}
				}
			}
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode && !flag)
			{
				bool flag2 = false;
				for (int num12 = 0; num12 < this.#=zm92199OybSmIl9Uefw==.Count; num12++)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = this.#=zm92199OybSmIl9Uefw==[num12];
					if (this.#=zPvPV29uCs8GIVUNPYd1$9jI=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885410), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF()
						});
						flag2 = true;
						break;
					}
				}
				if (!flag2)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885080), new object[]
					{
						#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z0fiI0Hu3rK3y()
					});
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsUpgradeCompressingMode = false;
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
					this.#=zJA1zmO6YC9XY();
					this.#=zMS$$UTrXW0NA();
					this.#=zUBiHA1DLZS3V3G0r3Ghnw2c=(true);
				}
			}
		}
	}

	// Token: 0x060002DC RID: 732 RVA: 0x0001963C File Offset: 0x0001783C
	private void #=z4B66sSIz3BT8()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoGeneralsUpgradeFullCycle)
		{
			for (int i = 0; i < this.#=zm92199OybSmIl9Uefw==.Count; i++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zm92199OybSmIl9Uefw==[i];
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=ztj93y6niVpCR() >= 5 && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zYS6NXcO7DUmh() && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVm_gjb4pLtQN() == 0 && this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21 && !this.#=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
				{
					this.#=zhBpEP4zA$SM5(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
				}
			}
		}
	}

	// Token: 0x060002DD RID: 733 RVA: 0x000196B4 File Offset: 0x000178B4
	private bool #=zhBpEP4zA$SM5(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		bool result = false;
		#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = null;
		for (int i = this.#=zm92199OybSmIl9Uefw==.Count - 1; i >= 0; i--)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = this.#=zm92199OybSmIl9Uefw==[i];
			if (this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10 && !this.#=zj_RULOkSJy6BjegQMw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2) && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zFMDiymuLQ7_4() == #=zU4TPzxM=.#=zFMDiymuLQ7_4() && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() == #=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==() && !#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=ztP$zSGbniHTJ())
			{
				if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForJoin, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2))
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2;
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885014), new object[]
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF()
				});
			}
		}
		if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null)
		{
			string text = this.#=zBsXSanI=.#=z8svVNUU2uXef(#=zU4TPzxM=.#=zMuFMjGQ=(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885171), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF()
				});
				this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
				result = true;
			}
			else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882130)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870499), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					JSONManager.Cut(text)
				});
				this.#=z2_T$I1RhbXCE(#=zU4TPzxM=);
				this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			}
			else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883821)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870430), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					JSONManager.Cut(text)
				});
				this.#=z2_T$I1RhbXCE(#=zU4TPzxM=);
				this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			}
			else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885707)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870615), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					JSONManager.Cut(text)
				});
				this.#=z2_T$I1RhbXCE(#=zU4TPzxM=);
				this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			}
			else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885332)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870533), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					JSONManager.Cut(text)
				});
				this.#=z2_T$I1RhbXCE(#=zU4TPzxM=);
				this.#=z2_T$I1RhbXCE(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870196), new object[]
				{
					#=zU4TPzxM=.#=zTbtwDpWhYGtF(),
					JSONManager.Cut(text)
				});
			}
		}
		return result;
	}

	// Token: 0x060002DE RID: 734 RVA: 0x00019994 File Offset: 0x00017B94
	private void #=zWppZPDMMEapK67$UYdFi4q0=()
	{
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zMZQEcIQQyctgBOxH$ex9QdE= #=zMZQEcIQQyctgBOxH$ex9QdE= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zMZQEcIQQyctgBOxH$ex9QdE=();
		#=zMZQEcIQQyctgBOxH$ex9QdE=.#=zlJSAjfPMVf41 = this;
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsActivateInCity)
		{
			return;
		}
		List<List<int>> list = GameApplicationData.#=zhQhOis4l117BYDWAjw==();
		#=zMZQEcIQQyctgBOxH$ex9QdE=.#=zSNPnJbDunfxk = this.#=zJuJOGd$r9zprxxNhlVfqNto=;
		int num = -1;
		for (int i = 0; i < list.Count; i++)
		{
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zYyVzn7vuC8wOyX6RmBckS2Q= #=zYyVzn7vuC8wOyX6RmBckS2Q= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zYyVzn7vuC8wOyX6RmBckS2Q=();
			#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg= = #=zMZQEcIQQyctgBOxH$ex9QdE=;
			List<int> list2 = list[i];
			#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zC7NDbDM= = new List<int>();
			for (int j = 0; j < list2.Count; j++)
			{
				if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsInCityDontActivate.Contains(list2[j]))
				{
					#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zC7NDbDM=.Add(list2[j]);
				}
			}
			#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zW5FyGUI= = 0;
			foreach (int num2 in #=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zC7NDbDM=)
			{
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsInCityPreferred.Contains(num2))
				{
					#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zW5FyGUI= = num2;
					break;
				}
			}
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list3 = this.#=zm92199OybSmIl9Uefw==.FindAll(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zN1r_geHfRQ_r7AHPI111Ss03kcQIHNZNqw==));
			list3.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=z65HlBNJ16JhFRIiV$uW6E9RngO3xxE1Nbg==));
			if (list3.Count > 0)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = list3[0];
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = this.#=zm92199OybSmIl9Uefw==.Find(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zYcgY5b3tl908T6lstt8B$YCUuwKVYdzeNQ==));
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 == null || (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=() != #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=() && (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zFMDiymuLQ7_4().Equals(#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zW5FyGUI=) != #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4().Equals(#=zYyVzn7vuC8wOyX6RmBckS2Q=.#=zW5FyGUI=) || #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zIttox1M=() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=() - 0.0001)))
				{
					string text = this.#=zBsXSanI=.#=zs2E35D6TWS3QWmfmVA==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2);
					if (text.Length > 10000)
					{
						if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 != null)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870150), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF()
							});
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870347), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF()
						});
						num = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zv4c9O3M=();
					}
					else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908885332)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870298), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(),
							JSONManager.Cut(text)
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869965), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(),
							JSONManager.Cut(text)
						});
					}
				}
			}
		}
		if (num > 0)
		{
			string text2 = this.#=zBsXSanI=.#=zFdQTSOSm7vkNJwHo$g==(num);
			if (text2.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869910), new object[]
				{
					num
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870095), new object[]
			{
				num,
				JSONManager.Cut(text2)
			});
		}
	}

	// Token: 0x060002DF RID: 735 RVA: 0x00019D20 File Offset: 0x00017F20
	private void #=zz22eei$X86rOSc_Pnw==()
	{
		try
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869744), Array.Empty<object>());
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
			foreach (GeneralActionRule generalActionRule in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.FindAll(new Predicate<GeneralActionRule>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zOhmjcqgOm$N$_yrcN4uGYNsq5kHJ)))
			{
				foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ in this.#=zm92199OybSmIl9Uefw==)
				{
					if (this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1 && !this.#=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) && generalActionRule.#=zQLl7KKs=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVm_gjb4pLtQN() < 5 && !list.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
					{
						list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
					}
				}
			}
			foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 in list)
			{
				int num = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zVm_gjb4pLtQN();
				while (num < 5 && this.#=zhBpEP4zA$SM5(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2))
				{
					num++;
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
		}
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x00019EE8 File Offset: 0x000180E8
	private void #=zXeuUS5od9ixgZ12trePxOLM=()
	{
		try
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869692), Array.Empty<object>());
			List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
			foreach (GeneralActionRule generalActionRule in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.FindAll(new Predicate<GeneralActionRule>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=z$ZIjlgFNtNHLeKVgorghPZIrrfmSFpGajA==)))
			{
				foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ in this.#=zm92199OybSmIl9Uefw==)
				{
					if (this.#=zbMDj$Y4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1 && !this.#=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) && generalActionRule.#=zQLl7KKs=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$) && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zXt1d$7x_ycgZ1FjORA==() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zw1MB4Q248t5N2yPQ6NrVzAs=() && !list.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
					{
						list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
					}
				}
			}
			foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 in list)
			{
				int num = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() - 1 + 17003;
				int num2 = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zw1MB4Q248t5N2yPQ6NrVzAs=() - #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zXt1d$7x_ycgZ1FjORA==();
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[num];
				if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0)
				{
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() < num2)
					{
						num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
					}
					string text = this.#=zBsXSanI=.#=zE5VuNRZp3jma7rvkFkPylqamaD1D(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=(), num, num2);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869879), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF(),
							num2
						});
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() - num2);
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869829), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zTbtwDpWhYGtF(),
							num2,
							JSONManager.Cut(text)
						});
					}
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
		}
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x0001A1A0 File Offset: 0x000183A0
	private void #=z01svGUf_$gU0uF_sG9_mbU8=()
	{
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck = DateTime.Now + TimeSpan.FromMinutes(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerCheckPeriod);
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908869767), new object[]
		{
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck
		});
		object data = JSONManager.GetData(this.#=zBsXSanI=.#=z88KXN9YQlR89lG4bcw==(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==().ToString(), this.#=z8StzeqE=.#=zjV_wsuvJ0R_B()));
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871448));
		if (dictionary == null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871447), Array.Empty<object>());
			return;
		}
		bool flag = false;
		if (JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871647) + this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069695), 0) == 0)
		{
			int @int = JSONManager.GetInt(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871626), 0);
			string text = this.#=zBsXSanI=.#=zDXci15F7pdyeXydMqENhPDY=(@int);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871621), Array.Empty<object>());
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871573), new object[]
				{
					JSONManager.Cut(text)
				});
			}
			int int2 = JSONManager.GetInt(data, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871258), 0);
			string text2 = this.#=zBsXSanI=.#=zH4JeD1tMoszPBpV$jAOs758=(int2, this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zxWJWBWxyVjKWhkQ0ywNvzKs=());
			if (text2.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871248)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871226), Array.Empty<object>());
			}
			else if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871179)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871406), Array.Empty<object>());
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871359), new object[]
				{
					JSONManager.Cut(text2)
				});
				flag = true;
			}
		}
		Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094));
		if (dictionary2 == null)
		{
			if (flag)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871038), new object[]
				{
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck
				});
				return;
			}
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck = JSONManager.GetDateTime(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), false, DateTime.Now + TimeSpan.FromDays(1.0));
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870963), new object[]
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerNextCheck
			});
			return;
		}
		else
		{
			int num = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)]);
			int num2 = (num - 1) / 20 + 1;
			if (num2 > 5)
			{
				num2 = 5;
			}
			bool flag2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsTowerIgnoreRarity && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=z8StzeqE=);
			double totalDays = (JSONManager.DecodeTime(Convert.ToString(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)]), false) - DateTime.Now).TotalDays;
			List<int> list = new List<int>();
			List<int> list2 = new List<int>();
			int num3 = 0;
			object[] array = JSONManager.GetArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871149) + this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=().ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871130));
			if (array != null)
			{
				foreach (Dictionary<string, object> dictionary3 in array)
				{
					int num4 = Convert.ToInt32(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)]);
					if (Convert.ToInt32(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]) >= num4)
					{
						int item = Convert.ToInt32(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]);
						if (num4 > 1 || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockMinRarity > 5)
						{
							list.Add(item);
						}
						else
						{
							list2.Add(item);
						}
					}
					if (num4 > 1)
					{
						num3 += num4 - 1;
					}
				}
			}
			#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
			if (list.Count == #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Count)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871123), Array.Empty<object>());
				return;
			}
			Dictionary<int, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$> dictionary4 = new Dictionary<int, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
			foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ in this.#=zm92199OybSmIl9Uefw==)
			{
				if (!list.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4()) && (!(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zSuFpIqmi3qUZ() != DateTime.MinValue) || !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsGeneralsTowerDontSentTimer) && !this.#=zpBYA1bhTG_f_(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$))
				{
					if (!dictionary4.ContainsKey(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4()))
					{
						dictionary4.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4(), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
					}
					else
					{
						#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = dictionary4[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4()];
						if (flag2)
						{
							if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zvnZc$RhG_1Du() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du() || (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==() && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zvnZc$RhG_1Du() == #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du()))
							{
								dictionary4[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4()] = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$;
							}
						}
						else if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==() || (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zaKAy47_E$9SRuF6oiw==() == #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zaKAy47_E$9SRuF6oiw==() && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zvnZc$RhG_1Du() < #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zvnZc$RhG_1Du()))
						{
							dictionary4[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zFMDiymuLQ7_4()] = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$;
						}
					}
				}
			}
			for (int j = list2.Count - 1; j >= 0; j--)
			{
				int key = list2[j];
				if (dictionary4.ContainsKey(key))
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3 = dictionary4[key];
					if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zaKAy47_E$9SRuF6oiw==() >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockMinRarity && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zM_w3ufFbc_RdRFaz$9jXTgI=() >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockMinStrength && (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zaKAy47_E$9SRuF6oiw==() >= num2 || flag2) && (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockMax <= 0 || num3 < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockMax))
					{
						if (this.#=zyIZM7WyuUPAGsGI1VA==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3, ref num3))
						{
							list2.RemoveAt(j);
						}
						else
						{
							dictionary4.Remove(key);
						}
					}
					else
					{
						dictionary4.Remove(key);
					}
				}
			}
			StringBuilder stringBuilder = new StringBuilder();
			#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU = new #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU();
			foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4 in dictionary4.Values)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4);
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=zaKAy47_E$9SRuF6oiw==() == num2 || flag2)
				{
					#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4);
				}
				else if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=zaKAy47_E$9SRuF6oiw==() > num2)
				{
					double num5;
					switch (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=zaKAy47_E$9SRuF6oiw==())
					{
					case 2:
						num5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerStartRarity2;
						break;
					case 3:
						num5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerStartRarity3;
						break;
					case 4:
						num5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerStartRarity4;
						break;
					case 5:
						num5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerStartRarity5;
						break;
					default:
						num5 = 30.0;
						break;
					}
					if (num5 >= totalDays)
					{
						#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4);
					}
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871077), new object[]
			{
				totalDays,
				num2,
				stringBuilder
			});
			if (#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Count > 0)
			{
				#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zZxNyxBfaGmUoIXY$DRRXNBPSVhE1mCNpzg==));
				#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= = new #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=((object[])dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)]);
				#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Sort(new Comparison<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=z5coTMgA_xV3IfvO13KPAkDTtZ5uZ2iKGRQ==));
				int num6 = 0;
				for (int k = 0; k < #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Count; k++)
				{
					if (#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Count == 0)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870691), Array.Empty<object>());
						return;
					}
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$5 = #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU[k];
					if (this.#=zDgJiXLE=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870668), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
							num
						});
					}
					else
					{
						#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = null;
						for (int l = #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Count - 1; l >= 0; l--)
						{
							if (#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=[l].#=z8Nl16CPh9dN5() <= #=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zM_w3ufFbc_RdRFaz$9jXTgI=())
							{
								#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=[l];
								break;
							}
						}
						if (#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= == null)
						{
							for (int m = #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Count - 1; m >= 0; m--)
							{
								if ((double)#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=[m].#=z8Nl16CPh9dN5() <= (double)#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zM_w3ufFbc_RdRFaz$9jXTgI=() * 1.5)
								{
									#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=[m];
									break;
								}
							}
						}
						if (#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= == null)
						{
							#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= = #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=[#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Count - 1];
						}
						string text3 = this.#=zBsXSanI=.#=zz76ciiSOrlyTX_GJslAUF2WRi$Rh(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zMuFMjGQ=(), #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=.#=zMuFMjGQ=());
						if (text3.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870830), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
								num
							});
							#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Remove(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=);
							num6++;
							if (num6 >= 1)
							{
								return;
							}
						}
						else if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882130)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908870668), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
								num
							});
						}
						else if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883821)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872563), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
								num
							});
						}
						else if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883578)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872467), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
								num
							});
							#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=.Remove(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=);
						}
						else if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908883468)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872631), Array.Empty<object>());
							int num7 = this.#=zJxfgWpOiQEkVffms$_L1sXM=;
							if (!this.#=z7HJMWn$luDrY_PsTVnx85D4=(ref num7))
							{
								return;
							}
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872316), new object[]
							{
								#=zrDcgv9ny10MzDWIXXLpHLoin_0n$5.#=zTbtwDpWhYGtF(),
								num,
								text3
							});
						}
					}
				}
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872241), Array.Empty<object>());
			return;
		}
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x0001AE28 File Offset: 0x00019028
	private bool #=zyIZM7WyuUPAGsGI1VA==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, ref int #=z2AYXxxYb3GgHwE9te4iPFZ8=)
	{
		#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[17100];
		int num = 0;
		#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872202), Array.Empty<object>());
		bool flag = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0;
		if (#=z2AYXxxYb3GgHwE9te4iPFZ8= >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockUseItemAfter && flag)
		{
			num = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zMuFMjGQ=();
			#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872447), new object[]
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=()
			});
		}
		string text = this.#=zBsXSanI=.#=zFzgnyFG5jZhbZNE1nHNAXh0=(#=zU4TPzxM=.#=zFMDiymuLQ7_4(), num);
		if (text.Length > 1000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872410), new object[]
			{
				#=zU4TPzxM=.#=zh3RXM2eC0gtG(),
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==
			});
			#=z2AYXxxYb3GgHwE9te4iPFZ8=++;
			if (flag)
			{
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
				int num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_();
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(num2 - 1);
			}
			return true;
		}
		if (text.ToLower().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872376)) && num == 0 && flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872361), new object[]
			{
				#=zU4TPzxM=.#=zh3RXM2eC0gtG(),
				#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==,
				#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=()
			});
			#=z2AYXxxYb3GgHwE9te4iPFZ8= = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralsTowerUnlockUseItemAfter;
			return this.#=zyIZM7WyuUPAGsGI1VA==(#=zU4TPzxM=, ref #=z2AYXxxYb3GgHwE9te4iPFZ8=);
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872023), new object[]
		{
			#=zU4TPzxM=.#=zh3RXM2eC0gtG(),
			#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==,
			JSONManager.Cut(text)
		});
		return false;
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x0001AFE8 File Offset: 0x000191E8
	private void #=zHnqt7Q2SvpE77_mIJNjEk7E=()
	{
		#=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= = this.#=z1L5EVM5jSO3xd$DrZn2dfAI=;
		List<int> list = new List<int>();
		for (int i = 0; i < #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=.Count; i++)
		{
			#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g== #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g== = #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=[i];
			if (#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=z9ZHUN$Y=() == (#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM=)1)
			{
				List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list2 = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
				int count = #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=z6Uo9D2yKen_Y().Count;
				List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=> list3 = new List<#=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM=>();
				list3.AddRange(#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=z6Uo9D2yKen_Y());
				for (int j = this.#=zm92199OybSmIl9Uefw==.Count - 1; j >= 0; j--)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zm92199OybSmIl9Uefw==[j];
					if (!list.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
					{
						bool flag = false;
						for (int k = list3.Count - 1; k >= 0; k--)
						{
							if (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zOxiB3lzOFQkspyYXMkXOvTs=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$, list3[k]))
							{
								if (#=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=.#=zMVECo3Lv7Wwz(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
								{
									list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
									break;
								}
								flag = true;
								list3.RemoveAt(k);
							}
						}
						if (flag)
						{
							list2.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
							if (list2.Count >= count || list3.Count == 0)
							{
								break;
							}
						}
					}
				}
				if (list2.Count < count && list3.Count == 0)
				{
					for (int l = this.#=zm92199OybSmIl9Uefw==.Count - 1; l >= 0; l--)
					{
						#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = this.#=zm92199OybSmIl9Uefw==[l];
						if (list.Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=()))
						{
							if (#=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=.#=zMVECo3Lv7Wwz(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=()))
							{
								list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zMuFMjGQ=());
								break;
							}
							list2.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2);
							if (list2.Count >= count)
							{
								break;
							}
						}
					}
				}
				if (list2.Count == count && list3.Count == 0)
				{
					List<int> list4 = new List<int>();
					StringBuilder stringBuilder = new StringBuilder();
					for (int m = 0; m < list2.Count; m++)
					{
						#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$3 = list2[m];
						list4.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zMuFMjGQ=());
						if (stringBuilder.Length > 0)
						{
							stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
						}
						stringBuilder.Append(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$3.#=zTbtwDpWhYGtF());
					}
					string text = this.#=zBsXSanI=.#=zWiOs0kkTWW95mMbc8JNhN1o2lvNPcO5jjA==(#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zMuFMjGQ=(), list4);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871974), new object[]
						{
							#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=ztj93y6niVpCR(),
							#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zl9Bdc6w=(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=()),
							stringBuilder
						});
						for (int n = 0; n < list2.Count; n++)
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$4 = list2[n];
							list.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$4.#=zMuFMjGQ=());
						}
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908872138), new object[]
						{
							#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=ztj93y6niVpCR(),
							#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zl9Bdc6w=(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=()),
							stringBuilder,
							JSONManager.Cut(text)
						});
					}
				}
			}
			else if (#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=z9ZHUN$Y=() == (#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zY9gFTlM=)4)
			{
				string text2 = this.#=zBsXSanI=.#=zcwlPp9PZeHF6Y7rAf9X9a538lI31awXBcA==(#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=zMuFMjGQ=());
				if (text2.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871793), new object[]
					{
						#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=ztj93y6niVpCR()
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871723), new object[]
					{
						#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==.#=ztj93y6niVpCR(),
						JSONManager.Cut(text2)
					});
				}
			}
		}
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x0001B39C File Offset: 0x0001959C
	private static bool #=zOxiB3lzOFQkspyYXMkXOvTs=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=, #=zrouQvl0J7WVEWtKaTYewqgLTYe_dtJPTBA1CxE$8KYT1pS6OoNo4XiM= #=zStwl$p8=)
	{
		return #=zU4TPzxM=.#=ztj93y6niVpCR() >= #=zStwl$p8=.#=z4zXcBHTOAiAX() && #=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==() >= #=zStwl$p8=.#=z6Dr4DsOt5CbKnBxwYg==() && (#=zStwl$p8=.#=zFMDiymuLQ7_4() <= 0 || #=zU4TPzxM=.#=zFMDiymuLQ7_4() == #=zStwl$p8=.#=zFMDiymuLQ7_4());
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x0001B3D8 File Offset: 0x000195D8
	private static bool #=zekU8dWv_Vlc3PL2OB4V85kksA7By(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoWorldBossTournment && #=z8StzeqE=.#=zHk2CSHOH76iz().#=zZYedJFIIpwzNXWMrtGBOC2I=() != null && #=z8StzeqE=.#=zHk2CSHOH76iz().#=zZYedJFIIpwzNXWMrtGBOC2I=().Count != 0;
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x0001B410 File Offset: 0x00019610
	private bool #=zv63Ga0Rf9HluVcTAB6ZCt24HJ2p_()
	{
		if (!#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zekU8dWv_Vlc3PL2OB4V85kksA7By(this.#=z8StzeqE=))
		{
			return false;
		}
		#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= = this.#=z8StzeqE=.#=zHk2CSHOH76iz().#=zZYedJFIIpwzNXWMrtGBOC2I=().#=zSwuC41Ya81kR();
		if (#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= == null)
		{
			return false;
		}
		int num = this.#=z8StzeqE=.#=zHk2CSHOH76iz().#=zZYedJFIIpwzNXWMrtGBOC2I=().#=zU8Ih$XGWPaBB6guu3uHs3e0wKKyh();
		long num2 = -1L;
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = this.#=zeYLQo2n2g2lR;
		for (int i = 0; i < list.Count; i++)
		{
			#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== = list[i];
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zd$BbM3Y=() == num)
			{
				num2 = #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zKa2XiiZl7goe();
				break;
			}
		}
		if (num2 < 0L)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871900), Array.Empty<object>());
			return false;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908871808), new object[]
		{
			num2 / 1000000L,
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WorldBossTournmentTargetScore
		});
		if (num2 > (long)this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WorldBossTournmentTargetScore * 1000000L)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873502), Array.Empty<object>());
			return false;
		}
		#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zVDnFwifPDatT21IqSw==(#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zv4c9O3M=());
		#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zmEXh9AenN64_bRhjgQ==();
		List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list2 = this.#=z2A$p0y8DkB6TW7Eq$A==(#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=);
		if (list2.Count == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873678), Array.Empty<object>());
			return false;
		}
		List<int> list3 = new List<int>();
		StringBuilder stringBuilder = new StringBuilder();
		for (int j = 0; j < list2.Count; j++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = list2[j];
			list3.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
			if (j > 0)
			{
				stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
			}
			stringBuilder.Append(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF());
		}
		double num3;
		int num4;
		double num5;
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zQ_BGiNBo1_lviGFGyDoR$YY=(list2, #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=, out num3, out num4, out num5);
		int num6 = (int)((double)((long)this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WorldBossTournmentTargetScore * 1000000L - num2) / num3);
		if (num6 > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WorldBossTournmentAttempts)
		{
			num6 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WorldBossTournmentAttempts;
		}
		if (num6 < 1)
		{
			num6 = 1;
		}
		int num7 = this.#=zJxfgWpOiQEkVffms$_L1sXM=;
		bool result = false;
		for (int k = 0; k < num6; k++)
		{
			if (k > 0)
			{
				Thread.Sleep(30000);
			}
			if (num7 < 100 && !this.#=z7HJMWn$luDrY_PsTVnx85D4=(ref num7))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873614), Array.Empty<object>());
				return true;
			}
			string text = this.#=zBsXSanI=.#=zEcPV97n7bWfJ8XLR7uS8FwMBcFho(list3);
			if (text.Length <= 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873458), new object[]
				{
					stringBuilder,
					JSONManager.Cut(text)
				});
				break;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873311), new object[]
			{
				stringBuilder,
				(int)num3,
				num4
			});
			num7 = 0;
			result = true;
		}
		return result;
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x0001B764 File Offset: 0x00019964
	private List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=z2A$p0y8DkB6TW7Eq$A==(#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z0smlvCiQcuhV)
	{
		#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zVA5DTxsop0DII4nixnWcIFQ= #=zVA5DTxsop0DII4nixnWcIFQ= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zVA5DTxsop0DII4nixnWcIFQ=();
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=zlJSAjfPMVf41 = this;
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=z0smlvCiQcuhV = #=z0smlvCiQcuhV;
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=zSc8VHuH3XAKZ = 4;
		#=zVA5DTxsop0DII4nixnWcIFQ=.#=zqtUdKaNfGEErCKScKK2OlT8= = this.#=zJuJOGd$r9zprxxNhlVfqNto=;
		List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list = this.#=zm92199OybSmIl9Uefw==.FindAll(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zVA5DTxsop0DII4nixnWcIFQ=.#=zjN5$GnbIPU7KQtciU5hUGTc=));
		if (list.Count < #=zVA5DTxsop0DII4nixnWcIFQ=.#=zSc8VHuH3XAKZ)
		{
			return new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
		}
		List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list2 = list.FindAll(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zJxeAhDGxMF12xFoy88RVUqC7UV_3));
		#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$;
		if (list2.Count > 0)
		{
			list2.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=.#=zLkw0NRU=.#=zJXOxOsCsssYNV8ahrMg29_MimZd7));
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = list2[0];
		}
		else
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = null;
		}
		list.Sort(new Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zVA5DTxsop0DII4nixnWcIFQ=.#=zB$fiJQwbqCdODybn_SIClmg=));
		List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list3 = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
		for (int i = 0; i < #=zVA5DTxsop0DII4nixnWcIFQ=.#=zSc8VHuH3XAKZ; i++)
		{
			list3.Add(list[i]);
		}
		List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> list4 = new List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>();
		if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null)
		{
			list4.Add(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			list.Remove(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$);
			#=zVA5DTxsop0DII4nixnWcIFQ=.#=zSc8VHuH3XAKZ--;
			for (int j = 0; j < #=zVA5DTxsop0DII4nixnWcIFQ=.#=zSc8VHuH3XAKZ; j++)
			{
				list4.Add(list[j]);
			}
		}
		double num = #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zQ_BGiNBo1_lviGFGyDoR$YY=(list3, #=zVA5DTxsop0DII4nixnWcIFQ=.#=z0smlvCiQcuhV);
		double num2 = #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zQ_BGiNBo1_lviGFGyDoR$YY=(list4, #=zVA5DTxsop0DII4nixnWcIFQ=.#=z0smlvCiQcuhV);
		if (num <= num2)
		{
			return list4;
		}
		return list3;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x0001B8D4 File Offset: 0x00019AD4
	private static double #=zQ_BGiNBo1_lviGFGyDoR$YY=(List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zCIRVQzI=, #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z0smlvCiQcuhV)
	{
		double num;
		int num2;
		double num3;
		return #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zQ_BGiNBo1_lviGFGyDoR$YY=(#=zCIRVQzI=, #=z0smlvCiQcuhV, out num, out num2, out num3);
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x0001B8F0 File Offset: 0x00019AF0
	private static double #=zQ_BGiNBo1_lviGFGyDoR$YY=(List<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zCIRVQzI=, #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z0smlvCiQcuhV, out double #=zr1O3tg2bVLdR, out int #=z5yMdA8igDzdU, out double #=zw45Mc8i1U2MV)
	{
		if (#=zCIRVQzI=.Count == 0)
		{
			#=zr1O3tg2bVLdR = 0.0;
			#=z5yMdA8igDzdU = 0;
			#=zw45Mc8i1U2MV = 0.0;
			return 0.0;
		}
		double num = 0.0;
		double num2 = 0.0;
		double num3 = 1.0;
		for (int i = 0; i < #=zCIRVQzI=.Count; i++)
		{
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = #=zCIRVQzI=[i];
			num += (double)#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zM_w3ufFbc_RdRFaz$9jXTgI=();
			num2 += #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zYd5BqJHlljWT4ecPQrIWiGc=(#=z0smlvCiQcuhV, #=zCIRVQzI=.Count);
		}
		#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 = #=zCIRVQzI=[0];
		if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zFMDiymuLQ7_4() == 21000)
		{
			num3 = 1.0 + #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zL9KMJ9Y=() / 100.0;
		}
		#=zr1O3tg2bVLdR = num * num2 * num3;
		#=z5yMdA8igDzdU = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zvnZc$RhG_1Du();
		#=zw45Mc8i1U2MV = #=zr1O3tg2bVLdR * (1.0 + 0.5 * (double)#=z5yMdA8igDzdU / 100.0);
		return #=zw45Mc8i1U2MV;
	}

	// Token: 0x060002EA RID: 746 RVA: 0x0001B9EC File Offset: 0x00019BEC
	private int #=zWno7CqHs1cgJ2vls3ZaVzHRxDFy8(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
	{
		bool flag = this.#=zbMDj$Y4=(#=zm8PpuDU=) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1;
		int num = (this.#=zbMDj$Y4=(#=zcltuPyw=) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)1).CompareTo(flag);
		if (num != 0)
		{
			return num;
		}
		if (flag)
		{
			num = #=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==());
			if (num != 0)
			{
				return num;
			}
			num = (#=zcltuPyw=.#=zVm_gjb4pLtQN() == 0).CompareTo(#=zm8PpuDU=.#=zVm_gjb4pLtQN() == 0);
			if (num != 0)
			{
				return num;
			}
		}
		return #=zcltuPyw=.#=ztj93y6niVpCR().CompareTo(#=zm8PpuDU=.#=ztj93y6niVpCR());
	}

	// Token: 0x040000E0 RID: 224
	private #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zm92199OybSmIl9Uefw==;

	// Token: 0x040000E1 RID: 225
	private #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=z9NIv67WFQ8g8Cs8ekA==;

	// Token: 0x040000E2 RID: 226
	private #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI= #=zlhbZ30IOYw$h$EOR3Q==;

	// Token: 0x040000E3 RID: 227
	private int #=zJxfgWpOiQEkVffms$_L1sXM=;

	// Token: 0x040000E4 RID: 228
	private int #=zn29IPVKYXuGYsOi4mOtk3oQ=;

	// Token: 0x040000E5 RID: 229
	private List<int> #=zJuJOGd$r9zprxxNhlVfqNto=;

	// Token: 0x040000E6 RID: 230
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x040000E7 RID: 231
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x040000E8 RID: 232
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zeYLQo2n2g2lR;

	// Token: 0x040000E9 RID: 233
	private #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= #=z1L5EVM5jSO3xd$DrZn2dfAI=;

	// Token: 0x040000EA RID: 234
	private int #=zcS6EjrRHjirK;

	// Token: 0x040000EB RID: 235
	private #=zsXHWUPT57npsJ0h0q$KoR2cvphBjbYrLqGF_iQjBZHmR #=z5RRcbP0wotIN;

	// Token: 0x040000EC RID: 236
	private Dictionary<int, #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=> #=zM4AChhv$H1IU;

	// Token: 0x040000ED RID: 237
	private List<int> #=zg$16SdGDB42$cfLxQjb37TRRE8tU36$9sw==;

	// Token: 0x040000EE RID: 238
	private List<int> #=zRT1x$yoZiY5y4Z$sjNrd1vml12rpAACRC18t_P4=;

	// Token: 0x040000EF RID: 239
	private List<int> #=zergXG9cVaBnKiv9KDJT$1WC9j9sqcJfgmg==;

	// Token: 0x040000F0 RID: 240
	private List<int> #=zf4Ru31wCo3DEDkD4NCiLjNAby8S0jyZF1A==;

	// Token: 0x0200005F RID: 95
	private sealed class #=zB1S9ASeEJWvz86OjP9N7sh4=
	{
		// Token: 0x060002EC RID: 748 RVA: 0x0001BA78 File Offset: 0x00019C78
		internal bool #=zYWwBOvFGnm6EAag$vLDky78=(#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns= #=z5iQBCwKizwUEgvTrUw==)
		{
			return #=z5iQBCwKizwUEgvTrUw==.#=zaKAy47_E$9SRuF6oiw==() == this.#=zU4TPzxM=.#=zaKAy47_E$9SRuF6oiw==() && #=z5iQBCwKizwUEgvTrUw==.#=ztj93y6niVpCR() == this.#=zU4TPzxM=.#=ztj93y6niVpCR() && !#=z5iQBCwKizwUEgvTrUw==.#=ztP$zSGbniHTJ() && !this.#=zlJSAjfPMVf41.#=zDgJiXLE=(#=z5iQBCwKizwUEgvTrUw==);
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0001BAC4 File Offset: 0x00019CC4
		internal bool #=zuUrixzVtj0X3ZPmAz5ez1c4=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zpNgbFmyrA4h4)
		{
			#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zuanTuKudkPmTOVfbNyttLWQ= #=zuanTuKudkPmTOVfbNyttLWQ= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zuanTuKudkPmTOVfbNyttLWQ=();
			#=zuanTuKudkPmTOVfbNyttLWQ=.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg= = this;
			#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4 = #=zpNgbFmyrA4h4;
			if (#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=zMuFMjGQ=() != this.#=zU4TPzxM=.#=zMuFMjGQ=() && #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=ztj93y6niVpCR() == this.#=zU4TPzxM=.#=ztj93y6niVpCR() && !#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=ztP$zSGbniHTJ() && !this.#=zlJSAjfPMVf41.#=zj_RULOkSJy6BjegQMw==(#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4))
			{
				#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zY9gFTlM= = this.#=zlJSAjfPMVf41.#=zbMDj$Y4=(#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4);
				if ((#=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)21 && #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=zYS6NXcO7DUmh()) || #=zY9gFTlM= == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)30)
				{
					bool flag = #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=ztj93y6niVpCR() < 5 || #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=zVm_gjb4pLtQN() > 0;
					if (!flag && #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=zaKAy47_E$9SRuF6oiw==() > 1 && this.#=zlJSAjfPMVf41.#=zm92199OybSmIl9Uefw==.Find(new Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$>(#=zuanTuKudkPmTOVfbNyttLWQ=.#=zS6nX2ySyyFJ$tEZMoQwg_kY=)) == null)
					{
						flag = true;
					}
					if (flag)
					{
						if (this.#=zlJSAjfPMVf41.#=z8StzeqE=.#=zv2Kyu17YrGOC().GeneralSpecRules.#=zQLl7KKs=(GeneralActionRule.GarTypes.DontUseForRankUpgrade, #=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4))
						{
							this.#=zlJSAjfPMVf41.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zlJSAjfPMVf41.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908882872), new object[]
							{
								#=zuanTuKudkPmTOVfbNyttLWQ=.#=zpNgbFmyrA4h4.#=zTbtwDpWhYGtF()
							});
							return false;
						}
						return true;
					}
				}
			}
			return false;
		}

		// Token: 0x040000F1 RID: 241
		public #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=;

		// Token: 0x040000F2 RID: 242
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg== #=zlJSAjfPMVf41;
	}

	// Token: 0x02000060 RID: 96
	private sealed class #=zMZQEcIQQyctgBOxH$ex9QdE=
	{
		// Token: 0x040000F3 RID: 243
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg== #=zlJSAjfPMVf41;

		// Token: 0x040000F4 RID: 244
		public List<int> #=zSNPnJbDunfxk;
	}

	// Token: 0x02000061 RID: 97
	private sealed class #=zVA5DTxsop0DII4nixnWcIFQ=
	{
		// Token: 0x060002F0 RID: 752 RVA: 0x0001BC38 File Offset: 0x00019E38
		internal bool #=zjN5$GnbIPU7KQtciU5hUGTc=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return !this.#=zlJSAjfPMVf41.#=zDgJiXLE=(#=zQrqFdos=) && !this.#=zqtUdKaNfGEErCKScKK2OlT8=.Contains(#=zQrqFdos=.#=zMuFMjGQ=()) && #=zQrqFdos=.#=zvnZc$RhG_1Du() >= 25;
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x0001BC6C File Offset: 0x00019E6C
		internal int #=zB$fiJQwbqCdODybn_SIClmg=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return ((double)#=zcltuPyw=.#=zM_w3ufFbc_RdRFaz$9jXTgI=() * #=zcltuPyw=.#=zYd5BqJHlljWT4ecPQrIWiGc=(this.#=z0smlvCiQcuhV, this.#=zSc8VHuH3XAKZ)).CompareTo((double)#=zm8PpuDU=.#=zM_w3ufFbc_RdRFaz$9jXTgI=() * #=zm8PpuDU=.#=zYd5BqJHlljWT4ecPQrIWiGc=(this.#=z0smlvCiQcuhV, this.#=zSc8VHuH3XAKZ));
		}

		// Token: 0x040000F5 RID: 245
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg== #=zlJSAjfPMVf41;

		// Token: 0x040000F6 RID: 246
		public List<int> #=zqtUdKaNfGEErCKScKK2OlT8=;

		// Token: 0x040000F7 RID: 247
		public #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z0smlvCiQcuhV;

		// Token: 0x040000F8 RID: 248
		public int #=zSc8VHuH3XAKZ;
	}

	// Token: 0x02000062 RID: 98
	private sealed class #=zVIyf3uKMUPb9lnp7FtSr638=
	{
		// Token: 0x060002F3 RID: 755 RVA: 0x0001BCC0 File Offset: 0x00019EC0
		internal bool #=z7kbTiK7osjpxa1BQfHfQ30A=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zQi6$ZU4=.Id && #=zQrqFdos=.#=zaKAy47_E$9SRuF6oiw==() >= 2;
		}

		// Token: 0x040000F9 RID: 249
		public #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zQi6$ZU4=;
	}

	// Token: 0x02000063 RID: 99
	public enum #=zY9gFTlM=
	{

	}

	// Token: 0x02000064 RID: 100
	private sealed class #=zYyVzn7vuC8wOyX6RmBckS2Q=
	{
		// Token: 0x060002F5 RID: 757 RVA: 0x0001BCEC File Offset: 0x00019EEC
		internal bool #=zN1r_geHfRQ_r7AHPI111Ss03kcQIHNZNqw==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return this.#=zC7NDbDM=.Contains(#=zQrqFdos=.#=zFMDiymuLQ7_4()) && !this.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=.#=zlJSAjfPMVf41.#=zDgJiXLE=(#=zQrqFdos=) && #=zQrqFdos=.#=zaKAy47_E$9SRuF6oiw==() >= 2;
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x0001BD24 File Offset: 0x00019F24
		internal int #=z65HlBNJ16JhFRIiV$uW6E9RngO3xxE1Nbg==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
			{
				#=zcltuPyw=.#=zFMDiymuLQ7_4().Equals(this.#=zW5FyGUI=).CompareTo(#=zm8PpuDU=.#=zFMDiymuLQ7_4().Equals(this.#=zW5FyGUI=)),
				#=zcltuPyw=.#=zIttox1M=().CompareTo(#=zm8PpuDU=.#=zIttox1M=()),
				#=zm8PpuDU=.#=zMuFMjGQ=().CompareTo(#=zcltuPyw=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x0001BDA0 File Offset: 0x00019FA0
		internal bool #=zYcgY5b3tl908T6lstt8B$YCUuwKVYdzeNQ==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return this.#=zC7NDbDM=.Contains(#=zQrqFdos=.#=zFMDiymuLQ7_4()) && this.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=.#=zSNPnJbDunfxk.Contains(#=zQrqFdos=.#=zMuFMjGQ=());
		}

		// Token: 0x040000FB RID: 251
		public List<int> #=zC7NDbDM=;

		// Token: 0x040000FC RID: 252
		public int #=zW5FyGUI=;

		// Token: 0x040000FD RID: 253
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zMZQEcIQQyctgBOxH$ex9QdE= #=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=;
	}

	// Token: 0x02000065 RID: 101
	private sealed class #=zbNDPf$Hd8gYrHkOOd7T_3VE=
	{
		// Token: 0x060002F9 RID: 761 RVA: 0x0001BDD8 File Offset: 0x00019FD8
		internal bool #=zdoq9GX0MRqKtVhGIja1IOOI=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=ztj93y6niVpCR() == this.#=z0i3iSog= && this.#=zlJSAjfPMVf41.#=zbMDj$Y4=(#=zQrqFdos=) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)0;
		}

		// Token: 0x040000FE RID: 254
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg== #=zlJSAjfPMVf41;

		// Token: 0x040000FF RID: 255
		public int #=z0i3iSog=;

		// Token: 0x04000100 RID: 256
		public Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zR_c6jW5wZ06o;
	}

	// Token: 0x02000066 RID: 102
	private sealed class #=zoHB7AuaUwS0ptNO1CfLCyWI=
	{
		// Token: 0x060002FB RID: 763 RVA: 0x0001BE04 File Offset: 0x0001A004
		internal bool #=zMhNJ0Oe8TdP3sScFZi03kXKXw_UX(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du() == this.#=zqA$P993_7f9soaIprQ==;
		}

		// Token: 0x04000101 RID: 257
		public int #=zqA$P993_7f9soaIprQ==;
	}

	// Token: 0x02000067 RID: 103
	private sealed class #=zuanTuKudkPmTOVfbNyttLWQ=
	{
		// Token: 0x060002FD RID: 765 RVA: 0x0001BE1C File Offset: 0x0001A01C
		internal bool #=zS6nX2ySyyFJ$tEZMoQwg_kY=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zT9YY8oHOeV7j0KaeUw==)
		{
			return #=zT9YY8oHOeV7j0KaeUw==.#=zFMDiymuLQ7_4() == this.#=zpNgbFmyrA4h4.#=zFMDiymuLQ7_4() && #=zT9YY8oHOeV7j0KaeUw==.#=zaKAy47_E$9SRuF6oiw==() == this.#=zpNgbFmyrA4h4.#=zaKAy47_E$9SRuF6oiw==() && !#=zT9YY8oHOeV7j0KaeUw==.#=ztP$zSGbniHTJ() && !this.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=.#=zlJSAjfPMVf41.#=zj_RULOkSJy6BjegQMw==(#=zT9YY8oHOeV7j0KaeUw==) && this.#=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=.#=zlJSAjfPMVf41.#=zbMDj$Y4=(#=zT9YY8oHOeV7j0KaeUw==) == (#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM=)10;
		}

		// Token: 0x04000102 RID: 258
		public #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zpNgbFmyrA4h4;

		// Token: 0x04000103 RID: 259
		public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zB1S9ASeEJWvz86OjP9N7sh4= #=qJ5ypczCqyDCw31_r5sWK2m3Ow7X8xdlDee$Jpe0BMyg=;
	}

	// Token: 0x02000068 RID: 104
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000300 RID: 768 RVA: 0x0001BE98 File Offset: 0x0001A098
		internal int #=zKpf8gWzxDegS54BCSqV9yZ_PdoBR(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zm8PpuDU=, #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zvnZc$RhG_1Du().CompareTo(#=zcltuPyw=.#=zvnZc$RhG_1Du());
		}

		// Token: 0x06000301 RID: 769 RVA: 0x0001BEBC File Offset: 0x0001A0BC
		internal int #=zZhNwwlVgmFfP4Y5NnYg6yX8=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zrHi0fK8=(new int[]
			{
				#=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==()),
				#=zm8PpuDU=.#=zpoRmlojd2iH8().CompareTo(#=zcltuPyw=.#=zpoRmlojd2iH8()),
				#=zm8PpuDU=.#=zIttox1M=().CompareTo(#=zcltuPyw=.#=zIttox1M=()),
				#=zcltuPyw=.#=zMuFMjGQ=().CompareTo(#=zm8PpuDU=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x06000302 RID: 770 RVA: 0x0001BF30 File Offset: 0x0001A130
		internal int #=z3ZN3eaJsdyq6M47arM0SRTs=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zrHi0fK8=(new int[]
			{
				#=zm8PpuDU=.#=zpoRmlojd2iH8().CompareTo(#=zcltuPyw=.#=zpoRmlojd2iH8()),
				#=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==()),
				#=zm8PpuDU=.#=zIttox1M=().CompareTo(#=zcltuPyw=.#=zIttox1M=()),
				#=zcltuPyw=.#=zMuFMjGQ=().CompareTo(#=zm8PpuDU=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x06000303 RID: 771 RVA: 0x0001BFA4 File Offset: 0x0001A1A4
		internal int #=zeAND3kd$AVDwRoAYCuViwrc=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zrHi0fK8=(new int[]
			{
				#=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==()),
				#=zcltuPyw=.#=ztj93y6niVpCR().CompareTo(#=zm8PpuDU=.#=ztj93y6niVpCR()),
				#=zcltuPyw=.#=zvnZc$RhG_1Du().CompareTo(#=zm8PpuDU=.#=zvnZc$RhG_1Du()),
				#=zcltuPyw=.#=zMuFMjGQ=().CompareTo(#=zm8PpuDU=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x06000304 RID: 772 RVA: 0x0001C018 File Offset: 0x0001A218
		internal int #=zGMMDQaseeeFN55oab99pwxS0ZzlT(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			int num = #=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==();
			int num2;
			if (num != 1)
			{
				if (num != 5)
				{
					num2 = #=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==();
				}
				else
				{
					num2 = 100;
				}
			}
			else
			{
				num2 = 10;
			}
			num = #=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==();
			int value;
			if (num != 1)
			{
				if (num != 5)
				{
					value = #=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==();
				}
				else
				{
					value = 100;
				}
			}
			else
			{
				value = 10;
			}
			return num2.CompareTo(value);
		}

		// Token: 0x06000305 RID: 773 RVA: 0x0001C074 File Offset: 0x0001A274
		internal bool #=zOhmjcqgOm$N$_yrcN4uGYNsq5kHJ(GeneralActionRule #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type == GeneralActionRule.GarTypes.UseJoinsForUseful;
		}

		// Token: 0x06000306 RID: 774 RVA: 0x0001C080 File Offset: 0x0001A280
		internal bool #=z$ZIjlgFNtNHLeKVgorghPZIrrfmSFpGajA==(GeneralActionRule #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type == GeneralActionRule.GarTypes.UseAmuletsForUseful;
		}

		// Token: 0x06000307 RID: 775 RVA: 0x0001C08C File Offset: 0x0001A28C
		internal int #=zZxNyxBfaGmUoIXY$DRRXNBPSVhE1mCNpzg==(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zM_w3ufFbc_RdRFaz$9jXTgI=().CompareTo(#=zcltuPyw=.#=zM_w3ufFbc_RdRFaz$9jXTgI=());
		}

		// Token: 0x06000308 RID: 776 RVA: 0x0001C0B0 File Offset: 0x0001A2B0
		internal int #=z5coTMgA_xV3IfvO13KPAkDTtZ5uZ2iKGRQ==(#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zm8PpuDU=, #=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=z8Nl16CPh9dN5().CompareTo(#=zcltuPyw=.#=z8Nl16CPh9dN5());
		}

		// Token: 0x06000309 RID: 777 RVA: 0x0001C0D4 File Offset: 0x0001A2D4
		internal bool #=zJxeAhDGxMF12xFoy88RVUqC7UV_3(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == 21000;
		}

		// Token: 0x0600030A RID: 778 RVA: 0x0001C0E4 File Offset: 0x0001A2E4
		internal int #=zJXOxOsCsssYNV8ahrMg29_MimZd7(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zm8PpuDU=, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zcltuPyw=)
		{
			return #=zcltuPyw=.#=zIttox1M=().CompareTo(#=zm8PpuDU=.#=zIttox1M=());
		}

		// Token: 0x04000104 RID: 260
		public static readonly #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU= #=zLkw0NRU= = new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zyDNvciU=();

		// Token: 0x04000105 RID: 261
		public static Comparison<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=> #=zlj2QhQwZXfWbEXsQaw==;

		// Token: 0x04000106 RID: 262
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zGwCjRBKbIP7X6f8oQg==;

		// Token: 0x04000107 RID: 263
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zad5ZGdearMp$Wm5iOA==;

		// Token: 0x04000108 RID: 264
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=z5L96ayI9as3cQMhgtg==;

		// Token: 0x04000109 RID: 265
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zcxWHZVwBwNeU1yRlNw==;

		// Token: 0x0400010A RID: 266
		public static Predicate<GeneralActionRule> #=z_$QCZkKip7SdFkheVQ==;

		// Token: 0x0400010B RID: 267
		public static Predicate<GeneralActionRule> #=zs27KIlD2Hl4lcRTyqw==;

		// Token: 0x0400010C RID: 268
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zN$76HSjxj$ffm2AhFA==;

		// Token: 0x0400010D RID: 269
		public static Comparison<#=z6NLmXMAz_pWKErj5yl9EIqNwMoYJEV5mk63PRUM=> #=zj_oCQCe9cL$KxJ6V$g==;

		// Token: 0x0400010E RID: 270
		public static Predicate<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=zlCVtSkf9QrpcidTskQ==;

		// Token: 0x0400010F RID: 271
		public static Comparison<#=zrDcgv9ny10MzDWIXXLpHLoin_0n$> #=z0wdL3VBoaAj$_9lU2g==;
	}
}
