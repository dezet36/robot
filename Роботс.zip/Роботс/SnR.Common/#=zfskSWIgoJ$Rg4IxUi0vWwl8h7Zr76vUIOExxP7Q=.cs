﻿using System;
using Skink.SnR.Common.Tasks;

// Token: 0x0200023E RID: 574
internal sealed class #=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=
{
	// Token: 0x06001194 RID: 4500 RVA: 0x0008869C File Offset: 0x0008689C
	public static #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=zYzfPccI=(#=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=zgV3wa0k=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		bool #=zCHbn2hfH3UKtUNPP0hes2P8= = false;
		for (int i = 0; i < #=zgV3wa0k=.Count; i++)
		{
			if (#=zgV3wa0k=[i].Type == TaskTypes.ExchangeDenaries)
			{
				#=zCHbn2hfH3UKtUNPP0hes2P8= = true;
				break;
			}
		}
		#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== = new #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==(#=zG2wnL_q7IxpD);
		for (int j = 0; j < #=zgV3wa0k=.Count; j++)
		{
			#=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=.#=zY7mlHwd77Mt7(#=zgV3wa0k=[j], #=zG2wnL_q7IxpD, #=zuJjQ1XU=, #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==, #=zCHbn2hfH3UKtUNPP0hes2P8=);
		}
		return #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==;
	}

	// Token: 0x06001195 RID: 4501 RVA: 0x000886F8 File Offset: 0x000868F8
	public static #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=zGr5DE2c=(Task #=zcTyyNys=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== = new #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==(#=zG2wnL_q7IxpD);
		#=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=.#=zY7mlHwd77Mt7(#=zcTyyNys=, #=zG2wnL_q7IxpD, #=zuJjQ1XU=, #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==, #=zcTyyNys=.Type == TaskTypes.ExchangeDenaries);
		if (#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==.Count <= 0)
		{
			return null;
		}
		return #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==[0];
	}

	// Token: 0x06001196 RID: 4502 RVA: 0x00088730 File Offset: 0x00086930
	private static void #=zY7mlHwd77Mt7(Task #=zcTyyNys=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=, #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=ziGiOPVdp4YvFFSfpzw==, bool #=zCHbn2hfH3UKtUNPP0hes2P8=)
	{
		if (#=zuJjQ1XU=.#=zN9p5NNdPP8hONn3XaYpbiK4=())
		{
			return;
		}
		#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== = #=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=.#=zI4eRlrtg2gqf(#=zcTyyNys=);
		if (#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== == null)
		{
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959674), new object[]
			{
				#=zcTyyNys=.Type
			});
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959674), new object[]
			{
				#=zcTyyNys=.ToString()
			});
			return;
		}
		try
		{
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zC68QI$8=(#=zcTyyNys=, #=zG2wnL_q7IxpD, #=zuJjQ1XU=, #=zCHbn2hfH3UKtUNPP0hes2P8=);
			#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=znhayI43rZGmx(new #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==.#=zsIEBeRIWmuxA(#=ziGiOPVdp4YvFFSfpzw==.#=z$ufXuqs=));
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959619), new object[]
			{
				#=zcTyyNys=.Type,
				#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.Message
			});
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K), Array.Empty<object>());
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs= #=zArez$Gs= = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=();
			if (#=zArez$Gs= == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)0 || #=zArez$Gs= == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)5)
			{
				return;
			}
			throw;
		}
		catch (Exception ex)
		{
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959619), new object[]
			{
				#=zcTyyNys=.Type,
				ex.Message
			});
			#=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(ex), Array.Empty<object>());
			return;
		}
		#=ziGiOPVdp4YvFFSfpzw==.Add(#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==);
	}

	// Token: 0x06001197 RID: 4503 RVA: 0x000888B0 File Offset: 0x00086AB0
	private static #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=zI4eRlrtg2gqf(Task #=zcTyyNys=)
	{
		TaskTypes type = #=zcTyyNys=.Type;
		if (type <= TaskTypes.SearchByPattern)
		{
			switch (type)
			{
			case TaskTypes.SendToAcropol:
				return new #=zLJMcwUm04UPUxz1kDvdwxcsTN6Ibaw$AB31zEXz_rj$Lj9gU6A==();
			case TaskTypes.SendUnit:
				return new #=zyYrg2fk_TBVQl2D$r4VyQW1xNCMcwraUIpsFeQY=();
			case TaskTypes.CompleteProphecies:
				return new #=zU3cP2VAjCLIwckk8jYHplBykCpwX50k3i59vZMzv634RqBn1nJR2W84=();
			case TaskTypes.ExchangeDenaries:
				return new #=zNVzAwhVv$COkn8Frxjw9sJ8JehzczWe87zvNgakhf1OQ5GNPuApqAV0=();
			case (TaskTypes)4:
			case (TaskTypes)5:
			case (TaskTypes)7:
			case (TaskTypes)13:
			case (TaskTypes)30:
			case (TaskTypes)31:
			case (TaskTypes)40:
			case (TaskTypes)41:
			case (TaskTypes)42:
			case (TaskTypes)43:
			case (TaskTypes)44:
			case (TaskTypes)45:
			case (TaskTypes)46:
			case (TaskTypes)47:
			case (TaskTypes)48:
			case (TaskTypes)49:
			case (TaskTypes)50:
			case (TaskTypes)51:
			case (TaskTypes)52:
			case (TaskTypes)53:
			case (TaskTypes)54:
			case (TaskTypes)55:
			case (TaskTypes)56:
			case (TaskTypes)57:
			case (TaskTypes)58:
			case (TaskTypes)59:
			case (TaskTypes)60:
			case (TaskTypes)61:
			case (TaskTypes)62:
			case (TaskTypes)63:
			case (TaskTypes)64:
			case (TaskTypes)65:
			case (TaskTypes)66:
			case (TaskTypes)67:
			case (TaskTypes)68:
			case (TaskTypes)69:
			case (TaskTypes)70:
			case (TaskTypes)71:
			case (TaskTypes)72:
			case (TaskTypes)73:
			case (TaskTypes)74:
			case (TaskTypes)75:
			case (TaskTypes)76:
			case (TaskTypes)77:
			case (TaskTypes)78:
			case (TaskTypes)79:
			case (TaskTypes)80:
			case (TaskTypes)81:
			case (TaskTypes)82:
			case (TaskTypes)83:
			case (TaskTypes)84:
			case (TaskTypes)85:
			case (TaskTypes)86:
			case (TaskTypes)87:
			case (TaskTypes)88:
			case (TaskTypes)89:
			case (TaskTypes)90:
			case (TaskTypes)91:
			case (TaskTypes)92:
			case (TaskTypes)93:
			case (TaskTypes)94:
			case (TaskTypes)95:
			case (TaskTypes)96:
			case (TaskTypes)97:
			case (TaskTypes)98:
			case (TaskTypes)99:
				break;
			case TaskTypes.CollectResources:
				return new #=zBJfJNgk6OsvVsjubap5k9iWQrMb0ay4cA_2oIguuw9zD();
			case TaskTypes.HireTroops:
				return new #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==();
			case TaskTypes.GrabGiftsAndRewards:
				return new #=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG();
			case TaskTypes.CollectResourcesBuildings:
				return new #=zaoOiuYMoeagRA7XoY4USjunVkexciFKg6PX9P$YDvlUjyHiHNwE_PO4=();
			case TaskTypes.CloseTournments:
				return new #=zcJaILoueQx4ziYZOhsGXTdS2OGyNJUqt6bRWiQcdWvqlO2QdeLvkyQM=();
			case TaskTypes.UpgradeHermes:
				return new #=z5xOUZe6p9IolBXKUjzJgvgWchaN3Pb87T1VyUZyyAXbD();
			case TaskTypes.ExchangeTechSchemas:
				return new #=zyPm9rTYUgK7yX5ni6uix$8eZwu4JqVkXP67$V2efslG8();
			case TaskTypes.ResearchTechs:
				return new #=z4D$ECR7YZvHgryv3YAxotORKEv4IvQ9qHs5rS3Bgcbpv1YA$VslIQRE=();
			case TaskTypes.EmporiaCapture:
				return new #=ze_csdS6D0DG7gOcVFJ_prdT2gQrOixPG56d2ohLYOySadsGSIA==();
			case TaskTypes.BuildBuildings:
				return new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==();
			case TaskTypes.CloseQuests:
				return new #=zN8eMCGe_TZb6LVfI$b1iH3kieigqM0f4LPP7drJRLY2UP4kkOw==();
			case TaskTypes.UpgradeNanos:
				return new #=z09uBdDd2iz0QeX6llCvID1nzz6_zpt3C5LXY$zu1lDVU();
			case TaskTypes.DragonRefresh:
				return new #=z7fcSQ3tV0MgLdCDSty0XTQ2xWmEdxhFPh7fO6eEhDsUS();
			case TaskTypes.DragonActivate:
				return new #=z0$hsXh8Yx45LUUakrnf4tFcWiHH6HvvzGWPLouVPt8CM();
			case TaskTypes.DragonUpgrade:
				return new #=zUCFY4XfDhjO0V0C6PepmzBAj2dB9STInsOZulUcEt47u();
			case TaskTypes.ExpandCity:
				return new #=zWaKLKYohuwvUhLIsA$3P6cJseyjrr3iLFJ_ms3U=();
			case TaskTypes.AddMobilizers:
				return new #=z39CF$2Z72mTwPaVmpE$VHCQ4FzQ$73X5pXVPxO$OnJ97ikYVYLj$LJI$0wu8();
			case TaskTypes.ContributeResourcesToPant:
				return new #=z2gAz25B09ZkzeYrE18YsAzD83SwNkovB4LeS7_AErSt9VevB_Kw$wzI=();
			case TaskTypes.ResurrectAfterMassacre:
				return new #=zfp7Y0agYjoSHI1byAeN2_D4zTiOf_tTF3GsbsQb29gOycYIoJsyvIr1eexZweqf1J2LNWTU=();
			case TaskTypes.AskToJoinAlliance:
				return new #=zDQJuiDzV7frl3AP2cTATd6w_y1fmnPyLvUV8aCnHkP7nva7tPC5251B4PMz_();
			case TaskTypes.LeaveAlliance:
				return new #=zzqeSAwos8D3OVeT6KSX9wCil7tNun4JurgmsUoh4MYPyGF4whTl_DgM=();
			case TaskTypes.ExchangeResources:
				return new #=zmB0xRlrRv6pIa$ciil9Jq_5NOlfsQHcxTKrxCBk=();
			case TaskTypes.HireBuilder:
				return new #=zrmGJkGgrWBAXk_n4pBi6VC1CbVW3lWG44M2CKWChCGb16etqRg==();
			case TaskTypes.AcceptAmbassadors:
				return new #=zioyJqCzIpuexwMlEpsfRemyKul_GDQlRN8yjQktMWwrAISIBz76Yas8=();
			case TaskTypes.ReadAllMessages:
				return new #=z6Z3CifoDYyM1Rk78zE65mz368HEFGeMFjTFcUYYY18Dvml3O0Q==();
			case TaskTypes.ProcessAllianceHelpRequests:
				return new #=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4();
			case TaskTypes.CancelSendUnits:
				return new #=zaiKnF0Tuk1ojKG$DvLC9rp3vOkLCv$zR8KTYVNdq6M8d();
			case TaskTypes.PrepareSendUnit:
				return new #=zAbcSCj8sqOQ9y_deRAlbn8cBmKePAqynabK2tZ1ayjcg();
			case TaskTypes.ApplyBonusCode:
				return new #=zSpFD6rFEYRcNWdSPpl9nij_K54HaEnnz5cv3cTJoptMC0ydIMg==();
			case TaskTypes.SendAmbassador:
				return new #=zV1KAjEqnXqSD8sKGQkFqhXg$MJm_JGJeQhuYRIs1$$16qhb_$g==();
			case TaskTypes.MassOccupation:
				return new #=zcju5$uN1PXXbbiPydrm_fqtw2qRc3ZeiQ$Lz7oTcYAJiZuV8QVnmaqI=();
			case TaskTypes.RecallAllTroops:
				return new #=zv2HaP3gN5ahyY7xs2RkSli83QKj2NH7LiYY$WyH26ahPNF6QdTnKwEM=();
			case TaskTypes.AutoRobberyStart:
				return new #=z3u6T3VOBXqB_fmFvpAnIHKQK5WacY2Q$v0FpWi9yNWW1cZ$K1XTDqNO9sRPd();
			case TaskTypes.AutoRobbery:
				return new #=zB2P6bgqqdJp97KehPvZ3MeBFMq8cAQol5HhBvNaH0PeuLbRFccQZyiQ=();
			case TaskTypes.UpgradeGenerals:
				return new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==();
			case TaskTypes.OccupationBreak:
				return new #=zX8yC7RnVbFRg1JrW_W26WK6gVt0OMcFmf3yWwXbxrEnDgI5y6A==();
			case TaskTypes.BuyBlackMarketItem:
				return new #=zHX81WnZccFiSVLlYVs1ZEWM714ki4TNFBVoDOvhE3TFERmTCNTqmwomvCwiE();
			case TaskTypes.UseBlackMarketItem:
				return new #=zdwJTdqKoKRET2BsuIPULIMSHAQPOc7mmZxF9D4PXIGluCDCDKJ6aC72NrQra();
			case TaskTypes.BuyBlackMarketTroops:
				return new #=zlGgEEPoDqx7kgJsLy02l6i8stYZaMfTybmbscclFkFipwOJyQHZZT5526B9gB$pdew==();
			case TaskTypes.FillUpResourcesFromBlackMarket:
				return new #=zuwGCAxWx_QT6N5zYtvZwG8RczV_Wh1HraY2LEBhJG29A1LgHDa1XlX_oOhXIxC8FHg==();
			case TaskTypes.BuyBlackMarketResources:
				return new #=zX8yC7RnVbFRg1JrW_W26WDdlNK_APxBPDMLH7I$_5ejEfnwaQ_CQfLiovBcN();
			case TaskTypes.MutateTroops:
				return new #=za6D0G12s9eJwbPj6YpPRVbu9XDoFKok1wSyvgLNWGvDXX3qzt12Pzeg=();
			case TaskTypes.SendAndRecallResources:
				return new #=zM9NnqyNC9zqfCk7gu9NWKuRlQfWtMQ1tsAlvtB8bmNd0_MEev7iPnSXvWj55();
			case TaskTypes.InventoryItems:
				return new #=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==();
			case TaskTypes.TechSchemasStockExchange:
				return new #=zcJaILoueQx4ziYZOhsGXTecvP6_jn8VlbKSw8bMt3_sTBGwotg==();
			case TaskTypes.UpgradeBuildingInstant:
				return new #=zEORknQ0bAYB9_cZ7av2r0Tkv8JBBfa2EkovXKDbKAUH2iNZs9rZYSLqTTblP();
			case TaskTypes.UpgradeTechInstant:
				return new #=zfrCQv8cDlxR3zcqzqa1Tqv3SbDH9E8JwLBS6S9LaNo$RUUgg3nSMhibQ6Ki2();
			case TaskTypes.Artifacts:
				return new #=z7vgLvoK30HM177elyIfaTsOYLkcz7QZ7VlrBDUY=();
			case TaskTypes.UpgradeTroops:
				return new #=zqoHwpopEx4xhcgHR8z_QjHbMlu1Y9o4eYGXM8qXMo8_M();
			case TaskTypes.VeorCollectLocaBonus:
				return new #=zXhFnYdTTY8SF8XFn2TuXIY$gEvP3RhBHpW_QQpv2DockZ6DXweXRLGjLesnD();
			case TaskTypes.VeorHireTroops:
				return new #=zbPfnHT5IhdOk3l$n7_262VJ3eSUNHU9RSNY8sZ9ZHUFtP8UTNJqbXJM=();
			case TaskTypes.MassAttackManage:
				return new #=z0xcs93RQRrwIMe4tGOWkzRwGVBzPKZw2fYonUk7Ku1LyJT9zhA==();
			case TaskTypes.MassAttackExecute:
				return new #=zbsbryJUbmGdixhxydLA7ujvodYljo9x2bsIkRiXEZWJJNZkHHw==();
			case TaskTypes.SendResources:
				return new #=zMv$ucMI1oezKtpt83ajrLXW96PQYS0FCXMiVmPs=();
			case TaskTypes.SetCity:
				return new #=zs7nWTJ18w3NxyEcUSfp9i0yheg3o9VxTTtdMp5TN7ZyUEfUIQw==();
			case TaskTypes.RunContiniousBoosts:
				return new #=zM9NnqyNC9zqfCk7gu9NWKhGn70OYjXHfUhrxWaxCnWSgeOEkcqwXYQ08_a0UgtFvNA==();
			case TaskTypes.UpgradeCaravansForGlory:
				return new #=zwvsM$9wEubWozv5w4VLoSdetrGyQYF3Qf9yO07QR$Rfmjr_JOaCIe_$EWxfrgVXPsw==();
			case TaskTypes.BuyInCoalitionShop:
				return new #=ztDHrRr6WEBWYhz66z1p4mmWQP8LBmi5ijKk$94mVVX5s$TbLctNc2r64le4FpjgzGQ==();
			case TaskTypes.ProcessGems:
				return new #=zZdICVTsm6ghXO8tWVehr0n59PpeNSfpPOuvrduXmn1VO();
			case TaskTypes.BuyAgreementArticle:
				return new #=z37KPW$UCz0SXnmqksM1LreMbT$O$8Otaz_sa9HxBGWOIqN4oPFT64qNLLoSLfkEQey9V5QE=();
			case TaskTypes.ProcessStronghold:
				return new #=zwklHVRl_iQNty7dLSWLivEyAPw8CTlRMptoakOcYv4sU0L1flVfJ_as=();
			case TaskTypes.BingoEvent:
				return new #=zcju5$uN1PXXbbiPydrm_fmxsscNNICBypc9SgqmSLLzxSSqkiw==();
			case TaskTypes.DiceEvent:
				return new #=z2$7JhsUL6fqHJpYg7cvlnb$3s7Fkn2OaGQ1UGT4qF9jbAovfUw==();
			case TaskTypes.TeamLocationsManageTeams:
				return new #=zz7bEJOuww6fZBJGrd$X4sLqc74B1p$YXzVbiYCQFnNq0FYpx5rfRuaw=();
			case TaskTypes.TeamLocationsFulfillTeams:
				return new #=ztEgBLMOufGMp$jADTFyUN$HNx$Ohpa8rEARJeZ7rLZXLkX2ITanXwHXghge4();
			case TaskTypes.SendToAcropolImmediate:
				return new #=z3f$zldN8egqVy4mzJE_mNp7HG$T7tte3UrV60BwV1oj6wK5GQw==();
			case TaskTypes.SendAllianceBeacons:
				return new #=zp$20c7790ptYd19cWkfPpLYZ2IHCiL$hUIuDCJzKuEEiTgGUvOPTPaYHrpUN();
			case TaskTypes.HireTroopsImmediate:
				return new #=zcAioOxLrSCaNUY8WB6BWlWow_$LLreAAm98rBuM7Nvlpo_dosw==();
			default:
				if (type == TaskTypes.SearchByPattern)
				{
					return new #=zl851dSWRyRCNDk7uOEuQ2kjYwY0wEf8QGGen4ObeXzdf();
				}
				break;
			}
		}
		else
		{
			if (type == TaskTypes.ChangeAccProps)
			{
				return new #=z44F_lbUYkIWRkTSXKNO4MN5DR73Q4EYgT75fO6w8YDVW();
			}
			if (type == TaskTypes.Initiation)
			{
				return new #=zFHWlB3$fq6BNH8yTMAvTKsscE8r3lkLecn9KINQ=();
			}
			switch (type)
			{
			case TaskTypes.AutoRobberyTargetsAdd:
				return new #=ziBmi3s639WqpYN2JCWztK$ZKBDsrMTYIuSv_7bNZaZqspzmaIvLnbHfSEJzI();
			case TaskTypes.AutoRobberyCheckResult:
				return new #=z4D$ECR7YZvHgryv3YAxotEYnCEx3I7NlneobGySYRhkWfIxgAN7qyopWWSD0();
			case TaskTypes.AutoRobberyTargetsReset:
				return new #=zbL7n$53iGUBjdarp3LrY4L8XPgRHrxa87s2dT7Xho4eU$xwhLbiWYMlSoGCa();
			}
		}
		return null;
	}
}
