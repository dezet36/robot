﻿using System;

// Token: 0x020001B4 RID: 436
internal enum #=zUYB79z3coxPKjfLVGQT58nQo28R2ixgZps$KOFU=
{
	// Token: 0x04000798 RID: 1944
	Calculate,
	// Token: 0x04000799 RID: 1945
	MeasureApproximate,
	// Token: 0x0400079A RID: 1946
	MeasurePrecise
}
