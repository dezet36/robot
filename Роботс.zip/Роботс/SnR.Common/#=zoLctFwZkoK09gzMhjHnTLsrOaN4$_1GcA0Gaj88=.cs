﻿using System;

// Token: 0x020002A0 RID: 672
internal sealed class #=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=
{
	// Token: 0x06001473 RID: 5235 RVA: 0x0009C7D4 File Offset: 0x0009A9D4
	public int #=zVr0Tzd0=()
	{
		return this.#=zEG$5kcHvvjQAA9Pjrw==;
	}

	// Token: 0x06001474 RID: 5236 RVA: 0x0009C7DC File Offset: 0x0009A9DC
	public void #=zOxsGjgI=(int #=z$Ib9gYQ=)
	{
		this.#=zEG$5kcHvvjQAA9Pjrw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001475 RID: 5237 RVA: 0x0009C7E8 File Offset: 0x0009A9E8
	public int #=zV8r3OM1EBBH_()
	{
		return this.#=z8ewxO6m2rmCtSAlneA==;
	}

	// Token: 0x06001476 RID: 5238 RVA: 0x0009C7F0 File Offset: 0x0009A9F0
	public void #=zETiXjxYQf5Cr(int #=z$Ib9gYQ=)
	{
		this.#=z8ewxO6m2rmCtSAlneA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001477 RID: 5239 RVA: 0x0009C7FC File Offset: 0x0009A9FC
	public bool #=zzooUPydC3AwkLIr1rw==()
	{
		return this.#=zmuQxbCh0kR66IyNY_Yw_Deg=;
	}

	// Token: 0x06001478 RID: 5240 RVA: 0x0009C804 File Offset: 0x0009AA04
	public void #=z5UhXmdMbFOrHJ44CrQ==(bool #=z$Ib9gYQ=)
	{
		this.#=zmuQxbCh0kR66IyNY_Yw_Deg= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000BAD RID: 2989
	private int #=zEG$5kcHvvjQAA9Pjrw==;

	// Token: 0x04000BAE RID: 2990
	private int #=z8ewxO6m2rmCtSAlneA==;

	// Token: 0x04000BAF RID: 2991
	private bool #=zmuQxbCh0kR66IyNY_Yw_Deg=;
}
