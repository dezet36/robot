﻿// Token: 0x02000259 RID: 601
internal sealed partial class #=zhzsRcc1ezE70XWqxEZrzI6GrgAKW3puKZA== : global::System.Windows.Forms.Form
{
	// Token: 0x06001249 RID: 4681 RVA: 0x0008CDE0 File Offset: 0x0008AFE0
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000A3A RID: 2618
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
