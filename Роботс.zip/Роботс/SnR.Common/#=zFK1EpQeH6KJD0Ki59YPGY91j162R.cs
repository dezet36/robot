﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000F1 RID: 241
internal sealed class #=zFK1EpQeH6KJD0Ki59YPGY91j162R
{
	// Token: 0x06000646 RID: 1606 RVA: 0x00032650 File Offset: 0x00030850
	public #=zFK1EpQeH6KJD0Ki59YPGY91j162R(string #=z6QPrZ_4=, string #=z$Ib9gYQ=)
	{
		this.#=zrsHDyhs= = #=z6QPrZ_4=;
		this.#=zziO1gvU= = #=z$Ib9gYQ=;
		this.#=zvuWqnvI= = null;
	}

	// Token: 0x06000647 RID: 1607 RVA: 0x00032670 File Offset: 0x00030870
	public #=zFK1EpQeH6KJD0Ki59YPGY91j162R(string #=z6QPrZ_4=, string #=z$Ib9gYQ=, string #=z0ONi4Bk=)
	{
		this.#=zrsHDyhs= = #=z6QPrZ_4=;
		this.#=zziO1gvU= = #=z$Ib9gYQ=;
		this.#=zvuWqnvI= = #=z0ONi4Bk=;
	}

	// Token: 0x06000648 RID: 1608 RVA: 0x00032690 File Offset: 0x00030890
	public static string #=zmocA6lfLwHhL(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z88V33U9I4DoN)
	{
		List<#=zFK1EpQeH6KJD0Ki59YPGY91j162R> list = #=z88V33U9I4DoN.#=zNyDVWg8=();
		object[] array = new object[list.Count];
		for (int i = 0; i < list.Count; i++)
		{
			#=zFK1EpQeH6KJD0Ki59YPGY91j162R #=zFK1EpQeH6KJD0Ki59YPGY91j162R = list[i];
			array[i] = new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
					#=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zrsHDyhs=
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
					#=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zziO1gvU=
				},
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094),
					#=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zvuWqnvI=
				}
			};
		}
		return JSONManager.SerializeData(array);
	}

	// Token: 0x06000649 RID: 1609 RVA: 0x0003271C File Offset: 0x0003091C
	public static #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z8jJCAkXvwc0s(string #=zk656SlQ=)
	{
		#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== = new #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==();
		foreach (Dictionary<string, object> dictionary in (object[])JSONManager.DeserializeData(#=zk656SlQ=))
		{
			#=zFK1EpQeH6KJD0Ki59YPGY91j162R #=zycxjQhk= = new #=zFK1EpQeH6KJD0Ki59YPGY91j162R(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), string.Empty), JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), string.Empty));
			#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==.#=z48rEd0A=(#=zycxjQhk=);
		}
		return #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==;
	}

	// Token: 0x04000295 RID: 661
	public string #=zrsHDyhs=;

	// Token: 0x04000296 RID: 662
	public string #=zziO1gvU=;

	// Token: 0x04000297 RID: 663
	public string #=zvuWqnvI=;
}
