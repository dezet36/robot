﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x020000AB RID: 171
internal sealed class #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI= : #=z59JlNC2q1c97q8noCLWtKshKvf0ih0cyMw==
{
	// Token: 0x06000478 RID: 1144 RVA: 0x00025F5C File Offset: 0x0002415C
	public #=z8mnYrV_uXHt3QjLt4QlrJcQOPmXHOUoPrmp8OjI=(string #=zh9RaNgY=, string #=zcvyluurhAj5L) : base(TaskTypes.SearchByPattern)
	{
		this.#=zpVBlD$IJ4abR((#=zh9RaNgY= != null) ? #=zh9RaNgY=.ToLower() : string.Empty);
		this.#=zn60ui3ChU5Yk((#=zcvyluurhAj5L != null) ? #=zcvyluurhAj5L.ToLower() : string.Empty);
		this.#=zWt2s_xjAGwvM(new List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==>());
		this.#=zaK5cihF3wA8Au06mQw==(new List<int>());
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x00025FB8 File Offset: 0x000241B8
	public string #=zbfOGJA_8wt3H()
	{
		return this.#=zWc1UIOZJ5PmgFnozwA==;
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x00025FC0 File Offset: 0x000241C0
	private void #=zpVBlD$IJ4abR(string #=z$Ib9gYQ=)
	{
		this.#=zWc1UIOZJ5PmgFnozwA== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x00025FCC File Offset: 0x000241CC
	public string #=zTqDBdc7DKJmY()
	{
		return this.#=zHmMuYQbBjidCBK_H6A==;
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x00025FD4 File Offset: 0x000241D4
	private void #=zn60ui3ChU5Yk(string #=z$Ib9gYQ=)
	{
		this.#=zHmMuYQbBjidCBK_H6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x00025FE0 File Offset: 0x000241E0
	public List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=zoK6IbO99EGFZ()
	{
		return this.#=z_gpI$LafrVele14IXvGoJR0=;
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x00025FE8 File Offset: 0x000241E8
	private void #=zWt2s_xjAGwvM(List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=z$Ib9gYQ=)
	{
		this.#=z_gpI$LafrVele14IXvGoJR0= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x00025FF4 File Offset: 0x000241F4
	public List<int> #=zvVU8NknI_fMNii0PDw==()
	{
		return this.#=zFxbQxPgZeAHdnxVEi5cddd0=;
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x00025FFC File Offset: 0x000241FC
	private void #=zaK5cihF3wA8Au06mQw==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zFxbQxPgZeAHdnxVEi5cddd0= = #=z$Ib9gYQ=;
	}

	// Token: 0x040001AA RID: 426
	private string #=zWc1UIOZJ5PmgFnozwA==;

	// Token: 0x040001AB RID: 427
	private string #=zHmMuYQbBjidCBK_H6A==;

	// Token: 0x040001AC RID: 428
	private List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=z_gpI$LafrVele14IXvGoJR0=;

	// Token: 0x040001AD RID: 429
	private List<int> #=zFxbQxPgZeAHdnxVEi5cddd0=;
}
