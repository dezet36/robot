﻿using System;
using System.Runtime.CompilerServices;

// Token: 0x02000298 RID: 664
internal sealed class #=zo0xM9Yh84PPUvmstyPOlAl83hN9T : #=zM2IXTcon_Hd$W3PwdqAcldAgZzVT
{
	// Token: 0x06001438 RID: 5176 RVA: 0x0009A968 File Offset: 0x00098B68
	[CompilerGenerated]
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001439 RID: 5177 RVA: 0x0009A970 File Offset: 0x00098B70
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600143A RID: 5178 RVA: 0x0009A97C File Offset: 0x00098B7C
	[CompilerGenerated]
	public int #=zFMDiymuLQ7_4()
	{
		return this.#=z0Nhisi6IKhKY3b0saw==;
	}

	// Token: 0x0600143B RID: 5179 RVA: 0x0009A984 File Offset: 0x00098B84
	public void #=zedb$WwBQsoJF(int #=z$Ib9gYQ=)
	{
		this.#=z0Nhisi6IKhKY3b0saw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600143C RID: 5180 RVA: 0x0009A990 File Offset: 0x00098B90
	[CompilerGenerated]
	public int #=zaKAy47_E$9SRuF6oiw==()
	{
		return this.#=zg9DHdRJeKrYsJIc4CEiCbn4=;
	}

	// Token: 0x0600143D RID: 5181 RVA: 0x0009A998 File Offset: 0x00098B98
	public void #=zI74NzG$2ecMvvw_Hiw==(int #=z$Ib9gYQ=)
	{
		this.#=zg9DHdRJeKrYsJIc4CEiCbn4= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600143E RID: 5182 RVA: 0x0009A9A4 File Offset: 0x00098BA4
	[CompilerGenerated]
	public int #=ztj93y6niVpCR()
	{
		return this.#=zW7kHJvkAORBWJxF1eQ==;
	}

	// Token: 0x0600143F RID: 5183 RVA: 0x0009A9AC File Offset: 0x00098BAC
	public void #=zMU3h5OahHKt6(int #=z$Ib9gYQ=)
	{
		this.#=zW7kHJvkAORBWJxF1eQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001440 RID: 5184 RVA: 0x0009A9B8 File Offset: 0x00098BB8
	[CompilerGenerated]
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06001441 RID: 5185 RVA: 0x0009A9C0 File Offset: 0x00098BC0
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001442 RID: 5186 RVA: 0x0009A9CC File Offset: 0x00098BCC
	[CompilerGenerated]
	public int #=zVm_gjb4pLtQN()
	{
		return this.#=zkzfe7PbZTNPt9ZOkHQ==;
	}

	// Token: 0x06001443 RID: 5187 RVA: 0x0009A9D4 File Offset: 0x00098BD4
	public void #=zB6wj1d$M7SYT(int #=z$Ib9gYQ=)
	{
		this.#=zkzfe7PbZTNPt9ZOkHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001444 RID: 5188 RVA: 0x0009A9E0 File Offset: 0x00098BE0
	public int #=zjw43QGFcPyHH()
	{
		return this.#=z$cjfMsOUZJUVVe7pGQ==;
	}

	// Token: 0x06001445 RID: 5189 RVA: 0x0009A9E8 File Offset: 0x00098BE8
	public void #=zpmbhfimGMj3U(int #=z$Ib9gYQ=)
	{
		this.#=z$cjfMsOUZJUVVe7pGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001446 RID: 5190 RVA: 0x0009A9F4 File Offset: 0x00098BF4
	[CompilerGenerated]
	public string #=zPEhDdtHVGNHR()
	{
		return this.#=z1Sjro3iiXmreuPTxRA==;
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x0009A9FC File Offset: 0x00098BFC
	public void #=zlMZ1R0P0SMkC(string #=z$Ib9gYQ=)
	{
		this.#=z1Sjro3iiXmreuPTxRA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x0009AA08 File Offset: 0x00098C08
	public string #=zNTEClmggtyu4()
	{
		if (string.IsNullOrEmpty(this.#=zPEhDdtHVGNHR()))
		{
			return string.Empty;
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077047) + this.#=zPEhDdtHVGNHR()[0].ToString().ToLower();
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x0009AA50 File Offset: 0x00098C50
	public #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=z9ZHUN$Y=()
	{
		return this.#=zZqJ39hEu7SS_bez5Ag==;
	}

	// Token: 0x0600144A RID: 5194 RVA: 0x0009AA58 File Offset: 0x00098C58
	public void #=zbrtvpkQ=(#=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=z$Ib9gYQ=)
	{
		this.#=zZqJ39hEu7SS_bez5Ag== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000B93 RID: 2963
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000B94 RID: 2964
	private int #=z0Nhisi6IKhKY3b0saw==;

	// Token: 0x04000B95 RID: 2965
	private int #=zg9DHdRJeKrYsJIc4CEiCbn4=;

	// Token: 0x04000B96 RID: 2966
	private int #=zW7kHJvkAORBWJxF1eQ==;

	// Token: 0x04000B97 RID: 2967
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x04000B98 RID: 2968
	private int #=zkzfe7PbZTNPt9ZOkHQ==;

	// Token: 0x04000B99 RID: 2969
	private int #=z$cjfMsOUZJUVVe7pGQ==;

	// Token: 0x04000B9A RID: 2970
	private string #=z1Sjro3iiXmreuPTxRA==;

	// Token: 0x04000B9B RID: 2971
	private #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==.#=zY9gFTlM= #=zZqJ39hEu7SS_bez5Ag==;
}
