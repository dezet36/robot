﻿// Token: 0x02000100 RID: 256
internal sealed partial class #=zGhvzlNkMy89O6bFpwJ3Qf$OS7Vva3h1ccA== : global::System.Windows.Forms.Form
{
	// Token: 0x060006AE RID: 1710 RVA: 0x00034A0C File Offset: 0x00032C0C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040002C0 RID: 704
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
