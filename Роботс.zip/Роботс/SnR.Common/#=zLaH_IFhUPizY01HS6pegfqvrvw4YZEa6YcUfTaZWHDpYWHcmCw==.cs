﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Tasks;

// Token: 0x0200014C RID: 332
internal sealed partial class #=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw== : Form
{
	// Token: 0x060008BF RID: 2239 RVA: 0x00045320 File Offset: 0x00043520
	public #=zLaH_IFhUPizY01HS6pegfqvrvw4YZEa6YcUfTaZWHDpYWHcmCw==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, int #=zbwrJfOI=, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=z40sk5mc=)
	{
		try
		{
			this.#=zshVEGQI= = #=z8S9_Kvw=;
			this.#=zeJZsbgM= = #=z8StzeqE=;
			this.#=z38FouKE= = #=zbwrJfOI=;
			this.#=zoCem5Mk= = #=z40sk5mc=;
			this.#=zgpzgXirqPT5_();
			if (this.#=zoCem5Mk= is #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==)
			{
				this.#=zafBS1_w=.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086725), new object[]
				{
					this.#=zoCem5Mk=.#=zkfqcY3I=(),
					this.#=zoCem5Mk=.#=zfTB62qendhk_VEy8rw==(),
					this.#=zoCem5Mk=.#=zY0soxphmGIACbOHy6A==(),
					(this.#=zoCem5Mk= as #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==).#=zj661vGqZTMsoJ4JrPg==()
				});
			}
			else
			{
				this.#=zafBS1_w=.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070458), this.#=zoCem5Mk=.#=zkfqcY3I=(), this.#=zoCem5Mk=.#=zfTB62qendhk_VEy8rw==(), this.#=zoCem5Mk=.#=zY0soxphmGIACbOHy6A==());
			}
			this.#=zxEypbnjGs$V6.Text = this.#=zeJZsbgM=.#=zdEt_WRHpdEMmGTK_3Q==();
			this.#=zSQNJAkuxeuiSbH2Umg== = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
			for (int i = this.#=zshVEGQI=.#=zol80P7TKoihZ().Count - 1; i >= 0; i--)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[i];
				if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=() != null && #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zDZReNK0=().#=zG95DTZntR2nRriTBdb76SEs=().ContainsKey(this.#=z38FouKE=))
				{
					this.#=zSQNJAkuxeuiSbH2Umg==.Add(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
				}
			}
			if (this.#=zSQNJAkuxeuiSbH2Umg==.Count > 1)
			{
				this.#=zy8QqQE0iY401.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086957), new object[]
				{
					this.#=zSQNJAkuxeuiSbH2Umg==.Count - 1
				}).ToString();
				this.#=z0jCNg0Xy6scU.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086914), new object[]
				{
					this.#=zeJZsbgM=.#=zh5Q$jgycqA15().#=zSByqmFV12x0z()
				}).ToString();
			}
			else
			{
				this.#=zy8QqQE0iY401.Visible = false;
				this.#=z0jCNg0Xy6scU.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086899), Array.Empty<object>()).ToString();
				this.#=zxAI1oADPGMJn.Visible = false;
			}
			#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
		}
		catch (Exception ex)
		{
			this.#=zshVEGQI=.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, ex);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
			base.Close();
		}
	}

	// Token: 0x060008C0 RID: 2240 RVA: 0x00045598 File Offset: 0x00043798
	private void #=zDl4$1Gx3wrr17h923A==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		Clipboard.SetText(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070446), this.#=zoCem5Mk=.#=zfTB62qendhk_VEy8rw==(), this.#=zoCem5Mk=.#=zY0soxphmGIACbOHy6A==()));
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086883));
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x000455EC File Offset: 0x000437EC
	private void #=zEvCLpZNOG2BBhnoGqw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== #=zcTyyNys= = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSeverities.Background, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false, TaskSendUnitTypes.RecallReinforcement, this.#=z38FouKE=.ToString(), this.#=zoCem5Mk=.#=zkfqcY3I=(), null, 0, 0);
		this.#=zeJZsbgM=.#=zeR3QFrc=(#=zcTyyNys=);
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(this.#=zeJZsbgM=);
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088628));
		base.Close();
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x00045664 File Offset: 0x00043864
	private void #=zYkLut9TmFDCzFqtu$g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zSQNJAkuxeuiSbH2Umg==)
		{
			#=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== #=zcTyyNys= = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(TaskSeverities.Background, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false, TaskSendUnitTypes.RecallReinforcement, this.#=z38FouKE=.ToString(), this.#=zoCem5Mk=.#=zkfqcY3I=(), null, 0, 0);
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(#=zcTyyNys=);
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
		}
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088571));
		base.Close();
	}

	// Token: 0x060008C4 RID: 2244 RVA: 0x0004572C File Offset: 0x0004392C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zivQ3vZbROia4 = new Label();
		this.#=zafBS1_w= = new Label();
		this.#=zxAI1oADPGMJn = new Button();
		this.#=zORGDH1sn2uNxdCJuHw== = new Button();
		this.#=z0jCNg0Xy6scU = new Button();
		this.#=zxEypbnjGs$V6 = new Label();
		this.#=zy8QqQE0iY401 = new Label();
		this.#=zysAtYaVE42i8 = new Label();
		base.SuspendLayout();
		this.#=zivQ3vZbROia4.AutoSize = true;
		this.#=zivQ3vZbROia4.Location = new Point(12, 67);
		this.#=zivQ3vZbROia4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088527);
		this.#=zivQ3vZbROia4.Size = new Size(145, 13);
		this.#=zivQ3vZbROia4.TabIndex = 0;
		this.#=zivQ3vZbROia4.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088755);
		this.#=zafBS1_w=.AutoSize = true;
		this.#=zafBS1_w=.Location = new Point(12, 9);
		this.#=zafBS1_w=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088724);
		this.#=zafBS1_w=.Size = new Size(40, 13);
		this.#=zafBS1_w=.TabIndex = 1;
		this.#=zafBS1_w=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088698);
		this.#=zxAI1oADPGMJn.Location = new Point(15, 207);
		this.#=zxAI1oADPGMJn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088693);
		this.#=zxAI1oADPGMJn.Size = new Size(257, 23);
		this.#=zxAI1oADPGMJn.TabIndex = 2;
		this.#=zxAI1oADPGMJn.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088671);
		this.#=zxAI1oADPGMJn.UseVisualStyleBackColor = true;
		this.#=zxAI1oADPGMJn.Click += this.#=zYkLut9TmFDCzFqtu$g==;
		this.#=zORGDH1sn2uNxdCJuHw==.Location = new Point(15, 33);
		this.#=zORGDH1sn2uNxdCJuHw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088378);
		this.#=zORGDH1sn2uNxdCJuHw==.Size = new Size(257, 23);
		this.#=zORGDH1sn2uNxdCJuHw==.TabIndex = 3;
		this.#=zORGDH1sn2uNxdCJuHw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088364);
		this.#=zORGDH1sn2uNxdCJuHw==.UseVisualStyleBackColor = true;
		this.#=zORGDH1sn2uNxdCJuHw==.Click += this.#=zDl4$1Gx3wrr17h923A==;
		this.#=z0jCNg0Xy6scU.Location = new Point(15, 178);
		this.#=z0jCNg0Xy6scU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088341);
		this.#=z0jCNg0Xy6scU.Size = new Size(257, 23);
		this.#=z0jCNg0Xy6scU.TabIndex = 4;
		this.#=z0jCNg0Xy6scU.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088307);
		this.#=z0jCNg0Xy6scU.UseVisualStyleBackColor = true;
		this.#=z0jCNg0Xy6scU.Click += this.#=zEvCLpZNOG2BBhnoGqw==;
		this.#=zxEypbnjGs$V6.AutoSize = true;
		this.#=zxEypbnjGs$V6.Location = new Point(12, 96);
		this.#=zxEypbnjGs$V6.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088291);
		this.#=zxEypbnjGs$V6.Size = new Size(48, 13);
		this.#=zxEypbnjGs$V6.TabIndex = 5;
		this.#=zxEypbnjGs$V6.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088278);
		this.#=zy8QqQE0iY401.AutoSize = true;
		this.#=zy8QqQE0iY401.Location = new Point(12, 125);
		this.#=zy8QqQE0iY401.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088262);
		this.#=zy8QqQE0iY401.Size = new Size(101, 13);
		this.#=zy8QqQE0iY401.TabIndex = 6;
		this.#=zy8QqQE0iY401.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088494);
		this.#=zysAtYaVE42i8.AutoSize = true;
		this.#=zysAtYaVE42i8.Location = new Point(12, 154);
		this.#=zysAtYaVE42i8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088458);
		this.#=zysAtYaVE42i8.Size = new Size(129, 13);
		this.#=zysAtYaVE42i8.TabIndex = 7;
		this.#=zysAtYaVE42i8.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088440);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(284, 261);
		base.Controls.Add(this.#=zysAtYaVE42i8);
		base.Controls.Add(this.#=zy8QqQE0iY401);
		base.Controls.Add(this.#=zxEypbnjGs$V6);
		base.Controls.Add(this.#=z0jCNg0Xy6scU);
		base.Controls.Add(this.#=zORGDH1sn2uNxdCJuHw==);
		base.Controls.Add(this.#=zxAI1oADPGMJn);
		base.Controls.Add(this.#=zafBS1_w=);
		base.Controls.Add(this.#=zivQ3vZbROia4);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088411);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088122);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x040004F4 RID: 1268
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x040004F5 RID: 1269
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zeJZsbgM=;

	// Token: 0x040004F6 RID: 1270
	private int #=z38FouKE=;

	// Token: 0x040004F7 RID: 1271
	private #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zoCem5Mk=;

	// Token: 0x040004F8 RID: 1272
	private List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> #=zSQNJAkuxeuiSbH2Umg==;

	// Token: 0x040004FA RID: 1274
	private Label #=zivQ3vZbROia4;

	// Token: 0x040004FB RID: 1275
	private Label #=zafBS1_w=;

	// Token: 0x040004FC RID: 1276
	private Button #=zxAI1oADPGMJn;

	// Token: 0x040004FD RID: 1277
	private Button #=zORGDH1sn2uNxdCJuHw==;

	// Token: 0x040004FE RID: 1278
	private Button #=z0jCNg0Xy6scU;

	// Token: 0x040004FF RID: 1279
	private Label #=zxEypbnjGs$V6;

	// Token: 0x04000500 RID: 1280
	private Label #=zy8QqQE0iY401;

	// Token: 0x04000501 RID: 1281
	private Label #=zysAtYaVE42i8;
}
