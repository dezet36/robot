﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x0200007B RID: 123
internal sealed class #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= : IIntID
{
	// Token: 0x06000374 RID: 884 RVA: 0x0001F798 File Offset: 0x0001D998
	public #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=(int #=zAk8mKBk=, string #=z6QPrZ_4=)
	{
		this.Id = #=zAk8mKBk=;
		this.#=zwXKUV2c=(#=z6QPrZ_4=);
		this.#=zfnzHYuml3768MNNL9C6dE3o=(0);
		this.#=zqKuKYjYjdzxssVtN4UY1uYg=(new Dictionary<int, int>());
	}

	// Token: 0x06000375 RID: 885 RVA: 0x0001F7C0 File Offset: 0x0001D9C0
	public #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=(Dictionary<string, object> #=zHfk$OlM=)
	{
		this.Id = JSONManager.ExtractInt(#=zHfk$OlM=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
		this.#=zwXKUV2c=(JSONManager.GetString(#=zHfk$OlM=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null));
		this.#=zfnzHYuml3768MNNL9C6dE3o=(0);
		this.#=zqKuKYjYjdzxssVtN4UY1uYg=(new Dictionary<int, int>());
		object[] array = JSONManager.ExtractArray(#=zHfk$OlM=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907));
		if (array != null)
		{
			object[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				Dictionary<string, object> dictionary = JSONManager.ExtractDictionary((Dictionary<string, object>)array2[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
				if (dictionary != null)
				{
					Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
					if (dictionary2 != null)
					{
						this.#=zfnzHYuml3768MNNL9C6dE3o=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
						foreach (string text in dictionary2.Keys)
						{
							this.#=zEJwR6o0uD87uOKs2BdWvRnY=()[Convert.ToInt32(text)] = JSONManager.ExtractInt(dictionary2, text, 0);
						}
					}
				}
			}
		}
	}

	// Token: 0x17000006 RID: 6
	// (get) Token: 0x06000376 RID: 886 RVA: 0x0001F8E8 File Offset: 0x0001DAE8
	// (set) Token: 0x06000377 RID: 887 RVA: 0x0001F8F0 File Offset: 0x0001DAF0
	public int Id
	{
		[CompilerGenerated]
		get
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = value;
		}
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0001F8FC File Offset: 0x0001DAFC
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x06000379 RID: 889 RVA: 0x0001F904 File Offset: 0x0001DB04
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600037A RID: 890 RVA: 0x0001F910 File Offset: 0x0001DB10
	public int #=ziJ$YU1JNP2G7091OKNlTPms=()
	{
		return this.#=zDskDx0wxk0XwuT8gWgaOGc9_xl9E;
	}

	// Token: 0x0600037B RID: 891 RVA: 0x0001F918 File Offset: 0x0001DB18
	public void #=zfnzHYuml3768MNNL9C6dE3o=(int #=z$Ib9gYQ=)
	{
		this.#=zDskDx0wxk0XwuT8gWgaOGc9_xl9E = #=z$Ib9gYQ=;
	}

	// Token: 0x0600037C RID: 892 RVA: 0x0001F924 File Offset: 0x0001DB24
	public Dictionary<int, int> #=zEJwR6o0uD87uOKs2BdWvRnY=()
	{
		return this.#=zEMCmSJeRaM$u9zg9cDQ_9WoYQg87;
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0001F92C File Offset: 0x0001DB2C
	public void #=zqKuKYjYjdzxssVtN4UY1uYg=(Dictionary<int, int> #=z$Ib9gYQ=)
	{
		this.#=zEMCmSJeRaM$u9zg9cDQ_9WoYQg87 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600037E RID: 894 RVA: 0x0001F938 File Offset: 0x0001DB38
	public override string ToString()
	{
		return this.#=zkfqcY3I=();
	}

	// Token: 0x04000136 RID: 310
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000137 RID: 311
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x04000138 RID: 312
	private int #=zDskDx0wxk0XwuT8gWgaOGc9_xl9E;

	// Token: 0x04000139 RID: 313
	private Dictionary<int, int> #=zEMCmSJeRaM$u9zg9cDQ_9WoYQg87;
}
