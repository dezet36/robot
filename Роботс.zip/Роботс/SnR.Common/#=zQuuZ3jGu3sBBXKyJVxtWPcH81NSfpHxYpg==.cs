﻿using System;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Global;

// Token: 0x0200018E RID: 398
internal sealed class #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg== : IIntID
{
	// Token: 0x06000B61 RID: 2913 RVA: 0x000577B0 File Offset: 0x000559B0
	public #=zQuuZ3jGu3sBBXKyJVxtWPcH81NSfpHxYpg==(int #=zAk8mKBk=, string #=z6QPrZ_4=)
	{
		this.Id = #=zAk8mKBk=;
		this.Name = #=z6QPrZ_4=;
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x06000B62 RID: 2914 RVA: 0x000577C8 File Offset: 0x000559C8
	// (set) Token: 0x06000B63 RID: 2915 RVA: 0x000577D0 File Offset: 0x000559D0
	public int Id
	{
		[CompilerGenerated]
		get
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = value;
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000B64 RID: 2916 RVA: 0x000577DC File Offset: 0x000559DC
	// (set) Token: 0x06000B65 RID: 2917 RVA: 0x000577E4 File Offset: 0x000559E4
	public string Name
	{
		[CompilerGenerated]
		get
		{
			return this.#=zWd4PtJyWoTk_ZThs2A==;
		}
		[CompilerGenerated]
		set
		{
			this.#=zWd4PtJyWoTk_ZThs2A== = value;
		}
	}

	// Token: 0x06000B66 RID: 2918 RVA: 0x000577F0 File Offset: 0x000559F0
	public override string ToString()
	{
		return this.Name;
	}

	// Token: 0x04000620 RID: 1568
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000621 RID: 1569
	private string #=zWd4PtJyWoTk_ZThs2A==;
}
