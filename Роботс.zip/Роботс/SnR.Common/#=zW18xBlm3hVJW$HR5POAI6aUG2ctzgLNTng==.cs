﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Skink.SnR.Common.Managers;

// Token: 0x020001C5 RID: 453
internal sealed class #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng== : List<#=z7c3f2qXWcxmaz11o0HIoNIq39nWO>
{
	// Token: 0x06000D6C RID: 3436 RVA: 0x00068D5C File Offset: 0x00066F5C
	public #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==()
	{
	}

	// Token: 0x06000D6D RID: 3437 RVA: 0x00068D64 File Offset: 0x00066F64
	public #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zUkCnoYMDFjRG(#=zJ5GWysk=);
	}

	// Token: 0x17000042 RID: 66
	[IndexerName("#=zx6APBRk=")]
	public double this[#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zvRLj9WQ=]
	{
		get
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].#=zq2bPTdY=() == #=zvRLj9WQ=)
				{
					return base[i].#=zVcIxe_4=();
				}
			}
			return 0.0;
		}
	}

	// Token: 0x06000D6F RID: 3439 RVA: 0x00068DB8 File Offset: 0x00066FB8
	private void #=zUkCnoYMDFjRG(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zx3YL44sHqkqkeCnPuA==(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)1);
		this.#=zx3YL44sHqkqkeCnPuA==(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)2);
		this.#=zx3YL44sHqkqkeCnPuA==(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)3);
		this.#=zx3YL44sHqkqkeCnPuA==(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)4);
		this.#=z$pWq6PzKA7jo(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)5, 0);
		this.#=z$pWq6PzKA7jo(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061946), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)5, 1);
		this.#=z$pWq6PzKA7jo(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)10, 0);
		this.#=z$pWq6PzKA7jo(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)11, 0);
		this.#=zKRbz1RYYCZ_IeEdwMg==(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061940), (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)12, 1);
	}

	// Token: 0x06000D70 RID: 3440 RVA: 0x00068E70 File Offset: 0x00067070
	private void #=z$pWq6PzKA7jo(Dictionary<string, object> #=zJ5GWysk=, string #=zNraCe1Y=, #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zvRLj9WQ=, int #=zKJA8IWQ=)
	{
		double num;
		if (!#=zNraCe1Y=.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077047)))
		{
			num = JSONManager.ExtractDouble(#=zJ5GWysk=, #=zNraCe1Y=, 0.0);
		}
		else
		{
			num = JSONManager.GetDouble(#=zJ5GWysk=, #=zNraCe1Y=, 0.0);
		}
		if (Math.Abs(num) > 1E-05)
		{
			base.Add(new #=z7c3f2qXWcxmaz11o0HIoNIq39nWO(#=zvRLj9WQ=, #=zKJA8IWQ=, num));
		}
	}

	// Token: 0x06000D71 RID: 3441 RVA: 0x00068ED4 File Offset: 0x000670D4
	private void #=zx3YL44sHqkqkeCnPuA==(Dictionary<string, object> #=zJ5GWysk=, string #=zNraCe1Y=, #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zvRLj9WQ=)
	{
		Dictionary<string, object> dictionary;
		if (!#=zNraCe1Y=.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077047)))
		{
			dictionary = JSONManager.ExtractDictionary(#=zJ5GWysk=, #=zNraCe1Y=);
		}
		else
		{
			dictionary = JSONManager.GetDictionary(#=zJ5GWysk=, #=zNraCe1Y=);
		}
		if (dictionary != null)
		{
			foreach (string text in dictionary.Keys)
			{
				double num = JSONManager.ExtractDouble(dictionary, text, 0.0);
				if (num > 1E-05)
				{
					base.Add(new #=z7c3f2qXWcxmaz11o0HIoNIq39nWO(#=zvRLj9WQ=, (int)#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zsJJ$G_g=(text), num));
				}
			}
		}
	}

	// Token: 0x06000D72 RID: 3442 RVA: 0x00068F78 File Offset: 0x00067178
	private void #=zKRbz1RYYCZ_IeEdwMg==(Dictionary<string, object> #=zJ5GWysk=, string #=zNraCe1Y=, #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs= #=zvRLj9WQ=, int #=ze7ZtytQ=)
	{
		object @object = JSONManager.GetObject(#=zJ5GWysk=, #=zNraCe1Y=);
		if (@object != null)
		{
			int num;
			if (@object is IDictionary)
			{
				num = (@object as IDictionary).Count;
			}
			else if (@object is object[])
			{
				num = (@object as object[]).Length;
			}
			else
			{
				num = 0;
			}
			if (num > 0)
			{
				base.Add(new #=z7c3f2qXWcxmaz11o0HIoNIq39nWO(#=zvRLj9WQ=, 0, (double)#=ze7ZtytQ=));
			}
		}
	}
}
