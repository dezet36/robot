﻿using System;
using System.Collections.Generic;

// Token: 0x020001BC RID: 444
internal sealed class #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA== : List<#=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==>
{
	// Token: 0x06000D48 RID: 3400 RVA: 0x00068540 File Offset: 0x00066740
	public #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA==(Dictionary<string, object> #=z37QZzByLaZsZ)
	{
		if (#=z37QZzByLaZsZ != null)
		{
			foreach (object obj in #=z37QZzByLaZsZ.Values)
			{
				Dictionary<string, object> #=zbWbysAaKzDhE = (Dictionary<string, object>)obj;
				base.Add(new #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==(#=zbWbysAaKzDhE));
			}
		}
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x000685A8 File Offset: 0x000667A8
	public #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g== #=zk$6QZNA=(int #=z2KfQVwXUhuru, int #=z2Vvuf5o=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			#=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g== #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g== = base[i];
			if (#=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==.#=zLEh48lU$jhVz() == #=z2KfQVwXUhuru && #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==.#=zwTvtD4XPFdA4() == #=z2Vvuf5o=)
			{
				return #=ze_Lmuj3oJ8BobI493QfwlWKtMI15VEQf7g==;
			}
		}
		return null;
	}
}
