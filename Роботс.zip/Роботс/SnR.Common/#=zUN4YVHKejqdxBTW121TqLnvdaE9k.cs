﻿using System;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x020001B3 RID: 435
internal sealed class #=zUN4YVHKejqdxBTW121TqLnvdaE9k : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x06000D16 RID: 3350 RVA: 0x00067B4C File Offset: 0x00065D4C
	public #=zUN4YVHKejqdxBTW121TqLnvdaE9k(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		int @int = IntegerHelper.getInt(array[2], array[3]);
		int int2 = IntegerHelper.getInt(array[4], array[5]);
		this.#=zaknBcbE= = (double)@int + (double)int2 / 1024.0;
		int int3 = IntegerHelper.getInt(array[6], array[7]);
		int int4 = IntegerHelper.getInt(array[8], array[9]);
		this.#=zW9UfNlU= = (double)int3 + (double)int4 / 256.0;
		int int5 = IntegerHelper.getInt(array[10], array[11]);
		int int6 = IntegerHelper.getInt(array[12], array[13]);
		this.#=zkG0Mce4= = (double)int5 + (double)int6 / 1024.0;
		int int7 = IntegerHelper.getInt(array[14], array[15]);
		int int8 = IntegerHelper.getInt(array[16], array[17]);
		this.#=zI0kV8Ds= = (double)int7 + (double)int8 / 256.0;
	}

	// Token: 0x06000D17 RID: 3351 RVA: 0x00067C30 File Offset: 0x00065E30
	public #=zUN4YVHKejqdxBTW121TqLnvdaE9k(double #=zaknBcbE=, double #=zW9UfNlU=, double #=zkG0Mce4=, double #=zI0kV8Ds=) : base(EscherRecordType.CLIENT_ANCHOR)
	{
		this.#=zaknBcbE= = #=zaknBcbE=;
		this.#=zW9UfNlU= = #=zW9UfNlU=;
		this.#=zkG0Mce4= = #=zkG0Mce4=;
		this.#=zI0kV8Ds= = #=zI0kV8Ds=;
	}

	// Token: 0x06000D18 RID: 3352 RVA: 0x00067C5C File Offset: 0x00065E5C
	internal double #=z$waIkbE0FlsB()
	{
		return this.#=zaknBcbE=;
	}

	// Token: 0x06000D19 RID: 3353 RVA: 0x00067C64 File Offset: 0x00065E64
	internal double #=zqCs6ye7AziwC()
	{
		return this.#=zW9UfNlU=;
	}

	// Token: 0x06000D1A RID: 3354 RVA: 0x00067C6C File Offset: 0x00065E6C
	internal double #=zN2lKWAF_QOWa()
	{
		return this.#=zkG0Mce4=;
	}

	// Token: 0x06000D1B RID: 3355 RVA: 0x00067C74 File Offset: 0x00065E74
	internal double #=zv_B2pKpRtO4m()
	{
		return this.#=zI0kV8Ds=;
	}

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x06000D1C RID: 3356 RVA: 0x00067C7C File Offset: 0x00065E7C
	public override sbyte[] Data
	{
		get
		{
			this.#=zJ5GWysk= = new sbyte[18];
			IntegerHelper.getTwoBytes(2, this.#=zJ5GWysk=, 0);
			IntegerHelper.getTwoBytes((int)this.#=zaknBcbE=, this.#=zJ5GWysk=, 2);
			IntegerHelper.getTwoBytes((int)((this.#=zaknBcbE= - (double)((int)this.#=zaknBcbE=)) * 1024.0), this.#=zJ5GWysk=, 4);
			IntegerHelper.getTwoBytes((int)this.#=zW9UfNlU=, this.#=zJ5GWysk=, 6);
			IntegerHelper.getTwoBytes((int)((this.#=zW9UfNlU= - (double)((int)this.#=zW9UfNlU=)) * 256.0), this.#=zJ5GWysk=, 8);
			IntegerHelper.getTwoBytes((int)this.#=zkG0Mce4=, this.#=zJ5GWysk=, 10);
			IntegerHelper.getTwoBytes((int)((this.#=zkG0Mce4= - (double)((int)this.#=zkG0Mce4=)) * 1024.0), this.#=zJ5GWysk=, 12);
			IntegerHelper.getTwoBytes((int)this.#=zI0kV8Ds=, this.#=zJ5GWysk=, 14);
			IntegerHelper.getTwoBytes((int)((this.#=zI0kV8Ds= - (double)((int)this.#=zI0kV8Ds=)) * 256.0), this.#=zJ5GWysk=, 16);
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x04000792 RID: 1938
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x04000793 RID: 1939
	private double #=zaknBcbE=;

	// Token: 0x04000794 RID: 1940
	private double #=zW9UfNlU=;

	// Token: 0x04000795 RID: 1941
	private double #=zkG0Mce4=;

	// Token: 0x04000796 RID: 1942
	private double #=zI0kV8Ds=;
}
