﻿using System;
using System.Collections.Generic;

// Token: 0x020001FC RID: 508
internal sealed class #=zaMx8ko6bO$VKskpk3hkrQBbepuFJSOdvnaN32za0u7h6rpueXx3v52bNM$dhqFi4En413JE=
{
	// Token: 0x06000FA6 RID: 4006 RVA: 0x0007A4E4 File Offset: 0x000786E4
	public static List<#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==> #=zKNSug6s=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return new List<#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==>();
	}
}
