﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Units;

// Token: 0x0200019E RID: 414
internal sealed class #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==
{
	// Token: 0x06000C0D RID: 3085 RVA: 0x00062F0C File Offset: 0x0006110C
	public #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==()
	{
		this.#=zDn3d_$$N3duv(new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==());
		this.#=z0ZSI$2XjLdng(new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==());
		this.#=zX58ScsagA3OP(0);
		this.#=zkBVTMJSwgKB7ZIJdQw==(new #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zmDoC4t9zpHqa());
		this.#=z8cFRULU1GGytVB9Seg==(string.Empty);
		this.#=zbQYNwsZJXoW5QGpRN8cqD9qfkgqK(new int[5]);
		for (int i = 0; i < 5; i++)
		{
			this.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[i] = 0;
		}
		this.#=zswNGTNM5aX7hIuneRg==(0);
		this.#=zkYzAkaEUeymdzZrE05MmeJ8=(0);
		this.#=z2j8Xmu$NjacEsbfDJf$ZwtwsSg6Y(0);
		this.#=zcSfz6yWf4QB$bBMhg9H9JIw=(0);
		this.#=zb1Utr2uDdFE$hb3mFJcZ0bpOFY5RuBZqeA==(0);
		this.#=zWixFFaqFeJ3lwzX4zw==(0);
		this.#=z44CphetUzo78i93MjdjJglY=(0);
		this.#=z9kf4261P96texB1HBF1_nSM=(0);
		this.#=z1$rEfXZMoF4Ym$bZruZVweg=(0);
		this.#=zJjcm8lqjLI6rgxHprA==(new #=zD3QqiXZS0rGfIouxlaV9u5JKFmZkFOCHqw==());
		this.#=zzvuff1OIeXXkuojWcA==(new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==());
		this.#=zPbeZn1K$1Jh_5FaB500k0B8=(new #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==());
		this.#=zZNl43YkB6SF$aEhOJQ==(new #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=());
		this.#=zlCaAeSAgWoGx5bqr9VKUHrf1xVzu(new Dictionary<int, int>());
		this.#=zAKMeqAOLD2mHUaBSZA==(0);
		this.#=zPUB6vTocgBSz(new #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=());
		this.#=z1VGf2zlCX__XBAeySIKPBz8=(new #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==());
	}

	// Token: 0x06000C0E RID: 3086 RVA: 0x00063008 File Offset: 0x00061208
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z_tcU3ov4mZ9V()
	{
		return this.#=za_GZrBlIijB72VhfHg==;
	}

	// Token: 0x06000C0F RID: 3087 RVA: 0x00063010 File Offset: 0x00061210
	public void #=zDn3d_$$N3duv(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z$Ib9gYQ=)
	{
		this.#=za_GZrBlIijB72VhfHg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C10 RID: 3088 RVA: 0x0006301C File Offset: 0x0006121C
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zVgFk2IFQEXit()
	{
		return this.#=ztI_LzzHjaVgaTfy8PkqErqI=;
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x00063024 File Offset: 0x00061224
	public void #=z0ZSI$2XjLdng(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=z$Ib9gYQ=)
	{
		this.#=ztI_LzzHjaVgaTfy8PkqErqI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x00063030 File Offset: 0x00061230
	public int #=zS933gw03tLyr()
	{
		return this.#=zOkUv430IX$QUigoFoGzBUrQ=;
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x00063038 File Offset: 0x00061238
	public void #=zX58ScsagA3OP(int #=z$Ib9gYQ=)
	{
		this.#=zOkUv430IX$QUigoFoGzBUrQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C14 RID: 3092 RVA: 0x00063044 File Offset: 0x00061244
	public #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zmDoC4t9zpHqa #=z8MLrXqpSC$z2kv75$A==()
	{
		return this.#=zxKBc37keYNQPA3VbEhCDZ6o=;
	}

	// Token: 0x06000C15 RID: 3093 RVA: 0x0006304C File Offset: 0x0006124C
	public void #=zkBVTMJSwgKB7ZIJdQw==(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zmDoC4t9zpHqa #=z$Ib9gYQ=)
	{
		this.#=zxKBc37keYNQPA3VbEhCDZ6o= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x00063058 File Offset: 0x00061258
	public string #=zyiOd40BScdn01uJKRA==()
	{
		return this.#=zJwBvJh3qCzcYWrq8wIse5EyUw6s3;
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x00063060 File Offset: 0x00061260
	public void #=z8cFRULU1GGytVB9Seg==(string #=z$Ib9gYQ=)
	{
		this.#=zJwBvJh3qCzcYWrq8wIse5EyUw6s3 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x0006306C File Offset: 0x0006126C
	public int[] #=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()
	{
		return this.#=znQU0Zu3XRHyz9EmXUXLsR2wwPGITga4opDosVTU=;
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x00063074 File Offset: 0x00061274
	public void #=zbQYNwsZJXoW5QGpRN8cqD9qfkgqK(int[] #=z$Ib9gYQ=)
	{
		this.#=znQU0Zu3XRHyz9EmXUXLsR2wwPGITga4opDosVTU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C1A RID: 3098 RVA: 0x00063080 File Offset: 0x00061280
	public int #=zsdEnlvQfBDeIOQc4bg==()
	{
		return this.#=zYXS_sjdtntJ7A6KWvdxqW3s=;
	}

	// Token: 0x06000C1B RID: 3099 RVA: 0x00063088 File Offset: 0x00061288
	public void #=zswNGTNM5aX7hIuneRg==(int #=z$Ib9gYQ=)
	{
		this.#=zYXS_sjdtntJ7A6KWvdxqW3s= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C1C RID: 3100 RVA: 0x00063094 File Offset: 0x00061294
	public int #=zvlRkNe7UV2qeDYRtI8PSHhE=()
	{
		return this.#=z1M0yHXHU_sy$O6uymDRH0XmRLd97DBEEqw==;
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x0006309C File Offset: 0x0006129C
	public void #=zkYzAkaEUeymdzZrE05MmeJ8=(int #=z$Ib9gYQ=)
	{
		this.#=z1M0yHXHU_sy$O6uymDRH0XmRLd97DBEEqw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x000630A8 File Offset: 0x000612A8
	public int #=zIqugR6QOaNTtJEgBGqfk3xYb1PMe()
	{
		return this.#=zOJqocLTd7ft95$_BS8hfV1tEPJnMWSklozoKJeI=;
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x000630B0 File Offset: 0x000612B0
	public void #=z2j8Xmu$NjacEsbfDJf$ZwtwsSg6Y(int #=z$Ib9gYQ=)
	{
		this.#=zOJqocLTd7ft95$_BS8hfV1tEPJnMWSklozoKJeI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x000630BC File Offset: 0x000612BC
	public int #=zz0nG8agAb6T9FBYEQpohzzc=()
	{
		return this.#=zUFvfR5ZW$_qhufGsDA6YqfdxlV90ZE1dRg==;
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x000630C4 File Offset: 0x000612C4
	public void #=zcSfz6yWf4QB$bBMhg9H9JIw=(int #=z$Ib9gYQ=)
	{
		this.#=zUFvfR5ZW$_qhufGsDA6YqfdxlV90ZE1dRg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x000630D0 File Offset: 0x000612D0
	public int #=zeCfnpts4KBpp$nmnTfjEMlsCFfxFuVoDIA==()
	{
		return this.#=zZaUZ4nFDBWdpZ8$DqM0IYSDog10pfJ4pukTwxpo=;
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x000630D8 File Offset: 0x000612D8
	public void #=zb1Utr2uDdFE$hb3mFJcZ0bpOFY5RuBZqeA==(int #=z$Ib9gYQ=)
	{
		this.#=zZaUZ4nFDBWdpZ8$DqM0IYSDog10pfJ4pukTwxpo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C24 RID: 3108 RVA: 0x000630E4 File Offset: 0x000612E4
	public int #=zN$_0ciN4j1M9Es9_zg==()
	{
		return this.#=zmXZr9SzY7frvZkZ$gDnHr8w=;
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x000630EC File Offset: 0x000612EC
	public void #=zWixFFaqFeJ3lwzX4zw==(int #=z$Ib9gYQ=)
	{
		this.#=zmXZr9SzY7frvZkZ$gDnHr8w= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x000630F8 File Offset: 0x000612F8
	public int #=zRjoD_ziLkooIuukNQn3Lf7c=()
	{
		return this.#=zlhfYjX$Z5aEk60tCtH9WFFGTfA33;
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x00063100 File Offset: 0x00061300
	public void #=z44CphetUzo78i93MjdjJglY=(int #=z$Ib9gYQ=)
	{
		this.#=zlhfYjX$Z5aEk60tCtH9WFFGTfA33 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C28 RID: 3112 RVA: 0x0006310C File Offset: 0x0006130C
	public int #=zOTZUAC36s8y1ftdX7c1JuLQ=()
	{
		return this.#=zwaLCq2M9tbB0Nap5d7F_NxGEFIbY;
	}

	// Token: 0x06000C29 RID: 3113 RVA: 0x00063114 File Offset: 0x00061314
	public void #=z9kf4261P96texB1HBF1_nSM=(int #=z$Ib9gYQ=)
	{
		this.#=zwaLCq2M9tbB0Nap5d7F_NxGEFIbY = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C2A RID: 3114 RVA: 0x00063120 File Offset: 0x00061320
	public int #=zGWs2fahGtxAO3NnMGVZSK7g=()
	{
		return this.#=zLEoLluXhOks2EMRw$tTtYRpK2MdblhoPPw==;
	}

	// Token: 0x06000C2B RID: 3115 RVA: 0x00063128 File Offset: 0x00061328
	public void #=z1$rEfXZMoF4Ym$bZruZVweg=(int #=z$Ib9gYQ=)
	{
		this.#=zLEoLluXhOks2EMRw$tTtYRpK2MdblhoPPw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C2C RID: 3116 RVA: 0x00063134 File Offset: 0x00061334
	public #=zD3QqiXZS0rGfIouxlaV9u5JKFmZkFOCHqw== #=zdz_5DLjhAG09Q78wOA==()
	{
		return this.#=zWLFBC0o5hlOyLt9qO5$Co$bgvsC2;
	}

	// Token: 0x06000C2D RID: 3117 RVA: 0x0006313C File Offset: 0x0006133C
	public void #=zJjcm8lqjLI6rgxHprA==(#=zD3QqiXZS0rGfIouxlaV9u5JKFmZkFOCHqw== #=z$Ib9gYQ=)
	{
		this.#=zWLFBC0o5hlOyLt9qO5$Co$bgvsC2 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C2E RID: 3118 RVA: 0x00063148 File Offset: 0x00061348
	public #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zNnx4xxtx9xYwefJwdg==()
	{
		return this.#=zDyuAvNYeLlJyJWr3rMn$jwxULYvJ;
	}

	// Token: 0x06000C2F RID: 3119 RVA: 0x00063150 File Offset: 0x00061350
	public void #=zzvuff1OIeXXkuojWcA==(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z$Ib9gYQ=)
	{
		this.#=zDyuAvNYeLlJyJWr3rMn$jwxULYvJ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C30 RID: 3120 RVA: 0x0006315C File Offset: 0x0006135C
	public #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zS96aE1JwlopY1ifRovTglSw=()
	{
		return this.#=zTYKeQXiP0eQCmeVf3jPH9Jr3bNAcGFCiPw==;
	}

	// Token: 0x06000C31 RID: 3121 RVA: 0x00063164 File Offset: 0x00061364
	public void #=zPbeZn1K$1Jh_5FaB500k0B8=(#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=z$Ib9gYQ=)
	{
		this.#=zTYKeQXiP0eQCmeVf3jPH9Jr3bNAcGFCiPw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C32 RID: 3122 RVA: 0x00063170 File Offset: 0x00061370
	public #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zTbkv095gWozyg_xVnw==()
	{
		return this.#=zrdKWqP15HY6UZtIu4IvJYuI=;
	}

	// Token: 0x06000C33 RID: 3123 RVA: 0x00063178 File Offset: 0x00061378
	public void #=zZNl43YkB6SF$aEhOJQ==(#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=z$Ib9gYQ=)
	{
		this.#=zrdKWqP15HY6UZtIu4IvJYuI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C34 RID: 3124 RVA: 0x00063184 File Offset: 0x00061384
	public Dictionary<int, int> #=zc4t_BNE$BmXcFL6b6tKvb_sJsoUj()
	{
		return this.#=zJEuMVY9qWra8q22xiGeBfzK4d6hBiCZ3_kWpZnA=;
	}

	// Token: 0x06000C35 RID: 3125 RVA: 0x0006318C File Offset: 0x0006138C
	public void #=zlCaAeSAgWoGx5bqr9VKUHrf1xVzu(Dictionary<int, int> #=z$Ib9gYQ=)
	{
		this.#=zJEuMVY9qWra8q22xiGeBfzK4d6hBiCZ3_kWpZnA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C36 RID: 3126 RVA: 0x00063198 File Offset: 0x00061398
	public int #=z9Jm$ne_kr_H5D_R8UQ==()
	{
		return this.#=zob1b5ptZWbRPgJTd08z8GIQ=;
	}

	// Token: 0x06000C37 RID: 3127 RVA: 0x000631A0 File Offset: 0x000613A0
	public void #=zAKMeqAOLD2mHUaBSZA==(int #=z$Ib9gYQ=)
	{
		this.#=zob1b5ptZWbRPgJTd08z8GIQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C38 RID: 3128 RVA: 0x000631AC File Offset: 0x000613AC
	public #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zqOzsq_ebYcIC()
	{
		return this.#=zy_958MoVO170mlThfnf5dSQ=;
	}

	// Token: 0x06000C39 RID: 3129 RVA: 0x000631B4 File Offset: 0x000613B4
	public void #=zPUB6vTocgBSz(#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=z$Ib9gYQ=)
	{
		this.#=zy_958MoVO170mlThfnf5dSQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C3A RID: 3130 RVA: 0x000631C0 File Offset: 0x000613C0
	public #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zG95DTZntR2nRriTBdb76SEs=()
	{
		return this.#=zWKFPKQrDbv7dNJXvBWNuLfh9ZolhMM1NOg==;
	}

	// Token: 0x06000C3B RID: 3131 RVA: 0x000631C8 File Offset: 0x000613C8
	public void #=z1VGf2zlCX__XBAeySIKPBz8=(#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=z$Ib9gYQ=)
	{
		this.#=zWKFPKQrDbv7dNJXvBWNuLfh9ZolhMM1NOg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C3C RID: 3132 RVA: 0x000631D4 File Offset: 0x000613D4
	public void #=zLikmsNA=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA== #=zNhLzguI=)
	{
		this.#=z_tcU3ov4mZ9V().#=z48rEd0A=(#=zNhLzguI=.#=z_tcU3ov4mZ9V());
		this.#=z8MLrXqpSC$z2kv75$A==().#=z48rEd0A=(#=zNhLzguI=.#=z8MLrXqpSC$z2kv75$A==());
		for (int i = 0; i < 5; i++)
		{
			this.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[i] += #=zNhLzguI=.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[i];
		}
		this.#=zswNGTNM5aX7hIuneRg==(this.#=zsdEnlvQfBDeIOQc4bg==() + #=zNhLzguI=.#=zsdEnlvQfBDeIOQc4bg==());
		this.#=zkYzAkaEUeymdzZrE05MmeJ8=(this.#=zvlRkNe7UV2qeDYRtI8PSHhE=() + #=zNhLzguI=.#=zvlRkNe7UV2qeDYRtI8PSHhE=());
		this.#=z2j8Xmu$NjacEsbfDJf$ZwtwsSg6Y(this.#=zIqugR6QOaNTtJEgBGqfk3xYb1PMe() + #=zNhLzguI=.#=zIqugR6QOaNTtJEgBGqfk3xYb1PMe());
		this.#=zcSfz6yWf4QB$bBMhg9H9JIw=(this.#=zz0nG8agAb6T9FBYEQpohzzc=() + #=zNhLzguI=.#=zz0nG8agAb6T9FBYEQpohzzc=());
		this.#=zb1Utr2uDdFE$hb3mFJcZ0bpOFY5RuBZqeA==(this.#=zeCfnpts4KBpp$nmnTfjEMlsCFfxFuVoDIA==() + #=zNhLzguI=.#=zeCfnpts4KBpp$nmnTfjEMlsCFfxFuVoDIA==());
		this.#=zWixFFaqFeJ3lwzX4zw==(this.#=zN$_0ciN4j1M9Es9_zg==() + #=zNhLzguI=.#=zN$_0ciN4j1M9Es9_zg==());
		this.#=z44CphetUzo78i93MjdjJglY=(this.#=zRjoD_ziLkooIuukNQn3Lf7c=() + #=zNhLzguI=.#=zRjoD_ziLkooIuukNQn3Lf7c=());
		this.#=z9kf4261P96texB1HBF1_nSM=(this.#=zOTZUAC36s8y1ftdX7c1JuLQ=() + #=zNhLzguI=.#=zOTZUAC36s8y1ftdX7c1JuLQ=());
		this.#=z1$rEfXZMoF4Ym$bZruZVweg=(this.#=zGWs2fahGtxAO3NnMGVZSK7g=() + #=zNhLzguI=.#=zGWs2fahGtxAO3NnMGVZSK7g=());
	}

	// Token: 0x06000C3D RID: 3133 RVA: 0x000632D4 File Offset: 0x000614D4
	public void #=zsRV1Asc=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		try
		{
			if (#=zuJjQ1XU=.#=z_tcU3ov4mZ9V().Count != 0)
			{
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC();
				this.#=zDn3d_$$N3duv(#=zuJjQ1XU=.#=z_tcU3ov4mZ9V().#=zmTCxtJo=());
				this.#=zkYzAkaEUeymdzZrE05MmeJ8=(this.#=z_tcU3ov4mZ9V()[ResourceTypes.GeneralsCurrency]);
				this.#=zVgFk2IFQEXit().Clear();
				if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zKatp2kKFbWctd3l7feJusRE=())
				{
					foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= in #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=().Values)
					{
						if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)2010)
						{
							int #=zNvCMwussKumm = (int)#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zjw43QGFcPyHH() * #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
							this.#=zVgFk2IFQEXit().#=z48rEd0A=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zQ4pGtq_Ng_rixBGQrQ==(), #=zNvCMwussKumm);
						}
					}
				}
				UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
				UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
				unitSquadCollection.AddUnits(#=zuJjQ1XU=.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru());
				#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== = new #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==();
				bool flag = false;
				foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==())
				{
					if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
					{
						unitSquadCollection.AddUnits(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD());
						if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zK0Bl_aLmVIcfjen9YvGM2N2U4PVP7Hbgng==() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() != #=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zL4D9WC8RTH921DofgQ==() == DateTime.MinValue)
						{
							int totalNumber = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD().TotalNumber;
							if (totalNumber > 1)
							{
								if (this.#=zG95DTZntR2nRriTBdb76SEs=().ContainsKey(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()))
								{
									#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ== = this.#=zG95DTZntR2nRriTBdb76SEs=()[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()];
									if (#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zlIXJ9$NfUZc_() == totalNumber)
									{
										#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()] = #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==;
									}
									else
									{
										#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()] = new #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==(#=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zK5gF1KeGk_H_(), #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zuFPZLKs=(), #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==.#=zzasQXAPWhOif(), totalNumber);
									}
								}
								else
								{
									if (!flag)
									{
										#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zXmgq7Yr_4ykr(#=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==());
										flag = true;
									}
									if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zuFPZLKs=() != null)
									{
										#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==[#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_()] = new #=z$qIFYW8lQItMMNKSVUCEw4aG29dyrRzMpQ==(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==, totalNumber);
									}
								}
							}
						}
					}
				}
				if (#=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==().Count > 0)
				{
					this.#=z1VGf2zlCX__XBAeySIKPBz8=(#=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw==);
				}
				this.#=z8MLrXqpSC$z2kv75$A==().#=zm7nSMZ8=();
				foreach (UnitSquad unitSquad in unitSquadCollection)
				{
					this.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(unitSquad.Type.Class, unitSquad.Type.Function).#=ziX3HUTg=(unitSquad.Number);
				}
				this.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(UnitType.Classes.Rocket, UnitType.Functions.Offence).#=zAdbC0svu$p0C(#=zuJjQ1XU=.#=zgRq0Ty7BhBO543uVxmeuTso=());
				foreach (#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= #=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk= in #=zuJjQ1XU=.#=zOo2ORcNoE4PzlDAS9fQ8Rc8=().Values)
				{
					UnitType unitType = unitTypeCollection.Find(#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=zFMDiymuLQ7_4());
					if (unitType != null)
					{
						this.#=z8MLrXqpSC$z2kv75$A==().#=ziI7GJ5Q=(unitType.Class, unitType.Function).#=z65MYjTey3P0m(#=zVA17M_fK1QsqV7HiAbWewoQ5Gmp3mycf9do$$Fk=.#=zBHuoQg9JVxim());
					}
				}
				foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==())
				{
					if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4() == 107)
					{
						this.#=z8cFRULU1GGytVB9Seg==(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du().ToString());
					}
				}
				if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zQmMP6wt1RftoX0jGx5VWOLw=())
				{
					#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU = #=zuJjQ1XU=.#=zdz_5DLjhAG09Q78wOA==();
					for (int i = 0; i < 5; i++)
					{
						this.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[i] = 0;
					}
					for (int j = 0; j < #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Count; j++)
					{
						int num = #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU[j].#=zaKAy47_E$9SRuF6oiw==();
						if (num >= 1 && num <= 5)
						{
							this.#=zZglIUFRqp6xHo1B9c6H9qgfBfBoA()[num - 1]++;
						}
					}
					#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
					this.#=zswNGTNM5aX7hIuneRg==(#=zuJjQ1XU=.#=zK2B3D5hNXDwHR1pT1hpYeOQ=());
					this.#=z2j8Xmu$NjacEsbfDJf$ZwtwsSg6Y(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17000));
					this.#=zcSfz6yWf4QB$bBMhg9H9JIw=(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17001));
					this.#=zb1Utr2uDdFE$hb3mFJcZ0bpOFY5RuBZqeA==(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17002));
					this.#=zWixFFaqFeJ3lwzX4zw==(#=zuJjQ1XU=.#=zN$_0ciN4j1M9Es9_zg==());
					this.#=z44CphetUzo78i93MjdjJglY=(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17007));
					this.#=z9kf4261P96texB1HBF1_nSM=(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17006));
					this.#=z1$rEfXZMoF4Ym$bZruZVweg=(#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z2cw4dd0=(17010));
					this.#=zdz_5DLjhAG09Q78wOA==().#=z20ohAjI=(#=zuJjQ1XU=.#=zdz_5DLjhAG09Q78wOA==());
				}
				if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zOfJCiJK$ZVVkuth4jDES0lb35dZpcHbrSQ==())
				{
					this.#=zzvuff1OIeXXkuojWcA==(#=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==());
					this.#=zPbeZn1K$1Jh_5FaB500k0B8=(#=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=());
					this.#=zZNl43YkB6SF$aEhOJQ==(#=zuJjQ1XU=.#=zTbkv095gWozyg_xVnw==());
					if (#=zuJjQ1XU=.#=zld8y4Nc63Ecs5jIAkxY9QS4=().#=zwA$pC4$kvy0a())
					{
						this.#=zlCaAeSAgWoGx5bqr9VKUHrf1xVzu(#=zuJjQ1XU=.#=zld8y4Nc63Ecs5jIAkxY9QS4=().#=zluiMMMrmz25htA87Ew==());
					}
					this.#=zAKMeqAOLD2mHUaBSZA==(#=zuJjQ1XU=.#=z9Jm$ne_kr_H5D_R8UQ==());
				}
				if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zKatp2kKFbWctd3l7feJusRE=())
				{
					this.#=zPUB6vTocgBSz(#=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==());
				}
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zY$pvpstqHPJzppOpm5pa2HJPtuI4(#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B(), #=zuJjQ1XU=.#=zQ4wZnctPyyRO(), #=zuJjQ1XU=.#=z$2ijYGRf0FB5());
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zuJjQ1XU=.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
		}
	}

	// Token: 0x04000706 RID: 1798
	private #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=za_GZrBlIijB72VhfHg==;

	// Token: 0x04000707 RID: 1799
	private #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=ztI_LzzHjaVgaTfy8PkqErqI=;

	// Token: 0x04000708 RID: 1800
	private int #=zOkUv430IX$QUigoFoGzBUrQ=;

	// Token: 0x04000709 RID: 1801
	private #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zmDoC4t9zpHqa #=zxKBc37keYNQPA3VbEhCDZ6o=;

	// Token: 0x0400070A RID: 1802
	private string #=zJwBvJh3qCzcYWrq8wIse5EyUw6s3;

	// Token: 0x0400070B RID: 1803
	private int[] #=znQU0Zu3XRHyz9EmXUXLsR2wwPGITga4opDosVTU=;

	// Token: 0x0400070C RID: 1804
	private int #=zYXS_sjdtntJ7A6KWvdxqW3s=;

	// Token: 0x0400070D RID: 1805
	private int #=z1M0yHXHU_sy$O6uymDRH0XmRLd97DBEEqw==;

	// Token: 0x0400070E RID: 1806
	private int #=zOJqocLTd7ft95$_BS8hfV1tEPJnMWSklozoKJeI=;

	// Token: 0x0400070F RID: 1807
	private int #=zUFvfR5ZW$_qhufGsDA6YqfdxlV90ZE1dRg==;

	// Token: 0x04000710 RID: 1808
	private int #=zZaUZ4nFDBWdpZ8$DqM0IYSDog10pfJ4pukTwxpo=;

	// Token: 0x04000711 RID: 1809
	private int #=zmXZr9SzY7frvZkZ$gDnHr8w=;

	// Token: 0x04000712 RID: 1810
	private int #=zlhfYjX$Z5aEk60tCtH9WFFGTfA33;

	// Token: 0x04000713 RID: 1811
	private int #=zwaLCq2M9tbB0Nap5d7F_NxGEFIbY;

	// Token: 0x04000714 RID: 1812
	private int #=zLEoLluXhOks2EMRw$tTtYRpK2MdblhoPPw==;

	// Token: 0x04000715 RID: 1813
	private #=zD3QqiXZS0rGfIouxlaV9u5JKFmZkFOCHqw== #=zWLFBC0o5hlOyLt9qO5$Co$bgvsC2;

	// Token: 0x04000716 RID: 1814
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zDyuAvNYeLlJyJWr3rMn$jwxULYvJ;

	// Token: 0x04000717 RID: 1815
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zTYKeQXiP0eQCmeVf3jPH9Jr3bNAcGFCiPw==;

	// Token: 0x04000718 RID: 1816
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zrdKWqP15HY6UZtIu4IvJYuI=;

	// Token: 0x04000719 RID: 1817
	private Dictionary<int, int> #=zJEuMVY9qWra8q22xiGeBfzK4d6hBiCZ3_kWpZnA=;

	// Token: 0x0400071A RID: 1818
	private int #=zob1b5ptZWbRPgJTd08z8GIQ=;

	// Token: 0x0400071B RID: 1819
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zy_958MoVO170mlThfnf5dSQ=;

	// Token: 0x0400071C RID: 1820
	private #=zhMUDmfuWkgnBmf8irHYx29v5DsgVqENmaw== #=zWKFPKQrDbv7dNJXvBWNuLfh9ZolhMM1NOg==;

	// Token: 0x0200019F RID: 415
	internal sealed class #=zQeDBKSB$s0kh0h_1pg==
	{
		// Token: 0x06000C3E RID: 3134 RVA: 0x000638B8 File Offset: 0x00061AB8
		public #=zQeDBKSB$s0kh0h_1pg==()
		{
			this.#=zAdbC0svu$p0C(0);
			this.#=zCnV9OIfF0ZBQLYDtGQ==(0);
		}

		// Token: 0x06000C3F RID: 3135 RVA: 0x000638D0 File Offset: 0x00061AD0
		public int #=zXnLDg7kAwVWx()
		{
			return this.#=zVz7quZJ1kaMwhBfBqw==;
		}

		// Token: 0x06000C40 RID: 3136 RVA: 0x000638D8 File Offset: 0x00061AD8
		public void #=zAdbC0svu$p0C(int #=z$Ib9gYQ=)
		{
			this.#=zVz7quZJ1kaMwhBfBqw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000C41 RID: 3137 RVA: 0x000638E4 File Offset: 0x00061AE4
		public int #=zmo5ghO3ieFGdSjD7kA==()
		{
			return this.#=zPtsD6veT2NVBDPcQkefFJms=;
		}

		// Token: 0x06000C42 RID: 3138 RVA: 0x000638EC File Offset: 0x00061AEC
		public void #=zCnV9OIfF0ZBQLYDtGQ==(int #=z$Ib9gYQ=)
		{
			this.#=zPtsD6veT2NVBDPcQkefFJms= = #=z$Ib9gYQ=;
		}

		// Token: 0x06000C43 RID: 3139 RVA: 0x000638F8 File Offset: 0x00061AF8
		public void #=z48rEd0A=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=z326x4zk=)
		{
			this.#=zAdbC0svu$p0C(this.#=zXnLDg7kAwVWx() + #=z326x4zk=.#=zXnLDg7kAwVWx());
			this.#=zCnV9OIfF0ZBQLYDtGQ==(this.#=zmo5ghO3ieFGdSjD7kA==() + #=z326x4zk=.#=zmo5ghO3ieFGdSjD7kA==());
		}

		// Token: 0x06000C44 RID: 3140 RVA: 0x00063920 File Offset: 0x00061B20
		public void #=ziX3HUTg=(int #=z326x4zk=)
		{
			this.#=zAdbC0svu$p0C(this.#=zXnLDg7kAwVWx() + #=z326x4zk=);
		}

		// Token: 0x06000C45 RID: 3141 RVA: 0x00063930 File Offset: 0x00061B30
		public void #=z65MYjTey3P0m(int #=z326x4zk=)
		{
			this.#=zCnV9OIfF0ZBQLYDtGQ==(this.#=zmo5ghO3ieFGdSjD7kA==() + #=z326x4zk=);
		}

		// Token: 0x0400071D RID: 1821
		private int #=zVz7quZJ1kaMwhBfBqw==;

		// Token: 0x0400071E RID: 1822
		private int #=zPtsD6veT2NVBDPcQkefFJms=;
	}

	// Token: 0x020001A0 RID: 416
	[DefaultMember("Item")]
	internal sealed class #=zmDoC4t9zpHqa
	{
		// Token: 0x06000C46 RID: 3142 RVA: 0x00063940 File Offset: 0x00061B40
		public #=zmDoC4t9zpHqa()
		{
			this.#=z9HdGFQI= = new Dictionary<int, #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg==>();
		}

		// Token: 0x06000C47 RID: 3143 RVA: 0x00063954 File Offset: 0x00061B54
		public #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=ziI7GJ5Q=(UnitType.Classes #=zCbzrivcBDHRo, UnitType.Functions #=zMpM8dfw=)
		{
			return this.#=ziI7GJ5Q=((int)(#=zCbzrivcBDHRo * (UnitType.Classes)100 + (int)#=zMpM8dfw=));
		}

		// Token: 0x06000C48 RID: 3144 RVA: 0x00063964 File Offset: 0x00061B64
		public #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=ziI7GJ5Q=(int #=zKJA8IWQ=)
		{
			if (this.#=z9HdGFQI=.ContainsKey(#=zKJA8IWQ=))
			{
				return this.#=z9HdGFQI=[#=zKJA8IWQ=];
			}
			#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg== #=zQeDBKSB$s0kh0h_1pg== = new #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg==();
			this.#=z9HdGFQI=.Add(#=zKJA8IWQ=, #=zQeDBKSB$s0kh0h_1pg==);
			return #=zQeDBKSB$s0kh0h_1pg==;
		}

		// Token: 0x06000C49 RID: 3145 RVA: 0x000639A0 File Offset: 0x00061BA0
		public void #=z48rEd0A=(#=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zmDoC4t9zpHqa #=z326x4zk=)
		{
			foreach (int #=zKJA8IWQ= in #=z326x4zk=.#=z9HdGFQI=.Keys)
			{
				this.#=ziI7GJ5Q=(#=zKJA8IWQ=).#=z48rEd0A=(#=z326x4zk=.#=ziI7GJ5Q=(#=zKJA8IWQ=));
			}
		}

		// Token: 0x06000C4A RID: 3146 RVA: 0x00063A04 File Offset: 0x00061C04
		public void #=zm7nSMZ8=()
		{
			this.#=z9HdGFQI=.Clear();
		}

		// Token: 0x0400071F RID: 1823
		private Dictionary<int, #=zSOFNWijOtky0oxgcXH1kF6tYGJ9Opvr1yA==.#=zQeDBKSB$s0kh0h_1pg==> #=z9HdGFQI=;
	}
}
