﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x020000AC RID: 172
internal sealed class #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==
{
	// Token: 0x06000481 RID: 1153 RVA: 0x00026008 File Offset: 0x00024208
	public #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==(Dictionary<string, object> #=zaPDIgPVIJwMc6DcAuA==)
	{
		this.#=zJPR1D4vj4Ojo = new Dictionary<string, string>();
		if (#=zaPDIgPVIJwMc6DcAuA== != null)
		{
			foreach (KeyValuePair<string, object> keyValuePair in #=zaPDIgPVIJwMc6DcAuA==)
			{
				object[] array = (object[])keyValuePair.Value;
				if (array != null)
				{
					foreach (string key in array)
					{
						this.#=zJPR1D4vj4Ojo[key] = keyValuePair.Key;
					}
				}
			}
		}
		this.#=zENpef7zKxTXwAy7Wo_QzcJ8= = new List<string>();
		this.#=za2nTHzhJsK$qYZLV8bofB2E= = DateTime.MinValue;
		this.#=zMbiaD7V1e8A2_UJ6dqaR6iM= = DateTime.MinValue;
		this.#=zYe83cMfoP44Y4anSEkjbris= = DateTime.MinValue;
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x000260D0 File Offset: 0x000242D0
	public Dictionary<string, object> #=zHTvXKUY=()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		foreach (KeyValuePair<string, string> keyValuePair in this.#=zJPR1D4vj4Ojo)
		{
			if (dictionary.ContainsKey(keyValuePair.Value))
			{
				dictionary[keyValuePair.Value].Add(keyValuePair.Key);
			}
			else
			{
				dictionary[keyValuePair.Value] = new List<string>
				{
					keyValuePair.Key
				};
			}
		}
		Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
		foreach (KeyValuePair<string, List<string>> keyValuePair2 in dictionary)
		{
			object[] array = new object[keyValuePair2.Value.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = keyValuePair2.Value[i];
			}
			dictionary2[keyValuePair2.Key] = array;
		}
		return dictionary2;
	}

	// Token: 0x06000483 RID: 1155 RVA: 0x000261EC File Offset: 0x000243EC
	private static string #=z8FwXRs9sVOGt(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		return #=z8StzeqE=.#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe();
	}

	// Token: 0x06000484 RID: 1156 RVA: 0x000261FC File Offset: 0x000243FC
	private static string #=ziUsbeuuW$Pcl(ProxyInfo #=zsHG$Y6w=)
	{
		return #=zsHG$Y6w=.ProxyKey;
	}

	// Token: 0x06000485 RID: 1157 RVA: 0x00026204 File Offset: 0x00024404
	public bool #=zg6ifiug=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, ProxyInfo #=zsHG$Y6w=, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zl$4PvuuQiEl5, out bool #=zGBbGrXiYmpIccXm1sQ==)
	{
		string text = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z8FwXRs9sVOGt(#=z8StzeqE=);
		string b = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zsHG$Y6w=);
		bool flag;
		if (this.#=zJPR1D4vj4Ojo.ContainsKey(text))
		{
			flag = (this.#=zJPR1D4vj4Ojo[text] == b);
		}
		else
		{
			#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zbjP7ZBivanWUvybn8iffczU= #=zbjP7ZBivanWUvybn8iffczU= = new #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zbjP7ZBivanWUvybn8iffczU=();
			#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== = new #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==();
			#=zbjP7ZBivanWUvybn8iffczU=.#=z9Z3H0wUaslGm = new Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>>();
			List<string> #=zGBv9vvB23PwT = new List<string>();
			this.#=zmqnFwZHn2k2reNCl1g==(#=zl$4PvuuQiEl5, #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==, #=zbjP7ZBivanWUvybn8iffczU=.#=z9Z3H0wUaslGm, #=zGBv9vvB23PwT);
			#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Sort(new Comparison<ProxyInfo>(#=zbjP7ZBivanWUvybn8iffczU=.#=zRCQj2IpKoT58gfuIcA==));
			string text2 = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1]);
			this.#=zJPR1D4vj4Ojo[text] = text2;
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942088), new object[]
			{
				#=z8StzeqE=.#=zdEt_WRHpdEMmGTK_3Q==(),
				text2
			});
			flag = (text2 == b);
		}
		if (flag && #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zSDzL$lsR3vYFW9AP7Wibl1x6NGFq() && this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Contains(text))
		{
			#=zGBbGrXiYmpIccXm1sQ== = true;
			this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Remove(text);
		}
		else
		{
			#=zGBbGrXiYmpIccXm1sQ== = false;
		}
		return flag;
	}

	// Token: 0x06000486 RID: 1158 RVA: 0x00026318 File Offset: 0x00024518
	public void #=zhqOtDQRSXQg8Qo8gmM6zXIg=(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zEhGRLRSSQTM3nxmPHQ==)
	{
		#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z64GoslHWKG7eUA2yrYgyGf4= #=z64GoslHWKG7eUA2yrYgyGf4= = new #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z64GoslHWKG7eUA2yrYgyGf4=();
		if (this.#=za2nTHzhJsK$qYZLV8bofB2E= > DateTime.Now || this.#=zYe83cMfoP44Y4anSEkjbris= > DateTime.Now || this.#=zMbiaD7V1e8A2_UJ6dqaR6iM= + TimeSpan.FromMinutes((double)#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zHXf6R08vedD$hfpwG5Ci3WE=()) > DateTime.Now)
		{
			return;
		}
		this.#=za2nTHzhJsK$qYZLV8bofB2E= = DateTime.Now + TimeSpan.FromMinutes(1.0);
		#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== = new #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==();
		#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm = new Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>>();
		List<string> list = new List<string>();
		this.#=zmqnFwZHn2k2reNCl1g==(#=zEhGRLRSSQTM3nxmPHQ==, #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==, #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm, list);
		if (#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count == 0)
		{
			return;
		}
		if (#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count > 1 || list.Count > 0)
		{
			#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Sort(new Comparison<ProxyInfo>(#=z64GoslHWKG7eUA2yrYgyGf4=.#=zUMytavOuP$J0iHU9H8Yma2V9k7$KDebPtw==));
			int num = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[0], #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm);
			int num2 = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1], #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm);
			if (((num2 > 0) ? ((double)(num / num2) > 2.0) : (num > 1)) || list.Count > 0)
			{
				if (this.#=zYe83cMfoP44Y4anSEkjbris= == DateTime.MinValue)
				{
					if (list.Count > 0)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942298), new object[]
						{
							list.Count,
							5
						});
					}
					if ((num2 > 0) ? ((double)(num / num2) > 2.0) : (num > 1))
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942228), new object[]
						{
							num2,
							num,
							5
						});
					}
					this.#=zYe83cMfoP44Y4anSEkjbris= = DateTime.Now + TimeSpan.FromMinutes(5.0);
					return;
				}
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=z9tn1xKU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941879), new object[]
				{
					#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count,
					this.#=zJPR1D4vj4Ojo.Count
				});
				while (list.Count > 0)
				{
					#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zLzCFKykd0blCBjZJ0ZZDOiA= #=zLzCFKykd0blCBjZJ0ZZDOiA= = new #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zLzCFKykd0blCBjZJ0ZZDOiA=();
					#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=zu1EBJkQ= = list[0];
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = #=zEhGRLRSSQTM3nxmPHQ==.Find(new Predicate<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>(#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=z1p8TQrDCKZtyqrGLR9_7Qp6BW0mvkEjmYQ==));
					if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== != null)
					{
						string text = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1]);
						if (this.#=zJPR1D4vj4Ojo.ContainsKey(#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=zu1EBJkQ=) && #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zSDzL$lsR3vYFW9AP7Wibl1x6NGFq() && !this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Contains(#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=zu1EBJkQ=))
						{
							this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Add(#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=zu1EBJkQ=);
						}
						this.#=zJPR1D4vj4Ojo[#=zLzCFKykd0blCBjZJ0ZZDOiA=.#=zu1EBJkQ=] = text;
						if (#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm.ContainsKey(text))
						{
							#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm[text].Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==);
						}
						else
						{
							#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm[text] = new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>
							{
								#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==
							};
						}
						List<ProxyInfo> list2 = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==;
						Comparison<ProxyInfo> comparison;
						if ((comparison = #=z64GoslHWKG7eUA2yrYgyGf4=.#=zkDQnIvLlnqrP) == null)
						{
							comparison = (#=z64GoslHWKG7eUA2yrYgyGf4=.#=zkDQnIvLlnqrP = new Comparison<ProxyInfo>(#=z64GoslHWKG7eUA2yrYgyGf4=.#=zqXQhGp5Y46k$wu7tZGca9YrNyr5nxpwOpg==));
						}
						list2.Sort(comparison);
					}
					list.RemoveAt(0);
				}
				while (num - num2 > 1)
				{
					ProxyInfo #=zsHG$Y6w= = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[0];
					ProxyInfo #=zsHG$Y6w=2 = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1];
					string key = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zsHG$Y6w=);
					string text2 = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zsHG$Y6w=2);
					List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list3 = #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm[key];
					List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list4;
					if (#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm.ContainsKey(text2))
					{
						list4 = #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm[text2];
					}
					else
					{
						list4 = new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>();
						#=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm[text2] = list4;
					}
					#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2 = list3[list3.Count - 1];
					list3.RemoveAt(list3.Count - 1);
					list4.Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2);
					string text3 = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z8FwXRs9sVOGt(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==2.#=zol80P7TKoihZ()[0]);
					if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zSDzL$lsR3vYFW9AP7Wibl1x6NGFq() && !this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Contains(text3))
					{
						this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Add(text3);
					}
					this.#=zJPR1D4vj4Ojo[text3] = text2;
					List<ProxyInfo> list5 = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==;
					Comparison<ProxyInfo> comparison2;
					if ((comparison2 = #=z64GoslHWKG7eUA2yrYgyGf4=.#=zCopSF6f7KYgs) == null)
					{
						comparison2 = (#=z64GoslHWKG7eUA2yrYgyGf4=.#=zCopSF6f7KYgs = new Comparison<ProxyInfo>(#=z64GoslHWKG7eUA2yrYgyGf4=.#=zj6be1sBQC0i1gyIumDFkgukGA2Fm6HoA2g==));
					}
					list5.Sort(comparison2);
					num = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[0], #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm);
					num2 = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count - 1], #=z64GoslHWKG7eUA2yrYgyGf4=.#=z9Z3H0wUaslGm);
				}
				this.#=zMbiaD7V1e8A2_UJ6dqaR6iM= = DateTime.Now;
				this.#=zYe83cMfoP44Y4anSEkjbris= = DateTime.MinValue;
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zJWtlXjI=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942078), Array.Empty<object>());
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zknIUyoRVNcX2().#=zLyaSD5E=(null, JSONManager.SerializeData(this.#=zHTvXKUY=()), Array.Empty<object>());
			}
		}
	}

	// Token: 0x06000487 RID: 1159 RVA: 0x00026804 File Offset: 0x00024A04
	private void #=zmqnFwZHn2k2reNCl1g==(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zEhGRLRSSQTM3nxmPHQ==, #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=znnXBdi4Pp2to, Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>> #=z9Z3H0wUaslGm, List<string> #=zGBv9vvB23PwT)
	{
		#=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ== = ProxyInfo.#=zn2ovxJQcP5BV();
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		for (int i = 0; i < #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==.Count; i++)
		{
			ProxyInfo proxyInfo = #=zWirpFTin9dF2QJ5VorQ0pR4P_C5B5zFreQ==[i];
			if (proxyInfo.State == ProxyStates.Ok)
			{
				#=znnXBdi4Pp2to.#=z48rEd0A=(proxyInfo);
				string text = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(proxyInfo);
				list.Add(text);
				List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list3 = new List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>();
				for (int j = 0; j < #=zEhGRLRSSQTM3nxmPHQ==.Count; j++)
				{
					if (#=zEhGRLRSSQTM3nxmPHQ==[j].#=zol80P7TKoihZ().Count > 0)
					{
						string key = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z8FwXRs9sVOGt(#=zEhGRLRSSQTM3nxmPHQ==[j].#=zol80P7TKoihZ()[0]);
						if (this.#=zJPR1D4vj4Ojo.ContainsKey(key) && this.#=zJPR1D4vj4Ojo[key] == text)
						{
							list3.Add(#=zEhGRLRSSQTM3nxmPHQ==[j]);
						}
					}
				}
				#=z9Z3H0wUaslGm[text] = list3;
			}
			else
			{
				list2.Add(#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(proxyInfo));
			}
		}
		List<string> list4 = new List<string>();
		foreach (KeyValuePair<string, string> keyValuePair in this.#=zJPR1D4vj4Ojo)
		{
			if (list2.Contains(keyValuePair.Value))
			{
				#=zGBv9vvB23PwT.Add(keyValuePair.Key);
			}
			else if (!list.Contains(keyValuePair.Value))
			{
				list4.Add(keyValuePair.Key);
			}
		}
		foreach (string key2 in list4)
		{
			this.#=zJPR1D4vj4Ojo.Remove(key2);
		}
	}

	// Token: 0x06000488 RID: 1160 RVA: 0x000269C4 File Offset: 0x00024BC4
	private static int #=zN3XDg2kMgmMV(ProxyInfo #=zsHG$Y6w=, Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>> #=z9Z3H0wUaslGm)
	{
		string key = #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=ziUsbeuuW$Pcl(#=zsHG$Y6w=);
		if (!#=z9Z3H0wUaslGm.ContainsKey(key))
		{
			return 0;
		}
		return #=z9Z3H0wUaslGm[key].Count;
	}

	// Token: 0x06000489 RID: 1161 RVA: 0x000269F0 File Offset: 0x00024BF0
	public void #=zT8mrD6t_f2Of()
	{
		this.#=zJPR1D4vj4Ojo.Clear();
		this.#=zENpef7zKxTXwAy7Wo_QzcJ8=.Clear();
	}

	// Token: 0x040001AE RID: 430
	private Dictionary<string, string> #=zJPR1D4vj4Ojo;

	// Token: 0x040001AF RID: 431
	public List<string> #=zENpef7zKxTXwAy7Wo_QzcJ8=;

	// Token: 0x040001B0 RID: 432
	private DateTime #=za2nTHzhJsK$qYZLV8bofB2E=;

	// Token: 0x040001B1 RID: 433
	private DateTime #=zMbiaD7V1e8A2_UJ6dqaR6iM=;

	// Token: 0x040001B2 RID: 434
	private DateTime #=zYe83cMfoP44Y4anSEkjbris=;

	// Token: 0x020000AD RID: 173
	private sealed class #=z64GoslHWKG7eUA2yrYgyGf4=
	{
		// Token: 0x0600048B RID: 1163 RVA: 0x00026A10 File Offset: 0x00024C10
		internal int #=zUMytavOuP$J0iHU9H8Yma2V9k7$KDebPtw==(ProxyInfo #=zm8PpuDU=, ProxyInfo #=zcltuPyw=)
		{
			return #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zcltuPyw=, this.#=z9Z3H0wUaslGm).CompareTo(#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zm8PpuDU=, this.#=z9Z3H0wUaslGm));
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x00026A40 File Offset: 0x00024C40
		internal int #=zqXQhGp5Y46k$wu7tZGca9YrNyr5nxpwOpg==(ProxyInfo #=zm8PpuDU=, ProxyInfo #=zcltuPyw=)
		{
			return #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zcltuPyw=, this.#=z9Z3H0wUaslGm).CompareTo(#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zm8PpuDU=, this.#=z9Z3H0wUaslGm));
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x00026A70 File Offset: 0x00024C70
		internal int #=zj6be1sBQC0i1gyIumDFkgukGA2Fm6HoA2g==(ProxyInfo #=zm8PpuDU=, ProxyInfo #=zcltuPyw=)
		{
			return #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zcltuPyw=, this.#=z9Z3H0wUaslGm).CompareTo(#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zm8PpuDU=, this.#=z9Z3H0wUaslGm));
		}

		// Token: 0x040001B3 RID: 435
		public Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>> #=z9Z3H0wUaslGm;

		// Token: 0x040001B4 RID: 436
		public Comparison<ProxyInfo> #=zkDQnIvLlnqrP;

		// Token: 0x040001B5 RID: 437
		public Comparison<ProxyInfo> #=zCopSF6f7KYgs;
	}

	// Token: 0x020000AE RID: 174
	private sealed class #=zLzCFKykd0blCBjZJ0ZZDOiA=
	{
		// Token: 0x0600048F RID: 1167 RVA: 0x00026AA8 File Offset: 0x00024CA8
		internal bool #=z1p8TQrDCKZtyqrGLR9_7Qp6BW0mvkEjmYQ==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zm8PpuDU=)
		{
			return ((#=zm8PpuDU=.#=zol80P7TKoihZ().Count > 0) ? #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=z8FwXRs9sVOGt(#=zm8PpuDU=.#=zol80P7TKoihZ()[0]) : null) == this.#=zu1EBJkQ=;
		}

		// Token: 0x040001B6 RID: 438
		public string #=zu1EBJkQ=;
	}

	// Token: 0x020000AF RID: 175
	private sealed class #=zbjP7ZBivanWUvybn8iffczU=
	{
		// Token: 0x06000491 RID: 1169 RVA: 0x00026AE0 File Offset: 0x00024CE0
		internal int #=zRCQj2IpKoT58gfuIcA==(ProxyInfo #=zm8PpuDU=, ProxyInfo #=zcltuPyw=)
		{
			return #=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zcltuPyw=, this.#=z9Z3H0wUaslGm).CompareTo(#=z96$0NcA5hSBpuQp$OZIMzCn4nSBXxiOJXQ==.#=zN3XDg2kMgmMV(#=zm8PpuDU=, this.#=z9Z3H0wUaslGm));
		}

		// Token: 0x040001B7 RID: 439
		public Dictionary<string, List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==>> #=z9Z3H0wUaslGm;
	}
}
