﻿// Token: 0x0200018F RID: 399
internal sealed partial class #=zR88OH6uFpyeUuxZgsVNI7Yt14vyk3Le4sw== : global::System.Windows.Forms.Form
{
	// Token: 0x06000B69 RID: 2921 RVA: 0x000578CC File Offset: 0x00055ACC
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000623 RID: 1571
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
