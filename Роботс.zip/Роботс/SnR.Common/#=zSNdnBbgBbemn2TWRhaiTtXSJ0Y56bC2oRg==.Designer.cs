﻿// Token: 0x0200019C RID: 412
internal sealed partial class #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg== : global::System.Windows.Forms.Form
{
	// Token: 0x06000C07 RID: 3079 RVA: 0x00062540 File Offset: 0x00060740
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040006F2 RID: 1778
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
