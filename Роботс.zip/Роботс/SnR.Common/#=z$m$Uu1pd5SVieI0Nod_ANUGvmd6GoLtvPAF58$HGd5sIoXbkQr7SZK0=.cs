﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000020 RID: 32
internal sealed class #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= : List<#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=>
{
	// Token: 0x06000063 RID: 99 RVA: 0x00003C88 File Offset: 0x00001E88
	public void #=z20ohAjI=(object[] #=zcxaOJ0f$bdxPGuyeCLsp2wY=)
	{
		foreach (Dictionary<string, object> dictionary in #=zcxaOJ0f$bdxPGuyeCLsp2wY=)
		{
			if (dictionary != null)
			{
				base.Add(new #=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=(dictionary));
			}
		}
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00003CC0 File Offset: 0x00001EC0
	public #=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x06000065 RID: 101 RVA: 0x00003CF8 File Offset: 0x00001EF8
	public Dictionary<int, List<int>> #=zg7WszcBuQb1OUXsJ6UON5uI=(object[] #=zYAGQTDiJicWHgXzf02aAj18=)
	{
		Dictionary<int, List<int>> dictionary = new Dictionary<int, List<int>>();
		foreach (Dictionary<string, object> dictionary2 in #=zYAGQTDiJicWHgXzf02aAj18=)
		{
			int num = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
			#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= #=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= = this.#=zk$6QZNA=(num);
			if (#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= != null)
			{
				Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253));
				List<int> list = new List<int>();
				foreach (int item in #=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=.#=z6VxB9VQJ2pz6cLIJO89h0QM=())
				{
					string key = item.ToString();
					if (dictionary3.ContainsKey(key) && JSONManager.ExtractInt(JSONManager.ExtractDictionary(dictionary3, key), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), 0) == 2)
					{
						list.Add(item);
						break;
					}
				}
				if (list.Count > 0)
				{
					dictionary.Add(num, list);
				}
			}
		}
		return dictionary;
	}
}
