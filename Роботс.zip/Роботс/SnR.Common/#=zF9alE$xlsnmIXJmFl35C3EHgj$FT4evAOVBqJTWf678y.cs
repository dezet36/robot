﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x020000ED RID: 237
internal sealed class #=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y
{
	// Token: 0x06000635 RID: 1589 RVA: 0x00031F0C File Offset: 0x0003010C
	public static void #=zwNOfqVYF7bWUWGMaPw==(string #=zsGkziQH4l9Fpi_2cMg==, UnitSquadCollection #=zIzeO7X$TAdP_KrQ03A==, UnitSquadCollection #=zL5HENIqQVsI0YcTj6XQHBQM=, out UnitSquadCollection #=zFaw3GplOScPRKEa5Sw==, out UnitSquadCollection #=zs32iWYSGTwqcfgnkoXdA_AM=, out int #=zLcJetTnOBHGt)
	{
		if (#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zzfuUJztcOt9$(#=zsGkziQH4l9Fpi_2cMg==))
		{
			#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= = #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zRNqnDZfnmn0P(#=zsGkziQH4l9Fpi_2cMg==);
			#=zFaw3GplOScPRKEa5Sw== = new UnitSquadCollection();
			#=zs32iWYSGTwqcfgnkoXdA_AM= = new UnitSquadCollection();
			#=zLcJetTnOBHGt = -1;
			for (int i = 0; i < #=zIzeO7X$TAdP_KrQ03A==.Count; i++)
			{
				if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(#=zIzeO7X$TAdP_KrQ03A==[i]))
				{
					#=zFaw3GplOScPRKEa5Sw==.Add(#=zIzeO7X$TAdP_KrQ03A==[i]);
				}
			}
			for (int j = 0; j < #=zL5HENIqQVsI0YcTj6XQHBQM=.Count; j++)
			{
				if (#=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=.#=zQLl7KKs=(#=zL5HENIqQVsI0YcTj6XQHBQM=[j]))
				{
					#=zs32iWYSGTwqcfgnkoXdA_AM=.Add(#=zL5HENIqQVsI0YcTj6XQHBQM=[j]);
				}
			}
			return;
		}
		#=zFaw3GplOScPRKEa5Sw== = new UnitSquadCollection();
		#=zs32iWYSGTwqcfgnkoXdA_AM= = UnitSquadCollection.FromString(#=zsGkziQH4l9Fpi_2cMg==, null);
		if (#=zs32iWYSGTwqcfgnkoXdA_AM=.Count == 0)
		{
			#=zLcJetTnOBHGt = 0;
			return;
		}
		if (#=zs32iWYSGTwqcfgnkoXdA_AM=.Count == 1 && #=zs32iWYSGTwqcfgnkoXdA_AM=[0].Number == 1)
		{
			#=zLcJetTnOBHGt = 1;
		}
		else
		{
			#=zLcJetTnOBHGt = -1;
		}
		if (#=zLcJetTnOBHGt != 1)
		{
			foreach (UnitSquad unitSquad in #=zs32iWYSGTwqcfgnkoXdA_AM=)
			{
				UnitSquad unitSquad2 = #=zL5HENIqQVsI0YcTj6XQHBQM=.Find(unitSquad.Type.Id);
				if (unitSquad2 != null)
				{
					if (unitSquad.Number > unitSquad2.Number)
					{
						UnitSquad unitSquad3 = new UnitSquad();
						unitSquad3.Type = unitSquad.Type;
						unitSquad3.Number = unitSquad.Number - unitSquad2.Number;
						#=zFaw3GplOScPRKEa5Sw==.Add(unitSquad3);
						unitSquad.Number = unitSquad2.Number;
					}
				}
				else
				{
					UnitSquad unitSquad4 = new UnitSquad();
					unitSquad4.Type = unitSquad.Type;
					unitSquad4.Number = unitSquad.Number;
					#=zFaw3GplOScPRKEa5Sw==.Add(unitSquad4);
					unitSquad.Number = 0;
				}
			}
			for (int k = #=zs32iWYSGTwqcfgnkoXdA_AM=.Count - 1; k >= 0; k--)
			{
				if (#=zs32iWYSGTwqcfgnkoXdA_AM=[k].Number <= 0)
				{
					#=zs32iWYSGTwqcfgnkoXdA_AM=.RemoveAt(k);
				}
			}
			#=zFaw3GplOScPRKEa5Sw==.LimitToUnits(#=zIzeO7X$TAdP_KrQ03A==);
		}
	}

	// Token: 0x06000636 RID: 1590 RVA: 0x00032104 File Offset: 0x00030304
	public static int #=zgCEatgfxawCZM3H0DQ==(int #=zShL45qY=, UnitSquadCollection #=zxHIOVSaavkpE, bool #=zc3d4T3dmj8QfGq0r1A==, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD)
	{
		if (#=zShL45qY= > 0)
		{
			int num = #=zShL45qY=;
			List<#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==> collection = #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zTDmMhEqM6TVu4F4rmym2iJlz9OJo9Yp42p_ZAZA=(#=zxHIOVSaavkpE, #=zMEwuTGAUgTDD);
			List<UnitSquad> list = new List<UnitSquad>();
			list.AddRange(collection);
			list.AddRange(#=zxHIOVSaavkpE);
			list.Sort(new Comparison<UnitSquad>(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU=.#=zLkw0NRU=.#=zAstBtTfGPBtPfJRBfgNSBMdI4WjI));
			for (int i = list.Count - 1; i >= 0; i--)
			{
				if (num > 0)
				{
					UnitSquad unitSquad = list[i];
					int j = Convert.ToInt32(Math.Ceiling(unitSquad.GetConsumption()));
					if (num >= j)
					{
						num -= j;
					}
					else if (unitSquad is #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==)
					{
						#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ== #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ== = (#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==)unitSquad;
						#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zUh0YLXs8xYVxIEYFOQ==().Sort(new Comparison<UnitSquad>(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU=.#=zLkw0NRU=.#=zYafFYfymgNv8uAqIgjyCzTN1rQfK));
						while (j > num)
						{
							#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.Number--;
							int num2 = #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zDlfcC$kY8j_2tynD7ite18I=();
							for (int k = #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zUh0YLXs8xYVxIEYFOQ==().Count - 1; k >= 0; k--)
							{
								UnitSquad unitSquad2 = #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zUh0YLXs8xYVxIEYFOQ==()[k];
								if (unitSquad2.Number > num2)
								{
									unitSquad2.Number -= num2;
									break;
								}
								#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zUh0YLXs8xYVxIEYFOQ==().RemoveAt(k);
								num2 -= unitSquad2.Number;
							}
							j = Convert.ToInt32(Math.Ceiling(unitSquad.GetConsumption()));
						}
						num -= j;
					}
					else
					{
						unitSquad.Number = Convert.ToInt32(Math.Floor((double)num / unitSquad.Type.Consumption));
						num = 0;
					}
				}
				else
				{
					list.RemoveAt(i);
				}
			}
			#=zxHIOVSaavkpE.Clear();
			for (int l = list.Count - 1; l >= 0; l--)
			{
				UnitSquad unitSquad3 = list[l];
				#=zxHIOVSaavkpE.AddUnits(unitSquad3);
				if (unitSquad3 is #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==)
				{
					#=zxHIOVSaavkpE.AddUnits(((#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==)unitSquad3).#=zUh0YLXs8xYVxIEYFOQ==());
				}
			}
			return num;
		}
		if (#=zc3d4T3dmj8QfGq0r1A==)
		{
			#=zxHIOVSaavkpE.RemoveAll(new Predicate<UnitSquad>(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU=.#=zLkw0NRU=.#=zU$Ui27WhiVdSi3yHFOeTm68ujk_Y));
			if (#=zxHIOVSaavkpE.Count > 0)
			{
				#=zxHIOVSaavkpE.Sort(new Comparison<UnitSquad>(#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU=.#=zLkw0NRU=.#=zWyCsj4Ec7IWPBAWbJ_E81Zxa6zd6));
				for (int m = #=zxHIOVSaavkpE.Count - 1; m >= 1; m--)
				{
					#=zxHIOVSaavkpE.RemoveAt(m);
				}
				#=zxHIOVSaavkpE[0].Number = 1;
			}
		}
		else
		{
			#=zxHIOVSaavkpE.Clear();
		}
		return 0;
	}

	// Token: 0x06000637 RID: 1591 RVA: 0x0003238C File Offset: 0x0003058C
	public static string #=zy0P4$vJTLTxpa7WEqw==(UnitSquadCollection #=zFaw3GplOScPRKEa5Sw==, UnitSquadCollection #=zs32iWYSGTwqcfgnkoXdA_AM=, Dictionary<int, UnitSquadCollection> #=zzFbIudPbcByFmBe_wslCCsw=)
	{
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
		if (#=zFaw3GplOScPRKEa5Sw==.Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=zs32iWYSGTwqcfgnkoXdA_AM=.ToStringLabels(), Array.Empty<object>());
		}
		else if (#=zs32iWYSGTwqcfgnkoXdA_AM=.Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=zFaw3GplOScPRKEa5Sw==.ToStringLabels(), Array.Empty<object>());
		}
		else
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964385), new object[]
			{
				#=zFaw3GplOScPRKEa5Sw==.ToStringLabels()
			});
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964372), new object[]
			{
				#=zs32iWYSGTwqcfgnkoXdA_AM=.ToStringLabels()
			});
		}
		if (#=zzFbIudPbcByFmBe_wslCCsw= != null && #=zzFbIudPbcByFmBe_wslCCsw=.Count > 0)
		{
			foreach (UnitSquadCollection unitSquadCollection in #=zzFbIudPbcByFmBe_wslCCsw=.Values)
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zLikmsNA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964604), new object[]
				{
					unitSquadCollection.ToStringLabels()
				});
			}
		}
		return #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString();
	}

	// Token: 0x06000638 RID: 1592 RVA: 0x00032490 File Offset: 0x00030690
	public static #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=z4ttDoYN4UeOZsvmnr4f1eMo=(TaskSendUnitTypes #=zmV6257E=)
	{
		switch (#=zmV6257E=)
		{
		case TaskSendUnitTypes.Robbery:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2;
		case TaskSendUnitTypes.Scouting:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)4;
		case TaskSendUnitTypes.Siege:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3;
		case TaskSendUnitTypes.Reinforcement:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5;
		case TaskSendUnitTypes.RecallReinforcement:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)9;
		case TaskSendUnitTypes.AttackCapital:
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)1;
		default:
			if (#=zmV6257E= != TaskSendUnitTypes.SendAssasin)
			{
				throw new Exception(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964574), #=zmV6257E=, (int)#=zmV6257E=));
			}
			return (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)6;
		}
	}

	// Token: 0x020000EE RID: 238
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600063B RID: 1595 RVA: 0x00032508 File Offset: 0x00030708
		internal int #=zAstBtTfGPBtPfJRBfgNSBMdI4WjI(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			return #=zm8PpuDU=.GetStrengthPerConsumption().CompareTo(#=zcltuPyw=.GetStrengthPerConsumption());
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0003252C File Offset: 0x0003072C
		internal int #=zYafFYfymgNv8uAqIgjyCzTN1rQfK(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			return #=zcltuPyw=.Type.StrengthPerConsumption.CompareTo(#=zm8PpuDU=.Type.StrengthPerConsumption);
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x00032558 File Offset: 0x00030758
		internal bool #=zU$Ui27WhiVdSi3yHFOeTm68ujk_Y(UnitSquad #=zQrqFdos=)
		{
			return #=zQrqFdos=.Number < 1;
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x00032564 File Offset: 0x00030764
		internal int #=zWyCsj4Ec7IWPBAWbJ_E81Zxa6zd6(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			return #=zm8PpuDU=.Type.Consumption.CompareTo(#=zcltuPyw=.Type.Consumption);
		}

		// Token: 0x0400028F RID: 655
		public static readonly #=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU= #=zLkw0NRU= = new #=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zyDNvciU=();

		// Token: 0x04000290 RID: 656
		public static Comparison<UnitSquad> #=zXQv2dFi_NeOnCln2eA==;

		// Token: 0x04000291 RID: 657
		public static Comparison<UnitSquad> #=zy_pg2baEDfoPLMbXUQ==;

		// Token: 0x04000292 RID: 658
		public static Predicate<UnitSquad> #=z$RFcbqoxLJ6bRjn3qw==;

		// Token: 0x04000293 RID: 659
		public static Comparison<UnitSquad> #=zJqAOu8u4E_hxvFCLJg==;
	}
}
