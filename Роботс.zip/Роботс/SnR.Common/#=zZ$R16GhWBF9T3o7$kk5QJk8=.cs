﻿using System;

// Token: 0x020001EC RID: 492
internal interface #=zZ$R16GhWBF9T3o7$kk5QJk8=
{
	// Token: 0x06000EE4 RID: 3812
	string #=zmUYpUBj2v7o$();

	// Token: 0x06000EE5 RID: 3813
	sbyte[] #=ztbIWLuVjfGLU();

	// Token: 0x06000EE6 RID: 3814
	void #=zGgEMxSM=();

	// Token: 0x06000EE7 RID: 3815
	void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw);

	// Token: 0x06000EE8 RID: 3816
	void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC);

	// Token: 0x06000EE9 RID: 3817
	void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC);

	// Token: 0x06000EEA RID: 3818
	void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC);

	// Token: 0x06000EEB RID: 3819
	void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC);
}
