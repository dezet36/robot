﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x0200020F RID: 527
internal sealed class #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=
{
	// Token: 0x0600101E RID: 4126 RVA: 0x0007C03C File Offset: 0x0007A23C
	private #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=(Dictionary<string, object> #=zJ5GWysk=, string #=zW2vk27c=)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875));
		if (dictionary != null)
		{
			this.#=zvfBhGOp4QxBo(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), false));
			this.#=zpO_J9Ykg6Lhr(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), false));
		}
		else
		{
			this.#=zvfBhGOp4QxBo(DateTime.MinValue);
			this.#=zpO_J9Ykg6Lhr(DateTime.MinValue);
		}
		this.#=zaJ4RhKNSC0BV(new Dictionary<int, List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>>());
		foreach (Dictionary<string, object> dictionary2 in JSONManager.GetArray(#=zJ5GWysk=, #=zW2vk27c= + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069695)))
		{
			int key = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
			List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=> list = new List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>();
			this.#=zH3a5_YoOkwU2()[key] = list;
			object[] array2 = JSONManager.ExtractArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
			for (int j = 0; j < array2.Length; j++)
			{
				Dictionary<string, object> dictionary3 = (Dictionary<string, object>)array2[j];
				List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=> list2 = list;
				#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= #=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= = new #=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=();
				#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zOxsGjgI=(j);
				#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zETiXjxYQf5Cr(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0));
				#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=z5UhXmdMbFOrHJ44CrQ==(dictionary3.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)));
				list2.Add(#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=);
			}
		}
	}

	// Token: 0x0600101F RID: 4127 RVA: 0x0007C180 File Offset: 0x0007A380
	private DateTime #=zzqJBhunZ1qKZ()
	{
		return this.#=zVqT0WU843JqXRJizgQ==;
	}

	// Token: 0x06001020 RID: 4128 RVA: 0x0007C188 File Offset: 0x0007A388
	private void #=zvfBhGOp4QxBo(DateTime #=z$Ib9gYQ=)
	{
		this.#=zVqT0WU843JqXRJizgQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001021 RID: 4129 RVA: 0x0007C194 File Offset: 0x0007A394
	private DateTime #=z5Ykdq$MwgecZ()
	{
		return this.#=zpdvu$ObC5XaSuc6pf22QYq0=;
	}

	// Token: 0x06001022 RID: 4130 RVA: 0x0007C19C File Offset: 0x0007A39C
	private void #=zpO_J9Ykg6Lhr(DateTime #=z$Ib9gYQ=)
	{
		this.#=zpdvu$ObC5XaSuc6pf22QYq0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001023 RID: 4131 RVA: 0x0007C1A8 File Offset: 0x0007A3A8
	private Dictionary<int, List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>> #=zH3a5_YoOkwU2()
	{
		return this.#=zdg7rZfpG653DL1KyQg==;
	}

	// Token: 0x06001024 RID: 4132 RVA: 0x0007C1B0 File Offset: 0x0007A3B0
	private void #=zaJ4RhKNSC0BV(Dictionary<int, List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>> #=z$Ib9gYQ=)
	{
		this.#=zdg7rZfpG653DL1KyQg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001025 RID: 4133 RVA: 0x0007C1BC File Offset: 0x0007A3BC
	public static #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zTMDMKYg=(Dictionary<string, object> #=zknBhslssFXLQ, string #=zMC4ChWQ=, string #=zW2vk27c=)
	{
		object[] array = JSONManager.ExtractArray(#=zknBhslssFXLQ, #=zMC4ChWQ=);
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= = new #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=((Dictionary<string, object>)array[i], #=zW2vk27c=);
				if (#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=zzqJBhunZ1qKZ() < DateTime.Now && #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=z5Ykdq$MwgecZ() > DateTime.Now)
				{
					return #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=;
				}
			}
		}
		return null;
	}

	// Token: 0x06001026 RID: 4134 RVA: 0x0007C218 File Offset: 0x0007A418
	public static #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zMdX55nIyiBpE(Dictionary<string, object> #=zknBhslssFXLQ, string #=zMC4ChWQ=, string #=zW2vk27c=)
	{
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zknBhslssFXLQ, #=zMC4ChWQ=);
		if (dictionary != null)
		{
			#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= = new #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=(dictionary, #=zW2vk27c=);
			if (#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=zzqJBhunZ1qKZ() < DateTime.Now && #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=z5Ykdq$MwgecZ() > DateTime.Now)
			{
				return #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=;
			}
		}
		return null;
	}

	// Token: 0x06001027 RID: 4135 RVA: 0x0007C260 File Offset: 0x0007A460
	public List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=> #=zc2q1URQCK_hB(int #=zvRLj9WQ=)
	{
		if (this.#=zH3a5_YoOkwU2().ContainsKey(#=zvRLj9WQ=))
		{
			return this.#=zH3a5_YoOkwU2()[#=zvRLj9WQ=];
		}
		return new List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>();
	}

	// Token: 0x040008E2 RID: 2274
	private DateTime #=zVqT0WU843JqXRJizgQ==;

	// Token: 0x040008E3 RID: 2275
	private DateTime #=zpdvu$ObC5XaSuc6pf22QYq0=;

	// Token: 0x040008E4 RID: 2276
	private Dictionary<int, List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=>> #=zdg7rZfpG653DL1KyQg==;
}
