﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020001ED RID: 493
internal sealed class #=zZ4TczVhhqPd03VvEaufX1hUlE1pF : #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==, IComparable
{
	// Token: 0x06000EEC RID: 3820 RVA: 0x00076814 File Offset: 0x00074A14
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF() : base(Entities.Building)
	{
		this.#=z60Lqre$arQLO(new #=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw==());
	}

	// Token: 0x06000EED RID: 3821 RVA: 0x00076828 File Offset: 0x00074A28
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF(Dictionary<string, object> #=z1YNp7IY=) : base(#=z1YNp7IY=, Entities.Building)
	{
		this.#=zAcj8KiiwPtkT((#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)0);
		this.#=z345iMHU0qIyv(base.Name);
		this.#=z60Lqre$arQLO(new #=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw==());
		object[] array = JSONManager.GetArray(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070681));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				int @int = JSONManager.GetInt(array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
				if (@int > 1000 && @int < 2000)
				{
					this.#=z36uV8HmJaa1n(@int);
					break;
				}
			}
		}
		int id = base.Id;
		string text;
		if (id <= 109)
		{
			if (id == 108)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070677);
				goto IL_F1;
			}
			if (id == 109)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070659);
				goto IL_F1;
			}
		}
		else
		{
			if (id == 124)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086);
				goto IL_F1;
			}
			if (id == 125)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045);
				goto IL_F1;
			}
			if (id == 150)
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070649);
				goto IL_F1;
			}
		}
		text = null;
		IL_F1:
		object[] array2 = JSONManager.GetArray(#=z1YNp7IY=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070647));
		if (array2 != null)
		{
			if (text != null)
			{
				this.#=zpmbhfimGMj3U(new int[array2.Length]);
				for (int j = 0; j < array2.Length; j++)
				{
					this.#=zjw43QGFcPyHH()[j] = JSONManager.GetInt(array2[j], text, 0);
				}
			}
			this.#=zJtclDBkKCg12().#=z20ohAjI=(array2);
		}
	}

	// Token: 0x06000EEE RID: 3822 RVA: 0x00076978 File Offset: 0x00074B78
	public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs= #=zgFVkd5ydGXNJ()
	{
		return this.#=ziUTuDhp_n_4tYiKFVA==;
	}

	// Token: 0x06000EEF RID: 3823 RVA: 0x00076980 File Offset: 0x00074B80
	public void #=zAcj8KiiwPtkT(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs= #=z$Ib9gYQ=)
	{
		this.#=ziUTuDhp_n_4tYiKFVA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EF0 RID: 3824 RVA: 0x0007698C File Offset: 0x00074B8C
	public int #=zYd7ksR1y$HrM()
	{
		return this.#=z419cjdqus74qlOI5E1qF9HU=;
	}

	// Token: 0x06000EF1 RID: 3825 RVA: 0x00076994 File Offset: 0x00074B94
	public void #=z36uV8HmJaa1n(int #=z$Ib9gYQ=)
	{
		this.#=z419cjdqus74qlOI5E1qF9HU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EF2 RID: 3826 RVA: 0x000769A0 File Offset: 0x00074BA0
	public string #=zNn0PpoXIcD55()
	{
		return this.#=z1yFwC_LF_Rwf83gagQ==;
	}

	// Token: 0x06000EF3 RID: 3827 RVA: 0x000769A8 File Offset: 0x00074BA8
	public void #=z345iMHU0qIyv(string #=z$Ib9gYQ=)
	{
		this.#=z1yFwC_LF_Rwf83gagQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EF4 RID: 3828 RVA: 0x000769B4 File Offset: 0x00074BB4
	public int[] #=zjw43QGFcPyHH()
	{
		return this.#=z$cjfMsOUZJUVVe7pGQ==;
	}

	// Token: 0x06000EF5 RID: 3829 RVA: 0x000769BC File Offset: 0x00074BBC
	public void #=zpmbhfimGMj3U(int[] #=z$Ib9gYQ=)
	{
		this.#=z$cjfMsOUZJUVVe7pGQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EF6 RID: 3830 RVA: 0x000769C8 File Offset: 0x00074BC8
	public #=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw== #=zJtclDBkKCg12()
	{
		return this.#=z9Wlxu9fHC8eqtRo_AzOFf9E=;
	}

	// Token: 0x06000EF7 RID: 3831 RVA: 0x000769D0 File Offset: 0x00074BD0
	public void #=z60Lqre$arQLO(#=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw== #=z$Ib9gYQ=)
	{
		this.#=z9Wlxu9fHC8eqtRo_AzOFf9E= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EF8 RID: 3832 RVA: 0x000769DC File Offset: 0x00074BDC
	public bool #=z97C9Udp8hOam()
	{
		if (base.#=z2fOvUeiaHzR6().Count <= 0)
		{
			return this.#=zxMEpaIbD6lZ5;
		}
		return base.#=z2fOvUeiaHzR6().Count > 1;
	}

	// Token: 0x06000EF9 RID: 3833 RVA: 0x00076A04 File Offset: 0x00074C04
	public void #=znayYIHY8nMCv(bool #=z$Ib9gYQ=)
	{
		this.#=zxMEpaIbD6lZ5 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000EFA RID: 3834 RVA: 0x00076A10 File Offset: 0x00074C10
	public bool #=zrmfzXr6EXxL0VG1ofw==()
	{
		return base.Id == 850;
	}

	// Token: 0x06000EFB RID: 3835 RVA: 0x00076A20 File Offset: 0x00074C20
	public int CompareTo(object #=ze8bSiug=)
	{
		if (#=ze8bSiug= != null && #=ze8bSiug= is #=zZ4TczVhhqPd03VvEaufX1hUlE1pF)
		{
			UnitType unitType = #=ze8bSiug= as UnitType;
			return base.Id.CompareTo(unitType.Id);
		}
		return 0;
	}

	// Token: 0x06000EFC RID: 3836 RVA: 0x00076A58 File Offset: 0x00074C58
	public override string ToString()
	{
		return base.Name;
	}

	// Token: 0x06000EFD RID: 3837 RVA: 0x00076A60 File Offset: 0x00074C60
	public static Dictionary<int, int> #=zFHkCBp9mRlgs()
	{
		return new Dictionary<int, int>
		{
			{
				102,
				198
			},
			{
				104,
				199
			},
			{
				106,
				197
			}
		};
	}

	// Token: 0x04000853 RID: 2131
	private #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs= #=ziUTuDhp_n_4tYiKFVA==;

	// Token: 0x04000854 RID: 2132
	private int #=z419cjdqus74qlOI5E1qF9HU=;

	// Token: 0x04000855 RID: 2133
	private string #=z1yFwC_LF_Rwf83gagQ==;

	// Token: 0x04000856 RID: 2134
	private int[] #=z$cjfMsOUZJUVVe7pGQ==;

	// Token: 0x04000857 RID: 2135
	private #=zXovNw2V_P9oJnOGjpEaQGR0LvhzvxV5djw== #=z9Wlxu9fHC8eqtRo_AzOFf9E=;

	// Token: 0x04000858 RID: 2136
	private bool #=zxMEpaIbD6lZ5;

	// Token: 0x020001EE RID: 494
	public enum #=zOct_nIs=
	{

	}
}
