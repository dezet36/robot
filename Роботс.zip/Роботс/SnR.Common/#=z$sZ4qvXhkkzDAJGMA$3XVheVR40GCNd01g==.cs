﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using Skink.SnR.Common.Global;

// Token: 0x02000022 RID: 34
internal sealed class #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g== : UserControl
{
	// Token: 0x06000070 RID: 112 RVA: 0x00003EA4 File Offset: 0x000020A4
	public #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==()
	{
		this.#=zmUBPO5k= = new List<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=>();
		this.AutoScroll = true;
		this.#=zgpzgXirqPT5_();
	}

	// Token: 0x06000071 RID: 113 RVA: 0x00003EC4 File Offset: 0x000020C4
	public void #=z20ohAjI=(IList #=z54kioasMVF64)
	{
		#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zV_Jaipud2OIj6AvV0w== #=zV_Jaipud2OIj6AvV0w== = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zV_Jaipud2OIj6AvV0w==();
		#=zV_Jaipud2OIj6AvV0w==.#=z54kioasMVF64 = #=z54kioasMVF64;
		this.#=zmUBPO5k=.Clear();
		for (int i = base.Controls.Count - 1; i >= 0; i--)
		{
			if (base.Controls[i] is Label)
			{
				base.Controls.RemoveAt(i);
			}
		}
		for (int j = 0; j < #=zV_Jaipud2OIj6AvV0w==.#=z54kioasMVF64.Count; j++)
		{
			ITagged tagged = (ITagged)#=zV_Jaipud2OIj6AvV0w==.#=z54kioasMVF64[j];
			if (tagged != null)
			{
				for (int k = 0; k < tagged.Tags.Count; k++)
				{
					#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zmDwN9yb7ERprLr24AQ== #=zmDwN9yb7ERprLr24AQ== = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zmDwN9yb7ERprLr24AQ==();
					#=zmDwN9yb7ERprLr24AQ==.#=zldJnnFk= = tagged.Tags[k];
					if (!string.IsNullOrWhiteSpace(#=zmDwN9yb7ERprLr24AQ==.#=zldJnnFk=))
					{
						#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc= = this.#=zmUBPO5k=.Find(new Predicate<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=>(#=zmDwN9yb7ERprLr24AQ==.#=zp0sQEHXmxILFqsoVRA==));
						if (#=zz6MgBBc= == null)
						{
							#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc=2 = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=();
							#=zz6MgBBc=2.#=zwXKUV2c=(#=zmDwN9yb7ERprLr24AQ==.#=zldJnnFk=);
							#=zz6MgBBc=2.#=zJTi3SpuC8r7G1561qA==(0);
							#=zz6MgBBc=2.#=zXm81eMqpYhVA(0);
							#=zz6MgBBc= = #=zz6MgBBc=2;
							this.#=zmUBPO5k=.Add(#=zz6MgBBc=);
						}
						#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc=3 = #=zz6MgBBc=;
						int num = #=zz6MgBBc=3.#=zis9QdJFDLKrt8oA6zw==();
						#=zz6MgBBc=3.#=zJTi3SpuC8r7G1561qA==(num + 1);
					}
				}
			}
		}
		this.#=zmUBPO5k=.RemoveAll(new Predicate<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=>(#=zV_Jaipud2OIj6AvV0w==.#=zVhFWx0Jx__xJZEOcqw==));
		this.#=zmUBPO5k=.Sort(new Comparison<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=>(#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zyDNvciU=.#=zLkw0NRU=.#=z1KGcowTcQbwFmNIIrw==));
		int num2 = 50;
		for (int l = 0; l < this.#=zmUBPO5k=.Count; l++)
		{
			#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc=4 = this.#=zmUBPO5k=[l];
			Label label = new Label();
			label.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099259) + l.ToString();
			label.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069843), #=zz6MgBBc=4.#=zkfqcY3I=(), #=zz6MgBBc=4.#=zis9QdJFDLKrt8oA6zw==());
			label.Tag = #=zz6MgBBc=4;
			label.Click += this.#=zWN3jtSWi1yky;
			label.ForeColor = Color.Black;
			label.Left = 10;
			label.Top = l * 30 + num2;
			label.Width = 200;
			base.Controls.Add(label);
		}
	}

	// Token: 0x06000072 RID: 114 RVA: 0x00004114 File Offset: 0x00002314
	public void #=znoclypZSSO9V(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=z3NYbsp8=;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Combine(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=z3NYbsp8=, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x06000073 RID: 115 RVA: 0x0000414C File Offset: 0x0000234C
	public void #=zWFrtw57XHmO3(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=z3NYbsp8=;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Remove(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=z3NYbsp8=, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00004184 File Offset: 0x00002384
	private void #=zWN3jtSWi1yky(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		Label label = (Label)#=zP95I7AY=;
		if (label == null)
		{
			return;
		}
		#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc= = (#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=)label.Tag;
		if (#=zz6MgBBc=.#=zMxhKr$31toD7() == 0)
		{
			#=zz6MgBBc=.#=zXm81eMqpYhVA(1);
			label.ForeColor = Color.DarkGreen;
			label.Font = new Font(label.Font, FontStyle.Bold);
		}
		else if (#=zz6MgBBc=.#=zMxhKr$31toD7() > 0)
		{
			#=zz6MgBBc=.#=zXm81eMqpYhVA(-1);
			label.ForeColor = Color.Red;
			label.Font = new Font(label.Font, FontStyle.Strikeout);
		}
		else
		{
			#=zz6MgBBc=.#=zXm81eMqpYhVA(0);
			label.ForeColor = Color.Black;
			label.Font = new Font(label.Font, FontStyle.Regular);
		}
		EventHandler eventHandler = this.#=z3NYbsp8=;
		if (eventHandler == null)
		{
			return;
		}
		eventHandler(this, #=z4Q$h3mE=);
	}

	// Token: 0x06000075 RID: 117 RVA: 0x0000423C File Offset: 0x0000243C
	private void #=zo3sPngJCS6jApOSixw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		EventHandler eventHandler = this.#=z3NYbsp8=;
		if (eventHandler == null)
		{
			return;
		}
		eventHandler(this, #=z4Q$h3mE=);
	}

	// Token: 0x06000076 RID: 118 RVA: 0x00004250 File Offset: 0x00002450
	public bool #=zQLl7KKs=(ITagged #=ze8bSiug=)
	{
		bool flag = true;
		bool @checked = this.#=zGSp$jkTyBHdw.Checked;
		for (int i = 0; i < this.#=zmUBPO5k=.Count; i++)
		{
			#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zz6MgBBc= = this.#=zmUBPO5k=[i];
			if (#=zz6MgBBc=.#=zMxhKr$31toD7() > 0)
			{
				flag = false;
				if (@checked)
				{
					if (!#=ze8bSiug=.Tags.Contains(#=zz6MgBBc=.#=zkfqcY3I=()))
					{
						return false;
					}
				}
				else if (#=ze8bSiug=.Tags.Contains(#=zz6MgBBc=.#=zkfqcY3I=()))
				{
					return true;
				}
			}
			else if (#=zz6MgBBc=.#=zMxhKr$31toD7() < 0)
			{
				flag = false;
				if (@checked)
				{
					if (#=ze8bSiug=.Tags.Contains(#=zz6MgBBc=.#=zkfqcY3I=()))
					{
						return false;
					}
				}
				else if (!#=ze8bSiug=.Tags.Contains(#=zz6MgBBc=.#=zkfqcY3I=()))
				{
					return true;
				}
			}
		}
		return flag || @checked;
	}

	// Token: 0x06000077 RID: 119 RVA: 0x0000430C File Offset: 0x0000250C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x0000432C File Offset: 0x0000252C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zGSp$jkTyBHdw = new RadioButton();
		this.#=zlk20SXT6f4jy = new RadioButton();
		base.SuspendLayout();
		this.#=zGSp$jkTyBHdw.AutoSize = true;
		this.#=zGSp$jkTyBHdw.Checked = true;
		this.#=zGSp$jkTyBHdw.Location = new Point(10, 9);
		this.#=zGSp$jkTyBHdw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099242);
		this.#=zGSp$jkTyBHdw.Size = new Size(42, 19);
		this.#=zGSp$jkTyBHdw.TabIndex = 0;
		this.#=zGSp$jkTyBHdw.TabStop = true;
		this.#=zGSp$jkTyBHdw.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099226);
		this.#=zGSp$jkTyBHdw.UseVisualStyleBackColor = true;
		this.#=zGSp$jkTyBHdw.CheckedChanged += this.#=zo3sPngJCS6jApOSixw==;
		this.#=zlk20SXT6f4jy.AutoSize = true;
		this.#=zlk20SXT6f4jy.Location = new Point(67, 9);
		this.#=zlk20SXT6f4jy.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099220);
		this.#=zlk20SXT6f4jy.Size = new Size(59, 19);
		this.#=zlk20SXT6f4jy.TabIndex = 0;
		this.#=zlk20SXT6f4jy.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099207);
		this.#=zlk20SXT6f4jy.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Controls.Add(this.#=zlk20SXT6f4jy);
		base.Controls.Add(this.#=zGSp$jkTyBHdw);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909099184);
		base.Size = new Size(157, 150);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400001F RID: 31
	private List<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=> #=zmUBPO5k=;

	// Token: 0x04000020 RID: 32
	private EventHandler #=z3NYbsp8=;

	// Token: 0x04000021 RID: 33
	private IContainer #=zRWEHIqY=;

	// Token: 0x04000022 RID: 34
	private RadioButton #=zGSp$jkTyBHdw;

	// Token: 0x04000023 RID: 35
	private RadioButton #=zlk20SXT6f4jy;

	// Token: 0x02000023 RID: 35
	private sealed class #=zV_Jaipud2OIj6AvV0w==
	{
		// Token: 0x0600007A RID: 122 RVA: 0x000044E8 File Offset: 0x000026E8
		internal bool #=zVhFWx0Jx__xJZEOcqw==(#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zis9QdJFDLKrt8oA6zw==() >= this.#=z54kioasMVF64.Count;
		}

		// Token: 0x04000024 RID: 36
		public IList #=z54kioasMVF64;
	}

	// Token: 0x02000024 RID: 36
	private sealed class #=zmDwN9yb7ERprLr24AQ==
	{
		// Token: 0x0600007C RID: 124 RVA: 0x00004508 File Offset: 0x00002708
		internal bool #=zp0sQEHXmxILFqsoVRA==(#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zkfqcY3I=() == this.#=zldJnnFk=;
		}

		// Token: 0x04000025 RID: 37
		public string #=zldJnnFk=;
	}

	// Token: 0x02000025 RID: 37
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600007F RID: 127 RVA: 0x00004530 File Offset: 0x00002730
		internal int #=z1KGcowTcQbwFmNIIrw==(#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zm8PpuDU=, #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.#=zkfqcY3I=().CompareTo(#=zcltuPyw=.#=zkfqcY3I=());
		}

		// Token: 0x04000026 RID: 38
		public static readonly #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zyDNvciU= #=zLkw0NRU= = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zyDNvciU=();

		// Token: 0x04000027 RID: 39
		public static Comparison<#=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==.#=zz6MgBBc=> #=zjNXlGToPxbWHj7Yokw==;
	}

	// Token: 0x02000026 RID: 38
	private sealed class #=zz6MgBBc=
	{
		// Token: 0x06000081 RID: 129 RVA: 0x0000454C File Offset: 0x0000274C
		public string #=zkfqcY3I=()
		{
			return this.#=zWd4PtJyWoTk_ZThs2A==;
		}

		// Token: 0x06000082 RID: 130 RVA: 0x00004554 File Offset: 0x00002754
		public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
		{
			this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00004560 File Offset: 0x00002760
		public int #=zis9QdJFDLKrt8oA6zw==()
		{
			return this.#=zjz1v0UfDANY3iN77zWEsDkmkbh0C;
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00004568 File Offset: 0x00002768
		public void #=zJTi3SpuC8r7G1561qA==(int #=z$Ib9gYQ=)
		{
			this.#=zjz1v0UfDANY3iN77zWEsDkmkbh0C = #=z$Ib9gYQ=;
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00004574 File Offset: 0x00002774
		public int #=zMxhKr$31toD7()
		{
			return this.#=zZXXgGpfm3rsSXvaLKw==;
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000457C File Offset: 0x0000277C
		public void #=zXm81eMqpYhVA(int #=z$Ib9gYQ=)
		{
			this.#=zZXXgGpfm3rsSXvaLKw== = #=z$Ib9gYQ=;
		}

		// Token: 0x04000028 RID: 40
		private string #=zWd4PtJyWoTk_ZThs2A==;

		// Token: 0x04000029 RID: 41
		private int #=zjz1v0UfDANY3iN77zWEsDkmkbh0C;

		// Token: 0x0400002A RID: 42
		private int #=zZXXgGpfm3rsSXvaLKw==;
	}
}
