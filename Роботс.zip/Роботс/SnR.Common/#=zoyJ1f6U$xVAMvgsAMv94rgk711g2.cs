﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x020002A3 RID: 675
internal sealed class #=zoyJ1f6U$xVAMvgsAMv94rgk711g2 : EscherContainer
{
	// Token: 0x0600148A RID: 5258 RVA: 0x0009C8E0 File Offset: 0x0009AAE0
	public #=zoyJ1f6U$xVAMvgsAMv94rgk711g2() : base(EscherRecordType.SPGR_CONTAINER)
	{
	}

	// Token: 0x0600148B RID: 5259 RVA: 0x0009C8F0 File Offset: 0x0009AAF0
	public #=zoyJ1f6U$xVAMvgsAMv94rgk711g2(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
	}
}
