﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Units;

// Token: 0x020001D6 RID: 470
internal sealed class #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=
{
	// Token: 0x06000E34 RID: 3636 RVA: 0x00071910 File Offset: 0x0006FB10
	public #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=(ResourceTypes #=zZ$DCY48=)
	{
		this.#=zIvNG6up0oMnc(#=zZ$DCY48=);
		this.#=zFiOdOlyi7HMkkGc2eA== = new List<#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zscRxrmg=>();
		this.#=zMvg5q9SrxuA1HA8Szw== = new List<double>();
		this.#=zNzyh9onSszcp$aMTbho5EHM= = new List<double>();
		this.#=z$8lrXvsxQ$LC = DateTime.MinValue;
		this.#=zQFgj6hjLUTj_ = 0.0;
	}

	// Token: 0x06000E35 RID: 3637 RVA: 0x00071968 File Offset: 0x0006FB68
	public ResourceTypes #=zKPUeE1FOGkx5()
	{
		return this.#=zPDRN2_ur7JzxhYmaqg==;
	}

	// Token: 0x06000E36 RID: 3638 RVA: 0x00071970 File Offset: 0x0006FB70
	private void #=zIvNG6up0oMnc(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zPDRN2_ur7JzxhYmaqg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000E37 RID: 3639 RVA: 0x0007197C File Offset: 0x0006FB7C
	public void #=zK7_p5R0=(DateTime #=zNcIt8nk=, #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zy0tqKwE=)
	{
		double num = (double)#=zy0tqKwE=[this.#=zKPUeE1FOGkx5()];
		List<#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zscRxrmg=> list = this.#=zFiOdOlyi7HMkkGc2eA==;
		#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zscRxrmg= #=zscRxrmg= = new #=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zscRxrmg=();
		#=zscRxrmg=.#=zIR9Xlcg=(#=zNcIt8nk=);
		#=zscRxrmg=.#=zqoCq5j01dD5w((int)num);
		list.Add(#=zscRxrmg=);
		while (this.#=zFiOdOlyi7HMkkGc2eA==.Count > 10)
		{
			this.#=zFiOdOlyi7HMkkGc2eA==.RemoveAt(0);
		}
		if (this.#=zQFgj6hjLUTj_ > 0.0)
		{
			if (num > 0.0)
			{
				double item = (num - this.#=zQFgj6hjLUTj_) / (#=zNcIt8nk= - this.#=z$8lrXvsxQ$LC).TotalHours;
				this.#=zMvg5q9SrxuA1HA8Szw==.Add(item);
				while (this.#=zMvg5q9SrxuA1HA8Szw==.Count > 10)
				{
					this.#=zMvg5q9SrxuA1HA8Szw==.RemoveAt(0);
				}
			}
			else
			{
				double item2 = -this.#=zQFgj6hjLUTj_ / (#=zNcIt8nk= - this.#=z$8lrXvsxQ$LC).TotalHours;
				this.#=zNzyh9onSszcp$aMTbho5EHM=.Add(item2);
				while (this.#=zNzyh9onSszcp$aMTbho5EHM=.Count > 10)
				{
					this.#=zNzyh9onSszcp$aMTbho5EHM=.RemoveAt(0);
				}
			}
		}
		this.#=z$8lrXvsxQ$LC = #=zNcIt8nk=;
		this.#=zQFgj6hjLUTj_ = num;
	}

	// Token: 0x06000E38 RID: 3640 RVA: 0x00071A90 File Offset: 0x0006FC90
	public bool #=zT3IY42oVPEUC()
	{
		for (int i = 0; i < this.#=zFiOdOlyi7HMkkGc2eA==.Count; i++)
		{
			if (this.#=zFiOdOlyi7HMkkGc2eA==[i].#=zlIXJ9$NfUZc_() == 0)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000E39 RID: 3641 RVA: 0x00071ACC File Offset: 0x0006FCCC
	public int #=zcPDeKMQFl$$_()
	{
		List<List<double>> list = new List<List<double>>();
		for (int i = 0; i < this.#=zMvg5q9SrxuA1HA8Szw==.Count; i++)
		{
			double num = this.#=zMvg5q9SrxuA1HA8Szw==[i];
			bool flag = false;
			for (int j = 0; j < list.Count; j++)
			{
				double num2 = list[j][0];
				if (num2 == 0.0)
				{
					if (num < 0.1)
					{
						list[j].Add(num);
						flag = true;
						break;
					}
				}
				else if (Math.Abs(num - num2) / num2 < 0.1)
				{
					list[j].Add(num);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				list.Add(new List<double>
				{
					num
				});
			}
		}
		for (int k = list.Count - 1; k >= 0; k--)
		{
			if (list[k].Count >= 5)
			{
				return (int)Math.Round(list[k][0]);
			}
		}
		double num3 = 0.0;
		for (int l = 0; l < this.#=zNzyh9onSszcp$aMTbho5EHM=.Count; l++)
		{
			if (this.#=zNzyh9onSszcp$aMTbho5EHM=[l] < num3)
			{
				num3 = this.#=zNzyh9onSszcp$aMTbho5EHM=[l];
			}
		}
		return (int)Math.Round(num3);
	}

	// Token: 0x06000E3A RID: 3642 RVA: 0x00071C20 File Offset: 0x0006FE20
	public static int #=zfkMjd4$nuTc4l5SAG5VXdaY=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==, UnitSquadCollection #=z31ngnCFKehMCAvytODmoiTk=, List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zTaYuFbOBUS8Q4vm0YQ==, #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=z96cxP9pQp9fD)
	{
		double num = 0.0;
		Dictionary<string, double> dictionary = new Dictionary<string, double>();
		double num2 = 0.0;
		Dictionary<string, double> dictionary2 = new Dictionary<string, double>();
		for (int i = 0; i < #=zatMRdFUxBCRS1oul8g==.Count; i++)
		{
			#=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng== #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng== = #=zatMRdFUxBCRS1oul8g==[i].#=zJtclDBkKCg12();
			for (int j = 0; j < #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==.Count; j++)
			{
				#=z7c3f2qXWcxmaz11o0HIoNIq39nWO #=z7c3f2qXWcxmaz11o0HIoNIq39nWO = #=zW18xBlm3hVJW$HR5POAI6aUG2ctzgLNTng==[j];
				if (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zd$BbM3Y=() == 1)
				{
					if (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zq2bPTdY=() == (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)1)
					{
						num += #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zVcIxe_4=();
					}
					else if (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zq2bPTdY=() == (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)2)
					{
						#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zmJ9OKjRbVfar(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zVcIxe_4=());
					}
				}
				if (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zq2bPTdY=() == (#=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zArez$Gs=)5)
				{
					#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zmJ9OKjRbVfar(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907) + #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zd$BbM3Y=().ToString(), #=z7c3f2qXWcxmaz11o0HIoNIq39nWO.#=zVcIxe_4=());
				}
			}
		}
		for (int k = 0; k < #=z31ngnCFKehMCAvytODmoiTk=.Count; k++)
		{
			UnitSquad unitSquad = #=z31ngnCFKehMCAvytODmoiTk=[k];
			num2 += unitSquad.Type.Consumption * (double)unitSquad.Number;
		}
		for (int l = 0; l < #=z96cxP9pQp9fD.Count; l++)
		{
			if (#=z96cxP9pQp9fD[l].#=zq2bPTdY=().#=zzasQXAPWhOif() == (#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==.#=z4wicdB5kowMyxyMssQ==)3)
			{
				#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zmJ9OKjRbVfar(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907) + 0.ToString(), #=z96cxP9pQp9fD[l].#=zjw43QGFcPyHH());
				break;
			}
		}
		for (int m = 0; m < #=zTaYuFbOBUS8Q4vm0YQ==.Count; m++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=zTaYuFbOBUS8Q4vm0YQ==[m];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
			{
				UnitSquadCollection unitSquadCollection = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD();
				for (int n = 0; n < unitSquadCollection.Count; n++)
				{
					UnitSquad unitSquad2 = unitSquadCollection[n];
					num2 += unitSquad2.Type.Consumption * (double)unitSquad2.Number;
				}
			}
		}
		double num3 = 1.0;
		foreach (double num4 in dictionary.Values)
		{
			num3 *= num4 + 1.0;
		}
		double num5 = 1.0;
		foreach (double num6 in dictionary2.Values)
		{
			num5 *= 1.0 - num6 / 100.0;
		}
		return (int)(num * num3 - num2 * num5);
	}

	// Token: 0x06000E3B RID: 3643 RVA: 0x00071EE0 File Offset: 0x000700E0
	private static void #=zmJ9OKjRbVfar(Dictionary<string, double> #=zAMO8P5A=, string #=zNraCe1Y=, double #=ze7ZtytQ=)
	{
		if (!#=zAMO8P5A=.ContainsKey(#=zNraCe1Y=))
		{
			#=zAMO8P5A=[#=zNraCe1Y=] = #=ze7ZtytQ=;
			return;
		}
		#=zAMO8P5A=[#=zNraCe1Y=] += #=ze7ZtytQ=;
	}

	// Token: 0x040007ED RID: 2029
	private ResourceTypes #=zPDRN2_ur7JzxhYmaqg==;

	// Token: 0x040007EE RID: 2030
	private List<#=zXwfuwXHjbMRpxz3mAoa$mhSj8UrDJeQhxsXjMRI=.#=zscRxrmg=> #=zFiOdOlyi7HMkkGc2eA==;

	// Token: 0x040007EF RID: 2031
	private List<double> #=zMvg5q9SrxuA1HA8Szw==;

	// Token: 0x040007F0 RID: 2032
	private List<double> #=zNzyh9onSszcp$aMTbho5EHM=;

	// Token: 0x040007F1 RID: 2033
	private DateTime #=z$8lrXvsxQ$LC;

	// Token: 0x040007F2 RID: 2034
	private double #=zQFgj6hjLUTj_;

	// Token: 0x020001D7 RID: 471
	private sealed class #=zscRxrmg=
	{
		// Token: 0x06000E3D RID: 3645 RVA: 0x00071F0C File Offset: 0x0007010C
		public DateTime #=zPHMvvJ8=()
		{
			return this.#=zJDEdzIaDvHbnYM06$w==;
		}

		// Token: 0x06000E3E RID: 3646 RVA: 0x00071F14 File Offset: 0x00070114
		public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
		{
			this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000E3F RID: 3647 RVA: 0x00071F20 File Offset: 0x00070120
		public int #=zlIXJ9$NfUZc_()
		{
			return this.#=zxojFZYWVfXhu329mAA==;
		}

		// Token: 0x06000E40 RID: 3648 RVA: 0x00071F28 File Offset: 0x00070128
		public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
		{
			this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
		}

		// Token: 0x040007F3 RID: 2035
		private DateTime #=zJDEdzIaDvHbnYM06$w==;

		// Token: 0x040007F4 RID: 2036
		private int #=zxojFZYWVfXhu329mAA==;
	}
}
