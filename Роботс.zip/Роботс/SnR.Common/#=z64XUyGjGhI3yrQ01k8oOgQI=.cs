﻿using System;

// Token: 0x02000079 RID: 121
internal sealed class #=z64XUyGjGhI3yrQ01k8oOgQI=
{
	// Token: 0x06000367 RID: 871 RVA: 0x0001F6D8 File Offset: 0x0001D8D8
	private #=z64XUyGjGhI3yrQ01k8oOgQI=()
	{
	}

	// Token: 0x06000368 RID: 872 RVA: 0x0001F6E0 File Offset: 0x0001D8E0
	public static double #=zeTioEPI=(int #=zD9tXfOI=)
	{
		if ((#=zD9tXfOI= & 2) != 0)
		{
			double num = (double)(#=zD9tXfOI= >> 2);
			if ((#=zD9tXfOI= & 1) != 0)
			{
				num /= 100.0;
			}
			return num;
		}
		double num2 = BitConverter.Int64BitsToDouble(((long)#=zD9tXfOI= & (long)((ulong)-4)) << 32);
		if ((#=zD9tXfOI= & 1) != 0)
		{
			num2 /= 100.0;
		}
		return num2;
	}
}
