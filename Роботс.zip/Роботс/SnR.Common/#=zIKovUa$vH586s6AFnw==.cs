﻿using System;
using System.Runtime.InteropServices;

// Token: 0x02000108 RID: 264
internal sealed class #=zIKovUa$vH586s6AFnw==
{
	// Token: 0x040003FB RID: 1019 RVA: 0x00104BC0 File Offset: 0x00102DC0
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q4f08zFDttl_16gkaAdNpY_clDCCFvP7OnmNVQSbQpL0= #=z_qqgFo$UFWyJK2pIUrHO9FKaN3XD575IfXxuyzxWm_z6dGprAmL12fBs3_QJxHVrySSjPqcnQ2P9f7bAsTfLhDU=;

	// Token: 0x040003FC RID: 1020 RVA: 0x00104BD4 File Offset: 0x00102DD4
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q_GqsXYle2Gx1sOBh7EK3SGhRpCPdI8yzUXaVOJ3_9Jg= #=z1n4sm1Jo_gBeD4zYWJm9NQxbcKqxeVO3jEXsSIacYCC9_AXrIFMRmlZAzvfSOIQCN0nL8O_KncNDWam$vJVueZuvocHU;

	// Token: 0x040003FD RID: 1021 RVA: 0x00104BDC File Offset: 0x00102DDC
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qJIAaczrWjrnsb6NjkfvGraDwHaXCifGvwqfb8YP8s6c= #=zVdR2_deczXvKF8oPUbIFR4cHfFYbumlYThRlcuR132HnASI9Z71pwcHaueepL$vf4ifrS4G2NDl$mhGb45B0KDlKSbJE;

	// Token: 0x040003FE RID: 1022 RVA: 0x0010505C File Offset: 0x0010325C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qlhit1bUJpUJoq9psSqf4p87HHy34K96PHS6jnws4la8= #=z8Xu8A7XY$Fs6bBTGkgiMrPiJLX62TNBqxHpxtVOJkHzmTkSq1F3snX$TsKrObDYF0u9cweTN_aG7aJ6J1RpoVUaA$AkG;

	// Token: 0x040003FF RID: 1023 RVA: 0x0010525C File Offset: 0x0010345C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qpeKjs7JY_YEZ_u4HFeeaGZ$EgoNPSWFYSBpEucmJ0lA= #=z95lRQ_JH5m9h9VhER2RcRN_yo3Eudh5sLacYUTw76IePptbxU31mreejDjZJefBwHKO6ZSdI7DTNktfSdIBkCJXm0ieo;

	// Token: 0x04000400 RID: 1024 RVA: 0x00105268 File Offset: 0x00103468
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qpeKjs7JY_YEZ_u4HFeeaGZ$EgoNPSWFYSBpEucmJ0lA= #=zYB004IRX$IOrFSOzm_Pljh270YjfANfd41QBSc4qXV4XNwnD2yY0sbOPGekS9UlBWjgzlhSKJ89kkiDCeawqbn_BDPVw;

	// Token: 0x04000401 RID: 1025 RVA: 0x00105274 File Offset: 0x00103474
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qSSBabFXKkNY269t3j9__K1XuFJwytrG_3rfjfIGGZ6Y= #=ze6cCWwgJymG$EuO9QSxoXR7nLggFJrR8zacS9f4KDIp7f68oUbyhltKdtIDISP5x4f3XaEGUHNULjOxtF5kYMf4=;

	// Token: 0x04000402 RID: 1026 RVA: 0x001052EC File Offset: 0x001034EC
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qAvxCcYEcR6NEE6w4Qk3F78sc7Zn3FIj3GRIYoR4JvIo= #=zLZ_QOwZA5WEeF9XS6at06igRu2QzxNfBRHWO4JD4dreh6JAj4KVh$Rup3DMW66h_bvVGG7wND7K8RCSb5mGq$os=;

	// Token: 0x04000403 RID: 1027 RVA: 0x0010546C File Offset: 0x0010366C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q2SmeezIJKSItxzcF4X7Km9m9FZo5sD5lIeTKqckSpbM= #=zKdk3yVJRBT08F3LVwsEhLwApmRySuUXmAf5lSrXoP6jqUA4CZQCpznwEmCrBuBBWPTA4fXxyXu$EpIcpDLgXcvyryQP_;

	// Token: 0x04000404 RID: 1028 RVA: 0x001054E8 File Offset: 0x001036E8
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q2SmeezIJKSItxzcF4X7Km9m9FZo5sD5lIeTKqckSpbM= #=z_9Cvk8XrxDi3xXn9BJfksVHoNw0sQ15vcWK1JjQciZG1UjuU4KEjmPrPSnBh4mFm1h_tilIVgEdGssiuDMh8YtrGegVd;

	// Token: 0x04000405 RID: 1029 RVA: 0x00105564 File Offset: 0x00103764
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qpeKjs7JY_YEZ_u4HFeeaGZ$EgoNPSWFYSBpEucmJ0lA= #=zb4wnJb0EV6B7ifSR0TEsZ1W22shGjK68VroUoDFCI03dMtFjgUaw2ZfH1S8FoRdVSuhpqlDuZPV2B3jtOJKaI$qweW9G;

	// Token: 0x04000406 RID: 1030 RVA: 0x00105570 File Offset: 0x00103770
	internal static readonly long #=zkOtAS5ebDWidon1FwIs92CXGwzBSRJgPmJ0rVZ5k_UGnGHJ0t8_eZYPsWSqcQmoffG6$qFKC4S4hLDHVZAKRLKNnc_Qr;

	// Token: 0x04000407 RID: 1031 RVA: 0x00105578 File Offset: 0x00103778
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qsqQCOgek$91afpG9_gNqE5rb_3Vt77W7ih2MDmJvrNM= #=za7qYyIp_JCQUC5CM8vYI8GVi7Lk9twveT8Nd47Xhfh8fL3K37SC$Ebp53lj15_OWRAaD$lRdn0kQtE9PClCTQ$zHxSgb;

	// Token: 0x04000408 RID: 1032 RVA: 0x0010558C File Offset: 0x0010378C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qzw9z21o4Ld$wSfCgC2vRMZvdGT3YT84jVy_xeBBVuBU= #=z83Gs3G4OviaAPkA5K1u5xbTKM5ucYnaUf4FFjzkWGdYYX$FS4DONReNTnzQT5WleD1vlkAHVSODPimXEjKvZg3wTPJ8d;

	// Token: 0x04000409 RID: 1033 RVA: 0x00105600 File Offset: 0x00103800
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q4C$0t2AX4gbdy7Swkey2iZpQKJWDDHR36eWjdVKp$vI= #=zDsduNzmU7YrCgc04TVVzh4GmCX7zNc5LQDVojYTMhat$qNRE2pnvk5P7VcqHUxvogj$bBROZxvoXUpI6adO6sdE=;

	// Token: 0x0400040A RID: 1034 RVA: 0x00105610 File Offset: 0x00103810
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qxZu3K1PStnZ20BHZHVB7fPgRdKvbG1bqy8ZuJlj2vJ4= #=zKftseou6sCU8VpsJhW_LUKgek1x1bEH8LDcegQyxCWrxwqwM3GeP0HMYKZ29IPF$ka09V3K_WxH4OVt36x7bhinRY9U2;

	// Token: 0x0400040B RID: 1035 RVA: 0x0010561C File Offset: 0x0010381C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qtFQB5eiBixeIrTQyCU4HPn3hfDzT2fKmT_LRfumlGkE= #=z8EblOyEZiDQge9CCpdCN_NBI_EQsvQiYLdnHktoC5yQSkZe65myzlMdkgMx3$L5Fx1FtUhVi$s8V1NVjUhrgIBeRwJOo;

	// Token: 0x0400040C RID: 1036 RVA: 0x00106E1C File Offset: 0x0010501C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q$NnbY6x8Re8NtY6RpZ0Dcq3ohZ4rZtq4elpsSg6TXmI= #=zuBB6HMH9wsFQL$Y8twVV7SNLJ8gPyPEPmpb_7qPxq4d9CjEz2W3FWHKjox1i$5harQTFntwIyfY5_TRlJ_LVej$8TzsN;

	// Token: 0x0400040D RID: 1037 RVA: 0x00106E68 File Offset: 0x00105068
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qSSBabFXKkNY269t3j9__K1XuFJwytrG_3rfjfIGGZ6Y= #=zZIbJdGIfqX5v71DZUP36d2WHghZMQuiYpITjPwsLu2IbhPW_w0_kMW2OyuDMNNiDx1Fypwh52SaSeeR3sCb_TI8JfSaL;

	// Token: 0x0400040E RID: 1038 RVA: 0x00106EE0 File Offset: 0x001050E0
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qaiumXs_$lE3FVRe$9qAylf$8HMCsAkNxPdcrL_Ym2mQ= #=z6p2zT4$AggVZ5Z0x6CIGjWHjQ6AGXpBC0vfD0MbYncoP1F2eEwJEimqPN7NceXu0B1$XyPSzztS$onv3b2hKCGyxDSYU;

	// Token: 0x0400040F RID: 1039 RVA: 0x00106F30 File Offset: 0x00105130
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qSSBabFXKkNY269t3j9__K1XuFJwytrG_3rfjfIGGZ6Y= #=zpfbV_5Aeq1o5rTb6y2g2e64fb6TqgBsr$EliJllPgrIqK2WobhUjfduSuX2Kc2usAWVeSRK5USmRjox9Y2w1sWQ=;

	// Token: 0x04000410 RID: 1040 RVA: 0x00106FA8 File Offset: 0x001051A8
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qUSZpd7QWqjNM2bB2d4caXOmkiI2H5vAwZliCyazfYtM= #=zsLC_0K49e2BjYquSj1TnycexPqAZKrLy2xwUdK7kQjLc0J5l75$M_i21zD4FgF3AsPMTr5m3oW1x$NO2Ha1qxWohTWvd;

	// Token: 0x04000411 RID: 1041 RVA: 0x001070A8 File Offset: 0x001052A8
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q8CN8nZRZ_azV1HOzhPW25dkpUHEL3g_tZv2qoycjrYE= #=znzKZGE$zCrQNsIRBVxHxF6rDH0z1EcADy$vMuRICXzf2qOPULvBhDmf2KavAqApPgxGQc0kRiynhskug7KyMQkYfXdJG;

	// Token: 0x04000412 RID: 1042 RVA: 0x001070D8 File Offset: 0x001052D8
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q$NnbY6x8Re8NtY6RpZ0Dcq3ohZ4rZtq4elpsSg6TXmI= #=zw89i_ficWjinHdbNpEtaMgGIxJJIO4VLYPRFOng8gP4Gcz2TWJFU9Rmga$iLjjMozSrbhd25Zn_0nqBQXUBV1Hg=;

	// Token: 0x04000413 RID: 1043 RVA: 0x00107124 File Offset: 0x00105324
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qsqQCOgek$91afpG9_gNqE5rb_3Vt77W7ih2MDmJvrNM= #=zPSiTUG$GAxUPgYSn1syVdSlmCeOISF74JIMuuA7wktXyr8UU$YOr3vqLRMyqJ8o9RprHjBYlTPrt3zt7JnZIAMIGMKD7;

	// Token: 0x04000414 RID: 1044 RVA: 0x00107138 File Offset: 0x00105338
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qGDXXEkykkrHfyG1TUk4VnEVB4SZGldRlNZZemjTgSKs= #=zM6rOjxK67S64kXhH02tiNJF36MCgTGLDCrhyDxBWnI5XEanPYhP3z42st4LL7jGgPtVXjXsoSoTFX1f9YB$DZ3LdaVLQ;

	// Token: 0x04000415 RID: 1045 RVA: 0x0010717C File Offset: 0x0010537C
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q4C$0t2AX4gbdy7Swkey2iZpQKJWDDHR36eWjdVKp$vI= #=zsKFK1NvJZ6uD52rjUtkXTTjuNwffp_$RZJ66t$nG6JCPavvduo7RrpTFm8Q92$kimveg7MUARbjiL34jiID0phrT6MwU;

	// Token: 0x04000416 RID: 1046 RVA: 0x0010718C File Offset: 0x0010538C
	internal static readonly long #=zJORpzXbdr4yKksu8UKop3WQi2YY3L14vZWOi2qFi2pKozrQRiYhyo0r5bfb9GLQu2uSmATIENU7Vt35h2chelt0=;

	// Token: 0x04000417 RID: 1047 RVA: 0x00107194 File Offset: 0x00105394
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=q73CwaXR7sTlQrLRrXAFojGalpCfLhf$4hDeuTSWddXM= #=zOZ4x4Jo_lVFlGxDLnhdRqIU3CC42ZJ4MwoH8gwfOBlee0nvAuYN77lzs6h$26yPAVby_MmYLdcWS1E0cuXb9ym4DSoiM;

	// Token: 0x04000418 RID: 1048 RVA: 0x001071A4 File Offset: 0x001053A4
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qzw9z21o4Ld$wSfCgC2vRMZvdGT3YT84jVy_xeBBVuBU= #=z0vZqzWQyZWm2fxwjjV_3OTK7FyKrinmpDZVQiIHyddGFyuWAt7YSWJIqfLZJKNWVmTcq32OIp9abvHexkmsuPj6MhXob;

	// Token: 0x04000419 RID: 1049 RVA: 0x00107218 File Offset: 0x00105418
	internal static readonly #=zIKovUa$vH586s6AFnw==.#=qSSBabFXKkNY269t3j9__K1XuFJwytrG_3rfjfIGGZ6Y= #=z0Dr00$NkkXU2zwbK$GJAMtcp4hw4t0BirwnyvgiYUR12r2twrOMc5WysF6Ji5xofcmBIad7arL8U2ei8bGWQNsgEO1NE;

	// Token: 0x02000109 RID: 265
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 76)]
	internal struct #=q$NnbY6x8Re8NtY6RpZ0Dcq3ohZ4rZtq4elpsSg6TXmI=
	{
	}

	// Token: 0x0200010A RID: 266
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 124)]
	internal struct #=q2SmeezIJKSItxzcF4X7Km9m9FZo5sD5lIeTKqckSpbM=
	{
	}

	// Token: 0x0200010B RID: 267
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 16)]
	internal struct #=q4C$0t2AX4gbdy7Swkey2iZpQKJWDDHR36eWjdVKp$vI=
	{
	}

	// Token: 0x0200010C RID: 268
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 19)]
	internal struct #=q4f08zFDttl_16gkaAdNpY_clDCCFvP7OnmNVQSbQpL0=
	{
	}

	// Token: 0x0200010D RID: 269
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 14)]
	internal struct #=q73CwaXR7sTlQrLRrXAFojGalpCfLhf$4hDeuTSWddXM=
	{
	}

	// Token: 0x0200010E RID: 270
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 48)]
	internal struct #=q8CN8nZRZ_azV1HOzhPW25dkpUHEL3g_tZv2qoycjrYE=
	{
	}

	// Token: 0x0200010F RID: 271
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 384)]
	internal struct #=qAvxCcYEcR6NEE6w4Qk3F78sc7Zn3FIj3GRIYoR4JvIo=
	{
	}

	// Token: 0x02000110 RID: 272
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 68)]
	internal struct #=qGDXXEkykkrHfyG1TUk4VnEVB4SZGldRlNZZemjTgSKs=
	{
	}

	// Token: 0x02000111 RID: 273
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1152)]
	internal struct #=qJIAaczrWjrnsb6NjkfvGraDwHaXCifGvwqfb8YP8s6c=
	{
	}

	// Token: 0x02000112 RID: 274
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 120)]
	internal struct #=qSSBabFXKkNY269t3j9__K1XuFJwytrG_3rfjfIGGZ6Y=
	{
	}

	// Token: 0x02000113 RID: 275
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 256)]
	internal struct #=qUSZpd7QWqjNM2bB2d4caXOmkiI2H5vAwZliCyazfYtM=
	{
	}

	// Token: 0x02000114 RID: 276
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 6)]
	internal struct #=q_GqsXYle2Gx1sOBh7EK3SGhRpCPdI8yzUXaVOJ3_9Jg=
	{
	}

	// Token: 0x02000115 RID: 277
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 80)]
	internal struct #=qaiumXs_$lE3FVRe$9qAylf$8HMCsAkNxPdcrL_Ym2mQ=
	{
	}

	// Token: 0x02000116 RID: 278
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 512)]
	internal struct #=qlhit1bUJpUJoq9psSqf4p87HHy34K96PHS6jnws4la8=
	{
	}

	// Token: 0x02000117 RID: 279
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 12)]
	internal struct #=qpeKjs7JY_YEZ_u4HFeeaGZ$EgoNPSWFYSBpEucmJ0lA=
	{
	}

	// Token: 0x02000118 RID: 280
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 20)]
	internal struct #=qsqQCOgek$91afpG9_gNqE5rb_3Vt77W7ih2MDmJvrNM=
	{
	}

	// Token: 0x02000119 RID: 281
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 6144)]
	internal struct #=qtFQB5eiBixeIrTQyCU4HPn3hfDzT2fKmT_LRfumlGkE=
	{
	}

	// Token: 0x0200011A RID: 282
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 10)]
	internal struct #=qxZu3K1PStnZ20BHZHVB7fPgRdKvbG1bqy8ZuJlj2vJ4=
	{
	}

	// Token: 0x0200011B RID: 283
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 116)]
	internal struct #=qzw9z21o4Ld$wSfCgC2vRMZvdGT3YT84jVy_xeBBVuBU=
	{
	}
}
