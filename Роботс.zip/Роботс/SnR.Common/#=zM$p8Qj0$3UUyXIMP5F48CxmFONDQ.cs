﻿using System;

// Token: 0x0200015B RID: 347
internal sealed class #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ
{
	// Token: 0x06000938 RID: 2360 RVA: 0x0004B480 File Offset: 0x00049680
	internal static int #=zql2UPBE=(int #=z0id6pM2wr9jd)
	{
		if (#=z0id6pM2wr9jd >= 256)
		{
			return (int)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zlpBoj3whHHTgsgjReA==[256 + #=zQ0$80BSWnStXHXPSq3JljiY0_7rbyMy8RA==.#=zPMfJtLxrx9HD(#=z0id6pM2wr9jd, 7)];
		}
		return (int)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zlpBoj3whHHTgsgjReA==[#=z0id6pM2wr9jd];
	}

	// Token: 0x06000939 RID: 2361 RVA: 0x0004B4A8 File Offset: 0x000496A8
	internal void #=zxypasNuw4kgRr5X1Fw==(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA== #=zWj7xLq8=)
	{
		short[] array = this.#=zVnLx7cu3S4sV;
		short[] #=z0Kv84TunSrd = this.#=zb9dSZnEz1qIR.#=z0Kv84TunSrd6;
		int[] #=zpyahLQ1cblSe = this.#=zb9dSZnEz1qIR.#=zpyahLQ1cblSe;
		int #=zK$MmJ3Y= = this.#=zb9dSZnEz1qIR.#=zK$MmJ3Y=;
		int #=z1D6ecFeEFyCR = this.#=zb9dSZnEz1qIR.#=z1D6ecFeEFyCR;
		int num = 0;
		for (int i = 0; i <= #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zO9LTehyXK9Wr; i++)
		{
			#=zWj7xLq8=.#=zRQKwGJjqgRGa[i] = 0;
		}
		array[#=zWj7xLq8=.#=zpXKZvhI=[#=zWj7xLq8=.#=zheGHEHMCIpNT] * 2 + 1] = 0;
		int j;
		for (j = #=zWj7xLq8=.#=zheGHEHMCIpNT + 1; j < #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zCO1be_pw_8RU; j++)
		{
			int num2 = #=zWj7xLq8=.#=zpXKZvhI=[j];
			int i = (int)(array[(int)(array[num2 * 2 + 1] * 2 + 1)] + 1);
			if (i > #=z1D6ecFeEFyCR)
			{
				i = #=z1D6ecFeEFyCR;
				num++;
			}
			array[num2 * 2 + 1] = (short)i;
			if (num2 <= this.#=zDjtKVgb3mIkZ)
			{
				short[] #=zRQKwGJjqgRGa = #=zWj7xLq8=.#=zRQKwGJjqgRGa;
				int num3 = i;
				#=zRQKwGJjqgRGa[num3] += 1;
				int num4 = 0;
				if (num2 >= #=zK$MmJ3Y=)
				{
					num4 = #=zpyahLQ1cblSe[num2 - #=zK$MmJ3Y=];
				}
				short num5 = array[num2 * 2];
				#=zWj7xLq8=.#=z3nPze4xN8xfT += (int)num5 * (i + num4);
				if (#=z0Kv84TunSrd != null)
				{
					#=zWj7xLq8=.#=zQzrhsNbgIMpy += (int)num5 * ((int)#=z0Kv84TunSrd[num2 * 2 + 1] + num4);
				}
			}
		}
		if (num == 0)
		{
			return;
		}
		do
		{
			int i = #=z1D6ecFeEFyCR - 1;
			while (#=zWj7xLq8=.#=zRQKwGJjqgRGa[i] == 0)
			{
				i--;
			}
			short[] #=zRQKwGJjqgRGa2 = #=zWj7xLq8=.#=zRQKwGJjqgRGa;
			int num6 = i;
			#=zRQKwGJjqgRGa2[num6] -= 1;
			#=zWj7xLq8=.#=zRQKwGJjqgRGa[i + 1] = #=zWj7xLq8=.#=zRQKwGJjqgRGa[i + 1] + 2;
			short[] #=zRQKwGJjqgRGa3 = #=zWj7xLq8=.#=zRQKwGJjqgRGa;
			int num7 = #=z1D6ecFeEFyCR;
			#=zRQKwGJjqgRGa3[num7] -= 1;
			num -= 2;
		}
		while (num > 0);
		for (int i = #=z1D6ecFeEFyCR; i != 0; i--)
		{
			int num2 = (int)#=zWj7xLq8=.#=zRQKwGJjqgRGa[i];
			while (num2 != 0)
			{
				int num8 = #=zWj7xLq8=.#=zpXKZvhI=[--j];
				if (num8 <= this.#=zDjtKVgb3mIkZ)
				{
					if ((int)array[num8 * 2 + 1] != i)
					{
						#=zWj7xLq8=.#=z3nPze4xN8xfT = (int)((long)#=zWj7xLq8=.#=z3nPze4xN8xfT + ((long)i - (long)array[num8 * 2 + 1]) * (long)array[num8 * 2]);
						array[num8 * 2 + 1] = (short)i;
					}
					num2--;
				}
			}
		}
	}

	// Token: 0x0600093A RID: 2362 RVA: 0x0004B6A4 File Offset: 0x000498A4
	internal void #=zS0Twt13P67pD(#=zfkgQ1xkV69Mkkr1PDr5TmHHJcrXCpCPomA== #=zWj7xLq8=)
	{
		short[] array = this.#=zVnLx7cu3S4sV;
		short[] #=z0Kv84TunSrd = this.#=zb9dSZnEz1qIR.#=z0Kv84TunSrd6;
		int #=znw806Fdo4Ckg = this.#=zb9dSZnEz1qIR.#=znw806Fdo4Ckg;
		int num = -1;
		#=zWj7xLq8=.#=zh85prTr2G_WY = 0;
		#=zWj7xLq8=.#=zheGHEHMCIpNT = #=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zCO1be_pw_8RU;
		int num2;
		for (int i = 0; i < #=znw806Fdo4Ckg; i++)
		{
			if (array[i * 2] != 0)
			{
				int[] #=zpXKZvhI= = #=zWj7xLq8=.#=zpXKZvhI=;
				num2 = #=zWj7xLq8=.#=zh85prTr2G_WY + 1;
				#=zWj7xLq8=.#=zh85prTr2G_WY = num2;
				num = (#=zpXKZvhI=[num2] = i);
				#=zWj7xLq8=.#=z8h8JAHU=[i] = 0;
			}
			else
			{
				array[i * 2 + 1] = 0;
			}
		}
		int num3;
		while (#=zWj7xLq8=.#=zh85prTr2G_WY < 2)
		{
			int[] #=zpXKZvhI=2 = #=zWj7xLq8=.#=zpXKZvhI=;
			num2 = #=zWj7xLq8=.#=zh85prTr2G_WY + 1;
			#=zWj7xLq8=.#=zh85prTr2G_WY = num2;
			num3 = (#=zpXKZvhI=2[num2] = ((num < 2) ? (++num) : 0));
			array[num3 * 2] = 1;
			#=zWj7xLq8=.#=z8h8JAHU=[num3] = 0;
			#=zWj7xLq8=.#=z3nPze4xN8xfT--;
			if (#=z0Kv84TunSrd != null)
			{
				#=zWj7xLq8=.#=zQzrhsNbgIMpy -= (int)#=z0Kv84TunSrd[num3 * 2 + 1];
			}
		}
		this.#=zDjtKVgb3mIkZ = num;
		for (int i = #=zWj7xLq8=.#=zh85prTr2G_WY / 2; i >= 1; i--)
		{
			#=zWj7xLq8=.#=zCu4lG9BjZkFjY$eOAg==(array, i);
		}
		num3 = #=znw806Fdo4Ckg;
		do
		{
			int i = #=zWj7xLq8=.#=zpXKZvhI=[1];
			int[] #=zpXKZvhI=3 = #=zWj7xLq8=.#=zpXKZvhI=;
			int num4 = 1;
			int[] #=zpXKZvhI=4 = #=zWj7xLq8=.#=zpXKZvhI=;
			num2 = #=zWj7xLq8=.#=zh85prTr2G_WY;
			#=zWj7xLq8=.#=zh85prTr2G_WY = num2 - 1;
			#=zpXKZvhI=3[num4] = #=zpXKZvhI=4[num2];
			#=zWj7xLq8=.#=zCu4lG9BjZkFjY$eOAg==(array, 1);
			int num5 = #=zWj7xLq8=.#=zpXKZvhI=[1];
			int[] #=zpXKZvhI=5 = #=zWj7xLq8=.#=zpXKZvhI=;
			num2 = #=zWj7xLq8=.#=zheGHEHMCIpNT - 1;
			#=zWj7xLq8=.#=zheGHEHMCIpNT = num2;
			#=zpXKZvhI=5[num2] = i;
			int[] #=zpXKZvhI=6 = #=zWj7xLq8=.#=zpXKZvhI=;
			num2 = #=zWj7xLq8=.#=zheGHEHMCIpNT - 1;
			#=zWj7xLq8=.#=zheGHEHMCIpNT = num2;
			#=zpXKZvhI=6[num2] = num5;
			array[num3 * 2] = array[i * 2] + array[num5 * 2];
			#=zWj7xLq8=.#=z8h8JAHU=[num3] = (sbyte)(Math.Max((byte)#=zWj7xLq8=.#=z8h8JAHU=[i], (byte)#=zWj7xLq8=.#=z8h8JAHU=[num5]) + 1);
			array[i * 2 + 1] = (array[num5 * 2 + 1] = (short)num3);
			#=zWj7xLq8=.#=zpXKZvhI=[1] = num3++;
			#=zWj7xLq8=.#=zCu4lG9BjZkFjY$eOAg==(array, 1);
		}
		while (#=zWj7xLq8=.#=zh85prTr2G_WY >= 2);
		int[] #=zpXKZvhI=7 = #=zWj7xLq8=.#=zpXKZvhI=;
		num2 = #=zWj7xLq8=.#=zheGHEHMCIpNT - 1;
		#=zWj7xLq8=.#=zheGHEHMCIpNT = num2;
		#=zpXKZvhI=7[num2] = #=zWj7xLq8=.#=zpXKZvhI=[1];
		this.#=zxypasNuw4kgRr5X1Fw==(#=zWj7xLq8=);
		#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=zg3xsMT9LLYY$7e4hPg==(array, num, #=zWj7xLq8=.#=zRQKwGJjqgRGa);
	}

	// Token: 0x0600093B RID: 2363 RVA: 0x0004B8CC File Offset: 0x00049ACC
	internal static void #=zg3xsMT9LLYY$7e4hPg==(short[] #=zZUWDhT4=, int #=zDjtKVgb3mIkZ, short[] #=zRQKwGJjqgRGa)
	{
		short[] array = new short[#=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zO9LTehyXK9Wr + 1];
		short num = 0;
		for (int i = 1; i <= #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zO9LTehyXK9Wr; i++)
		{
			num = (array[i] = (short)(num + #=zRQKwGJjqgRGa[i - 1] << 1));
		}
		for (int j = 0; j <= #=zDjtKVgb3mIkZ; j++)
		{
			int num2 = (int)#=zZUWDhT4=[j * 2 + 1];
			if (num2 != 0)
			{
				int num3 = j * 2;
				short[] array2 = array;
				int num4 = num2;
				short num5 = array2[num4];
				array2[num4] = num5 + 1;
				#=zZUWDhT4=[num3] = (short)#=zM$p8Qj0$3UUyXIMP5F48CxmFONDQ.#=ztzut2ZYe56sd((int)num5, num2);
			}
		}
	}

	// Token: 0x0600093C RID: 2364 RVA: 0x0004B940 File Offset: 0x00049B40
	internal static int #=ztzut2ZYe56sd(int #=zKJA8IWQ=, int #=zZBlusgI=)
	{
		int num = 0;
		do
		{
			num |= (#=zKJA8IWQ= & 1);
			#=zKJA8IWQ= >>= 1;
			num <<= 1;
		}
		while (--#=zZBlusgI= > 0);
		return num >> 1;
	}

	// Token: 0x04000545 RID: 1349
	private static readonly int #=zCO1be_pw_8RU = 2 * #=zwT_XUiDAFAHOdVueuF$yv$heNm02k2Wc$g==.#=zexLItYjL27h5 + 1;

	// Token: 0x04000546 RID: 1350
	internal static readonly int[] #=zzQyDK_wHTKNo = new int[]
	{
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		1,
		1,
		1,
		1,
		2,
		2,
		2,
		2,
		3,
		3,
		3,
		3,
		4,
		4,
		4,
		4,
		5,
		5,
		5,
		5,
		0
	};

	// Token: 0x04000547 RID: 1351
	internal static readonly int[] #=ziI2CPZrUbbyH = new int[]
	{
		0,
		0,
		0,
		0,
		1,
		1,
		2,
		2,
		3,
		3,
		4,
		4,
		5,
		5,
		6,
		6,
		7,
		7,
		8,
		8,
		9,
		9,
		10,
		10,
		11,
		11,
		12,
		12,
		13,
		13
	};

	// Token: 0x04000548 RID: 1352
	internal static readonly int[] #=zsY8LAUVSMo4dR3ja7g== = new int[]
	{
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		2,
		3,
		7
	};

	// Token: 0x04000549 RID: 1353
	internal static readonly sbyte[] #=zIRTm2U81INPo = new sbyte[]
	{
		16,
		17,
		18,
		0,
		8,
		7,
		9,
		6,
		10,
		5,
		11,
		4,
		12,
		3,
		13,
		2,
		14,
		1,
		15
	};

	// Token: 0x0400054A RID: 1354
	private static readonly sbyte[] #=zlpBoj3whHHTgsgjReA== = new sbyte[]
	{
		0,
		1,
		2,
		3,
		4,
		4,
		5,
		5,
		6,
		6,
		6,
		6,
		7,
		7,
		7,
		7,
		8,
		8,
		8,
		8,
		8,
		8,
		8,
		8,
		9,
		9,
		9,
		9,
		9,
		9,
		9,
		9,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		10,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		11,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		12,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		13,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		14,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		15,
		0,
		0,
		16,
		17,
		18,
		18,
		19,
		19,
		20,
		20,
		20,
		20,
		21,
		21,
		21,
		21,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		28,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29,
		29
	};

	// Token: 0x0400054B RID: 1355
	internal static readonly sbyte[] #=zsobUQ2s= = new sbyte[]
	{
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		8,
		9,
		9,
		10,
		10,
		11,
		11,
		12,
		12,
		12,
		12,
		13,
		13,
		13,
		13,
		14,
		14,
		14,
		14,
		15,
		15,
		15,
		15,
		16,
		16,
		16,
		16,
		16,
		16,
		16,
		16,
		17,
		17,
		17,
		17,
		17,
		17,
		17,
		17,
		18,
		18,
		18,
		18,
		18,
		18,
		18,
		18,
		19,
		19,
		19,
		19,
		19,
		19,
		19,
		19,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		20,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		21,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		22,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		23,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		24,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		25,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		26,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		27,
		28
	};

	// Token: 0x0400054C RID: 1356
	internal static readonly int[] #=zHuD6mw0= = new int[]
	{
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		10,
		12,
		14,
		16,
		20,
		24,
		28,
		32,
		40,
		48,
		56,
		64,
		80,
		96,
		112,
		128,
		160,
		192,
		224,
		0
	};

	// Token: 0x0400054D RID: 1357
	internal static readonly int[] #=z4vhELrw= = new int[]
	{
		0,
		1,
		2,
		3,
		4,
		6,
		8,
		12,
		16,
		24,
		32,
		48,
		64,
		96,
		128,
		192,
		256,
		384,
		512,
		768,
		1024,
		1536,
		2048,
		3072,
		4096,
		6144,
		8192,
		12288,
		16384,
		24576
	};

	// Token: 0x0400054E RID: 1358
	internal short[] #=zVnLx7cu3S4sV;

	// Token: 0x0400054F RID: 1359
	internal int #=zDjtKVgb3mIkZ;

	// Token: 0x04000550 RID: 1360
	internal #=zfJbYIyQbR6lxSFBzJ_T5_yIFJtnFP76a0w== #=zb9dSZnEz1qIR;
}
