﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Units;

// Token: 0x0200025D RID: 605
internal sealed class #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F
{
	// Token: 0x06001259 RID: 4697 RVA: 0x00090608 File Offset: 0x0008E808
	public #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F()
	{
		this.#=zOYncLb8t4lCiceD7OOhqB9o=(new List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM>());
		this.#=zJVJcyocfLne0ZVMOGQ==(new List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM>());
	}

	// Token: 0x0600125A RID: 4698 RVA: 0x00090628 File Offset: 0x0008E828
	public List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=zvTCifSRaFZOllfn_p6GNioE=()
	{
		return this.#=zLn6ZexVMNdPtU2wSF2z8ahGyy$33CvBf6A==;
	}

	// Token: 0x0600125B RID: 4699 RVA: 0x00090630 File Offset: 0x0008E830
	public void #=zOYncLb8t4lCiceD7OOhqB9o=(List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=z$Ib9gYQ=)
	{
		this.#=zLn6ZexVMNdPtU2wSF2z8ahGyy$33CvBf6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600125C RID: 4700 RVA: 0x0009063C File Offset: 0x0008E83C
	public List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=z0FpPt9eHggEgFdE2FA==()
	{
		return this.#=zzUfkWbokMm7TNYB6Cku8wIW9Zo9E;
	}

	// Token: 0x0600125D RID: 4701 RVA: 0x00090644 File Offset: 0x0008E844
	public void #=zJVJcyocfLne0ZVMOGQ==(List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=z$Ib9gYQ=)
	{
		this.#=zzUfkWbokMm7TNYB6Cku8wIW9Zo9E = #=z$Ib9gYQ=;
	}

	// Token: 0x0600125E RID: 4702 RVA: 0x00090650 File Offset: 0x0008E850
	public void #=z20ohAjI=(object[] #=zDd4hozcxS065cNCGjA==, Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> #=ztKvq_Y9pgrutl6u$aLDpjmc=, UnitTypeCollection #=zlhLE8UQVU0AG)
	{
		this.#=zOYncLb8t4lCiceD7OOhqB9o=(new List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM>());
		this.#=zJVJcyocfLne0ZVMOGQ==(new List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM>());
		if (#=zDd4hozcxS065cNCGjA== != null)
		{
			for (int i = 0; i < #=zDd4hozcxS065cNCGjA==.Length; i++)
			{
				#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM #=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM = new #=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM((Dictionary<string, object>)#=zDd4hozcxS065cNCGjA==[i], #=ztKvq_Y9pgrutl6u$aLDpjmc=, #=zlhLE8UQVU0AG);
				if (#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM != null && #=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM.#=zq2bPTdY=() != (#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM.#=zArez$Gs=)0)
				{
					if (#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM.#=zisvlKsvs85jd()[ResourceTypes.AllianceGold] > 0)
					{
						this.#=z0FpPt9eHggEgFdE2FA==().Add(#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM);
					}
					else if (#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM.#=zisvlKsvs85jd()[ResourceTypes.AllianceSilver] > 0)
					{
						this.#=zvTCifSRaFZOllfn_p6GNioE=().Add(#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM);
					}
				}
			}
		}
	}

	// Token: 0x0600125F RID: 4703 RVA: 0x000906DC File Offset: 0x0008E8DC
	public #=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM #=zzbOeLbLtmvMC(int #=zTgxc8FPtK7T2)
	{
		for (int i = 0; i < this.#=zvTCifSRaFZOllfn_p6GNioE=().Count; i++)
		{
			if (this.#=zvTCifSRaFZOllfn_p6GNioE=()[i].Id == #=zTgxc8FPtK7T2)
			{
				return this.#=zvTCifSRaFZOllfn_p6GNioE=()[i];
			}
		}
		for (int j = 0; j < this.#=z0FpPt9eHggEgFdE2FA==().Count; j++)
		{
			if (this.#=z0FpPt9eHggEgFdE2FA==()[j].Id == #=zTgxc8FPtK7T2)
			{
				return this.#=z0FpPt9eHggEgFdE2FA==()[j];
			}
		}
		return null;
	}

	// Token: 0x04000A99 RID: 2713
	private List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=zLn6ZexVMNdPtU2wSF2z8ahGyy$33CvBf6A==;

	// Token: 0x04000A9A RID: 2714
	private List<#=zwhLjjv0vVRInKwF39yuaARK_3pbH506mlgRiRebe5LLM> #=zzUfkWbokMm7TNYB6Cku8wIW9Zo9E;
}
