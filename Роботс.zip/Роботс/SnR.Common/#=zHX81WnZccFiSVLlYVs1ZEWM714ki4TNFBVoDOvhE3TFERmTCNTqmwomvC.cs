﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x02000104 RID: 260
internal sealed class #=zHX81WnZccFiSVLlYVs1ZEWM714ki4TNFBVoDOvhE3TFERmTCNTqmwomvCwiE : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060006CE RID: 1742 RVA: 0x000398D0 File Offset: 0x00037AD0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x000398D4 File Offset: 0x00037AD4
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=))
		{
			return;
		}
		#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= = (#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=)this.#=zcDRV51Ut$7oP;
		#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=().#=zd634hMCtcd$T(#=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().ItemTypeId);
		int num;
		int num2;
		if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z_hmItAwnEING() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zqRJC4XyBqf1D)1)
		{
			num = 1;
			num2 = #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount;
		}
		else
		{
			num = #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().Amount;
			num2 = 1;
		}
		for (int i = 0; i < num; i++)
		{
			string text = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=(), num2, #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=.#=zXFnsTSimqiPo().IsBuyAndUse);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908923954), new object[]
				{
					#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zkfqcY3I=(),
					num2
				});
			}
			else
			{
				text = JSONManager.Cut(text);
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924146), new object[]
				{
					#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zkfqcY3I=(),
					num2,
					text
				});
			}
		}
	}
}
