﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x02000055 RID: 85
internal sealed class #=z3rfOYNK$7gX4ahwPAsnHF9vdxPJ7 : EscherContainer
{
	// Token: 0x0600028E RID: 654 RVA: 0x00016758 File Offset: 0x00014958
	public #=z3rfOYNK$7gX4ahwPAsnHF9vdxPJ7() : base(EscherRecordType.DGG_CONTAINER)
	{
	}
}
