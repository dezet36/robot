﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x0200028A RID: 650
internal sealed class #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1
{
	// Token: 0x060013BD RID: 5053 RVA: 0x00097F4C File Offset: 0x0009614C
	public #=zmams4JIhsOnnOzmys6M92JAjk41wikW8ZyJ$1xXTX3c1(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zVNqezYTad3Gx, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z8StzeqE= = #=zVNqezYTad3Gx;
		this.#=zBsXSanI= = #=zuJjQ1XU=.#=z$2ijYGRf0FB5();
	}

	// Token: 0x060013BE RID: 5054 RVA: 0x00097F68 File Offset: 0x00096168
	public bool #=zgxmFrVwfCJn_(int #=zrP8tv0fgzpCr)
	{
		bool result;
		try
		{
			string text = this.#=zBsXSanI=.#=zMV_fZC22CEHViE8g4A==(#=zrP8tv0fgzpCr, true);
			if (!text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963422), new object[]
				{
					#=zrP8tv0fgzpCr
				});
				result = true;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963374), new object[]
				{
					#=zrP8tv0fgzpCr,
					JSONManager.Cut(text)
				});
				result = false;
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
			result = false;
		}
		return result;
	}

	// Token: 0x04000B66 RID: 2918
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000B67 RID: 2919
	private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=;
}
