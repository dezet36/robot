﻿using System;
using System.Collections.Generic;

// Token: 0x020001C1 RID: 449
internal sealed class #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD
{
	// Token: 0x06000D58 RID: 3416 RVA: 0x000689F4 File Offset: 0x00066BF4
	public #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD()
	{
		this.#=z3zaziys= = new Dictionary<int, #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx>();
	}

	// Token: 0x06000D59 RID: 3417 RVA: 0x00068A08 File Offset: 0x00066C08
	public void #=zZJ6fWCM=(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zU4TPzxM=)
	{
		if (this.#=z3zaziys=.ContainsKey(#=zU4TPzxM=.#=zMuFMjGQ=()))
		{
			#=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx #=zN6vLxX6NWe8ohc6DScgGk43q_hSx = this.#=z3zaziys=[#=zU4TPzxM=.#=zMuFMjGQ=()];
			if (#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zU_eEdz869MZE() != (int)#=zU4TPzxM=.#=z5iePdUZjnAHd())
			{
				#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=z_0iw0dySJHLu((int)#=zU4TPzxM=.#=z5iePdUZjnAHd());
				#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zIR9Xlcg=(DateTime.Now);
				return;
			}
		}
		else
		{
			this.#=z3zaziys=[#=zU4TPzxM=.#=zMuFMjGQ=()] = new #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx(#=zU4TPzxM=.#=zMuFMjGQ=(), #=zU4TPzxM=.#=z5iePdUZjnAHd());
		}
	}

	// Token: 0x06000D5A RID: 3418 RVA: 0x00068A84 File Offset: 0x00066C84
	public bool #=zR5pc2qgJfKgf(#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zm92199OybSmIl9Uefw==)
	{
		int num = 0;
		bool flag = false;
		foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ in #=zm92199OybSmIl9Uefw==)
		{
			if (this.#=z3zaziys=.ContainsKey(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
			{
				#=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx #=zN6vLxX6NWe8ohc6DScgGk43q_hSx = this.#=z3zaziys=[#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()];
				if ((int)#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=z5iePdUZjnAHd() != #=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zU_eEdz869MZE())
				{
					flag = true;
					break;
				}
				if (#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zPHMvvJ8=() < DateTime.Now - TimeSpan.FromMinutes(2.0))
				{
					num++;
				}
			}
		}
		return num >= 2 && !flag;
	}

	// Token: 0x06000D5B RID: 3419 RVA: 0x00068B40 File Offset: 0x00066D40
	public void #=zm7nSMZ8=()
	{
		List<int> list = new List<int>();
		foreach (#=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx #=zN6vLxX6NWe8ohc6DScgGk43q_hSx in this.#=z3zaziys=.Values)
		{
			if (#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zPHMvvJ8=() < DateTime.Now - TimeSpan.FromMinutes(3.0))
			{
				list.Add(#=zN6vLxX6NWe8ohc6DScgGk43q_hSx.#=zMuFMjGQ=());
			}
		}
		foreach (int key in list)
		{
			this.#=z3zaziys=.Remove(key);
		}
	}

	// Token: 0x040007AD RID: 1965
	private Dictionary<int, #=zVYhrtgzJRvuhGW_0cjTu2fpsUXUyL9UhCOR6630GtcVD.#=zN6vLxX6NWe8ohc6DScgGk43q_hSx> #=z3zaziys=;

	// Token: 0x020001C2 RID: 450
	private sealed class #=zN6vLxX6NWe8ohc6DScgGk43q_hSx
	{
		// Token: 0x06000D5C RID: 3420 RVA: 0x00068C0C File Offset: 0x00066E0C
		public #=zN6vLxX6NWe8ohc6DScgGk43q_hSx(int #=zAk8mKBk=, double #=z9h1TqIc=)
		{
			this.#=zbsxKkj4=(#=zAk8mKBk=);
			this.#=z_0iw0dySJHLu((int)#=z9h1TqIc=);
			this.#=zIR9Xlcg=(DateTime.Now);
		}

		// Token: 0x06000D5D RID: 3421 RVA: 0x00068C30 File Offset: 0x00066E30
		public int #=zMuFMjGQ=()
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}

		// Token: 0x06000D5E RID: 3422 RVA: 0x00068C38 File Offset: 0x00066E38
		public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D5F RID: 3423 RVA: 0x00068C44 File Offset: 0x00066E44
		public int #=zU_eEdz869MZE()
		{
			return this.#=zpXNBNUwBXwC4eOfIAQ==;
		}

		// Token: 0x06000D60 RID: 3424 RVA: 0x00068C4C File Offset: 0x00066E4C
		public void #=z_0iw0dySJHLu(int #=z$Ib9gYQ=)
		{
			this.#=zpXNBNUwBXwC4eOfIAQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D61 RID: 3425 RVA: 0x00068C58 File Offset: 0x00066E58
		public DateTime #=zPHMvvJ8=()
		{
			return this.#=zJDEdzIaDvHbnYM06$w==;
		}

		// Token: 0x06000D62 RID: 3426 RVA: 0x00068C60 File Offset: 0x00066E60
		public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
		{
			this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
		}

		// Token: 0x040007AE RID: 1966
		private int #=zdw4aIlzRxu5LWjlGFw==;

		// Token: 0x040007AF RID: 1967
		private int #=zpXNBNUwBXwC4eOfIAQ==;

		// Token: 0x040007B0 RID: 1968
		private DateTime #=zJDEdzIaDvHbnYM06$w==;
	}
}
