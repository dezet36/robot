﻿using System;

// Token: 0x02000196 RID: 406
internal sealed class #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY=
{
	// Token: 0x06000BAE RID: 2990 RVA: 0x0005865C File Offset: 0x0005685C
	public #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY=(int #=zXHTER4Q=, int #=zhCgcfxGrLF3u, int #=zRLNm1Ug1v0RG)
	{
		this.#=z6LUCX1zMpXIf(#=zXHTER4Q=);
		this.#=zWJSACVZlhl6v(#=zhCgcfxGrLF3u);
		this.#=zCTYwZBTbsgPZ(#=zRLNm1Ug1v0RG);
	}

	// Token: 0x06000BAF RID: 2991 RVA: 0x0005867C File Offset: 0x0005687C
	public int #=z2UCBrfce7z8r()
	{
		return this.#=z$67euFAUnKwkyTDxKw==;
	}

	// Token: 0x06000BB0 RID: 2992 RVA: 0x00058684 File Offset: 0x00056884
	private void #=z6LUCX1zMpXIf(int #=z$Ib9gYQ=)
	{
		this.#=z$67euFAUnKwkyTDxKw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000BB1 RID: 2993 RVA: 0x00058690 File Offset: 0x00056890
	public int #=z1$GKSNmtfrzR()
	{
		return this.#=zhTie06AcR59n6jO2wE1g6EE=;
	}

	// Token: 0x06000BB2 RID: 2994 RVA: 0x00058698 File Offset: 0x00056898
	private void #=zWJSACVZlhl6v(int #=z$Ib9gYQ=)
	{
		this.#=zhTie06AcR59n6jO2wE1g6EE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000BB3 RID: 2995 RVA: 0x000586A4 File Offset: 0x000568A4
	public int #=zGJTylv6IVXpT()
	{
		return this.#=znt$zHMpLl1PwyIPEnbCpixM=;
	}

	// Token: 0x06000BB4 RID: 2996 RVA: 0x000586AC File Offset: 0x000568AC
	private void #=zCTYwZBTbsgPZ(int #=z$Ib9gYQ=)
	{
		this.#=znt$zHMpLl1PwyIPEnbCpixM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000BB5 RID: 2997 RVA: 0x000586B8 File Offset: 0x000568B8
	public int #=zMbI49ITzPNVB()
	{
		return this.#=z1$GKSNmtfrzR() * this.#=zGJTylv6IVXpT();
	}

	// Token: 0x06000BB6 RID: 2998 RVA: 0x000586C8 File Offset: 0x000568C8
	public int #=zunVWVnmqJuqR()
	{
		return this.#=z2UCBrfce7z8r() * this.#=zGJTylv6IVXpT();
	}

	// Token: 0x06000BB7 RID: 2999 RVA: 0x000586D8 File Offset: 0x000568D8
	public int #=zZKOviA1u5Mb9vJK4B4fIhHn2XvMU(int #=zNvCMwussKumm)
	{
		int num = #=zNvCMwussKumm / this.#=zGJTylv6IVXpT();
		if (#=zNvCMwussKumm % this.#=zGJTylv6IVXpT() > 0)
		{
			num++;
		}
		return num;
	}

	// Token: 0x06000BB8 RID: 3000 RVA: 0x00058700 File Offset: 0x00056900
	public int #=zC$WOVdQc1g7UCejyvB8Cj6s=(int #=zNvCMwussKumm)
	{
		return this.#=zZKOviA1u5Mb9vJK4B4fIhHn2XvMU(#=zNvCMwussKumm) * this.#=zGJTylv6IVXpT();
	}

	// Token: 0x04000642 RID: 1602
	private int #=z$67euFAUnKwkyTDxKw==;

	// Token: 0x04000643 RID: 1603
	private int #=zhTie06AcR59n6jO2wE1g6EE=;

	// Token: 0x04000644 RID: 1604
	private int #=znt$zHMpLl1PwyIPEnbCpixM=;
}
