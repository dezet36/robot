﻿using System;
using common;
using NExcel.Biff;

// Token: 0x0200011D RID: 285
internal sealed class #=zINqPaypOVANwYlpJtujz4xc= : #=zzbpCJK3dGFyQL8hO_FEikfY=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x060006E8 RID: 1768 RVA: 0x00039E0C File Offset: 0x0003800C
	public #=zINqPaypOVANwYlpJtujz4xc=()
	{
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x00039E14 File Offset: 0x00038014
	public #=zINqPaypOVANwYlpJtujz4xc=(string #=zWj7xLq8=)
	{
		try
		{
			this.#=zziO1gvU= = double.Parse(#=zWj7xLq8=);
		}
		catch (FormatException ex)
		{
			#=zINqPaypOVANwYlpJtujz4xc=.#=zJLdzGuI=.warn(ex, ex);
			this.#=zziO1gvU= = 0.0;
		}
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x00039E7C File Offset: 0x0003807C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[9];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zOnKjUs92eTFw.#=zd$BbM3Y=();
		DoubleHelper.getIEEEBytes(this.#=zziO1gvU=, array, 1);
		return array;
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x00039EAC File Offset: 0x000380AC
	public override int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zziO1gvU= = DoubleHelper.getIEEEDouble(#=zJ5GWysk=, #=z4J_G3VM=);
		return 8;
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x00039EBC File Offset: 0x000380BC
	public override double #=z1bSEHQ8=()
	{
		return this.#=zziO1gvU=;
	}

	// Token: 0x0400041C RID: 1052
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zINqPaypOVANwYlpJtujz4xc=));

	// Token: 0x0400041D RID: 1053
	private double #=zziO1gvU=;
}
