﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x020001A9 RID: 425
internal sealed class #=zU3cP2VAjCLIwckk8jYHplBykCpwX50k3i59vZMzv634RqBn1nJR2W84= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000CDE RID: 3294 RVA: 0x000665C0 File Offset: 0x000647C0
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zNA3wycrO1gxV = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
		this.#=zcupCkK7MGUUPPNNUnE95P7g= = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=zQwNUa7X4qnHM = #=zuJjQ1XU=.#=zMJwfeAYJPt8h1j02AQ==();
		this.#=zlLpCQWZ_ADwE2On60a39SZg= = #=zuJjQ1XU=.#=zoVA6$xcZ4s_kK6oLGzNOhWE=();
	}

	// Token: 0x06000CDF RID: 3295 RVA: 0x000665F4 File Offset: 0x000647F4
	protected override void #=zvb5bnug=()
	{
		List<ProphecyTypes> list = new List<ProphecyTypes>();
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list2 = new List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>();
		foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== in this.#=zNA3wycrO1gxV)
		{
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=znqqYiI0yKfELaxv8MQ==() != ProphecyTypes.NotProphecy)
			{
				list2.Add(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==);
				if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zXuw1agBmq5jc() != DateTime.MinValue && !#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zosN4hoVyBAOs() && !list.Contains(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=znqqYiI0yKfELaxv8MQ==()))
				{
					list.Add(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=znqqYiI0yKfELaxv8MQ==());
				}
			}
		}
		bool flag = false;
		#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=();
		foreach (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== in this.#=zQwNUa7X4qnHM)
		{
			if (#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=z71_rggORFKZ5() > DateTime.Now)
			{
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zk$6QZNA=(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=zMuFMjGQ=());
				if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= != null && #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)500)
				{
					flag = true;
				}
			}
		}
		Dictionary<ProphecyTypes, List<int>> dictionary = new Dictionary<ProphecyTypes, List<int>>();
		foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2 in list2)
		{
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zLg_4gHQfENBn() == 0 && !list.Contains(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==()) && (flag || #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==() != ProphecyTypes.Elite))
			{
				string text = this.#=zBsXSanI=.#=zEoRJ9iFCtj0AXzcGqw==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zMuFMjGQ=());
				if (text.Length > 3000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952169), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952130), new object[]
					{
						JSONManager.Cut(text)
					});
				}
				list.Add(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==());
			}
			else if ((#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zLg_4gHQfENBn() == 9 || #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zosN4hoVyBAOs()) && (flag || #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==() != ProphecyTypes.Elite))
			{
				List<int> list3;
				if (dictionary.ContainsKey(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==()))
				{
					list3 = dictionary[#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==()];
				}
				else
				{
					list3 = new List<int>();
					dictionary[#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=znqqYiI0yKfELaxv8MQ==()] = list3;
				}
				list3.Add(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==2.#=zMuFMjGQ=());
			}
		}
		foreach (List<int> list4 in dictionary.Values)
		{
			if (list4.Count > 1)
			{
				string text2 = this.#=zBsXSanI=.#=zPGdAfjp1ACpVyjjsrA==(list4);
				if (text2.Length > 3000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952093), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952295), new object[]
					{
						JSONManager.Cut(text2)
					});
				}
			}
			else if (list4.Count == 1)
			{
				foreach (int #=zZe01zHKivUKm in list4)
				{
					string text3 = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zZe01zHKivUKm, null);
					if (text3.Length > 3000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952233), Array.Empty<object>());
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951922), new object[]
						{
							JSONManager.Cut(text3)
						});
					}
				}
			}
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRefreshProphecies && list.Count == 0 && this.#=zlLpCQWZ_ADwE2On60a39SZg= < 10)
		{
			Dictionary<ProphecyTypes, int> dictionary2 = new Dictionary<ProphecyTypes, int>
			{
				{
					ProphecyTypes.Personal,
					10002
				},
				{
					ProphecyTypes.Alliance,
					10003
				},
				{
					ProphecyTypes.Elite,
					10054
				}
			};
			foreach (ProphecyTypes prophecyTypes in dictionary2.Keys)
			{
				if (prophecyTypes != ProphecyTypes.Elite || flag)
				{
					int #=zH2f5zJg= = dictionary2[prophecyTypes];
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zcupCkK7MGUUPPNNUnE95P7g=[#=zH2f5zJg=];
					if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null && #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0)
					{
						#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), 1);
						if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926895), new object[]
							{
								#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
								1
							});
							base.#=zW3vCypudd9EC().NextExecutionTime = DateTime.Now;
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926506), new object[]
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
							1,
							JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
						});
						break;
					}
				}
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951879), Array.Empty<object>());
		this.#=zBsXSanI=.#=zeoI_JM$qmO3Jp7VRURuP390=();
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908951818), Array.Empty<object>());
	}

	// Token: 0x0400076B RID: 1899
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zNA3wycrO1gxV;

	// Token: 0x0400076C RID: 1900
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zcupCkK7MGUUPPNNUnE95P7g=;

	// Token: 0x0400076D RID: 1901
	private #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zQwNUa7X4qnHM;

	// Token: 0x0400076E RID: 1902
	private int #=zlLpCQWZ_ADwE2On60a39SZg=;
}
