﻿using System;

// Token: 0x02000037 RID: 55
internal sealed class #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==
{
	// Token: 0x060001C5 RID: 453 RVA: 0x000126B8 File Offset: 0x000108B8
	public #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x000126C0 File Offset: 0x000108C0
	public void #=zzQwUIEs=(#=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x000126CC File Offset: 0x000108CC
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x000126D4 File Offset: 0x000108D4
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x000126E0 File Offset: 0x000108E0
	public int #=zMuFMjGQ=()
	{
		return this.#=zq2bPTdY=().Id;
	}

	// Token: 0x060001CA RID: 458 RVA: 0x000126F0 File Offset: 0x000108F0
	public string #=zkfqcY3I=()
	{
		return this.#=zq2bPTdY=().#=zkfqcY3I=();
	}

	// Token: 0x060001CB RID: 459 RVA: 0x00012700 File Offset: 0x00010900
	public double #=zjw43QGFcPyHH()
	{
		if (this.#=zq2bPTdY=() == null)
		{
			return 0.0;
		}
		if (this.#=zq2bPTdY=().#=zjw43QGFcPyHH() == null)
		{
			return 0.0;
		}
		if (this.#=zq2bPTdY=().#=zjw43QGFcPyHH().Count == 0 || this.#=zvnZc$RhG_1Du() <= 0)
		{
			return 0.0;
		}
		if (this.#=zq2bPTdY=().#=zjw43QGFcPyHH().Count > this.#=zvnZc$RhG_1Du() - 1)
		{
			return this.#=zq2bPTdY=().#=zjw43QGFcPyHH()[this.#=zvnZc$RhG_1Du() - 1];
		}
		return this.#=zq2bPTdY=().#=zjw43QGFcPyHH()[this.#=zq2bPTdY=().#=zjw43QGFcPyHH().Count - 1];
	}

	// Token: 0x04000065 RID: 101
	private #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ== #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x04000066 RID: 102
	private int #=zq9EZwxO2tjqgH$qWVQ==;
}
