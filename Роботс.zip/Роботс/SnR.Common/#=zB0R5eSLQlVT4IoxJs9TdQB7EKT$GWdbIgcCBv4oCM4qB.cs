﻿using System;
using System.Collections.Generic;
using System.Threading;

// Token: 0x020000BF RID: 191
internal sealed class #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB
{
	// Token: 0x06000502 RID: 1282 RVA: 0x00028C90 File Offset: 0x00026E90
	public #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB(int #=zR_ghn73r50Vw, #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=z1$_sdfQ= #=zgaoDPaw=, bool #=z$yMliMM5aDsRZdymIw==)
	{
		this.#=z1MStkmYOu5PU = #=zR_ghn73r50Vw;
		this.#=zjQk5HHk= = #=zgaoDPaw=;
		this.#=zTnSnUV0P5HXFwlkgqw== = #=z$yMliMM5aDsRZdymIw==;
		this.#=zds4RKfw= = new List<object>();
		this.#=zc8KXkxfHi333 = DateTime.MinValue;
		this.#=zhxeJazvZk9Mx = null;
		this.#=zdDVWRLKtNQo0 = new object();
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x00028CE0 File Offset: 0x00026EE0
	public void #=zNiDqnIE=(object #=zdPovgAA=)
	{
		object obj = this.#=zdDVWRLKtNQo0;
		lock (obj)
		{
			if (!this.#=zds4RKfw=.Contains(#=zdPovgAA=))
			{
				this.#=zds4RKfw=.Add(#=zdPovgAA=);
			}
			if (this.#=zhxeJazvZk9Mx == null)
			{
				this.#=zhxeJazvZk9Mx = new Thread(new ParameterizedThreadStart(#=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=zmXoPYH4=));
				this.#=zhxeJazvZk9Mx.Start(this);
				this.#=zc8KXkxfHi333 = DateTime.Now + TimeSpan.FromSeconds((double)this.#=z1MStkmYOu5PU);
			}
			else if (this.#=zTnSnUV0P5HXFwlkgqw==)
			{
				this.#=zc8KXkxfHi333 = DateTime.Now + TimeSpan.FromSeconds((double)this.#=z1MStkmYOu5PU);
			}
		}
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x00028DA4 File Offset: 0x00026FA4
	private static void #=zmXoPYH4=(object #=zhGPl6L1BHcOG4ijStubgP6Y=)
	{
		#=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB = (#=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB)#=zhGPl6L1BHcOG4ijStubgP6Y=;
		if (#=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB != null)
		{
			#=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=zvb5bnug=();
		}
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x00028DC4 File Offset: 0x00026FC4
	private void #=zvb5bnug=()
	{
		bool flag = false;
		while (!flag)
		{
			TimeSpan t = this.#=zc8KXkxfHi333 - DateTime.Now;
			if (t <= TimeSpan.Zero)
			{
				flag = true;
			}
			else
			{
				Thread.Sleep((int)t.TotalMilliseconds + 1);
			}
		}
		object obj = this.#=zdDVWRLKtNQo0;
		lock (obj)
		{
			this.#=zjQk5HHk=(this.#=zds4RKfw=);
			this.#=zds4RKfw= = new List<object>();
			this.#=zhxeJazvZk9Mx = null;
		}
	}

	// Token: 0x040001F0 RID: 496
	private int #=z1MStkmYOu5PU;

	// Token: 0x040001F1 RID: 497
	private #=zB0R5eSLQlVT4IoxJs9TdQB7EKT$GWdbIgcCBv4oCM4qB.#=z1$_sdfQ= #=zjQk5HHk=;

	// Token: 0x040001F2 RID: 498
	private bool #=zTnSnUV0P5HXFwlkgqw==;

	// Token: 0x040001F3 RID: 499
	private List<object> #=zds4RKfw=;

	// Token: 0x040001F4 RID: 500
	private DateTime #=zc8KXkxfHi333;

	// Token: 0x040001F5 RID: 501
	private Thread #=zhxeJazvZk9Mx;

	// Token: 0x040001F6 RID: 502
	private object #=zdDVWRLKtNQo0;

	// Token: 0x020000C0 RID: 192
	// (Invoke) Token: 0x06000507 RID: 1287
	public delegate void #=z1$_sdfQ=(List<object> #=zDRWcagA=);
}
