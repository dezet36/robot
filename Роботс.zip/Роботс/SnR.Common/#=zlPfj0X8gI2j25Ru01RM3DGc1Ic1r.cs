﻿using System;
using System.Text;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;

// Token: 0x0200027D RID: 637
internal sealed class #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06001335 RID: 4917 RVA: 0x00095BF0 File Offset: 0x00093DF0
	public #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r(Cell #=zLWZxLVM=, ExternalSheet #=zgLaCy2g=)
	{
		this.#=zq07FqDs= = #=zLWZxLVM=;
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=zgLaCy2g=;
	}

	// Token: 0x06001336 RID: 4918 RVA: 0x00095C08 File Offset: 0x00093E08
	public #=zlPfj0X8gI2j25Ru01RM3DGc1Ic1r(string #=zWj7xLq8=, ExternalSheet #=zgLaCy2g=)
	{
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=zgLaCy2g=;
		this.#=zEKQLhRCOdkGm = true;
		this.#=zXY7Hgaj_6YSr = true;
		int num = #=zWj7xLq8=.IndexOf('!');
		string s = #=zWj7xLq8=.Substring(num + 1);
		this.#=zEh1wLVk= = NExcel.Biff.CellReferenceHelper.getColumn(s);
		this.#=zg9A8_dw= = NExcel.Biff.CellReferenceHelper.getRow(s);
		string text = #=zWj7xLq8=.Substring(0, num);
		if (text[0] == '\'' && text[text.Length - 1] == '\'')
		{
			text = text.Substring(1, text.Length - 1 - 1);
		}
		this.#=zNEZ0SGey$A9J = #=zgLaCy2g=.getExternalSheetIndex(text);
		if (this.#=zNEZ0SGey$A9J < 0)
		{
			throw new FormulaException(FormulaException.#=zvQjmbmClENVK8Iem6A==, text);
		}
	}

	// Token: 0x06001337 RID: 4919 RVA: 0x00095CB8 File Offset: 0x00093EB8
	public int #=z85RU4eQ=()
	{
		return this.#=zEh1wLVk=;
	}

	// Token: 0x06001338 RID: 4920 RVA: 0x00095CC0 File Offset: 0x00093EC0
	public int #=zNMAKc1U=()
	{
		return this.#=zg9A8_dw=;
	}

	// Token: 0x06001339 RID: 4921 RVA: 0x00095CC8 File Offset: 0x00093EC8
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[7];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zHPI6sEfaHA0e.#=zd$BbM3Y=();
		IntegerHelper.getTwoBytes(this.#=zNEZ0SGey$A9J, array, 1);
		IntegerHelper.getTwoBytes(this.#=zg9A8_dw=, array, 3);
		int num = this.#=zEh1wLVk=;
		if (this.#=zXY7Hgaj_6YSr)
		{
			num |= 32768;
		}
		if (this.#=zEKQLhRCOdkGm)
		{
			num |= 16384;
		}
		IntegerHelper.getTwoBytes(num, array, 5);
		return array;
	}

	// Token: 0x0600133A RID: 4922 RVA: 0x00095D34 File Offset: 0x00093F34
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zNEZ0SGey$A9J = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		this.#=zg9A8_dw= = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 2], #=zJ5GWysk=[#=z4J_G3VM= + 3]);
		int @int = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 4], #=zJ5GWysk=[#=z4J_G3VM= + 5]);
		this.#=zEh1wLVk= = (@int & 255);
		this.#=zEKQLhRCOdkGm = ((@int & 16384) != 0);
		this.#=zXY7Hgaj_6YSr = ((@int & 32768) != 0);
		return 6;
	}

	// Token: 0x0600133B RID: 4923 RVA: 0x00095DA8 File Offset: 0x00093FA8
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		NExcel.Biff.CellReferenceHelper.getCellReference(this.#=zNEZ0SGey$A9J, this.#=zEh1wLVk=, !this.#=zEKQLhRCOdkGm, this.#=zg9A8_dw=, !this.#=zXY7Hgaj_6YSr, this.#=zJY$tXiAJ_$AzbtOFtg==, #=zXvwCnz8=);
	}

	// Token: 0x0600133C RID: 4924 RVA: 0x00095DDC File Offset: 0x00093FDC
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		if (this.#=zEKQLhRCOdkGm)
		{
			this.#=zEh1wLVk= += #=zUFUpoGQeXcCf;
		}
		if (this.#=zXY7Hgaj_6YSr)
		{
			this.#=zg9A8_dw= += #=zJhSli$dVSPlw;
		}
	}

	// Token: 0x0600133D RID: 4925 RVA: 0x00095E0C File Offset: 0x0009400C
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (this.#=zEh1wLVk= >= #=zMYEXL$w=)
		{
			this.#=zEh1wLVk=++;
		}
	}

	// Token: 0x0600133E RID: 4926 RVA: 0x00095E30 File Offset: 0x00094030
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (this.#=zEh1wLVk= >= #=zMYEXL$w=)
		{
			this.#=zEh1wLVk=--;
		}
	}

	// Token: 0x0600133F RID: 4927 RVA: 0x00095E54 File Offset: 0x00094054
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zihyUFzs=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (this.#=zg9A8_dw= >= #=zihyUFzs=)
		{
			this.#=zg9A8_dw=++;
		}
	}

	// Token: 0x06001340 RID: 4928 RVA: 0x00095E78 File Offset: 0x00094078
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zihyUFzs=, bool #=z8f56V5lpWtIC)
	{
		if (#=zoAAA4zDu4OU$ != this.#=zNEZ0SGey$A9J)
		{
			return;
		}
		if (this.#=zg9A8_dw= >= #=zihyUFzs=)
		{
			this.#=zg9A8_dw=--;
		}
	}

	// Token: 0x04000B14 RID: 2836
	private bool #=zEKQLhRCOdkGm;

	// Token: 0x04000B15 RID: 2837
	private bool #=zXY7Hgaj_6YSr;

	// Token: 0x04000B16 RID: 2838
	private int #=zEh1wLVk=;

	// Token: 0x04000B17 RID: 2839
	private int #=zg9A8_dw=;

	// Token: 0x04000B18 RID: 2840
	private Cell #=zq07FqDs=;

	// Token: 0x04000B19 RID: 2841
	private int #=zNEZ0SGey$A9J;

	// Token: 0x04000B1A RID: 2842
	private ExternalSheet #=zJY$tXiAJ_$AzbtOFtg==;
}
