﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x020001CC RID: 460
internal sealed class #=zWoKrUer$b_XCCTV5dGhUPlYjupuYWCGqQBMBZFk= : Task
{
	// Token: 0x06000D9F RID: 3487 RVA: 0x0006A280 File Offset: 0x00068480
	public #=zWoKrUer$b_XCCTV5dGhUPlYjupuYWCGqQBMBZFk=(List<int> #=zpHIhdZR1Go7Q, string #=zxHIOVSaavkpE, TimeSpan #=zDMrQCas=) : base(TaskSources.Manual, TaskSeverities.Background, TaskTypes.SendUnit, DateTime.Now, TimeSpan.Zero, #=zDMrQCas=, #=zDMrQCas=, DateTime.MaxValue, true)
	{
		this.#=z$hsREZwlEjTa = #=zpHIhdZR1Go7Q;
		this.#=zP3P9itgnlF6q = #=zxHIOVSaavkpE;
	}

	// Token: 0x06000DA0 RID: 3488 RVA: 0x0006A2B8 File Offset: 0x000684B8
	public #=zWoKrUer$b_XCCTV5dGhUPlYjupuYWCGqQBMBZFk=(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x06000DA1 RID: 3489 RVA: 0x0006A2C8 File Offset: 0x000684C8
	public string #=z8MLrXqpSC$z2kv75$A==()
	{
		return this.#=zP3P9itgnlF6q;
	}

	// Token: 0x06000DA2 RID: 3490 RVA: 0x0006A2D0 File Offset: 0x000684D0
	public List<int> #=zkJTeRgUAnrMZ()
	{
		return this.#=z$hsREZwlEjTa;
	}

	// Token: 0x06000DA3 RID: 3491 RVA: 0x0006A2D8 File Offset: 0x000684D8
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		object[] array = (object[])#=z8e5z318=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875633)];
		this.#=z$hsREZwlEjTa = new List<int>();
		foreach (object value in array)
		{
			this.#=z$hsREZwlEjTa.Add(Convert.ToInt32(value));
		}
		this.#=zP3P9itgnlF6q = Convert.ToString(#=z8e5z318=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875620)]);
	}

	// Token: 0x06000DA4 RID: 3492 RVA: 0x0006A344 File Offset: 0x00068544
	public override void UpdateTask(Dictionary<string, object> #=z8e5z318=)
	{
		base.UpdateTask(#=z8e5z318=);
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x06000DA5 RID: 3493 RVA: 0x0006A354 File Offset: 0x00068554
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874471);
		}
	}

	// Token: 0x06000DA6 RID: 3494 RVA: 0x0006A360 File Offset: 0x00068560
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		object[] array = new object[this.#=z$hsREZwlEjTa.Count];
		for (int i = 0; i < this.#=z$hsREZwlEjTa.Count; i++)
		{
			array[i] = this.#=z$hsREZwlEjTa[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875633)] = array;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875620)] = this.#=zP3P9itgnlF6q;
		return dictionary;
	}

	// Token: 0x040007C4 RID: 1988
	private List<int> #=z$hsREZwlEjTa;

	// Token: 0x040007C5 RID: 1989
	private string #=zP3P9itgnlF6q;
}
