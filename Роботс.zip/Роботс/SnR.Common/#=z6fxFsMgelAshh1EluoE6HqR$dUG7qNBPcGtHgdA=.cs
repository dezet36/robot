﻿using System;
using System.Collections.Generic;

// Token: 0x02000084 RID: 132
internal sealed class #=z6fxFsMgelAshh1EluoE6HqR$dUG7qNBPcGtHgdA= : IComparer<#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=>
{
	// Token: 0x060003A8 RID: 936 RVA: 0x00020094 File Offset: 0x0001E294
	public #=z6fxFsMgelAshh1EluoE6HqR$dUG7qNBPcGtHgdA=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zl$x2hTQ=)
	{
		this.#=zYiC$Jug= = #=zl$x2hTQ=.#=zfTB62qendhk_VEy8rw==();
		this.#=z94jR55E= = #=zl$x2hTQ=.#=zY0soxphmGIACbOHy6A==();
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000200B4 File Offset: 0x0001E2B4
	public int Compare(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXg4BqCM=, #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zcf4mMM4=)
	{
		int num = #=zXg4BqCM=.#=zSL$CHR_zajMs().CompareTo(#=zcf4mMM4=.#=zSL$CHR_zajMs());
		if (num != 0)
		{
			return num;
		}
		DateTime t = DateTime.Today - TimeSpan.FromDays(15.0);
		num = (#=zXg4BqCM=.#=zmj4J_vTRu57u() < t).CompareTo(#=zcf4mMM4=.#=zmj4J_vTRu57u() < t);
		if (num != 0)
		{
			return num;
		}
		double num2 = Math.Sqrt(Math.Pow((double)(#=zXg4BqCM=.#=zfTB62qendhk_VEy8rw==() - this.#=zYiC$Jug=), 2.0) + Math.Pow((double)(#=zXg4BqCM=.#=zY0soxphmGIACbOHy6A==() - this.#=z94jR55E=), 2.0));
		double value = Math.Sqrt(Math.Pow((double)(#=zcf4mMM4=.#=zfTB62qendhk_VEy8rw==() - this.#=zYiC$Jug=), 2.0) + Math.Pow((double)(#=zcf4mMM4=.#=zY0soxphmGIACbOHy6A==() - this.#=z94jR55E=), 2.0));
		return num2.CompareTo(value);
	}

	// Token: 0x04000148 RID: 328
	private int #=zYiC$Jug=;

	// Token: 0x04000149 RID: 329
	private int #=z94jR55E=;
}
