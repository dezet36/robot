﻿using System;
using System.Threading;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x02000213 RID: 531
internal sealed class #=zcAioOxLrSCaNUY8WB6BWlWow_$LLreAAm98rBuM7Nvlpo_dosw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600104B RID: 4171 RVA: 0x0007DA54 File Offset: 0x0007BC54
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x0600104C RID: 4172 RVA: 0x0007DA58 File Offset: 0x0007BC58
	protected override void #=zvb5bnug=()
	{
		int num = (int)(this.#=zcDRV51Ut$7oP.ExecutionTime + TimeSpan.FromSeconds(15.0) - DateTime.Now).TotalMilliseconds;
		if (num > 0)
		{
			Thread.Sleep(num + 1);
		}
		object data = JSONManager.GetData(this.#=zBsXSanI=.#=zeoI_JM$qmO3Jp7VRURuP390=());
		base.#=zL1HTbwC75LO$(data);
		#=zcAioOxLrSCaNUY8WB6BWlWow_$LLreAAm98rBuM7Nvlpo_dosw==.#=zwqF5KngciPEuUAe8xmYIVt0=(this.#=zG2wnL_q7IxpD, data);
	}

	// Token: 0x0600104D RID: 4173 RVA: 0x0007DAC8 File Offset: 0x0007BCC8
	public static void #=zwqF5KngciPEuUAe8xmYIVt0=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, object #=zxheKPs0=)
	{
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU= = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zG2wnL_q7IxpD, #=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO(), #=zxheKPs0=, null);
		#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw== #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw== = new #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==();
		Task #=zI9YjZ6Url_ar = new #=z3PrlvJvoAvMaRit6oJzhopb9RaLKiwiIEQ==(TaskSources.Manual, TaskSeverities.Urgent, TaskTypes.HireTroops, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
		#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zC68QI$8=(#=zI9YjZ6Url_ar, #=zG2wnL_q7IxpD, #=zuJjQ1XU=, false);
		UnitTypeCollection #=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		#=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==.#=zkcXnL8F0L56vUTI_jbqUKJg=(#=zlhLE8UQVU0AG, #=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().HiringPlan);
	}
}
