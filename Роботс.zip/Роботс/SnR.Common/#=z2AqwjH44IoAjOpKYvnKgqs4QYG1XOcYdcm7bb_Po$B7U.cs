﻿using System;

// Token: 0x02000046 RID: 70
internal sealed class #=z2AqwjH44IoAjOpKYvnKgqs4QYG1XOcYdcm7bb_Po$B7U
{
	// Token: 0x0600022A RID: 554 RVA: 0x00014FA0 File Offset: 0x000131A0
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x0600022B RID: 555 RVA: 0x00014FA8 File Offset: 0x000131A8
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600022C RID: 556 RVA: 0x00014FB4 File Offset: 0x000131B4
	public int #=z87Y19O7ba$bQhxFzP5Tzx1U=()
	{
		return this.#=zygqPbLLDctbMETRUHd8Z0$753rMb;
	}

	// Token: 0x0600022D RID: 557 RVA: 0x00014FBC File Offset: 0x000131BC
	public void #=zxyxsU3Nw3pkbz6KzQL4a3Lw=(int #=z$Ib9gYQ=)
	{
		this.#=zygqPbLLDctbMETRUHd8Z0$753rMb = #=z$Ib9gYQ=;
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00014FC8 File Offset: 0x000131C8
	public double #=zfsK6IsXPY3fH()
	{
		return this.#=zA9J9FpPB5EjjjBoHzw1inqo=;
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00014FD0 File Offset: 0x000131D0
	public void #=z$lXumYwaQq$0(double #=z$Ib9gYQ=)
	{
		this.#=zA9J9FpPB5EjjjBoHzw1inqo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000230 RID: 560 RVA: 0x00014FDC File Offset: 0x000131DC
	public double #=zeA6BU4adJ_o7()
	{
		return this.#=z0ufPuGAj7zH72DeQ0aawkk8=;
	}

	// Token: 0x06000231 RID: 561 RVA: 0x00014FE4 File Offset: 0x000131E4
	public void #=zN4pxYhBIgTlk(double #=z$Ib9gYQ=)
	{
		this.#=z0ufPuGAj7zH72DeQ0aawkk8= = #=z$Ib9gYQ=;
	}

	// Token: 0x040000A4 RID: 164
	private int #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x040000A5 RID: 165
	private int #=zygqPbLLDctbMETRUHd8Z0$753rMb;

	// Token: 0x040000A6 RID: 166
	private double #=zA9J9FpPB5EjjjBoHzw1inqo=;

	// Token: 0x040000A7 RID: 167
	private double #=z0ufPuGAj7zH72DeQ0aawkk8=;
}
