﻿// Token: 0x020000D7 RID: 215
internal sealed partial class #=zCrk95KsMUskvgPI6KwlLKPNMoWb7r3RKtw== : global::System.Windows.Forms.Form
{
	// Token: 0x060005C3 RID: 1475 RVA: 0x0002FC60 File Offset: 0x0002DE60
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000265 RID: 613
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
