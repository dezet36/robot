﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;

// Token: 0x02000122 RID: 290
internal sealed partial class #=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw== : Form
{
	// Token: 0x0600072A RID: 1834 RVA: 0x0003BD90 File Offset: 0x00039F90
	public #=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw==()
	{
		this.#=zgpzgXirqPT5_();
		this.#=z13iv$cZNPHkR.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091871));
		this.#=z$nuoogBxZAN6.Focus();
		this.#=zIKkwWpOCxG5A.#=z20ohAjI=(#=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw==.#=z2Z4nvgvUQZ3W((int)GameApplicationData.#=z7wsmjLWw49AC()), false, false);
		this.#=zZ_J8a9DbQI5$$lOyQw==.#=z20ohAjI=(#=zIuGnKCJz99xhOWm0wVpr5tT5D37WsFddGw==.#=zLYnIpHUp4u4Ym463Hw==(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(GameApplicationData.#=zZ2dsDUeWDYAN())), false, false);
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x0600072B RID: 1835 RVA: 0x0003BE08 File Offset: 0x0003A008
	public static List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> #=z2Z4nvgvUQZ3W(int #=zMNyjkoNBl46z)
	{
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		foreach (object obj in Enum.GetValues(typeof(GameApplicationData.GameHosters)))
		{
			GameApplicationData.GameHosters gameHosters = (GameApplicationData.GameHosters)obj;
			string text;
			if (gameHosters <= GameApplicationData.GameHosters.VKontakte)
			{
				switch (gameHosters)
				{
				case GameApplicationData.GameHosters.MyMail:
					text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093464);
					break;
				case GameApplicationData.GameHosters.GamesMail:
					text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093448);
					break;
				case (GameApplicationData.GameHosters)3:
					goto IL_A8;
				case GameApplicationData.GameHosters.Odnoklassniki:
					text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093426);
					break;
				default:
					if (gameHosters != GameApplicationData.GameHosters.VKontakte)
					{
						goto IL_A8;
					}
					text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093412);
					break;
				}
			}
			else if (gameHosters != GameApplicationData.GameHosters.PlariumRu)
			{
				if (gameHosters != GameApplicationData.GameHosters.PlariumEn)
				{
					goto IL_A8;
				}
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093631);
			}
			else
			{
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093386);
			}
			IL_B6:
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(text);
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==((int)gameHosters, text, (gameHosters & (GameApplicationData.GameHosters)#=zMNyjkoNBl46z) > (GameApplicationData.GameHosters)0));
			continue;
			IL_A8:
			text = gameHosters.ToString();
			goto IL_B6;
		}
		return list;
	}

	// Token: 0x0600072C RID: 1836 RVA: 0x0003BF18 File Offset: 0x0003A118
	public static List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> #=zLYnIpHUp4u4Ym463Hw==(int #=z9gIpoQ3Yc7P7)
	{
		List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> list = new List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==>();
		foreach (object obj in Enum.GetValues(typeof(GameApplicationData.Games)))
		{
			GameApplicationData.Games #=zSg73axlT2_0Z = (GameApplicationData.Games)obj;
			string text;
			switch (#=zSg73axlT2_0Z)
			{
			case GameApplicationData.Games.RulesOfWar:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093600);
				break;
			case GameApplicationData.Games.CodexOfPirate:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093589);
				break;
			case GameApplicationData.Games.WarOfThrones:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093565);
				break;
			case GameApplicationData.Games.Konflikt:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093540);
				break;
			case GameApplicationData.Games.Sparta:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093525);
				break;
			case GameApplicationData.Games.Nords:
				text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093508);
				break;
			default:
				text = #=zSg73axlT2_0Z.ToString();
				break;
			}
			text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(text);
			int num = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(#=zSg73axlT2_0Z);
			list.Add(new #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==(num, text, (num & #=z9gIpoQ3Yc7P7) > 0));
		}
		return list;
	}

	// Token: 0x0600072D RID: 1837 RVA: 0x0003C028 File Offset: 0x0003A228
	private void #=zgnwqoqlRSG4m(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		string text = this.#=z$nuoogBxZAN6.Text;
		if (string.IsNullOrWhiteSpace(text))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093238));
			return;
		}
		if (!string.IsNullOrEmpty(this.#=zbSLhtDkqeUY2.Text) && !#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zrrJL63eTcjQB(this.#=zbSLhtDkqeUY2.Text))
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093196));
			return;
		}
		if (#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zNerpgmc=(text).StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075201)))
		{
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z9Cr3BXA=(text);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093149));
			base.Close();
			return;
		}
		int #=z84LHPL2J2FN = this.#=zIKkwWpOCxG5A.#=zqust6dSu_GiZ();
		int #=zSc7_kYiCqktH = this.#=zZ_J8a9DbQI5$$lOyQw==.#=zqust6dSu_GiZ();
		string text2 = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zi7BLllIjRjs1(text, #=z84LHPL2J2FN, #=zSc7_kYiCqktH, this.#=zbSLhtDkqeUY2.Text);
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(text2);
		string text3 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), string.Empty);
		if (string.IsNullOrEmpty(text3))
		{
			string text4 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), string.Empty);
			if (string.IsNullOrEmpty(text4))
			{
				text4 = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104554), new object[]
				{
					JSONManager.Cut(text2)
				}).ToString();
			}
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(text4);
			return;
		}
		this.#=z13iv$cZNPHkR.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909093040), new object[]
		{
			text3
		}).ToString();
		#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z9Cr3BXA=(text3);
		this.#=zkN1LLvakdGuh.Enabled = false;
		#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094822), #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094793)), text), text3, null, false);
	}

	// Token: 0x0600072E RID: 1838 RVA: 0x0003C1CC File Offset: 0x0003A3CC
	private void #=zJkTp7s2AX6JvDknJ4g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zrrJL63eTcjQB(this.#=zbSLhtDkqeUY2.Text) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094492) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094789));
	}

	// Token: 0x06000730 RID: 1840 RVA: 0x0003C21C File Offset: 0x0003A41C
	private void #=zgpzgXirqPT5_()
	{
		this.#=z13iv$cZNPHkR = new TextBox();
		this.#=z$nuoogBxZAN6 = new TextBox();
		this.#=zdIohk$YkZSod = new Label();
		this.#=zkN1LLvakdGuh = new Button();
		this.#=zZ_J8a9DbQI5$$lOyQw== = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zIKkwWpOCxG5A = new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==();
		this.#=zulTJPbH8Sy1jOye98g== = new Label();
		this.#=zNVRUv5ZYgNJ7 = new Label();
		this.#=zbSLhtDkqeUY2 = new TextBox();
		this.#=zkL8xlualzf7P = new Button();
		this.#=zHizNmxAqiU8a = new Label();
		base.SuspendLayout();
		this.#=z13iv$cZNPHkR.Location = new Point(12, 12);
		this.#=z13iv$cZNPHkR.Multiline = true;
		this.#=z13iv$cZNPHkR.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094454);
		this.#=z13iv$cZNPHkR.ReadOnly = true;
		this.#=z13iv$cZNPHkR.ScrollBars = ScrollBars.Vertical;
		this.#=z13iv$cZNPHkR.Size = new Size(448, 218);
		this.#=z13iv$cZNPHkR.TabIndex = 0;
		this.#=z13iv$cZNPHkR.TabStop = false;
		this.#=z$nuoogBxZAN6.Location = new Point(101, 236);
		this.#=z$nuoogBxZAN6.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094429);
		this.#=z$nuoogBxZAN6.Size = new Size(359, 20);
		this.#=z$nuoogBxZAN6.TabIndex = 1;
		this.#=zdIohk$YkZSod.AutoSize = true;
		this.#=zdIohk$YkZSod.Location = new Point(12, 239);
		this.#=zdIohk$YkZSod.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094405);
		this.#=zdIohk$YkZSod.Size = new Size(63, 13);
		this.#=zdIohk$YkZSod.TabIndex = 2;
		this.#=zdIohk$YkZSod.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094639);
		this.#=zkN1LLvakdGuh.Location = new Point(231, 500);
		this.#=zkN1LLvakdGuh.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094621);
		this.#=zkN1LLvakdGuh.Size = new Size(75, 23);
		this.#=zkN1LLvakdGuh.TabIndex = 3;
		this.#=zkN1LLvakdGuh.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094586);
		this.#=zkN1LLvakdGuh.UseVisualStyleBackColor = true;
		this.#=zkN1LLvakdGuh.Click += this.#=zgnwqoqlRSG4m;
		this.#=zZ_J8a9DbQI5$$lOyQw==.Location = new Point(368, 288);
		this.#=zZ_J8a9DbQI5$$lOyQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094581);
		this.#=zZ_J8a9DbQI5$$lOyQw==.Size = new Size(184, 183);
		this.#=zZ_J8a9DbQI5$$lOyQw==.TabIndex = 6;
		this.#=zIKkwWpOCxG5A.Location = new Point(101, 288);
		this.#=zIKkwWpOCxG5A.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094552);
		this.#=zIKkwWpOCxG5A.Size = new Size(184, 183);
		this.#=zIKkwWpOCxG5A.TabIndex = 7;
		this.#=zulTJPbH8Sy1jOye98g==.AutoSize = true;
		this.#=zulTJPbH8Sy1jOye98g==.Location = new Point(291, 288);
		this.#=zulTJPbH8Sy1jOye98g==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094543);
		this.#=zulTJPbH8Sy1jOye98g==.Size = new Size(49, 13);
		this.#=zulTJPbH8Sy1jOye98g==.TabIndex = 4;
		this.#=zulTJPbH8Sy1jOye98g==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094259);
		this.#=zNVRUv5ZYgNJ7.AutoSize = true;
		this.#=zNVRUv5ZYgNJ7.Location = new Point(12, 288);
		this.#=zNVRUv5ZYgNJ7.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094242);
		this.#=zNVRUv5ZYgNJ7.Size = new Size(39, 13);
		this.#=zNVRUv5ZYgNJ7.TabIndex = 5;
		this.#=zNVRUv5ZYgNJ7.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094230);
		this.#=zbSLhtDkqeUY2.Location = new Point(158, 262);
		this.#=zbSLhtDkqeUY2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094209);
		this.#=zbSLhtDkqeUY2.Size = new Size(221, 20);
		this.#=zbSLhtDkqeUY2.TabIndex = 1;
		this.#=zkL8xlualzf7P.Location = new Point(385, 262);
		this.#=zkL8xlualzf7P.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094191);
		this.#=zkL8xlualzf7P.Size = new Size(75, 23);
		this.#=zkL8xlualzf7P.TabIndex = 8;
		this.#=zkL8xlualzf7P.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094166);
		this.#=zkL8xlualzf7P.UseVisualStyleBackColor = true;
		this.#=zkL8xlualzf7P.Click += this.#=zJkTp7s2AX6JvDknJ4g==;
		this.#=zHizNmxAqiU8a.AutoSize = true;
		this.#=zHizNmxAqiU8a.Location = new Point(12, 265);
		this.#=zHizNmxAqiU8a.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094151);
		this.#=zHizNmxAqiU8a.Size = new Size(107, 13);
		this.#=zHizNmxAqiU8a.TabIndex = 2;
		this.#=zHizNmxAqiU8a.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094383);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(564, 535);
		base.Controls.Add(this.#=zkL8xlualzf7P);
		base.Controls.Add(this.#=zZ_J8a9DbQI5$$lOyQw==);
		base.Controls.Add(this.#=zIKkwWpOCxG5A);
		base.Controls.Add(this.#=zulTJPbH8Sy1jOye98g==);
		base.Controls.Add(this.#=zNVRUv5ZYgNJ7);
		base.Controls.Add(this.#=zkN1LLvakdGuh);
		base.Controls.Add(this.#=zHizNmxAqiU8a);
		base.Controls.Add(this.#=zdIohk$YkZSod);
		base.Controls.Add(this.#=zbSLhtDkqeUY2);
		base.Controls.Add(this.#=z$nuoogBxZAN6);
		base.Controls.Add(this.#=z13iv$cZNPHkR);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094347);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909094347);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x0400044D RID: 1101
	private TextBox #=z13iv$cZNPHkR;

	// Token: 0x0400044E RID: 1102
	private TextBox #=z$nuoogBxZAN6;

	// Token: 0x0400044F RID: 1103
	private Label #=zdIohk$YkZSod;

	// Token: 0x04000450 RID: 1104
	private Button #=zkN1LLvakdGuh;

	// Token: 0x04000451 RID: 1105
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=zZ_J8a9DbQI5$$lOyQw==;

	// Token: 0x04000452 RID: 1106
	private #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== #=zIKkwWpOCxG5A;

	// Token: 0x04000453 RID: 1107
	private Label #=zulTJPbH8Sy1jOye98g==;

	// Token: 0x04000454 RID: 1108
	private Label #=zNVRUv5ZYgNJ7;

	// Token: 0x04000455 RID: 1109
	private TextBox #=zbSLhtDkqeUY2;

	// Token: 0x04000456 RID: 1110
	private Button #=zkL8xlualzf7P;

	// Token: 0x04000457 RID: 1111
	private Label #=zHizNmxAqiU8a;
}
