﻿using System;
using System.Collections.Generic;

// Token: 0x020001F3 RID: 499
internal sealed class #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== : List<#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==>
{
	// Token: 0x06000F1B RID: 3867 RVA: 0x0007889C File Offset: 0x00076A9C
	public #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== #=zd634hMCtcd$T(int #=zAk8mKBk=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zMuFMjGQ=() == #=zAk8mKBk=)
			{
				return base[i];
			}
		}
		return new #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==(#=zAk8mKBk=);
	}
}
