﻿using System;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;
using NExcel.Read.Biff;

// Token: 0x020001CD RID: 461
internal sealed class #=zWtqvncUGnSJ_BQ4yLgYhygVKqw42 : CellValue, BooleanCell, Cell, FormulaData, BooleanFormulaCell, FormulaCell
{
	// Token: 0x06000DA7 RID: 3495 RVA: 0x0006A3D8 File Offset: 0x000685D8
	public #=zWtqvncUGnSJ_BQ4yLgYhygVKqw42(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		this.#=z$qdebj6dfyrP = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
		this.#=zaiKvawI= = false;
		this.#=zJ5GWysk= = this.getRecord().Data;
		Assert.verify(this.#=zJ5GWysk=[6] != 2);
		this.#=zaiKvawI= = (this.#=zJ5GWysk=[8] == 1);
	}

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000DA8 RID: 3496 RVA: 0x0006A43C File Offset: 0x0006863C
	public bool BooleanValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x06000DA9 RID: 3497 RVA: 0x0006A444 File Offset: 0x00068644
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x06000DAA RID: 3498 RVA: 0x0006A454 File Offset: 0x00068654
	public new string Contents
	{
		get
		{
			return this.#=zaiKvawI=.ToString().ToUpper();
		}
	}

	// Token: 0x17000047 RID: 71
	// (get) Token: 0x06000DAB RID: 3499 RVA: 0x0006A468 File Offset: 0x00068668
	public new CellType Type
	{
		get
		{
			return CellType.BOOLEAN_FORMULA;
		}
	}

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x06000DAC RID: 3500 RVA: 0x0006A470 File Offset: 0x00068670
	public string Formula
	{
		get
		{
			if (this.#=z06z1muCn8UNxP0yekw== == null)
			{
				sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 22];
				Array.Copy(this.#=zJ5GWysk=, 22, array, 0, array.Length);
				FormulaParser formulaParser = new FormulaParser(array, this, this.#=z$qdebj6dfyrP, this.#=zLJGAifU=, this.Sheet.#=znmG_kF0igveL8fwbqw==().Settings);
				formulaParser.parse();
				this.#=z06z1muCn8UNxP0yekw== = formulaParser.Formula;
			}
			return this.#=z06z1muCn8UNxP0yekw==;
		}
	}

	// Token: 0x06000DAD RID: 3501 RVA: 0x0006A4E4 File Offset: 0x000686E4
	public sbyte[] getFormulaData()
	{
		sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 6];
		Array.Copy(this.#=zJ5GWysk=, 6, array, 0, this.#=zJ5GWysk=.Length - 6);
		return array;
	}

	// Token: 0x040007C6 RID: 1990
	private bool #=zaiKvawI=;

	// Token: 0x040007C7 RID: 1991
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x040007C8 RID: 1992
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x040007C9 RID: 1993
	private string #=z06z1muCn8UNxP0yekw==;

	// Token: 0x040007CA RID: 1994
	private sbyte[] #=zJ5GWysk=;
}
