﻿using System;

// Token: 0x02000148 RID: 328
internal interface #=zLG6uk$Gz0HYsu5astWupkBlXmaty4YJdWIIUAcw=
{
	// Token: 0x060008A0 RID: 2208
	#=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A== #=zo4pctbtCxQ0d();

	// Token: 0x060008A1 RID: 2209
	int #=zMuFMjGQ=();

	// Token: 0x060008A2 RID: 2210
	int #=zFMDiymuLQ7_4();

	// Token: 0x060008A3 RID: 2211
	string #=zkfqcY3I=();

	// Token: 0x060008A4 RID: 2212
	int #=zvnZc$RhG_1Du();

	// Token: 0x060008A5 RID: 2213
	DateTime #=zGhmoNZChgwf8();

	// Token: 0x060008A6 RID: 2214
	bool #=z5kpAZQpjT2b7();
}
