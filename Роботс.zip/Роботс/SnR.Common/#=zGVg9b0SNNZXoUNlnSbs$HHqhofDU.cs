﻿using System;

// Token: 0x020000FE RID: 254
internal sealed class #=zGVg9b0SNNZXoUNlnSbs$HHqhofDU : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000690 RID: 1680 RVA: 0x00033DA8 File Offset: 0x00031FA8
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zIFRl8bAAVcfa;
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x00033DB0 File Offset: 0x00031FB0
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x00033DB4 File Offset: 0x00031FB4
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080271);
	}
}
