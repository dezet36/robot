﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using System.Web;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200008E RID: 142
internal sealed class #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=
{
	// Token: 0x060003DB RID: 987 RVA: 0x00021EB0 File Offset: 0x000200B0
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zQJXHt0k9VEeL, ProxyInfo #=zGNXp2dgl6HSh)
	{
		this.#=zhoOF5s8= = #=zQJXHt0k9VEeL;
		this.#=zsHG$Y6w= = #=zGNXp2dgl6HSh;
		this.#=zyfyFTf4= = new StringBuilder();
		this.#=zo2RQp2yC5Y8V = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
		this.#=zrQZFF9ZLZCqi = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
		this.#=zQGaIow0kN$r$6A7CPw== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
		this.#=zPZuvSTeWXxFf9DC_cA== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
		this.#=z0cuDVoxxW7KKHiS7Ow== = ((this.#=zdojm_UxSjvCm().Count == 0) ? ((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1) : ((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0));
		this.#=zqWJEzYwJdOh3xlWBcA== = false;
	}

	// Token: 0x060003DC RID: 988 RVA: 0x00021F18 File Offset: 0x00020118
	private CookieContainer #=zdojm_UxSjvCm()
	{
		if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x == null)
		{
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x = new CookieContainer();
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zYRp1VUqXfCjmdQCbRw==(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zspiARYMWXWCQ(), #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x);
		}
		return #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x;
	}

	// Token: 0x060003DD RID: 989 RVA: 0x00021F44 File Offset: 0x00020144
	public static #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zOGyoZpE=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=)
	{
		ProxyInfo proxyInfo = ProxyInfo.#=zn2ovxJQcP5BV().#=zHYTbT9o3ZkEb();
		if (proxyInfo == null)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056383), Array.Empty<object>());
			return #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedNoProxyFound;
		}
		if (proxyInfo.Type != ProxyTypes.NoProxy)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056335), new object[]
			{
				proxyInfo
			});
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056308), new object[]
			{
				proxyInfo
			});
		}
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4= #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4= = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=(#=zhoOF5s8=, proxyInfo);
		#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zG4GdawKHNR1$ = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
		if (#=zhoOF5s8=.#=zTvv00UNStlgLec8wAKQUeKGOQNz3() > 1 && !string.IsNullOrEmpty(#=zhoOF5s8=.#=zw3M1PzX18p_r()))
		{
			#=zhoOF5s8=.#=zpeAmYAKx8nem(null);
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056276), Array.Empty<object>());
		}
		if (#=zhoOF5s8=.#=zTvv00UNStlgLec8wAKQUeKGOQNz3() > 2 && !string.IsNullOrEmpty(#=zhoOF5s8=.#=z$V9uwJPAniCv()))
		{
			#=zhoOF5s8=.#=zZJbepNH_IDuQ(null);
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056450), Array.Empty<object>());
		}
		int num = 0;
		while (num < 15 && #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zfkRA7n4a_zZE(out #=zG4GdawKHNR1$))
		{
			num++;
		}
		if (#=zG4GdawKHNR1$ != #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful)
		{
			string text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056385), JSONManager.FixStringForFileName(#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS()));
			try
			{
				#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(text, #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zyfyFTf4=.ToString(), null, false);
				#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056097), new object[]
				{
					text
				});
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056060), new object[]
				{
					text + Environment.NewLine + #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
				});
			}
		}
		return #=zG4GdawKHNR1$;
	}

	// Token: 0x060003DE RID: 990 RVA: 0x000220DC File Offset: 0x000202DC
	public bool #=zfkRA7n4a_zZE(out #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zyGENCSs=)
	{
		bool result;
		try
		{
			Thread.Sleep(3000 + new Random().Next(7000));
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zh5VnWdQ=;
			if (string.IsNullOrEmpty(this.#=zhoOF5s8=.#=z$V9uwJPAniCv()))
			{
				if (this.#=zo2RQp2yC5Y8V == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0)
				{
					#=zh5VnWdQ= = this.#=zjWopFeIWC2Ej();
					if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1 || #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2)
					{
						this.#=zo2RQp2yC5Y8V = #=zh5VnWdQ=.#=zZ_Vdevw=();
					}
				}
				else if (this.#=zo2RQp2yC5Y8V == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2)
				{
					if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z97Z7CxekCb4f())
					{
						#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedWrongPassword;
						this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Action, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056000), Array.Empty<object>());
						return false;
					}
					#=zh5VnWdQ= = this.#=zXMko7huUF_Pyj3d8z7mHweI=();
					if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1)
					{
						this.#=zrQZFF9ZLZCqi = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
						this.#=zo2RQp2yC5Y8V = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
					}
					else
					{
						this.#=zrQZFF9ZLZCqi = #=zh5VnWdQ=.#=zZ_Vdevw=();
					}
				}
				else
				{
					#=zh5VnWdQ= = this.#=zyzRUcck=();
					if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2)
					{
						#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedWrongPassword;
						return false;
					}
				}
			}
			else if (string.IsNullOrEmpty(this.#=zhoOF5s8=.#=zw3M1PzX18p_r()))
			{
				#=zh5VnWdQ= = this.#=zMSegtj$iORvP();
				if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2)
				{
					this.#=zhoOF5s8=.#=zZJbepNH_IDuQ(null);
				}
			}
			else
			{
				#=zh5VnWdQ= = this.#=zijJuNnDJO1t$();
				if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1)
				{
					#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful;
					return false;
				}
				if (#=zh5VnWdQ=.#=zZ_Vdevw=() != (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2)
				{
					#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
					return false;
				}
				this.#=zhoOF5s8=.#=zpeAmYAKx8nem(null);
			}
			bool flag = false;
			bool flag2 = false;
			if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
			{
				flag = this.#=zxLgtrglxDiZGQBTC$A==(#=zh5VnWdQ=);
				flag2 = false;
			}
			bool flag3 = flag || flag2 || #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1 || #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2;
			if (!flag && !flag2 && #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3)
			{
				if (#=zh5VnWdQ=.#=z1_c0G5o=() != null)
				{
					this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zh5VnWdQ=.#=z1_c0G5o=()), Array.Empty<object>());
					if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
					{
						this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Debug, JSONManager.Cut(#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z0KhF75_5Qux2()), Array.Empty<object>());
					}
				}
				else if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
				{
					this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, JSONManager.Cut(#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z0KhF75_5Qux2()), Array.Empty<object>());
				}
			}
			if (this.#=zqWJEzYwJdOh3xlWBcA==)
			{
				#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedTooManyRequests;
				if (!flag3)
				{
					ProxyInfo.#=zn2ovxJQcP5BV().#=zCF48XOrkrCH5eTWGFRgk1tQ=(this.#=zsHG$Y6w=);
				}
			}
			else
			{
				#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
			}
			result = flag3;
		}
		catch (Exception ex)
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(ex), Array.Empty<object>());
			#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
			this.#=z2b213par1Y6I(ex);
			if (ex.Message.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056220)))
			{
				ProxyInfo.#=zn2ovxJQcP5BV().#=zarxi$nsR5nh$2OfZZw==(this.#=zsHG$Y6w=);
			}
			result = false;
		}
		return result;
	}

	// Token: 0x060003DF RID: 991 RVA: 0x0002239C File Offset: 0x0002059C
	private bool #=zxLgtrglxDiZGQBTC$A==(#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zrhvCoyA=)
	{
		if (#=zrhvCoyA= == null)
		{
			throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056200));
		}
		if (#=zrhvCoyA=.#=zCh2q0p3jzp4u() == null)
		{
			throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056169));
		}
		if (#=zrhvCoyA=.#=zCh2q0p3jzp4u().#=z5aV1tF47CwIR() == null)
		{
			throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056135));
		}
		if (#=zrhvCoyA=.#=zCh2q0p3jzp4u().#=z0KhF75_5Qux2() == null)
		{
			throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057877));
		}
		if (#=zrhvCoyA=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1)
		{
			return false;
		}
		bool result = false;
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zrhvCoyA=.#=zCh2q0p3jzp4u();
		if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 403)
		{
			Dictionary<string, object> dictionary = null;
			try
			{
				dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2());
			}
			catch
			{
			}
			if (dictionary != null && dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068985)))
			{
				Convert.ToString(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068985)]);
				if (this.#=zQGaIow0kN$r$6A7CPw== == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0 && #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z5aV1tF47CwIR().ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057828)))
				{
					this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057813), Array.Empty<object>());
					this.#=zQGaIow0kN$r$6A7CPw== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
					result = true;
				}
				else if (this.#=zPZuvSTeWXxFf9DC_cA== == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0)
				{
					this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058017), Array.Empty<object>());
					string text = this.#=zVznV2nzHBK942DE3cw==();
					if (!string.IsNullOrWhiteSpace(text))
					{
						this.#=zYRp1VUqXfCjmdQCbRw==(text);
						this.#=zPZuvSTeWXxFf9DC_cA== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
					}
					else
					{
						this.#=zPZuvSTeWXxFf9DC_cA== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3;
					}
					result = true;
				}
				else if (this.#=z0cuDVoxxW7KKHiS7Ow== == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0)
				{
					this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057978), Array.Empty<object>());
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zbyDiyVoj8UoZ(null);
					#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x = null;
					this.#=zQGaIow0kN$r$6A7CPw== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
					this.#=zPZuvSTeWXxFf9DC_cA== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)0;
					this.#=z0cuDVoxxW7KKHiS7Ow== = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
					result = true;
				}
				else
				{
					this.#=zqWJEzYwJdOh3xlWBcA== = true;
				}
			}
		}
		return result;
	}

	// Token: 0x060003E0 RID: 992 RVA: 0x00022578 File Offset: 0x00020778
	private void #=zYRp1VUqXfCjmdQCbRw==(string #=zm9S8Fd2gJICK0we6rA==)
	{
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zYRp1VUqXfCjmdQCbRw==(#=zm9S8Fd2gJICK0we6rA==, this.#=zdojm_UxSjvCm());
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x00022588 File Offset: 0x00020788
	private static void #=zYRp1VUqXfCjmdQCbRw==(string #=zm9S8Fd2gJICK0we6rA==, CookieContainer #=z1aqYQax9jqUB)
	{
		if (!string.IsNullOrEmpty(#=zm9S8Fd2gJICK0we6rA==))
		{
			if (#=zm9S8Fd2gJICK0we6rA==.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931)))
			{
				#=z1aqYQax9jqUB.SetCookies(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)), #=zm9S8Fd2gJICK0we6rA==);
				return;
			}
			#=z1aqYQax9jqUB.SetCookies(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)), #=zm9S8Fd2gJICK0we6rA== + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057633));
		}
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x000225EC File Offset: 0x000207EC
	private string #=zVznV2nzHBK942DE3cw==()
	{
		Cookie cookie = this.#=zdojm_UxSjvCm().GetCookies(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)))[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057565)];
		if (cookie != null)
		{
			return #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zVznV2nzHBK942DE3cw==(this.#=zhoOF5s8=, cookie.Value, this.#=zsHG$Y6w=, this.#=zyfyFTf4=);
		}
		return null;
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00022648 File Offset: 0x00020848
	public static string #=zVznV2nzHBK942DE3cw==(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, string #=z3A65pb2Dfv1La$eIlA==, ProxyInfo #=zsHG$Y6w=, StringBuilder #=zyfyFTf4=)
	{
		#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zjZWhv$4= = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zZhqMK1rUHEaR0OpJtPNbpIw=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057548)).#=z0KhF75_5Qux2().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057541), HttpUtility.UrlEncode(#=z3A65pb2Dfv1La$eIlA==)), null, null, #=zsHG$Y6w=);
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=zjZWhv$4=, true);
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2b213par1Y6I(#=zyfyFTf4=, #=zjZWhv$4=, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp);
		string text;
		if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 200)
		{
			text = JSONManager.ExtractString((Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057770), string.Empty);
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057767), new object[]
			{
				text
			});
			if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=ztmwqj9gOfD5f3LJDJXnN16s=())
			{
				#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zbyDiyVoj8UoZ(text);
			}
		}
		else
		{
			text = null;
		}
		return text;
	}

	// Token: 0x060003E4 RID: 996 RVA: 0x00022704 File Offset: 0x00020904
	internal static void #=z7hPlwc__UnvN(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=)
	{
		object[] array = new object[#=zshVEGQI=.#=zOdy_aU_tk1aY().Count];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = #=zshVEGQI=.#=zOdy_aU_tk1aY()[i].#=zCCBXDJ5n_DGghKXXmA==();
		}
		try
		{
			string src = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057722);
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendFormat(JSONManager.Decode16(src, true), #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zVZd$8ug=(), (int)GameApplicationData.#=z7wsmjLWw49AC(), (int)GameApplicationData.#=zZ2dsDUeWDYAN());
			stringBuilder.AppendLine();
			stringBuilder.AppendLine();
			stringBuilder.Append(JSONManager.SerializeData(new Dictionary<string, object>
			{
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
					array
				}
			}));
			object[] array2 = JSONManager.GetArray(JSONManager.DeserializeData(#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(stringBuilder.ToString(), null, null, null), true).#=z0KhF75_5Qux2()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
			if (array2 != null)
			{
				foreach (Dictionary<string, object> dictionary in array2)
				{
					string item = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), string.Empty);
					if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zD2giaLw= == null)
					{
						#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zD2giaLw= = new List<string>();
					}
					if (!#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zD2giaLw=.Contains(item))
					{
						int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0);
						object[] array4 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057325));
						List<string> list = new List<string>();
						foreach (object value in array4)
						{
							list.Add(Convert.ToString(value));
						}
						Dictionary<string, object> #=z8e5z318= = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
						foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zshVEGQI=.#=zOdy_aU_tk1aY())
						{
							if (list.Contains(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==()))
							{
								foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
								{
									if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == num)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(Task.#=zErO$$v4=(#=z8e5z318=, null));
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
									}
								}
							}
						}
						#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zD2giaLw=.Add(item);
					}
				}
			}
		}
		catch (Exception ex)
		{
			#=zshVEGQI=.#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057306), new object[]
			{
				ex.Message
			});
		}
	}

	// Token: 0x060003E5 RID: 997 RVA: 0x000229C0 File Offset: 0x00020BC0
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zjWopFeIWC2Ej()
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057534), Array.Empty<object>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = this.#=zL6KXIXs=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057495));
			if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 200)
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057484), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 400 && this.#=zFAM3fyUkKiV4(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057463)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057446))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057427), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception ex)
		{
			this.#=z2b213par1Y6I(ex);
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, ex);
		}
		return result;
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x00022AB8 File Offset: 0x00020CB8
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zyzRUcck=()
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057138), Array.Empty<object>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = this.#=zL6KXIXs=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068546));
			string text = JSONManager.ExtractString((Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057116), string.Empty);
			if (!string.IsNullOrEmpty(text))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057096), Array.Empty<object>());
				this.#=zhoOF5s8=.#=zZJbepNH_IDuQ(text);
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 400 && this.#=zFAM3fyUkKiV4(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057463)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057446))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057068), Array.Empty<object>());
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057265), new object[]
				{
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2()
				});
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception ex)
		{
			this.#=z2b213par1Y6I(ex);
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, ex);
		}
		return result;
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x00022C10 File Offset: 0x00020E10
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zMSegtj$iORvP()
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057234), Array.Empty<object>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = this.#=zL6KXIXs=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057207));
			string text = JSONManager.ExtractString((Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057116), string.Empty);
			if (!string.IsNullOrEmpty(text))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057197), Array.Empty<object>());
				this.#=zhoOF5s8=.#=zpeAmYAKx8nem(text);
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 401)
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception ex)
		{
			this.#=z2b213par1Y6I(ex);
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, ex);
		}
		return result;
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x00022CF4 File Offset: 0x00020EF4
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zijJuNnDJO1t$()
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108088), Array.Empty<object>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = this.#=zL6KXIXs=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108052));
			if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 200)
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2());
				string text = HttpUtility.UrlDecode(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108034), string.Empty));
				string text2 = HttpUtility.UrlDecode(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108019), string.Empty)).Substring(text.Length).Trim();
				if (string.IsNullOrEmpty(text))
				{
					text = text2;
					text2 = null;
				}
				this.#=zhoOF5s8=.#=z9l$gimR8dkJhDCQJAw==(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108014), string.Empty));
				this.#=zhoOF5s8=.#=zpVBlD$IJ4abR(text);
				this.#=zhoOF5s8=.#=zVOkdnwLzxOWf(text2);
				this.#=zhoOF5s8=.#=zPzFoe9Yoa4Jh(HttpUtility.UrlDecode(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108004), string.Empty)));
				this.#=zhoOF5s8=.#=zchs2LGrZFGl4(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107997), string.Empty));
				this.#=zhoOF5s8=.#=zhWr8WM11sNyG(HttpUtility.UrlDecode(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107979), string.Empty)));
			}
			if (!string.IsNullOrEmpty(this.#=zhoOF5s8=.#=zG96rwfOikL5q()))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107969), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 401)
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception ex)
		{
			this.#=z2b213par1Y6I(ex);
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, ex);
		}
		return result;
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x00022EDC File Offset: 0x000210DC
	public static bool #=zzVO7jsiozzIu(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=)
	{
		ProxyInfo proxyInfo = ProxyInfo.#=zn2ovxJQcP5BV().#=zBRHMDb8uMY1n();
		if (proxyInfo == null)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108180), Array.Empty<object>());
			return false;
		}
		if (proxyInfo.Type != ProxyTypes.NoProxy)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056335), new object[]
			{
				proxyInfo
			});
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056308), new object[]
			{
				proxyInfo
			});
		}
		return new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=(#=zhoOF5s8=, proxyInfo).#=zXMko7huUF_Pyj3d8z7mHweI=().#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1;
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x00022F64 File Offset: 0x00021164
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zXMko7huUF_Pyj3d8z7mHweI=()
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			if (string.IsNullOrWhiteSpace(this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS()))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108125), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, null, null);
			}
			else if (!this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075522)))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107814), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, null, null);
			}
			else if (string.IsNullOrWhiteSpace(this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7()))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107738), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, null, null);
			}
			else if (string.IsNullOrWhiteSpace(this.#=zhoOF5s8=.#=zSByqmFV12x0z()) && string.IsNullOrWhiteSpace(this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zuyncuBlQbn2L()))
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107938), Array.Empty<object>());
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, null, null);
			}
			else
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107889), Array.Empty<object>());
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = this.#=zL6KXIXs=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107850));
				foreach (object obj in this.#=zdojm_UxSjvCm().GetCookies(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923))))
				{
					Cookie cookie = (Cookie)obj;
					if (cookie.Name != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057565))
					{
						cookie.Expired = true;
					}
				}
				Dictionary<string, object> dictionary = this.#=zBHgOlx6HcTk2(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp);
				if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 200)
				{
					if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108014)))
					{
						this.#=zhoOF5s8=.#=zZJbepNH_IDuQ(JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057116), string.Empty));
						return new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
					}
				}
				else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 400)
				{
					string text = JSONManager.GetString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107840), null);
					if (string.IsNullOrWhiteSpace(text))
					{
						text = JSONManager.Cut(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2());
					}
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107563)))
					{
						return new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
					}
					return new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, new Exception(text));
				}
				else if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 429)
				{
					return new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)4, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
				}
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception ex)
		{
			this.#=z2b213par1Y6I(ex);
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, ex);
		}
		return result;
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x00023258 File Offset: 0x00021458
	public static #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zHl$V63KooLJO(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, string #=z$C3w6Bs=)
	{
		ProxyInfo proxyInfo = ProxyInfo.#=zn2ovxJQcP5BV().#=zHYTbT9o3ZkEb();
		if (proxyInfo == null)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056383), Array.Empty<object>());
			return #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedNoProxyFound;
		}
		if (proxyInfo.Type != ProxyTypes.NoProxy)
		{
			#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056335), new object[]
			{
				proxyInfo
			});
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107524), new object[]
			{
				proxyInfo
			});
		}
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4= #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4= = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=(#=zhoOF5s8=, proxyInfo);
		#=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zG4GdawKHNR1$ = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
		string #=z0ONi4Bk= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107474);
		#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zxyAQIs1RlUuf(#=z0ONi4Bk=, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107696), #=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS(), #=zhoOF5s8=.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7(), #=z$C3w6Bs=), null);
		int num = 0;
		while (num < 5 && #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zH7t$o07HcqVw(#=z$C3w6Bs=, out #=zG4GdawKHNR1$))
		{
			num++;
		}
		#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zxyAQIs1RlUuf(#=z0ONi4Bk=, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107678), #=zG4GdawKHNR1$, Environment.NewLine), null);
		return #=zG4GdawKHNR1$;
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x00023348 File Offset: 0x00021548
	private bool #=zH7t$o07HcqVw(string #=z$C3w6Bs=, out #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$ #=zyGENCSs=)
	{
		bool result;
		try
		{
			Thread.Sleep(3000 + new Random().Next(7000));
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zh5VnWdQ= = this.#=zSHwTeRbKgEQU(#=z$C3w6Bs=);
			if (#=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1)
			{
				#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.Successful;
				result = false;
			}
			else
			{
				bool flag = false;
				bool flag2 = false;
				if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
				{
					flag = this.#=zxLgtrglxDiZGQBTC$A==(#=zh5VnWdQ=);
					flag2 = false;
				}
				bool flag3 = flag || flag2 || #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1 || #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)2;
				if (!flag && !flag2 && #=zh5VnWdQ=.#=zZ_Vdevw=() == (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3)
				{
					if (#=zh5VnWdQ=.#=z1_c0G5o=() != null)
					{
						this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zh5VnWdQ=.#=z1_c0G5o=()), Array.Empty<object>());
						if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
						{
							this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Debug, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107659), new object[]
							{
								#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z9ZHUN$Y=(),
								JSONManager.Cut(#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z0KhF75_5Qux2())
							});
						}
					}
					else if (#=zh5VnWdQ=.#=zCh2q0p3jzp4u() != null)
					{
						this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107659), new object[]
						{
							#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z9ZHUN$Y=(),
							JSONManager.Cut(#=zh5VnWdQ=.#=zCh2q0p3jzp4u().#=z0KhF75_5Qux2())
						});
					}
				}
				if (this.#=zqWJEzYwJdOh3xlWBcA==)
				{
					#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedTooManyRequests;
					if (!flag3)
					{
						ProxyInfo.#=zn2ovxJQcP5BV().#=zCF48XOrkrCH5eTWGFRgk1tQ=(this.#=zsHG$Y6w=);
					}
				}
				else
				{
					#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
				}
				result = flag3;
			}
		}
		catch (Exception ex)
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(ex), Array.Empty<object>());
			#=zyGENCSs= = #=zBqE8dxOUNedBrN7Qa7btFDDs6kE0.#=zG4GdawKHNR1$.FailedReasonUnknown;
			if (ex.Message.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909056220)))
			{
				ProxyInfo.#=zn2ovxJQcP5BV().#=zarxi$nsR5nh$2OfZZw==(this.#=zsHG$Y6w=);
			}
			result = false;
		}
		return result;
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x00023524 File Offset: 0x00021724
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= #=zSHwTeRbKgEQU(string #=z$C3w6Bs=)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = null;
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ= result;
		try
		{
			this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107636), Array.Empty<object>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zZhqMK1rUHEaR0OpJtPNbpIw=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107604)).#=z0KhF75_5Qux2().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107586), this.#=zhoOF5s8=.#=z$V9uwJPAniCv()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107312), this.#=zhoOF5s8=.#=zw3M1PzX18p_r()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107288), this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107277), #=z$C3w6Bs=), null, this.#=zdojm_UxSjvCm(), this.#=zsHG$Y6w=), true);
			if (#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z9ZHUN$Y=() == 200)
			{
				this.#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107254), Array.Empty<object>());
				this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zuKcwTqrq7yWC(#=z$C3w6Bs=);
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)1, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
			else
			{
				result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, null);
			}
		}
		catch (Exception #=z1148NY8=)
		{
			result = new #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zh5VnWdQ=((#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0=)3, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp, #=z1148NY8=);
		}
		return result;
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x0002364C File Offset: 0x0002184C
	private #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zL6KXIXs=(string #=z1$GFuFE=)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zZhqMK1rUHEaR0OpJtPNbpIw=(#=z1$GFuFE=);
		string newValue = this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS();
		string text = this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7();
		text = text.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077262), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107208));
		string newValue2 = string.IsNullOrWhiteSpace(this.#=zhoOF5s8=.#=zSByqmFV12x0z()) ? this.#=zhoOF5s8=.#=zh5Q$jgycqA15().#=zuyncuBlQbn2L() : this.#=zhoOF5s8=.#=zSByqmFV12x0z();
		#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zAjO7I84RW8RKI9PeCopgq9B$x73y = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107201), newValue).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107443), text).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107586), this.#=zhoOF5s8=.#=z$V9uwJPAniCv()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107312), this.#=zhoOF5s8=.#=zw3M1PzX18p_r()).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107424), newValue2), null, this.#=zdojm_UxSjvCm(), this.#=zsHG$Y6w=);
		if (#=zAjO7I84RW8RKI9PeCopgq9B$x73y.#=zJgvbqC5Kxvxk().RequestUri.ToString().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)) && #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2g56AnsQz6F57FBqTANp4Hk= != null)
		{
			foreach (KeyValuePair<string, string> keyValuePair in #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2g56AnsQz6F57FBqTANp4Hk=)
			{
				#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zE2fpVUDtCZmG(#=zAjO7I84RW8RKI9PeCopgq9B$x73y.#=zJgvbqC5Kxvxk(), keyValuePair.Key, keyValuePair.Value);
			}
		}
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2 = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=zAjO7I84RW8RKI9PeCopgq9B$x73y, true);
		this.#=z2b213par1Y6I(#=zAjO7I84RW8RKI9PeCopgq9B$x73y, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2);
		return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2;
	}

	// Token: 0x060003EF RID: 1007 RVA: 0x000237DC File Offset: 0x000219DC
	private Dictionary<string, object> #=zBHgOlx6HcTk2(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zC1K2Mos=)
	{
		if (string.IsNullOrEmpty(#=zC1K2Mos=.#=z0KhF75_5Qux2()))
		{
			return null;
		}
		Dictionary<string, object> dictionary = null;
		try
		{
			if (#=zC1K2Mos=.#=z0KhF75_5Qux2().StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051205)))
			{
				dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zC1K2Mos=.#=z0KhF75_5Qux2());
			}
		}
		catch
		{
		}
		if (dictionary == null)
		{
			dictionary = new Dictionary<string, object>();
		}
		return dictionary;
	}

	// Token: 0x060003F0 RID: 1008 RVA: 0x00023844 File Offset: 0x00021A44
	private string #=zFAM3fyUkKiV4(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zC1K2Mos=, string #=zNraCe1Y=)
	{
		return JSONManager.GetString(this.#=zBHgOlx6HcTk2(#=zC1K2Mos=), #=zNraCe1Y=, null);
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x00023854 File Offset: 0x00021A54
	private void #=z2b213par1Y6I(#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zjZWhv$4=, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zC1K2Mos=)
	{
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2b213par1Y6I(this.#=zyfyFTf4=, #=zjZWhv$4=, #=zC1K2Mos=);
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x00023864 File Offset: 0x00021A64
	private static void #=z2b213par1Y6I(StringBuilder #=zyfyFTf4=, #=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zjZWhv$4=, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zC1K2Mos=)
	{
		try
		{
			string text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107413);
			#=zyfyFTf4=.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107329), new object[]
			{
				#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zxrOUaQcZA_57(#=zjZWhv$4=),
				#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zME6c59mcU_6Y(#=zC1K2Mos=),
				text,
				DateTime.Now
			});
		}
		catch
		{
		}
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x000238CC File Offset: 0x00021ACC
	private void #=z2b213par1Y6I(Exception #=zN_s5Z5A=)
	{
		try
		{
			string text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909107413);
			this.#=zyfyFTf4=.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109026), new object[]
			{
				#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=),
				null,
				text,
				DateTime.Now
			});
		}
		catch
		{
		}
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x00023930 File Offset: 0x00021B30
	public static void #=zOM_Iu4t4SVDEYd3_p$I6rh4=(string #=zg4isb1se8HtAU1zSJ6yeWks=, string #=zYVfIQNFoCIQfeS__luv_ddM=)
	{
		try
		{
			#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zAjO7I84RW8RKI9PeCopgq9B$x73y = #=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zIXHGARF4HWoZ(#=zg4isb1se8HtAU1zSJ6yeWks=, null, null, null);
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			foreach (object obj in #=zAjO7I84RW8RKI9PeCopgq9B$x73y.#=zJgvbqC5Kxvxk().Headers.Keys)
			{
				string text = (string)obj;
				dictionary[text] = #=zAjO7I84RW8RKI9PeCopgq9B$x73y.#=zJgvbqC5Kxvxk().Headers[text];
			}
			string[] array = #=zYVfIQNFoCIQfeS__luv_ddM=.Split(new char[]
			{
				'\n',
				'\r'
			}, StringSplitOptions.RemoveEmptyEntries);
			string #=z60SXaZC6jCBJ = array[array.Length - 1];
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zOM_Iu4t4SVDEYd3_p$I6rh4=(dictionary, #=zAjO7I84RW8RKI9PeCopgq9B$x73y.#=ziywd55xwWd2r(), new Dictionary<string, object>(), #=z60SXaZC6jCBJ);
		}
		catch (Exception ex)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109239), new object[]
			{
				ex.Message
			});
			throw;
		}
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x00023A1C File Offset: 0x00021C1C
	public static #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno= #=z2OZmDzwOS07Bq_74qgfSMN_t88Xc(string #=z0HqaquI=)
	{
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno= result;
		try
		{
			string text = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0HqaquI=);
			if (string.IsNullOrWhiteSpace(text))
			{
				result = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno=)11;
			}
			else
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(text);
				Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109188));
				Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109174));
				result = #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zOM_Iu4t4SVDEYd3_p$I6rh4=(JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109153)), JSONManager.ExtractString(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109139), string.Empty), JSONManager.ExtractDictionary(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109153)), JSONManager.ExtractString(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109139), string.Empty));
			}
		}
		catch (Exception ex)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109239), new object[]
			{
				ex.Message
			});
			result = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno=)10;
		}
		return result;
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x00023AF8 File Offset: 0x00021CF8
	private static #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno= #=zOM_Iu4t4SVDEYd3_p$I6rh4=(Dictionary<string, object> #=zte439tgplves, string #=zWC15sHaiwX4N, Dictionary<string, object> #=zjmnto4yJ$c8u, string #=z60SXaZC6jCBJ)
	{
		string text = JSONManager.ExtractString((Dictionary<string, object>)JSONManager.DeserializeData(#=z60SXaZC6jCBJ), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057116), string.Empty);
		if (string.IsNullOrEmpty(text))
		{
			return (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno=)12;
		}
		CookieContainer cookieContainer = new CookieContainer();
		List<string> list = new List<string>
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052955),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109134),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108863),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108844),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108817),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108804),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108785),
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057770)
		};
		if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2g56AnsQz6F57FBqTANp4Hk= == null)
		{
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2g56AnsQz6F57FBqTANp4Hk= = new Dictionary<string, string>();
		}
		foreach (string text2 in #=zte439tgplves.Keys)
		{
			if (!list.Contains(text2.ToLower()))
			{
				if (text2.ToLower() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057770))
				{
					cookieContainer.SetCookies(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)), Convert.ToString(#=zte439tgplves[text2]).Replace(';', ','));
				}
				else
				{
					#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=z2g56AnsQz6F57FBqTANp4Hk=[text2] = Convert.ToString(#=zte439tgplves[text2]);
				}
			}
		}
		if (#=zjmnto4yJ$c8u.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108763)))
		{
			string[] array = Convert.ToString(#=zjmnto4yJ$c8u[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108763)]).Split(new char[]
			{
				'='
			});
			if (!string.IsNullOrEmpty(array[0]))
			{
				cookieContainer.Add(new Uri(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057923)), new Cookie(array[0], array[1]));
			}
		}
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(#=zWC15sHaiwX4N);
		string text3 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108744), string.Empty);
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zl$4PvuuQiEl = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zOdy_aU_tk1aY();
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno= result;
		if (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zG9tEURIPK2eP(#=zl$4PvuuQiEl, text3, text))
		{
			result = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno=)1;
		}
		else
		{
			#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zZCnf9GRArmR4(#=zl$4PvuuQiEl, text3, JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053898), string.Empty), text);
			result = (#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zW0V1F7UVwy7h6dCHICXJtno=)0;
		}
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zMFZYMZ0k526x = cookieContainer;
		return result;
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x00023D48 File Offset: 0x00021F48
	public static void #=zZCnf9GRArmR4(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zl$4PvuuQiEl5, string #=z7AcZdMA=, string #=zjMfTbhE=, string #=zX6LmW4I=)
	{
		List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==> list = new List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==>();
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zl$4PvuuQiEl5)
		{
			list.Add(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zh5Q$jgycqA15());
		}
		#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== = new #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==();
		#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=ze8TQhOAtefck(#=z7AcZdMA=);
		#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuKcwTqrq7yWC(#=zjMfTbhE=);
		#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=znJq9SDhBSPImQwwzNw==(true);
		list.Add(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==);
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=z0ZcCdTI=(list, false);
		#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zG9tEURIPK2eP(#=zl$4PvuuQiEl5, #=z7AcZdMA=, #=zX6LmW4I=);
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x00023DD8 File Offset: 0x00021FD8
	private static bool #=zG9tEURIPK2eP(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zl$4PvuuQiEl5, string #=zDu2ZTOnSae3g, string #=zX6LmW4I=)
	{
		bool result = false;
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zl$4PvuuQiEl5)
		{
			if (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=z9Yordw6ZFjQe() == #=zDu2ZTOnSae3g)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zZJbepNH_IDuQ(#=zX6LmW4I=);
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zsFXnaqjXugcU(#=zX6LmW4I=);
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108740), Array.Empty<object>());
				result = true;
				break;
			}
		}
		return result;
	}

	// Token: 0x04000166 RID: 358
	private static CookieContainer #=zMFZYMZ0k526x;

	// Token: 0x04000167 RID: 359
	private static Dictionary<string, string> #=z2g56AnsQz6F57FBqTANp4Hk=;

	// Token: 0x04000168 RID: 360
	private #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=;

	// Token: 0x04000169 RID: 361
	private ProxyInfo #=zsHG$Y6w=;

	// Token: 0x0400016A RID: 362
	private StringBuilder #=zyfyFTf4=;

	// Token: 0x0400016B RID: 363
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zo2RQp2yC5Y8V;

	// Token: 0x0400016C RID: 364
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zrQZFF9ZLZCqi;

	// Token: 0x0400016D RID: 365
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zQGaIow0kN$r$6A7CPw==;

	// Token: 0x0400016E RID: 366
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zPZuvSTeWXxFf9DC_cA==;

	// Token: 0x0400016F RID: 367
	private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=z0cuDVoxxW7KKHiS7Ow==;

	// Token: 0x04000170 RID: 368
	private bool #=zqWJEzYwJdOh3xlWBcA==;

	// Token: 0x04000171 RID: 369
	private static List<string> #=zD2giaLw=;

	// Token: 0x0200008F RID: 143
	public enum #=zW0V1F7UVwy7h6dCHICXJtno=
	{

	}

	// Token: 0x02000090 RID: 144
	private sealed class #=zh5VnWdQ=
	{
		// Token: 0x060003F9 RID: 1017 RVA: 0x00023E5C File Offset: 0x0002205C
		public #=zh5VnWdQ=(#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zrhvCoyA=, #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zvq0$kQI=, Exception #=z1148NY8=)
		{
			this.#=z6WYOZiA=(#=zrhvCoyA=);
			this.#=zUrXgCLGy$Fwy(#=zvq0$kQI=);
			this.#=zP5bTygE=(#=z1148NY8=);
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00023E7C File Offset: 0x0002207C
		public #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zZ_Vdevw=()
		{
			return this.#=zUyPZJFpCvLRcMQPxzQ==;
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00023E84 File Offset: 0x00022084
		public void #=z6WYOZiA=(#=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=z$Ib9gYQ=)
		{
			this.#=zUyPZJFpCvLRcMQPxzQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00023E90 File Offset: 0x00022090
		public #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zCh2q0p3jzp4u()
		{
			return this.#=zmnZeX6AYiR3afRD1Zw==;
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00023E98 File Offset: 0x00022098
		public void #=zUrXgCLGy$Fwy(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=z$Ib9gYQ=)
		{
			this.#=zmnZeX6AYiR3afRD1Zw== = #=z$Ib9gYQ=;
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00023EA4 File Offset: 0x000220A4
		public Exception #=z1_c0G5o=()
		{
			return this.#=z9a_7GWSY637vdCkwzQ==;
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x00023EAC File Offset: 0x000220AC
		public void #=zP5bTygE=(Exception #=z$Ib9gYQ=)
		{
			this.#=z9a_7GWSY637vdCkwzQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x04000173 RID: 371
		private #=z7aDrcR7bMfqAl_8nw5LwkpeEgbDX8GDAj0RJ2p4=.#=zvC26_B0= #=zUyPZJFpCvLRcMQPxzQ==;

		// Token: 0x04000174 RID: 372
		private #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zmnZeX6AYiR3afRD1Zw==;

		// Token: 0x04000175 RID: 373
		private Exception #=z9a_7GWSY637vdCkwzQ==;
	}

	// Token: 0x02000091 RID: 145
	private enum #=zvC26_B0=
	{

	}
}
