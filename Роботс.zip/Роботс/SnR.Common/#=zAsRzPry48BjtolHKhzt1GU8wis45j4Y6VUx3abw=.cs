﻿using System;
using Skink.SnR.Common.Units;

// Token: 0x020000BD RID: 189
internal interface #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= : #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=
{
	// Token: 0x060004FF RID: 1279
	bool #=zQLl7KKs=(UnitSquad #=zCtbXRq2SiURL);

	// Token: 0x06000500 RID: 1280
	bool #=zQLl7KKs=(UnitType #=zvRLj9WQ=);
}
