﻿using System;
using System.Net;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Tasks;

// Token: 0x02000085 RID: 133
internal sealed class #=z6ozZM$fwsEVn6xrBXDtluE0maUyDMS9naA==
{
	// Token: 0x060003AB RID: 939 RVA: 0x000201AC File Offset: 0x0001E3AC
	public static void #=z1GX$uzE=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=z23sS9NhIcGaTj3irAlB1lVH1yUQC #=zHhz$VxIrfU57)
	{
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zG2wnL_q7IxpD, #=z8StzeqE=, null, null);
		#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==;
		try
		{
			#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw== = #=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=.#=zYzfPccI=(#=zHhz$VxIrfU57, #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==);
			#=z0e_4WrkEEJPo988hDdHqxv4HrSMubxMFHw==.#=zKNSug6s=(#=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==, #=zG2wnL_q7IxpD, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==);
			#=z8StzeqE=.#=zsyjyZeg=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==);
			foreach (Task task in #=zHhz$VxIrfU57)
			{
				if (task.#=zRHQWIGrpniarcc1a6A==() != null)
				{
					task.#=zRHQWIGrpniarcc1a6A==().#=zM4ts4Mc=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==);
				}
			}
		}
		finally
		{
			((IDisposable)#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==).Dispose();
		}
		foreach (#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=zvGsrUNadhGP in #=zyVB4NB_Tbn2hBQdpseFYkwPvZ2t4$bYwzw==)
		{
			if (GameApplicationData.#=zv3f1uqjnJC$0())
			{
				break;
			}
			if (#=zG2wnL_q7IxpD.#=z9TrQaE7EBV1U().State != ProxyStates.Ok)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942028), Array.Empty<object>());
				break;
			}
			#=z6ozZM$fwsEVn6xrBXDtluE0maUyDMS9naA==.#=zryTcrns=(#=zG2wnL_q7IxpD, #=zvGsrUNadhGP, false);
			if (#=z8StzeqE=.#=z87XIzK7RTgT1() == null)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941683), Array.Empty<object>());
				break;
			}
		}
	}

	// Token: 0x060003AC RID: 940 RVA: 0x000202D8 File Offset: 0x0001E4D8
	private static void #=zryTcrns=(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=zvGsrUNadhGP8, bool #=zOHpNIo3l68usnRl2IA==)
	{
		Task task = #=zvGsrUNadhGP8.#=zW3vCypudd9EC();
		if (task.State == TaskStates.Cancelled)
		{
			return;
		}
		#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = #=zG2wnL_q7IxpD.#=zQ4wZnctPyyRO();
		if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zFaAgw7POs43y(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, task.Type))
		{
			task.ExecutionTime += TimeSpan.FromHours(1.0);
			task.State = TaskStates.Pending;
			return;
		}
		#=zDSiRXECNe4Awos25aECUKlmR8FRd #=zDSiRXECNe4Awos25aECUKlmR8FRd;
		bool flag = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zxoq6CXk=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, task, out #=zDSiRXECNe4Awos25aECUKlmR8FRd);
		if (#=zDSiRXECNe4Awos25aECUKlmR8FRd != null)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zTNSS3ihKtVfU(), #=zDSiRXECNe4Awos25aECUKlmR8FRd.#=zVIqstfu8tTbu());
		}
		if (!flag)
		{
			if (#=zDSiRXECNe4Awos25aECUKlmR8FRd == null)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941614), Array.Empty<object>());
			}
			task.State = TaskStates.Cancelled;
			return;
		}
		if (task.ExpireTime > DateTime.MinValue && DateTime.Now > task.ExpireTime)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941571), new object[]
			{
				task.Type,
				task.Details
			});
			task.State = TaskStates.Missed;
			return;
		}
		if (task.#=zRHQWIGrpniarcc1a6A==() != null && task.#=zRHQWIGrpniarcc1a6A==().#=zHp_H9kjso26frPfu2USZhi4=())
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941794), new object[]
			{
				task.Type,
				task.Details
			});
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, task.ToString(), Array.Empty<object>());
			task.State = TaskStates.Complete;
			return;
		}
		if (DateTime.Now > task.TimeOutTime)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941744), new object[]
			{
				task.Type,
				task.Details
			});
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, task.ToString(), Array.Empty<object>());
			task.State = TaskStates.Missed;
			return;
		}
		if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=ziYbj9IsgzGRe7374EQ==() > DateTime.Now)
		{
			return;
		}
		bool flag2 = false;
		try
		{
			task.State = TaskStates.Running;
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941702), new object[]
			{
				task.Type
			});
			if (task.Source == TaskSources.Manual || task.Source == TaskSources.ManualNotSavable)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zLyaSD5E=(#=zG2wnL_q7IxpD, task.ToString(), Array.Empty<object>());
			}
			#=zvGsrUNadhGP8.#=zryTcrns=();
			flag2 = true;
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)4)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=z_CMx39SmGb4B(false);
			}
			else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)2)
			{
				if (!#=zOHpNIo3l68usnRl2IA== && !#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zQ$VqUtt$6rBX())
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.Message, Array.Empty<object>());
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsInstantBackgroundOff)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941413), Array.Empty<object>());
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = false;
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zgi8txbeKnNhG(null);
					}
					else if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsAutoBackgroundOff && DateTime.Now - #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zueZ$FCyRT_UZyAN7rg==() < TimeSpan.FromMinutes(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().AutoBackgroundOffMinutes))
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941348), Array.Empty<object>());
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = false;
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zgi8txbeKnNhG(null);
					}
					if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground || task.Severity == TaskSeverities.Urgent)
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zgi8txbeKnNhG(null);
						#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU= = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zG2wnL_q7IxpD, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, null, null);
						#=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw== #=zvGsrUNadhGP9 = #=zfskSWIgoJ$Rg4IxUi0vWwl8h7Zr76vUIOExxP7Q=.#=zGr5DE2c=(task, #=zG2wnL_q7IxpD, #=zuJjQ1XU=);
						#=z6ozZM$fwsEVn6xrBXDtluE0maUyDMS9naA==.#=zryTcrns=(#=zG2wnL_q7IxpD, #=zvGsrUNadhGP9, true);
					}
				}
				else
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
				}
			}
			else if ((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)7 || #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)6) && #=zG2wnL_q7IxpD.#=z9TrQaE7EBV1U().Type != ProxyTypes.NoProxy)
			{
				task.State = TaskStates.Rescheduled;
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941522), new object[]
				{
					task.Type,
					task.Details
				});
			}
			else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)12)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908937005), new object[]
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=ziYbj9IsgzGRe7374EQ==()
				});
			}
			else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)10)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsRunBackground = false;
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
			}
			else if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() != (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)3 && #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() != (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)8)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K);
			}
		}
		catch (WebException #=zN_s5Z5A=)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			if (task.RetriesCount > 0)
			{
				task.State = TaskStates.Rescheduled;
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941522), new object[]
				{
					task.Type,
					task.Details
				});
				Task task2 = task;
				int retriesCount = task2.RetriesCount;
				task2.RetriesCount = retriesCount - 1;
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zN_s5Z5A=2);
		}
		finally
		{
			if (!flag2 && (task.Options & TaskOptions.MustComplete) == TaskOptions.MustComplete)
			{
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941493), Array.Empty<object>());
				task.ExecutionTime = DateTime.Now + TimeSpan.FromMinutes(15.0);
				task.State = TaskStates.Rescheduled;
			}
			if (task.State == TaskStates.Rescheduled)
			{
				task.State = TaskStates.Pending;
			}
			else
			{
				if (task.State != TaskStates.Cancelled && task.State != TaskStates.Missed)
				{
					task.State = TaskStates.Complete;
				}
				if (task.RepeatDelayMax != TimeSpan.Zero && task.State != TaskStates.Cancelled)
				{
					TimeSpan timeSpan = task.RepeatDelay();
					if (timeSpan.TotalMinutes < 30.0 && (task.Source == TaskSources.Manual || task.Source == TaskSources.ManualNotSavable) && task.Type == TaskTypes.SendUnit && !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==))
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943220), Array.Empty<object>());
						timeSpan = TimeSpan.FromMinutes(30.0);
						task.RepeatDelayMin = timeSpan;
						if (task.RepeatDelayMax < task.RepeatDelayMin)
						{
							task.RepeatDelayMax = task.RepeatDelayMin;
						}
					}
					if (task.NextExecutionTime != DateTime.MinValue)
					{
						task.ExecutionTime = task.NextExecutionTime;
						task.NextExecutionTime = DateTime.MinValue;
					}
					else if (task.IsRepeatFromExecutionTime)
					{
						task.ExecutionTime = DateTime.Now + timeSpan;
					}
					else
					{
						task.ExecutionTime += timeSpan;
						if (task.ExecutionTime + timeSpan < DateTime.Now)
						{
							task.ExecutionTime = DateTime.Now;
						}
					}
					bool flag3 = false;
					if (task.ExecutionTime >= task.ExpireTime)
					{
						flag3 = true;
					}
					if (task.ExpireIterations > 0)
					{
						if (task.ExpireIterations > 1)
						{
							task.ExpireIterations--;
						}
						else
						{
							flag3 = true;
						}
					}
					if (!flag3)
					{
						task.State = TaskStates.Pending;
					}
				}
			}
		}
	}
}
