﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000076 RID: 118
internal sealed class #=z5sYY1ZL9rZwR6wKtZfp7H8$5YZfM : #=zIysmcffbrCbtDK6qpNil6NA=
{
	// Token: 0x0600035E RID: 862 RVA: 0x0001EFBC File Offset: 0x0001D1BC
	internal #=z5sYY1ZL9rZwR6wKtZfp7H8$5YZfM(Record #=zihyUFzs=) : base(Type.TOPMARGIN, #=zihyUFzs=)
	{
	}
}
