﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

// Token: 0x02000227 RID: 551
internal sealed partial class #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA= : Form
{
	// Token: 0x060010DF RID: 4319 RVA: 0x00081A80 File Offset: 0x0007FC80
	internal #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zvGoq6ic3HMCR, bool #=z3pxpP6rtXDpDm4Mp_iAQ$DI=)
	{
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=z8StzeqE= = #=zvGoq6ic3HMCR;
		this.#=zORYZMJ3RxkI_ = new #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q=(this.#=z8StzeqE=, #=z3pxpP6rtXDpDm4Mp_iAQ$DI=);
		this.#=zgpzgXirqPT5_();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
		new Thread(new ParameterizedThreadStart(#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zW2J$QHs=)).Start(this.#=zORYZMJ3RxkI_);
		this.#=zkl4nXp1pqgdr.Enabled = true;
	}

	// Token: 0x060010E0 RID: 4320 RVA: 0x00081AE8 File Offset: 0x0007FCE8
	private void #=z4guiCTpG$48S9DfSJQ==(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zkl4nXp1pqgdr.Enabled)
		{
			return;
		}
		this.#=zORYZMJ3RxkI_.#=z0Y7dLtOFqBP$(#=z4Q$h3mE=.RowIndex);
		this.#=z0z0q_8QIqTngmIwy$A==.Visible = false;
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104403), Array.Empty<object>()).ToString();
		new Thread(new ParameterizedThreadStart(#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zPh_IX4lm4F7v7FVs6GhOD$U=)).Start(this.#=zORYZMJ3RxkI_);
		this.#=zkl4nXp1pqgdr.Enabled = true;
	}

	// Token: 0x060010E1 RID: 4321 RVA: 0x00081B6C File Offset: 0x0007FD6C
	private void #=ztFBz6I4FhK1V(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (!this.#=zz3ywcefYEZcr.Visible)
			{
				if (this.#=zORYZMJ3RxkI_.#=ziasHiGlKUcpU())
				{
					this.#=zz3ywcefYEZcr.Rows.Clear();
					for (int i = 0; i < this.#=zORYZMJ3RxkI_.Count; i++)
					{
						#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== = this.#=zORYZMJ3RxkI_[i].#=zqjHOR9Q=();
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = this.#=zORYZMJ3RxkI_[i].#=zz06aak3g76OOx7_cRg==();
						this.#=zz3ywcefYEZcr.Rows.Add(new object[]
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zkfqcY3I=(),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zfTB62qendhk_VEy8rw==(),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zY0soxphmGIACbOHy6A==(),
							this.#=zOnM0lrc=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zj661vGqZTMsoJ4JrPg==(),
							#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=ziOXVgvjvFhzEtBZSB7CJqUA=().Length,
							#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zPHMvvJ8=().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104390))
						});
					}
					this.#=zz3ywcefYEZcr.Visible = true;
					this.#=zkl4nXp1pqgdr.Enabled = false;
				}
				else
				{
					this.#=zW1BEqcz$2PAmR5eQcA==.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104628), new object[]
					{
						this.#=zORYZMJ3RxkI_.#=zAATL_ycNz7if(),
						this.#=zORYZMJ3RxkI_.#=zxKFP$AJR4sh4()
					}).ToString();
				}
			}
			else if (this.#=zORYZMJ3RxkI_.#=za07dXEFI27g_IXqQQay9StjwAv9d())
			{
				this.#=z0z0q_8QIqTngmIwy$A==.Rows.Clear();
				for (int j = 0; j < this.#=zORYZMJ3RxkI_.#=zfA6C0jYwhi0tXFeEPaBsGiU=().Count; j++)
				{
					#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2 = this.#=zORYZMJ3RxkI_.#=zfA6C0jYwhi0tXFeEPaBsGiU=()[j];
					if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2 != null)
					{
						this.#=z0z0q_8QIqTngmIwy$A==.Rows.Add(new object[]
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zkfqcY3I=(),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zfTB62qendhk_VEy8rw==(),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zY0soxphmGIACbOHy6A==(),
							this.#=zOnM0lrc=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2),
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==2.#=zj661vGqZTMsoJ4JrPg==()
						});
					}
					else
					{
						this.#=z0z0q_8QIqTngmIwy$A==.Rows.Add();
					}
				}
				this.#=z0z0q_8QIqTngmIwy$A==.Visible = true;
				this.#=zkl4nXp1pqgdr.Enabled = false;
			}
			else
			{
				this.#=zR30yrxzzFe$VXgFZr2axxlE=.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104591), new object[]
				{
					this.#=zORYZMJ3RxkI_.#=zAATL_ycNz7if(),
					this.#=zORYZMJ3RxkI_.#=zxKFP$AJR4sh4()
				}).ToString();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zkl4nXp1pqgdr.Enabled = false;
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
			this.#=zR30yrxzzFe$VXgFZr2axxlE=.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104554), new object[]
			{
				#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
			}).ToString();
		}
	}

	// Token: 0x060010E2 RID: 4322 RVA: 0x00081E68 File Offset: 0x00080068
	private int #=zOnM0lrc=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z$YoE6dyQ_NWs)
	{
		return (int)Math.Round(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOnM0lrc=((double)this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), (double)this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==(), (double)#=z$YoE6dyQ_NWs.#=zfTB62qendhk_VEy8rw==(), (double)#=z$YoE6dyQ_NWs.#=zY0soxphmGIACbOHy6A==()));
	}

	// Token: 0x060010E4 RID: 4324 RVA: 0x00081EC8 File Offset: 0x000800C8
	private void #=zgpzgXirqPT5_()
	{
		this.#=zRWEHIqY= = new Container();
		DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
		DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
		this.#=z8bcpLWm$DpFw = new SplitContainer();
		this.#=zz3ywcefYEZcr = new DataGridView();
		this.#=zW1BEqcz$2PAmR5eQcA== = new Label();
		this.#=z0z0q_8QIqTngmIwy$A== = new DataGridView();
		this.#=zR30yrxzzFe$VXgFZr2axxlE= = new Label();
		this.#=zkl4nXp1pqgdr = new Timer(this.#=zRWEHIqY=);
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=zHHHTe_ojyY1E = new DataGridViewTextBoxColumn();
		this.#=zScb_GzPNvLku = new DataGridViewTextBoxColumn();
		this.#=zKnM7jrJgoIET = new DataGridViewTextBoxColumn();
		this.#=zH2VcRoOnUhbiDfZNqw== = new DataGridViewTextBoxColumn();
		this.#=zY9tTwiBSkdzD = new DataGridViewTextBoxColumn();
		this.#=zuruUKK0= = new DataGridViewTextBoxColumn();
		this.#=zwupEbQpE4YCr = new DataGridViewTextBoxColumn();
		this.#=zl6Ksc_m64s3ySfCLkQ== = new DataGridViewTextBoxColumn();
		this.#=zJUJaO$nrOrOYSIG8JA== = new DataGridViewTextBoxColumn();
		this.#=z58jXl7HczXKQ = new DataGridViewTextBoxColumn();
		this.#=zqhlFJ2OUEHPhlYR1DQ== = new DataGridViewTextBoxColumn();
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).BeginInit();
		this.#=z8bcpLWm$DpFw.Panel1.SuspendLayout();
		this.#=z8bcpLWm$DpFw.Panel2.SuspendLayout();
		this.#=z8bcpLWm$DpFw.SuspendLayout();
		((ISupportInitialize)this.#=zz3ywcefYEZcr).BeginInit();
		((ISupportInitialize)this.#=z0z0q_8QIqTngmIwy$A==).BeginInit();
		base.SuspendLayout();
		this.#=z8bcpLWm$DpFw.Dock = DockStyle.Fill;
		this.#=z8bcpLWm$DpFw.Location = new Point(0, 0);
		this.#=z8bcpLWm$DpFw.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114121);
		this.#=z8bcpLWm$DpFw.Panel1.Controls.Add(this.#=zz3ywcefYEZcr);
		this.#=z8bcpLWm$DpFw.Panel1.Controls.Add(this.#=zW1BEqcz$2PAmR5eQcA==);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=z0z0q_8QIqTngmIwy$A==);
		this.#=z8bcpLWm$DpFw.Panel2.Controls.Add(this.#=zR30yrxzzFe$VXgFZr2axxlE=);
		this.#=z8bcpLWm$DpFw.Size = new Size(1146, 484);
		this.#=z8bcpLWm$DpFw.SplitterDistance = 648;
		this.#=z8bcpLWm$DpFw.TabIndex = 0;
		this.#=zz3ywcefYEZcr.AllowUserToAddRows = false;
		this.#=zz3ywcefYEZcr.AllowUserToDeleteRows = false;
		dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle.BackColor = SystemColors.Control;
		dataGridViewCellStyle.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle.ForeColor = SystemColors.WindowText;
		dataGridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
		this.#=zz3ywcefYEZcr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
		this.#=zz3ywcefYEZcr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zz3ywcefYEZcr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zO0jJkos=,
			this.#=zHHHTe_ojyY1E,
			this.#=zScb_GzPNvLku,
			this.#=zKnM7jrJgoIET,
			this.#=zH2VcRoOnUhbiDfZNqw==,
			this.#=zY9tTwiBSkdzD,
			this.#=zuruUKK0=
		});
		dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle2.BackColor = SystemColors.Window;
		dataGridViewCellStyle2.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
		dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
		this.#=zz3ywcefYEZcr.DefaultCellStyle = dataGridViewCellStyle2;
		this.#=zz3ywcefYEZcr.Dock = DockStyle.Fill;
		this.#=zz3ywcefYEZcr.Location = new Point(0, 0);
		this.#=zz3ywcefYEZcr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104521);
		this.#=zz3ywcefYEZcr.ReadOnly = true;
		dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle3.BackColor = SystemColors.Control;
		dataGridViewCellStyle3.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
		dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
		this.#=zz3ywcefYEZcr.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
		this.#=zz3ywcefYEZcr.Size = new Size(648, 484);
		this.#=zz3ywcefYEZcr.TabIndex = 1;
		this.#=zz3ywcefYEZcr.Visible = false;
		this.#=zz3ywcefYEZcr.CellContentClick += this.#=z4guiCTpG$48S9DfSJQ==;
		this.#=zW1BEqcz$2PAmR5eQcA==.AutoSize = true;
		this.#=zW1BEqcz$2PAmR5eQcA==.Location = new Point(26, 27);
		this.#=zW1BEqcz$2PAmR5eQcA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104255);
		this.#=zW1BEqcz$2PAmR5eQcA==.Size = new Size(163, 13);
		this.#=zW1BEqcz$2PAmR5eQcA==.TabIndex = 0;
		this.#=zW1BEqcz$2PAmR5eQcA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104228);
		this.#=z0z0q_8QIqTngmIwy$A==.AllowUserToAddRows = false;
		this.#=z0z0q_8QIqTngmIwy$A==.AllowUserToDeleteRows = false;
		dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle4.BackColor = SystemColors.Control;
		dataGridViewCellStyle4.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
		dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
		this.#=z0z0q_8QIqTngmIwy$A==.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
		this.#=z0z0q_8QIqTngmIwy$A==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z0z0q_8QIqTngmIwy$A==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zwupEbQpE4YCr,
			this.#=zl6Ksc_m64s3ySfCLkQ==,
			this.#=zJUJaO$nrOrOYSIG8JA==,
			this.#=z58jXl7HczXKQ,
			this.#=zqhlFJ2OUEHPhlYR1DQ==
		});
		dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle5.BackColor = SystemColors.Window;
		dataGridViewCellStyle5.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
		dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
		this.#=z0z0q_8QIqTngmIwy$A==.DefaultCellStyle = dataGridViewCellStyle5;
		this.#=z0z0q_8QIqTngmIwy$A==.Dock = DockStyle.Fill;
		this.#=z0z0q_8QIqTngmIwy$A==.Location = new Point(0, 0);
		this.#=z0z0q_8QIqTngmIwy$A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104178);
		this.#=z0z0q_8QIqTngmIwy$A==.ReadOnly = true;
		dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
		dataGridViewCellStyle6.BackColor = SystemColors.Control;
		dataGridViewCellStyle6.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 177);
		dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
		dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
		dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
		dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
		this.#=z0z0q_8QIqTngmIwy$A==.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
		this.#=z0z0q_8QIqTngmIwy$A==.Size = new Size(494, 484);
		this.#=z0z0q_8QIqTngmIwy$A==.TabIndex = 1;
		this.#=z0z0q_8QIqTngmIwy$A==.Visible = false;
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.AutoSize = true;
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.Location = new Point(28, 27);
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104166);
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.Size = new Size(16, 13);
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.TabIndex = 0;
		this.#=zR30yrxzzFe$VXgFZr2axxlE=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114954);
		this.#=zkl4nXp1pqgdr.Interval = 500;
		this.#=zkl4nXp1pqgdr.Tick += this.#=ztFBz6I4FhK1V;
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104130);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.ReadOnly = true;
		this.#=zO0jJkos=.Width = 200;
		this.#=zHHHTe_ojyY1E.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104363);
		this.#=zHHHTe_ojyY1E.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104353);
		this.#=zHHHTe_ojyY1E.ReadOnly = true;
		this.#=zHHHTe_ojyY1E.Width = 40;
		this.#=zScb_GzPNvLku.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104340);
		this.#=zScb_GzPNvLku.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104322);
		this.#=zScb_GzPNvLku.ReadOnly = true;
		this.#=zScb_GzPNvLku.Width = 40;
		this.#=zKnM7jrJgoIET.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104305);
		this.#=zKnM7jrJgoIET.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104291);
		this.#=zKnM7jrJgoIET.ReadOnly = true;
		this.#=zKnM7jrJgoIET.Width = 50;
		this.#=zH2VcRoOnUhbiDfZNqw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zH2VcRoOnUhbiDfZNqw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104262);
		this.#=zH2VcRoOnUhbiDfZNqw==.ReadOnly = true;
		this.#=zY9tTwiBSkdzD.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106027);
		this.#=zY9tTwiBSkdzD.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106012);
		this.#=zY9tTwiBSkdzD.ReadOnly = true;
		this.#=zY9tTwiBSkdzD.Width = 80;
		this.#=zuruUKK0=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105987);
		this.#=zuruUKK0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105971);
		this.#=zuruUKK0=.ReadOnly = true;
		this.#=zuruUKK0=.Width = 70;
		this.#=zwupEbQpE4YCr.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105952);
		this.#=zwupEbQpE4YCr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105929);
		this.#=zwupEbQpE4YCr.ReadOnly = true;
		this.#=zwupEbQpE4YCr.Width = 200;
		this.#=zl6Ksc_m64s3ySfCLkQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104363);
		this.#=zl6Ksc_m64s3ySfCLkQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106173);
		this.#=zl6Ksc_m64s3ySfCLkQ==.ReadOnly = true;
		this.#=zl6Ksc_m64s3ySfCLkQ==.Width = 40;
		this.#=zJUJaO$nrOrOYSIG8JA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104340);
		this.#=zJUJaO$nrOrOYSIG8JA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106151);
		this.#=zJUJaO$nrOrOYSIG8JA==.ReadOnly = true;
		this.#=zJUJaO$nrOrOYSIG8JA==.Width = 40;
		this.#=z58jXl7HczXKQ.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104305);
		this.#=z58jXl7HczXKQ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106121);
		this.#=z58jXl7HczXKQ.ReadOnly = true;
		this.#=z58jXl7HczXKQ.Width = 50;
		this.#=zqhlFJ2OUEHPhlYR1DQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=zqhlFJ2OUEHPhlYR1DQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106109);
		this.#=zqhlFJ2OUEHPhlYR1DQ==.ReadOnly = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(1146, 484);
		base.Controls.Add(this.#=z8bcpLWm$DpFw);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106085);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106085);
		this.#=z8bcpLWm$DpFw.Panel1.ResumeLayout(false);
		this.#=z8bcpLWm$DpFw.Panel1.PerformLayout();
		this.#=z8bcpLWm$DpFw.Panel2.ResumeLayout(false);
		this.#=z8bcpLWm$DpFw.Panel2.PerformLayout();
		((ISupportInitialize)this.#=z8bcpLWm$DpFw).EndInit();
		this.#=z8bcpLWm$DpFw.ResumeLayout(false);
		((ISupportInitialize)this.#=zz3ywcefYEZcr).EndInit();
		((ISupportInitialize)this.#=z0z0q_8QIqTngmIwy$A==).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x04000917 RID: 2327
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000918 RID: 2328
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000919 RID: 2329
	private #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q= #=zORYZMJ3RxkI_;

	// Token: 0x0400091B RID: 2331
	private SplitContainer #=z8bcpLWm$DpFw;

	// Token: 0x0400091C RID: 2332
	private Label #=zW1BEqcz$2PAmR5eQcA==;

	// Token: 0x0400091D RID: 2333
	private Label #=zR30yrxzzFe$VXgFZr2axxlE=;

	// Token: 0x0400091E RID: 2334
	private DataGridView #=zz3ywcefYEZcr;

	// Token: 0x0400091F RID: 2335
	private DataGridView #=z0z0q_8QIqTngmIwy$A==;

	// Token: 0x04000920 RID: 2336
	private Timer #=zkl4nXp1pqgdr;

	// Token: 0x04000921 RID: 2337
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x04000922 RID: 2338
	private DataGridViewTextBoxColumn #=zHHHTe_ojyY1E;

	// Token: 0x04000923 RID: 2339
	private DataGridViewTextBoxColumn #=zScb_GzPNvLku;

	// Token: 0x04000924 RID: 2340
	private DataGridViewTextBoxColumn #=zKnM7jrJgoIET;

	// Token: 0x04000925 RID: 2341
	private DataGridViewTextBoxColumn #=zH2VcRoOnUhbiDfZNqw==;

	// Token: 0x04000926 RID: 2342
	private DataGridViewTextBoxColumn #=zY9tTwiBSkdzD;

	// Token: 0x04000927 RID: 2343
	private DataGridViewTextBoxColumn #=zuruUKK0=;

	// Token: 0x04000928 RID: 2344
	private DataGridViewTextBoxColumn #=zwupEbQpE4YCr;

	// Token: 0x04000929 RID: 2345
	private DataGridViewTextBoxColumn #=zl6Ksc_m64s3ySfCLkQ==;

	// Token: 0x0400092A RID: 2346
	private DataGridViewTextBoxColumn #=zJUJaO$nrOrOYSIG8JA==;

	// Token: 0x0400092B RID: 2347
	private DataGridViewTextBoxColumn #=z58jXl7HczXKQ;

	// Token: 0x0400092C RID: 2348
	private DataGridViewTextBoxColumn #=zqhlFJ2OUEHPhlYR1DQ==;

	// Token: 0x02000228 RID: 552
	internal sealed class #=zSHtW6TQZwDI3FfF3XnOKUOI=
	{
		// Token: 0x060010E6 RID: 4326 RVA: 0x00082A40 File Offset: 0x00080C40
		public #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zqjHOR9Q=()
		{
			return this.#=zMOn$W0DW3iFpiytW9w==;
		}

		// Token: 0x060010E7 RID: 4327 RVA: 0x00082A48 File Offset: 0x00080C48
		public void #=zeAChU_4=(#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=z$Ib9gYQ=)
		{
			this.#=zMOn$W0DW3iFpiytW9w== = #=z$Ib9gYQ=;
		}

		// Token: 0x060010E8 RID: 4328 RVA: 0x00082A54 File Offset: 0x00080C54
		public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zz06aak3g76OOx7_cRg==()
		{
			return this.#=zl_wZogMEnr6nFeW4$aqD21T0m8n8;
		}

		// Token: 0x060010E9 RID: 4329 RVA: 0x00082A5C File Offset: 0x00080C5C
		public void #=zejuXi_yDZSHsXjtZAg==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z$Ib9gYQ=)
		{
			this.#=zl_wZogMEnr6nFeW4$aqD21T0m8n8 = #=z$Ib9gYQ=;
		}

		// Token: 0x0400092D RID: 2349
		private #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zMOn$W0DW3iFpiytW9w==;

		// Token: 0x0400092E RID: 2350
		private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zl_wZogMEnr6nFeW4$aqD21T0m8n8;
	}

	// Token: 0x02000229 RID: 553
	internal sealed class #=zzrTIZk5avZsKZ_$408IvV2Q= : List<#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zSHtW6TQZwDI3FfF3XnOKUOI=>
	{
		// Token: 0x060010EA RID: 4330 RVA: 0x00082A68 File Offset: 0x00080C68
		public #=zzrTIZk5avZsKZ_$408IvV2Q=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zvGoq6ic3HMCR, bool #=z3pxpP6rtXDpDm4Mp_iAQ$DI=)
		{
			this.#=z8w$9U75qCzHc(false);
			this.#=z8StzeqE= = #=zvGoq6ic3HMCR;
			this.#=zDSOp4LdHDTK7W9Cid3zPycAwJEBD = #=z3pxpP6rtXDpDm4Mp_iAQ$DI=;
			this.#=z0Y7dLtOFqBP$(-1);
			this.#=zJRZnT8$NGTap6BbH9wGoPGg=(new List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==>());
			this.#=zShlEjy3SNmZE2bOFy0fqKgIUdDqq(false);
			this.#=zJwfg43Iwxy4N(0);
			this.#=zNFLgHrjVit1$(0);
		}

		// Token: 0x060010EB RID: 4331 RVA: 0x00082AB8 File Offset: 0x00080CB8
		public bool #=ziasHiGlKUcpU()
		{
			return this.#=zDqBE41LMvqKVk44N1A==;
		}

		// Token: 0x060010EC RID: 4332 RVA: 0x00082AC0 File Offset: 0x00080CC0
		public void #=z8w$9U75qCzHc(bool #=z$Ib9gYQ=)
		{
			this.#=zDqBE41LMvqKVk44N1A== = #=z$Ib9gYQ=;
		}

		// Token: 0x060010ED RID: 4333 RVA: 0x00082ACC File Offset: 0x00080CCC
		public int #=z4_PYUsMrrDxD()
		{
			return this.#=zEz6xOldWrBJAWJFr1PAIjR8=;
		}

		// Token: 0x060010EE RID: 4334 RVA: 0x00082AD4 File Offset: 0x00080CD4
		public void #=z0Y7dLtOFqBP$(int #=z$Ib9gYQ=)
		{
			this.#=zEz6xOldWrBJAWJFr1PAIjR8= = #=z$Ib9gYQ=;
		}

		// Token: 0x060010EF RID: 4335 RVA: 0x00082AE0 File Offset: 0x00080CE0
		public List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=zfA6C0jYwhi0tXFeEPaBsGiU=()
		{
			return this.#=zadzHe9XP13R_oBw2fa8U7B0JPP0v9gFTeA==;
		}

		// Token: 0x060010F0 RID: 4336 RVA: 0x00082AE8 File Offset: 0x00080CE8
		public void #=zJRZnT8$NGTap6BbH9wGoPGg=(List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=z$Ib9gYQ=)
		{
			this.#=zadzHe9XP13R_oBw2fa8U7B0JPP0v9gFTeA== = #=z$Ib9gYQ=;
		}

		// Token: 0x060010F1 RID: 4337 RVA: 0x00082AF4 File Offset: 0x00080CF4
		public bool #=za07dXEFI27g_IXqQQay9StjwAv9d()
		{
			return this.#=zVXOvVExtJjVg6Tqs3$T_h8P7RCqxuuAtUw==;
		}

		// Token: 0x060010F2 RID: 4338 RVA: 0x00082AFC File Offset: 0x00080CFC
		public void #=zShlEjy3SNmZE2bOFy0fqKgIUdDqq(bool #=z$Ib9gYQ=)
		{
			this.#=zVXOvVExtJjVg6Tqs3$T_h8P7RCqxuuAtUw== = #=z$Ib9gYQ=;
		}

		// Token: 0x060010F3 RID: 4339 RVA: 0x00082B08 File Offset: 0x00080D08
		public int #=zAATL_ycNz7if()
		{
			return this.#=z5IwHc0VPfAuZ_z9R40aKsVc=;
		}

		// Token: 0x060010F4 RID: 4340 RVA: 0x00082B10 File Offset: 0x00080D10
		public void #=zJwfg43Iwxy4N(int #=z$Ib9gYQ=)
		{
			this.#=z5IwHc0VPfAuZ_z9R40aKsVc= = #=z$Ib9gYQ=;
		}

		// Token: 0x060010F5 RID: 4341 RVA: 0x00082B1C File Offset: 0x00080D1C
		public int #=zxKFP$AJR4sh4()
		{
			return this.#=zLNFJ5mIaX$b0GfpBzjNtsXo=;
		}

		// Token: 0x060010F6 RID: 4342 RVA: 0x00082B24 File Offset: 0x00080D24
		public void #=zNFLgHrjVit1$(int #=z$Ib9gYQ=)
		{
			this.#=zLNFJ5mIaX$b0GfpBzjNtsXo= = #=z$Ib9gYQ=;
		}

		// Token: 0x060010F7 RID: 4343 RVA: 0x00082B30 File Offset: 0x00080D30
		public static void #=zW2J$QHs=(object #=zcyRsraWouSUf)
		{
			#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q= #=zzrTIZk5avZsKZ_$408IvV2Q= = null;
			try
			{
				#=zzrTIZk5avZsKZ_$408IvV2Q= = (#=zcyRsraWouSUf as #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q=);
				if (#=zzrTIZk5avZsKZ_$408IvV2Q= != null && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=))
				{
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8w$9U75qCzHc(false);
					#=zzrTIZk5avZsKZ_$408IvV2Q=.Clear();
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zJwfg43Iwxy4N(0);
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zNFLgHrjVit1$(1);
					#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=);
					object[] array = #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z_WwoAi$Ptgio();
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zNFLgHrjVit1$(array.Length);
					List<int> list = new List<int>();
					for (int i = 0; i < array.Length; i++)
					{
						#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== = #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zi1hFJwI=(array[i] as Dictionary<string, object>);
						if (#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==() > 0 && #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==() != #=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && !list.Contains(#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==()) && (#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=ziOXVgvjvFhzEtBZSB7CJqUA=().Length != 0 || #=zzrTIZk5avZsKZ_$408IvV2Q=.#=zDSOp4LdHDTK7W9Cid3zPycAwJEBD))
						{
							#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=, #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==().ToString(), true, #=z0fnp28WHdHHIomvTDkV56EngzJg);
							if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null)
							{
								List<#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zSHtW6TQZwDI3FfF3XnOKUOI=> list2 = #=zzrTIZk5avZsKZ_$408IvV2Q=;
								#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zSHtW6TQZwDI3FfF3XnOKUOI= #=zSHtW6TQZwDI3FfF3XnOKUOI= = new #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zSHtW6TQZwDI3FfF3XnOKUOI=();
								#=zSHtW6TQZwDI3FfF3XnOKUOI=.#=zeAChU_4=(#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==);
								#=zSHtW6TQZwDI3FfF3XnOKUOI=.#=zejuXi_yDZSHsXjtZAg==(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==);
								list2.Add(#=zSHtW6TQZwDI3FfF3XnOKUOI=);
							}
							list.Add(#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z4i7DNJN0d7zCbKfc$w==());
						}
						#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zJwfg43Iwxy4N(i + 1);
					}
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
			if (#=zzrTIZk5avZsKZ_$408IvV2Q= != null)
			{
				#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8w$9U75qCzHc(true);
			}
		}

		// Token: 0x060010F8 RID: 4344 RVA: 0x00082C84 File Offset: 0x00080E84
		public static void #=zPh_IX4lm4F7v7FVs6GhOD$U=(object #=zcyRsraWouSUf)
		{
			#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q= #=zzrTIZk5avZsKZ_$408IvV2Q= = null;
			try
			{
				#=zzrTIZk5avZsKZ_$408IvV2Q= = (#=zcyRsraWouSUf as #=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zzrTIZk5avZsKZ_$408IvV2Q=);
				if (#=zzrTIZk5avZsKZ_$408IvV2Q= != null && #=zzrTIZk5avZsKZ_$408IvV2Q=.#=z4_PYUsMrrDxD() >= 0 && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=))
				{
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zShlEjy3SNmZE2bOFy0fqKgIUdDqq(false);
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zfA6C0jYwhi0tXFeEPaBsGiU=().Clear();
					#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=);
					#=zeIC$gptqwJTzV1z7KfH5CvRE51ueHuWiPvqlmeA=.#=zSHtW6TQZwDI3FfF3XnOKUOI= #=zSHtW6TQZwDI3FfF3XnOKUOI= = #=zzrTIZk5avZsKZ_$408IvV2Q=[#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z4_PYUsMrrDxD()];
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zJwfg43Iwxy4N(0);
					#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zNFLgHrjVit1$(#=zSHtW6TQZwDI3FfF3XnOKUOI=.#=zqjHOR9Q=().#=ziOXVgvjvFhzEtBZSB7CJqUA=().Length);
					for (int i = 0; i < #=zSHtW6TQZwDI3FfF3XnOKUOI=.#=zqjHOR9Q=().#=ziOXVgvjvFhzEtBZSB7CJqUA=().Length; i++)
					{
						#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== item = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zzPn$273mIKsu(#=zzrTIZk5avZsKZ_$408IvV2Q=.#=z8StzeqE=, #=zSHtW6TQZwDI3FfF3XnOKUOI=.#=zqjHOR9Q=().#=ziOXVgvjvFhzEtBZSB7CJqUA=()[i].ToString(), true, #=zSJY$s3o=);
						#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zfA6C0jYwhi0tXFeEPaBsGiU=().Add(item);
						#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zJwfg43Iwxy4N(i + 1);
					}
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
			if (#=zzrTIZk5avZsKZ_$408IvV2Q= != null)
			{
				#=zzrTIZk5avZsKZ_$408IvV2Q=.#=zShlEjy3SNmZE2bOFy0fqKgIUdDqq(true);
			}
		}

		// Token: 0x0400092F RID: 2351
		private bool #=zDqBE41LMvqKVk44N1A==;

		// Token: 0x04000930 RID: 2352
		private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

		// Token: 0x04000931 RID: 2353
		private bool #=zDSOp4LdHDTK7W9Cid3zPycAwJEBD;

		// Token: 0x04000932 RID: 2354
		private int #=zEz6xOldWrBJAWJFr1PAIjR8=;

		// Token: 0x04000933 RID: 2355
		private List<#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=zadzHe9XP13R_oBw2fa8U7B0JPP0v9gFTeA==;

		// Token: 0x04000934 RID: 2356
		private bool #=zVXOvVExtJjVg6Tqs3$T_h8P7RCqxuuAtUw==;

		// Token: 0x04000935 RID: 2357
		private int #=z5IwHc0VPfAuZ_z9R40aKsVc=;

		// Token: 0x04000936 RID: 2358
		private int #=zLNFJ5mIaX$b0GfpBzjNtsXo=;
	}
}
