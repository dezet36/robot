﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Skink.SnR.Common;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.GZip;
using Skink.SnR.Common.Managers;

// Token: 0x02000210 RID: 528
internal sealed class #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T
{
	// Token: 0x06001029 RID: 4137 RVA: 0x0007C28C File Offset: 0x0007A48C
	public static string #=zNe6HKhaDPVTk(string #=zVI_2r0M=)
	{
		return #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWHJEiAyx8u5z((HttpWebRequest)WebRequest.Create(#=zVI_2r0M=));
	}

	// Token: 0x0600102A RID: 4138 RVA: 0x0007C2A0 File Offset: 0x0007A4A0
	public static void #=zTvO8aG2BI37U(HttpWebRequest #=zjZWhv$4=, string #=zWC15sHaiwX4N)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(#=zWC15sHaiwX4N);
		#=zjZWhv$4=.ContentLength = (long)bytes.Length;
		Stream requestStream = #=zjZWhv$4=.GetRequestStream();
		requestStream.Write(bytes, 0, bytes.Length);
		requestStream.Close();
	}

	// Token: 0x0600102B RID: 4139 RVA: 0x0007C2DC File Offset: 0x0007A4DC
	public static string #=zWHJEiAyx8u5z(HttpWebRequest #=zjZWhv$4=)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(#=zjZWhv$4=, false);
		if (!string.IsNullOrEmpty(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof()))
		{
			return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof();
		}
		return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2();
	}

	// Token: 0x0600102C RID: 4140 RVA: 0x0007C30C File Offset: 0x0007A50C
	public static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zm08MN_hjR85D(HttpWebRequest #=zjZWhv$4=, bool #=zF$cT06obOreP)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 result;
		using (HttpWebResponse httpWebResponse = (HttpWebResponse)#=zjZWhv$4=.GetResponse())
		{
			if (httpWebResponse.StatusCode != 200)
			{
				throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)0, string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944433), httpWebResponse.StatusCode, httpWebResponse.StatusDescription), Array.Empty<object>());
			}
			result = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(httpWebResponse, #=zF$cT06obOreP);
		}
		return result;
	}

	// Token: 0x0600102D RID: 4141 RVA: 0x0007C384 File Offset: 0x0007A584
	public static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zjZWhv$4=, bool #=zF$cT06obOreP)
	{
		return #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(#=zjZWhv$4=.#=zJgvbqC5Kxvxk(), #=zF$cT06obOreP);
	}

	// Token: 0x0600102E RID: 4142 RVA: 0x0007C394 File Offset: 0x0007A594
	public static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=z09iafw7Wl4vQKwc3HkSF0Ny0shVn(HttpWebRequest #=zjZWhv$4=, bool #=zF$cT06obOreP)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 result;
		try
		{
			using (HttpWebResponse httpWebResponse = (HttpWebResponse)#=zjZWhv$4=.GetResponse())
			{
				result = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(httpWebResponse, #=zF$cT06obOreP);
			}
		}
		catch (WebException ex)
		{
			result = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D((HttpWebResponse)ex.Response, #=zF$cT06obOreP);
		}
		return result;
	}

	// Token: 0x0600102F RID: 4143 RVA: 0x0007C3F8 File Offset: 0x0007A5F8
	public static string #=zWHJEiAyx8u5z(HttpWebResponse #=zvq0$kQI=)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(#=zvq0$kQI=, false);
		if (!string.IsNullOrEmpty(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof()))
		{
			return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z37JbfhBQfNof();
		}
		return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=z0KhF75_5Qux2();
	}

	// Token: 0x06001030 RID: 4144 RVA: 0x0007C428 File Offset: 0x0007A628
	public static #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zm08MN_hjR85D(HttpWebResponse #=zvq0$kQI=, bool #=zF$cT06obOreP)
	{
		#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 result;
		try
		{
			MemoryStream memoryStream = new MemoryStream();
			using (Stream responseStream = #=zvq0$kQI=.GetResponseStream())
			{
				try
				{
					responseStream.CopyTo(memoryStream);
				}
				catch (Exception ex)
				{
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp = new #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4();
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=zk_HcutVoOsuQ(Encoding.UTF8);
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=zU_xQHn4tKaS4(new Dictionary<string, string>());
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=zLJA68V6kgd4y(null);
					#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp.#=zegbyLruW1Ya2(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944403) + #=zvq0$kQI=.StatusCode.ToString() + #=zvq0$kQI=.ContentLength.ToString() + ex.Message);
					return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp;
				}
			}
			byte[] array = memoryStream.GetBuffer();
			try
			{
				if (#=zvq0$kQI=.ContentEncoding.ToLower().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944636)))
				{
					array = GZipStream.UncompressBuffer(array);
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2 = new #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4();
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2.#=zk_HcutVoOsuQ(Encoding.UTF8);
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2.#=zU_xQHn4tKaS4(new Dictionary<string, string>());
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2.#=zLJA68V6kgd4y(null);
				#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2.#=zegbyLruW1Ya2(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944619) + #=zvq0$kQI=.StatusCode.ToString() + #=zvq0$kQI=.ContentLength.ToString() + #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
				return #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp2;
			}
			Encoding encoding = Encoding.UTF8;
			string text = #=zvq0$kQI=.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108817)];
			if (!string.IsNullOrEmpty(text) && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944595)))
			{
				encoding = Encoding.GetEncoding(1251);
			}
			string text2 = encoding.GetString(array);
			text2 = text2.Trim(new char[1]);
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			if (#=zF$cT06obOreP)
			{
				string[] allKeys = #=zvq0$kQI=.Headers.AllKeys;
				for (int i = 0; i < allKeys.Length; i++)
				{
					dictionary.Add(allKeys[i], #=zvq0$kQI=.Headers[allKeys[i]]);
				}
			}
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3 = new #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4();
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zk_HcutVoOsuQ(encoding);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zJgSvWYozGNUy(#=zvq0$kQI=.ProtocolVersion.ToString());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zbrtvpkQ=(#=zvq0$kQI=.StatusCode);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zU_xQHn4tKaS4(dictionary);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zLJA68V6kgd4y(text2);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3.#=zegbyLruW1Ya2(null);
			result = #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp3;
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 = new #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4();
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4.#=zk_HcutVoOsuQ(Encoding.UTF8);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4.#=zU_xQHn4tKaS4(new Dictionary<string, string>());
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4.#=zLJA68V6kgd4y(null);
			#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4.#=zegbyLruW1Ya2(#=zvq0$kQI=.StatusCode.ToString() + #=zvq0$kQI=.ContentLength.ToString() + #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=2));
			result = #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4;
		}
		return result;
	}

	// Token: 0x06001031 RID: 4145 RVA: 0x0007C700 File Offset: 0x0007A900
	public static string[] #=zXMCIYOSN94Do7EXjeQ==(string #=z1e9esKlJKE7y)
	{
		return JSONManager.SplitStringByFirstOccurence(#=z1e9esKlJKE7y, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), true, 1);
	}

	// Token: 0x06001032 RID: 4146 RVA: 0x0007C714 File Offset: 0x0007A914
	public static void #=zE2fpVUDtCZmG(HttpWebRequest #=zjZWhv$4=, string #=z1e9esKlJKE7y)
	{
		string[] array = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zXMCIYOSN94Do7EXjeQ==(#=z1e9esKlJKE7y);
		#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zE2fpVUDtCZmG(#=zjZWhv$4=, array[0], array[1]);
	}

	// Token: 0x06001033 RID: 4147 RVA: 0x0007C734 File Offset: 0x0007A934
	public static void #=zE2fpVUDtCZmG(HttpWebRequest #=zjZWhv$4=, string #=zMH5y1Xo=, string #=zVdd26RE=)
	{
		string text = #=zMH5y1Xo=.ToLower();
		if (text != null)
		{
			switch (text.Length)
			{
			case 4:
				if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052955))
				{
					return;
				}
				break;
			case 6:
			{
				char c = text[0];
				if (c != 'a')
				{
					if (c == 'c')
					{
						if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057770))
						{
							if (#=zjZWhv$4=.CookieContainer != null)
							{
								#=zjZWhv$4=.CookieContainer.SetCookies(#=zjZWhv$4=.RequestUri, #=zVdd26RE=.Replace(';', ','));
								return;
							}
							#=zjZWhv$4=.Headers.Add(#=zMH5y1Xo=, #=zVdd26RE=);
							return;
						}
					}
				}
				else if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108804))
				{
					#=zjZWhv$4=.Accept = #=zVdd26RE=;
					return;
				}
				break;
			}
			case 7:
				if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944567))
				{
					#=zjZWhv$4=.Referer = #=zVdd26RE=;
					return;
				}
				break;
			case 10:
			{
				char c = text[0];
				if (c <= 'k')
				{
					if (c != 'c')
					{
						if (c == 'k')
						{
							if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108863))
							{
								#=zjZWhv$4=.KeepAlive = (#=zVdd26RE=.ToLower() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
								return;
							}
						}
					}
					else if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109134))
					{
						if (#=zVdd26RE=.ToLower() == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108863))
						{
							#=zjZWhv$4=.KeepAlive = true;
							return;
						}
						#=zjZWhv$4=.Connection = #=zVdd26RE=;
						return;
					}
				}
				else if (c != 's')
				{
					if (c == 'u')
					{
						if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944582))
						{
							#=zjZWhv$4=.UserAgent = #=zVdd26RE=;
							return;
						}
					}
				}
				else if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108763))
				{
					if (#=zjZWhv$4=.CookieContainer == null)
					{
						#=zjZWhv$4=.CookieContainer = new CookieContainer();
					}
					string[] array = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zXMCIYOSN94Do7EXjeQ==(#=zVdd26RE=);
					if (!string.IsNullOrEmpty(array[0]))
					{
						#=zjZWhv$4=.CookieContainer.Add(#=zjZWhv$4=.RequestUri, new Cookie(array[0], array[1]));
						return;
					}
					return;
				}
				break;
			}
			case 12:
				if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108817))
				{
					#=zjZWhv$4=.ContentType = #=zVdd26RE=;
					return;
				}
				break;
			case 14:
				if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108844))
				{
					#=zjZWhv$4=.ContentLength = Convert.ToInt64(#=zVdd26RE=);
					return;
				}
				break;
			}
		}
		#=zjZWhv$4=.Headers.Add(#=zMH5y1Xo=, #=zVdd26RE=);
	}

	// Token: 0x06001034 RID: 4148 RVA: 0x0007C9C8 File Offset: 0x0007ABC8
	public static string #=zEM0NHOpV67i4(string #=z1_TMI3g=, int #=ziU7$qJ4=, string #=zb8Lv3Rk=)
	{
		if (#=zb8Lv3Rk=.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944545)))
		{
			string s = #=zb8Lv3Rk=.Substring(#=zb8Lv3Rk=.IndexOf(Environment.NewLine + Environment.NewLine)).Trim();
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			#=zb8Lv3Rk= = #=zb8Lv3Rk=.Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944545), bytes.Length.ToString());
		}
		SslStream sslStream = new SslStream(new TcpClient(#=z1_TMI3g=, #=ziU7$qJ4=).GetStream(), false, new RemoteCertificateValidationCallback(#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zyDNvciU=.#=zLkw0NRU=.#=zZmOlw2iKdh_6ZLRG1f6NvpX6sZ4n), null);
		sslStream.AuthenticateAsClient(#=z1_TMI3g=);
		byte[] array = new byte[2048];
		byte[] bytes2 = Encoding.UTF8.GetBytes(#=zb8Lv3Rk=);
		sslStream.Write(bytes2, 0, bytes2.Length);
		sslStream.Flush();
		StringBuilder stringBuilder = new StringBuilder();
		int num;
		do
		{
			num = sslStream.Read(array, 0, array.Length);
			stringBuilder.Append(Encoding.UTF8.GetString(array, 0, num));
		}
		while (num == 2048);
		return stringBuilder.ToString();
	}

	// Token: 0x06001035 RID: 4149 RVA: 0x0007CAD0 File Offset: 0x0007ACD0
	public static string #=zxrOUaQcZA_57(#=zAjO7I84RW8RKI9PeCopgq9B$x73y #=zjZWhv$4=)
	{
		string result;
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.Append(#=zjZWhv$4=.#=zJgvbqC5Kxvxk().Method);
			stringBuilder.Append(' ');
			stringBuilder.Append(#=zjZWhv$4=.#=zJgvbqC5Kxvxk().RequestUri);
			stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944520));
			stringBuilder.Append(#=zjZWhv$4=.#=zJgvbqC5Kxvxk().ProtocolVersion.ToString());
			stringBuilder.Append(Environment.NewLine);
			foreach (object obj in #=zjZWhv$4=.#=zJgvbqC5Kxvxk().Headers.Keys)
			{
				string text = (string)obj;
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102575), text, #=zjZWhv$4=.#=zJgvbqC5Kxvxk().Headers[text], Environment.NewLine);
			}
			if (!string.IsNullOrEmpty(#=zjZWhv$4=.#=zjPGMpWAlPPyY()))
			{
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102575), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943737), #=zjZWhv$4=.#=zjPGMpWAlPPyY(), Environment.NewLine);
			}
			stringBuilder.Append(Environment.NewLine);
			stringBuilder.Append(#=zjZWhv$4=.#=ziywd55xwWd2r());
			result = stringBuilder.ToString();
		}
		catch (Exception #=zN_s5Z5A=)
		{
			result = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
		}
		return result;
	}

	// Token: 0x06001036 RID: 4150 RVA: 0x0007CC40 File Offset: 0x0007AE40
	public static string #=zME6c59mcU_6Y(HttpWebResponse #=zvq0$kQI=)
	{
		return #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zME6c59mcU_6Y(#=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zm08MN_hjR85D(#=zvq0$kQI=, false));
	}

	// Token: 0x06001037 RID: 4151 RVA: 0x0007CC50 File Offset: 0x0007AE50
	public static string #=zME6c59mcU_6Y(#=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4 #=zhgo816s=)
	{
		string result;
		if (string.IsNullOrEmpty(#=zhgo816s=.#=z37JbfhBQfNof()))
		{
			StringBuilder stringBuilder = new StringBuilder(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908944517));
			stringBuilder.Append(#=zhgo816s=.#=zUorwLJaGMjZ6());
			stringBuilder.Append(' ');
			stringBuilder.Append(#=zhgo816s=.#=z9ZHUN$Y=());
			stringBuilder.Append(' ');
			stringBuilder.Append(#=zhgo816s=.#=z9ZHUN$Y=());
			stringBuilder.Append(Environment.NewLine);
			foreach (string text in #=zhgo816s=.#=z5aV1tF47CwIR().Keys)
			{
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946289), text, #=zhgo816s=.#=z5aV1tF47CwIR()[text], Environment.NewLine);
			}
			if (stringBuilder.Length > 0)
			{
				result = stringBuilder.ToString() + Environment.NewLine + #=zhgo816s=.#=z0KhF75_5Qux2();
			}
			else
			{
				result = #=zhgo816s=.#=z0KhF75_5Qux2();
			}
		}
		else
		{
			result = #=zhgo816s=.#=z37JbfhBQfNof();
		}
		return result;
	}

	// Token: 0x06001038 RID: 4152 RVA: 0x0007CD64 File Offset: 0x0007AF64
	public static void #=zWP6h8M9Cec$M(HttpWebRequest #=zjZWhv$4=, ProxyInfo #=zsHG$Y6w=)
	{
		if (#=zsHG$Y6w= != null && #=zsHG$Y6w=.Type != ProxyTypes.NoProxy)
		{
			#=zjZWhv$4=.Proxy = new WebProxy(#=zsHG$Y6w=.IP, #=zsHG$Y6w=.Port);
			if (!string.IsNullOrEmpty(#=zsHG$Y6w=.Login))
			{
				#=zjZWhv$4=.Proxy.Credentials = new NetworkCredential(#=zsHG$Y6w=.Login, #=zsHG$Y6w=.Password);
			}
		}
	}

	// Token: 0x06001039 RID: 4153 RVA: 0x0007CDBC File Offset: 0x0007AFBC
	public static void #=zWP6h8M9Cec$M(HttpWebRequest #=zjZWhv$4=, string #=zzmHSvBQ=, ProxyFormats #=z7gOpVK0=)
	{
		if (!string.IsNullOrEmpty(#=zzmHSvBQ=))
		{
			try
			{
				ProxyInfo fromString = ProxyInfo.GetFromString(#=zzmHSvBQ=, #=z7gOpVK0=, ProxyTypes.Static);
				#=zjZWhv$4=.Proxy = new WebProxy(fromString.IP, fromString.Port);
				if (!string.IsNullOrEmpty(fromString.Login))
				{
					#=zjZWhv$4=.Proxy.Credentials = new NetworkCredential(fromString.Login, fromString.Password);
				}
			}
			catch (Exception ex)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zibPHrbBZL5Cc(LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946279), new object[]
				{
					#=zzmHSvBQ=,
					ex.Message
				});
			}
		}
	}

	// Token: 0x0600103A RID: 4154 RVA: 0x0007CE58 File Offset: 0x0007B058
	public static List<CookieCollection> #=zswTkwfUL6oHu(CookieContainer #=zQUn_5_A=)
	{
		List<CookieCollection> list = new List<CookieCollection>();
		foreach (object obj in ((Hashtable)#=zQUn_5_A=.GetType().GetField(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946217), BindingFlags.Instance | BindingFlags.NonPublic).GetValue(#=zQUn_5_A=)))
		{
			DictionaryEntry dictionaryEntry = (DictionaryEntry)obj;
			foreach (object obj2 in ((SortedList)dictionaryEntry.Value.GetType().GetField(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946205), BindingFlags.Instance | BindingFlags.NonPublic).GetValue(dictionaryEntry.Value)))
			{
				list.Add((CookieCollection)((DictionaryEntry)obj2).Value);
			}
		}
		return list;
	}

	// Token: 0x02000211 RID: 529
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600103D RID: 4157 RVA: 0x0007CF68 File Offset: 0x0007B168
		internal bool #=zZmOlw2iKdh_6ZLRG1f6NvpX6sZ4n(object #=zdoNsHoiNlO_E, X509Certificate #=zz8wTU8Q4JhVX, X509Chain #=zTHuOiIWxRHU7, SslPolicyErrors #=zfLQAmC11gDdq)
		{
			return true;
		}

		// Token: 0x040008E5 RID: 2277
		public static readonly #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zyDNvciU= #=zLkw0NRU= = new #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zyDNvciU=();

		// Token: 0x040008E6 RID: 2278
		public static RemoteCertificateValidationCallback #=z6kaS0hT02rVUCvrtZA==;
	}
}
