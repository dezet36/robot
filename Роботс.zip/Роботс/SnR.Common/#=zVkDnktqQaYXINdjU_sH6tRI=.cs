﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020001C3 RID: 451
internal sealed class #=zVkDnktqQaYXINdjU_sH6tRI= : RecordData
{
	// Token: 0x06000D63 RID: 3427 RVA: 0x00068C6C File Offset: 0x00066E6C
	public #=zVkDnktqQaYXINdjU_sH6tRI=(Record #=zJce$Sys=) : base(Type.PASSWORD)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		this.#=zu2TaByqQIHba = IntegerHelper.getInt(data[0], data[1]);
	}

	// Token: 0x06000D64 RID: 3428 RVA: 0x00068C9C File Offset: 0x00066E9C
	public int #=z94Qyva_6wFgj()
	{
		return this.#=zu2TaByqQIHba;
	}

	// Token: 0x040007B1 RID: 1969
	private string #=zjMfTbhE=;

	// Token: 0x040007B2 RID: 1970
	private int #=zu2TaByqQIHba;
}
