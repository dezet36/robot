﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;

// Token: 0x02000051 RID: 81
internal sealed class #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl : IComparer<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>
{
	// Token: 0x06000261 RID: 609 RVA: 0x00015E0C File Offset: 0x0001400C
	public #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl()
	{
		this.#=zzM_7pdfAr69D(100);
	}

	// Token: 0x06000262 RID: 610 RVA: 0x00015E1C File Offset: 0x0001401C
	public #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl(Dictionary<string, object> #=zimDxJ9A=)
	{
		this.#=zBSjk$U_t1Pev((GameApplicationData.GameHosters)JSONManager.ExtractInt(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053), 0));
		this.#=zinKNQicbcZrD(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zIsC$qK_fWhaH76s5gg==(JSONManager.ExtractInt(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), 0)));
		this.#=zFzGvi_S6jJhE((AccessLevels)JSONManager.ExtractInt(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767), 0));
		this.#=zYTBroMkKB8GB(JSONManager.ExtractDate(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899), true));
		this.#=zSYGTieA=((AccoutRegistrationResults)JSONManager.ExtractInt(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		this.#=zdsiwBTS4ofKZ(JSONManager.ExtractString(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), string.Empty));
		this.#=ze8TQhOAtefck(JSONManager.ExtractString(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), string.Empty));
		this.#=zwXKUV2c=(JSONManager.ExtractString(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950), string.Empty));
		this.#=zU2TppkfXydBf(JSONManager.ExtractString(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), string.Empty));
		this.#=zzM_7pdfAr69D(JSONManager.ExtractInt(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940242), 100));
		this.#=zojHCQcuGBXly(new #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g==(JSONManager.ExtractDictionary(#=zimDxJ9A=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940038))));
	}

	// Token: 0x06000263 RID: 611 RVA: 0x00015F48 File Offset: 0x00014148
	public GameApplicationData.GameHosters #=z7wsmjLWw49AC()
	{
		return this.#=zjOKMKV$iWbcRSA1YeA==;
	}

	// Token: 0x06000264 RID: 612 RVA: 0x00015F50 File Offset: 0x00014150
	public void #=zBSjk$U_t1Pev(GameApplicationData.GameHosters #=z$Ib9gYQ=)
	{
		this.#=zjOKMKV$iWbcRSA1YeA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000265 RID: 613 RVA: 0x00015F5C File Offset: 0x0001415C
	public GameApplicationData.Games #=zZ2dsDUeWDYAN()
	{
		return this.#=zZZfzOIF7ifXR_NwlBQJ9tTM=;
	}

	// Token: 0x06000266 RID: 614 RVA: 0x00015F64 File Offset: 0x00014164
	public void #=zinKNQicbcZrD(GameApplicationData.Games #=z$Ib9gYQ=)
	{
		this.#=zZZfzOIF7ifXR_NwlBQJ9tTM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000267 RID: 615 RVA: 0x00015F70 File Offset: 0x00014170
	public bool #=zhk3ouca6bP96()
	{
		return this.#=zI8oDtNkLEXL1lC6o96o5tcI=;
	}

	// Token: 0x06000268 RID: 616 RVA: 0x00015F78 File Offset: 0x00014178
	public void #=z$slFH0_Vf3dL(bool #=z$Ib9gYQ=)
	{
		this.#=zI8oDtNkLEXL1lC6o96o5tcI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000269 RID: 617 RVA: 0x00015F84 File Offset: 0x00014184
	public string #=zCCvotbi$42tS()
	{
		return this.#=zUdpjF2Q=;
	}

	// Token: 0x0600026A RID: 618 RVA: 0x00015F8C File Offset: 0x0001418C
	public void #=ze8TQhOAtefck(string #=z$Ib9gYQ=)
	{
		this.#=zUdpjF2Q= = ((#=z$Ib9gYQ= == null) ? #=z$Ib9gYQ= : #=z$Ib9gYQ=.Trim());
	}

	// Token: 0x0600026B RID: 619 RVA: 0x00015FA0 File Offset: 0x000141A0
	public string #=zsmHAU_GQ9ylR()
	{
		return this.#=zs9eWKHsFxO7Gex1BBlB3CVQ=;
	}

	// Token: 0x0600026C RID: 620 RVA: 0x00015FA8 File Offset: 0x000141A8
	public void #=zU2TppkfXydBf(string #=z$Ib9gYQ=)
	{
		this.#=zs9eWKHsFxO7Gex1BBlB3CVQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600026D RID: 621 RVA: 0x00015FB4 File Offset: 0x000141B4
	public string #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x0600026E RID: 622 RVA: 0x00015FBC File Offset: 0x000141BC
	public void #=zwXKUV2c=(string #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600026F RID: 623 RVA: 0x00015FC8 File Offset: 0x000141C8
	public AccessLevels #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x06000270 RID: 624 RVA: 0x00015FD0 File Offset: 0x000141D0
	public void #=zFzGvi_S6jJhE(AccessLevels #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000271 RID: 625 RVA: 0x00015FDC File Offset: 0x000141DC
	public DateTime #=zCa0AyEddce6P()
	{
		return this.#=zbORbz_4r2xrKseWiP2E4_rE=;
	}

	// Token: 0x06000272 RID: 626 RVA: 0x00015FE4 File Offset: 0x000141E4
	public void #=zYTBroMkKB8GB(DateTime #=z$Ib9gYQ=)
	{
		this.#=zbORbz_4r2xrKseWiP2E4_rE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000273 RID: 627 RVA: 0x00015FF0 File Offset: 0x000141F0
	public AccoutRegistrationResults #=zDZReNK0=()
	{
		return this.#=zIMMjA4KhtGkvHGzNFA==;
	}

	// Token: 0x06000274 RID: 628 RVA: 0x00015FF8 File Offset: 0x000141F8
	public void #=zSYGTieA=(AccoutRegistrationResults #=z$Ib9gYQ=)
	{
		this.#=zIMMjA4KhtGkvHGzNFA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000275 RID: 629 RVA: 0x00016004 File Offset: 0x00014204
	public string #=zfrnDBNz$xQBu()
	{
		return this.#=zQXDDOxQLIxByLtqz2A==;
	}

	// Token: 0x06000276 RID: 630 RVA: 0x0001600C File Offset: 0x0001420C
	public void #=zdsiwBTS4ofKZ(string #=z$Ib9gYQ=)
	{
		this.#=zQXDDOxQLIxByLtqz2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000277 RID: 631 RVA: 0x00016018 File Offset: 0x00014218
	public int #=zuAUSO_bM1Gri()
	{
		return this.#=zyEFWgTVYcZtUZrFrao7i_Ic=;
	}

	// Token: 0x06000278 RID: 632 RVA: 0x00016020 File Offset: 0x00014220
	public void #=zzM_7pdfAr69D(int #=z$Ib9gYQ=)
	{
		this.#=zyEFWgTVYcZtUZrFrao7i_Ic= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000279 RID: 633 RVA: 0x0001602C File Offset: 0x0001422C
	public #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=zc8qEfLcp5D1z()
	{
		return this.#=zDaROUXHklYaNexJf9Q==;
	}

	// Token: 0x0600027A RID: 634 RVA: 0x00016034 File Offset: 0x00014234
	public void #=zojHCQcuGBXly(#=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=z$Ib9gYQ=)
	{
		this.#=zDaROUXHklYaNexJf9Q== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600027B RID: 635 RVA: 0x00016040 File Offset: 0x00014240
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071053),
				(int)this.#=z7wsmjLWw49AC()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				(int)this.#=zZ2dsDUeWDYAN()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767),
				(int)this.#=zvnZc$RhG_1Du()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899),
				JSONManager.EncodeTime(this.#=zCa0AyEddce6P(), true)
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102),
				(int)this.#=zDZReNK0=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245),
				this.#=zCCvotbi$42tS()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077950),
				this.#=zkfqcY3I=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				this.#=zsmHAU_GQ9ylR()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940242),
				this.#=zuAUSO_bM1Gri()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908940038),
				this.#=zc8qEfLcp5D1z().#=zhv7OhlM=()
			}
		};
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00016154 File Offset: 0x00014354
	public int Compare(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=zm8PpuDU=, #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=zcltuPyw=)
	{
		int num = -#=zm8PpuDU=.#=zhk3ouca6bP96().CompareTo(#=zcltuPyw=.#=zhk3ouca6bP96());
		if (num != 0)
		{
			return num;
		}
		num = #=zm8PpuDU=.#=z7wsmjLWw49AC().CompareTo(#=zcltuPyw=.#=z7wsmjLWw49AC());
		if (num != 0)
		{
			return num;
		}
		num = #=zm8PpuDU=.#=zZ2dsDUeWDYAN().CompareTo(#=zcltuPyw=.#=zZ2dsDUeWDYAN());
		if (num != 0)
		{
			return num;
		}
		num = -#=zm8PpuDU=.#=zvnZc$RhG_1Du().CompareTo(#=zcltuPyw=.#=zvnZc$RhG_1Du());
		if (num != 0)
		{
			return num;
		}
		return #=zm8PpuDU=.#=zkfqcY3I=().CompareTo(#=zcltuPyw=.#=zkfqcY3I=());
	}

	// Token: 0x040000BA RID: 186
	private GameApplicationData.GameHosters #=zjOKMKV$iWbcRSA1YeA==;

	// Token: 0x040000BB RID: 187
	private GameApplicationData.Games #=zZZfzOIF7ifXR_NwlBQJ9tTM=;

	// Token: 0x040000BC RID: 188
	private bool #=zI8oDtNkLEXL1lC6o96o5tcI=;

	// Token: 0x040000BD RID: 189
	private string #=zUdpjF2Q=;

	// Token: 0x040000BE RID: 190
	private string #=zs9eWKHsFxO7Gex1BBlB3CVQ=;

	// Token: 0x040000BF RID: 191
	private string #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040000C0 RID: 192
	private AccessLevels #=zq9EZwxO2tjqgH$qWVQ==;

	// Token: 0x040000C1 RID: 193
	private DateTime #=zbORbz_4r2xrKseWiP2E4_rE=;

	// Token: 0x040000C2 RID: 194
	private AccoutRegistrationResults #=zIMMjA4KhtGkvHGzNFA==;

	// Token: 0x040000C3 RID: 195
	private string #=zQXDDOxQLIxByLtqz2A==;

	// Token: 0x040000C4 RID: 196
	private int #=zyEFWgTVYcZtUZrFrao7i_Ic=;

	// Token: 0x040000C5 RID: 197
	private #=znjvOrUxO_YWa6RT7KpTPeUF_pt8BHqe8$g== #=zDaROUXHklYaNexJf9Q==;
}
