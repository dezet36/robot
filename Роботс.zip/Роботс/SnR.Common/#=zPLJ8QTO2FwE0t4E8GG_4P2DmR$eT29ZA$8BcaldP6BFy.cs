﻿using System;

// Token: 0x0200017C RID: 380
internal sealed class #=zPLJ8QTO2FwE0t4E8GG_4P2DmR$eT29ZA$8BcaldP6BFy
{
	// Token: 0x06000AE9 RID: 2793 RVA: 0x00054A04 File Offset: 0x00052C04
	public int #=zdr5FzsyK0qvK()
	{
		return this.#=zXTmqRsy_1tm5q_RBgQ==;
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x00054A0C File Offset: 0x00052C0C
	public void #=z$4RR7hl0Xqo6(int #=z$Ib9gYQ=)
	{
		this.#=zXTmqRsy_1tm5q_RBgQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x00054A18 File Offset: 0x00052C18
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x00054A20 File Offset: 0x00052C20
	public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x040005D4 RID: 1492
	private int #=zXTmqRsy_1tm5q_RBgQ==;

	// Token: 0x040005D5 RID: 1493
	private DateTime #=zJDEdzIaDvHbnYM06$w==;
}
