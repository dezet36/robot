﻿using System;

// Token: 0x0200001C RID: 28
internal interface #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=
{
	// Token: 0x0600004F RID: 79
	bool #=z5od3PV4HEEHLXRWOfZO6P1VrIQHbl1oBd8Cp_FowZoG3mzdKBhQQCq7rP3hB8qKv88UWk0MgM_LM();

	// Token: 0x06000050 RID: 80
	object #=zRGzvFRPn8bJ9t1Tvjk6L$29zAc8YPrcXV_qXA_O5PDBquk65wTwHU61yY9$vh4FPEQ==();

	// Token: 0x06000051 RID: 81
	void #=z7t9vaCLtXgabJKRCE5yIlY7ECce7IQyij7_NW7UrMuuwpeWcqEVWJ3M57xc6DuLTWHsw8tfStDfHdBUEaBtg6mc=();
}
