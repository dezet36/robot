﻿using System;
using System.Collections.Generic;

// Token: 0x0200021E RID: 542
internal sealed class #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg== : Dictionary<int, int>
{
}
