﻿using System;
using System.Collections.Generic;

// Token: 0x02000288 RID: 648
internal sealed class #=zmRluY78FHjyY$O53a2bSLlt_HC$s
{
	// Token: 0x060013AC RID: 5036 RVA: 0x00097994 File Offset: 0x00095B94
	public #=zmRluY78FHjyY$O53a2bSLlt_HC$s(int #=zLeeSKrg=)
	{
		this.#=zgs9J0JlAFhod = #=zLeeSKrg=;
		this.#=zb41Wty4f$IAb = new Dictionary<string, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==>();
		this.#=zyvV1nOBJtP8hwTcFNXlN_hk= = new Dictionary<string, DateTime>();
		this.#=z8GoZ5sWIC0cl = new Dictionary<string, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==>();
		this.#=zJy2iIQX70xf2dDuC$g== = new Dictionary<string, DateTime>();
		this.#=zZ_r4Kqm4l7LCYA0kSw== = new Dictionary<int, string>();
		this.#=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn = new Dictionary<int, DateTime>();
		this.#=zVGprhAIbJ0UXPk00mjCYJMo= = new List<int>();
	}

	// Token: 0x060013AE RID: 5038 RVA: 0x00097A14 File Offset: 0x00095C14
	private static #=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zjqscX6s=(int #=zLeeSKrg=)
	{
		#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = null;
		for (int i = 0; i < #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m.Count; i++)
		{
			if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m[i].#=zgs9J0JlAFhod == #=zLeeSKrg=)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m[i];
				break;
			}
		}
		if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s == null)
		{
			object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
			lock (obj)
			{
				for (int j = 0; j < #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m.Count; j++)
				{
					if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m[j].#=zgs9J0JlAFhod == #=zLeeSKrg=)
					{
						#=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m[j];
						break;
					}
				}
				if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s == null)
				{
					#=zmRluY78FHjyY$O53a2bSLlt_HC$s = new #=zmRluY78FHjyY$O53a2bSLlt_HC$s(#=zLeeSKrg=);
					#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjz3qsKoI_h4m.Add(#=zmRluY78FHjyY$O53a2bSLlt_HC$s);
				}
			}
		}
		return #=zmRluY78FHjyY$O53a2bSLlt_HC$s;
	}

	// Token: 0x060013AF RID: 5039 RVA: 0x00097ADC File Offset: 0x00095CDC
	public static #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zEwTYXjk=(int #=zLeeSKrg=, string #=zAk8mKBk=)
	{
		#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
		if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zb41Wty4f$IAb.ContainsKey(#=zAk8mKBk=))
		{
			if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zyvV1nOBJtP8hwTcFNXlN_hk=.ContainsKey(#=zAk8mKBk=) && #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zyvV1nOBJtP8hwTcFNXlN_hk=[#=zAk8mKBk=] > DateTime.Now)
			{
				return #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zb41Wty4f$IAb[#=zAk8mKBk=];
			}
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zGOw9fVM=(#=zLeeSKrg=, #=zAk8mKBk=);
		}
		return null;
	}

	// Token: 0x060013B0 RID: 5040 RVA: 0x00097B3C File Offset: 0x00095D3C
	public static void #=zGq68XSs=(int #=zLeeSKrg=, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zjenaw44=)
	{
		if (#=zjenaw44= != null)
		{
			object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zb41Wty4f$IAb[#=zjenaw44=.#=zMuFMjGQ=().ToString()] = #=zjenaw44=;
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zyvV1nOBJtP8hwTcFNXlN_hk=[#=zjenaw44=.#=zMuFMjGQ=().ToString()] = DateTime.Now + TimeSpan.FromMinutes(10.0);
			}
		}
	}

	// Token: 0x060013B1 RID: 5041 RVA: 0x00097BC8 File Offset: 0x00095DC8
	public static bool #=zGOw9fVM=(int #=zLeeSKrg=, string #=zAk8mKBk=)
	{
		object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
		bool result;
		lock (obj)
		{
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
			bool flag2 = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zb41Wty4f$IAb.Remove(#=zAk8mKBk=);
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zyvV1nOBJtP8hwTcFNXlN_hk=.Remove(#=zAk8mKBk=);
			result = flag2;
		}
		return result;
	}

	// Token: 0x060013B2 RID: 5042 RVA: 0x00097C24 File Offset: 0x00095E24
	public static #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zoMNV7yzvZ8th(int #=zLeeSKrg=, string #=zAk8mKBk=)
	{
		#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
		if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z8GoZ5sWIC0cl.ContainsKey(#=zAk8mKBk=))
		{
			if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zJy2iIQX70xf2dDuC$g==.ContainsKey(#=zAk8mKBk=) && #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zJy2iIQX70xf2dDuC$g==[#=zAk8mKBk=] > DateTime.Now)
			{
				return #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z8GoZ5sWIC0cl[#=zAk8mKBk=];
			}
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z4wYeHwEB7YSP(#=zLeeSKrg=, #=zAk8mKBk=);
		}
		return null;
	}

	// Token: 0x060013B3 RID: 5043 RVA: 0x00097C84 File Offset: 0x00095E84
	public static void #=zBDC6HVnfSGIL(int #=zLeeSKrg=, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zdrGIKg0=)
	{
		if (#=zdrGIKg0= != null)
		{
			object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z8GoZ5sWIC0cl[#=zdrGIKg0=.#=zMuFMjGQ=().ToString()] = #=zdrGIKg0=;
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zJy2iIQX70xf2dDuC$g==[#=zdrGIKg0=.#=zMuFMjGQ=().ToString()] = DateTime.Now + TimeSpan.FromMinutes(5.0);
			}
		}
	}

	// Token: 0x060013B4 RID: 5044 RVA: 0x00097D10 File Offset: 0x00095F10
	public static bool #=z4wYeHwEB7YSP(int #=zLeeSKrg=, string #=zAk8mKBk=)
	{
		object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
		bool result;
		lock (obj)
		{
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
			bool flag2 = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=z8GoZ5sWIC0cl.Remove(#=zAk8mKBk=);
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zJy2iIQX70xf2dDuC$g==.Remove(#=zAk8mKBk=);
			result = flag2;
		}
		return result;
	}

	// Token: 0x060013B5 RID: 5045 RVA: 0x00097D6C File Offset: 0x00095F6C
	public static string #=z88KXN9YQlR89lG4bcw==(int #=zLeeSKrg=, int #=zAk8mKBk=)
	{
		#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
		if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zZ_r4Kqm4l7LCYA0kSw==.ContainsKey(#=zAk8mKBk=))
		{
			if (#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn.ContainsKey(#=zAk8mKBk=) && #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn[#=zAk8mKBk=] > DateTime.Now)
			{
				return #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zZ_r4Kqm4l7LCYA0kSw==[#=zAk8mKBk=];
			}
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zaSj923AcHbIipudkqg==(#=zLeeSKrg=, #=zAk8mKBk=);
		}
		return null;
	}

	// Token: 0x060013B6 RID: 5046 RVA: 0x00097DCC File Offset: 0x00095FCC
	public static void #=z9Uo2__KT2KDVqGg7YQ==(int #=zLeeSKrg=, int #=zAk8mKBk=, string #=z39WpvgDrY2U1QQIPUw==)
	{
		if (!string.IsNullOrWhiteSpace(#=z39WpvgDrY2U1QQIPUw==))
		{
			object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zZ_r4Kqm4l7LCYA0kSw==[#=zAk8mKBk=] = #=z39WpvgDrY2U1QQIPUw==;
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn[#=zAk8mKBk=] = DateTime.Now + TimeSpan.FromMinutes(60.0);
			}
		}
	}

	// Token: 0x060013B7 RID: 5047 RVA: 0x00097E44 File Offset: 0x00096044
	public static bool #=zaSj923AcHbIipudkqg==(int #=zLeeSKrg=, int #=zAk8mKBk=)
	{
		object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
		bool result;
		lock (obj)
		{
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
			bool flag2 = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zZ_r4Kqm4l7LCYA0kSw==.Remove(#=zAk8mKBk=);
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn.Remove(#=zAk8mKBk=);
			result = flag2;
		}
		return result;
	}

	// Token: 0x060013B8 RID: 5048 RVA: 0x00097EA0 File Offset: 0x000960A0
	public static bool #=z5nwSpHr8_MMZ(int #=zLeeSKrg=, int #=zAk8mKBk=)
	{
		return #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=).#=zVGprhAIbJ0UXPk00mjCYJMo=.Contains(#=zAk8mKBk=);
	}

	// Token: 0x060013B9 RID: 5049 RVA: 0x00097EB8 File Offset: 0x000960B8
	public static void #=z88R87Aei0uiQ(int #=zLeeSKrg=, int #=zAk8mKBk=)
	{
		object obj = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zSV4$mlFB34WM;
		lock (obj)
		{
			#=zmRluY78FHjyY$O53a2bSLlt_HC$s #=zmRluY78FHjyY$O53a2bSLlt_HC$s = #=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zjqscX6s=(#=zLeeSKrg=);
			if (!#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zVGprhAIbJ0UXPk00mjCYJMo=.Contains(#=zAk8mKBk=))
			{
				#=zmRluY78FHjyY$O53a2bSLlt_HC$s.#=zVGprhAIbJ0UXPk00mjCYJMo=.Add(#=zAk8mKBk=);
			}
		}
	}

	// Token: 0x04000B5C RID: 2908
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000B5D RID: 2909
	private static List<#=zmRluY78FHjyY$O53a2bSLlt_HC$s> #=zjz3qsKoI_h4m = new List<#=zmRluY78FHjyY$O53a2bSLlt_HC$s>();

	// Token: 0x04000B5E RID: 2910
	private int #=zgs9J0JlAFhod;

	// Token: 0x04000B5F RID: 2911
	private Dictionary<string, #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==> #=zb41Wty4f$IAb;

	// Token: 0x04000B60 RID: 2912
	private Dictionary<string, DateTime> #=zyvV1nOBJtP8hwTcFNXlN_hk=;

	// Token: 0x04000B61 RID: 2913
	private Dictionary<string, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> #=z8GoZ5sWIC0cl;

	// Token: 0x04000B62 RID: 2914
	private Dictionary<string, DateTime> #=zJy2iIQX70xf2dDuC$g==;

	// Token: 0x04000B63 RID: 2915
	private Dictionary<int, string> #=zZ_r4Kqm4l7LCYA0kSw==;

	// Token: 0x04000B64 RID: 2916
	private Dictionary<int, DateTime> #=zFH6tGOph5gfVWuSoHL3sRPuZ9Jpn;

	// Token: 0x04000B65 RID: 2917
	private List<int> #=zVGprhAIbJ0UXPk00mjCYJMo=;
}
