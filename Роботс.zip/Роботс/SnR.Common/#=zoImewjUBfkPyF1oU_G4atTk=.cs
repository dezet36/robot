﻿using System;
using System.Text;

// Token: 0x0200029F RID: 671
internal abstract class #=zoImewjUBfkPyF1oU_G4atTk=
{
	// Token: 0x06001465 RID: 5221 RVA: 0x0009C760 File Offset: 0x0009A960
	public #=zoImewjUBfkPyF1oU_G4atTk=()
	{
		this.#=zJ97IZ1IwBsnR = false;
		this.#=z790jx38= = false;
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x0009C778 File Offset: 0x0009A978
	protected internal virtual void #=zn2dh4vc=(#=zoImewjUBfkPyF1oU_G4atTk= #=z$Ib9gYQ=)
	{
		this.#=z0xdP5aY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001467 RID: 5223
	internal abstract sbyte[] #=ztbIWLuVjfGLU();

	// Token: 0x06001468 RID: 5224 RVA: 0x0009C784 File Offset: 0x0009A984
	protected internal virtual void #=z_3UsFxQ=()
	{
		this.#=zJ97IZ1IwBsnR = true;
		if (this.#=z0xdP5aY= != null && !this.#=z0xdP5aY=.#=zgKtpZzY=())
		{
			this.#=z0xdP5aY=.#=z_3UsFxQ=();
		}
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x0009C7B0 File Offset: 0x0009A9B0
	internal bool #=zgKtpZzY=()
	{
		return this.#=zJ97IZ1IwBsnR;
	}

	// Token: 0x0600146A RID: 5226
	public abstract void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=);

	// Token: 0x0600146B RID: 5227
	public abstract void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw);

	// Token: 0x0600146C RID: 5228
	public abstract void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC);

	// Token: 0x0600146D RID: 5229
	internal abstract void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC);

	// Token: 0x0600146E RID: 5230
	internal abstract void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC);

	// Token: 0x0600146F RID: 5231
	internal abstract void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC);

	// Token: 0x06001470 RID: 5232 RVA: 0x0009C7B8 File Offset: 0x0009A9B8
	protected internal virtual void #=zN73BToKeZLgg()
	{
		this.#=z790jx38= = true;
	}

	// Token: 0x06001471 RID: 5233 RVA: 0x0009C7C4 File Offset: 0x0009A9C4
	protected internal bool #=zt$EpC6LMXeRk()
	{
		return this.#=z790jx38=;
	}

	// Token: 0x04000BAA RID: 2986
	private #=zoImewjUBfkPyF1oU_G4atTk= #=z0xdP5aY=;

	// Token: 0x04000BAB RID: 2987
	private bool #=zJ97IZ1IwBsnR;

	// Token: 0x04000BAC RID: 2988
	private bool #=z790jx38=;
}
