﻿using System;
using NExcel.Biff;

// Token: 0x02000089 RID: 137
internal sealed class #=z76qtqmSRL$vZ0XZJUc$PDB0= : WritableRecordData
{
	// Token: 0x060003B5 RID: 949 RVA: 0x000210DC File Offset: 0x0001F2DC
	public #=z76qtqmSRL$vZ0XZJUc$PDB0=(int #=zHJlGRZNRnALY, int #=zrGmcQXo=) : base(Type.STYLE)
	{
		this.#=zJqpM8PY= = #=zHJlGRZNRnALY;
		this.#=zVNnRefwlW$xD = #=zrGmcQXo=;
	}

	// Token: 0x060003B6 RID: 950 RVA: 0x000210F8 File Offset: 0x0001F2F8
	public override sbyte[] getData()
	{
		sbyte[] array = new sbyte[4];
		IntegerHelper.getTwoBytes(this.#=zJqpM8PY=, array, 0);
		sbyte[] array2 = array;
		int num = 1;
		array2[num] |= sbyte.MinValue;
		array[2] = (sbyte)this.#=zVNnRefwlW$xD;
		array[3] = -1;
		return array;
	}

	// Token: 0x0400014D RID: 333
	private int #=zJqpM8PY=;

	// Token: 0x0400014E RID: 334
	private int #=zVNnRefwlW$xD;
}
