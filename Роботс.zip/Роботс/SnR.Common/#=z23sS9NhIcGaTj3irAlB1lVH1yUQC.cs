﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.UserMeta;

// Token: 0x02000043 RID: 67
internal sealed class #=z23sS9NhIcGaTj3irAlB1lVH1yUQC : List<Task>
{
	// Token: 0x0600021B RID: 539 RVA: 0x00014D40 File Offset: 0x00012F40
	public #=z23sS9NhIcGaTj3irAlB1lVH1yUQC(bool #=zXax54lzEowMN)
	{
		this.#=zyZjP5ISUBvqKAkowJA==(#=zXax54lzEowMN);
		this.#=z0rhCzVKmQNwL(SessionProcessStates.Idle);
		this.#=zBCxv0_Eazs01 = new object();
	}

	// Token: 0x0600021C RID: 540 RVA: 0x00014D64 File Offset: 0x00012F64
	public bool #=zU3NiAfDQweme8jKsqw==()
	{
		return this.#=zmjXMcO1hY409GOjLGX52HdQ=;
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00014D6C File Offset: 0x00012F6C
	public void #=zyZjP5ISUBvqKAkowJA==(bool #=z$Ib9gYQ=)
	{
		this.#=zmjXMcO1hY409GOjLGX52HdQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600021E RID: 542 RVA: 0x00014D78 File Offset: 0x00012F78
	public SessionProcessStates #=z3MeIeP8$C0ue()
	{
		if (this.#=zI74wVSbojj8r == SessionProcessStates.Processing && DateTime.Now >= this.#=z9EGZo7e$cc0T)
		{
			bool flag = false;
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].State == TaskStates.Running)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				this.#=zI74wVSbojj8r = SessionProcessStates.Idle;
				throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908875173));
			}
			this.#=z9EGZo7e$cc0T = DateTime.Now + TimeSpan.FromMinutes(15.0);
		}
		return this.#=zI74wVSbojj8r;
	}

	// Token: 0x0600021F RID: 543 RVA: 0x00014E04 File Offset: 0x00013004
	public void #=z0rhCzVKmQNwL(SessionProcessStates #=z$Ib9gYQ=)
	{
		this.#=zI74wVSbojj8r = #=z$Ib9gYQ=;
		if (#=z$Ib9gYQ= == SessionProcessStates.Processing)
		{
			this.#=z9EGZo7e$cc0T = DateTime.Now + TimeSpan.FromMinutes(60.0);
		}
	}

	// Token: 0x06000220 RID: 544 RVA: 0x00014E30 File Offset: 0x00013030
	public Task #=zEh7CJ2RYceMs(TaskTypes #=zvRLj9WQ=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].Type == #=zvRLj9WQ=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x06000221 RID: 545 RVA: 0x00014E68 File Offset: 0x00013068
	public Task #=zEh7CJ2RYceMs(TaskSendUnitTypes #=zvRLj9WQ=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			Task task = base[i];
			if (task is #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw== && (task as #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==).#=zeWSpwqqtMyd5() == #=zvRLj9WQ=)
			{
				return task;
			}
		}
		return null;
	}

	// Token: 0x06000222 RID: 546 RVA: 0x00014EA8 File Offset: 0x000130A8
	public string #=zhv7OhlM=()
	{
		object[] array = new object[base.Count];
		for (int i = base.Count - 1; i >= 0; i--)
		{
			array[i] = base[i].Serialize();
		}
		return JSONManager.SerializeData(array).Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873400), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051212) + Environment.NewLine + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873390));
	}

	// Token: 0x040000A0 RID: 160
	private bool #=zmjXMcO1hY409GOjLGX52HdQ=;

	// Token: 0x040000A1 RID: 161
	private SessionProcessStates #=zI74wVSbojj8r;

	// Token: 0x040000A2 RID: 162
	private DateTime #=z9EGZo7e$cc0T;

	// Token: 0x040000A3 RID: 163
	public object #=zBCxv0_Eazs01;
}
