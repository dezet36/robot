﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography;
using System.Threading;
using Skink.SnR.Common.Managers;

// Token: 0x020000F6 RID: 246
[SuppressUnmanagedCodeSecurity]
internal static class #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==
{
	// Token: 0x06000667 RID: 1639 RVA: 0x00033514 File Offset: 0x00031714
	static #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==()
	{
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zMMidYLAvrHgUiSQcHQ== = File.Exists(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938503));
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zzOWUhRjxiZC8 = Process.GetCurrentProcess().Handle;
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zys2VCrha6kj_ = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z1R6nt6WKgk38<#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zKxrbha_JCHXLDeDneA==>(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928961));
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zyjVhSKGYHsZc8_AgNQ== = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z1R6nt6WKgk38<#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z$ADOioTpgnNmHwGbXQ==>(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928929));
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zvvtYJ$6f5s7_();
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zVRWoYsUmljkPPhq02Cnjs$Q= = new Thread(new ThreadStart(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zhHsHKNttR_PA))
		{
			IsBackground = true,
			Priority = ThreadPriority.Highest
		};
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zVRWoYsUmljkPPhq02Cnjs$Q=.Start();
	}

	// Token: 0x06000668 RID: 1640
	[DllImport("kernel32.dll", EntryPoint = "IsDebuggerPresent")]
	private static extern bool #=zNtv3wQmBzzh4();

	// Token: 0x06000669 RID: 1641
	[DllImport("kernel32.dll", EntryPoint = "CheckRemoteDebuggerPresent")]
	private static extern bool #=z8iCUW4kKqijUAjBI3A==(IntPtr #=zPwsOQIs=, ref bool #=zFbXYoDwa2faE);

	// Token: 0x0600066A RID: 1642
	[DllImport("kernel32.dll", EntryPoint = "GetCurrentThread")]
	private static extern IntPtr #=zgzCOQFY6Z3Zw();

	// Token: 0x0600066B RID: 1643
	[DllImport("kernel32.dll", EntryPoint = "GetModuleHandle")]
	private static extern IntPtr #=zV68ZMNWEVu6m(string #=zsLjdoU4QAu30);

	// Token: 0x0600066C RID: 1644
	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress", ExactSpelling = true)]
	private static extern IntPtr #=zOi1O9f3pQiCE(IntPtr #=zU5FT7mQ=, string #=zcsBdrtE=);

	// Token: 0x0600066D RID: 1645
	[DllImport("kernel32.dll", EntryPoint = "LoadLibraryEx", SetLastError = true)]
	private static extern IntPtr #=zvUZ6jnn2ZBHC(string #=z4ypZQ0Owlu2O, IntPtr #=zS9WRPaDqmBwG, uint #=zbYBHCz8=);

	// Token: 0x0600066E RID: 1646 RVA: 0x000335D8 File Offset: 0x000317D8
	public static void #=z1jlGMrg=()
	{
		if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zMMidYLAvrHgUiSQcHQ== && JSONManager.GetConfigValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928898)) == #=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==.#=zYhB1CCJa0Gd_())
		{
			return;
		}
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zvvtYJ$6f5s7_();
		int num = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zk0HdSGfrU2SM();
		if (num > 0)
		{
			#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928626) + num.ToString());
		}
		if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zmAJmx_IcczsZ())
		{
			#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928594));
		}
		if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z8O$P$5I6zXhn.ElapsedMilliseconds % 3000L < 100L)
		{
			if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zH4cEmLWoJBfcAEzTRc12OKs=())
			{
				#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928562));
			}
			int num2 = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z4GGKh35EQE6L();
			if (num2 > 0)
			{
				#=zh_fJw6oiO_jk5oIs4tXPK_UlGB0C.#=zIhEoTo0tDwFVzyvxnw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928530) + num2.ToString());
			}
		}
	}

	// Token: 0x0600066F RID: 1647 RVA: 0x0003369C File Offset: 0x0003189C
	private static void #=zhHsHKNttR_PA()
	{
		while (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zXmlH9E9XjwTZ)
		{
			#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z1jlGMrg=();
			Thread.Sleep(500);
		}
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x000336B8 File Offset: 0x000318B8
	private static int #=zk0HdSGfrU2SM()
	{
		int result;
		try
		{
			if (Debugger.IsAttached)
			{
				result = 1;
			}
			else if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zNtv3wQmBzzh4())
			{
				result = 2;
			}
			else
			{
				bool flag = false;
				if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z8iCUW4kKqijUAjBI3A==(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zzOWUhRjxiZC8, ref flag) && flag)
				{
					result = 3;
				}
				else
				{
					result = 0;
				}
			}
		}
		catch
		{
			result = 0;
		}
		return result;
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x0003370C File Offset: 0x0003190C
	private static bool #=zmAJmx_IcczsZ()
	{
		bool result;
		try
		{
			IntPtr zero = IntPtr.Zero;
			int num = 0;
			result = (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zys2VCrha6kj_(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zzOWUhRjxiZC8, 7, ref zero, IntPtr.Size, ref num) == (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z9E79EvU=)0U && zero != IntPtr.Zero);
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x00033764 File Offset: 0x00031964
	private static void #=zvvtYJ$6f5s7_()
	{
		try
		{
			#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zyjVhSKGYHsZc8_AgNQ==(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zgzCOQFY6Z3Zw(), 17U, IntPtr.Zero, 0U);
		}
		catch
		{
		}
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x000337A0 File Offset: 0x000319A0
	private static bool #=zrWQGqYS_C8r_()
	{
		Stopwatch stopwatch = Stopwatch.StartNew();
		double num = 0.0;
		for (int i = 0; i < 1000; i++)
		{
			num += Math.Sqrt((double)i);
		}
		stopwatch.Stop();
		return stopwatch.ElapsedMilliseconds > 100L;
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x000337E8 File Offset: 0x000319E8
	private static bool #=zH4cEmLWoJBfcAEzTRc12OKs=()
	{
		bool result;
		try
		{
			byte[] array = new byte[64];
			#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zCZTJUHq7ART$.Value.GetBytes(array);
			byte[] #=zyShZ9QI= = (byte[])array.Clone();
			result = !#=qKaO8sVjUVZt$pXjVq$Jyc3DeqwJFfbnmVjnePZ4XYyk=.#=zpRU7t58lATzJ(array, #=zyShZ9QI=);
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x0003383C File Offset: 0x00031A3C
	private static int #=z4GGKh35EQE6L()
	{
		int result;
		try
		{
			int num = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zBB8lR_csrPtT(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928754), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928961));
			if (num > 0)
			{
				result = 10 + num;
			}
			else
			{
				int num2 = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zBB8lR_csrPtT(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928738), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928721));
				if (num2 > 0)
				{
					result = 20 + num2;
				}
				else
				{
					result = 0;
				}
			}
		}
		catch
		{
			result = 0;
		}
		return result;
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x000338B0 File Offset: 0x00031AB0
	private static int #=zBB8lR_csrPtT(string #=z2eB_3x8=, string #=z3lUqbh8=)
	{
		IntPtr intPtr = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zOi1O9f3pQiCE(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zV68ZMNWEVu6m(#=z2eB_3x8=), #=z3lUqbh8=);
		if (intPtr == IntPtr.Zero)
		{
			return 0;
		}
		byte[] array = new byte[10];
		Marshal.Copy(intPtr, array, 0, array.Length);
		if (array[0] == 233)
		{
			return 1;
		}
		if (array[0] == 204)
		{
			return 2;
		}
		return 0;
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x00033908 File Offset: 0x00031B08
	private static bool #=zwebbr3UKs2sZ()
	{
		DateTime now = DateTime.Now;
		if (#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zClIAfhKCjujeJ46ecg== != DateTime.MinValue && (now - #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zClIAfhKCjujeJ46ecg==).TotalMilliseconds > 60000.0)
		{
			return true;
		}
		#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zClIAfhKCjujeJ46ecg== = now;
		return false;
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x00033954 File Offset: 0x00031B54
	private static T #=z1R6nt6WKgk38<T>(string #=zYICS0Uc=) where T : Delegate
	{
		T delegateForFunctionPointer;
		try
		{
			IntPtr intPtr = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zvUZ6jnn2ZBHC(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928697), IntPtr.Zero, 2U);
			if (intPtr == IntPtr.Zero)
			{
				throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928669));
			}
			IntPtr intPtr2 = #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zOi1O9f3pQiCE(intPtr, #=zYICS0Uc=);
			if (intPtr2 == IntPtr.Zero)
			{
				throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928376));
			}
			delegateForFunctionPointer = Marshal.GetDelegateForFunctionPointer<T>(intPtr2);
		}
		catch
		{
			delegateForFunctionPointer = Marshal.GetDelegateForFunctionPointer<T>(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zOi1O9f3pQiCE(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zV68ZMNWEVu6m(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928754)), #=zYICS0Uc=));
		}
		return delegateForFunctionPointer;
	}

	// Token: 0x040002A9 RID: 681
	private static readonly ThreadLocal<RandomNumberGenerator> #=zCZTJUHq7ART$ = new ThreadLocal<RandomNumberGenerator>(new Func<RandomNumberGenerator>(#=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zyDNvciU=.#=zLkw0NRU=.#=z4sRh8_zMZv0NN_XXIr09iPU=));

	// Token: 0x040002AA RID: 682
	private static readonly #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zKxrbha_JCHXLDeDneA== #=zys2VCrha6kj_;

	// Token: 0x040002AB RID: 683
	private static readonly #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z$ADOioTpgnNmHwGbXQ== #=zyjVhSKGYHsZc8_AgNQ==;

	// Token: 0x040002AC RID: 684
	private static readonly IntPtr #=zzOWUhRjxiZC8;

	// Token: 0x040002AD RID: 685
	private static readonly Thread #=zVRWoYsUmljkPPhq02Cnjs$Q=;

	// Token: 0x040002AE RID: 686
	private static volatile bool #=zXmlH9E9XjwTZ = true;

	// Token: 0x040002AF RID: 687
	private static readonly Stopwatch #=z8O$P$5I6zXhn = Stopwatch.StartNew();

	// Token: 0x040002B0 RID: 688
	private static readonly bool #=zMMidYLAvrHgUiSQcHQ==;

	// Token: 0x040002B1 RID: 689
	private static DateTime #=zClIAfhKCjujeJ46ecg== = DateTime.MinValue;

	// Token: 0x020000F7 RID: 247
	// (Invoke) Token: 0x0600067A RID: 1658
	private delegate uint #=z$ADOioTpgnNmHwGbXQ==(IntPtr #=zaynZgkUIUZfJ, uint #=zIlBC$KvGvmyG, IntPtr #=z3TIgVU8tNMTU, uint #=zHEz3AGsRofVU);

	// Token: 0x020000F8 RID: 248
	private enum #=z9E79EvU= : uint
	{

	}

	// Token: 0x020000F9 RID: 249
	// (Invoke) Token: 0x0600067E RID: 1662
	private delegate #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=z9E79EvU= #=zKxrbha_JCHXLDeDneA==(IntPtr #=zPwsOQIs=, int #=zTX6NlbAbIOkC, ref IntPtr #=zAUFAbUmxioKO, int #=ztYWTZMd19S5L, ref int #=z75Y0UPnSluSu);

	// Token: 0x020000FA RID: 250
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000683 RID: 1667 RVA: 0x00033A04 File Offset: 0x00031C04
		internal RandomNumberGenerator #=z4sRh8_zMZv0NN_XXIr09iPU=()
		{
			return RandomNumberGenerator.Create();
		}

		// Token: 0x040002B3 RID: 691
		public static readonly #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zyDNvciU= #=zLkw0NRU= = new #=zGAy1znIhQXgPdMKWeunrR4sy42$nPvJE4A==.#=zyDNvciU=();
	}
}
