﻿using System;

// Token: 0x0200001A RID: 26
internal interface #=qkl7WnaOCeOKhJFzb$edIqFlt2A0QhwtR2xgkRCtivuY=<#=zm8PpuDU=> : #=qxk4jgf3to8ruOmZuuOvLr3hFRe30PTzVserGqAFsdyc=, #=qjU9y2YbXKDX9w$auN09jycq094j3zHKdw8gUC1HOqY4=
{
	// Token: 0x0600004E RID: 78
	#=zm8PpuDU= #=zRGzvFRPn8bJ9t1Tvjk6L$29zAc8YPrcXV_qXA_O5PDBquk65wTwHU61yY9$vh4FPEQ==();
}
