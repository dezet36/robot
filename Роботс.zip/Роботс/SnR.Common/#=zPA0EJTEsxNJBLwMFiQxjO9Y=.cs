﻿using System;
using System.Text;
using NExcel;
using NExcel.Biff;

// Token: 0x0200017B RID: 379
internal sealed class #=zPA0EJTEsxNJBLwMFiQxjO9Y= : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000AE3 RID: 2787 RVA: 0x00054918 File Offset: 0x00052B18
	public #=zPA0EJTEsxNJBLwMFiQxjO9Y=(WorkbookSettings #=z4JisLog=)
	{
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x00054928 File Offset: 0x00052B28
	public #=zPA0EJTEsxNJBLwMFiQxjO9Y=(string #=zWj7xLq8=)
	{
		this.#=zziO1gvU= = #=zWj7xLq8=;
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x00054938 File Offset: 0x00052B38
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[this.#=zziO1gvU=.Length * 2 + 3];
		array[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=z8ozxU5g=.#=zd$BbM3Y=();
		array[1] = (sbyte)this.#=zziO1gvU=.Length;
		array[2] = 1;
		StringHelper.getUnicodeBytes(this.#=zziO1gvU=, array, 3);
		return array;
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x00054988 File Offset: 0x00052B88
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		int num = (int)#=zJ5GWysk=[#=z4J_G3VM=];
		int num2 = 2;
		if ((#=zJ5GWysk=[#=z4J_G3VM= + 1] & 1) == 0)
		{
			this.#=zziO1gvU= = StringHelper.getString(#=zJ5GWysk=, num, #=z4J_G3VM= + 2, this.#=z6bRJXNQ=);
			num2 += num;
		}
		else
		{
			this.#=zziO1gvU= = StringHelper.getUnicodeString(#=zJ5GWysk=, num, #=z4J_G3VM= + 2);
			num2 += num * 2;
		}
		return num2;
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x000549D8 File Offset: 0x00052BD8
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		#=zXvwCnz8=.Append('"');
		#=zXvwCnz8=.Append(this.#=zziO1gvU=);
		#=zXvwCnz8=.Append('"');
	}

	// Token: 0x040005D2 RID: 1490
	private string #=zziO1gvU=;

	// Token: 0x040005D3 RID: 1491
	private WorkbookSettings #=z6bRJXNQ=;
}
