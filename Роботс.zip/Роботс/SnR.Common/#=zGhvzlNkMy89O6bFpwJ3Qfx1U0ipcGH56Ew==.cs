﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Interface;
using Skink.SnR.Common.Managers;

// Token: 0x02000101 RID: 257
internal sealed partial class #=zGhvzlNkMy89O6bFpwJ3Qfx1U0ipcGH56Ew== : Form
{
	// Token: 0x060006B0 RID: 1712 RVA: 0x00036714 File Offset: 0x00034914
	public #=zGhvzlNkMy89O6bFpwJ3Qfx1U0ipcGH56Ew==(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=)
	{
		this.#=zgpzgXirqPT5_();
		if (GameApplicationData.#=zMD9IS3VDVH4f() < 2)
		{
			this.#=zyOh81vGXmDSr1fHzng==.Columns[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112219)].Visible = false;
		}
		if (GameApplicationData.#=zMD9IS3VDVH4f() < 3)
		{
			this.#=zyOh81vGXmDSr1fHzng==.Columns[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112207)].Visible = false;
		}
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=zYKZmRVh6DmCqqKkQZA== = new AccountControlInfoCollection();
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8= in this.#=zshVEGQI=.#=zOdy_aU_tk1aY())
		{
			this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=(#=zhoOF5s8=);
		}
		this.#=zvTYRhZxdEfEx = (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zmWSq0sTYcJfLLSlbyQ==() ? #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zuz_M2jEYZbqf() : int.MaxValue);
		if (this.#=zshVEGQI=.#=zOdy_aU_tk1aY().Count < this.#=zvTYRhZxdEfEx)
		{
			this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=();
		}
		this.#=z8XTfQgz8EgWO = false;
		this.#=zyOh81vGXmDSr1fHzng==.AutoGenerateColumns = false;
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
		#=zNsQzXeoabEMVlUX_4E_fU_Vvrj_cEVZgRg==.#=zcBW$PBE=(this.#=zyOh81vGXmDSr1fHzng==, new string[]
		{
			#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111176)
		});
		this.#=zX0RpEROCT1P5L5qCFQ==.Checked = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z97Z7CxekCb4f();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x0003688C File Offset: 0x00034A8C
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zjg9CGODqQRqZ(this.#=zX0RpEROCT1P5L5qCFQ==.Checked);
			List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==> list = new List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==>();
			foreach (AccountControlInfo accountControlInfo in this.#=zYKZmRVh6DmCqqKkQZA==)
			{
				if (!string.IsNullOrEmpty(accountControlInfo.Login))
				{
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== = new #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==();
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=ze8TQhOAtefck(accountControlInfo.Login);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuKcwTqrq7yWC(accountControlInfo.Password);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z0yzdXaRNk7l4(accountControlInfo.UserName);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=znJq9SDhBSPImQwwzNw==(accountControlInfo.IsUse1stServer);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zpCXbWGwIG26C0pyQVA==(accountControlInfo.IsUse2ndServer);
					#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zbptKj70_nY72H4iMaw==(accountControlInfo.IsUse3rdServer);
					list.Add(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==);
				}
			}
			bool #=zwMbodNUH47FNsb_gIw== = false;
			if (this.#=z8XTfQgz8EgWO && !#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zmWSq0sTYcJfLLSlbyQ==() && #=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111923), MessageBoxButtons.YesNo, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111904), Array.Empty<object>()) == DialogResult.Yes)
			{
				#=zwMbodNUH47FNsb_gIw== = true;
			}
			this.#=zshVEGQI=.#=z0ZcCdTI=(list, #=zwMbodNUH47FNsb_gIw==);
			base.Close();
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zELdlHynwcS2l(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111813), new object[]
			{
				#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
			});
		}
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x000369D8 File Offset: 0x00034BD8
	private string #=z4095DMHUMLeZ(int #=zMcBvqbE=)
	{
		if (#=zMcBvqbE= >= 0 && #=zMcBvqbE= < this.#=zyOh81vGXmDSr1fHzng==.Columns.Count)
		{
			return this.#=zyOh81vGXmDSr1fHzng==.Columns[#=zMcBvqbE=].Name;
		}
		return null;
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x00036A0C File Offset: 0x00034C0C
	private void #=zyIQKhWcHE2BS()
	{
		if (this.#=zYKZmRVh6DmCqqKkQZA==.Count > 0)
		{
			if (!string.IsNullOrEmpty(this.#=zYKZmRVh6DmCqqKkQZA==[this.#=zYKZmRVh6DmCqqKkQZA==.Count - 1].Login) && this.#=zYKZmRVh6DmCqqKkQZA==.Count < this.#=zvTYRhZxdEfEx)
			{
				this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=();
				this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
				this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
				return;
			}
		}
		else
		{
			this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=();
			this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
			this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
		}
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x00036AB0 File Offset: 0x00034CB0
	private void #=zc4froDOSW6u9u5p4SXg_Ww8=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex >= 0 && #=z4Q$h3mE=.ColumnIndex < this.#=zyOh81vGXmDSr1fHzng==.Columns.Count && #=z4Q$h3mE=.RowIndex >= 0 && #=z4Q$h3mE=.RowIndex < this.#=zyOh81vGXmDSr1fHzng==.Rows.Count && this.#=z4095DMHUMLeZ(#=z4Q$h3mE=.ColumnIndex) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312))
		{
			this.#=zyIQKhWcHE2BS();
			return;
		}
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x00036B24 File Offset: 0x00034D24
	private void #=z5I5Z9ugnX33_cicMOIy1YIY=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (this.#=z4095DMHUMLeZ(#=z4Q$h3mE=.ColumnIndex) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112040) && #=z4Q$h3mE=.RowIndex >= 0 && #=z4Q$h3mE=.RowIndex < this.#=zYKZmRVh6DmCqqKkQZA==.Count)
		{
			this.#=zYKZmRVh6DmCqqKkQZA==.RemoveAt(#=z4Q$h3mE=.RowIndex);
			this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
			this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
			this.#=zyIQKhWcHE2BS();
			this.#=z8XTfQgz8EgWO = true;
		}
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x00036BA8 File Offset: 0x00034DA8
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x00036BB0 File Offset: 0x00034DB0
	private void #=zbK7Cl2Mq19fnd7Rzlb4bHoo=(object #=zP95I7AY=, ScrollEventArgs #=z4Q$h3mE=)
	{
	}

	// Token: 0x060006B8 RID: 1720 RVA: 0x00036BB4 File Offset: 0x00034DB4
	private void #=zutfjX2q6J$5jSj8iAiVcyao=(object #=zP95I7AY=, MouseEventArgs #=z4Q$h3mE=)
	{
	}

	// Token: 0x060006B9 RID: 1721 RVA: 0x00036BB8 File Offset: 0x00034DB8
	private void #=zmktfc2uUe0ln(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string value = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051860);
		bool flag = false;
		stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111277)));
		stringBuilder.Append(value);
		stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111195)));
		stringBuilder.Append(value);
		stringBuilder.Append(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246)));
		for (int i = 1; i <= GameApplicationData.#=zMD9IS3VDVH4f(); i++)
		{
			stringBuilder.Append(value);
			stringBuilder.Append(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.#=zJHLHKso=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112031), new object[]
			{
				i
			}));
		}
		for (int j = 0; j < this.#=zYKZmRVh6DmCqqKkQZA==.Count; j++)
		{
			AccountControlInfo accountControlInfo = this.#=zYKZmRVh6DmCqqKkQZA==[j];
			if (!string.IsNullOrEmpty(accountControlInfo.Login))
			{
				stringBuilder.Append(Environment.NewLine);
				stringBuilder.Append(accountControlInfo.Login);
				stringBuilder.Append(value);
				stringBuilder.Append(accountControlInfo.Password);
				stringBuilder.Append(value);
				stringBuilder.Append(accountControlInfo.UserName);
				stringBuilder.Append(value);
				stringBuilder.Append(accountControlInfo.IsUse1stServer ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871));
				if (GameApplicationData.#=zMD9IS3VDVH4f() >= 2)
				{
					stringBuilder.Append(value);
					stringBuilder.Append(accountControlInfo.IsUse2ndServer ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871));
				}
				if (GameApplicationData.#=zMD9IS3VDVH4f() >= 3)
				{
					stringBuilder.Append(value);
					stringBuilder.Append(accountControlInfo.IsUse3rdServer ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909079871));
				}
				flag = true;
			}
		}
		if (flag)
		{
			Clipboard.SetText(stringBuilder.ToString());
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109500));
		}
	}

	// Token: 0x060006BA RID: 1722 RVA: 0x00036DA4 File Offset: 0x00034FA4
	private void #=zG2PMbSRZYcAZ(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (this.#=zLvEAOsFNsXhd.ShowDialog() == DialogResult.OK)
			{
				if (Path.GetExtension(this.#=zLvEAOsFNsXhd.FileName) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112001))
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111997));
				}
				else
				{
					string[][] array;
					if (Path.GetExtension(this.#=zLvEAOsFNsXhd.FileName) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111602))
					{
						#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==;
						array = ReadFileManager.#=zIw_gdos=(this.#=zLvEAOsFNsXhd.FileName, null, out #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
						if (#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== != null)
						{
							throw new Exception(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==.ToString());
						}
					}
					else
					{
						array = ReadFileManager.ReadText(this.#=zLvEAOsFNsXhd.FileName);
					}
					List<char> list = new List<char>
					{
						'y',
						'1',
						'+',
						'v',
						'x',
						'*'
					};
					List<string> list2 = new List<string>();
					foreach (AccountControlInfo accountControlInfo in this.#=zYKZmRVh6DmCqqKkQZA==)
					{
						if (!string.IsNullOrEmpty(accountControlInfo.Login))
						{
							string login = accountControlInfo.Login;
							list2.Add(login);
						}
					}
					List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==> list3 = new List<#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==>();
					for (int i = 1; i < array.Length; i++)
					{
						string[] array2 = array[i];
						if (array2.Length >= 2)
						{
							#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== = new #=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==();
							int num = 0;
							if (!string.IsNullOrEmpty(array2[num]))
							{
								#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=ze8TQhOAtefck(array2[num]);
								num++;
								if (array2.Length > num)
								{
									#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zuKcwTqrq7yWC(array2[num]);
									num++;
									if (array2.Length > num)
									{
										#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=z0yzdXaRNk7l4(array2[num]);
										num++;
										if (array2.Length > num)
										{
											if (!string.IsNullOrEmpty(array2[num]))
											{
												#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=znJq9SDhBSPImQwwzNw==(list.Contains(array2[num].ToLower()[0]));
											}
											num++;
										}
										if (array2.Length > num)
										{
											if (!string.IsNullOrEmpty(array2[num]))
											{
												#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zpCXbWGwIG26C0pyQVA==(list.Contains(array2[num].ToLower()[0]));
											}
											num++;
										}
										if (array2.Length > num)
										{
											if (!string.IsNullOrEmpty(array2[num]))
											{
												#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zbptKj70_nY72H4iMaw==(list.Contains(array2[num].ToLower()[0]));
											}
											num++;
										}
										if (!list2.Contains(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==.#=zCCvotbi$42tS()))
										{
											list3.Add(#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A==);
										}
									}
								}
							}
						}
					}
					if (list3.Count > 0)
					{
						if (this.#=zYKZmRVh6DmCqqKkQZA==.Count > 0 && string.IsNullOrEmpty(this.#=zYKZmRVh6DmCqqKkQZA==[this.#=zYKZmRVh6DmCqqKkQZA==.Count - 1].Login))
						{
							this.#=zYKZmRVh6DmCqqKkQZA==.RemoveAt(this.#=zYKZmRVh6DmCqqKkQZA==.Count - 1);
						}
						int num2 = 0;
						bool flag = false;
						foreach (#=zvhenNKUBRLOWhkt4jJGtm3d5q$lT7fy91A== #=zhoOF5s8= in list3)
						{
							if (this.#=zYKZmRVh6DmCqqKkQZA==.Count >= this.#=zvTYRhZxdEfEx)
							{
								flag = true;
								break;
							}
							this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=(#=zhoOF5s8=);
							num2++;
						}
						if (this.#=zYKZmRVh6DmCqqKkQZA==.Count < this.#=zvTYRhZxdEfEx)
						{
							this.#=zYKZmRVh6DmCqqKkQZA==.#=z48rEd0A=();
						}
						this.#=zyIQKhWcHE2BS();
						this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
						this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
						if (flag)
						{
							#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zELdlHynwcS2l(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111593), new object[]
							{
								num2
							});
						}
						else
						{
							#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zELdlHynwcS2l(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111757), new object[]
							{
								num2
							});
						}
					}
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x00037194 File Offset: 0x00035394
	private void #=z3n6THx8VQoBD(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		for (int i = this.#=zYKZmRVh6DmCqqKkQZA==.Count - 1; i >= 0; i--)
		{
			if (this.#=zYKZmRVh6DmCqqKkQZA==[i].IsSelected)
			{
				this.#=zYKZmRVh6DmCqqKkQZA==.RemoveAt(i);
			}
		}
		this.#=zyIQKhWcHE2BS();
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = null;
		this.#=zyOh81vGXmDSr1fHzng==.DataSource = this.#=zYKZmRVh6DmCqqKkQZA==;
		this.#=z8XTfQgz8EgWO = true;
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x00037204 File Offset: 0x00035404
	private void #=zprhCO59Jy9QXVEDd8A470oQ=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			new #=zSNdnBbgBbemn2TWRhaiTtXSJ0Y56bC2oRg==(this.#=zshVEGQI=).ShowDialog();
			base.Close();
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x00037248 File Offset: 0x00035448
	private void #=zUgWxOboJAcHxbN2XkA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111724), MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111708), Array.Empty<object>()) == DialogResult.OK)
		{
			#=z562Yn4bthBB8SZz_OKI7hATuvlyS$8gEnw==.#=z6i3mHuw=();
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111530));
			base.Close();
		}
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x000372A8 File Offset: 0x000354A8
	private void #=zgpzgXirqPT5_()
	{
		this.#=zuCaP$Fc= = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=zyOh81vGXmDSr1fHzng== = new DataGridView();
		this.#=zLjL0Bis= = new DataGridViewCheckBoxColumn();
		this.#=zby0EO0k= = new DataGridViewButtonColumn();
		this.#=zLQCfoJg= = new DataGridViewTextBoxColumn();
		this.#=zAfDv7ow= = new DataGridViewTextBoxColumn();
		this.#=zrAvVh3s= = new DataGridViewTextBoxColumn();
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=zlrMkWSbgth8Z = new DataGridViewCheckBoxColumn();
		this.#=zLAZiH5zub0PP = new DataGridViewCheckBoxColumn();
		this.#=zACJ8R44nK5m4 = new DataGridViewCheckBoxColumn();
		this.#=zz7L_8T4= = new Button();
		this.#=zGDK_Uh0= = new Button();
		this.#=zLvEAOsFNsXhd = new OpenFileDialog();
		this.#=zLDu$6_lzAAUC = new SaveFileDialog();
		this.#=zjzI5Sc4= = new Button();
		this.#=zTq4MXFUvBrbzue8IKw== = new Button();
		this.#=z7OA6UzQRKNaKGd04JYzrusA= = new SplitContainer();
		this.#=zvZ4t4YwwgBIa = new Button();
		this.#=zX0RpEROCT1P5L5qCFQ== = new CheckBox();
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).BeginInit();
		((ISupportInitialize)this.#=z7OA6UzQRKNaKGd04JYzrusA=).BeginInit();
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel1.SuspendLayout();
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.SuspendLayout();
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.SuspendLayout();
		base.SuspendLayout();
		this.#=zuCaP$Fc=.Location = new Point(62, 32);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(75, 23);
		this.#=zuCaP$Fc=.TabIndex = 4;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051773);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		this.#=zHeAVXAs=.Location = new Point(198, 32);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(75, 23);
		this.#=zHeAVXAs=.TabIndex = 5;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zyOh81vGXmDSr1fHzng==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zyOh81vGXmDSr1fHzng==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zLjL0Bis=,
			this.#=zby0EO0k=,
			this.#=zLQCfoJg=,
			this.#=zAfDv7ow=,
			this.#=zrAvVh3s=,
			this.#=zO0jJkos=,
			this.#=zlrMkWSbgth8Z,
			this.#=zLAZiH5zub0PP,
			this.#=zACJ8R44nK5m4
		});
		this.#=zyOh81vGXmDSr1fHzng==.Dock = DockStyle.Fill;
		this.#=zyOh81vGXmDSr1fHzng==.EditMode = DataGridViewEditMode.EditOnEnter;
		this.#=zyOh81vGXmDSr1fHzng==.Location = new Point(0, 0);
		this.#=zyOh81vGXmDSr1fHzng==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111099);
		this.#=zyOh81vGXmDSr1fHzng==.Size = new Size(829, 406);
		this.#=zyOh81vGXmDSr1fHzng==.TabIndex = 11;
		this.#=zyOh81vGXmDSr1fHzng==.CellClick += this.#=z5I5Z9ugnX33_cicMOIy1YIY=;
		this.#=zyOh81vGXmDSr1fHzng==.CellValueChanged += this.#=zc4froDOSW6u9u5p4SXg_Ww8=;
		this.#=zLjL0Bis=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113211);
		this.#=zLjL0Bis=.HeaderText = string.Empty;
		this.#=zLjL0Bis=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109696);
		this.#=zLjL0Bis=.Width = 30;
		this.#=zby0EO0k=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113192);
		this.#=zby0EO0k=.HeaderText = string.Empty;
		this.#=zby0EO0k=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112040);
		this.#=zby0EO0k=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051668);
		this.#=zby0EO0k=.Width = 70;
		this.#=zLQCfoJg=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111086);
		this.#=zLQCfoJg=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zLQCfoJg=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111054);
		this.#=zLQCfoJg=.ReadOnly = true;
		this.#=zLQCfoJg=.Resizable = DataGridViewTriState.True;
		this.#=zLQCfoJg=.SortMode = DataGridViewColumnSortMode.NotSortable;
		this.#=zLQCfoJg=.Width = 50;
		this.#=zAfDv7ow=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168);
		this.#=zAfDv7ow=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111277);
		this.#=zAfDv7ow=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909109312);
		this.#=zAfDv7ow=.Width = 150;
		this.#=zrAvVh3s=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111208);
		this.#=zrAvVh3s=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111195);
		this.#=zrAvVh3s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111176);
		this.#=zO0jJkos=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111263);
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.Width = 150;
		this.#=zlrMkWSbgth8Z.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113164);
		this.#=zlrMkWSbgth8Z.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113137);
		this.#=zlrMkWSbgth8Z.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113124);
		this.#=zlrMkWSbgth8Z.Width = 70;
		this.#=zLAZiH5zub0PP.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113096);
		this.#=zLAZiH5zub0PP.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113341);
		this.#=zLAZiH5zub0PP.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112219);
		this.#=zLAZiH5zub0PP.Width = 70;
		this.#=zACJ8R44nK5m4.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113312);
		this.#=zACJ8R44nK5m4.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113301);
		this.#=zACJ8R44nK5m4.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112207);
		this.#=zACJ8R44nK5m4.Width = 70;
		this.#=zz7L_8T4=.Location = new Point(279, 3);
		this.#=zz7L_8T4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110865);
		this.#=zz7L_8T4=.Size = new Size(75, 23);
		this.#=zz7L_8T4=.TabIndex = 7;
		this.#=zz7L_8T4=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909110852);
		this.#=zz7L_8T4=.UseVisualStyleBackColor = true;
		this.#=zz7L_8T4=.Click += this.#=zmktfc2uUe0ln;
		this.#=zGDK_Uh0=.Location = new Point(198, 3);
		this.#=zGDK_Uh0=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113272);
		this.#=zGDK_Uh0=.Size = new Size(75, 23);
		this.#=zGDK_Uh0=.TabIndex = 8;
		this.#=zGDK_Uh0=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113263);
		this.#=zGDK_Uh0=.UseVisualStyleBackColor = true;
		this.#=zGDK_Uh0=.Click += this.#=zG2PMbSRZYcAZ;
		this.#=zjzI5Sc4=.Location = new Point(3, 3);
		this.#=zjzI5Sc4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113246);
		this.#=zjzI5Sc4=.Size = new Size(134, 23);
		this.#=zjzI5Sc4=.TabIndex = 9;
		this.#=zjzI5Sc4=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113228);
		this.#=zjzI5Sc4=.UseVisualStyleBackColor = true;
		this.#=zjzI5Sc4=.Click += this.#=z3n6THx8VQoBD;
		this.#=zTq4MXFUvBrbzue8IKw==.Location = new Point(360, 28);
		this.#=zTq4MXFUvBrbzue8IKw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112948);
		this.#=zTq4MXFUvBrbzue8IKw==.Size = new Size(198, 23);
		this.#=zTq4MXFUvBrbzue8IKw==.TabIndex = 10;
		this.#=zTq4MXFUvBrbzue8IKw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112918);
		this.#=zTq4MXFUvBrbzue8IKw==.UseVisualStyleBackColor = true;
		this.#=zTq4MXFUvBrbzue8IKw==.Click += this.#=zprhCO59Jy9QXVEDd8A470oQ=;
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Dock = DockStyle.Fill;
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.FixedPanel = FixedPanel.Panel2;
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Location = new Point(0, 0);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112886);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Orientation = Orientation.Horizontal;
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel1.Controls.Add(this.#=zyOh81vGXmDSr1fHzng==);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zvZ4t4YwwgBIa);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zX0RpEROCT1P5L5qCFQ==);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zTq4MXFUvBrbzue8IKw==);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zuCaP$Fc=);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zz7L_8T4=);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zGDK_Uh0=);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.Controls.Add(this.#=zjzI5Sc4=);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Size = new Size(829, 473);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.SplitterDistance = 406;
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.TabIndex = 12;
		this.#=zvZ4t4YwwgBIa.Location = new Point(681, 3);
		this.#=zvZ4t4YwwgBIa.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112851);
		this.#=zvZ4t4YwwgBIa.Size = new Size(136, 23);
		this.#=zvZ4t4YwwgBIa.TabIndex = 12;
		this.#=zvZ4t4YwwgBIa.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113083);
		this.#=zvZ4t4YwwgBIa.UseVisualStyleBackColor = true;
		this.#=zvZ4t4YwwgBIa.Click += this.#=zUgWxOboJAcHxbN2XkA==;
		this.#=zX0RpEROCT1P5L5qCFQ==.AutoSize = true;
		this.#=zX0RpEROCT1P5L5qCFQ==.Location = new Point(360, 7);
		this.#=zX0RpEROCT1P5L5qCFQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113068);
		this.#=zX0RpEROCT1P5L5qCFQ==.Size = new Size(226, 17);
		this.#=zX0RpEROCT1P5L5qCFQ==.TabIndex = 11;
		this.#=zX0RpEROCT1P5L5qCFQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113035);
		this.#=zX0RpEROCT1P5L5qCFQ==.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(829, 473);
		base.Controls.Add(this.#=z7OA6UzQRKNaKGd04JYzrusA=);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112990);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112990);
		((ISupportInitialize)this.#=zyOh81vGXmDSr1fHzng==).EndInit();
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel1.ResumeLayout(false);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.ResumeLayout(false);
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.Panel2.PerformLayout();
		((ISupportInitialize)this.#=z7OA6UzQRKNaKGd04JYzrusA=).EndInit();
		this.#=z7OA6UzQRKNaKGd04JYzrusA=.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x040002EE RID: 750
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x040002EF RID: 751
	private AccountControlInfoCollection #=zYKZmRVh6DmCqqKkQZA==;

	// Token: 0x040002F0 RID: 752
	private int #=zvTYRhZxdEfEx;

	// Token: 0x040002F1 RID: 753
	private bool #=z8XTfQgz8EgWO;

	// Token: 0x040002F3 RID: 755
	private Button #=zuCaP$Fc=;

	// Token: 0x040002F4 RID: 756
	private Button #=zHeAVXAs=;

	// Token: 0x040002F5 RID: 757
	private Button #=zz7L_8T4=;

	// Token: 0x040002F6 RID: 758
	private Button #=zGDK_Uh0=;

	// Token: 0x040002F7 RID: 759
	private OpenFileDialog #=zLvEAOsFNsXhd;

	// Token: 0x040002F8 RID: 760
	private SaveFileDialog #=zLDu$6_lzAAUC;

	// Token: 0x040002F9 RID: 761
	private Button #=zjzI5Sc4=;

	// Token: 0x040002FA RID: 762
	private Button #=zTq4MXFUvBrbzue8IKw==;

	// Token: 0x040002FB RID: 763
	private DataGridView #=zyOh81vGXmDSr1fHzng==;

	// Token: 0x040002FC RID: 764
	private DataGridViewCheckBoxColumn #=zLjL0Bis=;

	// Token: 0x040002FD RID: 765
	private DataGridViewButtonColumn #=zby0EO0k=;

	// Token: 0x040002FE RID: 766
	private DataGridViewTextBoxColumn #=zLQCfoJg=;

	// Token: 0x040002FF RID: 767
	private DataGridViewTextBoxColumn #=zAfDv7ow=;

	// Token: 0x04000300 RID: 768
	private DataGridViewTextBoxColumn #=zrAvVh3s=;

	// Token: 0x04000301 RID: 769
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x04000302 RID: 770
	private DataGridViewCheckBoxColumn #=zlrMkWSbgth8Z;

	// Token: 0x04000303 RID: 771
	private DataGridViewCheckBoxColumn #=zLAZiH5zub0PP;

	// Token: 0x04000304 RID: 772
	private DataGridViewCheckBoxColumn #=zACJ8R44nK5m4;

	// Token: 0x04000305 RID: 773
	private SplitContainer #=z7OA6UzQRKNaKGd04JYzrusA=;

	// Token: 0x04000306 RID: 774
	private CheckBox #=zX0RpEROCT1P5L5qCFQ==;

	// Token: 0x04000307 RID: 775
	private Button #=zvZ4t4YwwgBIa;
}
