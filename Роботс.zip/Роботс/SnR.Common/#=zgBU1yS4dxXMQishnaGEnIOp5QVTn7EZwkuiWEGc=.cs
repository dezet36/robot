﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x02000243 RID: 579
internal sealed class #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc= : Task
{
	// Token: 0x060011A7 RID: 4519 RVA: 0x00089BD8 File Offset: 0x00087DD8
	public #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(TaskBlackMarketParams #=zHbX7HNM=, TaskSources #=zk656SlQ=, TaskSeverities #=z_qaYpFQ=, TaskTypes #=zvRLj9WQ=, DateTime #=zxSBcx18=, TimeSpan #=zKMZQB_CxkF$Q, TimeSpan #=zzqh5ZQa4EEuL, TimeSpan #=zJzGFjmMQUaxq, DateTime #=zYMNSoNFx5mMf, bool #=z0Vq2lE5$zejo) : base(#=zk656SlQ=, #=z_qaYpFQ=, #=zvRLj9WQ=, #=zxSBcx18=, #=zKMZQB_CxkF$Q, #=zzqh5ZQa4EEuL, #=zJzGFjmMQUaxq, #=zYMNSoNFx5mMf, #=z0Vq2lE5$zejo)
	{
		this.#=zZiTFAyhr4JrH(#=zHbX7HNM=);
		this.#=zHW1u6IS$tX7N(0);
		this.#=zEk_oTVpGYkjT(0.0);
	}

	// Token: 0x060011A8 RID: 4520 RVA: 0x00089C18 File Offset: 0x00087E18
	public #=zgBU1yS4dxXMQishnaGEnIOp5QVTn7EZwkuiWEGc=(Dictionary<string, object> #=z8e5z318=) : base(#=z8e5z318=)
	{
		this.#=z6ubHMavQ1YLP(#=z8e5z318=);
	}

	// Token: 0x060011A9 RID: 4521 RVA: 0x00089C28 File Offset: 0x00087E28
	public TaskBlackMarketParams #=zXFnsTSimqiPo()
	{
		return this.#=z8dYd_CCGyLaP3VCsNQ==;
	}

	// Token: 0x060011AA RID: 4522 RVA: 0x00089C30 File Offset: 0x00087E30
	public void #=zZiTFAyhr4JrH(TaskBlackMarketParams #=z$Ib9gYQ=)
	{
		this.#=z8dYd_CCGyLaP3VCsNQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011AB RID: 4523 RVA: 0x00089C3C File Offset: 0x00087E3C
	public int #=zr6zmRf3YG3UG()
	{
		return this.#=zwDdqzWERL1YJ1stKuBm3oQA=;
	}

	// Token: 0x060011AC RID: 4524 RVA: 0x00089C44 File Offset: 0x00087E44
	public void #=zHW1u6IS$tX7N(int #=z$Ib9gYQ=)
	{
		this.#=zwDdqzWERL1YJ1stKuBm3oQA= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011AD RID: 4525 RVA: 0x00089C50 File Offset: 0x00087E50
	public double #=zVJyJYuKV4nbu()
	{
		return this.#=zXo3SInqpE98l5qSk8pvWX$w=;
	}

	// Token: 0x060011AE RID: 4526 RVA: 0x00089C58 File Offset: 0x00087E58
	public void #=zEk_oTVpGYkjT(double #=z$Ib9gYQ=)
	{
		this.#=zXo3SInqpE98l5qSk8pvWX$w= = #=z$Ib9gYQ=;
	}

	// Token: 0x17000055 RID: 85
	// (get) Token: 0x060011AF RID: 4527 RVA: 0x00089C64 File Offset: 0x00087E64
	protected override string ClassName
	{
		get
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908874107);
		}
	}

	// Token: 0x060011B0 RID: 4528 RVA: 0x00089C70 File Offset: 0x00087E70
	private void #=z6ubHMavQ1YLP(Dictionary<string, object> #=z8e5z318=)
	{
		object[] array = JSONManager.ExtractArray(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873968));
		if (array != null)
		{
			int[] array2 = new int[array.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array2[i] = Convert.ToInt32(array[i]);
			}
			this.#=zZiTFAyhr4JrH(new TaskBlackMarketParams(array2, JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873965), 0) == 1, JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873948), 0), JSONManager.ExtractDouble(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873929), 0.0), JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873914), 0) == 1, JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873898), 0) == 1, JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873895), 0) == 1));
			this.#=zHW1u6IS$tX7N(JSONManager.ExtractInt(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873879), 0));
			this.#=zEk_oTVpGYkjT(JSONManager.ExtractDouble(#=z8e5z318=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873862), 0.0));
		}
	}

	// Token: 0x060011B1 RID: 4529 RVA: 0x00089D74 File Offset: 0x00087F74
	public override Dictionary<string, object> Serialize()
	{
		Dictionary<string, object> dictionary = base.Serialize();
		object[] array = new object[this.#=zXFnsTSimqiPo().AltItemTypeIds.Count + 1];
		array[0] = this.#=zXFnsTSimqiPo().ItemTypeId;
		for (int i = 0; i < this.#=zXFnsTSimqiPo().AltItemTypeIds.Count; i++)
		{
			array[i + 1] = this.#=zXFnsTSimqiPo().AltItemTypeIds[i];
		}
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873968)] = array;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873965)] = ((this.#=zXFnsTSimqiPo().IsUseEffect > false) ? 1 : 0);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873948)] = this.#=zXFnsTSimqiPo().Amount;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873929)] = this.#=zXFnsTSimqiPo().Effect;
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873914)] = ((this.#=zXFnsTSimqiPo().IsBuyAndUse > false) ? 1 : 0);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873898)] = ((this.#=zXFnsTSimqiPo().IsUseOneAtATime > false) ? 1 : 0);
		dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873895)] = ((this.#=zXFnsTSimqiPo().IsDontUsePartially > false) ? 1 : 0);
		if (this.#=zr6zmRf3YG3UG() > 0)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873879)] = this.#=zr6zmRf3YG3UG();
		}
		if (this.#=zVJyJYuKV4nbu() > 0.0)
		{
			dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908873862)] = this.#=zVJyJYuKV4nbu();
		}
		return dictionary;
	}

	// Token: 0x060011B2 RID: 4530 RVA: 0x00089F18 File Offset: 0x00088118
	internal void #=zXzFijdeUdQgj(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zHIedO$w=, int #=zNvCMwussKumm)
	{
		if (this.#=zXFnsTSimqiPo().IsUseEffect)
		{
			this.#=zEk_oTVpGYkjT(this.#=zVJyJYuKV4nbu() + #=zHIedO$w=.#=zjw43QGFcPyHH() * (double)#=zNvCMwussKumm);
			return;
		}
		this.#=zHW1u6IS$tX7N(this.#=zr6zmRf3YG3UG() + #=zNvCMwussKumm);
	}

	// Token: 0x040009E6 RID: 2534
	private TaskBlackMarketParams #=z8dYd_CCGyLaP3VCsNQ==;

	// Token: 0x040009E7 RID: 2535
	private int #=zwDdqzWERL1YJ1stKuBm3oQA=;

	// Token: 0x040009E8 RID: 2536
	private double #=zXo3SInqpE98l5qSk8pvWX$w=;
}
