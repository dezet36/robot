﻿using System;
using System.Collections;
using System.Text;
using NExcel.Biff;

// Token: 0x020001FA RID: 506
internal sealed class #=zaEU5e8fIH09jC12g2axA$gvvF8By : #=zsackb8N$OhpeUQLwxSU_3Lg=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000F97 RID: 3991 RVA: 0x0007A200 File Offset: 0x00078400
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		return null;
	}

	// Token: 0x06000F98 RID: 3992 RVA: 0x0007A204 File Offset: 0x00078404
	internal int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06000F99 RID: 3993 RVA: 0x0007A208 File Offset: 0x00078408
	public int #=zrHdsTiWu3oZX()
	{
		return this.#=z7HqoPh0=;
	}

	// Token: 0x06000F9A RID: 3994 RVA: 0x0007A210 File Offset: 0x00078410
	public void #=zLA7MgNl4ghKz(#=zoImewjUBfkPyF1oU_G4atTk=[] #=z$Ib9gYQ=)
	{
		this.#=zVuVJTas= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F9B RID: 3995 RVA: 0x0007A21C File Offset: 0x0007841C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=z7HqoPh0= = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM=], #=zJ5GWysk=[#=z4J_G3VM= + 1]);
		return 2;
	}

	// Token: 0x06000F9C RID: 3996 RVA: 0x0007A234 File Offset: 0x00078434
	public void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
	}

	// Token: 0x06000F9D RID: 3997 RVA: 0x0007A238 File Offset: 0x00078438
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		if (this.#=zVuVJTas=.Length == 1)
		{
			this.#=zVuVJTas=[0].#=zSpOkW5A=(#=zXvwCnz8=);
			return;
		}
		if (this.#=zVuVJTas=.Length == 2)
		{
			this.#=zVuVJTas=[1].#=zSpOkW5A=(#=zXvwCnz8=);
			#=zXvwCnz8=.Append(':');
			this.#=zVuVJTas=[0].#=zSpOkW5A=(#=zXvwCnz8=);
		}
	}

	// Token: 0x040008A5 RID: 2213
	private int #=z7HqoPh0=;

	// Token: 0x040008A6 RID: 2214
	private #=zoImewjUBfkPyF1oU_G4atTk=[] #=zVuVJTas=;
}
