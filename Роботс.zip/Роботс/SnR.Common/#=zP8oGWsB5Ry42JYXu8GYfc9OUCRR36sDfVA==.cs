﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000177 RID: 375
internal sealed class #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== : IDisposable
{
	// Token: 0x06000A10 RID: 2576 RVA: 0x000506F8 File Offset: 0x0004E8F8
	public #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==(#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, object #=zIRwPsGQY$M0r = null, string #=zRJiFeNQ= = null)
	{
		this.#=zXqKwUc4= = #=z8StzeqE=;
		this.#=zQmveeqwfZtWH = #=zG2wnL_q7IxpD;
		this.#=zpS65XT65S2pT = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(#=zG2wnL_q7IxpD);
		this.#=z9HdGFQI= = new Dictionary<string, object>();
		this.#=zskxfjcFDranQ(#=zRJiFeNQ=);
		this.#=zuQPTAKXcN0sT27WqTnSnZgI=(false);
		if (#=zIRwPsGQY$M0r != null)
		{
			this.#=zZEriZapMbvmY(#=zIRwPsGQY$M0r);
			return;
		}
		this.#=zZEriZapMbvmY(null);
	}

	// Token: 0x06000A11 RID: 2577 RVA: 0x00050754 File Offset: 0x0004E954
	public static string #=z_6EikM59XFqjHPXueA==()
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z5XRHUJ90tOjWip9hCDzQD_g=;
	}

	// Token: 0x06000A12 RID: 2578 RVA: 0x0005075C File Offset: 0x0004E95C
	public static void #=zBBdtOIwHrS6fN4w4iA==(string #=z$Ib9gYQ=)
	{
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z5XRHUJ90tOjWip9hCDzQD_g= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A13 RID: 2579 RVA: 0x00050764 File Offset: 0x0004E964
	public #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zQ4wZnctPyyRO()
	{
		return this.#=zXqKwUc4=;
	}

	// Token: 0x06000A14 RID: 2580 RVA: 0x0005076C File Offset: 0x0004E96C
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zI4J7zo5ZdOzg()
	{
		return this.#=zQmveeqwfZtWH;
	}

	// Token: 0x06000A15 RID: 2581 RVA: 0x00050774 File Offset: 0x0004E974
	public #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z$2ijYGRf0FB5()
	{
		return this.#=zpS65XT65S2pT;
	}

	// Token: 0x06000A16 RID: 2582 RVA: 0x0005077C File Offset: 0x0004E97C
	public bool #=zbhjPyxLDEPBD()
	{
		return this.#=zCCC3qqgZgmhw() != null;
	}

	// Token: 0x06000A17 RID: 2583 RVA: 0x00050788 File Offset: 0x0004E988
	private object #=zCCC3qqgZgmhw()
	{
		return this.#=zbvBtlZaWfruxOBtacPCk0Rk=;
	}

	// Token: 0x06000A18 RID: 2584 RVA: 0x00050790 File Offset: 0x0004E990
	private void #=zZEriZapMbvmY(object #=z$Ib9gYQ=)
	{
		this.#=zbvBtlZaWfruxOBtacPCk0Rk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A19 RID: 2585 RVA: 0x0005079C File Offset: 0x0004E99C
	private string #=zeacv7EoNSYZ5()
	{
		return this.#=zW88Ww4GRpWuygJ5Pfw==;
	}

	// Token: 0x06000A1A RID: 2586 RVA: 0x000507A4 File Offset: 0x0004E9A4
	private void #=zskxfjcFDranQ(string #=z$Ib9gYQ=)
	{
		this.#=zW88Ww4GRpWuygJ5Pfw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A1B RID: 2587 RVA: 0x000507B0 File Offset: 0x0004E9B0
	public bool #=zN9p5NNdPP8hONn3XaYpbiK4=()
	{
		return this.#=zzz7qrZKi8nJl6jGrqr_u63Dp0I4n;
	}

	// Token: 0x06000A1C RID: 2588 RVA: 0x000507B8 File Offset: 0x0004E9B8
	public void #=zuQPTAKXcN0sT27WqTnSnZgI=(bool #=z$Ib9gYQ=)
	{
		this.#=zzz7qrZKi8nJl6jGrqr_u63Dp0I4n = #=z$Ib9gYQ=;
	}

	// Token: 0x06000A1D RID: 2589 RVA: 0x000507C4 File Offset: 0x0004E9C4
	public void #=zFgabd6AP3NvQ(bool #=zCHbn2hfH3UKtUNPP0hes2P8=)
	{
		if (!this.#=zbhjPyxLDEPBD() && !this.#=zN9p5NNdPP8hONn3XaYpbiK4=())
		{
			this.#=zkiYM9EI=(#=zCHbn2hfH3UKtUNPP0hes2P8=, this.#=zeacv7EoNSYZ5(), false);
		}
	}

	// Token: 0x06000A1E RID: 2590 RVA: 0x000507E4 File Offset: 0x0004E9E4
	public void #=zhuG9bG4zLi8ogdOUAA==()
	{
		if (!this.#=zbhjPyxLDEPBD() && !this.#=zN9p5NNdPP8hONn3XaYpbiK4=())
		{
			this.#=zkiYM9EI=(false, this.#=zeacv7EoNSYZ5(), true);
		}
	}

	// Token: 0x06000A1F RID: 2591 RVA: 0x00050804 File Offset: 0x0004EA04
	private void #=zW3vXs9Q=(bool #=zCHbn2hfH3UKtUNPP0hes2P8=)
	{
		this.#=z9HdGFQI=.Clear();
		this.#=zZEriZapMbvmY(null);
		this.#=zkiYM9EI=(#=zCHbn2hfH3UKtUNPP0hes2P8=, this.#=zeacv7EoNSYZ5(), false);
	}

	// Token: 0x06000A20 RID: 2592 RVA: 0x00050828 File Offset: 0x0004EA28
	private void #=zkiYM9EI=(bool #=zCHbn2hfH3UKtUNPP0hes2P8=, string #=zRJiFeNQ=, bool #=zkZIHOX4=)
	{
		if (!string.IsNullOrEmpty(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z_6EikM59XFqjHPXueA==()))
		{
			this.#=zZEriZapMbvmY(JSONManager.GetData(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z_6EikM59XFqjHPXueA==()));
			#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBBdtOIwHrS6fN4w4iA==(null);
			return;
		}
		if (!this.#=zQ4wZnctPyyRO().#=zq76JuU9WPIZn())
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== obj = this.#=zQ4wZnctPyyRO();
			lock (obj)
			{
				if (!this.#=zQ4wZnctPyyRO().#=zq76JuU9WPIZn())
				{
					this.#=zZEriZapMbvmY(this.#=z16bP42ogtf3HrzzNRg==());
				}
			}
			#=zjNRlDQwOaWdKbErvpdHpebkyBG_yZATZZA==.#=zhxkCgoMhDoMmRxUjA5MfY_g=(this);
		}
		if (this.#=zCCC3qqgZgmhw() == null)
		{
			if (#=zkZIHOX4=)
			{
				this.#=zZEriZapMbvmY(JSONManager.GetData(this.#=z$2ijYGRf0FB5().#=zeoI_JM$qmO3Jp7VRURuP390=()));
			}
			else
			{
				this.#=zZEriZapMbvmY(this.#=zo0i70mCob6nR(#=zCHbn2hfH3UKtUNPP0hes2P8=, #=zRJiFeNQ=));
			}
		}
		if (this.#=zCCC3qqgZgmhw() == null)
		{
			this.#=zuQPTAKXcN0sT27WqTnSnZgI=(true);
		}
	}

	// Token: 0x06000A21 RID: 2593 RVA: 0x000508F4 File Offset: 0x0004EAF4
	private bool #=zaIqe7d5joOPU(object #=zIRwPsGQY$M0r, string #=zRJiFeNQ=)
	{
		if (#=zIRwPsGQY$M0r == null)
		{
			return false;
		}
		object @object = JSONManager.GetObject(#=zIRwPsGQY$M0r, #=zRJiFeNQ=);
		return @object != null && (!(@object is Dictionary<string, object>) || (@object as Dictionary<string, object>).Count != 0) && (!(@object is object[]) || (@object as object[]).Length != 0);
	}

	// Token: 0x06000A22 RID: 2594 RVA: 0x00050940 File Offset: 0x0004EB40
	private Dictionary<string, object> #=z16bP42ogtf3HrzzNRg==()
	{
		Dictionary<string, object> dictionary = this.#=z$2ijYGRf0FB5().#=zuq1FOz8SJbyH();
		Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759));
		dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399)] = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399));
		return dictionary2;
	}

	// Token: 0x06000A23 RID: 2595 RVA: 0x0005098C File Offset: 0x0004EB8C
	private object #=zo0i70mCob6nR(bool #=zCHbn2hfH3UKtUNPP0hes2P8=, string #=zE$u8Zgbd_9gU)
	{
		string #=zRJiFeNQ= = string.IsNullOrEmpty(#=zE$u8Zgbd_9gU) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070391) : #=zE$u8Zgbd_9gU;
		object obj = null;
		this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070374), Array.Empty<object>());
		try
		{
			string text = null;
			try
			{
				text = this.#=z$2ijYGRf0FB5().#=zMmyIB6$viHz8();
				obj = JSONManager.GetData(text);
			}
			catch
			{
			}
			if (!this.#=zQmveeqwfZtWH.#=zU3NiAfDQweme8jKsqw==())
			{
				if (!this.#=zaIqe7d5joOPU(obj, #=zRJiFeNQ=) && #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zOR7fTvmTu73NfJN7OcVEOIaIdTad2ijeeg==())
				{
					this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070345), Array.Empty<object>());
					text = this.#=z$2ijYGRf0FB5().#=zmCoo1cf$wbnyUGo_O$bDNY8=(#=zCHbn2hfH3UKtUNPP0hes2P8= ? 3 : 1);
					if (text.Trim().Length < 1000)
					{
						this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070547), Array.Empty<object>());
						text = this.#=z$2ijYGRf0FB5().#=zMmyIB6$viHz8();
					}
					obj = JSONManager.GetData(text);
				}
				if (!this.#=zaIqe7d5joOPU(obj, #=zRJiFeNQ=) && this.#=zXqKwUc4=.#=zye4p0LD68zfCQCgzAg==() != null)
				{
					bool flag = false;
					int[] array = new int[]
					{
						33,
						2,
						3,
						1,
						4
					};
					UnitSquadCollection unitSquadCollection = this.#=zXqKwUc4=.#=zye4p0LD68zfCQCgzAg==()[0];
					UnitSquadCollection unitSquadCollection2 = this.#=zXqKwUc4=.#=zye4p0LD68zfCQCgzAg==()[1];
					UnitSquadCollection unitSquadCollection3 = this.#=zXqKwUc4=.#=zye4p0LD68zfCQCgzAg==()[2];
					if (unitSquadCollection2.Count > 0)
					{
						for (int i = 0; i < array.Length; i++)
						{
							UnitSquad unitSquad = unitSquadCollection2.Find(array[i]);
							if (unitSquad != null && unitSquad.Number >= 2)
							{
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070472), new object[]
								{
									unitSquad.Type.Name
								});
								text = this.#=z$2ijYGRf0FB5().#=zf6Rj4tTeYocpS$xPAy8PT6s=(new UnitSquadCollection
								{
									new UnitSquad(unitSquad.Type, 1)
								});
								if (text.Length > 1000)
								{
									obj = JSONManager.GetData(text);
									flag = true;
									break;
								}
								if (!text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072212)))
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072156), new object[]
									{
										unitSquad.Type.Name,
										JSONManager.Cut(text)
									});
									break;
								}
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072185), new object[]
								{
									unitSquad.Type.Name
								});
							}
						}
					}
					if (!flag && unitSquadCollection.Count > 0)
					{
						for (int j = 0; j < array.Length; j++)
						{
							UnitSquad unitSquad2 = unitSquadCollection.Find(array[j]);
							if (unitSquad2 != null && unitSquad2.Number >= 2)
							{
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072354), new object[]
								{
									unitSquad2.Type.Name
								});
								text = this.#=z$2ijYGRf0FB5().#=zj6mJJFZU84bVSPLgcS8vCmc=(new UnitSquadCollection
								{
									new UnitSquad(unitSquad2.Type.Id, 1)
								});
								if (text.Length > 1000)
								{
									obj = JSONManager.GetData(text);
									flag = true;
									break;
								}
								if (!text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072297)))
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071977), new object[]
									{
										unitSquad2.Type.Name,
										JSONManager.Cut(text)
									});
									break;
								}
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072267), new object[]
								{
									unitSquad2.Type.Name
								});
							}
						}
					}
					if (!flag)
					{
						for (int k = 0; k < array.Length; k++)
						{
							UnitSquad unitSquad3 = unitSquadCollection.Find(array[k]);
							if (unitSquad3 == null || unitSquad3.Number == 0)
							{
								unitSquad3 = unitSquadCollection2.Find(array[k]);
							}
							if (unitSquad3 == null || unitSquad3.Number == 0)
							{
								unitSquad3 = unitSquadCollection3.Find(array[k]);
							}
							if (unitSquad3 != null && unitSquad3.Number >= 1)
							{
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072354), new object[]
								{
									unitSquad3.Type.Name
								});
								text = this.#=z$2ijYGRf0FB5().#=zj6mJJFZU84bVSPLgcS8vCmc=(new UnitSquadCollection
								{
									new UnitSquad(unitSquad3.Type.Id, 1)
								});
								if (text.Length > 1000)
								{
									obj = JSONManager.GetData(text);
									break;
								}
								if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072297)))
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072267), new object[]
									{
										unitSquad3.Type.Name
									});
								}
								else
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072156), new object[]
									{
										unitSquad3.Type.Name,
										JSONManager.Cut(text)
									});
								}
								this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070472), new object[]
								{
									unitSquad3.Type.Name
								});
								text = this.#=z$2ijYGRf0FB5().#=zf6Rj4tTeYocpS$xPAy8PT6s=(new UnitSquadCollection
								{
									new UnitSquad(unitSquad3.Type, 1)
								});
								if (text.Length > 1000)
								{
									obj = JSONManager.GetData(text);
									break;
								}
								if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072212)))
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072185), new object[]
									{
										unitSquad3.Type.Name
									});
								}
								else
								{
									this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071977), new object[]
									{
										unitSquad3.Type.Name,
										JSONManager.Cut(text)
									});
								}
							}
						}
					}
				}
			}
			if (!this.#=zaIqe7d5joOPU(obj, #=zRJiFeNQ=))
			{
				this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071931), Array.Empty<object>());
				text = this.#=z$2ijYGRf0FB5().#=zeoI_JM$qmO3Jp7VRURuP390=();
				obj = JSONManager.GetData(text);
			}
			if (!this.#=zaIqe7d5joOPU(obj, #=zRJiFeNQ=))
			{
				this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071879), new object[]
				{
					JSONManager.Cut(text)
				});
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zXqKwUc4=;
				int num = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zOHjQnymy_Z90w6eDb8LcZGkt6fW2QsRIYzB9SIw=();
				#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zBENwKCkTvw3nABAn9$QvZl2_afFQO6vtkkdQOCA=(num + 1);
				if (this.#=zXqKwUc4=.#=zOHjQnymy_Z90w6eDb8LcZGkt6fW2QsRIYzB9SIw=() < 5)
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072032), Array.Empty<object>());
				}
				this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072087), Array.Empty<object>());
				obj = this.#=z16bP42ogtf3HrzzNRg==();
				if (!this.#=zaIqe7d5joOPU(obj, #=zRJiFeNQ=))
				{
					throw new #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072032), Array.Empty<object>());
				}
			}
			else
			{
				this.#=zXqKwUc4=.#=zBENwKCkTvw3nABAn9$QvZl2_afFQO6vtkkdQOCA=(0);
			}
			#=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zOdJWKD4=(JSONManager.GetString(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), null));
			int @int = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071726), 0);
			if (this.#=zXqKwUc4=.#=zKplt9fghze5O() < @int)
			{
				this.#=zXqKwUc4=.#=zYNBRw$1JagVG(@int);
			}
			int int2 = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071707), 0);
			if (this.#=zXqKwUc4=.#=zk0_Y$SJ_d1Er() < int2)
			{
				this.#=zXqKwUc4=.#=zWqunoVP8Im4d(int2);
			}
			this.#=zaKh$UFb2Csg8JhWH$g==(obj);
		}
		catch (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K)
		{
			bool flag2;
			#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zlWRHwq8=(this.#=zXqKwUc4=, this.#=z$2ijYGRf0FB5().#=zI4J7zo5ZdOzg(), out flag2);
			if (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)7)
			{
				throw;
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=zN_s5Z5A=);
			throw;
		}
		this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071697), Array.Empty<object>());
		return obj;
	}

	// Token: 0x06000A24 RID: 2596 RVA: 0x00051238 File Offset: 0x0004F438
	private void #=zdiaRX0xSvp6Y(string #=zRJiFeNQ=, bool #=zCHbn2hfH3UKtUNPP0hes2P8=)
	{
		if (!this.#=zaIqe7d5joOPU(this.#=zCCC3qqgZgmhw(), #=zRJiFeNQ=))
		{
			this.#=zZEriZapMbvmY(this.#=zo0i70mCob6nR(#=zCHbn2hfH3UKtUNPP0hes2P8=, #=zRJiFeNQ=));
		}
	}

	// Token: 0x06000A25 RID: 2597 RVA: 0x00051258 File Offset: 0x0004F458
	private void #=zaKh$UFb2Csg8JhWH$g==(object #=zIRwPsGQY$M0r)
	{
		try
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071678));
			if (dictionary != null)
			{
				int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0);
				int num2 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0);
				if (this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==() != num)
				{
					this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zHD9M6IxBLboIezSsHQ==(num);
				}
				if (this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==() != num2)
				{
					this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=z2WdNm_CMtqBR6ukyUw==(num2);
				}
			}
			this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zFzGvi_S6jJhE(JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071658), 0));
			this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zAsCgbAN02olKpq2GjA==(JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071654), 0));
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zXqKwUc4=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=zN_s5Z5A=);
		}
	}

	// Token: 0x06000A26 RID: 2598 RVA: 0x00051358 File Offset: 0x0004F558
	private object #=zSxiy4fI=(string #=zTnidQv4=, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY= #=zCXnzjLQ=)
	{
		object obj;
		if (this.#=z9HdGFQI=.ContainsKey(#=zTnidQv4=))
		{
			obj = this.#=z9HdGFQI=[#=zTnidQv4=];
		}
		else
		{
			obj = #=zCXnzjLQ=(this.#=zCCC3qqgZgmhw());
			this.#=z9HdGFQI=[#=zTnidQv4=] = obj;
		}
		return obj;
	}

	// Token: 0x06000A27 RID: 2599 RVA: 0x000513A0 File Offset: 0x0004F5A0
	public void Dispose()
	{
	}

	// Token: 0x06000A28 RID: 2600 RVA: 0x000513A4 File Offset: 0x0004F5A4
	private #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg== #=zI9957LjzvGq4WHfNbg==(object #=zIRwPsGQY$M0r)
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zI9957LjzvGq4WHfNbg==(#=zIRwPsGQY$M0r, this.#=zMJwfeAYJPt8h1j02AQ==(), this.#=zI4J7zo5ZdOzg());
	}

	// Token: 0x06000A29 RID: 2601 RVA: 0x000513B8 File Offset: 0x0004F5B8
	private static #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg== #=zI9957LjzvGq4WHfNbg==(object #=zIRwPsGQY$M0r, #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zQwNUa7X4qnHM, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD)
	{
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg== #=zBCnTChVbdugYhUcjAg== = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg==();
		#=zBCnTChVbdugYhUcjAg==.#=zmJQbUL_pBinpxJ6J6aIsTKKr$prD(UnitSquadCollection.FromDictionary(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071635))));
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
		#=zBCnTChVbdugYhUcjAg==.#=z$ciwFejl0v_HCHJnkQ==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zMHi_CEsJyeAs(array, #=zG2wnL_q7IxpD));
		for (int i = 0; i < #=zBCnTChVbdugYhUcjAg==.#=zdG3ICWKpS3SqzRhweg==().Count; i++)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=zBCnTChVbdugYhUcjAg==.#=zdG3ICWKpS3SqzRhweg==()[i];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=() < 0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_())
			{
				#=zBCnTChVbdugYhUcjAg==.#=zLWIW5kq2HhxLBLYwqVn$ckU=(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD());
				break;
			}
		}
		if (#=zBCnTChVbdugYhUcjAg==.#=zxbmGqPOMiA5Vj98ROwlDDag=() == null)
		{
			#=zBCnTChVbdugYhUcjAg==.#=zLWIW5kq2HhxLBLYwqVn$ckU=(new UnitSquadCollection());
		}
		int num = -1;
		for (int j = #=zBCnTChVbdugYhUcjAg==.#=zdG3ICWKpS3SqzRhweg==().Count - 1; j >= 0; j--)
		{
			#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 = #=zBCnTChVbdugYhUcjAg==.#=zdG3ICWKpS3SqzRhweg==()[j];
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)2 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==() < DateTime.Now)
			{
				if (num < 0)
				{
					num = ((#=zQwNUa7X4qnHM.#=zlPpWltETVrM_((#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)10055) > DateTime.Now > false) ? 1 : 0);
				}
				if (num > 0)
				{
					#=zBCnTChVbdugYhUcjAg==.#=zxbmGqPOMiA5Vj98ROwlDDag=().AddUnits(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD());
				}
				else
				{
					#=zBCnTChVbdugYhUcjAg==.#=zT3KU1ttOKQGxrLutU1n1UV4_i0Wq().AddUnits(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zDy8wm$yKq8XD());
				}
				#=zBCnTChVbdugYhUcjAg==.#=zdG3ICWKpS3SqzRhweg==().RemoveAt(j);
			}
		}
		return #=zBCnTChVbdugYhUcjAg==;
	}

	// Token: 0x06000A2A RID: 2602 RVA: 0x00051504 File Offset: 0x0004F704
	private #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg== #=zsT9lw5E9JdqCuR7rQw==()
	{
		return (#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071871), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zI9957LjzvGq4WHfNbg==));
	}

	// Token: 0x06000A2B RID: 2603 RVA: 0x00051528 File Offset: 0x0004F728
	public UnitSquadCollection #=zDM_Wlm8hm7V_KywDzIGOS0XNMCru()
	{
		return this.#=zsT9lw5E9JdqCuR7rQw==().#=zT3KU1ttOKQGxrLutU1n1UV4_i0Wq();
	}

	// Token: 0x06000A2C RID: 2604 RVA: 0x00051538 File Offset: 0x0004F738
	private UnitSquadCollection #=zlbLVz9sUlgzDvcx0RsXVah8dZbJT(object #=zIRwPsGQY$M0r)
	{
		UnitSquadCollection unitSquadCollection;
		if (this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().UnusedTroopsIsExist)
		{
			unitSquadCollection = UnitSquadCollection.FromString(this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().UnusedTroops, null);
			unitSquadCollection.RemoveUnits(this.#=zow71wfuy88DngCDjGxC$_qOPtUTd());
			unitSquadCollection.LimitToUnits(this.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru());
		}
		else
		{
			unitSquadCollection = new UnitSquadCollection();
		}
		return unitSquadCollection;
	}

	// Token: 0x06000A2D RID: 2605 RVA: 0x00051590 File Offset: 0x0004F790
	public UnitSquadCollection #=zp2mzms2YUjsUGxf5Ve03JIcq0mgU()
	{
		return (UnitSquadCollection)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071843), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zlbLVz9sUlgzDvcx0RsXVah8dZbJT));
	}

	// Token: 0x06000A2E RID: 2606 RVA: 0x000515B4 File Offset: 0x0004F7B4
	private UnitSquadCollection #=zomUH59M936PXMprGUlDLyE4TuxUa2O$nhAZBNdmExpz$fm9EuA==(object #=zIRwPsGQY$M0r)
	{
		UnitSquadCollection unitSquadCollection = this.#=zDM_Wlm8hm7V_KywDzIGOS0XNMCru().Clone();
		if (this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().UnusedTroopsIsExist)
		{
			unitSquadCollection.RemoveUnits(this.#=zp2mzms2YUjsUGxf5Ve03JIcq0mgU());
		}
		return unitSquadCollection;
	}

	// Token: 0x06000A2F RID: 2607 RVA: 0x000515EC File Offset: 0x0004F7EC
	public UnitSquadCollection #=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==()
	{
		return (UnitSquadCollection)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071810), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zomUH59M936PXMprGUlDLyE4TuxUa2O$nhAZBNdmExpz$fm9EuA==));
	}

	// Token: 0x06000A30 RID: 2608 RVA: 0x00051610 File Offset: 0x0004F810
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zZMcDuDoS83G7Fjxz7g==(object #=zIRwPsGQY$M0r)
	{
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zsT9lw5E9JdqCuR7rQw==().#=zdG3ICWKpS3SqzRhweg==();
		if (list.Count > 0)
		{
			this.#=zQ4wZnctPyyRO().#=zWwACCeJ9QQhNyL6$Hg==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zsO0UOz85fFukCr4OAg==(this.#=zsT9lw5E9JdqCuR7rQw==(), this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()));
		}
		return list;
	}

	// Token: 0x06000A31 RID: 2609 RVA: 0x0005164C File Offset: 0x0004F84C
	public List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zqWzt0eB5fbATSwpS3Q==()
	{
		return (List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071770), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zZMcDuDoS83G7Fjxz7g==));
	}

	// Token: 0x06000A32 RID: 2610 RVA: 0x00051670 File Offset: 0x0004F870
	public static List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zMHi_CEsJyeAs(object[] #=z09hPA$4KNfhpFNZgiw==, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD)
	{
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = new List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>();
		if (#=z09hPA$4KNfhpFNZgiw== != null)
		{
			foreach (Dictionary<string, object> dictionary in #=z09hPA$4KNfhpFNZgiw==)
			{
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071759)))
				{
					Dictionary<string, object> dictionary2 = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071759)] as Dictionary<string, object>;
					if (dictionary2.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)))
					{
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = new #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==(dictionary, #=zG2wnL_q7IxpD);
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zSXBstP4=(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]));
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zM5z33liKcNKa(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)]));
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zWIeOkE0$UPjN(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]));
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z3y$Jd2Y9Ey5E((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684)]));
						#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zLNM6_FpNs$Ws(UnitSquadCollection.FromDictionary(JSONManager.GetDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071748))));
						if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071474)))
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zgnto1O9DaXEn((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1);
							Dictionary<string, object> dictionary3 = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071474)] as Dictionary<string, object>;
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zW0BrC5xly8C6DW_5$sNAqBc=(JSONManager.DecodeTime(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)].ToString(), false));
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zLkO3VEKrN2mHIZiieQ==(JSONManager.DecodeTime(dictionary3[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)].ToString(), false));
						}
						else if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071467)))
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zgnto1O9DaXEn((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)2);
							Dictionary<string, object> dictionary4 = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071467)] as Dictionary<string, object>;
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zW0BrC5xly8C6DW_5$sNAqBc=(JSONManager.DecodeTime(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)].ToString(), false));
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zLkO3VEKrN2mHIZiieQ==(JSONManager.DecodeTime(dictionary4[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)].ToString(), false));
						}
						else
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zgnto1O9DaXEn((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0);
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zW0BrC5xly8C6DW_5$sNAqBc=(DateTime.MinValue);
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zLkO3VEKrN2mHIZiieQ==(DateTime.MinValue);
						}
						object[] array = JSONManager.GetArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071456));
						if (array != null)
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z0th9G3TTrmFP(new List<int>());
							foreach (object value in array)
							{
								#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT().Add(Convert.ToInt32(value));
							}
						}
						Dictionary<string, object> dictionary5 = JSONManager.ExtractDictionary(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
						if (dictionary5 != null)
						{
							#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== = new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==(dictionary5);
							if (#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==.Count > 0)
							{
								#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zP4oM5G$XLlhDYD0crBVk690=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==);
							}
						}
						list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==);
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06000A33 RID: 2611 RVA: 0x00051910 File Offset: 0x0004FB10
	public static UnitSquadCollection[] #=zsO0UOz85fFukCr4OAg==(int #=zvPiOyGQ=, object #=zIRwPsGQY$M0r, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD)
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zsO0UOz85fFukCr4OAg==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zI9957LjzvGq4WHfNbg==(#=zIRwPsGQY$M0r, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zUEIv5c0n07pU(#=zIRwPsGQY$M0r), #=zG2wnL_q7IxpD), #=zvPiOyGQ=);
	}

	// Token: 0x06000A34 RID: 2612 RVA: 0x00051928 File Offset: 0x0004FB28
	private static UnitSquadCollection[] #=zsO0UOz85fFukCr4OAg==(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBCnTChVbdugYhUcjAg== #=z7SyuZAeZNgJGFXYNsQ==, int #=zvPiOyGQ=)
	{
		UnitSquadCollection[] array = new UnitSquadCollection[]
		{
			#=z7SyuZAeZNgJGFXYNsQ==.#=zT3KU1ttOKQGxrLutU1n1UV4_i0Wq(),
			new UnitSquadCollection(),
			new UnitSquadCollection()
		};
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in #=z7SyuZAeZNgJGFXYNsQ==.#=zdG3ICWKpS3SqzRhweg==())
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=zvPiOyGQ=)
			{
				if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=() < 0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() == #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_())
				{
					array[1] = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD();
				}
				else if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z8waQMcfHThTd() != (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0)
				{
					array[2].AddUnits(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zDy8wm$yKq8XD());
				}
			}
		}
		return array;
	}

	// Token: 0x06000A35 RID: 2613 RVA: 0x000519D8 File Offset: 0x0004FBD8
	private UnitSquadCollection #=z9kmqSCYNrvthGHzRUR82deg4ziBD(object #=zIRwPsGQY$M0r)
	{
		return this.#=zsT9lw5E9JdqCuR7rQw==().#=zxbmGqPOMiA5Vj98ROwlDDag=();
	}

	// Token: 0x06000A36 RID: 2614 RVA: 0x000519E8 File Offset: 0x0004FBE8
	public UnitSquadCollection #=zow71wfuy88DngCDjGxC$_qOPtUTd()
	{
		return (UnitSquadCollection)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071454), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z9kmqSCYNrvthGHzRUR82deg4ziBD));
	}

	// Token: 0x06000A37 RID: 2615 RVA: 0x00051A0C File Offset: 0x0004FC0C
	private UnitSquadCollection #=zFKBEymM2Lj$ojBFfv0ig3Ogi8iI3g53sAfNMEOL2TJRODxieTg==(object #=zIRwPsGQY$M0r)
	{
		UnitSquadCollection unitSquadCollection = this.#=zow71wfuy88DngCDjGxC$_qOPtUTd().Clone();
		if (this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().UnusedTroopsIsExist)
		{
			unitSquadCollection.RemoveUnits(UnitSquadCollection.FromString(this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().UnusedTroops, null));
		}
		return unitSquadCollection;
	}

	// Token: 0x06000A38 RID: 2616 RVA: 0x00051A54 File Offset: 0x0004FC54
	public UnitSquadCollection #=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==()
	{
		return (UnitSquadCollection)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071428), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zFKBEymM2Lj$ojBFfv0ig3Ogi8iI3g53sAfNMEOL2TJRODxieTg==));
	}

	// Token: 0x06000A39 RID: 2617 RVA: 0x00051A78 File Offset: 0x0004FC78
	private object #=z6ZoDN2Vo66Cc8PfyvYsH4rg=(object #=zIRwPsGQY$M0r)
	{
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071391));
		int num = 0;
		if (dictionary != null)
		{
			using (Dictionary<string, object>.ValueCollection.Enumerator enumerator = dictionary.Values.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					num = Convert.ToInt32(enumerator.Current);
				}
			}
		}
		return num;
	}

	// Token: 0x06000A3A RID: 2618 RVA: 0x00051AE8 File Offset: 0x0004FCE8
	public int #=zgRq0Ty7BhBO543uVxmeuTso=()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071374), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z6ZoDN2Vo66Cc8PfyvYsH4rg=));
	}

	// Token: 0x06000A3B RID: 2619 RVA: 0x00051B0C File Offset: 0x0004FD0C
	public List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zn3lmtbueoIUfikFOI78eK$8=()
	{
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = new List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>();
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zqWzt0eB5fbATSwpS3Q==())
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zVVorJLug3m2L() != this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() == this.#=zXqKwUc4=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=() && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)2 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3))
			{
				list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==);
			}
		}
		return list;
	}

	// Token: 0x06000A3C RID: 2620 RVA: 0x00051BA8 File Offset: 0x0004FDA8
	private List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> #=zW9pM3Pb7HOVzqpn_5vpYHv8=(object #=zIRwPsGQY$M0r)
	{
		List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> list = new List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071618));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601)))
				{
					list.Add(new #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=(dictionary));
				}
			}
		}
		return list;
	}

	// Token: 0x06000A3D RID: 2621 RVA: 0x00051C08 File Offset: 0x0004FE08
	public List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> #=z0bat7_QugpCgKGwzpnRDXa8=()
	{
		return (List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071598), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zW9pM3Pb7HOVzqpn_5vpYHv8=));
	}

	// Token: 0x06000A3E RID: 2622 RVA: 0x00051C2C File Offset: 0x0004FE2C
	private List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> #=zSxlLPp1LQHMBPfsBgI7C1Ks=(object #=zIRwPsGQY$M0r)
	{
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071575));
		List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> list = new List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=>();
		if (array != null)
		{
			foreach (Dictionary<string, object> #=zOurwV8f4EneEUWOrkQ== in array)
			{
				list.Add(new #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=(#=zOurwV8f4EneEUWOrkQ==));
			}
		}
		return list;
	}

	// Token: 0x06000A3F RID: 2623 RVA: 0x00051C7C File Offset: 0x0004FE7C
	public List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=> #=zC6pCNPvHlvvsjFd3wuxtDlE=()
	{
		return (List<#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071552), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zSxlLPp1LQHMBPfsBgI7C1Ks=));
	}

	// Token: 0x06000A40 RID: 2624 RVA: 0x00051CA0 File Offset: 0x0004FEA0
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zSaY7vI6hwh3mFK75rWavVd0=(object #=zIRwPsGQY$M0r)
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z4UvGiLJo6$eGNGd0Mg==(#=zIRwPsGQY$M0r);
	}

	// Token: 0x06000A41 RID: 2625 RVA: 0x00051CA8 File Offset: 0x0004FEA8
	public #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zNnx4xxtx9xYwefJwdg==()
	{
		return (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071534), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zSaY7vI6hwh3mFK75rWavVd0=));
	}

	// Token: 0x06000A42 RID: 2626 RVA: 0x00051CCC File Offset: 0x0004FECC
	public static #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z4UvGiLJo6$eGNGd0Mg==(object #=zJ5GWysk=)
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		object[] array = JSONManager.GetObject(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070391)) as object[];
		if (array == null)
		{
			return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==;
		}
		#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
		foreach (Dictionary<string, object> dictionary in array)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = new #=zO6457TajDDxDJIsKqS1bbzDMLckn();
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zbsxKkj4=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zedb$WwBQsoJF(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0));
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zzQwUIEs=(#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4()));
			Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
			if (dictionary2 != null)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFzGvi_S6jJhE(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zdU1a9B$ueh_3(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), false));
			}
			Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071518));
			if (dictionary3 != null)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zHD9M6IxBLboIezSsHQ==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827), 0));
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z2WdNm_CMtqBR6ukyUw==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zNzS1JlWmGn84_d6f9A==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zSIKgNs5Taw6RyqqQZw==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891), 0) == 1);
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zQx7wBUdkq1I088Sg0Q==(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069976), 0));
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z6zRvpPP_$ZVF(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071511), 0) == 1);
			#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zpN8az$GdxbPzdnDtHg==(0);
			Dictionary<string, object> dictionary4 = JSONManager.GetDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071490));
			if (dictionary4 != null)
			{
				foreach (object value in dictionary4.Values)
				{
					double num = Convert.ToDouble(value);
					if (num > 0.01)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zpN8az$GdxbPzdnDtHg==((int)num);
						break;
					}
				}
			}
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
		}
		return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==;
	}

	// Token: 0x06000A43 RID: 2627 RVA: 0x00051EE0 File Offset: 0x000500E0
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=z9bK4xmyUWPbpIA3jiL7WSRQ=(object #=zIRwPsGQY$M0r)
	{
		#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== = new #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==();
		object[] array = JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073273)) as object[];
		if (array != null)
		{
			#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
			foreach (Dictionary<string, object> dictionary in array)
			{
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = new #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==();
				#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zzQwUIEs=(#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zk$6QZNA=(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)])));
				if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=() != null)
				{
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)];
					#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zFzGvi_S6jJhE(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
					if (dictionary2.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)) && dictionary2.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086)))
					{
						#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zdU1a9B$ueh_3(JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), false));
					}
					#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==.Add(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==);
				}
			}
		}
		return #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==;
	}

	// Token: 0x06000A44 RID: 2628 RVA: 0x00051FE4 File Offset: 0x000501E4
	public #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zS96aE1JwlopY1ifRovTglSw=()
	{
		return (#=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073259), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z9bK4xmyUWPbpIA3jiL7WSRQ=));
	}

	// Token: 0x06000A45 RID: 2629 RVA: 0x00052008 File Offset: 0x00050208
	private #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=z0ppJAuPVMrn$(object #=zIRwPsGQY$M0r)
	{
		#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= = new #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=();
		object[] array = JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073246)) as object[];
		if (array != null)
		{
			#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zi1hFJwI=();
			foreach (Dictionary<string, object> dictionary in array)
			{
				#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== = new #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==();
				#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zzQwUIEs=(#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.#=zk$6QZNA=(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)]) - 100));
				if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zq2bPTdY=() != null)
				{
					object[] array3 = (object[])JSONManager.GetObject(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073227));
					if (array3 != null)
					{
						#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=z9cbTL9Fte7ios6efTw==(new Dictionary<int, int>());
						for (int j = 0; j < array3.Length; j++)
						{
							int num = Convert.ToInt32(array3[j]);
							if (num > 0)
							{
								#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==()[j] = num;
							}
						}
						if (#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==.#=zo4gR$B4ZVFdYTDxEaw==().Count > 0)
						{
							#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=.Add(#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==);
						}
					}
				}
			}
		}
		return #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=;
	}

	// Token: 0x06000A46 RID: 2630 RVA: 0x00052104 File Offset: 0x00050304
	public #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= #=zTbkv095gWozyg_xVnw==()
	{
		return (#=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073217), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z0ppJAuPVMrn$));
	}

	// Token: 0x06000A47 RID: 2631 RVA: 0x00052128 File Offset: 0x00050328
	private #=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R #=zu7SGIZ933UFGay4A7UK_hKs=(object #=zIRwPsGQY$M0r)
	{
		return new #=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073207)));
	}

	// Token: 0x06000A48 RID: 2632 RVA: 0x00052140 File Offset: 0x00050340
	public #=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R #=zld8y4Nc63Ecs5jIAkxY9QS4=()
	{
		return (#=z43XCoevuFuOHULdQg900w9M6gy6AHpf7Bvs_DyyUvW2R)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073186), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zu7SGIZ933UFGay4A7UK_hKs=));
	}

	// Token: 0x06000A49 RID: 2633 RVA: 0x00052164 File Offset: 0x00050364
	private #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=zvJ$ZS9ubAJlz(object #=zIRwPsGQY$M0r)
	{
		#=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== = new #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw==();
		object[] array = JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073172)) as object[];
		if (array != null)
		{
			#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zi1hFJwI=();
			foreach (Dictionary<string, object> dictionary in array)
			{
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA== = new #=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==();
				#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zzQwUIEs=(#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.#=zk$6QZNA=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0)));
				if (#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zq2bPTdY=() != null)
				{
					#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==.#=zFzGvi_S6jJhE(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073153), 0));
					#=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw==.Add(#=z0oP_Gzwu3QY8IgOeVPcrdR3lg1fiJqpRzA==);
				}
			}
		}
		return #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw==;
	}

	// Token: 0x06000A4A RID: 2634 RVA: 0x00052204 File Offset: 0x00050404
	public #=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw== #=zzDosIddISk1$()
	{
		return (#=zOiWE_lc$VjCy6yogLwLJk$nXrjSlbLfCjw==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073407), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zvJ$ZS9ubAJlz));
	}

	// Token: 0x06000A4B RID: 2635 RVA: 0x00052228 File Offset: 0x00050428
	private #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ #=zMZqeLOTYlgJSyGMxI5bBIMDROgyl(object #=zIRwPsGQY$M0r)
	{
		#=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ = new #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_();
		object[] array = JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073387)) as object[];
		if (array != null)
		{
			#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5.#=zi1hFJwI=();
			foreach (Dictionary<string, object> dictionary in array)
			{
				#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = new #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN();
				#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zzQwUIEs=(#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958)])));
				if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=() != null)
				{
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581)];
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zFzGvi_S6jJhE(Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245)]));
					if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zvnZc$RhG_1Du() > 0)
					{
						#=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_.Add(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN);
					}
				}
			}
		}
		return #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_;
	}

	// Token: 0x06000A4C RID: 2636 RVA: 0x000522F8 File Offset: 0x000504F8
	public #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ #=zvQRf_STy5v8Sm5tuw7Xh278usASc()
	{
		return (#=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073380), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zMZqeLOTYlgJSyGMxI5bBIMDROgyl));
	}

	// Token: 0x06000A4D RID: 2637 RVA: 0x0005231C File Offset: 0x0005051C
	private #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= #=zyeH1$B2$PledRdAvqw==(object #=zIRwPsGQY$M0r)
	{
		#=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= = new #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM=();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073358));
		if (array != null)
		{
			foreach (Dictionary<string, object> #=zwIagxaleiGlavydUhA== in array)
			{
				#=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM=.#=zU0JAE58=(new #=zesBR9QdKGIBsSHNpxZRXyrToxyjs2cT1owEG06E=(#=zwIagxaleiGlavydUhA==));
			}
		}
		return #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM=;
	}

	// Token: 0x06000A4E RID: 2638 RVA: 0x0005236C File Offset: 0x0005056C
	public #=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM= #=zOo2ORcNoE4PzlDAS9fQ8Rc8=()
	{
		return (#=zPyyVu6Ap3$8ummc9$YTHnrgqwYFUNRqi0YIF$hM=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073337), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zyeH1$B2$PledRdAvqw==));
	}

	// Token: 0x06000A4F RID: 2639 RVA: 0x00052390 File Offset: 0x00050590
	private #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8= #=zbu9AYPX1ZuTAxp_H3A3Kc1Q=(object #=zIRwPsGQY$M0r)
	{
		#=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8= #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8= = new #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8=();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073358));
		if (array != null)
		{
			foreach (Dictionary<string, object> #=zwIagxaleiGlavydUhA== in array)
			{
				#=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8=.Add(new #=zesBR9QdKGIBsSHNpxZRXyrToxyjs2cT1owEG06E=(#=zwIagxaleiGlavydUhA==));
			}
		}
		return #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8=;
	}

	// Token: 0x06000A50 RID: 2640 RVA: 0x000523E0 File Offset: 0x000505E0
	public #=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8= #=zVB$f6ofgIEHftVz7HWepTzs=()
	{
		return (#=zxSQ1Jmg5eA7M3z6M6AkN6bZCaSJvoTZD1GIirp8=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073325), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zbu9AYPX1ZuTAxp_H3A3Kc1Q=));
	}

	// Token: 0x06000A51 RID: 2641 RVA: 0x00052404 File Offset: 0x00050604
	public List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> #=zCsLQRc5IYRE_(UnitType #=zvRLj9WQ=)
	{
		if (#=zvRLj9WQ= == null)
		{
			return new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>
			{
				(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0
			};
		}
		List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==> list = new List<#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==>();
		Worlds world = #=zvRLj9WQ=.World;
		if (world != Worlds.Elisium)
		{
			if (world != Worlds.Veor)
			{
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0);
				switch (#=zvRLj9WQ=.Class)
				{
				case UnitType.Classes.LightInfantry:
					if (this.#=zMJwfeAYJPt8h1j02AQ==().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=.#=zLkw0NRU=.#=zcsnsnOCtdJVrCMPNzNZ6PvxD$Wjy)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)3);
					}
					break;
				case UnitType.Classes.HeavyInfantry:
					if (this.#=zMJwfeAYJPt8h1j02AQ==().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=.#=zLkw0NRU=.#=zkZuhj97ct1jE1wJxKCszeeV0gjIs)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)4);
					}
					break;
				case UnitType.Classes.Phalanx:
					if (this.#=zMJwfeAYJPt8h1j02AQ==().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=.#=zLkw0NRU=.#=zELPrCPCD5OtsPv$W3JjWJjVxouKz)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)5);
					}
					break;
				case UnitType.Classes.Cavalry:
					if (this.#=zMJwfeAYJPt8h1j02AQ==().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=.#=zLkw0NRU=.#=z8pteX8apNXZOtAZMcoWV22ZullgS)) != null)
					{
						list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)6);
					}
					break;
				}
			}
			else
			{
				if (this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().IsVeorHireTroopsAsUsual && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=zQ4wZnctPyyRO()))
				{
					list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)0);
				}
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)8);
			}
		}
		else
		{
			list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)1);
			if (this.#=zMJwfeAYJPt8h1j02AQ==().Find(new Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==>(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=.#=zLkw0NRU=.#=zsTSQxC9jqLOce48Nn6nBEwrr$OTi)) != null)
			{
				list.Add((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)7);
			}
		}
		return list;
	}

	// Token: 0x06000A52 RID: 2642 RVA: 0x000525B0 File Offset: 0x000507B0
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zqjc3tm0LR7OOsCZmGQ==(object #=zIRwPsGQY$M0r)
	{
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073289));
		#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= = new #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=();
		if (dictionary != null)
		{
			#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=();
			for (int i = 0; i < #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.Count; i++)
			{
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=[i];
				if (dictionary.ContainsKey(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=().ToString()))
				{
					Dictionary<string, object> dictionary2 = (Dictionary<string, object>)dictionary[#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=().ToString()];
					int num = JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0);
					object[] array = JSONManager.GetArray(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966));
					if (array != null)
					{
						object[] array2 = array;
						for (int j = 0; j < array2.Length; j++)
						{
							if (JSONManager.DecodeTime(Convert.ToString(array2[j]), false) < DateTime.Now)
							{
								num--;
								#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.#=z8MmIBq3WuwD1k4Tygg==(true);
							}
						}
					}
					if (num > 0)
					{
						#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.Add(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=(), new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=, num));
					}
				}
			}
			foreach (string text in dictionary.Keys)
			{
				int num2;
				if (int.TryParse(text, out num2) && !#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.ContainsKey(num2))
				{
					Dictionary<string, object> dictionary3 = (Dictionary<string, object>)dictionary[text];
					int num3 = JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0);
					object[] array3 = JSONManager.GetArray(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966));
					if (array3 != null)
					{
						object[] array2 = array3;
						for (int j = 0; j < array2.Length; j++)
						{
							if (JSONManager.DecodeTime(Convert.ToString(array2[j]), false) < DateTime.Now)
							{
								num3--;
							}
						}
					}
					if (num3 > 0)
					{
						#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=.Add(num2, new #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zhDfo7Dc=(num2), num3));
					}
				}
			}
		}
		return #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=;
	}

	// Token: 0x06000A53 RID: 2643 RVA: 0x000527A0 File Offset: 0x000509A0
	public #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zu0512GNdOuq21KSBDS8fmqw=()
	{
		return (#=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073016), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zqjc3tm0LR7OOsCZmGQ==));
	}

	// Token: 0x06000A54 RID: 2644 RVA: 0x000527C4 File Offset: 0x000509C4
	private object #=zqoLEGYq18FVSFxS21g==(object #=zIRwPsGQY$M0r)
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zb38VODLUifr5RLC4eg==(this.#=zQ4wZnctPyyRO(), this, #=zIRwPsGQY$M0r);
	}

	// Token: 0x06000A55 RID: 2645 RVA: 0x000527D8 File Offset: 0x000509D8
	public bool #=zuMXv8DnEbNVrFpFzVw==()
	{
		return (bool)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072995), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zqoLEGYq18FVSFxS21g==));
	}

	// Token: 0x06000A56 RID: 2646 RVA: 0x000527FC File Offset: 0x000509FC
	private static bool #=zb38VODLUifr5RLC4eg==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=, object #=zIRwPsGQY$M0r)
	{
		if (!GameApplicationData.#=zFp3v5CbiiaCH())
		{
			return false;
		}
		if (!#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zeN7AHdfQJNd1(#=z8StzeqE=))
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072968), Array.Empty<object>());
			return false;
		}
		if (JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073143), 0) == 1)
		{
			return true;
		}
		if (#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zvnZc$RhG_1Du() < 60)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073121), Array.Empty<object>());
			return false;
		}
		if (#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zHVllBBIHynsrMuvepQ==() == 0)
		{
			#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zu7T_8nF2JRsQdbFe5A==(#=zuJjQ1XU=);
		}
		if (#=z8StzeqE=.#=z5Fxa9o9ygZWU().#=zHVllBBIHynsrMuvepQ==() < 40)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073064), Array.Empty<object>());
			return false;
		}
		List<int> list = new List<int>
		{
			1080,
			1086,
			1089
		};
		foreach (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== in #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=())
		{
			if (#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() > 0 && list.Contains(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zMuFMjGQ=()))
			{
				list.Remove(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zMuFMjGQ=());
			}
		}
		if (list.Count > 0)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072728), Array.Empty<object>());
			return false;
		}
		string text = #=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=zTf4iXOM9uYoCQZbsEw==();
		bool result;
		if (text.Length > 10000)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072652), Array.Empty<object>());
			result = true;
		}
		else if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072856)))
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072839), Array.Empty<object>());
			result = true;
		}
		else
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072773), new object[]
			{
				JSONManager.Cut(text)
			});
			result = false;
		}
		if (#=zuJjQ1XU=.#=zxGBLmFv_i0a2$PP1Jw==() == 0)
		{
			string text2 = #=zuJjQ1XU=.#=z$2ijYGRf0FB5().#=z8DuONse9WzaXcgQy4g==();
			if (text2.Length > 10000)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072477), Array.Empty<object>());
				#=zuJjQ1XU=.#=zW3vXs9Q=(false);
				if (#=zuJjQ1XU=.#=z9XuZ7IMaxkRw() == 0)
				{
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072439), Array.Empty<object>());
				}
			}
			else
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zuJjQ1XU=.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072597), new object[]
				{
					JSONManager.Cut(text2)
				});
			}
		}
		return result;
	}

	// Token: 0x06000A57 RID: 2647 RVA: 0x00052AC8 File Offset: 0x00050CC8
	private object #=zRUdQTqfW$TZT(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072556), 0);
	}

	// Token: 0x06000A58 RID: 2648 RVA: 0x00052AE0 File Offset: 0x00050CE0
	public int #=z9XuZ7IMaxkRw()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072537), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zRUdQTqfW$TZT));
	}

	// Token: 0x06000A59 RID: 2649 RVA: 0x00052B04 File Offset: 0x00050D04
	private object #=zbnqnpFlEnrcp2SHPwg==(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909072512), 0);
	}

	// Token: 0x06000A5A RID: 2650 RVA: 0x00052B1C File Offset: 0x00050D1C
	public int #=zxGBLmFv_i0a2$PP1Jw==()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074290), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zbnqnpFlEnrcp2SHPwg==));
	}

	// Token: 0x06000A5B RID: 2651 RVA: 0x00052B40 File Offset: 0x00050D40
	public int[] #=z5bKdgpPzNS6dKj$3ew==()
	{
		int num = 0;
		int num2 = 0;
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = this.#=zNnx4xxtx9xYwefJwdg==();
		for (int i = 0; i < list.Count; i++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = list[i];
			#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=();
			if (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF == null)
			{
				#=zZ4TczVhhqPd03VvEaufX1hUlE1pF = new #=zZ4TczVhhqPd03VvEaufX1hUlE1pF();
			}
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z5kpAZQpjT2b7() && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zGhmoNZChgwf8() > DateTime.Now && #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zgFVkd5ydGXNJ() != (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4)
			{
				num++;
				if (AbstractType.IsFutureWorld(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.World))
				{
					num2++;
				}
			}
		}
		return new int[]
		{
			this.#=z9XuZ7IMaxkRw() - num,
			this.#=zxGBLmFv_i0a2$PP1Jw==() - num2
		};
	}

	// Token: 0x06000A5C RID: 2652 RVA: 0x00052BDC File Offset: 0x00050DDC
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zeE7bYhQ=(object #=zIRwPsGQY$M0r)
	{
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074271));
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 result;
		if (dictionary != null)
		{
			result = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zFKAQ83WoonkR(dictionary);
		}
		else
		{
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074251), Array.Empty<object>());
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zQmveeqwfZtWH, JSONManager.Cut(JSONManager.SerializeData(#=zIRwPsGQY$M0r)), Array.Empty<object>());
			result = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		}
		return result;
	}

	// Token: 0x06000A5D RID: 2653 RVA: 0x00052C60 File Offset: 0x00050E60
	public #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z_tcU3ov4mZ9V()
	{
		return (#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074208), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zeE7bYhQ=));
	}

	// Token: 0x06000A5E RID: 2654 RVA: 0x00052C84 File Offset: 0x00050E84
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zpNIt4u6hilEg(object #=zIRwPsGQY$M0r)
	{
		Dictionary<string, object> dictionary = (Dictionary<string, object>)JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074192));
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 result;
		if (dictionary != null)
		{
			result = #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zFKAQ83WoonkR(dictionary);
		}
		else
		{
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074189), Array.Empty<object>());
			this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zQmveeqwfZtWH, JSONManager.Cut(JSONManager.SerializeData(#=zIRwPsGQY$M0r)), Array.Empty<object>());
			result = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		}
		return result;
	}

	// Token: 0x06000A5F RID: 2655 RVA: 0x00052D08 File Offset: 0x00050F08
	public #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zoSyVTLOhKIN4()
	{
		return (#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074386), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zpNIt4u6hilEg));
	}

	// Token: 0x06000A60 RID: 2656 RVA: 0x00052D2C File Offset: 0x00050F2C
	private static #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zFKAQ83WoonkR(Dictionary<string, object> #=zXBVka1c=)
	{
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		foreach (string text in #=zXBVka1c=.Keys)
		{
			ResourceTypes resourceTypes = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zsJJ$G_g=(text);
			if (resourceTypes != ResourceTypes.Unknown)
			{
				#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.Add(new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(resourceTypes, JSONManager.ExtractIntSafe(#=zXBVka1c=, text, 0)));
			}
		}
		return #=zRq2AEW0okvKAl3LdOqWDdBwtgdy;
	}

	// Token: 0x06000A61 RID: 2657 RVA: 0x00052DA0 File Offset: 0x00050FA0
	private #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=zx47y_ykkWer2VbYIzA==(object #=zIRwPsGQY$M0r)
	{
		int @int = JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074373), 0);
		int int2 = JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074358), 0);
		int num = @int;
		foreach (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= in this.#=zC6pCNPvHlvvsjFd3wuxtDlE=())
		{
			if (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=zr6MSgaIVrD1E() == (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)1)
			{
				this.#=z$2ijYGRf0FB5().#=ztNr$6f$4jFpqECtQlA==(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=zMuFMjGQ=());
			}
			if (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=zr6MSgaIVrD1E() == (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)2)
			{
				num--;
			}
		}
		foreach (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2 in this.#=z0bat7_QugpCgKGwzpnRDXa8=())
		{
			if (#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zVVorJLug3m2L() == this.#=zQ4wZnctPyyRO().#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
			{
				num -= #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=2.#=zokCzXrV0ersD0W_QcNKZ29M=();
			}
		}
		return new #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY=(@int, num, int2);
	}

	// Token: 0x06000A62 RID: 2658 RVA: 0x00052EA4 File Offset: 0x000510A4
	public #=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY= #=z6IODMVzrU6HMa5LZg021HYs=()
	{
		return (#=zRq2AEW0okvKAl3LdOqWDdERbcuyGD641_3sXcUY=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074339), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zx47y_ykkWer2VbYIzA==));
	}

	// Token: 0x06000A63 RID: 2659 RVA: 0x00052EC8 File Offset: 0x000510C8
	private List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zQRQPdLo51sgfMAQG$BTTgPs=(object #=zIRwPsGQY$M0r)
	{
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074327));
		if (dictionary != null)
		{
			#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM= = #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95.#=zi1hFJwI=();
			foreach (object obj in dictionary.Values)
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi1hFJwI=((Dictionary<string, object>)obj, #=zC7NDbDM=);
				if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().Id != 0)
				{
					list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
				}
			}
		}
		return list;
	}

	// Token: 0x06000A64 RID: 2660 RVA: 0x00052F58 File Offset: 0x00051158
	public List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zXzBC$aJalrr0Db$QLCfSwSA=()
	{
		return (List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074304), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zQRQPdLo51sgfMAQG$BTTgPs=));
	}

	// Token: 0x06000A65 RID: 2661 RVA: 0x00052F7C File Offset: 0x0005117C
	private List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zmes$bJ8Lf7RxSZZYt7bJqF0LBjnu(object #=zIRwPsGQY$M0r)
	{
		return #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zJ6$WS1_8kX5n(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074037)));
	}

	// Token: 0x06000A66 RID: 2662 RVA: 0x00052F94 File Offset: 0x00051194
	public List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zdZA4x4oPUECN4Za4xxkSMFn4pxoU()
	{
		return (List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074016), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zmes$bJ8Lf7RxSZZYt7bJqF0LBjnu));
	}

	// Token: 0x06000A67 RID: 2663 RVA: 0x00052FB8 File Offset: 0x000511B8
	private #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a #=znEM$luZrbu4M5_IcUT5S1NM=(object #=zIRwPsGQY$M0r)
	{
		return new #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073994)));
	}

	// Token: 0x06000A68 RID: 2664 RVA: 0x00052FD0 File Offset: 0x000511D0
	public #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a #=zcVljhXy3TCOtJ0MIzgy$uEY=()
	{
		return (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073991), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=znEM$luZrbu4M5_IcUT5S1NM=));
	}

	// Token: 0x06000A69 RID: 2665 RVA: 0x00052FF4 File Offset: 0x000511F4
	private static #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zUEIv5c0n07pU(object #=zIRwPsGQY$M0r)
	{
		#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= = new #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=();
		DateTime dateTime = JSONManager.GetDateTime(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073964), false);
		if (dateTime > DateTime.Now)
		{
			List<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> list = #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=;
			#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== = new #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==();
			#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=zbsxKkj4=(500);
			#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==.#=zWtGpwQAJDMH_(dateTime);
			list.Add(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==);
		}
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073951));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				int @int = JSONManager.GetInt(array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073928), 0);
				if (@int > 0)
				{
					DateTime dateTime2 = JSONManager.GetDateTime(array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069968), false);
					if (dateTime2 > DateTime.Now)
					{
						List<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> list2 = #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=;
						#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==2 = new #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==();
						#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==2.#=zbsxKkj4=(@int);
						#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==2.#=zWtGpwQAJDMH_(dateTime2);
						list2.Add(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==2);
					}
				}
			}
		}
		object[] array2 = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073926));
		if (array2 != null)
		{
			int j = 0;
			while (j < array2.Length)
			{
				Dictionary<string, object> dictionary = (Dictionary<string, object>)array2[j];
				DateTime #=z$Ib9gYQ= = JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false);
				int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
				int #=z$Ib9gYQ=2;
				switch (num)
				{
				case 3:
					#=z$Ib9gYQ=2 = 204;
					goto IL_14C;
				case 4:
					#=z$Ib9gYQ=2 = 203;
					goto IL_14C;
				case 5:
					#=z$Ib9gYQ=2 = 205;
					goto IL_14C;
				default:
					if (num == 22)
					{
						#=z$Ib9gYQ=2 = 21008;
						goto IL_14C;
					}
					break;
				}
				IL_167:
				j++;
				continue;
				IL_14C:
				List<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> list3 = #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=;
				#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==3 = new #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==();
				#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==3.#=zbsxKkj4=(#=z$Ib9gYQ=2);
				#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==3.#=zWtGpwQAJDMH_(#=z$Ib9gYQ=);
				list3.Add(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==3);
				goto IL_167;
			}
		}
		object[] array3 = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074163));
		if (array3 != null)
		{
			foreach (Dictionary<string, object> dictionary2 in array3)
			{
				DateTime #=z$Ib9gYQ=3 = JSONManager.ExtractDate(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), false);
				if (JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0) == 9)
				{
					List<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> list4 = #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=;
					#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==4 = new #=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==();
					#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==4.#=zbsxKkj4=(8051);
					#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==4.#=zWtGpwQAJDMH_(#=z$Ib9gYQ=3);
					list4.Add(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==4);
				}
			}
		}
		return #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=;
	}

	// Token: 0x06000A6A RID: 2666 RVA: 0x000531F0 File Offset: 0x000513F0
	public #=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE= #=zMJwfeAYJPt8h1j02AQ==()
	{
		return (#=zzpeOU_JOtuYoQaG2RC5LChZFXUoSW0erXe7phZE=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074157), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zUEIv5c0n07pU));
	}

	// Token: 0x06000A6B RID: 2667 RVA: 0x00053214 File Offset: 0x00051414
	private List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=zLkO9zvw=(object #=zIRwPsGQY$M0r)
	{
		List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> list = new List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV>();
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074133));
		if (dictionary != null)
		{
			#=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== #=zC7NDbDM= = #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==.#=zi1hFJwI=();
			foreach (object obj in dictionary.Values)
			{
				Dictionary<string, object> #=zTUb1WaU= = (Dictionary<string, object>)obj;
				list.Add(new #=zF_m$qwkni_ep$nCra3nSOCYbdgBV(#=zTUb1WaU=, #=zC7NDbDM=));
			}
		}
		return list;
	}

	// Token: 0x06000A6C RID: 2668 RVA: 0x00053294 File Offset: 0x00051494
	public List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=zlHORuxrRT9tH()
	{
		return (List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074119), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zLkO9zvw=));
	}

	// Token: 0x06000A6D RID: 2669 RVA: 0x000532B8 File Offset: 0x000514B8
	private List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=zlwm47B5WYkr_(object #=zIRwPsGQY$M0r)
	{
		List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> list = new List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV>();
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074133));
		if (dictionary != null)
		{
			#=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== #=zC7NDbDM= = #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==.#=zi1hFJwI=();
			foreach (object obj in dictionary.Values)
			{
				#=zF_m$qwkni_ep$nCra3nSOCYbdgBV #=zF_m$qwkni_ep$nCra3nSOCYbdgBV = new #=zF_m$qwkni_ep$nCra3nSOCYbdgBV((Dictionary<string, object>)obj, #=zC7NDbDM=);
				if (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zi66ZCDXN_8bo() == (#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw=)0)
				{
					list.Add(#=zF_m$qwkni_ep$nCra3nSOCYbdgBV);
				}
			}
		}
		return list;
	}

	// Token: 0x06000A6E RID: 2670 RVA: 0x00053340 File Offset: 0x00051540
	public List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV> #=zSLoaXUvNBvPo()
	{
		return (List<#=zF_m$qwkni_ep$nCra3nSOCYbdgBV>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074103), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zlwm47B5WYkr_));
	}

	// Token: 0x06000A6F RID: 2671 RVA: 0x00053364 File Offset: 0x00051564
	private #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=z_Tpft49uOv8RpAIiRA==(object #=zIRwPsGQY$M0r)
	{
		#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU = new #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU();
		#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zC7NDbDM= = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=();
		Dictionary<int, string> #=zN$80B0SQg_1n = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zLhrZP_oyOsqr();
		object[] array = (object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074073));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ item = new #=zrDcgv9ny10MzDWIXXLpHLoin_0n$((Dictionary<string, object>)array[i], #=zC7NDbDM=, #=zN$80B0SQg_1n);
				#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Add(item);
			}
		}
		#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU.Sort(new #=zqII3ZIVy1$iuelenykucuBTnVTDod4GcSQ==(this.#=zQ4wZnctPyyRO().#=zv2Kyu17YrGOC().GeneralSpecRules));
		return #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU;
	}

	// Token: 0x06000A70 RID: 2672 RVA: 0x000533E4 File Offset: 0x000515E4
	public #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zdz_5DLjhAG09Q78wOA==()
	{
		return (#=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074059), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z_Tpft49uOv8RpAIiRA==));
	}

	// Token: 0x06000A71 RID: 2673 RVA: 0x00053408 File Offset: 0x00051608
	private #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI= #=z0Ip9raO2pR00dxZ6Vw==(object #=zIRwPsGQY$M0r)
	{
		#=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI= #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI= = new #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI=();
		object[] array = (object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073786));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns= item = new #=zlYHUrEN7mlAmikRbrDXJpP$c7KG4_Hc8ZeoySns=((Dictionary<string, object>)array[i]);
				#=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI=.Add(item);
			}
		}
		return #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI=;
	}

	// Token: 0x06000A72 RID: 2674 RVA: 0x00053458 File Offset: 0x00051658
	public #=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI= #=zwfEE1b14gF5xTRSrkA==()
	{
		return (#=z3wv4JxQ4At7cfIzvOqieBlzsUMd6Pmz0yzZ$YTI=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073780), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z0Ip9raO2pR00dxZ6Vw==));
	}

	// Token: 0x06000A73 RID: 2675 RVA: 0x0005347C File Offset: 0x0005167C
	private object #=zvGj7QS_Dz7_74zMkp_Su$emQ17JlItbgTg==(object #=zIRwPsGQY$M0r)
	{
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073764));
		return (array != null) ? array.Length : 0;
	}

	// Token: 0x06000A74 RID: 2676 RVA: 0x000534A8 File Offset: 0x000516A8
	public int #=zM1lSdzKzjSvlrfI1IQtcu4s6U4Jyx$Cl6A==()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073750), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zvGj7QS_Dz7_74zMkp_Su$emQ17JlItbgTg==));
	}

	// Token: 0x06000A75 RID: 2677 RVA: 0x000534CC File Offset: 0x000516CC
	private #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= #=zbIHFhtJeYwjNlwD_u4HR3cw=(object #=zIRwPsGQY$M0r)
	{
		return new #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=(JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073713)));
	}

	// Token: 0x06000A76 RID: 2678 RVA: 0x000534E4 File Offset: 0x000516E4
	public #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= #=zJt$4JjFDRj2sHIQvVXpOBcTazZMs()
	{
		return (#=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073702), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zbIHFhtJeYwjNlwD_u4HR3cw=));
	}

	// Token: 0x06000A77 RID: 2679 RVA: 0x00053508 File Offset: 0x00051708
	private List<int> #=zhZRzZbOc9FEtey9T_DsKO7E=(object #=zIRwPsGQY$M0r)
	{
		List<int> list = new List<int>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073675));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(Convert.ToInt32(array[i]));
			}
		}
		object[] array2 = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073669));
		if (array2 != null)
		{
			for (int j = 0; j < array2.Length; j++)
			{
				list.Add(Convert.ToInt32(array2[j]));
			}
		}
		return list;
	}

	// Token: 0x06000A78 RID: 2680 RVA: 0x00053580 File Offset: 0x00051780
	public List<int> #=zMYCcUNQPbrHkLN3oUFTD9SU=()
	{
		return (List<int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073911), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zhZRzZbOc9FEtey9T_DsKO7E=));
	}

	// Token: 0x06000A79 RID: 2681 RVA: 0x000535A4 File Offset: 0x000517A4
	private object #=z7KWSytVoruGRjVk_99Io6Zk=(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073881), 0);
	}

	// Token: 0x06000A7A RID: 2682 RVA: 0x000535BC File Offset: 0x000517BC
	public int #=zK2B3D5hNXDwHR1pT1hpYeOQ=()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073867), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z7KWSytVoruGRjVk_99Io6Zk=));
	}

	// Token: 0x06000A7B RID: 2683 RVA: 0x000535E0 File Offset: 0x000517E0
	private object #=zH4_jtImpt_nO(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073847), 0);
	}

	// Token: 0x06000A7C RID: 2684 RVA: 0x000535F8 File Offset: 0x000517F8
	public int #=zN$_0ciN4j1M9Es9_zg==()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073830), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zH4_jtImpt_nO));
	}

	// Token: 0x06000A7D RID: 2685 RVA: 0x0005361C File Offset: 0x0005181C
	private #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=zcLzyTHxpp883NzxqEQ==(object #=zIRwPsGQY$M0r)
	{
		return new #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=((object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073795)));
	}

	// Token: 0x06000A7E RID: 2686 RVA: 0x00053638 File Offset: 0x00051838
	public #=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o= #=zXtdX41TcXB7KvgMdHw==()
	{
		return (#=zYICw4JxwhSLjn8tLJp81wyTtmHjqvMoZmHBgt4o=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073533), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zcLzyTHxpp883NzxqEQ==));
	}

	// Token: 0x06000A7F RID: 2687 RVA: 0x0005365C File Offset: 0x0005185C
	private object #=zlZjnJrC5Tt4sYLaOifUz71M=(object #=zIRwPsGQY$M0r)
	{
		return (int)Math.Ceiling(JSONManager.GetDouble(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073516), 0.0));
	}

	// Token: 0x06000A80 RID: 2688 RVA: 0x00053684 File Offset: 0x00051884
	public int #=zpvsaXyw82VkgOoZDJ1UnGfgei5Rf()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073502), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zlZjnJrC5Tt4sYLaOifUz71M=));
	}

	// Token: 0x06000A81 RID: 2689 RVA: 0x000536A8 File Offset: 0x000518A8
	private #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO #=zE$7nMc4=(object #=zIRwPsGQY$M0r)
	{
		return this.#=zE$7nMc4=(false, #=zIRwPsGQY$M0r);
	}

	// Token: 0x06000A82 RID: 2690 RVA: 0x000536B4 File Offset: 0x000518B4
	private #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO #=zE$7nMc4=(bool #=zqq5Z8gwE9e4N, object #=zIRwPsGQY$M0r)
	{
		Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=> #=zBIFu03PsP74P = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zTWc1gtYKnjc_();
		#=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO = new #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO();
		object obj = null;
		if (#=zqq5Z8gwE9e4N && this.#=zQ4wZnctPyyRO().#=z5WD8BTn54npdaX13Rg==() < DateTime.Now - TimeSpan.FromMinutes(5.0))
		{
			try
			{
				string text = this.#=z$2ijYGRf0FB5().#=zi3Aa1spKVns7();
				if (text.Length > 10000)
				{
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073475), Array.Empty<object>());
					obj = JSONManager.GetData(text);
					this.#=zQ4wZnctPyyRO().#=zW3LvHA20HtNnpfcb9g==(DateTime.Now);
				}
				else
				{
					this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073418), new object[]
					{
						JSONManager.Cut(text)
					});
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=zQ4wZnctPyyRO().#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zQmveeqwfZtWH, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073630), new object[]
				{
					#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=)
				});
			}
		}
		if (obj == null)
		{
			obj = #=zIRwPsGQY$M0r;
		}
		object[] array = (object[])JSONManager.GetObject(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073573));
		if (array != null)
		{
			object[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV = new #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV((Dictionary<string, object>)array2[i], #=zBIFu03PsP74P);
				if (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zzuDU5U9dTvAm())
				{
					if (!#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zi2a1Q$EWsrif())
					{
						#=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO.#=zCrb91gPnuXNh().Add(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV);
					}
					else
					{
						#=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO.#=zmtBGC_gcapNu().Add(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV);
					}
				}
			}
		}
		return #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO;
	}

	// Token: 0x06000A83 RID: 2691 RVA: 0x00053844 File Offset: 0x00051A44
	public #=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO #=zR7HYJ3$A4H5B()
	{
		return (#=zuE0GAZJB9g3OVNz_GgMRIaClDxqdQ_Hr5zg_hNfoqTZO)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073558), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zE$7nMc4=));
	}

	// Token: 0x06000A84 RID: 2692 RVA: 0x00053868 File Offset: 0x00051A68
	private List<int> #=zxw1bOi4573HAB0iXbDEofK8=(object #=zIRwPsGQY$M0r)
	{
		List<int> list = new List<int>();
		object[] array = (object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073542));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				int item = Convert.ToInt32(((Dictionary<string, object>)array[i])[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]);
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06000A85 RID: 2693 RVA: 0x000538C8 File Offset: 0x00051AC8
	public List<int> #=z_zzDSQCAp84Wuuup9dIcR2c=()
	{
		return (List<int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058931), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zxw1bOi4573HAB0iXbDEofK8=));
	}

	// Token: 0x06000A86 RID: 2694 RVA: 0x000538EC File Offset: 0x00051AEC
	private object #=zyQOsPpym93CRhcWTn$GUMMI=(object #=zIRwPsGQY$M0r)
	{
		int num = JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058918), 0);
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073951));
		if (array != null)
		{
			foreach (Dictionary<string, object> obj in array)
			{
				if (JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0) == 74)
				{
					num += JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058899), 0);
					break;
				}
			}
		}
		return num;
	}

	// Token: 0x06000A87 RID: 2695 RVA: 0x0005396C File Offset: 0x00051B6C
	public int #=ztY2Wai5zsO_u1Ct5WFVJPR0=()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058889), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zyQOsPpym93CRhcWTn$GUMMI=));
	}

	// Token: 0x06000A88 RID: 2696 RVA: 0x00053990 File Offset: 0x00051B90
	private object #=zfrLgAeDIZfWrR3FUQw==(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058865), 0);
	}

	// Token: 0x06000A89 RID: 2697 RVA: 0x000539A8 File Offset: 0x00051BA8
	public int #=z9Jm$ne_kr_H5D_R8UQ==()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058850), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zfrLgAeDIZfWrR3FUQw==));
	}

	// Token: 0x06000A8A RID: 2698 RVA: 0x000539CC File Offset: 0x00051BCC
	private object #=z0iSEuS_cOf2JmFmMzT7S6$w=(object #=zIRwPsGQY$M0r)
	{
		int num = 0;
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058824));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045)]) == 1)
				{
					num = Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759)]);
				}
			}
		}
		return num;
	}

	// Token: 0x06000A8B RID: 2699 RVA: 0x00053A40 File Offset: 0x00051C40
	public int #=zI7RuwYzM63XbHtSFc9y0Q831FDC2()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058821), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z0iSEuS_cOf2JmFmMzT7S6$w=));
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x00053A64 File Offset: 0x00051C64
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zqTc60j1DLBJR(object #=zIRwPsGQY$M0r)
	{
		List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> list = new List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>();
		object[] array = (object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059045));
		object[] array2 = (object[])JSONManager.GetObject(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399));
		int num = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zLTcKZ4NeSgHgtq5frELA$x0=();
		if (num != 1)
		{
			if (num == 2)
			{
				string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059030), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), JSONManager.FixStringForFileName(this.#=zQ4wZnctPyyRO().#=zh5Q$jgycqA15().#=z9Yordw6ZFjQe()), this.#=zQ4wZnctPyyRO().#=zYgvZuBwR$a1C());
				if (array2 != null)
				{
					#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, JSONManager.SerializeData(array2), Encoding.UTF8, false);
				}
				else
				{
					try
					{
						if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
						{
							array2 = (object[])JSONManager.DeserializeData(#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=));
						}
					}
					catch
					{
					}
				}
			}
		}
		else if (array2 != null)
		{
			this.#=zQ4wZnctPyyRO().#=z2qORYNmMpSU7().#=zuGvzZzWjmxxsQeny2A==(array2);
		}
		else
		{
			array2 = this.#=zQ4wZnctPyyRO().#=z2qORYNmMpSU7().#=zJwqmcdMgqCCbmR3NGQ==();
		}
		if (array != null && array2 != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(new #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==((Dictionary<string, object>)array[i], array2));
			}
		}
		return list;
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x00053B98 File Offset: 0x00051D98
	public List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zw$fMJ65lvs2ECx153Q==()
	{
		return (List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058990), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zqTc60j1DLBJR));
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00053BBC File Offset: 0x00051DBC
	private object #=zfP$xX9EkmflG(object #=zIRwPsGQY$M0r)
	{
		DateTime dateTime = JSONManager.GetDateTime(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false);
		if (dateTime == DateTime.MinValue)
		{
			dateTime = JSONManager.GetDateTime(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058971), false);
		}
		return dateTime;
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x00053C00 File Offset: 0x00051E00
	public DateTime #=zZan5aKOWyPR5()
	{
		return (DateTime)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058961), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zfP$xX9EkmflG));
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00053C24 File Offset: 0x00051E24
	private object #=zg6y3EuTcpMD8(object #=zIRwPsGQY$M0r)
	{
		long @long = JSONManager.GetLong(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0L);
		if (@long == 0L)
		{
			@long = JSONManager.GetLong(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058971), 0L);
		}
		return @long;
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00053C60 File Offset: 0x00051E60
	public long #=zqCMgNvOChEJ_GNc9ng==()
	{
		return (long)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058683), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zg6y3EuTcpMD8));
	}

	// Token: 0x06000A92 RID: 2706 RVA: 0x00053C84 File Offset: 0x00051E84
	private List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> #=zuqy2q9TqP27_(object #=zIRwPsGQY$M0r)
	{
		List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> list = new List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058662));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(new #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==((Dictionary<string, object>)array[i]));
			}
		}
		return list;
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x00053CD0 File Offset: 0x00051ED0
	public List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> #=z0jPLsvetj9_C()
	{
		return (List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058643), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zuqy2q9TqP27_));
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x00053CF4 File Offset: 0x00051EF4
	private List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=z6yMGOu3Gis99t8BS6A==(object #=zIRwPsGQY$M0r)
	{
		List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> list = new List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058629));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(new #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=((Dictionary<string, object>)array[i]));
			}
		}
		return list;
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x00053D40 File Offset: 0x00051F40
	public List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=ztGw3z50365iN60O4zw==()
	{
		return (List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058615), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z6yMGOu3Gis99t8BS6A==));
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x00053D64 File Offset: 0x00051F64
	private List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=zhYtIWRCzksdUhWBaRA==(object #=zIRwPsGQY$M0r)
	{
		List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> list = new List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058596));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(new #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=((Dictionary<string, object>)array[i]));
			}
		}
		return list;
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x00053DB0 File Offset: 0x00051FB0
	public List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=zOeHheEjaWrYHJfQ93g0lcRk=()
	{
		return (List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058582), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zhYtIWRCzksdUhWBaRA==));
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00053DD4 File Offset: 0x00051FD4
	private List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=> #=zHFLS0WcdA8lPwjMdUPh3AgE=(object #=zIRwPsGQY$M0r)
	{
		List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=> list = new List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058814));
		if (array != null)
		{
			Dictionary<int, string> #=z8OQAqQM4bxMSTfrG$jokQHA= = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q= #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q= = new #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=((Dictionary<string, object>)array[i], #=z8OQAqQM4bxMSTfrG$jokQHA=);
				if (#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zY1MCywb8bWJeKmolJ4iPMDZERdKEI_Ze0w==())
				{
					list.Add(#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=);
				}
			}
		}
		return list;
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x00053E30 File Offset: 0x00052030
	public List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=> #=zD7i9E2p9S0C8eRGxb8a0W5g=()
	{
		return (List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058795), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zHFLS0WcdA8lPwjMdUPh3AgE=));
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x00053E54 File Offset: 0x00052054
	private string #=zPmWxjPDsqAQP(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetString(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058782), null);
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00053E68 File Offset: 0x00052068
	public string #=zTqDBdc7DKJmY()
	{
		return (string)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058763), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zPmWxjPDsqAQP));
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x00053E8C File Offset: 0x0005208C
	private List<int> #=zZB3GbqYSjXgwz_Utqw==(object #=zIRwPsGQY$M0r)
	{
		List<int> list = new List<int>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058746));
		if (array != null)
		{
			foreach (Dictionary<string, object> dictionary in array)
			{
				if (JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058740), 0) > 0)
				{
					int num = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), -1);
					if (num >= 0)
					{
						list.Add(num);
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x00053F04 File Offset: 0x00052104
	public List<int> #=zOgsCl1czA8I8AjiIYrYxL5E=()
	{
		return (List<int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058722), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zZB3GbqYSjXgwz_Utqw==));
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x00053F28 File Offset: 0x00052128
	private List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=> #=z3F14s$s$0BKx$FTKcA==(object #=zIRwPsGQY$M0r)
	{
		List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=> list = new List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058701));
		if (array != null)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(new #=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=((Dictionary<string, object>)array[i]));
			}
		}
		return list;
	}

	// Token: 0x06000A9F RID: 2719 RVA: 0x00053F78 File Offset: 0x00052178
	public List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=> #=zdhEyxXTc3Fd_5GqmBgR3nOA=()
	{
		return (List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058424), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z3F14s$s$0BKx$FTKcA==));
	}

	// Token: 0x06000AA0 RID: 2720 RVA: 0x00053F9C File Offset: 0x0005219C
	private List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=> #=zjj6gaAuhrFhZFwN9GeySxVM=(object #=zIRwPsGQY$M0r)
	{
		List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=> list = new List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058403));
		if (array != null)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc= #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc= = new #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=((Dictionary<string, object>)array[i]);
				if (#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=.#=zcdH4JVnr8AGe4boeg9Ke5Kw=().Count > 0)
				{
					list.Add(#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=);
				}
			}
		}
		return list;
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00053FFC File Offset: 0x000521FC
	public List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=> #=zM01CQPcCrs_$HSTsmq1O62c=()
	{
		return (List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058386), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zjj6gaAuhrFhZFwN9GeySxVM=));
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00054020 File Offset: 0x00052220
	private List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=> #=zH4_tVQELW$J71RfISbqa$bE=(object #=zIRwPsGQY$M0r)
	{
		List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=> list = new List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058361));
		if (array != null)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw= #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw= = new #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=((Dictionary<string, object>)array[i]);
				if (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zFGyhIvqZjyZD())
				{
					list.Add(#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=);
				}
			}
		}
		return list;
	}

	// Token: 0x06000AA3 RID: 2723 RVA: 0x0005407C File Offset: 0x0005227C
	public List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=> #=zzigOkvJbQiWAdLJxy5rDqiA=()
	{
		return (List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058346), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zH4_tVQELW$J71RfISbqa$bE=));
	}

	// Token: 0x06000AA4 RID: 2724 RVA: 0x000540A0 File Offset: 0x000522A0
	private List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> #=zU4jT26LvHzkrR3ooqw==(object #=zIRwPsGQY$M0r)
	{
		UnitTypeCollection #=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> list = new List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058334));
		if (array != null)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ= item = new #=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=((Dictionary<string, object>)array[i], #=zlhLE8UQVU0AG);
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06000AA5 RID: 2725 RVA: 0x000540FC File Offset: 0x000522FC
	public List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=> #=zH7Kyf1cf3kepnPM4Mg==()
	{
		return (List<#=z0gbJnPInxajeoDjA72kIf2QeinmssCqwYr1qCVQ=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058312), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zU4jT26LvHzkrR3ooqw==));
	}

	// Token: 0x06000AA6 RID: 2726 RVA: 0x00054120 File Offset: 0x00052320
	private object #=zDHA5mW0rFRJw(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058559), 0);
	}

	// Token: 0x06000AA7 RID: 2727 RVA: 0x00054138 File Offset: 0x00052338
	public int #=z6Kl4FbeUhsIC()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058542), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zDHA5mW0rFRJw));
	}

	// Token: 0x06000AA8 RID: 2728 RVA: 0x0005415C File Offset: 0x0005235C
	private List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=zJxsBzqf33oG1j0hN5kl4Zas=(object #=zIRwPsGQY$M0r)
	{
		List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> list = new List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058521));
		if (array != null)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zVaSbJ9QgCetWbEk6RflqOR6esC81();
			for (int i = 0; i < array.Length; i++)
			{
				#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl item = new #=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl((Dictionary<string, object>)array[i]);
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06000AA9 RID: 2729 RVA: 0x000541B0 File Offset: 0x000523B0
	public List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=zIQDLqtJxqgZWX88MoNdeTR0k5rMf()
	{
		return (List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058505), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zJxsBzqf33oG1j0hN5kl4Zas=));
	}

	// Token: 0x06000AAA RID: 2730 RVA: 0x000541D4 File Offset: 0x000523D4
	private object #=z2YDcwL2lTiK1r_ElhB9_ituv4cOE(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058474), 0);
	}

	// Token: 0x06000AAB RID: 2731 RVA: 0x000541EC File Offset: 0x000523EC
	public int #=zYubRv_IdFXo9HaY2Cyq8ABQsCryc()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058458), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z2YDcwL2lTiK1r_ElhB9_ituv4cOE));
	}

	// Token: 0x06000AAC RID: 2732 RVA: 0x00054210 File Offset: 0x00052410
	private Dictionary<int, int> #=zPwtsJ7MoNlkVAR9E$w==(object #=zIRwPsGQY$M0r)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058169));
		if (dictionary2 != null)
		{
			foreach (string text in dictionary2.Keys)
			{
				dictionary.Add(Convert.ToInt32(text), Convert.ToInt32(dictionary2[text]));
			}
		}
		return dictionary;
	}

	// Token: 0x06000AAD RID: 2733 RVA: 0x00054290 File Offset: 0x00052490
	public Dictionary<int, int> #=zADpc34x0JAcLsjuojA==()
	{
		return (Dictionary<int, int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058152), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zPwtsJ7MoNlkVAR9E$w==));
	}

	// Token: 0x06000AAE RID: 2734 RVA: 0x000542B4 File Offset: 0x000524B4
	private List<int> #=zOjs3Y71oUMaKkOXUaao9LRruPAMB(object #=zIRwPsGQY$M0r)
	{
		List<int> list = new List<int>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058140));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				int item = JSONManager.ExtractInt((Dictionary<string, object>)array[i], #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0);
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06000AAF RID: 2735 RVA: 0x0005430C File Offset: 0x0005250C
	public List<int> #=zBnIJzUc1DkPSZ7$ymfBtn86ykUhA8cj6fg==()
	{
		return (List<int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058121), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zOjs3Y71oUMaKkOXUaao9LRruPAMB));
	}

	// Token: 0x06000AB0 RID: 2736 RVA: 0x00054330 File Offset: 0x00052530
	private #=zzS0pbMw01ynYpU6HGrcRitcMYEI6a9XsQw== #=z151uRUhZLy6E(object #=zIRwPsGQY$M0r)
	{
		UnitTypeCollection #=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058102));
		Dictionary<string, object> dictionary2 = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058083));
		int @int = JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058076), 0);
		return new #=zzS0pbMw01ynYpU6HGrcRitcMYEI6a9XsQw==(#=zlhLE8UQVU0AG, dictionary, dictionary2, @int);
	}

	// Token: 0x06000AB1 RID: 2737 RVA: 0x00054380 File Offset: 0x00052580
	public #=zzS0pbMw01ynYpU6HGrcRitcMYEI6a9XsQw== #=zZ5ysN0XHtuWT()
	{
		return (#=zzS0pbMw01ynYpU6HGrcRitcMYEI6a9XsQw==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058056), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z151uRUhZLy6E));
	}

	// Token: 0x06000AB2 RID: 2738 RVA: 0x000543A4 File Offset: 0x000525A4
	private object #=zSVVnP82Sh9YCKBgLDODxMTU=(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetDateTime(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058294), false);
	}

	// Token: 0x06000AB3 RID: 2739 RVA: 0x000543BC File Offset: 0x000525BC
	public DateTime #=zjVMzCR4MCwpUphuGNUeoxDg=()
	{
		return (DateTime)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058275), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zSVVnP82Sh9YCKBgLDODxMTU=));
	}

	// Token: 0x06000AB4 RID: 2740 RVA: 0x000543E0 File Offset: 0x000525E0
	public static #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA== #=z0ppPOLHUP72Y(object #=zR9JhC8w=)
	{
		return new #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA==(JSONManager.GetDictionary(#=zR9JhC8w=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058261)));
	}

	// Token: 0x06000AB5 RID: 2741 RVA: 0x000543F8 File Offset: 0x000525F8
	private #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA== #=zs1ED1qAWlBb_(object #=zIRwPsGQY$M0r)
	{
		return #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=z0ppPOLHUP72Y(#=zIRwPsGQY$M0r);
	}

	// Token: 0x06000AB6 RID: 2742 RVA: 0x00054400 File Offset: 0x00052600
	public #=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA== #=zDfAwKkK4E7L_()
	{
		return (#=zVBRbe2nsNjc8m8Rq3rGUzEBO71yMq9qFwA==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058244), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zs1ED1qAWlBb_));
	}

	// Token: 0x06000AB7 RID: 2743 RVA: 0x00054424 File Offset: 0x00052624
	private List<int> #=zsLY6OefAz56t(object #=zIRwPsGQY$M0r)
	{
		List<int> list = new List<int>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058223));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				list.Add(Convert.ToInt32(array[i]));
			}
		}
		return list;
	}

	// Token: 0x06000AB8 RID: 2744 RVA: 0x00054468 File Offset: 0x00052668
	public List<int> #=zFRCk0rwJNk$_()
	{
		return (List<int>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058200), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zsLY6OefAz56t));
	}

	// Token: 0x06000AB9 RID: 2745 RVA: 0x0005448C File Offset: 0x0005268C
	private #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg== #=zrDZKY5huN2rL3gs0yveHgMPOtmmE(object #=zIRwPsGQY$M0r)
	{
		return new #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909058176)));
	}

	// Token: 0x06000ABA RID: 2746 RVA: 0x000544A4 File Offset: 0x000526A4
	public #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg== #=zJr5eDmz2tzFDBh7JHtfBZy3IVxFG()
	{
		return (#=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059967), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zrDZKY5huN2rL3gs0yveHgMPOtmmE));
	}

	// Token: 0x06000ABB RID: 2747 RVA: 0x000544C8 File Offset: 0x000526C8
	private List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx> #=zScTmxyZGJrtGYsc_ZaU9USdV27Ps(object #=zIRwPsGQY$M0r)
	{
		List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx> list = new List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059941));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx item = new #=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx((Dictionary<string, object>)array[i]);
				list.Add(item);
			}
		}
		return list;
	}

	// Token: 0x06000ABC RID: 2748 RVA: 0x00054514 File Offset: 0x00052714
	public List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx> #=zlE3M25JOMzd3SHkB_pEM1BwNCci8()
	{
		return (List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059927), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zScTmxyZGJrtGYsc_ZaU9USdV27Ps));
	}

	// Token: 0x06000ABD RID: 2749 RVA: 0x00054538 File Offset: 0x00052738
	private List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=> #=zUNJweciETr9xnaDpXbNzDks=(object #=zIRwPsGQY$M0r)
	{
		List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=> list = new List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=>();
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059901));
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM= #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM= = new #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=((Dictionary<string, object>)array[i]);
				if (#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zKepaJ_crgOAGyqrTzo7ij1Y=() >= 0)
				{
					list.Add(#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=);
				}
			}
		}
		return list;
	}

	// Token: 0x06000ABE RID: 2750 RVA: 0x0005458C File Offset: 0x0005278C
	public List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=> #=zwbAh2BjlA1lknFqfbiwumHA=()
	{
		return (List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059887), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zUNJweciETr9xnaDpXbNzDks=));
	}

	// Token: 0x06000ABF RID: 2751 RVA: 0x000545B0 File Offset: 0x000527B0
	private #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y= #=zQAwz0_gvChhmwb2ctA==(object #=zIRwPsGQY$M0r)
	{
		return new #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059860)));
	}

	// Token: 0x06000AC0 RID: 2752 RVA: 0x000545C8 File Offset: 0x000527C8
	public #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y= #=z0aG$0zVW5aRTUSbdPg==()
	{
		return (#=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060095), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zQAwz0_gvChhmwb2ctA==));
	}

	// Token: 0x06000AC1 RID: 2753 RVA: 0x000545EC File Offset: 0x000527EC
	private #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg== #=z_c2jIMdQ_g87Bu2vCjBgw8OQu2Lg(object #=zIRwPsGQY$M0r)
	{
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060069));
		#=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg== #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg== = new #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg==();
		foreach (string text in dictionary.Keys)
		{
			int key;
			if (int.TryParse(text, out key))
			{
				#=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg==[key] = JSONManager.ExtractInt(dictionary, text, 0);
			}
		}
		return #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg==;
	}

	// Token: 0x06000AC2 RID: 2754 RVA: 0x0005466C File Offset: 0x0005286C
	public #=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg== #=zenagxaQHGwureoGqsIwstGKcJLNw()
	{
		return (#=zd0$9AkYdfkU9ef5bn0sdMI9pxd1UwT5DFGYj$S0VNYEqgNSzEg==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060055), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z_c2jIMdQ_g87Bu2vCjBgw8OQu2Lg));
	}

	// Token: 0x06000AC3 RID: 2755 RVA: 0x00054690 File Offset: 0x00052890
	private #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew== #=ztvTpShAcDNSt(object #=zIRwPsGQY$M0r)
	{
		#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=zY6BuiKQeE9Eb = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zPeypy81OWeno();
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060016));
		#=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew== result;
		if (dictionary != null)
		{
			result = new #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew==(dictionary, #=zY6BuiKQeE9Eb);
		}
		else
		{
			result = new #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew==();
		}
		return result;
	}

	// Token: 0x06000AC4 RID: 2756 RVA: 0x000546C8 File Offset: 0x000528C8
	public #=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew== #=zqm6T_XR3NwZ2()
	{
		return (#=zUG_jF4MFrn8TZZ1SxiYcgYvmHmIlCQ4iew==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060015), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=ztvTpShAcDNSt));
	}

	// Token: 0x06000AC5 RID: 2757 RVA: 0x000546EC File Offset: 0x000528EC
	private Dictionary<int, List<int>> #=z_bel$nwTnc16EplNHYN$aYGe2iLVbmjcQ0wG0TXS2iymSsqJuA==(object #=zIRwPsGQY$M0r)
	{
		object[] array = JSONManager.GetArray(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059991));
		if (array != null)
		{
			return #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zRNMbzapw7YG$2TckgCczwJRgHdTL$EF1cA==().#=zg7WszcBuQb1OUXsJ6UON5uI=(array);
		}
		return new Dictionary<int, List<int>>();
	}

	// Token: 0x06000AC6 RID: 2758 RVA: 0x00054720 File Offset: 0x00052920
	public Dictionary<int, List<int>> #=zAAtBlefTGfzeH317bDlnzkkaPBd67ajQ3B8Q5_AB6wLk2ABlyQ==()
	{
		return (Dictionary<int, List<int>>)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059969), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z_bel$nwTnc16EplNHYN$aYGe2iLVbmjcQ0wG0TXS2iymSsqJuA==));
	}

	// Token: 0x06000AC7 RID: 2759 RVA: 0x00054744 File Offset: 0x00052944
	private #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ== #=zNVsOzItF$LKLu734Qw==(object #=zIRwPsGQY$M0r)
	{
		return new #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ==(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059675)));
	}

	// Token: 0x06000AC8 RID: 2760 RVA: 0x0005475C File Offset: 0x0005295C
	public #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ== #=zJTtJgwWTp9gijtuuAA==()
	{
		return (#=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059670), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zNVsOzItF$LKLu734Qw==));
	}

	// Token: 0x06000AC9 RID: 2761 RVA: 0x00054780 File Offset: 0x00052980
	private #=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA== #=z1bN7yTJeDP_r(object #=zIRwPsGQY$M0r)
	{
		return new #=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA==(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059643)));
	}

	// Token: 0x06000ACA RID: 2762 RVA: 0x00054798 File Offset: 0x00052998
	public #=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA== #=zRuSBNTbcss_PPA9pNg==()
	{
		return (#=zm8oYXwCeAmzhsiDRD5dUR_DFdSgV92zCzA==)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059639), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=z1bN7yTJeDP_r));
	}

	// Token: 0x06000ACB RID: 2763 RVA: 0x000547BC File Offset: 0x000529BC
	private #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw= #=zXWBryHQm4QJ7$EveAg==(object #=zIRwPsGQY$M0r)
	{
		return new #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=(JSONManager.GetDictionary(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059600)));
	}

	// Token: 0x06000ACC RID: 2764 RVA: 0x000547D4 File Offset: 0x000529D4
	public #=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw= #=zLpfQR4rCsLNX6jyhnw==()
	{
		return (#=zmzHZid6mM4uEslxmAGWNBi$7MzUsazQZDZFSerw=)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059596), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zXWBryHQm4QJ7$EveAg==));
	}

	// Token: 0x06000ACD RID: 2765 RVA: 0x000547F8 File Offset: 0x000529F8
	private object #=zjSRuO5aC2h9B5AxgvCv_zqs=(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059827), 0);
	}

	// Token: 0x06000ACE RID: 2766 RVA: 0x00054810 File Offset: 0x00052A10
	public int #=zoVA6$xcZ4s_kK6oLGzNOhWE=()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059810), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zjSRuO5aC2h9B5AxgvCv_zqs=));
	}

	// Token: 0x06000ACF RID: 2767 RVA: 0x00054834 File Offset: 0x00052A34
	private object #=zQhb_eR2PEcgojeojrQ==(object #=zIRwPsGQY$M0r)
	{
		return JSONManager.GetInt(#=zIRwPsGQY$M0r, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059779), 0);
	}

	// Token: 0x06000AD0 RID: 2768 RVA: 0x0005484C File Offset: 0x00052A4C
	public int #=zjp4T2o8sDgUmdadFiw==()
	{
		return (int)this.#=zSxiy4fI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059772), new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zCwkSZzY=(this.#=zQhb_eR2PEcgojeojrQ==));
	}

	// Token: 0x040005C1 RID: 1473
	private static string #=z5XRHUJ90tOjWip9hCDzQD_g=;

	// Token: 0x040005C2 RID: 1474
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zXqKwUc4=;

	// Token: 0x040005C3 RID: 1475
	private #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zQmveeqwfZtWH;

	// Token: 0x040005C4 RID: 1476
	private #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zpS65XT65S2pT;

	// Token: 0x040005C5 RID: 1477
	private Dictionary<string, object> #=z9HdGFQI=;

	// Token: 0x040005C6 RID: 1478
	private object #=zbvBtlZaWfruxOBtacPCk0Rk=;

	// Token: 0x040005C7 RID: 1479
	private string #=zW88Ww4GRpWuygJ5Pfw==;

	// Token: 0x040005C8 RID: 1480
	private bool #=zzz7qrZKi8nJl6jGrqr_u63Dp0I4n;

	// Token: 0x02000178 RID: 376
	private sealed class #=zBCnTChVbdugYhUcjAg==
	{
		// Token: 0x06000AD2 RID: 2770 RVA: 0x00054878 File Offset: 0x00052A78
		public UnitSquadCollection #=zT3KU1ttOKQGxrLutU1n1UV4_i0Wq()
		{
			return this.#=zA6iq7hynoj4OTz4fgm4UuD0FfPARsB3lXQ==;
		}

		// Token: 0x06000AD3 RID: 2771 RVA: 0x00054880 File Offset: 0x00052A80
		public void #=zmJQbUL_pBinpxJ6J6aIsTKKr$prD(UnitSquadCollection #=z$Ib9gYQ=)
		{
			this.#=zA6iq7hynoj4OTz4fgm4UuD0FfPARsB3lXQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000AD4 RID: 2772 RVA: 0x0005488C File Offset: 0x00052A8C
		public UnitSquadCollection #=zxbmGqPOMiA5Vj98ROwlDDag=()
		{
			return this.#=zjUDfeEaZZY42LMpsLnVzcMsELW7yFhc_Ow==;
		}

		// Token: 0x06000AD5 RID: 2773 RVA: 0x00054894 File Offset: 0x00052A94
		public void #=zLWIW5kq2HhxLBLYwqVn$ckU=(UnitSquadCollection #=z$Ib9gYQ=)
		{
			this.#=zjUDfeEaZZY42LMpsLnVzcMsELW7yFhc_Ow== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000AD6 RID: 2774 RVA: 0x000548A0 File Offset: 0x00052AA0
		public List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zdG3ICWKpS3SqzRhweg==()
		{
			return this.#=zv__3p66ZUCcnL3$t0DEZt3CBuQFd;
		}

		// Token: 0x06000AD7 RID: 2775 RVA: 0x000548A8 File Offset: 0x00052AA8
		public void #=z$ciwFejl0v_HCHJnkQ==(List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=z$Ib9gYQ=)
		{
			this.#=zv__3p66ZUCcnL3$t0DEZt3CBuQFd = #=z$Ib9gYQ=;
		}

		// Token: 0x040005C9 RID: 1481
		private UnitSquadCollection #=zA6iq7hynoj4OTz4fgm4UuD0FfPARsB3lXQ==;

		// Token: 0x040005CA RID: 1482
		private UnitSquadCollection #=zjUDfeEaZZY42LMpsLnVzcMsELW7yFhc_Ow==;

		// Token: 0x040005CB RID: 1483
		private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zv__3p66ZUCcnL3$t0DEZt3CBuQFd;
	}

	// Token: 0x02000179 RID: 377
	// (Invoke) Token: 0x06000AD9 RID: 2777
	private delegate object #=zCwkSZzY=(object #=zIRwPsGQY$M0r);

	// Token: 0x0200017A RID: 378
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000ADE RID: 2782 RVA: 0x000548C8 File Offset: 0x00052AC8
		internal bool #=zsTSQxC9jqLOce48Nn6nBEwrr$OTi(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11804;
		}

		// Token: 0x06000ADF RID: 2783 RVA: 0x000548D8 File Offset: 0x00052AD8
		internal bool #=zcsnsnOCtdJVrCMPNzNZ6PvxD$Wjy(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11800;
		}

		// Token: 0x06000AE0 RID: 2784 RVA: 0x000548E8 File Offset: 0x00052AE8
		internal bool #=zkZuhj97ct1jE1wJxKCszeeV0gjIs(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11801;
		}

		// Token: 0x06000AE1 RID: 2785 RVA: 0x000548F8 File Offset: 0x00052AF8
		internal bool #=zELPrCPCD5OtsPv$W3JjWJjVxouKz(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11802;
		}

		// Token: 0x06000AE2 RID: 2786 RVA: 0x00054908 File Offset: 0x00052B08
		internal bool #=z8pteX8apNXZOtAZMcoWV22ZullgS(#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zMuFMjGQ=() == 11803;
		}

		// Token: 0x040005CC RID: 1484
		public static readonly #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU= #=zLkw0NRU= = new #=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zyDNvciU=();

		// Token: 0x040005CD RID: 1485
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=z92Fvn_h0LfbgNItN7g==;

		// Token: 0x040005CE RID: 1486
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zFnlA0pvqZRii0z7xQw==;

		// Token: 0x040005CF RID: 1487
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zEhBrhppgDYF9NhsMJg==;

		// Token: 0x040005D0 RID: 1488
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zb22AnG8h$xb8zb1$eQ==;

		// Token: 0x040005D1 RID: 1489
		public static Predicate<#=z2neEHCqEkW$0KUCU269IR$zST7pTAvwpYQ==> #=zeDFcnpc4a2XALpuk0A==;
	}
}
