﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001D3 RID: 467
internal sealed class #=zXhFnYdTTY8SF8XFn2TuXIY$gEvP3RhBHpW_QQpv2DockZ6DXweXRLGjLesnD : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000E0F RID: 3599 RVA: 0x00071268 File Offset: 0x0006F468
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zB5vEcEpTJLMd = #=zuJjQ1XU=.#=zR7HYJ3$A4H5B().#=zmtBGC_gcapNu();
	}

	// Token: 0x06000E10 RID: 3600 RVA: 0x0007127C File Offset: 0x0006F47C
	protected override void #=zvb5bnug=()
	{
		foreach (#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV in this.#=zB5vEcEpTJLMd)
		{
			if (!(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zTC2S$D65wv_r() < DateTime.Now - TimeSpan.FromDays(7.0)) || #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zdYIzg6l2nfKFX3LUnA==(this.#=z8StzeqE=))
			{
				int[] array = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zS7kcg6b8uXh$0NvnBDcz6Ys=();
				if (array != null)
				{
					int num = -1;
					int num2 = 9999;
					for (int i = 0; i < array.Length; i++)
					{
						int item = array[i];
						int num3 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().VeorLocaBonusesIds.IndexOf(item);
						if (num3 >= 0 && num3 < num2)
						{
							num = i;
							num2 = num3;
						}
					}
					if (num < 0 && array.Length != 0)
					{
						num = 0;
					}
					if (num >= 0)
					{
						#=zzpeOU_JOtuYoQaG2RC5LCvHWG30aBu6CAw== #=zzpeOU_JOtuYoQaG2RC5LCvHWG30aBu6CAw== = new #=zzpeOU_JOtuYoQaG2RC5LCvHWG30aBu6CAw==(array[num]);
						string text = this.#=zBsXSanI=.#=zmBQ$tkaoMKnhtoID9pPrpvw=(#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zMuFMjGQ=(), num);
						if (text.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959541), new object[]
							{
								#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zMuFMjGQ=(),
								#=zzpeOU_JOtuYoQaG2RC5LCvHWG30aBu6CAw==
							});
						}
						else
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959736), new object[]
							{
								#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zMuFMjGQ=(),
								#=zzpeOU_JOtuYoQaG2RC5LCvHWG30aBu6CAw==,
								JSONManager.Cut(text)
							});
						}
					}
				}
			}
		}
	}

	// Token: 0x040007E4 RID: 2020
	private List<#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV> #=zB5vEcEpTJLMd;
}
