﻿using System;
using System.Collections.Generic;

// Token: 0x020001B8 RID: 440
internal sealed class #=zUnqMHgYcw4kzYQNkai6lKUHUuT3C0iujZaTS8M4u0NiMCjwlvpvhWO48ecu2CoYkv6q3v6YdeSKU : List<#=zQ$hUgxLxdhz99NJe1Q$ow84DJC6v2$Igqc5zGG30IQ4cQlesn0KipkPM_ZH_Kx$PBI3XVav4V8Zk>
{
	// Token: 0x06000D35 RID: 3381 RVA: 0x00068294 File Offset: 0x00066494
	public #=zQ$hUgxLxdhz99NJe1Q$ow84DJC6v2$Igqc5zGG30IQ4cQlesn0KipkPM_ZH_Kx$PBI3XVav4V8Zk #=zk$6QZNA=(string #=zAmyvd_vrX3es)
	{
		if (!string.IsNullOrEmpty(#=zAmyvd_vrX3es))
		{
			for (int i = 0; i < base.Count; i++)
			{
				if (base[i].#=zHjFNHgK2yAWa() == #=zAmyvd_vrX3es)
				{
					return base[i];
				}
			}
		}
		return null;
	}
}
