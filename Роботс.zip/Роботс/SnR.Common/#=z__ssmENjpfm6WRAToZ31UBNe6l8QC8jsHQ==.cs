﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001F4 RID: 500
internal sealed class #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ==
{
	// Token: 0x06000F1C RID: 3868 RVA: 0x000788D8 File Offset: 0x00076AD8
	public #=z__ssmENjpfm6WRAToZ31UBNe6l8QC8jsHQ==(Dictionary<string, object> #=zbvyJfNBcGnys)
	{
		object[] array = JSONManager.ExtractArray(#=zbvyJfNBcGnys, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102));
		Dictionary<string, object> dictionary = null;
		if (array != null && array.Length != 0)
		{
			dictionary = (Dictionary<string, object>)array[0];
		}
		if (dictionary == null)
		{
			this.#=z3iFhBgRT_VV7(false);
			return;
		}
		this.#=z3iFhBgRT_VV7(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false) > DateTime.Now);
		this.#=zlq$jT6PL1ZrfjdUQkQ==(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069676), false) > DateTime.Now);
		this.#=zT7HVeut9Yi9Z(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245), 0));
		this.#=zlIpUhIdCMjnLnlj7Ow==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669), 0));
		object[] array2 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
		this.#=zOlonYCJyzWtU(new List<int>());
		if (array2 != null)
		{
			foreach (Dictionary<string, object> dictionary2 in array2)
			{
				this.#=z9YzLV$hp8NK$().Add(JSONManager.ExtractInt(dictionary2, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			}
		}
		this.#=zwvUbzGECX4A2yMf_HQ==(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069661), -1));
		this.#=zLHgdPLJnHT5fePx0nIGVF2Q=(new List<int>());
		foreach (int item in JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			this.#=zYElf33kvwWUgxXThrpQDfeg=().Add(item);
		}
		this.#=zDMzS2r6AwRRVI_Gl2FIuT_w=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0));
		this.#=zXUti4kXYAqcu(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0));
	}

	// Token: 0x06000F1D RID: 3869 RVA: 0x00078A68 File Offset: 0x00076C68
	public bool #=z6MYBfs3dpkwm()
	{
		return this.#=zx3i69tiYFUvkCCvxuGlZgAI=;
	}

	// Token: 0x06000F1E RID: 3870 RVA: 0x00078A70 File Offset: 0x00076C70
	public void #=z3iFhBgRT_VV7(bool #=z$Ib9gYQ=)
	{
		this.#=zx3i69tiYFUvkCCvxuGlZgAI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F1F RID: 3871 RVA: 0x00078A7C File Offset: 0x00076C7C
	public bool #=zfeAuAuTFIUk$ZhBQzw==()
	{
		return this.#=znDnyHx2mz9RFJBy5gknY$YE=;
	}

	// Token: 0x06000F20 RID: 3872 RVA: 0x00078A84 File Offset: 0x00076C84
	public void #=zlq$jT6PL1ZrfjdUQkQ==(bool #=z$Ib9gYQ=)
	{
		this.#=znDnyHx2mz9RFJBy5gknY$YE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F21 RID: 3873 RVA: 0x00078A90 File Offset: 0x00076C90
	public int #=zj$g2Nu72AlHi()
	{
		return this.#=zkuLOyH9qK4CKs$iHaA==;
	}

	// Token: 0x06000F22 RID: 3874 RVA: 0x00078A98 File Offset: 0x00076C98
	public void #=zT7HVeut9Yi9Z(int #=z$Ib9gYQ=)
	{
		this.#=zkuLOyH9qK4CKs$iHaA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F23 RID: 3875 RVA: 0x00078AA4 File Offset: 0x00076CA4
	public List<int> #=z9YzLV$hp8NK$()
	{
		return this.#=z5K2O2VRg_ZQcEPbt91tqhBc=;
	}

	// Token: 0x06000F24 RID: 3876 RVA: 0x00078AAC File Offset: 0x00076CAC
	public void #=zOlonYCJyzWtU(List<int> #=z$Ib9gYQ=)
	{
		this.#=z5K2O2VRg_ZQcEPbt91tqhBc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F25 RID: 3877 RVA: 0x00078AB8 File Offset: 0x00076CB8
	public int #=zcvNx6XGgs__ws7999w==()
	{
		return this.#=zjDHo0jp8v1aJ7Ad7UM9tK4g=;
	}

	// Token: 0x06000F26 RID: 3878 RVA: 0x00078AC0 File Offset: 0x00076CC0
	public void #=zlIpUhIdCMjnLnlj7Ow==(int #=z$Ib9gYQ=)
	{
		this.#=zjDHo0jp8v1aJ7Ad7UM9tK4g= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F27 RID: 3879 RVA: 0x00078ACC File Offset: 0x00076CCC
	public int #=zVL6eyHdiImEax4IH9A==()
	{
		return this.#=zdF2TOFCtR1IcXkZ7Jj$xeOeib1mZ;
	}

	// Token: 0x06000F28 RID: 3880 RVA: 0x00078AD4 File Offset: 0x00076CD4
	public void #=zwvUbzGECX4A2yMf_HQ==(int #=z$Ib9gYQ=)
	{
		this.#=zdF2TOFCtR1IcXkZ7Jj$xeOeib1mZ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F29 RID: 3881 RVA: 0x00078AE0 File Offset: 0x00076CE0
	public List<int> #=zYElf33kvwWUgxXThrpQDfeg=()
	{
		return this.#=zk6ReQIgSP07ycUVej8VzaroeUKIR;
	}

	// Token: 0x06000F2A RID: 3882 RVA: 0x00078AE8 File Offset: 0x00076CE8
	public void #=zLHgdPLJnHT5fePx0nIGVF2Q=(List<int> #=z$Ib9gYQ=)
	{
		this.#=zk6ReQIgSP07ycUVej8VzaroeUKIR = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F2B RID: 3883 RVA: 0x00078AF4 File Offset: 0x00076CF4
	public int #=zQ7ygciKkebhEvwzqLUW7vIE=()
	{
		return this.#=zkcdde6SKmcPIms_uJFUw2Zf4LXL2;
	}

	// Token: 0x06000F2C RID: 3884 RVA: 0x00078AFC File Offset: 0x00076CFC
	public void #=zDMzS2r6AwRRVI_Gl2FIuT_w=(int #=z$Ib9gYQ=)
	{
		this.#=zkcdde6SKmcPIms_uJFUw2Zf4LXL2 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000F2D RID: 3885 RVA: 0x00078B08 File Offset: 0x00076D08
	public int #=zp_aXyfSPS2SK()
	{
		return this.#=zuBNicBL$u9P0Yp1xDexNdxM=;
	}

	// Token: 0x06000F2E RID: 3886 RVA: 0x00078B10 File Offset: 0x00076D10
	public void #=zXUti4kXYAqcu(int #=z$Ib9gYQ=)
	{
		this.#=zuBNicBL$u9P0Yp1xDexNdxM= = #=z$Ib9gYQ=;
	}

	// Token: 0x0400086F RID: 2159
	private bool #=zx3i69tiYFUvkCCvxuGlZgAI=;

	// Token: 0x04000870 RID: 2160
	private bool #=znDnyHx2mz9RFJBy5gknY$YE=;

	// Token: 0x04000871 RID: 2161
	private int #=zkuLOyH9qK4CKs$iHaA==;

	// Token: 0x04000872 RID: 2162
	private List<int> #=z5K2O2VRg_ZQcEPbt91tqhBc=;

	// Token: 0x04000873 RID: 2163
	private int #=zjDHo0jp8v1aJ7Ad7UM9tK4g=;

	// Token: 0x04000874 RID: 2164
	private int #=zdF2TOFCtR1IcXkZ7Jj$xeOeib1mZ;

	// Token: 0x04000875 RID: 2165
	private List<int> #=zk6ReQIgSP07ycUVej8VzaroeUKIR;

	// Token: 0x04000876 RID: 2166
	private int #=zkcdde6SKmcPIms_uJFUw2Zf4LXL2;

	// Token: 0x04000877 RID: 2167
	private int #=zuBNicBL$u9P0Yp1xDexNdxM=;
}
