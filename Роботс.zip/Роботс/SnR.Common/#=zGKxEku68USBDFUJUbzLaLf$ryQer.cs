﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020000FC RID: 252
internal sealed class #=zGKxEku68USBDFUJUbzLaLf$ryQer : RecordData
{
	// Token: 0x06000685 RID: 1669 RVA: 0x00033A1C File Offset: 0x00031C1C
	public #=zGKxEku68USBDFUJUbzLaLf$ryQer(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		int length = this.getRecord().Length;
		this.#=zg9A8_dw= = IntegerHelper.getInt(data[0], data[1]);
		this.#=zN18H2DjHsrkb = IntegerHelper.getInt(data[2], data[3]);
		this.#=zFbfpcug5CC78 = IntegerHelper.getInt(data[length - 2], data[length - 1]);
		this.#=zRsANC43SuCYjfagzOg== = this.#=zFbfpcug5CC78 - this.#=zN18H2DjHsrkb + 1;
		this.#=z890y8dLqEnm$ = new int[this.#=zRsANC43SuCYjfagzOg==];
		this.#=z2sOLnG1Tp3lEWxS9GQ==(data);
	}

	// Token: 0x06000686 RID: 1670 RVA: 0x00033AAC File Offset: 0x00031CAC
	public int #=zNMAKc1U=()
	{
		return this.#=zg9A8_dw=;
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x00033AB4 File Offset: 0x00031CB4
	public int #=zas6WF9Y7vCuz()
	{
		return this.#=zN18H2DjHsrkb;
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x00033ABC File Offset: 0x00031CBC
	public int #=zhUfM2IzcS5zU()
	{
		return this.#=zRsANC43SuCYjfagzOg==;
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x00033AC4 File Offset: 0x00031CC4
	private void #=z2sOLnG1Tp3lEWxS9GQ==(sbyte[] #=zJ5GWysk=)
	{
		int num = 4;
		for (int i = 0; i < this.#=zRsANC43SuCYjfagzOg==; i++)
		{
			this.#=z890y8dLqEnm$[i] = IntegerHelper.getInt(#=zJ5GWysk=[num], #=zJ5GWysk=[num + 1]);
			num += 2;
		}
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x00033B00 File Offset: 0x00031D00
	public int #=zJVc2l$oPfOau(int #=zSPLDPE4=)
	{
		return this.#=z890y8dLqEnm$[#=zSPLDPE4=];
	}

	// Token: 0x040002B4 RID: 692
	private int #=zg9A8_dw=;

	// Token: 0x040002B5 RID: 693
	private int #=zN18H2DjHsrkb;

	// Token: 0x040002B6 RID: 694
	private int #=zFbfpcug5CC78;

	// Token: 0x040002B7 RID: 695
	private int #=zRsANC43SuCYjfagzOg==;

	// Token: 0x040002B8 RID: 696
	private int[] #=z890y8dLqEnm$;
}
