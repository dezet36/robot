﻿using System;
using Skink.SnR.Common.AppLocal;

// Token: 0x02000186 RID: 390
internal sealed class #=zQ$hUgxLxdhz99NJe1Q$ow84DJC6v2$Igqc5zGG30IQ4cQlesn0KipkPM_ZH_Kx$PBI3XVav4V8Zk
{
	// Token: 0x06000B1D RID: 2845 RVA: 0x0005624C File Offset: 0x0005444C
	public #=zQ$hUgxLxdhz99NJe1Q$ow84DJC6v2$Igqc5zGG30IQ4cQlesn0KipkPM_ZH_Kx$PBI3XVav4V8Zk(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zhgo816s=, int #=zxIlNiTU$VRuvtVqOog==)
	{
		this.#=zszUWSSHns_Zk(#=zhgo816s=.#=zHXS2On1IrCDk().Replace(GameApplicationData.#=z0Jq5DpdI2gB$(), string.Empty));
		this.#=zTimWn9E=(#=zhgo816s=);
		this.#=zOSQm7MVPIXnWem$qQw==(new #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==[#=zxIlNiTU$VRuvtVqOog==]);
		this.#=zxnUPsn8SRZx_(this.#=zFUffidZCt_W1qDTbAg==().Length - 1);
		this.#=zwsNyecaJRTtD = DateTime.MinValue;
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x000562A8 File Offset: 0x000544A8
	public string #=zHjFNHgK2yAWa()
	{
		return this.#=zto6tMx5VJR0qgsJf0b5HAA0=;
	}

	// Token: 0x06000B1F RID: 2847 RVA: 0x000562B0 File Offset: 0x000544B0
	public void #=zszUWSSHns_Zk(string #=z$Ib9gYQ=)
	{
		this.#=zto6tMx5VJR0qgsJf0b5HAA0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B20 RID: 2848 RVA: 0x000562BC File Offset: 0x000544BC
	public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zAK8L2sM=()
	{
		return this.#=zP376JIg1e6jqRLTI6A==;
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x000562C4 File Offset: 0x000544C4
	public void #=zTimWn9E=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z$Ib9gYQ=)
	{
		this.#=zP376JIg1e6jqRLTI6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x000562D0 File Offset: 0x000544D0
	public #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==[] #=zFUffidZCt_W1qDTbAg==()
	{
		return this.#=z1ZzOt3omV7sqKNKgacjfF3hZEgwB;
	}

	// Token: 0x06000B23 RID: 2851 RVA: 0x000562D8 File Offset: 0x000544D8
	public void #=zOSQm7MVPIXnWem$qQw==(#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==[] #=z$Ib9gYQ=)
	{
		this.#=z1ZzOt3omV7sqKNKgacjfF3hZEgwB = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B24 RID: 2852 RVA: 0x000562E4 File Offset: 0x000544E4
	public int #=zdJer9RZBTUpf()
	{
		return this.#=zHdg0$Ycv1$6bnvy1K9hFHbc=;
	}

	// Token: 0x06000B25 RID: 2853 RVA: 0x000562EC File Offset: 0x000544EC
	public void #=zxnUPsn8SRZx_(int #=z$Ib9gYQ=)
	{
		this.#=zHdg0$Ycv1$6bnvy1K9hFHbc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B26 RID: 2854 RVA: 0x000562F8 File Offset: 0x000544F8
	public void #=zLJOxdY8lSbqZ()
	{
		int num = this.#=zdJer9RZBTUpf();
		this.#=zxnUPsn8SRZx_(num + 1);
		if (this.#=zdJer9RZBTUpf() >= this.#=zFUffidZCt_W1qDTbAg==().Length)
		{
			this.#=zxnUPsn8SRZx_(0);
		}
	}

	// Token: 0x040005F5 RID: 1525
	private string #=zto6tMx5VJR0qgsJf0b5HAA0=;

	// Token: 0x040005F6 RID: 1526
	private #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=zP376JIg1e6jqRLTI6A==;

	// Token: 0x040005F7 RID: 1527
	private #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==[] #=z1ZzOt3omV7sqKNKgacjfF3hZEgwB;

	// Token: 0x040005F8 RID: 1528
	private int #=zHdg0$Ycv1$6bnvy1K9hFHbc=;

	// Token: 0x040005F9 RID: 1529
	private DateTime #=zwsNyecaJRTtD;
}
