﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020001A5 RID: 421
internal sealed class #=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000CBF RID: 3263 RVA: 0x00064220 File Offset: 0x00062420
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=zNgHF_0Tfb0_b2o2FZA== = #=zuJjQ1XU=.#=zzigOkvJbQiWAdLJxy5rDqiA=();
		this.#=zczxH0P21xmulH1TiIw== = #=zuJjQ1XU=.#=ztGw3z50365iN60O4zw==();
		this.#=zzh$JSx99g2DRwbMtrQ== = #=zuJjQ1XU=.#=zOeHheEjaWrYHJfQ93g0lcRk=();
		this.#=zk6BUq8G8gsT$IwX8$A== = #=zuJjQ1XU=.#=zwbAh2BjlA1lknFqfbiwumHA=();
		this.#=zRa6Pe08ub49zNhp16Rg2pHY= = #=zuJjQ1XU=.#=zD7i9E2p9S0C8eRGxb8a0W5g=();
		this.#=zl$RW2XBH1$hwXOmkng== = #=zuJjQ1XU=.#=zOgsCl1czA8I8AjiIYrYxL5E=();
		this.#=z8Hasu9oJW1vVuKmCfw== = #=zuJjQ1XU=.#=zdhEyxXTc3Fd_5GqmBgR3nOA=();
		this.#=zQawW$MKzphwCxRfILR$PUQ0= = #=zuJjQ1XU=.#=zM01CQPcCrs_$HSTsmq1O62c=();
		this.#=zcMS8uxtJTkUualZEFHm$RMrkgLNC = #=zuJjQ1XU=.#=zJr5eDmz2tzFDBh7JHtfBZy3IVxFG();
		this.#=zfscgiujjvAeldMeqzv8W0hJf1Oi4SdbPWQ== = #=zuJjQ1XU=.#=zM1lSdzKzjSvlrfI1IQtcu4s6U4Jyx$Cl6A==();
		this.#=zSFBqt1aWXDHjQXwNBGX_emyzWSsC = #=zuJjQ1XU=.#=zlE3M25JOMzd3SHkB_pEM1BwNCci8();
		this.#=zSj7jYqczwH8GGaX9mA== = #=zuJjQ1XU=.#=z0aG$0zVW5aRTUSbdPg==();
		this.#=z9EgPb71r1WTrIjG3gZbeKjUwT_1Ijt_aksuEyQACo_9V = #=zuJjQ1XU=.#=zAAtBlefTGfzeH317bDlnzkkaPBd67ajQ3B8Q5_AB6wLk2ABlyQ==();
		this.#=zcr21mh8= = #=zuJjQ1XU=.#=zTqDBdc7DKJmY();
		this.#=zkTFDbK1WLBVA = #=zuJjQ1XU=.#=zuMXv8DnEbNVrFpFzVw==();
	}

	// Token: 0x06000CC0 RID: 3264 RVA: 0x000642F0 File Offset: 0x000624F0
	protected override void #=zvb5bnug=()
	{
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2600, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2601, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2602, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2603, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2604, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2250, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2251, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2252, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2253, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(2254, false);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(5071, true);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(5072, true);
		this.#=zt20S$NLQDEEfHJRg_ipeX7g=(5073, true);
		if (this.#=zCY4az9$WUjLsEJ7fgg==.#=ztdA9BMY81Cs3tvO$LA==())
		{
			string text = this.#=zBsXSanI=.#=zzRaqor_c0Nlx8w$KJg==();
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953869), Array.Empty<object>());
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954093), new object[]
				{
					JSONManager.Cut(text)
				});
			}
		}
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zY$pvpstqHPJzppOpm5pa2HJPtuI4(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B(), this.#=z8StzeqE=, this.#=zBsXSanI=);
		if (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==() > 0)
		{
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(this.#=zBsXSanI=.#=z88KXN9YQlR89lG4bcw==(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==().ToString(), this.#=z8StzeqE=.#=zjV_wsuvJ0R_B())), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954047));
			if (array != null)
			{
				long num = JSONManager.EncodeTimeInt(DateTime.Now.ToUniversalTime().Date - TimeSpan.FromDays(1.0), false);
				long num2 = JSONManager.EncodeTimeInt(DateTime.Now.ToUniversalTime().Date, false);
				object[] array2 = array;
				int i = 0;
				while (i < array2.Length)
				{
					Dictionary<string, object> dictionary = (Dictionary<string, object>)array2[i];
					long num3 = Convert.ToInt64(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)]);
					if (num3 >= num && num3 < num2)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954024), Array.Empty<object>());
						string text2 = this.#=zBsXSanI=.#=zvm6NPNxHyfQ2tOa18pVUVuqwNwUy(num3, Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)]), Convert.ToInt32(dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237)]));
						text2 = text2.Trim();
						if (text2.Length > 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953709), Array.Empty<object>());
							break;
						}
						if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953652)))
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953631), Array.Empty<object>());
							break;
						}
						if (text2.Length > 1010)
						{
							text2 = text2.Substring(0, 1000);
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953816), new object[]
						{
							text2
						});
						break;
					}
					else
					{
						i++;
					}
				}
			}
		}
		this.#=za7fTxhuA8ItB5pXnfw==();
		this.#=zWaU1mmyjYH6EMPWwTh_INHbPU2U_();
		this.#=zi$ZMOjUlZHKSU_XCHgoo8vY=();
		this.#=z7lPpA9ktLslkJF4PFw==();
		if (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.RulesOfWar || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.WarOfThrones || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Konflikt || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Sparta)
		{
			try
			{
				string text3 = this.#=zBsXSanI=.#=z9rhZL8t_81pulIM3nQm23Zk=();
				if (text3.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953767), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953735), new object[]
					{
						JSONManager.Cut(text3)
					});
				}
			}
			catch (Exception ex)
			{
				if (ex.Message.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955472)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955468), new object[]
					{
						ex.Message
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908953735), new object[]
					{
						ex.Message
					});
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zLyaSD5E=(this.#=zG2wnL_q7IxpD, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(ex), Array.Empty<object>());
				}
			}
		}
		if (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.WarOfThrones || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Konflikt || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Sparta)
		{
			try
			{
				if (this.#=zBsXSanI=.#=zirw3IP8CnV_2uWHlKxidmHA=().Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955647), Array.Empty<object>());
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
			}
		}
		this.#=zdGPs78M1skwIoS9m5t31agd3nm75ACOZOQ9PhHs=();
		if (GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.RulesOfWar || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.CodexOfPirate || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.WarOfThrones || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Konflikt || GameApplicationData.#=zZ2dsDUeWDYAN() == GameApplicationData.Games.Sparta)
		{
			try
			{
				if (this.#=zBsXSanI=.#=zNwKl4C0t1_Uqpx$Qfw==().Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955612), Array.Empty<object>());
				}
			}
			catch (Exception #=zN_s5Z5A=2)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=zN_s5Z5A=2);
			}
		}
		this.#=zu1AtMrVSdNBnK_ffhg==();
		this.#=zio9xm1ZeM$6OQkvNslvLg1LjXVGB();
		this.#=zFCx2ZVVTqYkcbjByctbJV0BKcIiK();
		this.#=zmE$hpTn5UQFURFE4ww==();
		this.#=ztiO2LdQhfHOz0SfDy2ajOEKFQ8GOzx$Gwg==();
		this.#=zu$JyuyMyxRJD9S5KJ0u95gprW4PpdZ3sorniUA0=();
		this.#=zObuOMXysvPWHeYhSyg==();
		this.#=zNpWmVDTlPgWL1jlzRA==();
		this.#=zpaTco_yfVY57();
		this.#=zB6IOox0aaJ50cRxSkQfzE0wn5mFsC37fXQ==();
		this.#=zDsU7f2ofgPkZ5pPHjw==();
		if (this.#=zkTFDbK1WLBVA)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955588), Array.Empty<object>());
		}
	}

	// Token: 0x06000CC1 RID: 3265 RVA: 0x00064934 File Offset: 0x00062B34
	private void #=zt20S$NLQDEEfHJRg_ipeX7g=(int #=zgFRCQLw=, bool #=zEXOCKV1C8RsdOdWcmA==)
	{
		#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[#=zgFRCQLw=];
		if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
		{
			while (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_() > 0)
			{
				#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), #=zEXOCKV1C8RsdOdWcmA== ? 1 : #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_());
				if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15() != null)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975595), new object[]
					{
						#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zq2bPTdY=().#=zkfqcY3I=(),
						#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zlIXJ9$NfUZc_()
					});
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() - #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zKWa_xovuFS15().#=zlIXJ9$NfUZc_());
				}
				else
				{
					if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length <= 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975570), new object[]
						{
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
							#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_(),
							JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
						});
						return;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975595), new object[]
					{
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
						#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_()
					});
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=3.#=zlIXJ9$NfUZc_() - 1);
				}
			}
		}
	}

	// Token: 0x06000CC2 RID: 3266 RVA: 0x00064AAC File Offset: 0x00062CAC
	private void #=za7fTxhuA8ItB5pXnfw==()
	{
		foreach (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw= #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw= in this.#=zNgHF_0Tfb0_b2o2FZA==)
		{
			if (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zq2bPTdY=() == (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs=)7 && !#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zdyJ3f33C0g8OTd$jQPjXVGgGUPCf())
			{
				string text = this.#=zBsXSanI=.#=zR5GQ63w5iPhVqI0akQ==(#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zMuFMjGQ=());
				if (text.Length > 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955557), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955242), new object[]
					{
						text
					});
				}
			}
			else if (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zq2bPTdY=() == (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zArez$Gs=)5 && !#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zt5ldqGJD4wtmVa54mBffsQcig7CL())
			{
				if (!#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=z6ZCJ35XpMZv9qsAuPBwV5nGAIfKB())
				{
					string text2 = this.#=zBsXSanI=.#=zR5GQ63w5iPhVqI0akQ==(#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zMuFMjGQ=());
					if (text2.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955189), Array.Empty<object>());
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955144), new object[]
						{
							text2
						});
					}
				}
				bool flag = #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==().Count == 0 || (#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==().Count < #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zZQ6lX1_$WuQNGY73aoLLl7Yqn8Qj() && #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==()[#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==().Count - 1] + TimeSpan.FromDays(1.0) < DateTime.Now);
				if (flag)
				{
					int num = #=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zjPscSZFiXPNHgIdwFhr9qJKBAFwYrObnFw==().Count + 1;
					string text3 = this.#=zBsXSanI=.#=zVfLKoA6fqQLEhdmJIXuWxRk=(#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=.#=zMuFMjGQ=(), num);
					if (text3.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955353), new object[]
						{
							num
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955298), new object[]
						{
							num,
							text3
						});
					}
				}
			}
		}
	}

	// Token: 0x06000CC3 RID: 3267 RVA: 0x00064D24 File Offset: 0x00062F24
	private void #=zWaU1mmyjYH6EMPWwTh_INHbPU2U_()
	{
		List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> list = this.#=zczxH0P21xmulH1TiIw==;
		if (list.Count > 0)
		{
			#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zZ7bll7yjWibZ().#=ztGw3z50365iN60O4zw==();
			if (#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= != null)
			{
				#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8= #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8= = list[0];
				for (int i = 1; i <= #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zP1$wqipk8x42(); i++)
				{
					List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=> list2 = #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=zc2q1URQCK_hB(i);
					List<int> list3 = #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zDTWwIJgqYo904LK5Qw==()[i];
					List<int> list4 = new List<int>();
					for (int j = 0; j < list2.Count; j++)
					{
						#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= #=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= = list2[j];
						if (#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zV8r3OM1EBBH_() > #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zwe$oI0ETE6k7())
						{
							break;
						}
						if (#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zzooUPydC3AwkLIr1rw==())
						{
							int item = j + 1;
							if (!list3.Contains(item))
							{
								list4.Add(item);
							}
						}
					}
					for (int k = 0; k < list4.Count; k++)
					{
						int num = list4[k];
						string text = this.#=zBsXSanI=.#=zzPpW3KlyDM2m32M5rSYBhI_UOzn0(#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zMuFMjGQ=(), num, i);
						if (text.Length <= 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954923), new object[]
							{
								num,
								JSONManager.Cut(text)
							});
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954991), new object[]
						{
							num
						});
					}
				}
			}
		}
	}

	// Token: 0x06000CC4 RID: 3268 RVA: 0x00064EA0 File Offset: 0x000630A0
	private void #=zi$ZMOjUlZHKSU_XCHgoo8vY=()
	{
		List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> list = this.#=zzh$JSx99g2DRwbMtrQ==;
		if (list.Count > 0)
		{
			#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zZ7bll7yjWibZ().#=zB5$HYzT7EFuB();
			if (#=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk= != null)
			{
				#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8= #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8= = list[0];
				for (int i = 1; i <= #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zP1$wqipk8x42(); i++)
				{
					List<#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=> list2 = #=zbuggWLrMgXT_zSlJ9reJFw1FdKyhThj7dmKEqnk=.#=zc2q1URQCK_hB(i);
					List<int> list3 = #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zDTWwIJgqYo904LK5Qw==()[i];
					List<int> list4 = new List<int>();
					for (int j = 0; j < list2.Count; j++)
					{
						#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= #=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88= = list2[j];
						if (#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zV8r3OM1EBBH_() > #=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zlRsoLEEAL4Cs())
						{
							break;
						}
						if (#=zoLctFwZkoK09gzMhjHnTLsrOaN4$_1GcA0Gaj88=.#=zzooUPydC3AwkLIr1rw==())
						{
							int item = j + 1;
							if (!list3.Contains(item))
							{
								list4.Add(item);
							}
						}
					}
					for (int k = 0; k < list4.Count; k++)
					{
						int num = list4[k];
						string text = this.#=zBsXSanI=.#=zmWZB1t3AwP$x4klaVkNyWs0=(#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=.#=zMuFMjGQ=(), num, i);
						if (text.Length <= 10000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955058), new object[]
							{
								num,
								JSONManager.Cut(text)
							});
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955120), new object[]
						{
							num
						});
					}
				}
			}
		}
	}

	// Token: 0x06000CC5 RID: 3269 RVA: 0x0006501C File Offset: 0x0006321C
	private void #=z7lPpA9ktLslkJF4PFw==()
	{
		foreach (#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM= #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM= in this.#=zk6BUq8G8gsT$IwX8$A==)
		{
			bool flag = false;
			for (int i = 0; i < #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=z_fb7pdklVnb4tehtLA==().Count; i++)
			{
				#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA== #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA== = #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=z_fb7pdklVnb4tehtLA==()[i];
				List<int> list = new List<int>();
				for (int j = 0; j < #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=zzBrGWDHiU0qLGetyaA==().Length; j++)
				{
					if (#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=zzBrGWDHiU0qLGetyaA==()[j] <= #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=z0Uzl8ZetHWLkQjzo1g==() && !#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=zkC6ZpKb4sZtQYz2NHZb9oTnLoFAD().Contains(j))
					{
						list.Add(j);
					}
				}
				if (list.Count > 0)
				{
					string text = this.#=zBsXSanI=.#=zJgCJ_EK6JfhYhkCNaprcWQJSFUx1_0VsF18MX0M=(#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=z7k8I7thUvsEP(), #=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=z6GHEmJnDqJOM(), list);
					if (text.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954745), new object[]
						{
							#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=z7k8I7thUvsEP(),
							i,
							list.Count
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954666), new object[]
						{
							#=zCaSC8243oriDRqm9yH8wZqrbr6E1vuRPwXVzWX11KIPgEl0uLA==.#=z7k8I7thUvsEP(),
							i,
							JSONManager.Cut(text)
						});
					}
					flag = true;
				}
			}
			for (int k = 0; k < #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zH3a5_YoOkwU2().Count; k++)
			{
				#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG #=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG = #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zH3a5_YoOkwU2()[k];
				bool flag2 = #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zRJqKb2soHD5G().Contains(#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=());
				if (#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=z88Q7U9qUgaUzi0CbXbqRFR4=() <= #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zc4sdnDAZC8rp3i9N2QsCLEQ=() && !flag2)
				{
					string text2 = this.#=zBsXSanI=.#=zjTAJ4bi8c3jyZmIvtFQtdh9b9yzy(new List<int>
					{
						#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=()
					});
					if (text2.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954840), new object[]
						{
							#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=() + 1
						});
						flag2 = true;
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908954795), new object[]
						{
							#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=() + 1,
							JSONManager.Cut(text2)
						});
					}
				}
				if (flag2)
				{
					for (int l = 1; l <= #=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=.#=zKepaJ_crgOAGyqrTzo7ij1Y=(); l++)
					{
						if (#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=ze_5Gu3r6BR53wz_FwfuqkZZnvzn$DYg4rw==().Contains(l.ToString()))
						{
							string text3 = this.#=zBsXSanI=.#=z9gt_vrw7_liVtNKTVBCx$4WdTPXcPhBQGw==(new List<int>
							{
								#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=()
							}, l);
							if (text3.Length > 1000)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956541), new object[]
								{
									#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=() + 1,
									l
								});
							}
							else
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956471), new object[]
								{
									#=zPMhE1c9BgGRC0JkhV6g3tbD$fMz8_hIyfgyn574TEaeG.#=zVr0Tzd0=() + 1,
									l,
									JSONManager.Cut(text3)
								});
							}
							flag = true;
						}
					}
				}
			}
			if (!flag)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956643), Array.Empty<object>());
			}
		}
	}

	// Token: 0x06000CC6 RID: 3270 RVA: 0x000653E0 File Offset: 0x000635E0
	private void #=zdGPs78M1skwIoS9m5t31agd3nm75ACOZOQ9PhHs=()
	{
		List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=> list = this.#=zRa6Pe08ub49zNhp16Rg2pHY=;
		for (int i = 0; i < list.Count; i++)
		{
			#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q= #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q= = list[i];
			if (#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zY1MCywb8bWJeKmolJ4iPMDZERdKEI_Ze0w==())
			{
				string text = this.#=zBsXSanI=.#=zkyXJDGdwr3KP7QLLxCFfGxU=(#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zMuFMjGQ=(), #=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zvnZc$RhG_1Du());
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956281), new object[]
					{
						#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zkfqcY3I=(),
						#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zvnZc$RhG_1Du(),
						JSONManager.Cut(text)
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956597), new object[]
				{
					#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zkfqcY3I=(),
					#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=.#=zvnZc$RhG_1Du()
				});
			}
		}
	}

	// Token: 0x06000CC7 RID: 3271 RVA: 0x000654CC File Offset: 0x000636CC
	private void #=zu1AtMrVSdNBnK_ffhg==()
	{
		foreach (int num in this.#=zl$RW2XBH1$hwXOmkng==)
		{
			string text = this.#=zBsXSanI=.#=z11$G8mg_WFbDvfiFECVnGIQ=(num);
			if (text.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956219), new object[]
				{
					num
				});
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956182), new object[]
				{
					num,
					JSONManager.Cut(text)
				});
			}
		}
	}

	// Token: 0x06000CC8 RID: 3272 RVA: 0x000655A4 File Offset: 0x000637A4
	private void #=zio9xm1ZeM$6OQkvNslvLg1LjXVGB()
	{
		foreach (#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI= #=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI= in this.#=z8Hasu9oJW1vVuKmCfw==)
		{
			if (#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=.#=zzqJBhunZ1qKZ() != DateTime.MinValue && (int)Math.Ceiling((DateTime.Now - #=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=.#=zzqJBhunZ1qKZ()).TotalDays) > #=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=.#=z6foz3udqYa_dZPgZpRKIHxk=())
			{
				string text = this.#=zBsXSanI=.#=zyAtnVC2oxHMxT3LlQpajx5k=();
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956376), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956336), new object[]
					{
						JSONManager.Cut(text)
					});
				}
			}
		}
	}

	// Token: 0x06000CC9 RID: 3273 RVA: 0x000656A0 File Offset: 0x000638A0
	private void #=zFCx2ZVVTqYkcbjByctbJV0BKcIiK()
	{
		string text = this.#=zBsXSanI=.#=z7_iTRVW2Kudd3w0oka6ezlS8jCNw();
		if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956292), new object[]
			{
				JSONManager.Cut(text)
			});
			return;
		}
		object[] array = JSONManager.GetArray(JSONManager.GetData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907));
		if (array == null || array.Length == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956150), Array.Empty<object>());
			return;
		}
		string text2 = this.#=zBsXSanI=.#=zZkc$1nfnnSfgazpoY8HuNpaS2Hl19mNKrQ==();
		if (text2.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955969), new object[]
			{
				JSONManager.Cut(text2)
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955920), Array.Empty<object>());
	}

	// Token: 0x06000CCA RID: 3274 RVA: 0x000657B4 File Offset: 0x000639B4
	private void #=zmE$hpTn5UQFURFE4ww==()
	{
		List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=> list = this.#=zQawW$MKzphwCxRfILR$PUQ0=;
		for (int i = 0; i < list.Count; i++)
		{
			#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc= #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc= = list[i];
			foreach (int num in #=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=.#=zcdH4JVnr8AGe4boeg9Ke5Kw=())
			{
				string text = this.#=zBsXSanI=.#=zSSYmqrBg2RGnnvCg9Q==(#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=.#=zMuFMjGQ=(), num);
				if (text.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956102), new object[]
					{
						#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=.#=zMuFMjGQ=(),
						num,
						JSONManager.Cut(text)
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956040), Array.Empty<object>());
				}
			}
		}
	}

	// Token: 0x06000CCB RID: 3275 RVA: 0x000658C4 File Offset: 0x00063AC4
	private void #=ztiO2LdQhfHOz0SfDy2ajOEKFQ8GOzx$Gwg==()
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenEchelonPointPacks)
		{
			return;
		}
		for (int i = 601; i <= 608; i++)
		{
			this.#=zt20S$NLQDEEfHJRg_ipeX7g=(i, false);
		}
	}

	// Token: 0x06000CCC RID: 3276 RVA: 0x00065900 File Offset: 0x00063B00
	private void #=zu$JyuyMyxRJD9S5KJ0u95gprW4PpdZ3sorniUA0=()
	{
		#=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ== #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ== = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zZsVcPWNCb1EbXEj_RqOp1M1R0ASC();
		if (#=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ== != null)
		{
			#=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg== #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg== = this.#=zcMS8uxtJTkUualZEFHm$RMrkgLNC;
			for (int i = 0; i < #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ==.#=zFvMaJ6LObvpT().Count; i++)
			{
				#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg== #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg== = #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ==.#=zFvMaJ6LObvpT()[i];
				for (int j = 0; j < #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z60bm6Tbh2NS2Gf1JMg==().Count; j++)
				{
					#=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG.#=z0kvmSi0Ok_7pIkwHX6LIrcA= #=z0kvmSi0Ok_7pIkwHX6LIrcA= = new #=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG.#=z0kvmSi0Ok_7pIkwHX6LIrcA=();
					#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc = #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z60bm6Tbh2NS2Gf1JMg==()[j];
					bool flag = false;
					if (#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zxqd8DBH0LUsd0xrIUw==() != null)
					{
						bool flag2 = true;
						#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zzGl$RlI= = 0;
						while (#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zzGl$RlI= < #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zxqd8DBH0LUsd0xrIUw==().Count)
						{
							List<#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==> list = #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ==.#=zFvMaJ6LObvpT();
							Predicate<#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==> match;
							if ((match = #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zxwmV42lQK4CR) == null)
							{
								match = (#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zxwmV42lQK4CR = new Predicate<#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==>(#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zRCj8IBWU67zCCHOU0hFOLHgOxCmQkPr1lnb2qX7j6br2));
							}
							#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg== #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==2 = list.Find(match);
							bool flag3 = false;
							if (#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==2 != null && #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=z93_hvEh1P1n9Glhkxw==().ContainsKey(#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==2.#=z2UCBrfce7z8r()) && #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=z93_hvEh1P1n9Glhkxw==()[#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==2.#=z2UCBrfce7z8r()].Count == #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==2.#=z60bm6Tbh2NS2Gf1JMg==().Count)
							{
								flag3 = true;
							}
							if (!flag3)
							{
								flag2 = false;
								break;
							}
							int #=zzGl$RlI= = #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zzGl$RlI=;
							#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zzGl$RlI= = #=zzGl$RlI= + 1;
						}
						if (flag2)
						{
							flag = true;
						}
					}
					else if (!string.IsNullOrEmpty(#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zxr6xC83bUzbu()))
					{
						if (#=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=zUhBOqiJ4WrnVpOYYfw==().ContainsKey(#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zxr6xC83bUzbu()))
						{
							Dictionary<int, long> dictionary = #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=zUhBOqiJ4WrnVpOYYfw==()[#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zxr6xC83bUzbu()];
							if (dictionary.ContainsKey(#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zAkb1y5EVFbiC()) && dictionary[#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zAkb1y5EVFbiC()] >= #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zqcrTsdIQiIZP())
							{
								flag = true;
							}
						}
					}
					else if (#=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=zRBNVKQNrlBEoV8o9ZEa1KTQ=().ContainsKey(#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z2UCBrfce7z8r()) && #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=zRBNVKQNrlBEoV8o9ZEa1KTQ=()[#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z2UCBrfce7z8r()] >= #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zqcrTsdIQiIZP())
					{
						flag = true;
					}
					if (flag)
					{
						bool flag4 = false;
						if (#=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=z93_hvEh1P1n9Glhkxw==().ContainsKey(#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z2UCBrfce7z8r()) && #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg==.#=z93_hvEh1P1n9Glhkxw==()[#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z2UCBrfce7z8r()].Contains(#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zMuFMjGQ=()))
						{
							flag4 = true;
						}
						if (!flag4)
						{
							string text = this.#=zBsXSanI=.#=zFxqhqkKXyNkUkgA5YTRdXHXQ749CYmWj4KhlfF0=(#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=z2UCBrfce7z8r(), #=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zMuFMjGQ=());
							if (text.Length > 1000)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955746), new object[]
								{
									#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=zkfqcY3I=(),
									#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zMuFMjGQ=()
								});
							}
							else
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955697), new object[]
								{
									#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==.#=zkfqcY3I=(),
									#=z0kvmSi0Ok_7pIkwHX6LIrcA=.#=zfARpXNEbqFnc.#=zMuFMjGQ=(),
									JSONManager.Cut(text)
								});
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06000CCD RID: 3277 RVA: 0x00065C18 File Offset: 0x00063E18
	private void #=zObuOMXysvPWHeYhSyg==()
	{
		int num = this.#=zfscgiujjvAeldMeqzv8W0hJf1Oi4SdbPWQ==;
		if (num > 0)
		{
			string text = this.#=zBsXSanI=.#=zI6O4fQIGazCsBd4Xo7TskzfXF8gSZzTGRA==();
			if (text.Length > 1000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955890), new object[]
				{
					num
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955856), new object[]
			{
				num,
				JSONManager.Cut(text)
			});
		}
	}

	// Token: 0x06000CCE RID: 3278 RVA: 0x00065CB4 File Offset: 0x00063EB4
	private void #=zNpWmVDTlPgWL1jlzRA==()
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsProcessAresCult)
		{
			return;
		}
		int num = 100;
		string text = null;
		if (this.#=z251$6etAKm8UBSxw7tLsIew085bCwcZ1RQ==(28000, num, ref text) + this.#=z251$6etAKm8UBSxw7tLsIew085bCwcZ1RQ==(28001, num, ref text) + this.#=z251$6etAKm8UBSxw7tLsIew085bCwcZ1RQ==(28002, num, ref text) >= num && !string.IsNullOrEmpty(text))
		{
			base.#=zL1HTbwC75LO$(text);
		}
		List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx> list = this.#=zSFBqt1aWXDHjQXwNBGX_emyzWSsC;
		for (int i = 0; i < list.Count; i++)
		{
			#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx #=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx = list[i];
			if (#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx.#=zRoHefI4d0IZD())
			{
				UnitType unitType = UnitTypeCollection.Get().FindOrCreate(#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx.#=z9$XFwTaUKMJD());
				string text2 = this.#=zBsXSanI=.#=zbk_MxlunfqRdmn4jAmcb4Sdu_jv7bAVo$w==(#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx.#=z9$XFwTaUKMJD());
				if (text2.Length > 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955820), new object[]
					{
						unitType.Name
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908955778), new object[]
					{
						unitType.Name,
						JSONManager.Cut(text2)
					});
				}
			}
		}
	}

	// Token: 0x06000CCF RID: 3279 RVA: 0x00065DEC File Offset: 0x00063FEC
	private int #=z251$6etAKm8UBSxw7tLsIew085bCwcZ1RQ==(int #=zgFRCQLw=, int #=z2VlHBlbvoxGr, ref string #=zIapFsKF23kqB)
	{
		#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= = this.#=zCY4az9$WUjLsEJ7fgg==[#=zgFRCQLw=];
		int num = 0;
		if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= != null)
		{
			int num2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
			if (num2 > #=z2VlHBlbvoxGr)
			{
				num2 = #=z2VlHBlbvoxGr;
			}
			#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o= = this.#=zBsXSanI=.#=zju79dCyB4r7u(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=(), num2);
			if (#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC().Length > 1000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975595), new object[]
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
					num2
				});
				num = num2;
				#=zIapFsKF23kqB = #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC();
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975570), new object[]
				{
					#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zkfqcY3I=(),
					num2,
					JSONManager.Cut(#=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=.#=zv5TFggBD$2IC())
				});
			}
			#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2 = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=;
			#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zqoCq5j01dD5w(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=2.#=zlIXJ9$NfUZc_() - num);
		}
		return num;
	}

	// Token: 0x06000CD0 RID: 3280 RVA: 0x00065EE4 File Offset: 0x000640E4
	private void #=zpaTco_yfVY57()
	{
		#=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG.#=z4tAn7AX3LuhkbIOLQECdajU= #=z4tAn7AX3LuhkbIOLQECdajU= = new #=zTobRME_f1E6yD_Yz3kCoDJsOLfu8pUy0_VZ5WCyjmPo8j16N$QgUTBTKTqFG.#=z4tAn7AX3LuhkbIOLQECdajU=();
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LuckEventRewardTypeChoice == 0)
		{
			return;
		}
		#=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y= #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y= = this.#=zSj7jYqczwH8GGaX9mA==;
		if (#=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zTS397QmwRLvBFKxTJQ==() == 0 && #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zUZLtmsPiEO15k_Q8Gw==() == 0)
		{
			return;
		}
		int i = #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zUZLtmsPiEO15k_Q8Gw==();
		#=z4tAn7AX3LuhkbIOLQECdajU=.#=z8RQJosNU9N$bE1fIiw== = #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zTS397QmwRLvBFKxTJQ==();
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957534), new object[]
		{
			i,
			#=z4tAn7AX3LuhkbIOLQECdajU=.#=z8RQJosNU9N$bE1fIiw==
		});
		while (i > 0)
		{
			string text = this.#=zBsXSanI=.#=zI4t7DnP8v0BkMohlFQ==(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LuckEventRewardTypeChoice);
			if (text.Length <= 1000)
			{
				if (!text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957452)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957309), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957684), Array.Empty<object>());
				text = this.#=zBsXSanI=.#=znnVDFcgfmLU4n1Atpg==();
				if (text.Length < 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957611), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
				text = this.#=zBsXSanI=.#=zI4t7DnP8v0BkMohlFQ==(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LuckEventRewardTypeChoice);
				if (text.Length < 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957309), new object[]
					{
						JSONManager.Cut(text)
					});
					break;
				}
			}
			text = this.#=zBsXSanI=.#=zaYnKuPIPg5ylCSGiiAStYNQ=(0);
			if (text.Length < 1000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957248), new object[]
				{
					JSONManager.Cut(text)
				});
				break;
			}
			text = this.#=zBsXSanI=.#=znnVDFcgfmLU4n1Atpg==();
			if (text.Length < 1000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957611), new object[]
				{
					JSONManager.Cut(text)
				});
				break;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957206), Array.Empty<object>());
			i--;
			int #=z8RQJosNU9N$bE1fIiw== = #=z4tAn7AX3LuhkbIOLQECdajU=.#=z8RQJosNU9N$bE1fIiw==;
			#=z4tAn7AX3LuhkbIOLQECdajU=.#=z8RQJosNU9N$bE1fIiw== = #=z8RQJosNU9N$bE1fIiw== + 1;
		}
		int num = this.#=z8StzeqE=.#=zHk2CSHOH76iz().#=z91FrU_uar3cu7gebbDL9MWTXgwHZ().FindIndex(new Predicate<int>(#=z4tAn7AX3LuhkbIOLQECdajU=.#=zVbS3O_x503jAXRwEJfO6PnA=));
		if (#=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zD7ARvSV8xtCfE0_KzW0H$zo=().Count < num)
		{
			for (int j = 0; j < num; j++)
			{
				if (!#=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y=.#=zD7ARvSV8xtCfE0_KzW0H$zo=().Contains(j))
				{
					string text2 = this.#=zBsXSanI=.#=zM5DUhGnEb$kAQsXWzoO8fzSXuPUWYzguZ7LFOag=(j);
					if (text2.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957407), new object[]
						{
							j + 1
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957328), new object[]
						{
							j + 1,
							JSONManager.Cut(text2)
						});
					}
				}
			}
		}
	}

	// Token: 0x06000CD1 RID: 3281 RVA: 0x00066280 File Offset: 0x00064480
	private void #=zB6IOox0aaJ50cRxSkQfzE0wn5mFsC37fXQ==()
	{
		if (this.#=z9EgPb71r1WTrIjG3gZbeKjUwT_1Ijt_aksuEyQACo_9V.Count > 0)
		{
			#=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zRNMbzapw7YG$2TckgCczwJRgHdTL$EF1cA==();
			foreach (int num in this.#=z9EgPb71r1WTrIjG3gZbeKjUwT_1Ijt_aksuEyQACo_9V.Keys)
			{
				#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= #=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= = #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0=.#=zk$6QZNA=(num);
				List<int> list = this.#=z9EgPb71r1WTrIjG3gZbeKjUwT_1Ijt_aksuEyQACo_9V[num];
				if (#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM= != null)
				{
					foreach (int num2 in list)
					{
						string text = this.#=zBsXSanI=.#=z4qXabI0pe3LvAtCBGZ$bSBCQBI0$_7CbUQ==(#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=.#=zMuFMjGQ=());
						if (text.Length <= 1000)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956930), new object[]
							{
								#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=.#=zkfqcY3I=(),
								num2,
								JSONManager.Cut(text)
							});
							break;
						}
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908956995), new object[]
						{
							#=zpgslCn5Wg38JfX$HR3$BWST0xPmBRwuYj9tEiR9efD_QYbyL9yN0aVM=.#=zkfqcY3I=(),
							num2
						});
					}
				}
			}
		}
	}

	// Token: 0x06000CD2 RID: 3282 RVA: 0x00066400 File Offset: 0x00064600
	private void #=zDsU7f2ofgPkZ5pPHjw==()
	{
		if (!string.IsNullOrWhiteSpace(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName))
		{
			string text = this.#=zcr21mh8=;
			if (text == this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908957116), Array.Empty<object>());
				return;
			}
			string text2 = this.#=zBsXSanI=.#=zLbAeSYCTLemU(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName);
			if (text2.Length > 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964023), new object[]
				{
					text,
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963972), new object[]
			{
				text,
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName,
				JSONManager.Cut(text2)
			});
		}
	}

	// Token: 0x04000756 RID: 1878
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x04000757 RID: 1879
	private List<#=zP8oGWsB5Ry42JYXu8GYfc$Qg3cS0ZNmNYkHEaSw=> #=zNgHF_0Tfb0_b2o2FZA==;

	// Token: 0x04000758 RID: 1880
	private List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=zczxH0P21xmulH1TiIw==;

	// Token: 0x04000759 RID: 1881
	private List<#=zuE0GAZJB9g3OVNz_GgMRIdpUxM4pHQj5t7It$K8=> #=zzh$JSx99g2DRwbMtrQ==;

	// Token: 0x0400075A RID: 1882
	private List<#=zw3TksTBYYcr6bM76IYQYX7bziUx5r4mUk4RpmAM=> #=zk6BUq8G8gsT$IwX8$A==;

	// Token: 0x0400075B RID: 1883
	private List<#=zijg4KpWip$DrKPL_8X9ovmb_aI3TPE3rpBcYK2Q=> #=zRa6Pe08ub49zNhp16Rg2pHY=;

	// Token: 0x0400075C RID: 1884
	private List<int> #=zl$RW2XBH1$hwXOmkng==;

	// Token: 0x0400075D RID: 1885
	private List<#=zvbelcpujpvmCHmtTk0Hojv8vTGvjU4xHmJadDjI=> #=z8Hasu9oJW1vVuKmCfw==;

	// Token: 0x0400075E RID: 1886
	private List<#=z4r3CVDeykP6pcNKvrEOEMvGwv0kuzQA$FZPgZkc=> #=zQawW$MKzphwCxRfILR$PUQ0=;

	// Token: 0x0400075F RID: 1887
	private #=zaK6BefxUrAfW52gJ7dadFwSAWLyTWeiL_ThV0z0Br2yhhGG0Rg== #=zcMS8uxtJTkUualZEFHm$RMrkgLNC;

	// Token: 0x04000760 RID: 1888
	private int #=zfscgiujjvAeldMeqzv8W0hJf1Oi4SdbPWQ==;

	// Token: 0x04000761 RID: 1889
	private List<#=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx> #=zSFBqt1aWXDHjQXwNBGX_emyzWSsC;

	// Token: 0x04000762 RID: 1890
	private #=zLvme_sQk2K2mLhkQZjVxfhLVUaNMlp6jffuhA$Y= #=zSj7jYqczwH8GGaX9mA==;

	// Token: 0x04000763 RID: 1891
	private Dictionary<int, List<int>> #=z9EgPb71r1WTrIjG3gZbeKjUwT_1Ijt_aksuEyQACo_9V;

	// Token: 0x04000764 RID: 1892
	private string #=zcr21mh8=;

	// Token: 0x04000765 RID: 1893
	private bool #=zkTFDbK1WLBVA;

	// Token: 0x020001A6 RID: 422
	private sealed class #=z0kvmSi0Ok_7pIkwHX6LIrcA=
	{
		// Token: 0x06000CD4 RID: 3284 RVA: 0x00066524 File Offset: 0x00064724
		internal bool #=zRCj8IBWU67zCCHOU0hFOLHgOxCmQkPr1lnb2qX7j6br2(#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=z2UCBrfce7z8r() == this.#=zfARpXNEbqFnc.#=zxqd8DBH0LUsd0xrIUw==()[this.#=zzGl$RlI=];
		}

		// Token: 0x04000766 RID: 1894
		public #=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ= #=zfARpXNEbqFnc;

		// Token: 0x04000767 RID: 1895
		public int #=zzGl$RlI=;

		// Token: 0x04000768 RID: 1896
		public Predicate<#=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==> #=zxwmV42lQK4CR;
	}

	// Token: 0x020001A7 RID: 423
	private sealed class #=z4tAn7AX3LuhkbIOLQECdajU=
	{
		// Token: 0x06000CD6 RID: 3286 RVA: 0x0006654C File Offset: 0x0006474C
		internal bool #=zVbS3O_x503jAXRwEJfO6PnA=(int #=zQrqFdos=)
		{
			return #=zQrqFdos= > this.#=z8RQJosNU9N$bE1fIiw==;
		}

		// Token: 0x04000769 RID: 1897
		public int #=z8RQJosNU9N$bE1fIiw==;
	}
}
