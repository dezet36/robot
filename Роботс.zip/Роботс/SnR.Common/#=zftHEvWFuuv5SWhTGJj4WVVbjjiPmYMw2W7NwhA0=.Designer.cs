﻿// Token: 0x0200023F RID: 575
internal sealed partial class #=zftHEvWFuuv5SWhTGJj4WVVbjjiPmYMw2W7NwhA0= : global::System.Windows.Forms.Form
{
	// Token: 0x0600119D RID: 4509 RVA: 0x0008917C File Offset: 0x0008737C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040009D1 RID: 2513
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
