﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;

// Token: 0x02000277 RID: 631
internal sealed partial class #=zkoPM2trZEqBA6NpuZYtG_oD_66_1amKM9Q== : Form
{
	// Token: 0x06001313 RID: 4883 RVA: 0x00093DEC File Offset: 0x00091FEC
	public #=zkoPM2trZEqBA6NpuZYtG_oD_66_1amKM9Q==()
	{
		this.#=zgpzgXirqPT5_();
		this.#=zcBSiDOgQqUjT();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001314 RID: 4884 RVA: 0x00093E08 File Offset: 0x00092008
	public void #=zcBSiDOgQqUjT()
	{
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY();
		List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> list2 = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=().#=zOdy_aU_tk1aY();
		if (list.Count > 0)
		{
			list.Sort(list[0]);
		}
		this.#=z_IRaZLu7fTAr.Rows.Clear();
		int num = 1;
		for (int i = 0; i < list.Count; i++)
		{
			#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl = list[i];
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zDZReNK0=() == AccoutRegistrationResults.Successful)
			{
				#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = null;
				if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == GameApplicationData.#=z7wsmjLWw49AC() && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN() == GameApplicationData.#=zZ2dsDUeWDYAN())
				{
					for (int j = 0; j < list2.Count; j++)
					{
						if (list2[j].#=z9Yordw6ZFjQe() == #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCCvotbi$42tS())
						{
							#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== = list2[j];
							break;
						}
					}
				}
				this.#=z_IRaZLu7fTAr.Rows.Add(new object[]
				{
					num,
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC(),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN(),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCCvotbi$42tS(),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zkfqcY3I=(),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zvnZc$RhG_1Du(),
					#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zCa0AyEddce6P().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064874)),
					(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== == null) ? #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091557)) : string.Empty
				});
				num++;
			}
		}
		int num2 = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zuz_M2jEYZbqf() - #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zpGeTUhk0$z9R();
		if (num2 >= 0)
		{
			this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091540), new object[]
			{
				num2,
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N(),
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z0tAtvpk59AX6IZiVIY9dxVvko3Cf(),
				Environment.NewLine
			}).ToString();
			return;
		}
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Text = new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091146), new object[]
		{
			-num2,
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N(),
			#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z0tAtvpk59AX6IZiVIY9dxVvko3Cf(),
			Environment.NewLine
		}).ToString();
	}

	// Token: 0x06001315 RID: 4885 RVA: 0x0009403C File Offset: 0x0009223C
	private void #=zyOsQDNMu2HM7wYjT6V$0U5g=(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (this.#=z_IRaZLu7fTAr.Columns[#=z4Q$h3mE=.ColumnIndex].Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091204) && #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N() > 0)
			{
				if (string.IsNullOrWhiteSpace(Convert.ToString(this.#=z_IRaZLu7fTAr.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091204)].Value)))
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090923));
				}
				else if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N() <= 0)
				{
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090839));
				}
				else if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(string.Empty, MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090957), new object[]
				{
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zhnZtiNfmX6jGblnmG_kFgQvgBk7N(),
					Convert.ToString(this.#=z_IRaZLu7fTAr.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227)].Value)
				}) == DialogResult.OK)
				{
					DataGridViewRow dataGridViewRow = this.#=z_IRaZLu7fTAr.Rows[#=z4Q$h3mE=.RowIndex];
					string #=zDu2ZTOnSae3g = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092628)].Value);
					GameApplicationData.GameHosters #=z74XFXnQ7Q8Ia = (GameApplicationData.GameHosters)0;
					string b = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092858)].Value);
					foreach (object obj in Enum.GetValues(typeof(GameApplicationData.GameHosters)))
					{
						GameApplicationData.GameHosters gameHosters = (GameApplicationData.GameHosters)obj;
						if (gameHosters.ToString() == b)
						{
							#=z74XFXnQ7Q8Ia = gameHosters;
							break;
						}
					}
					GameApplicationData.Games #=zR2PWq$tkHfd = (GameApplicationData.Games)0;
					string b2 = Convert.ToString(dataGridViewRow.Cells[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092843)].Value);
					foreach (object obj2 in Enum.GetValues(typeof(GameApplicationData.Games)))
					{
						GameApplicationData.Games games = (GameApplicationData.Games)obj2;
						if (games.ToString() == b2)
						{
							#=zR2PWq$tkHfd = games;
							break;
						}
					}
					#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zvuVAl$GL8W_$(#=zDu2ZTOnSae3g, #=z74XFXnQ7Q8Ia, #=zR2PWq$tkHfd);
					this.#=zcBSiDOgQqUjT();
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x06001316 RID: 4886 RVA: 0x00094304 File Offset: 0x00092504
	private void #=zoVc7LMGg8rX35jUiZ2nAFO$7zf8U(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z0tAtvpk59AX6IZiVIY9dxVvko3Cf() <= 0)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092824));
			}
			else if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(string.Empty, MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092439), new object[]
			{
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=z0tAtvpk59AX6IZiVIY9dxVvko3Cf()
			}) == DialogResult.OK)
			{
				#=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=zWF51hHDlgzMZ();
				this.#=zcBSiDOgQqUjT();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x06001317 RID: 4887 RVA: 0x00094390 File Offset: 0x00092590
	private void #=zwCdlLz_L$Nse(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zcBSiDOgQqUjT();
	}

	// Token: 0x06001319 RID: 4889 RVA: 0x000943B8 File Offset: 0x000925B8
	private void #=zgpzgXirqPT5_()
	{
		this.#=z_IRaZLu7fTAr = new DataGridView();
		this.#=zqH0yfco= = new DataGridViewTextBoxColumn();
		this.#=zB2$PvwI= = new DataGridViewTextBoxColumn();
		this.#=zBJZr5RQg_AI2 = new DataGridViewTextBoxColumn();
		this.#=zp44xwe4= = new DataGridViewTextBoxColumn();
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=zlFYgIdo= = new DataGridViewTextBoxColumn();
		this.#=zmkzQuc3pLpBd = new DataGridViewTextBoxColumn();
		this.#=znQ3wJkA= = new DataGridViewButtonColumn();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8= = new Button();
		this.#=z190UPYw= = new Button();
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c= = new Label();
		((ISupportInitialize)this.#=z_IRaZLu7fTAr).BeginInit();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		base.SuspendLayout();
		this.#=z_IRaZLu7fTAr.AllowUserToAddRows = false;
		this.#=z_IRaZLu7fTAr.AllowUserToDeleteRows = false;
		this.#=z_IRaZLu7fTAr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z_IRaZLu7fTAr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zqH0yfco=,
			this.#=zB2$PvwI=,
			this.#=zBJZr5RQg_AI2,
			this.#=zp44xwe4=,
			this.#=zO0jJkos=,
			this.#=zlFYgIdo=,
			this.#=zmkzQuc3pLpBd,
			this.#=znQ3wJkA=
		});
		this.#=z_IRaZLu7fTAr.Dock = DockStyle.Fill;
		this.#=z_IRaZLu7fTAr.Location = new Point(0, 0);
		this.#=z_IRaZLu7fTAr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092535);
		this.#=z_IRaZLu7fTAr.Size = new Size(978, 425);
		this.#=z_IRaZLu7fTAr.TabIndex = 0;
		this.#=z_IRaZLu7fTAr.CellContentClick += this.#=zyOsQDNMu2HM7wYjT6V$0U5g=;
		this.#=zqH0yfco=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zqH0yfco=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092505);
		this.#=zqH0yfco=.Width = 50;
		this.#=zB2$PvwI=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092495);
		this.#=zB2$PvwI=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092218);
		this.#=zB2$PvwI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092858);
		this.#=zBJZr5RQg_AI2.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092215);
		this.#=zBJZr5RQg_AI2.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092194);
		this.#=zBJZr5RQg_AI2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092843);
		this.#=zp44xwe4=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168);
		this.#=zp44xwe4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112603);
		this.#=zp44xwe4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092628);
		this.#=zp44xwe4=.Width = 150;
		this.#=zO0jJkos=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315);
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.Width = 200;
		this.#=zlFYgIdo=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092191);
		this.#=zlFYgIdo=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909106605);
		this.#=zlFYgIdo=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092171);
		this.#=zmkzQuc3pLpBd.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092153);
		this.#=zmkzQuc3pLpBd.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092128);
		this.#=zmkzQuc3pLpBd.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092115);
		this.#=znQ3wJkA=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091557);
		this.#=znQ3wJkA=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091204);
		this.#=znQ3wJkA=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091557);
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=z_IRaZLu7fTAr);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=z190UPYw=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=);
		this.#=zByiHPAwyKD$Q.Size = new Size(978, 488);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 425;
		this.#=zByiHPAwyKD$Q.TabIndex = 1;
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.Location = new Point(700, 3);
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092103);
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.Size = new Size(180, 23);
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.TabIndex = 2;
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092333);
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.UseVisualStyleBackColor = true;
		this.#=zyP8Hy5iaaU9ymNg4tP2T6x8=.Click += this.#=zoVc7LMGg8rX35jUiZ2nAFO$7zf8U;
		this.#=z190UPYw=.Location = new Point(900, 3);
		this.#=z190UPYw=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092297);
		this.#=z190UPYw=.Size = new Size(75, 23);
		this.#=z190UPYw=.TabIndex = 1;
		this.#=z190UPYw=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092285);
		this.#=z190UPYw=.UseVisualStyleBackColor = true;
		this.#=z190UPYw=.Click += this.#=zwCdlLz_L$Nse;
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.AutoSize = true;
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Location = new Point(3, 8);
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092269);
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Size = new Size(34, 13);
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.TabIndex = 0;
		this.#=zCp7XO8g9BNaC7VQ7r8XwU7c=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092245);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(978, 488);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092231);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091945);
		((ISupportInitialize)this.#=z_IRaZLu7fTAr).EndInit();
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.PerformLayout();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000B03 RID: 2819
	private DataGridView #=z_IRaZLu7fTAr;

	// Token: 0x04000B04 RID: 2820
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x04000B05 RID: 2821
	private Label #=zCp7XO8g9BNaC7VQ7r8XwU7c=;

	// Token: 0x04000B06 RID: 2822
	private Button #=z190UPYw=;

	// Token: 0x04000B07 RID: 2823
	private Button #=zyP8Hy5iaaU9ymNg4tP2T6x8=;

	// Token: 0x04000B08 RID: 2824
	private DataGridViewTextBoxColumn #=zqH0yfco=;

	// Token: 0x04000B09 RID: 2825
	private DataGridViewTextBoxColumn #=zB2$PvwI=;

	// Token: 0x04000B0A RID: 2826
	private DataGridViewTextBoxColumn #=zBJZr5RQg_AI2;

	// Token: 0x04000B0B RID: 2827
	private DataGridViewTextBoxColumn #=zp44xwe4=;

	// Token: 0x04000B0C RID: 2828
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x04000B0D RID: 2829
	private DataGridViewTextBoxColumn #=zlFYgIdo=;

	// Token: 0x04000B0E RID: 2830
	private DataGridViewTextBoxColumn #=zmkzQuc3pLpBd;

	// Token: 0x04000B0F RID: 2831
	private DataGridViewButtonColumn #=znQ3wJkA=;
}
