﻿using System;

// Token: 0x0200021A RID: 538
internal sealed class #=zcryzuJdqHJDm55mRqseDxWYoSP9$ : #=z9EpCy_XFXi2VByCFZQZwOVUhFCY7, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x0600105E RID: 4190 RVA: 0x0007EFD8 File Offset: 0x0007D1D8
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zWdXRcUXGRn8Kng0PVQ==;
	}

	// Token: 0x0600105F RID: 4191 RVA: 0x0007EFE0 File Offset: 0x0007D1E0
	internal override int #=zXiDCyaHY58$0()
	{
		return 2;
	}

	// Token: 0x06001060 RID: 4192 RVA: 0x0007EFE4 File Offset: 0x0007D1E4
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077082);
	}
}
