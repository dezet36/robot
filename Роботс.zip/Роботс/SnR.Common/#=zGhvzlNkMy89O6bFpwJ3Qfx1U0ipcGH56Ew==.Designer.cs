﻿// Token: 0x02000101 RID: 257
internal sealed partial class #=zGhvzlNkMy89O6bFpwJ3Qfx1U0ipcGH56Ew== : global::System.Windows.Forms.Form
{
	// Token: 0x060006BE RID: 1726 RVA: 0x00037288 File Offset: 0x00035488
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040002F2 RID: 754
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
