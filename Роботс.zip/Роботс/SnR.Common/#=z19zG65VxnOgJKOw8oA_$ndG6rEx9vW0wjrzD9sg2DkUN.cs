﻿using System;

// Token: 0x0200003B RID: 59
internal sealed class #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN
{
	// Token: 0x060001E0 RID: 480 RVA: 0x00012B10 File Offset: 0x00010D10
	public #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060001E1 RID: 481 RVA: 0x00012B18 File Offset: 0x00010D18
	public void #=zzQwUIEs=(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00012B24 File Offset: 0x00010D24
	public int #=zvnZc$RhG_1Du()
	{
		return this.#=zq9EZwxO2tjqgH$qWVQ==;
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x00012B2C File Offset: 0x00010D2C
	public void #=zFzGvi_S6jJhE(int #=z$Ib9gYQ=)
	{
		this.#=zq9EZwxO2tjqgH$qWVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x00012B38 File Offset: 0x00010D38
	public int #=zMuFMjGQ=()
	{
		return this.#=zq2bPTdY=().#=zMuFMjGQ=();
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x00012B48 File Offset: 0x00010D48
	public string #=zkfqcY3I=()
	{
		return this.#=zq2bPTdY=().#=zkfqcY3I=();
	}

	// Token: 0x0400006D RID: 109
	private #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400006E RID: 110
	private int #=zq9EZwxO2tjqgH$qWVQ==;
}
