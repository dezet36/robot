﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Interface;

// Token: 0x02000189 RID: 393
internal sealed partial class #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw== : Form
{
	// Token: 0x06000B3A RID: 2874 RVA: 0x00056498 File Offset: 0x00054698
	public #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==()
	{
		this.#=zgpzgXirqPT5_();
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY();
		if (list.Count > 0)
		{
			list.Sort(list[0]);
		}
		this.#=zEhGRLRSSQTM3nxmPHQ== = new List<SelectableAccount>();
		int num = 1;
		foreach (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl in list)
		{
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == GameApplicationData.#=z7wsmjLWw49AC() && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN() == GameApplicationData.#=zZ2dsDUeWDYAN())
			{
				this.#=zEhGRLRSSQTM3nxmPHQ==.Add(new SelectableAccount(false, num, #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl));
				num++;
			}
		}
		this.#=zcIGb4QLv47ld.#=z20ohAjI=(this.#=zEhGRLRSSQTM3nxmPHQ==);
		this.#=z_IRaZLu7fTAr.AutoGenerateColumns = false;
		this.#=z_IRaZLu7fTAr.DataSource = this.#=zEhGRLRSSQTM3nxmPHQ==;
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
		this.#=z7w$ql1wK54iI(new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>());
		base.DialogResult = DialogResult.Cancel;
	}

	// Token: 0x06000B3B RID: 2875 RVA: 0x00056590 File Offset: 0x00054790
	public List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zWy14LPFrKhJw()
	{
		return this.#=zUIIMLCzd4mk02RuL3lu1fRQ=;
	}

	// Token: 0x06000B3C RID: 2876 RVA: 0x00056598 File Offset: 0x00054798
	public void #=z7w$ql1wK54iI(List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=z$Ib9gYQ=)
	{
		this.#=zUIIMLCzd4mk02RuL3lu1fRQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B3D RID: 2877 RVA: 0x000565A4 File Offset: 0x000547A4
	public #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==.#=zWcFUKBzZx1_L #=zpJso_yLM1u0C()
	{
		return this.#=zfVVCoyxNZNNBVRs$NQBDHbQ=;
	}

	// Token: 0x06000B3E RID: 2878 RVA: 0x000565AC File Offset: 0x000547AC
	public void #=zICocnal_tob$(#=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==.#=zWcFUKBzZx1_L #=z$Ib9gYQ=)
	{
		this.#=zfVVCoyxNZNNBVRs$NQBDHbQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B3F RID: 2879 RVA: 0x000565B8 File Offset: 0x000547B8
	private void #=zKqxwPI99W3ocv2XRdQ==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		foreach (SelectableAccount selectableAccount in this.#=zEhGRLRSSQTM3nxmPHQ==)
		{
			selectableAccount.IsSelected = true;
		}
		this.#=z_IRaZLu7fTAr.DataSource = null;
		this.#=z_IRaZLu7fTAr.DataSource = this.#=zEhGRLRSSQTM3nxmPHQ==;
	}

	// Token: 0x06000B40 RID: 2880 RVA: 0x00056628 File Offset: 0x00054828
	private void #=zF0WQM9P5ToZU(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> list = new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>();
		foreach (SelectableAccount selectableAccount in this.#=zEhGRLRSSQTM3nxmPHQ==)
		{
			if (selectableAccount.IsSelected && this.#=zcIGb4QLv47ld.#=zQLl7KKs=(selectableAccount))
			{
				list.Add(selectableAccount.#=zh5Q$jgycqA15());
			}
		}
		if (this.#=zpJso_yLM1u0C() != null)
		{
			#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== = this.#=zpJso_yLM1u0C()(list);
			if (#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== != null)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==);
				return;
			}
		}
		this.#=z7w$ql1wK54iI(list);
		base.DialogResult = DialogResult.OK;
		base.Close();
	}

	// Token: 0x06000B41 RID: 2881 RVA: 0x000566D0 File Offset: 0x000548D0
	private void #=zLTTufPconwZT(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		base.Close();
	}

	// Token: 0x06000B42 RID: 2882 RVA: 0x000566D8 File Offset: 0x000548D8
	private void #=z0sH6H1CW6kd3hI$lNg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<SelectableAccount> list = new List<SelectableAccount>();
		for (int i = 0; i < this.#=zEhGRLRSSQTM3nxmPHQ==.Count; i++)
		{
			SelectableAccount selectableAccount = this.#=zEhGRLRSSQTM3nxmPHQ==[i];
			if (this.#=zcIGb4QLv47ld.#=zQLl7KKs=(selectableAccount))
			{
				list.Add(selectableAccount);
			}
		}
		this.#=z_IRaZLu7fTAr.DataSource = list;
	}

	// Token: 0x06000B44 RID: 2884 RVA: 0x00056750 File Offset: 0x00054950
	private void #=zgpzgXirqPT5_()
	{
		this.#=z_IRaZLu7fTAr = new DataGridView();
		this.#=z5fyZbDs= = new DataGridViewCheckBoxColumn();
		this.#=zqH0yfco= = new DataGridViewTextBoxColumn();
		this.#=zB2$PvwI= = new DataGridViewTextBoxColumn();
		this.#=zBJZr5RQg_AI2 = new DataGridViewTextBoxColumn();
		this.#=zp44xwe4= = new DataGridViewTextBoxColumn();
		this.#=zO0jJkos= = new DataGridViewTextBoxColumn();
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zcIGb4QLv47ld = new #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g==();
		this.#=zMGND58EADYqc = new Button();
		this.#=zHeAVXAs= = new Button();
		this.#=zuCaP$Fc= = new Button();
		((ISupportInitialize)this.#=z_IRaZLu7fTAr).BeginInit();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		base.SuspendLayout();
		this.#=z_IRaZLu7fTAr.AllowUserToAddRows = false;
		this.#=z_IRaZLu7fTAr.AllowUserToDeleteRows = false;
		this.#=z_IRaZLu7fTAr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z_IRaZLu7fTAr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z5fyZbDs=,
			this.#=zqH0yfco=,
			this.#=zB2$PvwI=,
			this.#=zBJZr5RQg_AI2,
			this.#=zp44xwe4=,
			this.#=zO0jJkos=
		});
		this.#=z_IRaZLu7fTAr.Dock = DockStyle.Left;
		this.#=z_IRaZLu7fTAr.Location = new Point(0, 0);
		this.#=z_IRaZLu7fTAr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092535);
		this.#=z_IRaZLu7fTAr.Size = new Size(501, 425);
		this.#=z_IRaZLu7fTAr.TabIndex = 0;
		this.#=z5fyZbDs=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113211);
		this.#=z5fyZbDs=.HeaderText = string.Empty;
		this.#=z5fyZbDs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114018);
		this.#=z5fyZbDs=.Width = 30;
		this.#=zqH0yfco=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091921);
		this.#=zqH0yfco=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111056);
		this.#=zqH0yfco=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092505);
		this.#=zqH0yfco=.Width = 50;
		this.#=zB2$PvwI=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092495);
		this.#=zB2$PvwI=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092218);
		this.#=zB2$PvwI=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092858);
		this.#=zB2$PvwI=.Visible = false;
		this.#=zBJZr5RQg_AI2.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092215);
		this.#=zBJZr5RQg_AI2.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092194);
		this.#=zBJZr5RQg_AI2.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092843);
		this.#=zBJZr5RQg_AI2.Visible = false;
		this.#=zp44xwe4=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113168);
		this.#=zp44xwe4=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112603);
		this.#=zp44xwe4=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909092628);
		this.#=zp44xwe4=.Width = 150;
		this.#=zO0jJkos=.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315);
		this.#=zO0jJkos=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zO0jJkos=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111227);
		this.#=zO0jJkos=.Width = 200;
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zcIGb4QLv47ld);
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=z_IRaZLu7fTAr);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zMGND58EADYqc);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zHeAVXAs=);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zuCaP$Fc=);
		this.#=zByiHPAwyKD$Q.Size = new Size(737, 488);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 425;
		this.#=zByiHPAwyKD$Q.TabIndex = 1;
		this.#=zcIGb4QLv47ld.AutoScroll = true;
		this.#=zcIGb4QLv47ld.Dock = DockStyle.Right;
		this.#=zcIGb4QLv47ld.Location = new Point(507, 0);
		this.#=zcIGb4QLv47ld.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091904);
		this.#=zcIGb4QLv47ld.Size = new Size(230, 425);
		this.#=zcIGb4QLv47ld.TabIndex = 1;
		this.#=zcIGb4QLv47ld.#=znoclypZSSO9V(new EventHandler(this.#=z0sH6H1CW6kd3hI$lNg==));
		this.#=zMGND58EADYqc.Location = new Point(25, 24);
		this.#=zMGND58EADYqc.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112462);
		this.#=zMGND58EADYqc.Size = new Size(95, 23);
		this.#=zMGND58EADYqc.TabIndex = 2;
		this.#=zMGND58EADYqc.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114224);
		this.#=zMGND58EADYqc.UseVisualStyleBackColor = true;
		this.#=zMGND58EADYqc.Click += this.#=zKqxwPI99W3ocv2XRdQ==;
		this.#=zHeAVXAs=.Location = new Point(384, 24);
		this.#=zHeAVXAs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111461);
		this.#=zHeAVXAs=.Size = new Size(95, 23);
		this.#=zHeAVXAs=.TabIndex = 1;
		this.#=zHeAVXAs=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111432);
		this.#=zHeAVXAs=.UseVisualStyleBackColor = true;
		this.#=zHeAVXAs=.Click += this.#=zLTTufPconwZT;
		this.#=zuCaP$Fc=.Location = new Point(206, 24);
		this.#=zuCaP$Fc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909112145);
		this.#=zuCaP$Fc=.Size = new Size(95, 23);
		this.#=zuCaP$Fc=.TabIndex = 0;
		this.#=zuCaP$Fc=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051773);
		this.#=zuCaP$Fc=.UseVisualStyleBackColor = true;
		this.#=zuCaP$Fc=.Click += this.#=zF0WQM9P5ToZU;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(737, 488);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091891);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091945);
		((ISupportInitialize)this.#=z_IRaZLu7fTAr).EndInit();
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		base.ResumeLayout(false);
	}

	// Token: 0x04000600 RID: 1536
	private List<SelectableAccount> #=zEhGRLRSSQTM3nxmPHQ==;

	// Token: 0x04000601 RID: 1537
	private List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zUIIMLCzd4mk02RuL3lu1fRQ=;

	// Token: 0x04000602 RID: 1538
	private #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==.#=zWcFUKBzZx1_L #=zfVVCoyxNZNNBVRs$NQBDHbQ=;

	// Token: 0x04000604 RID: 1540
	private DataGridView #=z_IRaZLu7fTAr;

	// Token: 0x04000605 RID: 1541
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x04000606 RID: 1542
	private Button #=zHeAVXAs=;

	// Token: 0x04000607 RID: 1543
	private Button #=zuCaP$Fc=;

	// Token: 0x04000608 RID: 1544
	private Button #=zMGND58EADYqc;

	// Token: 0x04000609 RID: 1545
	private DataGridViewCheckBoxColumn #=z5fyZbDs=;

	// Token: 0x0400060A RID: 1546
	private DataGridViewTextBoxColumn #=zqH0yfco=;

	// Token: 0x0400060B RID: 1547
	private DataGridViewTextBoxColumn #=zB2$PvwI=;

	// Token: 0x0400060C RID: 1548
	private DataGridViewTextBoxColumn #=zBJZr5RQg_AI2;

	// Token: 0x0400060D RID: 1549
	private DataGridViewTextBoxColumn #=zp44xwe4=;

	// Token: 0x0400060E RID: 1550
	private DataGridViewTextBoxColumn #=zO0jJkos=;

	// Token: 0x0400060F RID: 1551
	private #=z$sZ4qvXhkkzDAJGMA$3XVheVR40GCNd01g== #=zcIGb4QLv47ld;

	// Token: 0x0200018A RID: 394
	// (Invoke) Token: 0x06000B46 RID: 2886
	public delegate #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zWcFUKBzZx1_L(List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=z7VCDvQtRk4l6);
}
