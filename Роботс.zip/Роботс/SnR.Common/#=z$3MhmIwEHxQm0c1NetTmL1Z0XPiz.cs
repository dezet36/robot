﻿using System;
using NExcel.Biff;

// Token: 0x0200001D RID: 29
internal sealed class #=z$3MhmIwEHxQm0c1NetTmL1Z0XPiz : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000053 RID: 83 RVA: 0x00003B64 File Offset: 0x00001D64
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zU5hY7Rk=;
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00003B6C File Offset: 0x00001D6C
	internal override int #=zXiDCyaHY58$0()
	{
		return 1;
	}

	// Token: 0x06000055 RID: 85 RVA: 0x00003B70 File Offset: 0x00001D70
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074);
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00003B7C File Offset: 0x00001D7C
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		this.#=z_3UsFxQ=();
		this.#=zSfsW7kY7wg9B();
		sbyte[] array = base.#=ztbIWLuVjfGLU();
		sbyte[] array2 = new sbyte[array.Length + 3];
		Array.Copy(array, 0, array2, 3, array.Length);
		array2[0] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zMK8dwE0VjgfQ.#=zd$BbM3Y=();
		IntegerHelper.getTwoBytes(array.Length, array2, 1);
		return array2;
	}
}
