﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;

// Token: 0x020000D6 RID: 214
internal sealed class #=zCn6$dSEIeGKpKiH$kWD3okBGgnU4
{
	// Token: 0x060005BD RID: 1469 RVA: 0x0002FB98 File Offset: 0x0002DD98
	public #=zCn6$dSEIeGKpKiH$kWD3okBGgnU4()
	{
		this.#=zlEJ0vtHtKO4s3U8$jw== = new List<ProblemType>();
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x0002FBAC File Offset: 0x0002DDAC
	public void #=z48rEd0A=(ProblemType #=zvRLj9WQ=)
	{
		if (!this.#=zlEJ0vtHtKO4s3U8$jw==.Contains(#=zvRLj9WQ=))
		{
			this.#=zlEJ0vtHtKO4s3U8$jw==.Add(#=zvRLj9WQ=);
		}
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x0002FBC8 File Offset: 0x0002DDC8
	public bool #=zR75Bpho=(ProblemType #=zvRLj9WQ=)
	{
		return this.#=zlEJ0vtHtKO4s3U8$jw==.Contains(#=zvRLj9WQ=);
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x0002FBD8 File Offset: 0x0002DDD8
	public object[] #=zhv7OhlM=()
	{
		object[] array = new object[this.#=zlEJ0vtHtKO4s3U8$jw==.Count];
		for (int i = 0; i < this.#=zlEJ0vtHtKO4s3U8$jw==.Count; i++)
		{
			array[i] = (int)this.#=zlEJ0vtHtKO4s3U8$jw==[i];
		}
		return array;
	}

	// Token: 0x04000263 RID: 611
	private List<ProblemType> #=zlEJ0vtHtKO4s3U8$jw==;
}
