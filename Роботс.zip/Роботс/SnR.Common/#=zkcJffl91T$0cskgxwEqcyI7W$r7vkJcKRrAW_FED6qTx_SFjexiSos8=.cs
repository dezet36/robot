﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Interface.Personal;

// Token: 0x02000276 RID: 630
internal sealed partial class #=zkcJffl91T$0cskgxwEqcyI7W$r7vkJcKRrAW_FED6qTx_SFjexiSos8= : Form
{
	// Token: 0x06001306 RID: 4870 RVA: 0x00092DCC File Offset: 0x00090FCC
	public #=zkcJffl91T$0cskgxwEqcyI7W$r7vkJcKRrAW_FED6qTx_SFjexiSos8=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf)
	{
		this.#=zgpzgXirqPT5_();
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=z8StzeqE= = #=zJUGTDqUtMnBf;
		this.#=zLeeSKrg= = #=zJUGTDqUtMnBf.#=zYgvZuBwR$a1C();
		if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zORZWLqrH$ZFy5cmRJncJGtg=() == null)
		{
			#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zdFvFX7WJ2dLoekhK_s_unCQ=(new #=zq49zgVzFmQEFEIYZqjY7n$uNqcTsdLf67$ak29kH10_4UWDThzRs$hi8ZX_YixeqadzF_04=());
		}
		this.#=z6bRJXNQ= = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zORZWLqrH$ZFy5cmRJncJGtg=()[this.#=zLeeSKrg=];
		if (this.#=z6bRJXNQ= == null)
		{
			this.#=z6bRJXNQ= = new #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw=();
			#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zMhe8jCbQi4yh().#=zORZWLqrH$ZFy5cmRJncJGtg=()[this.#=zLeeSKrg=] = this.#=z6bRJXNQ=;
		}
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Checked = this.#=z6bRJXNQ=.#=zXMCL4WkJhi0RMg21OR12cVE=();
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zKTAVzhk=(this.#=z6bRJXNQ=.#=zFNvWMWV7X1qBJxRWn2TCmJ8=());
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Checked = this.#=z6bRJXNQ=.#=zJCnhg5aiYC1jYmN42A==();
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zKTAVzhk=(this.#=z6bRJXNQ=.#=z5PSRkzC6teVxYkOPokgNWCM=());
		this.#=zUKK1QyPD5wu$.Text = this.#=z6bRJXNQ=.#=zBv8Fq3XNR01xFJNdQB6DJ8bti$IXOGJyNQ==().ToString();
		GameApplicationData.GameHosters gameHosters = GameApplicationData.#=z7wsmjLWw49AC();
		GameApplicationData.Games games = GameApplicationData.#=zZ2dsDUeWDYAN();
		this.#=zEvXwmP2x5SRy = new List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl>();
		foreach (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl in #=zKiS5gx37Wa0gGmjsl75y5fEK4XBT.#=z7d1QsAA=().#=zOdy_aU_tk1aY())
		{
			if (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=z7wsmjLWw49AC() == gameHosters && #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zZ2dsDUeWDYAN() == games && this.#=z6bRJXNQ=.#=zqA0_oagr6Vv2qNqwEkcOpe4=().Contains(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zsmHAU_GQ9ylR()))
			{
				this.#=zEvXwmP2x5SRy.Add(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl);
			}
		}
		this.#=z0z0q_8QIqTngmIwy$A==.AutoGenerateColumns = false;
		this.#=zQsixaxrtnmsMU8NKWQ==.Items.Clear();
		this.#=zQsixaxrtnmsMU8NKWQ==.Items.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086067));
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < this.#=zEvXwmP2x5SRy.Count; i++)
		{
			this.#=zQsixaxrtnmsMU8NKWQ==.Items.Add(this.#=zEvXwmP2x5SRy[i].#=zkfqcY3I=());
			if (stringBuilder.Length > 0)
			{
				stringBuilder.AppendLine();
			}
			stringBuilder.Append(this.#=zEvXwmP2x5SRy[i].#=zkfqcY3I=());
		}
		this.#=zsjKnX59AQlBm0_bjxw==.Text = stringBuilder.ToString();
		this.#=z9_D5uZ4hRSgf6OgFOA==.Items.Clear();
		for (int j = 0; j < 8; j++)
		{
			this.#=z9_D5uZ4hRSgf6OgFOA==.Items.Add(j + 1);
		}
		this.#=zQPUlVlnJ14iRiymxHw==();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06001307 RID: 4871 RVA: 0x00093074 File Offset: 0x00091274
	private void #=zXtigX8a5rvQpCdhpMvCFwnI=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			#=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw== #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw== = new #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==();
			try
			{
				if (#=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==.ShowDialog() == DialogResult.OK)
				{
					this.#=zEvXwmP2x5SRy = #=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==.#=zWy14LPFrKhJw();
					HashSet<string> hashSet = new HashSet<string>();
					hashSet.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086067));
					HashSet<string> hashSet2 = hashSet;
					this.#=z6bRJXNQ=.#=zqA0_oagr6Vv2qNqwEkcOpe4=().Clear();
					foreach (#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl #=z3ZBGDpsfh58xULeCrofUs5Z1hNWl in this.#=zEvXwmP2x5SRy)
					{
						this.#=z6bRJXNQ=.#=zqA0_oagr6Vv2qNqwEkcOpe4=().Add(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zsmHAU_GQ9ylR());
						hashSet2.Add(#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl.#=zkfqcY3I=());
					}
					this.#=zQsixaxrtnmsMU8NKWQ==.Items.Clear();
					this.#=zQsixaxrtnmsMU8NKWQ==.Items.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086067));
					StringBuilder stringBuilder = new StringBuilder();
					for (int i = 0; i < this.#=zEvXwmP2x5SRy.Count; i++)
					{
						this.#=zQsixaxrtnmsMU8NKWQ==.Items.Add(this.#=zEvXwmP2x5SRy[i].#=zkfqcY3I=());
						if (stringBuilder.Length > 0)
						{
							stringBuilder.AppendLine();
						}
						stringBuilder.Append(this.#=zEvXwmP2x5SRy[i].#=zkfqcY3I=());
					}
					this.#=zsjKnX59AQlBm0_bjxw==.Text = stringBuilder.ToString();
					foreach (DeferDataWrapper deferDataWrapper in this.#=z8CUgAcphpvt1)
					{
						if (!hashSet2.Contains(deferDataWrapper.TakerUserName))
						{
							deferDataWrapper.TakerUserName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086067);
						}
					}
					this.#=z0z0q_8QIqTngmIwy$A==.Refresh();
				}
			}
			finally
			{
				((IDisposable)#=zQr1o98D$Rpj0fuXTxf1KmReTkGoFby$Gqw==).Dispose();
			}
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x06001308 RID: 4872 RVA: 0x0009329C File Offset: 0x0009149C
	private void #=zQPUlVlnJ14iRiymxHw==()
	{
		string #=zvJ_YhNQgKCZo = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086054));
		this.#=z8CUgAcphpvt1 = new List<DeferDataWrapper>();
		foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in this.#=zshVEGQI=.#=zol80P7TKoihZ())
		{
			if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == this.#=zLeeSKrg= && !string.IsNullOrEmpty(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==()))
			{
				this.#=z8CUgAcphpvt1.Add(new DeferDataWrapper(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==, #=zvJ_YhNQgKCZo));
			}
		}
		this.#=z0z0q_8QIqTngmIwy$A==.DataSource = this.#=z8CUgAcphpvt1;
	}

	// Token: 0x06001309 RID: 4873 RVA: 0x0009334C File Offset: 0x0009154C
	private void #=zlZ6PwIvzuemg5PrEbH2EZDTIGQ5R(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.RowIndex < 0)
		{
			return;
		}
		if (this.#=z0z0q_8QIqTngmIwy$A==.Columns[#=z4Q$h3mE=.ColumnIndex] is DataGridViewComboBoxColumn)
		{
			this.#=z0z0q_8QIqTngmIwy$A==.BeginEdit(true);
			ComboBox comboBox = this.#=z0z0q_8QIqTngmIwy$A==.EditingControl as ComboBox;
			if (comboBox != null)
			{
				comboBox.DroppedDown = true;
			}
		}
	}

	// Token: 0x0600130A RID: 4874 RVA: 0x000933A8 File Offset: 0x000915A8
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zWDFWfXpw$zYBLq_dC4EwEAI=()
	{
		return this.#=z8StzeqE=;
	}

	// Token: 0x0600130B RID: 4875 RVA: 0x000933B0 File Offset: 0x000915B0
	private void #=zZ0btOltDBz5kPH5dJ0SwJ4KGUVjmRvrQpg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z6bRJXNQ=.#=zGe3AVOgg_sTuGQJpVBtdy_4=(this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zVcIxe_4=());
	}

	// Token: 0x0600130C RID: 4876 RVA: 0x000933C8 File Offset: 0x000915C8
	private void #=zyFrncxODQd$tteACupoMeRBB4dZun3rDtw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z6bRJXNQ=.#=zHL2ODY6M9f6oMD4ba$$8Kn8=(this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zVcIxe_4=());
	}

	// Token: 0x0600130D RID: 4877 RVA: 0x000933E0 File Offset: 0x000915E0
	private void #=z7_NkDWBY0xg$SnTYi2UGxxmC0PI_(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z6bRJXNQ=.#=zWmxuWiOCG1UewkLi32up7nU=(this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Checked);
	}

	// Token: 0x0600130E RID: 4878 RVA: 0x000933F8 File Offset: 0x000915F8
	private void #=z7S$kWCeTMHmjxihzUnUaMfoJom38(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z6bRJXNQ=.#=z5_EIUs_W$GlUKgUecw==(this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Checked);
	}

	// Token: 0x0600130F RID: 4879 RVA: 0x00093410 File Offset: 0x00091610
	private void #=z1k6EquevPTqFc1LNcw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		string text = this.#=zUKK1QyPD5wu$.Text;
		if (string.IsNullOrWhiteSpace(text))
		{
			this.#=z6bRJXNQ=.#=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==(1.0);
			return;
		}
		int num;
		int.TryParse(text, out num);
		if (num > 0)
		{
			this.#=z6bRJXNQ=.#=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==((double)num);
			return;
		}
		this.#=zUKK1QyPD5wu$.Text = string.Empty;
		this.#=z6bRJXNQ=.#=znW2RdR_nbPdLVdv8dhakjurxlC2mUye_4A==(1.0);
	}

	// Token: 0x06001310 RID: 4880 RVA: 0x00093488 File Offset: 0x00091688
	private void #=z2ftFA8r7urFXDt0Bn6mOkVXpWa1NolFuHg==(object #=zP95I7AY=, FormClosingEventArgs #=z4Q$h3mE=)
	{
		this.#=z0z0q_8QIqTngmIwy$A==.EndEdit();
	}

	// Token: 0x06001312 RID: 4882 RVA: 0x000934B8 File Offset: 0x000916B8
	private void #=zgpzgXirqPT5_()
	{
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg= = new CheckBox();
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s= = new CheckBox();
		this.#=zpSJ85RJFoJ1JFfJ9VA== = new Button();
		this.#=z0z0q_8QIqTngmIwy$A== = new DataGridView();
		this.#=z8e85VLWXr4rErH$fhjd9eeA= = new #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==();
		this.#=znKaaHoGRTqFrwv5a4UhAZhs= = new #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==();
		this.#=zsjKnX59AQlBm0_bjxw== = new TextBox();
		this.#=zUKK1QyPD5wu$ = new TextBox();
		this.#=z1bvara71Rk0Z = new Label();
		this.#=zyMbX8pBbul0C = new DataGridViewTextBoxColumn();
		this.#=zCEy82wzJcw9s96wxtw== = new DataGridViewTextBoxColumn();
		this.#=zKcvcXKefkGNEgtFcZA== = new DataGridViewTextBoxColumn();
		this.#=z_Bz_RfltKShBg5eqQw== = new DataGridViewTextBoxColumn();
		this.#=z$Jrt5gvF_qkkRNOwRQ== = new DataGridViewTextBoxColumn();
		this.#=zifGQLNaX37Jk = new DataGridViewCheckBoxColumn();
		this.#=zQsixaxrtnmsMU8NKWQ== = new DataGridViewComboBoxColumn();
		this.#=z9_D5uZ4hRSgf6OgFOA== = new DataGridViewComboBoxColumn();
		((ISupportInitialize)this.#=z0z0q_8QIqTngmIwy$A==).BeginInit();
		base.SuspendLayout();
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.AutoSize = true;
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Location = new Point(12, 12);
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086038);
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Size = new Size(92, 17);
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.TabIndex = 0;
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086002);
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.UseVisualStyleBackColor = true;
		this.#=zi0$m9hv2nMWiXlK_zfcqEJg=.CheckedChanged += this.#=z7_NkDWBY0xg$SnTYi2UGxxmC0PI_;
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.AutoSize = true;
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Location = new Point(12, 48);
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085985);
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Size = new Size(81, 17);
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.TabIndex = 1;
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085967);
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.UseVisualStyleBackColor = true;
		this.#=zsRhy_5T7WmVe$qEUdmUkV$s=.CheckedChanged += this.#=z7S$kWCeTMHmjxihzUnUaMfoJom38;
		this.#=zpSJ85RJFoJ1JFfJ9VA==.Location = new Point(12, 84);
		this.#=zpSJ85RJFoJ1JFfJ9VA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086204);
		this.#=zpSJ85RJFoJ1JFfJ9VA==.Size = new Size(155, 23);
		this.#=zpSJ85RJFoJ1JFfJ9VA==.TabIndex = 4;
		this.#=zpSJ85RJFoJ1JFfJ9VA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086181);
		this.#=zpSJ85RJFoJ1JFfJ9VA==.UseVisualStyleBackColor = true;
		this.#=zpSJ85RJFoJ1JFfJ9VA==.Click += this.#=zXtigX8a5rvQpCdhpMvCFwnI=;
		this.#=z0z0q_8QIqTngmIwy$A==.AllowUserToAddRows = false;
		this.#=z0z0q_8QIqTngmIwy$A==.AllowUserToDeleteRows = false;
		this.#=z0z0q_8QIqTngmIwy$A==.AllowUserToResizeRows = false;
		this.#=z0z0q_8QIqTngmIwy$A==.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=z0z0q_8QIqTngmIwy$A==.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=zyMbX8pBbul0C,
			this.#=zCEy82wzJcw9s96wxtw==,
			this.#=zKcvcXKefkGNEgtFcZA==,
			this.#=z_Bz_RfltKShBg5eqQw==,
			this.#=z$Jrt5gvF_qkkRNOwRQ==,
			this.#=zifGQLNaX37Jk,
			this.#=zQsixaxrtnmsMU8NKWQ==,
			this.#=z9_D5uZ4hRSgf6OgFOA==
		});
		this.#=z0z0q_8QIqTngmIwy$A==.Location = new Point(188, 121);
		this.#=z0z0q_8QIqTngmIwy$A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104178);
		this.#=z0z0q_8QIqTngmIwy$A==.RowHeadersVisible = false;
		this.#=z0z0q_8QIqTngmIwy$A==.Size = new Size(838, 317);
		this.#=z0z0q_8QIqTngmIwy$A==.TabIndex = 5;
		this.#=z0z0q_8QIqTngmIwy$A==.CellEnter += this.#=zlZ6PwIvzuemg5PrEbH2EZDTIGQ5R;
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zt7xfAW98hsnE5q54fZ6ajJ8=(false);
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.Location = new Point(110, 48);
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086145);
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.Size = new Size(696, 30);
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.TabIndex = 3;
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zKTAVzhk=(string.Empty);
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zug4zSYskVwSzt_eROw==(new EventHandler(this.#=zyFrncxODQd$tteACupoMeRBB4dZun3rDtw==));
		this.#=z8e85VLWXr4rErH$fhjd9eeA=.#=zvEOFp7j9ovbo(new #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo(this.#=zWDFWfXpw$zYBLq_dC4EwEAI=));
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zt7xfAW98hsnE5q54fZ6ajJ8=(false);
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.Location = new Point(110, 12);
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086120);
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.Size = new Size(696, 30);
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.TabIndex = 2;
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zKTAVzhk=(string.Empty);
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zug4zSYskVwSzt_eROw==(new EventHandler(this.#=zZ0btOltDBz5kPH5dJ0SwJ4KGUVjmRvrQpg==));
		this.#=znKaaHoGRTqFrwv5a4UhAZhs=.#=zvEOFp7j9ovbo(new #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw==.#=zeN_jT4XPbwKo(this.#=zWDFWfXpw$zYBLq_dC4EwEAI=));
		this.#=zsjKnX59AQlBm0_bjxw==.Location = new Point(23, 121);
		this.#=zsjKnX59AQlBm0_bjxw==.Multiline = true;
		this.#=zsjKnX59AQlBm0_bjxw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909086097);
		this.#=zsjKnX59AQlBm0_bjxw==.ReadOnly = true;
		this.#=zsjKnX59AQlBm0_bjxw==.ScrollBars = ScrollBars.Vertical;
		this.#=zsjKnX59AQlBm0_bjxw==.Size = new Size(144, 317);
		this.#=zsjKnX59AQlBm0_bjxw==.TabIndex = 6;
		this.#=zUKK1QyPD5wu$.Location = new Point(418, 86);
		this.#=zUKK1QyPD5wu$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085817);
		this.#=zUKK1QyPD5wu$.Size = new Size(100, 20);
		this.#=zUKK1QyPD5wu$.TabIndex = 7;
		this.#=zUKK1QyPD5wu$.TextChanged += this.#=z1k6EquevPTqFc1LNcw==;
		this.#=z1bvara71Rk0Z.AutoSize = true;
		this.#=z1bvara71Rk0Z.Location = new Point(309, 89);
		this.#=z1bvara71Rk0Z.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085796);
		this.#=z1bvara71Rk0Z.Size = new Size(103, 13);
		this.#=z1bvara71Rk0Z.TabIndex = 8;
		this.#=z1bvara71Rk0Z.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085773);
		this.#=zyMbX8pBbul0C.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315);
		this.#=zyMbX8pBbul0C.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071315);
		this.#=zyMbX8pBbul0C.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085737);
		this.#=zyMbX8pBbul0C.ReadOnly = true;
		this.#=zCEy82wzJcw9s96wxtw==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085715);
		this.#=zCEy82wzJcw9s96wxtw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085698);
		this.#=zCEy82wzJcw9s96wxtw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085938);
		this.#=zCEy82wzJcw9s96wxtw==.ReadOnly = true;
		this.#=zKcvcXKefkGNEgtFcZA==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085912);
		this.#=zKcvcXKefkGNEgtFcZA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085901);
		this.#=zKcvcXKefkGNEgtFcZA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085875);
		this.#=zKcvcXKefkGNEgtFcZA==.ReadOnly = true;
		this.#=z_Bz_RfltKShBg5eqQw==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085843);
		this.#=z_Bz_RfltKShBg5eqQw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909085828);
		this.#=z_Bz_RfltKShBg5eqQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087605);
		this.#=z_Bz_RfltKShBg5eqQw==.ReadOnly = true;
		this.#=z$Jrt5gvF_qkkRNOwRQ==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087573);
		this.#=z$Jrt5gvF_qkkRNOwRQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087550);
		this.#=z$Jrt5gvF_qkkRNOwRQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087533);
		this.#=z$Jrt5gvF_qkkRNOwRQ==.ReadOnly = true;
		this.#=zifGQLNaX37Jk.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087501);
		this.#=zifGQLNaX37Jk.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087740);
		this.#=zifGQLNaX37Jk.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087721);
		this.#=zQsixaxrtnmsMU8NKWQ==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087697);
		this.#=zQsixaxrtnmsMU8NKWQ==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087685);
		this.#=zQsixaxrtnmsMU8NKWQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087657);
		this.#=z9_D5uZ4hRSgf6OgFOA==.DataPropertyName = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087632);
		this.#=z9_D5uZ4hRSgf6OgFOA==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087618);
		this.#=z9_D5uZ4hRSgf6OgFOA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087358);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(1054, 450);
		base.Controls.Add(this.#=z1bvara71Rk0Z);
		base.Controls.Add(this.#=zUKK1QyPD5wu$);
		base.Controls.Add(this.#=zsjKnX59AQlBm0_bjxw==);
		base.Controls.Add(this.#=z0z0q_8QIqTngmIwy$A==);
		base.Controls.Add(this.#=zpSJ85RJFoJ1JFfJ9VA==);
		base.Controls.Add(this.#=z8e85VLWXr4rErH$fhjd9eeA=);
		base.Controls.Add(this.#=znKaaHoGRTqFrwv5a4UhAZhs=);
		base.Controls.Add(this.#=zsRhy_5T7WmVe$qEUdmUkV$s=);
		base.Controls.Add(this.#=zi0$m9hv2nMWiXlK_zfcqEJg=);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087322);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909087322);
		base.FormClosing += this.#=z2ftFA8r7urFXDt0Bn6mOkVXpWa1NolFuHg==;
		((ISupportInitialize)this.#=z0z0q_8QIqTngmIwy$A==).EndInit();
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000AEA RID: 2794
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000AEB RID: 2795
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000AEC RID: 2796
	private int #=zLeeSKrg=;

	// Token: 0x04000AED RID: 2797
	private #=zO0pZDIBUU$D8Il6U66tv2WQQ1bTbCGUU_q$KxbsgijCznK40veKcjGlMZBTCTcZ2X3JhySw= #=z6bRJXNQ=;

	// Token: 0x04000AEE RID: 2798
	private List<#=z3ZBGDpsfh58xULeCrofUs5Z1hNWl> #=zEvXwmP2x5SRy;

	// Token: 0x04000AEF RID: 2799
	private List<DeferDataWrapper> #=z8CUgAcphpvt1;

	// Token: 0x04000AF1 RID: 2801
	private CheckBox #=zi0$m9hv2nMWiXlK_zfcqEJg=;

	// Token: 0x04000AF2 RID: 2802
	private CheckBox #=zsRhy_5T7WmVe$qEUdmUkV$s=;

	// Token: 0x04000AF3 RID: 2803
	private #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw== #=znKaaHoGRTqFrwv5a4UhAZhs=;

	// Token: 0x04000AF4 RID: 2804
	private #=zanGez1y6ixXU2ZoYLARJoV_deONFQiOxsw== #=z8e85VLWXr4rErH$fhjd9eeA=;

	// Token: 0x04000AF5 RID: 2805
	private Button #=zpSJ85RJFoJ1JFfJ9VA==;

	// Token: 0x04000AF6 RID: 2806
	private DataGridView #=z0z0q_8QIqTngmIwy$A==;

	// Token: 0x04000AF7 RID: 2807
	private TextBox #=zsjKnX59AQlBm0_bjxw==;

	// Token: 0x04000AF8 RID: 2808
	private TextBox #=zUKK1QyPD5wu$;

	// Token: 0x04000AF9 RID: 2809
	private Label #=z1bvara71Rk0Z;

	// Token: 0x04000AFA RID: 2810
	private DataGridViewTextBoxColumn #=zyMbX8pBbul0C;

	// Token: 0x04000AFB RID: 2811
	private DataGridViewTextBoxColumn #=zCEy82wzJcw9s96wxtw==;

	// Token: 0x04000AFC RID: 2812
	private DataGridViewTextBoxColumn #=zKcvcXKefkGNEgtFcZA==;

	// Token: 0x04000AFD RID: 2813
	private DataGridViewTextBoxColumn #=z_Bz_RfltKShBg5eqQw==;

	// Token: 0x04000AFE RID: 2814
	private DataGridViewTextBoxColumn #=z$Jrt5gvF_qkkRNOwRQ==;

	// Token: 0x04000AFF RID: 2815
	private DataGridViewCheckBoxColumn #=zifGQLNaX37Jk;

	// Token: 0x04000B00 RID: 2816
	private DataGridViewComboBoxColumn #=zQsixaxrtnmsMU8NKWQ==;

	// Token: 0x04000B01 RID: 2817
	private DataGridViewComboBoxColumn #=z9_D5uZ4hRSgf6OgFOA==;
}
