﻿using System;
using NExcel.Biff.Drawing;

// Token: 0x0200009A RID: 154
internal sealed class #=z7pcyw1AW7L1ukcs4jMpNGNyqZ6qe : EscherContainer
{
	// Token: 0x06000422 RID: 1058 RVA: 0x000243D8 File Offset: 0x000225D8
	public #=z7pcyw1AW7L1ukcs4jMpNGNyqZ6qe() : base(EscherRecordType.DG_CONTAINER)
	{
	}
}
