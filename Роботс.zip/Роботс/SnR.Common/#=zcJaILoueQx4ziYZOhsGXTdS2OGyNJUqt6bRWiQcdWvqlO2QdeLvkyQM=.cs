﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000214 RID: 532
internal sealed class #=zcJaILoueQx4ziYZOhsGXTdS2OGyNJUqt6bRWiQcdWvqlO2QdeLvkyQM= : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600104F RID: 4175 RVA: 0x0007DB3C File Offset: 0x0007BD3C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zNA3wycrO1gxV = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
	}

	// Token: 0x06001050 RID: 4176 RVA: 0x0007DB4C File Offset: 0x0007BD4C
	protected override void #=zvb5bnug=()
	{
		bool flag = false;
		using (List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==>.Enumerator enumerator = this.#=zNA3wycrO1gxV.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				if (enumerator.Current.#=zzO1Tc28mhiyKO1MslOQ8t9E=())
				{
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071931), Array.Empty<object>());
			base.#=zL1HTbwC75LO$(JSONManager.GetData(this.#=zBsXSanI=.#=zeoI_JM$qmO3Jp7VRURuP390=()));
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967272), Array.Empty<object>());
		foreach (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== in this.#=zNA3wycrO1gxV)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsTakeAllianceBattleRewards && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zsGegpFIDm4HnM1ZwbMKrm1OyKO$D())
			{
				this.#=zBEda9TSz0MeHgTUYVe3qB3KojIaN8d58Pe5x9lE=(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==);
			}
			if (#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zosN4hoVyBAOs() && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zN0c_qE6yJTk7() && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zzO1Tc28mhiyKO1MslOQ8t9E=() && #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=() > 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967245), new object[]
				{
					#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
				});
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967187), new object[]
				{
					#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zKa2XiiZl7goe(),
					#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zuCvgEb_H$DFbBGNJwMU4czc=()
				});
				List<int> list = new List<int>();
				foreach (int[] array in #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zmwrfSHHI86R4$A6xvA==())
				{
					int num = -1;
					if (array.Length == 1)
					{
						num = array[0];
					}
					else if (array.Length == 2)
					{
						num = array[this.#=z8StzeqE=.#=zv2Kyu17YrGOC().CloseTournmentsChoice];
					}
					if (num >= 0)
					{
						list.Add(num);
					}
				}
				List<int> list2 = new List<int>();
				foreach (int[] array2 in #=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zdNyHlR6WcSxIgrGCoPjPDmc3An1R())
				{
					int num2 = -1;
					if (array2.Length == 1)
					{
						num2 = array2[0];
					}
					else if (array2.Length == 2)
					{
						num2 = array2[this.#=z8StzeqE=.#=zv2Kyu17YrGOC().CloseTournmentsChoice];
					}
					if (num2 >= 0)
					{
						list2.Add(num2);
					}
				}
				if (list.Count > 0 || list2.Count > 0)
				{
					string text = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=(), list2);
					text = text.Trim();
					if (text.Length < 1000 && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967369)))
					{
						text = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=(), list);
						text = text.Trim();
					}
					if (text.Length < 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967336), new object[]
						{
							#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=(),
							text
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967038), new object[]
						{
							#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
						});
					}
				}
				else
				{
					string text2 = this.#=zBsXSanI=.#=zV6M29KZ6UHBruxlfRg==(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zMuFMjGQ=(), null);
					if (text2.Length < 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967336), new object[]
						{
							#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=(),
							text2
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967038), new object[]
						{
							#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==.#=zkfqcY3I=()
						});
					}
				}
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967000), Array.Empty<object>());
	}

	// Token: 0x06001051 RID: 4177 RVA: 0x0007DFC4 File Offset: 0x0007C1C4
	private void #=zBEda9TSz0MeHgTUYVe3qB3KojIaN8d58Pe5x9lE=(#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g== #=zQhApCGmlHqRA)
	{
		if (!#=zQhApCGmlHqRA.#=zsGegpFIDm4HnM1ZwbMKrm1OyKO$D())
		{
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966973), Array.Empty<object>());
		if (#=zQhApCGmlHqRA.#=zuDNrgEn6avv5JV0$utd1XIH$Fx8Rf0nEkA==() > #=zQhApCGmlHqRA.#=zs4VItRnK8RHCsmBP1UyCU4NH2aiPL5bfuGvC00TmOQZJ().Length)
		{
			for (int i = 0; i < #=zQhApCGmlHqRA.#=zuDNrgEn6avv5JV0$utd1XIH$Fx8Rf0nEkA==(); i++)
			{
				bool flag = false;
				for (int j = 0; j < #=zQhApCGmlHqRA.#=zs4VItRnK8RHCsmBP1UyCU4NH2aiPL5bfuGvC00TmOQZJ().Length; j++)
				{
					if (Convert.ToInt32(#=zQhApCGmlHqRA.#=zs4VItRnK8RHCsmBP1UyCU4NH2aiPL5bfuGvC00TmOQZJ()[j]) == i)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					string text = this.#=zBsXSanI=.#=zJ1FwoaaqOFkpVB2rfr0dJxT1h7gUiw4BmoUT1zQ=(#=zQhApCGmlHqRA.#=zd$BbM3Y=(), i, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().CloseTournmentsChoice);
					if (text.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908966930), new object[]
						{
							#=zQhApCGmlHqRA.#=zkfqcY3I=(),
							i + 1
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967130), new object[]
						{
							#=zQhApCGmlHqRA.#=zkfqcY3I=(),
							i + 1,
							JSONManager.Cut(text)
						});
					}
				}
			}
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908967065), Array.Empty<object>());
		}
		string text2 = this.#=zBsXSanI=.#=z8LWNGrA1C1FBGjTFm81QLCsdQOhAL_0iDyrEmse0LL7A(#=zQhApCGmlHqRA.#=zd$BbM3Y=());
		if (text2.Length > 1000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952400), new object[]
			{
				#=zQhApCGmlHqRA.#=zkfqcY3I=()
			});
			return;
		}
		if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952359)))
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952340), new object[]
			{
				#=zQhApCGmlHqRA.#=zkfqcY3I=()
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952539), new object[]
		{
			#=zQhApCGmlHqRA.#=zkfqcY3I=(),
			JSONManager.Cut(text2)
		});
	}

	// Token: 0x040008F0 RID: 2288
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zNA3wycrO1gxV;
}
