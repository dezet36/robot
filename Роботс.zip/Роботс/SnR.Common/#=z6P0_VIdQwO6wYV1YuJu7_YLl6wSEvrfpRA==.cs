﻿using System;
using System.Management;
using System.Security.Cryptography;
using System.Text;

// Token: 0x0200007D RID: 125
internal static class #=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==
{
	// Token: 0x06000388 RID: 904 RVA: 0x0001F998 File Offset: 0x0001DB98
	public static string #=zYhB1CCJa0Gd_()
	{
		string result;
		using (SHA256 sha = SHA256.Create())
		{
			string s = string.Join(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908939112), new string[]
			{
				Environment.MachineName,
				Environment.ProcessorCount.ToString(),
				#=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==.#=zqV2foA1jKdUg(),
				#=z6P0_VIdQwO6wYV1YuJu7_YLl6wSEvrfpRA==.#=zOjcJx8_qepDU()
			});
			result = Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(s)));
		}
		return result;
	}

	// Token: 0x06000389 RID: 905 RVA: 0x0001FA20 File Offset: 0x0001DC20
	private static string #=zqV2foA1jKdUg()
	{
		try
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929542));
			try
			{
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (managementObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929992)] != null)
					{
						return managementObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929992)].ToString().Trim();
					}
				}
			}
			finally
			{
				((IDisposable)managementObjectSearcher).Dispose();
			}
		}
		catch
		{
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929754);
	}

	// Token: 0x0600038A RID: 906 RVA: 0x0001FAE4 File Offset: 0x0001DCE4
	private static string #=zOjcJx8_qepDU()
	{
		try
		{
			ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929737));
			try
			{
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					if (managementObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929992)] != null)
					{
						return managementObject[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929992)].ToString().Trim();
					}
				}
			}
			finally
			{
				((IDisposable)managementObjectSearcher).Dispose();
			}
		}
		catch
		{
		}
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929709);
	}
}
