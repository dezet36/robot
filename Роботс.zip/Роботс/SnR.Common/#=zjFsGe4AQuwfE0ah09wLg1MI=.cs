﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000267 RID: 615
internal sealed class #=zjFsGe4AQuwfE0ah09wLg1MI= : CellValue, LabelCell, Cell
{
	// Token: 0x060012A1 RID: 4769 RVA: 0x00091974 File Offset: 0x0008FB74
	public #=zjFsGe4AQuwfE0ah09wLg1MI=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=, WorkbookSettings #=z4JisLog=, #=zjFsGe4AQuwfE0ah09wLg1MI=.#=zlfjpmgW14u47 #=zMY9_HRM=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=z7HqoPh0= = IntegerHelper.getInt(data[6], data[7]);
		this.#=zaiKvawI= = StringHelper.getString(data, this.#=z7HqoPh0=, 8, #=z4JisLog=);
	}

	// Token: 0x17000061 RID: 97
	// (get) Token: 0x060012A3 RID: 4771 RVA: 0x000919C8 File Offset: 0x0008FBC8
	public string StringValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000062 RID: 98
	// (get) Token: 0x060012A4 RID: 4772 RVA: 0x000919D0 File Offset: 0x0008FBD0
	public override object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000063 RID: 99
	// (get) Token: 0x060012A5 RID: 4773 RVA: 0x000919D8 File Offset: 0x0008FBD8
	public new string Contents
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000064 RID: 100
	// (get) Token: 0x060012A6 RID: 4774 RVA: 0x000919E0 File Offset: 0x0008FBE0
	public new CellType Type
	{
		get
		{
			return CellType.LABEL;
		}
	}

	// Token: 0x04000ABB RID: 2747
	private int #=z7HqoPh0=;

	// Token: 0x04000ABC RID: 2748
	private string #=zaiKvawI=;

	// Token: 0x04000ABD RID: 2749
	public static #=zjFsGe4AQuwfE0ah09wLg1MI=.#=zlfjpmgW14u47 #=zJxoWYNQIfgMz = new #=zjFsGe4AQuwfE0ah09wLg1MI=.#=zlfjpmgW14u47();

	// Token: 0x02000268 RID: 616
	public sealed class #=zlfjpmgW14u47
	{
	}
}
