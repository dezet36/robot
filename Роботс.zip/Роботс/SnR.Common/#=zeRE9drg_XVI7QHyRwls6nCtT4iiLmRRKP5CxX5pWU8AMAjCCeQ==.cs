﻿using System;
using System.Collections.Generic;
using System.Linq;
using Skink.SnR.Common.Units;

// Token: 0x0200022B RID: 555
internal sealed class #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ== : UnitSquad
{
	// Token: 0x06001106 RID: 4358 RVA: 0x00083064 File Offset: 0x00081264
	private #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==(UnitType #=zvRLj9WQ=, int #=zXHTER4Q=, UnitSquadCollection #=zVILwo49oIM52, int #=zwJeHH7seY1bgLD8IOw==) : base(#=zvRLj9WQ=, #=zXHTER4Q=)
	{
		this.#=zDI6TFPb_jPhyNbuviw==(#=zVILwo49oIM52);
		this.#=zxx$HJnezqKWeJ0eJBQiKjc8=(#=zwJeHH7seY1bgLD8IOw==);
	}

	// Token: 0x06001107 RID: 4359 RVA: 0x00083080 File Offset: 0x00081280
	public UnitSquadCollection #=zUh0YLXs8xYVxIEYFOQ==()
	{
		return this.#=zvkTM7Cr3PxqnaMuZUUOzvBQ=;
	}

	// Token: 0x06001108 RID: 4360 RVA: 0x00083088 File Offset: 0x00081288
	public void #=zDI6TFPb_jPhyNbuviw==(UnitSquadCollection #=z$Ib9gYQ=)
	{
		this.#=zvkTM7Cr3PxqnaMuZUUOzvBQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001109 RID: 4361 RVA: 0x00083094 File Offset: 0x00081294
	public int #=zDlfcC$kY8j_2tynD7ite18I=()
	{
		return this.#=zONuzsUV_KBUeUcrq0eDuUyE9Xe7a;
	}

	// Token: 0x0600110A RID: 4362 RVA: 0x0008309C File Offset: 0x0008129C
	public void #=zxx$HJnezqKWeJ0eJBQiKjc8=(int #=z$Ib9gYQ=)
	{
		this.#=zONuzsUV_KBUeUcrq0eDuUyE9Xe7a = #=z$Ib9gYQ=;
	}

	// Token: 0x0600110B RID: 4363 RVA: 0x000830A8 File Offset: 0x000812A8
	public double #=zU7KLmK0=()
	{
		if (base.Type.Function == UnitType.Functions.Defence)
		{
			return base.Type.Strength.Defense * (double)base.Number + Enumerable.Sum<UnitSquad>(this.#=zUh0YLXs8xYVxIEYFOQ==(), new Func<UnitSquad, double>(#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zOrrOc_INO5HjTyxC$A==));
		}
		return base.Type.Strength.Attack * (double)base.Number + Enumerable.Sum<UnitSquad>(this.#=zUh0YLXs8xYVxIEYFOQ==(), new Func<UnitSquad, double>(#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=.#=zLkw0NRU=.#=z3DPduFmZ86BP8kPNnw==));
	}

	// Token: 0x0600110C RID: 4364 RVA: 0x0008314C File Offset: 0x0008134C
	public override double GetConsumption()
	{
		return base.Type.Consumption * (double)base.Number + Enumerable.Sum<UnitSquad>(this.#=zUh0YLXs8xYVxIEYFOQ==(), new Func<UnitSquad, double>(#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zvtE2_ULOXvEy8nwLDE$eNH6ghCKiWEdtVA==));
	}

	// Token: 0x0600110D RID: 4365 RVA: 0x0008318C File Offset: 0x0008138C
	public override double GetStrengthPerConsumption()
	{
		double consumption = this.GetConsumption();
		if (consumption > 0.0)
		{
			return this.#=zU7KLmK0=() / consumption;
		}
		return 999999.0;
	}

	// Token: 0x0600110E RID: 4366 RVA: 0x000831C0 File Offset: 0x000813C0
	public static List<#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==> #=zTDmMhEqM6TVu4F4rmym2iJlz9OJo9Yp42p_ZAZA=(UnitSquadCollection #=zZ0NLbUc=, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD)
	{
		List<#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==> list = new List<#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==>();
		UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
		for (int i = #=zZ0NLbUc=.Count - 1; i >= 0; i--)
		{
			if (#=zZ0NLbUc=[i].Type.IsStrategic)
			{
				unitSquadCollection.Add(#=zZ0NLbUc=[i]);
				#=zZ0NLbUc=.RemoveAt(i);
			}
		}
		unitSquadCollection.Sort(new #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zJtfyX8b8ncJoiylTwA==());
		#=zZ0NLbUc=.Sort(new Comparison<UnitSquad>(#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zTVnE5fHbEPJAAjUKKW1GsrWuFUElEZRTR3ok9dt3$ifBh$UNjA==));
		for (int j = unitSquadCollection.Count - 1; j >= 0; j--)
		{
			UnitSquad unitSquad = unitSquadCollection[j];
			UnitSquadCollection unitSquadCollection2 = new UnitSquadCollection();
			int num = #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=z1piEfs5T1oS1V$qSHw==(unitSquad.Type, #=zMEwuTGAUgTDD);
			int num2 = unitSquad.Number * num;
			for (int k = #=zZ0NLbUc=.Count - 1; k >= 0; k--)
			{
				UnitSquad unitSquad2 = #=zZ0NLbUc=[k];
				if (unitSquad.Type.StrategicData.MinionBonus.ContainsKey(unitSquad2.Type.Id))
				{
					if (unitSquad2.Number >= num2)
					{
						unitSquadCollection2.AddUnits(unitSquad2.Type, num2);
						break;
					}
					unitSquadCollection2.AddUnits(unitSquad2.Type, unitSquad2.Number);
					num2 -= unitSquad2.Number;
				}
			}
			int totalNumber = unitSquadCollection2.TotalNumber;
			int num3 = totalNumber / num;
			if (num3 > 0)
			{
				int num4 = totalNumber - num3 * num;
				if (num4 > 0)
				{
					unitSquadCollection2.Sort(new Comparison<UnitSquad>(#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=.#=zLkw0NRU=.#=z7eHB_m2jH9BPx48LuR_VGKT4wdf9rxGy0my3WID7k3UQp74siw==));
					for (int l = unitSquadCollection2.Count - 1; l >= 0; l--)
					{
						UnitSquad unitSquad3 = unitSquadCollection2[l];
						if (unitSquad3.Number > num4)
						{
							unitSquad3.Number -= num4;
							break;
						}
						unitSquadCollection2.RemoveAt(l);
						num4 -= unitSquad3.Number;
					}
				}
				#=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ== item = new #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==(unitSquad.Type, num3, unitSquadCollection2, num);
				list.Add(item);
				#=zZ0NLbUc=.RemoveUnits(unitSquadCollection2);
			}
		}
		return list;
	}

	// Token: 0x0600110F RID: 4367 RVA: 0x000833CC File Offset: 0x000815CC
	private static int #=z1piEfs5T1oS1V$qSHw==(UnitType #=zrg1DKr2Z9_Z6, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zMEwuTGAUgTDD)
	{
		if (#=zrg1DKr2Z9_Z6.StrategicData == null)
		{
			return 0;
		}
		if (#=zrg1DKr2Z9_Z6.StrategicData.MinionsNumberTechTypeId <= 0)
		{
			return #=zrg1DKr2Z9_Z6.StrategicData.MinionsNumber;
		}
		int num = 0;
		try
		{
			#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== = #=zMEwuTGAUgTDD.#=zk$6QZNA=(#=zrg1DKr2Z9_Z6.StrategicData.MinionsNumberTechTypeId);
			num = #=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zq2bPTdY=().#=zsWzBQdkf_CIsUJr7$Ln2aos=().#=z2oIM6JEk6QZGsx83FQ==()[#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==.#=zvnZc$RhG_1Du() - 1];
		}
		catch
		{
		}
		return (int)Math.Round((double)#=zrg1DKr2Z9_Z6.StrategicData.MinionsNumber * (1.0 + (double)num / 100.0));
	}

	// Token: 0x0400093A RID: 2362
	private UnitSquadCollection #=zvkTM7Cr3PxqnaMuZUUOzvBQ=;

	// Token: 0x0400093B RID: 2363
	private int #=zONuzsUV_KBUeUcrq0eDuUyE9Xe7a;

	// Token: 0x0200022C RID: 556
	internal sealed class #=zJtfyX8b8ncJoiylTwA== : IComparer<UnitSquad>
	{
		// Token: 0x06001111 RID: 4369 RVA: 0x00083474 File Offset: 0x00081674
		public int Compare(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			if (#=zm8PpuDU=.Type.StrategicData.MaxMinionClass > #=zcltuPyw=.Type.StrategicData.MaxMinionClass)
			{
				if (#=zm8PpuDU=.Type.StrategicData.MinMinionClass > #=zcltuPyw=.Type.StrategicData.MinMinionClass)
				{
					return 1;
				}
				return -1;
			}
			else if (#=zm8PpuDU=.Type.StrategicData.MaxMinionClass < #=zcltuPyw=.Type.StrategicData.MaxMinionClass)
			{
				if (#=zm8PpuDU=.Type.StrategicData.MinMinionClass < #=zcltuPyw=.Type.StrategicData.MinMinionClass)
				{
					return -1;
				}
				return 1;
			}
			else
			{
				if (#=zm8PpuDU=.Type.StrategicData.MinMinionClass > #=zcltuPyw=.Type.StrategicData.MinMinionClass)
				{
					return 1;
				}
				if (#=zm8PpuDU=.Type.StrategicData.MinMinionClass < #=zcltuPyw=.Type.StrategicData.MinMinionClass)
				{
					return -1;
				}
				return #=zm8PpuDU=.Type.StrategicData.MaxAvailableStrengthPerConsumption.CompareTo(#=zcltuPyw=.Type.StrategicData.MaxAvailableStrengthPerConsumption);
			}
		}
	}

	// Token: 0x0200022D RID: 557
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06001114 RID: 4372 RVA: 0x00083598 File Offset: 0x00081798
		internal double #=zOrrOc_INO5HjTyxC$A==(UnitSquad #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type.Strength.Defense * (double)#=zQrqFdos=.Number;
		}

		// Token: 0x06001115 RID: 4373 RVA: 0x000835B4 File Offset: 0x000817B4
		internal double #=z3DPduFmZ86BP8kPNnw==(UnitSquad #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type.Strength.Attack * (double)#=zQrqFdos=.Number;
		}

		// Token: 0x06001116 RID: 4374 RVA: 0x000835D0 File Offset: 0x000817D0
		internal double #=zvtE2_ULOXvEy8nwLDE$eNH6ghCKiWEdtVA==(UnitSquad #=zQrqFdos=)
		{
			return #=zQrqFdos=.Type.Consumption * (double)#=zQrqFdos=.Number;
		}

		// Token: 0x06001117 RID: 4375 RVA: 0x000835E8 File Offset: 0x000817E8
		internal int #=zTVnE5fHbEPJAAjUKKW1GsrWuFUElEZRTR3ok9dt3$ifBh$UNjA==(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			return #=zm8PpuDU=.Type.StrengthPerConsumption.CompareTo(#=zcltuPyw=.Type.StrengthPerConsumption);
		}

		// Token: 0x06001118 RID: 4376 RVA: 0x00083614 File Offset: 0x00081814
		internal int #=z7eHB_m2jH9BPx48LuR_VGKT4wdf9rxGy0my3WID7k3UQp74siw==(UnitSquad #=zm8PpuDU=, UnitSquad #=zcltuPyw=)
		{
			return #=zcltuPyw=.Type.StrengthPerConsumption.CompareTo(#=zm8PpuDU=.Type.StrengthPerConsumption);
		}

		// Token: 0x0400093C RID: 2364
		public static readonly #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU= #=zLkw0NRU= = new #=zeRE9drg_XVI7QHyRwls6nCtT4iiLmRRKP5CxX5pWU8AMAjCCeQ==.#=zyDNvciU=();

		// Token: 0x0400093D RID: 2365
		public static Func<UnitSquad, double> #=zLLcqwWqPPIJnz60lVA==;

		// Token: 0x0400093E RID: 2366
		public static Func<UnitSquad, double> #=zkgWKQi39p3FHh_Q9EQ==;

		// Token: 0x0400093F RID: 2367
		public static Func<UnitSquad, double> #=zQMgwRPHblNnKBhJcMQ==;

		// Token: 0x04000940 RID: 2368
		public static Comparison<UnitSquad> #=zbaoW3zbmp2urVzSQ6A==;

		// Token: 0x04000941 RID: 2369
		public static Comparison<UnitSquad> #=zgmcmspVnZnf_DaY9fg==;
	}
}
