﻿using System;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x0200024C RID: 588
internal sealed class #=zgmkRIiECuI_fCjgdr$M4Orc= : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x060011DD RID: 4573 RVA: 0x0008A3A8 File Offset: 0x000885A8
	public #=zgmkRIiECuI_fCjgdr$M4Orc=(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=zqhzsoGg= = this.Instance;
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		this.#=z73f3wYo= = IntegerHelper.getInt(array[0], array[1], array[2], array[3]);
		this.#=zDVlfpM8= = IntegerHelper.getInt(array[4], array[5], array[6], array[7]);
	}

	// Token: 0x060011DE RID: 4574 RVA: 0x0008A400 File Offset: 0x00088600
	public #=zgmkRIiECuI_fCjgdr$M4Orc=(#=zgmkRIiECuI_fCjgdr$M4Orc=.#=zslbkns0= #=zfN6NveI=, int #=zta02Of8=, int #=z6Q8LaXo=) : base(EscherRecordType.SP)
	{
		this.Version = 2;
		this.#=zqhzsoGg= = #=zfN6NveI=.#=zziO1gvU=;
		this.#=z73f3wYo= = #=zta02Of8=;
		this.#=zDVlfpM8= = #=z6Q8LaXo=;
		this.Instance = this.#=zqhzsoGg=;
	}

	// Token: 0x060011E0 RID: 4576 RVA: 0x0008A458 File Offset: 0x00088658
	internal int #=zXT1B86$yTpji()
	{
		return this.#=z73f3wYo=;
	}

	// Token: 0x17000057 RID: 87
	// (get) Token: 0x060011E1 RID: 4577 RVA: 0x0008A460 File Offset: 0x00088660
	public override sbyte[] Data
	{
		get
		{
			this.#=zJ5GWysk= = new sbyte[8];
			IntegerHelper.getFourBytes(this.#=z73f3wYo=, this.#=zJ5GWysk=, 0);
			IntegerHelper.getFourBytes(this.#=zDVlfpM8=, this.#=zJ5GWysk=, 4);
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x040009FC RID: 2556
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x040009FD RID: 2557
	private int #=zqhzsoGg=;

	// Token: 0x040009FE RID: 2558
	private int #=z73f3wYo=;

	// Token: 0x040009FF RID: 2559
	private int #=zDVlfpM8=;

	// Token: 0x04000A00 RID: 2560
	public static readonly #=zgmkRIiECuI_fCjgdr$M4Orc=.#=zslbkns0= #=zJgtibdo= = new #=zgmkRIiECuI_fCjgdr$M4Orc=.#=zslbkns0=(0);

	// Token: 0x04000A01 RID: 2561
	public static readonly #=zgmkRIiECuI_fCjgdr$M4Orc=.#=zslbkns0= #=zDlrjk$wlLqxh1qnaWQ== = new #=zgmkRIiECuI_fCjgdr$M4Orc=.#=zslbkns0=(75);

	// Token: 0x0200024D RID: 589
	public sealed class #=zslbkns0=
	{
		// Token: 0x060011E2 RID: 4578 RVA: 0x0008A4A0 File Offset: 0x000886A0
		internal #=zslbkns0=(int #=z3GDTqqw=)
		{
			this.#=zziO1gvU= = #=z3GDTqqw=;
		}

		// Token: 0x04000A02 RID: 2562
		internal int #=zziO1gvU=;
	}
}
