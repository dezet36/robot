﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000D0 RID: 208
internal sealed class #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==
{
	// Token: 0x06000589 RID: 1417 RVA: 0x0002EAF8 File Offset: 0x0002CCF8
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x0002EB00 File Offset: 0x0002CD00
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0002EB0C File Offset: 0x0002CD0C
	public string #=zgghOPx1cfudx5wYhjw==()
	{
		return this.#=zNT0hJfLlJeh_YXWrT9P973k=;
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x0002EB14 File Offset: 0x0002CD14
	public void #=zgEoShpNKDDTtZaEW1g==(string #=z$Ib9gYQ=)
	{
		this.#=zNT0hJfLlJeh_YXWrT9P973k= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0002EB20 File Offset: 0x0002CD20
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0002EB28 File Offset: 0x0002CD28
	public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x0002EB34 File Offset: 0x0002CD34
	public #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zzasQXAPWhOif()
	{
		return this.#=zkanVdU4qSKZQX0s_fw==;
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x0002EB3C File Offset: 0x0002CD3C
	public void #=z3y$Jd2Y9Ey5E(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=z$Ib9gYQ=)
	{
		this.#=zkanVdU4qSKZQX0s_fw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x0002EB48 File Offset: 0x0002CD48
	public int #=z9OkNmQe3tJa6tN2MkA==()
	{
		return this.#=z2N2E$4lindOXXEmoUvS57x5m23Mf;
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x0002EB50 File Offset: 0x0002CD50
	public void #=zq3PpF70fIqbhwP$vag==(int #=z$Ib9gYQ=)
	{
		this.#=z2N2E$4lindOXXEmoUvS57x5m23Mf = #=z$Ib9gYQ=;
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x0002EB5C File Offset: 0x0002CD5C
	public int #=z4i7DNJN0d7zCbKfc$w==()
	{
		return this.#=zztzYpTdhqjMFb4a0kF2jwPuNLILD;
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x0002EB64 File Offset: 0x0002CD64
	public void #=ztebJQq4nB16H22LArw==(int #=z$Ib9gYQ=)
	{
		this.#=zztzYpTdhqjMFb4a0kF2jwPuNLILD = #=z$Ib9gYQ=;
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x0002EB70 File Offset: 0x0002CD70
	public int #=zhw2gpAK2vADM()
	{
		return this.#=zB4k1DdLAiZaGwezVVQ==;
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x0002EB78 File Offset: 0x0002CD78
	public void #=z_Nuury_Hqz6r(int #=z$Ib9gYQ=)
	{
		this.#=zB4k1DdLAiZaGwezVVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000597 RID: 1431 RVA: 0x0002EB84 File Offset: 0x0002CD84
	public int[] #=ziOXVgvjvFhzEtBZSB7CJqUA=()
	{
		return this.#=zjP86VTnteCy7WcmjKfNocdQeQP_yIDLAwA==;
	}

	// Token: 0x06000598 RID: 1432 RVA: 0x0002EB8C File Offset: 0x0002CD8C
	public void #=zXtXK9QZXWJvZgpRrBWWEKh0=(int[] #=z$Ib9gYQ=)
	{
		this.#=zjP86VTnteCy7WcmjKfNocdQeQP_yIDLAwA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000599 RID: 1433 RVA: 0x0002EB98 File Offset: 0x0002CD98
	public static #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zi1hFJwI=(Dictionary<string, object> #=zZQYVp9q1prVF)
	{
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA== = new #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==();
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zbsxKkj4=(JSONManager.GetInt(#=zZQYVp9q1prVF, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943005), 0));
		Dictionary<string, object> dictionary = JSONManager.GetDictionary(#=zZQYVp9q1prVF, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zgEoShpNKDDTtZaEW1g==(JSONManager.GetString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750), null));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zIR9Xlcg=(#=zxR30SRmlUM9ZPqYYf7NF6U$3Ihg$.#=zICULcuHQnXe3(JSONManager.GetDateTime(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false)));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z3y$Jd2Y9Ey5E((#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zq3PpF70fIqbhwP$vag==(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=ztebJQq4nB16H22LArw==(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875), 0));
		#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=z_Nuury_Hqz6r(JSONManager.GetInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
		object[] array = JSONManager.GetArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909108004));
		if (array != null)
		{
			#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zXtXK9QZXWJvZgpRrBWWEKh0=(new int[array.Length]);
			for (int i = 0; i < array.Length; i++)
			{
				#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=ziOXVgvjvFhzEtBZSB7CJqUA=()[i] = Convert.ToInt32(array[i]);
			}
		}
		else
		{
			#=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==.#=zXtXK9QZXWJvZgpRrBWWEKh0=(new int[0]);
		}
		return #=zBuTwrXDhRu$44svBOySZG_EOlRUVk4STZA==;
	}

	// Token: 0x0400023A RID: 570
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400023B RID: 571
	private string #=zNT0hJfLlJeh_YXWrT9P973k=;

	// Token: 0x0400023C RID: 572
	private DateTime #=zJDEdzIaDvHbnYM06$w==;

	// Token: 0x0400023D RID: 573
	private #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l #=zkanVdU4qSKZQX0s_fw==;

	// Token: 0x0400023E RID: 574
	private int #=z2N2E$4lindOXXEmoUvS57x5m23Mf;

	// Token: 0x0400023F RID: 575
	private int #=zztzYpTdhqjMFb4a0kF2jwPuNLILD;

	// Token: 0x04000240 RID: 576
	private int #=zB4k1DdLAiZaGwezVVQ==;

	// Token: 0x04000241 RID: 577
	private int[] #=zjP86VTnteCy7WcmjKfNocdQeQP_yIDLAwA==;
}
