﻿using System;
using Skink.SnR.Common.GZip;

// Token: 0x02000030 RID: 48
internal sealed class #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=
{
	// Token: 0x060000BF RID: 191 RVA: 0x00006C44 File Offset: 0x00004E44
	public #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=()
	{
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x00006C54 File Offset: 0x00004E54
	public #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=(bool #=zNLuWmAmMKXjXV9BCQy5eiZE=)
	{
		this.#=zaWpHl92V8FbOfVIG0GAH3Ks= = #=zNLuWmAmMKXjXV9BCQy5eiZE=;
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00006C8C File Offset: 0x00004E8C
	internal bool #=zbEKzMsLPLifM9PELSGby6$4=()
	{
		return this.#=zaWpHl92V8FbOfVIG0GAH3Ks=;
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00006C94 File Offset: 0x00004E94
	internal void #=zabg7pQM7pOvSIs7GyTV_$P8=(bool #=z$Ib9gYQ=)
	{
		this.#=zaWpHl92V8FbOfVIG0GAH3Ks= = #=z$Ib9gYQ=;
	}

	// Token: 0x060000C4 RID: 196 RVA: 0x00006CA0 File Offset: 0x00004EA0
	internal int #=zW3vXs9Q=()
	{
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 = (this.#=zcXgLydccbe5C.#=z0KaacqESNJ$P = 0L);
		this.#=zcXgLydccbe5C.#=znwxGN8g= = null;
		this.#=zZ6hesjQ= = (this.#=zbEKzMsLPLifM9PELSGby6$4=() ? ((#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)0) : ((#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)7));
		this.#=zmI$ftM4=.#=zW3vXs9Q=();
		return 0;
	}

	// Token: 0x060000C5 RID: 197 RVA: 0x00006CF4 File Offset: 0x00004EF4
	internal int #=zhjKhhfc=()
	{
		if (this.#=zmI$ftM4= != null)
		{
			this.#=zmI$ftM4=.#=zuHP7ulY=();
		}
		this.#=zmI$ftM4= = null;
		return 0;
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00006D14 File Offset: 0x00004F14
	internal int #=z1jlGMrg=(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zuuFHPjILnjRT, int #=zgLaCy2g=)
	{
		this.#=zcXgLydccbe5C = #=zuuFHPjILnjRT;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = null;
		this.#=zmI$ftM4= = null;
		if (#=zgLaCy2g= < 8 || #=zgLaCy2g= > 15)
		{
			this.#=zhjKhhfc=();
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063757));
		}
		this.#=zjYXbC4LrxF$O = #=zgLaCy2g=;
		this.#=zmI$ftM4= = new #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI=(#=zuuFHPjILnjRT, this.#=zbEKzMsLPLifM9PELSGby6$4=() ? this : null, 1 << #=zgLaCy2g=);
		this.#=zW3vXs9Q=();
		return 0;
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x00006D88 File Offset: 0x00004F88
	internal int #=zlJv54NpQwKIa(FlushType #=zmhpr6mQ=)
	{
		if (this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0 == null)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063732));
		}
		int num = 0;
		int num2 = -5;
		int #=z_f$vhX8=;
		for (;;)
		{
			switch (this.#=zZ6hesjQ=)
			{
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)0:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				byte[] #=zJtQJROi1bLs = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				if (((this.#=zyhUp4Hk= = #=zJtQJROi1bLs[#=z_f$vhX8=]) & 15) != 8)
				{
					this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
					this.#=zcXgLydccbe5C.#=znwxGN8g= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063696), this.#=zyhUp4Hk=);
					this.#=zHoiztR8= = 5;
					continue;
				}
				if ((this.#=zyhUp4Hk= >> 4) + 8 > this.#=zjYXbC4LrxF$O)
				{
					this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
					this.#=zcXgLydccbe5C.#=znwxGN8g= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063916), (this.#=zyhUp4Hk= >> 4) + 8);
					this.#=zHoiztR8= = 5;
					continue;
				}
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)1;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)1:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				byte[] #=zJtQJROi1bLs2 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=2 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=2.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=2.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				int num3 = #=zJtQJROi1bLs2[#=z_f$vhX8=] & 255;
				if (((this.#=zyhUp4Hk= << 8) + num3) % 31 != 0)
				{
					this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
					this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063884);
					this.#=zHoiztR8= = 5;
					continue;
				}
				this.#=zZ6hesjQ= = (((num3 & 32) == 0) ? ((#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)7) : ((#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)2));
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)2:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				byte[] #=zJtQJROi1bLs3 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=3 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=3.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=3.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = (uint)(#=zJtQJROi1bLs3[#=z_f$vhX8=] << 24 & (long)((ulong)-16777216));
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)3;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)3:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				uint num4 = this.#=zC961r3hyU_$U;
				byte[] #=zJtQJROi1bLs4 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=4 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=4.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=4.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = num4 + (#=zJtQJROi1bLs4[#=z_f$vhX8=] << 16 & 16711680U);
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)4;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)4:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				uint num5 = this.#=zC961r3hyU_$U;
				byte[] #=zJtQJROi1bLs5 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=5 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=5.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=5.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = num5 + (#=zJtQJROi1bLs5[#=z_f$vhX8=] << 8 & 65280U);
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)5;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)5:
				goto IL_388;
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)6:
				goto IL_40F;
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)7:
				num2 = this.#=zmI$ftM4=.#=zvb5bnug=(num2);
				if (num2 == -3)
				{
					this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
					this.#=zHoiztR8= = 0;
					continue;
				}
				if (num2 == 0)
				{
					num2 = num;
				}
				if (num2 != 1)
				{
					return num2;
				}
				num2 = num;
				this.#=zflMCWEQ6MryP = this.#=zmI$ftM4=.#=zW3vXs9Q=();
				if (!this.#=zbEKzMsLPLifM9PELSGby6$4=())
				{
					goto Block_16;
				}
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)8;
				continue;
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)8:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				byte[] #=zJtQJROi1bLs6 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=6 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=6.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=6.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = (uint)(#=zJtQJROi1bLs6[#=z_f$vhX8=] << 24 & (long)((ulong)-16777216));
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)9;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)9:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				uint num6 = this.#=zC961r3hyU_$U;
				byte[] #=zJtQJROi1bLs7 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=7 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=7.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=7.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = num6 + (#=zJtQJROi1bLs7[#=z_f$vhX8=] << 16 & 16711680U);
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)10;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)10:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				uint num7 = this.#=zC961r3hyU_$U;
				byte[] #=zJtQJROi1bLs8 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=8 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=8.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=8.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = num7 + (#=zJtQJROi1bLs8[#=z_f$vhX8=] << 8 & 65280U);
				this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)11;
				continue;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)11:
			{
				if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
				{
					return num2;
				}
				num2 = num;
				this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
				this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
				uint num8 = this.#=zC961r3hyU_$U;
				byte[] #=zJtQJROi1bLs9 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=9 = this.#=zcXgLydccbe5C;
				#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=9.#=z_f$vhX8=;
				#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=9.#=z_f$vhX8= = #=z_f$vhX8= + 1;
				this.#=zC961r3hyU_$U = num8 + (#=zJtQJROi1bLs9[#=z_f$vhX8=] & 255U);
				if (this.#=zflMCWEQ6MryP != this.#=zC961r3hyU_$U)
				{
					this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
					this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063849);
					this.#=zHoiztR8= = 5;
					continue;
				}
				goto IL_6AE;
			}
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)12:
				return 1;
			case (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13:
				goto IL_6BA;
			}
			break;
		}
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062498));
		IL_388:
		if (this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 == 0)
		{
			return num2;
		}
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3--;
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += 1L;
		uint num9 = this.#=zC961r3hyU_$U;
		byte[] #=zJtQJROi1bLs10 = this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0;
		#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=10 = this.#=zcXgLydccbe5C;
		#=z_f$vhX8= = #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=10.#=z_f$vhX8=;
		#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=10.#=z_f$vhX8= = #=z_f$vhX8= + 1;
		this.#=zC961r3hyU_$U = num9 + (#=zJtQJROi1bLs10[#=z_f$vhX8=] & 255U);
		this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = this.#=zC961r3hyU_$U;
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)6;
		return 2;
		IL_40F:
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
		this.#=zcXgLydccbe5C.#=znwxGN8g= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062753);
		this.#=zHoiztR8= = 0;
		return -2;
		Block_16:
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)12;
		return 1;
		IL_6AE:
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)12;
		return 1;
		IL_6BA:
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063828), this.#=zcXgLydccbe5C.#=znwxGN8g=));
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00007480 File Offset: 0x00005680
	internal int #=zv4DxgDs=(byte[] #=zrnw7iZQ=)
	{
		int #=z1qaC5B0= = 0;
		int num = #=zrnw7iZQ=.Length;
		if (this.#=zZ6hesjQ= != (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)6)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062498));
		}
		if (Adler.Adler32(1U, #=zrnw7iZQ=, 0, #=zrnw7iZQ=.Length) != this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA==)
		{
			return -3;
		}
		this.#=zcXgLydccbe5C.#=z4A2fn4O2tDlTs77BiA== = Adler.Adler32(0U, null, 0, 0);
		if (num >= 1 << this.#=zjYXbC4LrxF$O)
		{
			num = (1 << this.#=zjYXbC4LrxF$O) - 1;
			#=z1qaC5B0= = #=zrnw7iZQ=.Length - num;
		}
		this.#=zmI$ftM4=.#=zv4DxgDs=(#=zrnw7iZQ=, #=z1qaC5B0=, num);
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)7;
		return 0;
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x00007514 File Offset: 0x00005714
	internal int #=zz2dSKkA=()
	{
		if (this.#=zZ6hesjQ= != (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13)
		{
			this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)13;
			this.#=zHoiztR8= = 0;
		}
		int num;
		if ((num = this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3) == 0)
		{
			return -5;
		}
		int num2 = this.#=zcXgLydccbe5C.#=z_f$vhX8=;
		int num3 = this.#=zHoiztR8=;
		while (num != 0 && num3 < 4)
		{
			if (this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num2] == #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=ziSMCAVE=[num3])
			{
				num3++;
			}
			else if (this.#=zcXgLydccbe5C.#=zJtQJROi1bLs0[num2] != 0)
			{
				num3 = 0;
			}
			else
			{
				num3 = 4 - num3;
			}
			num2++;
			num--;
		}
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 += (long)(num2 - this.#=zcXgLydccbe5C.#=z_f$vhX8=);
		this.#=zcXgLydccbe5C.#=z_f$vhX8= = num2;
		this.#=zcXgLydccbe5C.#=zEVNP$$evg7c3 = num;
		this.#=zHoiztR8= = num3;
		if (num3 != 4)
		{
			return -3;
		}
		long #=zX85$ivfbdo = this.#=zcXgLydccbe5C.#=zX85$ivfbdo86;
		long #=z0KaacqESNJ$P = this.#=zcXgLydccbe5C.#=z0KaacqESNJ$P;
		this.#=zW3vXs9Q=();
		this.#=zcXgLydccbe5C.#=zX85$ivfbdo86 = #=zX85$ivfbdo;
		this.#=zcXgLydccbe5C.#=z0KaacqESNJ$P = #=z0KaacqESNJ$P;
		this.#=zZ6hesjQ= = (#=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A==)7;
		return 0;
	}

	// Token: 0x060000CA RID: 202 RVA: 0x0000762C File Offset: 0x0000582C
	internal int #=zutJ2D_gir2nk(#=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zDNCCbqs=)
	{
		return this.#=zmI$ftM4=.#=zutJ2D_gir2nk();
	}

	// Token: 0x0400004E RID: 78
	private #=z0boV3vY3VdKRvsuAbuzdgMTQ90rvcqumJj2HGUQ=.#=zZRgPYuV$K8AEwTno$A== #=zZ6hesjQ=;

	// Token: 0x0400004F RID: 79
	internal #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zcXgLydccbe5C;

	// Token: 0x04000050 RID: 80
	internal int #=zyhUp4Hk=;

	// Token: 0x04000051 RID: 81
	internal uint #=zflMCWEQ6MryP;

	// Token: 0x04000052 RID: 82
	internal uint #=zC961r3hyU_$U;

	// Token: 0x04000053 RID: 83
	internal int #=zHoiztR8=;

	// Token: 0x04000054 RID: 84
	private bool #=zaWpHl92V8FbOfVIG0GAH3Ks= = true;

	// Token: 0x04000055 RID: 85
	internal int #=zjYXbC4LrxF$O;

	// Token: 0x04000056 RID: 86
	internal #=zf1NIvtuPM7uGNJRBhjgZ4CZZBhT_rgqLRzm1nwI= #=zmI$ftM4=;

	// Token: 0x04000057 RID: 87
	private static readonly byte[] #=ziSMCAVE= = new byte[]
	{
		0,
		0,
		byte.MaxValue,
		byte.MaxValue
	};

	// Token: 0x02000031 RID: 49
	private enum #=zZRgPYuV$K8AEwTno$A==
	{

	}
}
