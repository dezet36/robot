﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x020000B5 RID: 181
internal sealed class #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=> where #=zQSoxQMk= : IIntID
{
	// Token: 0x060004C3 RID: 1219 RVA: 0x000277E0 File Offset: 0x000259E0
	public #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zQSoxQMk=> #=z$0B8gas=)
	{
		this.#=zYCjxVKs= = #=z$0B8gas=;
		this.#=zkKJigFQ= = 0;
		this.#=ztr7CRtiGCrH8 = new List<int>();
		this.#=zRmD_mM6u4pbd = null;
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x00027808 File Offset: 0x00025A08
	private List<#=zQSoxQMk=> #=zS1IRgv8=()
	{
		while (this.#=zkKJigFQ= < this.#=zYCjxVKs=.Count)
		{
			List<#=zQSoxQMk=> list = this.#=zYCjxVKs=[this.#=zkKJigFQ=];
			List<#=zQSoxQMk=> list2 = new List<#=zQSoxQMk=>();
			for (int i = 0; i < list.Count; i++)
			{
				#=zQSoxQMk= item = list[i];
				if (!this.#=ztr7CRtiGCrH8.Contains(item.Id))
				{
					list2.Add(item);
				}
			}
			if (list2.Count > 0)
			{
				this.#=zRmD_mM6u4pbd = list2;
				return this.#=zRmD_mM6u4pbd;
			}
			this.#=zkKJigFQ=++;
		}
		this.#=zRmD_mM6u4pbd = new List<#=zQSoxQMk=>();
		return this.#=zRmD_mM6u4pbd;
	}

	// Token: 0x060004C5 RID: 1221 RVA: 0x000278B8 File Offset: 0x00025AB8
	private void #=zdGAgyXmd99i8(List<#=zQSoxQMk=> #=zSAsdTcYS_TY3)
	{
		for (int i = 0; i < #=zSAsdTcYS_TY3.Count; i++)
		{
			#=zQSoxQMk= item = #=zSAsdTcYS_TY3[i];
			if (this.#=zRmD_mM6u4pbd.Contains(item))
			{
				this.#=ztr7CRtiGCrH8.Add(item.Id);
			}
		}
	}

	// Token: 0x060004C6 RID: 1222 RVA: 0x00027904 File Offset: 0x00025B04
	public static List<#=zQSoxQMk=> #=z65EelYE=(List<#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zQSoxQMk=>> #=zg4rCXAtzhh0k, int #=zXHTER4Q=)
	{
		List<#=zQSoxQMk=> list = new List<#=zQSoxQMk=>();
		List<#=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=>> list2 = new List<#=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=>>();
		for (int i = 0; i < #=zg4rCXAtzhh0k.Count; i++)
		{
			#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zQSoxQMk=> #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM = #=zg4rCXAtzhh0k[i];
			if (#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM.Count > 0)
			{
				list2.Add(new #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=>(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM));
			}
		}
		for (int j = 0; j < #=zXHTER4Q=; j++)
		{
			#=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=>.#=zQ8GnZQyT9uFE1MX7Uw== #=zQ8GnZQyT9uFE1MX7Uw== = new #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=>.#=zQ8GnZQyT9uFE1MX7Uw==();
			List<List<#=zQSoxQMk=>> list3 = new List<List<#=zQSoxQMk=>>();
			for (int k = 0; k < list2.Count; k++)
			{
				#=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zQSoxQMk=> #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA== = list2[k];
				if (#=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==.#=zkKJigFQ= <= #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==.#=zYCjxVKs=.Count)
				{
					List<#=zQSoxQMk=> list4 = #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==.#=zS1IRgv8=();
					if (list4.Count > 0)
					{
						list3.Add(list4);
					}
				}
			}
			#=zQ8GnZQyT9uFE1MX7Uw==.#=zXYKPv45gLX6M = new Dictionary<int, int>();
			for (int l = 0; l < list3.Count; l++)
			{
				List<#=zQSoxQMk=> list5 = list3[l];
				for (int m = 0; m < list5.Count; m++)
				{
					#=zQSoxQMk= #=zQSoxQMk= = list5[m];
					if (#=zQ8GnZQyT9uFE1MX7Uw==.#=zXYKPv45gLX6M.ContainsKey(#=zQSoxQMk=.Id))
					{
						#=zQ8GnZQyT9uFE1MX7Uw==.#=zXYKPv45gLX6M[#=zQSoxQMk=.Id] = #=zQ8GnZQyT9uFE1MX7Uw==.#=zXYKPv45gLX6M[#=zQSoxQMk=.Id] + 1;
					}
					else
					{
						#=zQ8GnZQyT9uFE1MX7Uw==.#=zXYKPv45gLX6M[#=zQSoxQMk=.Id] = 1;
					}
				}
			}
			List<#=zQSoxQMk=> list6 = new List<#=zQSoxQMk=>();
			for (int n = 0; n < list3.Count; n++)
			{
				List<#=zQSoxQMk=> list7 = list3[n];
				if (list7.Count > 0)
				{
					List<#=zQSoxQMk=> list8 = list7;
					Comparison<#=zQSoxQMk=> comparison;
					if ((comparison = #=zQ8GnZQyT9uFE1MX7Uw==.#=zxwmV42lQK4CR) == null)
					{
						comparison = (#=zQ8GnZQyT9uFE1MX7Uw==.#=zxwmV42lQK4CR = new Comparison<#=zQSoxQMk=>(#=zQ8GnZQyT9uFE1MX7Uw==.#=z6fV$fqSKCRZSO6Onew==));
					}
					list8.Sort(comparison);
					#=zQSoxQMk= item = list7[0];
					if (!list6.Contains(item))
					{
						list6.Add(item);
					}
				}
			}
			for (int num = 0; num < list2.Count; num++)
			{
				list2[num].#=zdGAgyXmd99i8(list6);
			}
			list.AddRange(list6);
		}
		return list;
	}

	// Token: 0x040001D0 RID: 464
	private #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zQSoxQMk=> #=zYCjxVKs=;

	// Token: 0x040001D1 RID: 465
	private int #=zkKJigFQ=;

	// Token: 0x040001D2 RID: 466
	private List<int> #=ztr7CRtiGCrH8;

	// Token: 0x040001D3 RID: 467
	private List<#=zQSoxQMk=> #=zRmD_mM6u4pbd;

	// Token: 0x020000B6 RID: 182
	private sealed class #=zQ8GnZQyT9uFE1MX7Uw==
	{
		// Token: 0x060004C8 RID: 1224 RVA: 0x00027B28 File Offset: 0x00025D28
		internal int #=z6fV$fqSKCRZSO6Onew==(#=zQSoxQMk= #=zm8PpuDU=, #=zQSoxQMk= #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
			{
				this.#=zXYKPv45gLX6M[#=zcltuPyw=.Id].CompareTo(this.#=zXYKPv45gLX6M[#=zm8PpuDU=.Id]),
				#=zm8PpuDU=.Id.CompareTo(#=zcltuPyw=.Id)
			});
		}

		// Token: 0x040001D4 RID: 468
		public Dictionary<int, int> #=zXYKPv45gLX6M;

		// Token: 0x040001D5 RID: 469
		public Comparison<#=zQSoxQMk=> #=zxwmV42lQK4CR;
	}
}
