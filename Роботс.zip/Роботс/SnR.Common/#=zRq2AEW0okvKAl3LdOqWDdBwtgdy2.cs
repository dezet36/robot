﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using Skink.SnR.Common.City;

// Token: 0x02000195 RID: 405
internal sealed class #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 : List<#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio>
{
	// Token: 0x06000BA1 RID: 2977 RVA: 0x00058294 File Offset: 0x00056494
	public #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zk$6QZNA=(ResourceTypes #=zvRLj9WQ=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=zq2bPTdY=() == #=zvRLj9WQ=)
			{
				return base[i];
			}
		}
		return null;
	}

	// Token: 0x17000037 RID: 55
	[IndexerName("#=zx6APBRk=")]
	public int this[ResourceTypes #=zvRLj9WQ=]
	{
		get
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = this.#=zk$6QZNA=(#=zvRLj9WQ=);
			if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio != null)
			{
				return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_();
			}
			return 0;
		}
		set
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = this.#=zk$6QZNA=(#=zvRLj9WQ=);
			if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio != null)
			{
				#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(value);
				return;
			}
			if (value > 0)
			{
				#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(#=zvRLj9WQ=, value);
				base.Add(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio);
			}
		}
	}

	// Token: 0x06000BA4 RID: 2980 RVA: 0x00058320 File Offset: 0x00056520
	public bool #=zBxPnwYw=(ResourceTypes #=zvRLj9WQ=)
	{
		return this[#=zvRLj9WQ=] > 0;
	}

	// Token: 0x06000BA5 RID: 2981 RVA: 0x0005832C File Offset: 0x0005652C
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_() > 0)
			{
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_());
				stringBuilder.Append(' ');
				stringBuilder.Append(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zyhMluFK2CBji());
			}
		}
		if (stringBuilder.Length == 0)
		{
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061842));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000BA6 RID: 2982 RVA: 0x000583BC File Offset: 0x000565BC
	public #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zTnMGkyA=()
	{
		#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zRq2AEW0okvKAl3LdOqWDdBwtgdy = new #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2();
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			#=zRq2AEW0okvKAl3LdOqWDdBwtgdy.Add(new #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=(), #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_()));
		}
		return #=zRq2AEW0okvKAl3LdOqWDdBwtgdy;
	}

	// Token: 0x06000BA7 RID: 2983 RVA: 0x00058400 File Offset: 0x00056600
	public void #=zcEn_SGQ=(#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z9VFkiusCry4u)
	{
		for (int i = base.Count - 1; i >= 0; i--)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			int num = #=z9VFkiusCry4u[#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=()];
			if (num <= 0)
			{
				base.RemoveAt(i);
			}
			else if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_() > num)
			{
				#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(num);
			}
		}
	}

	// Token: 0x06000BA8 RID: 2984 RVA: 0x00058454 File Offset: 0x00056654
	public int #=z0zVhHqs=()
	{
		int num = 0;
		for (int i = 0; i < base.Count; i++)
		{
			num += base[i].#=zlIXJ9$NfUZc_();
		}
		return num;
	}

	// Token: 0x06000BA9 RID: 2985 RVA: 0x00058484 File Offset: 0x00056684
	public #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=zow6y$qY=(ResourceTypes[] #=zC7NDbDM=)
	{
		#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = null;
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2 = base[i];
			bool flag = false;
			for (int j = 0; j < #=zC7NDbDM=.Length; j++)
			{
				if (#=zC7NDbDM=[j] == #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zq2bPTdY=())
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio == null)
				{
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2;
				}
				else if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_() > #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2.#=zlIXJ9$NfUZc_())
				{
					#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio2;
				}
			}
		}
		return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio;
	}

	// Token: 0x06000BAA RID: 2986 RVA: 0x000584EC File Offset: 0x000566EC
	public int #=z$QpPChdewFHO(ResourceTypes[] #=zC7NDbDM=)
	{
		#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = this.#=zow6y$qY=(#=zC7NDbDM=);
		if (#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio != null)
		{
			return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_();
		}
		return 0;
	}

	// Token: 0x06000BAB RID: 2987 RVA: 0x0005850C File Offset: 0x0005670C
	public int #=zQF25K1c=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zF7ogm1Q=)
	{
		int num = int.MaxValue;
		List<ResourceTypes> list = new List<ResourceTypes>();
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			int num2 = #=zF7ogm1Q=[#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=()];
			if (num2 > 0)
			{
				int num3 = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_() / num2;
				if (num3 < num)
				{
					num = num3;
				}
				if (num3 < 1)
				{
					return 0;
				}
				list.Add(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=());
			}
		}
		foreach (ResourceTypes item in #=zF7ogm1Q=.Keys)
		{
			if (!list.Contains(item))
			{
				return 0;
			}
		}
		return num;
	}

	// Token: 0x06000BAC RID: 2988 RVA: 0x000585CC File Offset: 0x000567CC
	public void #=zWyy2M2Q=(#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zvNHnMrA54d7pHFYjXQ==, int #=zZUh0rLnQByG$)
	{
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			if (#=zvNHnMrA54d7pHFYjXQ==.ContainsKey(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=()))
			{
				#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zqoCq5j01dD5w(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_() - #=zvNHnMrA54d7pHFYjXQ==[#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=()] * #=zZUh0rLnQByG$);
			}
		}
	}

	// Token: 0x06000BAD RID: 2989 RVA: 0x0005861C File Offset: 0x0005681C
	public #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zmTCxtJo=()
	{
		#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ== = new #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==();
		for (int i = 0; i < base.Count; i++)
		{
			#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio = base[i];
			#=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==[#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zq2bPTdY=()] = #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zlIXJ9$NfUZc_();
		}
		return #=zJScngy0qjFVvjztnuhgvGT0X6N6$eHedMQ==;
	}
}
