﻿using System;
using System.Collections;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Drawing;
using NExcel.Format;
using NExcel.Read.Biff;

// Token: 0x020001DC RID: 476
internal sealed class #=zYIxo3mZj9AHsqpBLaTYcwZo=
{
	// Token: 0x06000E62 RID: 3682 RVA: 0x000723C8 File Offset: 0x000705C8
	internal #=zYIxo3mZj9AHsqpBLaTYcwZo=(File #=zTRA8u0c=, SSTRecord #=zsKIJBH4=, FormattingRecords #=zrRXQAB8=, BOFRecord #=zgj6Ipfc=, BOFRecord #=zAoi5o5M=, bool #=z1xdZb6s=, WorkbookParser #=zRudY0qs=, int #=zC6LEY64=, SheetImpl #=zf2IIpKw=)
	{
		this.#=zDI_c6jkXGlFD = #=zTRA8u0c=;
		this.#=zZjXcmtS49F0G = #=zsKIJBH4=;
		this.#=zwKQa9tCrbbw$ = #=zrRXQAB8=;
		this.#=zViVQP81p4BwqFpjFgQ== = #=zgj6Ipfc=;
		this.#=zRzM9L4lv39OwOrRPiw== = #=zAoi5o5M=;
		this.#=zmshE82IEtIBL = new ArrayList();
		this.#=zxBcpeO43ZpTTP1SMjA== = new ArrayList();
		this.#=z9MDU2K_833d9kAfSuA== = new ArrayList();
		this.#=zF2WRaDs= = new ArrayList(10);
		this.#=zygzOU7ZWzJ3P = new ArrayList();
		this.#=zq6L3hNAMw96suiNzaw== = new ArrayList();
		this.#=z8snpwsaw$imRxg6cFA== = #=z1xdZb6s=;
		this.#=zJY$tXiAJ_$AzbtOFtg== = #=zRudY0qs=;
		this.#=zBPg5R5JI4JfJ = #=zC6LEY64=;
		this.#=zNEZ0SGey$A9J = #=zf2IIpKw=;
		this.#=z6bRJXNQ= = new SheetSettings();
		this.#=zGgQ88FCSf3u6XZljng== = this.#=zJY$tXiAJ_$AzbtOFtg==.Settings;
	}

	// Token: 0x06000E64 RID: 3684 RVA: 0x00072498 File Offset: 0x00070698
	internal int #=zBTjsyhyK9LV2()
	{
		return this.#=zgTmLAohDTfaZ;
	}

	// Token: 0x06000E65 RID: 3685 RVA: 0x000724A0 File Offset: 0x000706A0
	internal int #=zWb7hAuv6cPuvosnFRw==()
	{
		return this.#=zuyRGtIBGTWoN;
	}

	// Token: 0x06000E66 RID: 3686 RVA: 0x000724A8 File Offset: 0x000706A8
	internal Cell[][] #=zDOPqxuu7x5b1()
	{
		return this.#=zRV_$73M=;
	}

	// Token: 0x06000E67 RID: 3687 RVA: 0x000724B0 File Offset: 0x000706B0
	internal ArrayList #=zhFRFwNd7CNFG()
	{
		return this.#=zF2WRaDs=;
	}

	// Token: 0x06000E68 RID: 3688 RVA: 0x000724B8 File Offset: 0x000706B8
	internal ArrayList #=zSckctwEGw9JV()
	{
		return this.#=zmshE82IEtIBL;
	}

	// Token: 0x06000E69 RID: 3689 RVA: 0x000724C0 File Offset: 0x000706C0
	internal ArrayList #=z3JzGodPEd03efAeP0InGr7g=()
	{
		return this.#=z9MDU2K_833d9kAfSuA==;
	}

	// Token: 0x06000E6A RID: 3690 RVA: 0x000724C8 File Offset: 0x000706C8
	internal ArrayList #=zbFQD5W5BcqrfHWxVeg==()
	{
		return this.#=zygzOU7ZWzJ3P;
	}

	// Token: 0x06000E6B RID: 3691 RVA: 0x000724D0 File Offset: 0x000706D0
	internal ArrayList #=zZoO_nv9mGlkBr0iRSw==()
	{
		return this.#=zq6L3hNAMw96suiNzaw==;
	}

	// Token: 0x06000E6C RID: 3692 RVA: 0x000724D8 File Offset: 0x000706D8
	internal Range[] #=zh0lOYuw3OKp4()
	{
		return this.#=zpBbFDjVAL0MB;
	}

	// Token: 0x06000E6D RID: 3693 RVA: 0x000724E0 File Offset: 0x000706E0
	internal SheetSettings #=zv2Kyu17YrGOC()
	{
		return this.#=z6bRJXNQ=;
	}

	// Token: 0x06000E6E RID: 3694 RVA: 0x000724E8 File Offset: 0x000706E8
	internal int[] #=zOmAd$eG7cqZo()
	{
		return this.#=zF5g$dZZQGSkT;
	}

	// Token: 0x06000E6F RID: 3695 RVA: 0x000724F0 File Offset: 0x000706F0
	internal WorkspaceInformationRecord #=zcoqs_Rb_BXeY()
	{
		return this.#=zcXkV2Pi1c$mP;
	}

	// Token: 0x06000E70 RID: 3696 RVA: 0x000724F8 File Offset: 0x000706F8
	internal PLSRecord #=z2zt0YEZhi7NR()
	{
		return this.#=zIWg$TzZj_0Ir;
	}

	// Token: 0x06000E71 RID: 3697 RVA: 0x00072500 File Offset: 0x00070700
	private void #=zn1vWly4=(Cell #=zcJSpiFI=)
	{
		if (#=zcJSpiFI=.Row < this.#=zgTmLAohDTfaZ && #=zcJSpiFI=.Column < this.#=zuyRGtIBGTWoN)
		{
			if (this.#=zRV_$73M=[#=zcJSpiFI=.Row][#=zcJSpiFI=.Column] != null)
			{
				StringBuilder stringBuilder = new StringBuilder();
				NExcel.CellReferenceHelper.getCellReference(#=zcJSpiFI=.Column, #=zcJSpiFI=.Row, stringBuilder);
				#=zYIxo3mZj9AHsqpBLaTYcwZo=.#=zJLdzGuI=.warn(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067525) + stringBuilder.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067761));
			}
			this.#=zRV_$73M=[#=zcJSpiFI=.Row][#=zcJSpiFI=.Column] = #=zcJSpiFI=;
		}
	}

	// Token: 0x06000E72 RID: 3698 RVA: 0x00072598 File Offset: 0x00070798
	internal void #=zJjGe$TU=()
	{
		BaseSharedFormulaRecord baseSharedFormulaRecord = null;
		bool flag = false;
		bool flag2 = true;
		this.#=zDI_c6jkXGlFD.Pos = this.#=zBPg5R5JI4JfJ;
		MsoDrawingRecord mso = null;
		ObjRecord obj = null;
		#=zS$ZFdBlV0aTFcFGb0SEhHNA= #=zS$ZFdBlV0aTFcFGb0SEhHNA= = null;
		while (flag2)
		{
			Record record = this.#=zDI_c6jkXGlFD.#=zVYqdNhU=();
			if (record.Type == Type.UNKNOWN && record.Code == 0)
			{
				if (record.Length == 10)
				{
					#=zYIxo3mZj9AHsqpBLaTYcwZo=.#=zJLdzGuI=.warn(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067730));
					record.Type = Type.DIMENSION;
				}
				else
				{
					#=zYIxo3mZj9AHsqpBLaTYcwZo=.#=zJLdzGuI=.warn(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067674));
				}
			}
			if (record.Type == Type.DIMENSION)
			{
				#=zbnUmxJezoVGfpl_vxHCBfj8= #=zbnUmxJezoVGfpl_vxHCBfj8=;
				if (this.#=zRzM9L4lv39OwOrRPiw==.isBiff8())
				{
					#=zbnUmxJezoVGfpl_vxHCBfj8= = new #=zbnUmxJezoVGfpl_vxHCBfj8=(record);
				}
				else
				{
					#=zbnUmxJezoVGfpl_vxHCBfj8= = new #=zbnUmxJezoVGfpl_vxHCBfj8=(record, #=zbnUmxJezoVGfpl_vxHCBfj8=.#=zJxoWYNQIfgMz);
				}
				this.#=zgTmLAohDTfaZ = #=zbnUmxJezoVGfpl_vxHCBfj8=.#=z$2ogfb5H9R6f();
				this.#=zuyRGtIBGTWoN = #=zbnUmxJezoVGfpl_vxHCBfj8=.#=zhUfM2IzcS5zU();
				this.#=zRV_$73M= = new Cell[this.#=zgTmLAohDTfaZ][];
				for (int i = 0; i < this.#=zgTmLAohDTfaZ; i++)
				{
					this.#=zRV_$73M=[i] = new Cell[this.#=zuyRGtIBGTWoN];
				}
			}
			else if (record.Type == Type.LABELSST)
			{
				#=zM6WLjlWzdT_uUu6fjdjjyIl14zQg #=zcJSpiFI= = new #=zM6WLjlWzdT_uUu6fjdjjyIl14zQg(record, this.#=zZjXcmtS49F0G, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
				this.#=zn1vWly4=(#=zcJSpiFI=);
			}
			else if (record.Type == Type.RK || record.Type == Type.RK2)
			{
				#=ze_OEBfpX9a85CAhsSkIMRcc= #=ze_OEBfpX9a85CAhsSkIMRcc= = new #=ze_OEBfpX9a85CAhsSkIMRcc=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
				if (this.#=zwKQa9tCrbbw$.isDate(#=ze_OEBfpX9a85CAhsSkIMRcc=.XFIndex))
				{
					DateCell #=zcJSpiFI=2 = new #=zk0bxu_9ri56pLWrVZ_xFGIw=(#=ze_OEBfpX9a85CAhsSkIMRcc=, #=ze_OEBfpX9a85CAhsSkIMRcc=.XFIndex, this.#=zwKQa9tCrbbw$, this.#=z8snpwsaw$imRxg6cFA==, this.#=zNEZ0SGey$A9J);
					this.#=zn1vWly4=(#=zcJSpiFI=2);
				}
				else
				{
					this.#=zn1vWly4=(#=ze_OEBfpX9a85CAhsSkIMRcc=);
				}
			}
			else if (record.Type == Type.HLINK)
			{
				HyperlinkRecord value = new HyperlinkRecord(record, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==);
				this.#=z9MDU2K_833d9kAfSuA==.Add(value);
			}
			else if (record.Type == Type.MERGEDCELLS)
			{
				MergedCellsRecord mergedCellsRecord = new MergedCellsRecord(record, this.#=zNEZ0SGey$A9J);
				if (this.#=zpBbFDjVAL0MB == null)
				{
					this.#=zpBbFDjVAL0MB = mergedCellsRecord.Ranges;
				}
				else
				{
					Range[] destinationArray = new Range[this.#=zpBbFDjVAL0MB.Length + mergedCellsRecord.Ranges.Length];
					Array.Copy(this.#=zpBbFDjVAL0MB, 0, destinationArray, 0, this.#=zpBbFDjVAL0MB.Length);
					Array.Copy(mergedCellsRecord.Ranges, 0, destinationArray, this.#=zpBbFDjVAL0MB.Length, mergedCellsRecord.Ranges.Length);
					this.#=zpBbFDjVAL0MB = destinationArray;
				}
			}
			else if (record.Type == Type.MULRK)
			{
				#=ziAZwWfsjJUHjtK6k0ndv5xwbl2io #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io = new #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io(record);
				int num = #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io.#=zhUfM2IzcS5zU();
				for (int j = 0; j < num; j++)
				{
					int num2 = #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io.#=zJVc2l$oPfOau(j);
					#=zRFFrkyRIJ42kEUG5F9aRdo8= #=zRFFrkyRIJ42kEUG5F9aRdo8= = new #=zRFFrkyRIJ42kEUG5F9aRdo8=(#=ziAZwWfsjJUHjtK6k0ndv5xwbl2io.#=zNMAKc1U=(), #=ziAZwWfsjJUHjtK6k0ndv5xwbl2io.#=zas6WF9Y7vCuz() + j, #=z64XUyGjGhI3yrQ01k8oOgQI=.#=zeTioEPI=(#=ziAZwWfsjJUHjtK6k0ndv5xwbl2io.#=zzAx9picknfF$(j)), num2, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
					if (this.#=zwKQa9tCrbbw$.isDate(num2))
					{
						DateCell #=zcJSpiFI=3 = new #=zk0bxu_9ri56pLWrVZ_xFGIw=(#=zRFFrkyRIJ42kEUG5F9aRdo8=, num2, this.#=zwKQa9tCrbbw$, this.#=z8snpwsaw$imRxg6cFA==, this.#=zNEZ0SGey$A9J);
						this.#=zn1vWly4=(#=zcJSpiFI=3);
					}
					else
					{
						#=zRFFrkyRIJ42kEUG5F9aRdo8=.#=z_6Yn4EGfIqYe(this.#=zwKQa9tCrbbw$.getNumberFormat(num2));
						this.#=zn1vWly4=(#=zRFFrkyRIJ42kEUG5F9aRdo8=);
					}
				}
			}
			else if (record.Type == Type.NUMBER)
			{
				#=zVuQRGxc1NEa1XCn8rHXZRUM= #=zVuQRGxc1NEa1XCn8rHXZRUM= = new #=zVuQRGxc1NEa1XCn8rHXZRUM=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
				if (this.#=zwKQa9tCrbbw$.isDate(#=zVuQRGxc1NEa1XCn8rHXZRUM=.XFIndex))
				{
					DateCell #=zcJSpiFI=4 = new #=zk0bxu_9ri56pLWrVZ_xFGIw=(#=zVuQRGxc1NEa1XCn8rHXZRUM=, #=zVuQRGxc1NEa1XCn8rHXZRUM=.XFIndex, this.#=zwKQa9tCrbbw$, this.#=z8snpwsaw$imRxg6cFA==, this.#=zNEZ0SGey$A9J);
					this.#=zn1vWly4=(#=zcJSpiFI=4);
				}
				else
				{
					this.#=zn1vWly4=(#=zVuQRGxc1NEa1XCn8rHXZRUM=);
				}
			}
			else if (record.Type == Type.BOOLERR)
			{
				#=zDAxGhtLn4yRqe$aqtbLJKf8= #=zDAxGhtLn4yRqe$aqtbLJKf8= = new #=zDAxGhtLn4yRqe$aqtbLJKf8=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
				if (#=zDAxGhtLn4yRqe$aqtbLJKf8=.#=zZEc75Ho=())
				{
					#=zrNNjZzpBGduICIktW7kp4dQ= #=zcJSpiFI=5 = new #=zrNNjZzpBGduICIktW7kp4dQ=(#=zDAxGhtLn4yRqe$aqtbLJKf8=.getRecord(), this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
					this.#=zn1vWly4=(#=zcJSpiFI=5);
				}
				else
				{
					this.#=zn1vWly4=(#=zDAxGhtLn4yRqe$aqtbLJKf8=);
				}
			}
			else if (record.Type == Type.PRINTGRIDLINES)
			{
				#=zlsoMZFdAX0vDkkzGOA_uys_lXE7s #=zlsoMZFdAX0vDkkzGOA_uys_lXE7s = new #=zlsoMZFdAX0vDkkzGOA_uys_lXE7s(record);
				this.#=z6bRJXNQ=.PrintGridLines = #=zlsoMZFdAX0vDkkzGOA_uys_lXE7s.#=zdtRq1EhsFB049kj0cA==();
			}
			else if (record.Type == Type.PRINTHEADERS)
			{
				#=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO #=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO = new #=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO(record);
				this.#=z6bRJXNQ=.PrintHeaders = #=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO.#=z35rwe4u2YH1T();
			}
			else if (record.Type == Type.WINDOW2)
			{
				#=zS$ZFdBlV0aTFcFGb0SEhHNA= = new #=zS$ZFdBlV0aTFcFGb0SEhHNA=(record);
				this.#=z6bRJXNQ=.ShowGridLines = #=zS$ZFdBlV0aTFcFGb0SEhHNA=.#=z6Okbw7uRmNbHB_lzMg==();
				this.#=z6bRJXNQ=.DisplayZeroValues = #=zS$ZFdBlV0aTFcFGb0SEhHNA=.#=ztmCn$_skNFjwu5baZw==();
				this.#=z6bRJXNQ=.setSelected();
			}
			else if (record.Type == Type.PANE)
			{
				#=zNHVdUzwLVHRXW7qqwg5NdnA= #=zNHVdUzwLVHRXW7qqwg5NdnA= = new #=zNHVdUzwLVHRXW7qqwg5NdnA=(record);
				if (#=zS$ZFdBlV0aTFcFGb0SEhHNA= != null && #=zS$ZFdBlV0aTFcFGb0SEhHNA=.#=zMJid0aWBDl5P() && #=zS$ZFdBlV0aTFcFGb0SEhHNA=.#=zbd8XKGnwOE3o())
				{
					this.#=z6bRJXNQ=.VerticalFreeze = #=zNHVdUzwLVHRXW7qqwg5NdnA=.#=zASqj2TProeAC();
					this.#=z6bRJXNQ=.HorizontalFreeze = #=zNHVdUzwLVHRXW7qqwg5NdnA=.#=zxgGTN5gtGbv1();
				}
			}
			else if (record.Type != Type.CONTINUE && record.Type != Type.NOTE && record.Type != Type.ARRAY)
			{
				if (record.Type == Type.PROTECT)
				{
					#=zJCqcRccbIsetIoA5cBhjLtg= #=zJCqcRccbIsetIoA5cBhjLtg= = new #=zJCqcRccbIsetIoA5cBhjLtg=(record);
					this.#=z6bRJXNQ=.Protected = #=zJCqcRccbIsetIoA5cBhjLtg=.#=zpwQuD$4=();
				}
				else if (record.Type == Type.SHAREDFORMULA)
				{
					if (baseSharedFormulaRecord == null)
					{
						#=zYIxo3mZj9AHsqpBLaTYcwZo=.#=zJLdzGuI=.warn(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067389));
						#=ztl7zQY5jOB52OgJX_3oVMtczpItq #=ztl7zQY5jOB52OgJX_3oVMtczpItq = (#=ztl7zQY5jOB52OgJX_3oVMtczpItq)this.#=zxBcpeO43ZpTTP1SMjA==[this.#=zxBcpeO43ZpTTP1SMjA==.Count - 1];
						if (#=ztl7zQY5jOB52OgJX_3oVMtczpItq != null)
						{
							baseSharedFormulaRecord = #=ztl7zQY5jOB52OgJX_3oVMtczpItq.#=z6TVdgFogpHsZ();
						}
					}
					#=ztl7zQY5jOB52OgJX_3oVMtczpItq value2 = new #=ztl7zQY5jOB52OgJX_3oVMtczpItq(record, baseSharedFormulaRecord, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zNEZ0SGey$A9J);
					this.#=zxBcpeO43ZpTTP1SMjA==.Add(value2);
					baseSharedFormulaRecord = null;
				}
				else if (record.Type == Type.FORMULA || record.Type == Type.FORMULA2)
				{
					#=z5jeE6bKUUm6$P8GX1rIIQpA= #=z5jeE6bKUUm6$P8GX1rIIQpA= = new #=z5jeE6bKUUm6$P8GX1rIIQpA=(record, this.#=zDI_c6jkXGlFD, this.#=zwKQa9tCrbbw$, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==);
					if (#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zXuAoZ_2JHdw6())
					{
						BaseSharedFormulaRecord baseSharedFormulaRecord2 = baseSharedFormulaRecord;
						baseSharedFormulaRecord = (BaseSharedFormulaRecord)#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$();
						flag = this.#=zokgSLZdfRmLR_CFfkr1maT8=(baseSharedFormulaRecord);
						if (flag)
						{
							baseSharedFormulaRecord = baseSharedFormulaRecord2;
						}
						if (!flag && baseSharedFormulaRecord2 != null)
						{
							this.#=zn1vWly4=(this.#=zHErV_HiPU$XO(baseSharedFormulaRecord2));
						}
					}
					else
					{
						Cell #=zcJSpiFI=6 = #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$();
						if (#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$().Type == CellType.NUMBER_FORMULA)
						{
							#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z = (#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z)#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$();
							if (this.#=zwKQa9tCrbbw$.isDate(#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z.XFIndex))
							{
								#=zcJSpiFI=6 = new #=zAN6nfDbGVeM6PRGodOTnP2$G4k_M(#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z, this.#=zwKQa9tCrbbw$, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=z8snpwsaw$imRxg6cFA==, this.#=zNEZ0SGey$A9J);
							}
						}
						this.#=zn1vWly4=(#=zcJSpiFI=6);
					}
				}
				else if (record.Type == Type.LABEL)
				{
					#=z7jy7QwkVtkyomnRikJhu3R8= #=zcJSpiFI=7;
					if (this.#=zRzM9L4lv39OwOrRPiw==.isBiff8())
					{
						#=zcJSpiFI=7 = new #=z7jy7QwkVtkyomnRikJhu3R8=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==);
					}
					else
					{
						#=zcJSpiFI=7 = new #=z7jy7QwkVtkyomnRikJhu3R8=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==, #=z7jy7QwkVtkyomnRikJhu3R8=.#=zJxoWYNQIfgMz);
					}
					this.#=zn1vWly4=(#=zcJSpiFI=7);
				}
				else if (record.Type == Type.RSTRING)
				{
					Assert.verify(!this.#=zRzM9L4lv39OwOrRPiw==.isBiff8());
					#=zjFsGe4AQuwfE0ah09wLg1MI= #=zcJSpiFI=8 = new #=zjFsGe4AQuwfE0ah09wLg1MI=(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==, #=zjFsGe4AQuwfE0ah09wLg1MI=.#=zJxoWYNQIfgMz);
					this.#=zn1vWly4=(#=zcJSpiFI=8);
				}
				else if (record.Type != Type.NAME)
				{
					if (record.Type == Type.PASSWORD)
					{
						#=zVkDnktqQaYXINdjU_sH6tRI= #=zVkDnktqQaYXINdjU_sH6tRI= = new #=zVkDnktqQaYXINdjU_sH6tRI=(record);
						this.#=z6bRJXNQ=.PasswordHash = #=zVkDnktqQaYXINdjU_sH6tRI=.#=z94Qyva_6wFgj();
					}
					else if (record.Type == Type.ROW)
					{
						RowRecord rowRecord = new RowRecord(record);
						if (!rowRecord.#=zN_gU_Em_6I03() || rowRecord.isCollapsed() || rowRecord.isZeroHeight())
						{
							this.#=zF2WRaDs=.Add(rowRecord);
						}
					}
					else if (record.Type == Type.BLANK)
					{
						BlankCell #=zcJSpiFI=9 = new BlankCell(record, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
						this.#=zn1vWly4=(#=zcJSpiFI=9);
					}
					else if (record.Type == Type.MULBLANK)
					{
						#=zGKxEku68USBDFUJUbzLaLf$ryQer #=zGKxEku68USBDFUJUbzLaLf$ryQer = new #=zGKxEku68USBDFUJUbzLaLf$ryQer(record);
						int num3 = #=zGKxEku68USBDFUJUbzLaLf$ryQer.#=zhUfM2IzcS5zU();
						for (int k = 0; k < num3; k++)
						{
							int #=zPZu1Eq8= = #=zGKxEku68USBDFUJUbzLaLf$ryQer.#=zJVc2l$oPfOau(k);
							#=znWaKw4kqnwpWPK4Xh97hQbP84bvk #=zcJSpiFI=10 = new #=znWaKw4kqnwpWPK4Xh97hQbP84bvk(#=zGKxEku68USBDFUJUbzLaLf$ryQer.#=zNMAKc1U=(), #=zGKxEku68USBDFUJUbzLaLf$ryQer.#=zas6WF9Y7vCuz() + k, #=zPZu1Eq8=, this.#=zwKQa9tCrbbw$, this.#=zNEZ0SGey$A9J);
							this.#=zn1vWly4=(#=zcJSpiFI=10);
						}
					}
					else if (record.Type == Type.SCL)
					{
						#=zcrOVZP3y1tL51HDCqoQyhR4gGvym #=zcrOVZP3y1tL51HDCqoQyhR4gGvym = new #=zcrOVZP3y1tL51HDCqoQyhR4gGvym(record);
						this.#=z6bRJXNQ=.ZoomFactor = #=zcrOVZP3y1tL51HDCqoQyhR4gGvym.#=zCKlbGs0WDfWv();
					}
					else if (record.Type == Type.COLINFO)
					{
						ColumnInfoRecord value3 = new ColumnInfoRecord(record);
						this.#=zmshE82IEtIBL.Add(value3);
					}
					else if (record.Type == Type.HEADER)
					{
						HeaderRecord headerRecord;
						if (this.#=zRzM9L4lv39OwOrRPiw==.isBiff8())
						{
							headerRecord = new HeaderRecord(record, this.#=zGgQ88FCSf3u6XZljng==);
						}
						else
						{
							headerRecord = new HeaderRecord(record, this.#=zGgQ88FCSf3u6XZljng==, HeaderRecord.biff7);
						}
						NExcel.HeaderFooter header = new NExcel.HeaderFooter(headerRecord.#=zQRmPMa9A4K7a());
						this.#=z6bRJXNQ=.Header = header;
					}
					else if (record.Type == Type.FOOTER)
					{
						FooterRecord footerRecord;
						if (this.#=zRzM9L4lv39OwOrRPiw==.isBiff8())
						{
							footerRecord = new FooterRecord(record, this.#=zGgQ88FCSf3u6XZljng==);
						}
						else
						{
							footerRecord = new FooterRecord(record, this.#=zGgQ88FCSf3u6XZljng==, FooterRecord.biff7);
						}
						NExcel.HeaderFooter footer = new NExcel.HeaderFooter(footerRecord.#=zVQqUHDI1Biws());
						this.#=z6bRJXNQ=.Footer = footer;
					}
					else if (record.Type == Type.SETUP)
					{
						SetupRecord setupRecord = new SetupRecord(record);
						if (setupRecord.isPortrait())
						{
							this.#=z6bRJXNQ=.Orientation = PageOrientation.PORTRAIT;
						}
						else
						{
							this.#=z6bRJXNQ=.Orientation = PageOrientation.LANDSCAPE;
						}
						this.#=z6bRJXNQ=.PaperSize = PaperSize.getPaperSize(setupRecord.PaperSize);
						this.#=z6bRJXNQ=.HeaderMargin = setupRecord.HeaderMargin;
						this.#=z6bRJXNQ=.FooterMargin = setupRecord.FooterMargin;
						this.#=z6bRJXNQ=.ScaleFactor = setupRecord.ScaleFactor;
						this.#=z6bRJXNQ=.PageStart = setupRecord.PageStart;
						this.#=z6bRJXNQ=.FitWidth = setupRecord.FitWidth;
						this.#=z6bRJXNQ=.FitHeight = setupRecord.FitHeight;
						this.#=z6bRJXNQ=.HorizontalPrintResolution = setupRecord.HorizontalPrintResolution;
						this.#=z6bRJXNQ=.VerticalPrintResolution = setupRecord.VerticalPrintResolution;
						this.#=z6bRJXNQ=.Copies = setupRecord.Copies;
						if (this.#=zcXkV2Pi1c$mP != null)
						{
							this.#=z6bRJXNQ=.FitToPages = this.#=zcXkV2Pi1c$mP.FitToPages;
						}
					}
					else if (record.Type == Type.WSBOOL)
					{
						this.#=zcXkV2Pi1c$mP = new WorkspaceInformationRecord(record);
					}
					else if (record.Type == Type.DEFCOLWIDTH)
					{
						#=zaYT8aKAHk4UAfaJlb1OjWFaDUinM #=zaYT8aKAHk4UAfaJlb1OjWFaDUinM = new #=zaYT8aKAHk4UAfaJlb1OjWFaDUinM(record);
						this.#=z6bRJXNQ=.DefaultColumnWidth = #=zaYT8aKAHk4UAfaJlb1OjWFaDUinM.#=z3wd31$FU6UNi();
					}
					else if (record.Type == Type.DEFAULTROWHEIGHT)
					{
						#=z0XsBd0_a35ky2DAeWXb5ETjt2TI3 #=z0XsBd0_a35ky2DAeWXb5ETjt2TI = new #=z0XsBd0_a35ky2DAeWXb5ETjt2TI3(record);
						if (#=z0XsBd0_a35ky2DAeWXb5ETjt2TI.#=zOYKii9SVwU3a() != 0)
						{
							this.#=z6bRJXNQ=.DefaultRowHeight = #=z0XsBd0_a35ky2DAeWXb5ETjt2TI.#=zOYKii9SVwU3a();
						}
					}
					else if (record.Type == Type.LEFTMARGIN)
					{
						#=zIysmcffbrCbtDK6qpNil6NA= #=zIysmcffbrCbtDK6qpNil6NA= = new #=zEJ$cA4Bz8pcLrsPh_8lGquf88RWE(record);
						this.#=z6bRJXNQ=.LeftMargin = #=zIysmcffbrCbtDK6qpNil6NA=.#=ze8CeOJ6eHljC();
					}
					else if (record.Type == Type.RIGHTMARGIN)
					{
						#=zIysmcffbrCbtDK6qpNil6NA= #=zIysmcffbrCbtDK6qpNil6NA=2 = new #=zxP0fb3r7nplm_AN_eKvoUTAIZh14(record);
						this.#=z6bRJXNQ=.RightMargin = #=zIysmcffbrCbtDK6qpNil6NA=2.#=ze8CeOJ6eHljC();
					}
					else if (record.Type == Type.TOPMARGIN)
					{
						#=zIysmcffbrCbtDK6qpNil6NA= #=zIysmcffbrCbtDK6qpNil6NA=3 = new #=z5sYY1ZL9rZwR6wKtZfp7H8$5YZfM(record);
						this.#=z6bRJXNQ=.TopMargin = #=zIysmcffbrCbtDK6qpNil6NA=3.#=ze8CeOJ6eHljC();
					}
					else if (record.Type == Type.BOTTOMMARGIN)
					{
						#=zIysmcffbrCbtDK6qpNil6NA= #=zIysmcffbrCbtDK6qpNil6NA=4 = new #=zGD7drqf3iCgkzDDZQ7f6wGtzWK9E(record);
						this.#=z6bRJXNQ=.BottomMargin = #=zIysmcffbrCbtDK6qpNil6NA=4.#=ze8CeOJ6eHljC();
					}
					else if (record.Type == Type.HORIZONTALPAGEBREAKS)
					{
						#=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX;
						if (this.#=zRzM9L4lv39OwOrRPiw==.isBiff8())
						{
							#=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX = new #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX(record);
						}
						else
						{
							#=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX = new #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX(record, #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX.#=zJxoWYNQIfgMz);
						}
						this.#=zF5g$dZZQGSkT = #=zbnVkjCGVbe7JIWvR_YdtCmjJEMUX.#=zOmAd$eG7cqZo();
					}
					else if (record.Type == Type.PLS)
					{
						this.#=zIWg$TzZj_0Ir = new PLSRecord(record);
					}
					else if (record.Type != Type.OBJ)
					{
						if (record.Type == Type.MSODRAWING)
						{
							mso = new MsoDrawingRecord(record);
						}
						else if (record.Type == Type.BOF)
						{
							BOFRecord bofrecord = new BOFRecord(record);
							Assert.verify(!bofrecord.isWorksheet());
							int sp = this.#=zDI_c6jkXGlFD.Pos - record.Length - 4;
							Record record2 = this.#=zDI_c6jkXGlFD.#=zVYqdNhU=();
							while (record2.Code != Type.EOF.Value)
							{
								record2 = this.#=zDI_c6jkXGlFD.#=zVYqdNhU=();
							}
							if (bofrecord.isChart())
							{
								Chart chart = new Chart(mso, obj, sp, this.#=zDI_c6jkXGlFD.Pos, this.#=zDI_c6jkXGlFD, this.#=zGgQ88FCSf3u6XZljng==);
								this.#=zygzOU7ZWzJ3P.Add(chart);
								if (this.#=zJY$tXiAJ_$AzbtOFtg==.DrawingGroup != null)
								{
									this.#=zJY$tXiAJ_$AzbtOFtg==.DrawingGroup.add(chart);
								}
								mso = null;
								obj = null;
							}
							if (this.#=zViVQP81p4BwqFpjFgQ==.isChart())
							{
								flag2 = false;
							}
						}
						else if (record.Type == Type.EOF)
						{
							flag2 = false;
						}
					}
				}
			}
		}
		this.#=zDI_c6jkXGlFD.restorePos();
		foreach (object obj2 in this.#=zxBcpeO43ZpTTP1SMjA==)
		{
			Cell[] array = ((#=ztl7zQY5jOB52OgJX_3oVMtczpItq)obj2).#=zXg1mdZA6dudhkBDv8g==(this.#=zwKQa9tCrbbw$, this.#=z8snpwsaw$imRxg6cFA==);
			for (int l = 0; l < array.Length; l++)
			{
				this.#=zn1vWly4=(array[l]);
			}
		}
		if (!flag && baseSharedFormulaRecord != null)
		{
			this.#=zn1vWly4=(this.#=zHErV_HiPU$XO(baseSharedFormulaRecord));
		}
	}

	// Token: 0x06000E73 RID: 3699 RVA: 0x00073404 File Offset: 0x00071604
	private bool #=zokgSLZdfRmLR_CFfkr1maT8=(BaseSharedFormulaRecord #=zrRXQAB8=)
	{
		bool flag = false;
		foreach (object obj in this.#=zxBcpeO43ZpTTP1SMjA==)
		{
			#=ztl7zQY5jOB52OgJX_3oVMtczpItq #=ztl7zQY5jOB52OgJX_3oVMtczpItq = (#=ztl7zQY5jOB52OgJX_3oVMtczpItq)obj;
			if (flag)
			{
				break;
			}
			flag = #=ztl7zQY5jOB52OgJX_3oVMtczpItq.#=zdJYbEvQ=(#=zrRXQAB8=);
		}
		return flag;
	}

	// Token: 0x06000E74 RID: 3700 RVA: 0x00073468 File Offset: 0x00071668
	private Cell #=zHErV_HiPU$XO(BaseSharedFormulaRecord #=zTRA8u0c=)
	{
		int pos = this.#=zDI_c6jkXGlFD.Pos;
		this.#=zDI_c6jkXGlFD.Pos = #=zTRA8u0c=.#=zq9EAmL_tCYxf();
		#=z5jeE6bKUUm6$P8GX1rIIQpA= #=z5jeE6bKUUm6$P8GX1rIIQpA= = new #=z5jeE6bKUUm6$P8GX1rIIQpA=(#=zTRA8u0c=.getRecord(), this.#=zDI_c6jkXGlFD, this.#=zwKQa9tCrbbw$, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zJY$tXiAJ_$AzbtOFtg==, #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zVg7jYRh8fpFz, this.#=zNEZ0SGey$A9J, this.#=zGgQ88FCSf3u6XZljng==);
		Cell result = #=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$();
		if (#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$().Type == CellType.NUMBER_FORMULA)
		{
			#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z #=zJce$Sys= = (#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z)#=z5jeE6bKUUm6$P8GX1rIIQpA=.#=zmUYpUBj2v7o$();
			if (this.#=zwKQa9tCrbbw$.isDate(#=z5jeE6bKUUm6$P8GX1rIIQpA=.XFIndex))
			{
				result = new #=zAN6nfDbGVeM6PRGodOTnP2$G4k_M(#=zJce$Sys=, this.#=zwKQa9tCrbbw$, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=zJY$tXiAJ_$AzbtOFtg==, this.#=z8snpwsaw$imRxg6cFA==, this.#=zNEZ0SGey$A9J);
			}
		}
		this.#=zDI_c6jkXGlFD.Pos = pos;
		return result;
	}

	// Token: 0x040007FF RID: 2047
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zYIxo3mZj9AHsqpBLaTYcwZo=));

	// Token: 0x04000800 RID: 2048
	private File #=zDI_c6jkXGlFD;

	// Token: 0x04000801 RID: 2049
	private SSTRecord #=zZjXcmtS49F0G;

	// Token: 0x04000802 RID: 2050
	private BOFRecord #=zViVQP81p4BwqFpjFgQ==;

	// Token: 0x04000803 RID: 2051
	private BOFRecord #=zRzM9L4lv39OwOrRPiw==;

	// Token: 0x04000804 RID: 2052
	private FormattingRecords #=zwKQa9tCrbbw$;

	// Token: 0x04000805 RID: 2053
	private int #=zgTmLAohDTfaZ;

	// Token: 0x04000806 RID: 2054
	private int #=zuyRGtIBGTWoN;

	// Token: 0x04000807 RID: 2055
	private Cell[][] #=zRV_$73M=;

	// Token: 0x04000808 RID: 2056
	private int #=zBPg5R5JI4JfJ;

	// Token: 0x04000809 RID: 2057
	private ArrayList #=zF2WRaDs=;

	// Token: 0x0400080A RID: 2058
	private ArrayList #=zmshE82IEtIBL;

	// Token: 0x0400080B RID: 2059
	private ArrayList #=zxBcpeO43ZpTTP1SMjA==;

	// Token: 0x0400080C RID: 2060
	private ArrayList #=z9MDU2K_833d9kAfSuA==;

	// Token: 0x0400080D RID: 2061
	private Range[] #=zpBbFDjVAL0MB;

	// Token: 0x0400080E RID: 2062
	private ArrayList #=zygzOU7ZWzJ3P;

	// Token: 0x0400080F RID: 2063
	private ArrayList #=zq6L3hNAMw96suiNzaw==;

	// Token: 0x04000810 RID: 2064
	private bool #=z8snpwsaw$imRxg6cFA==;

	// Token: 0x04000811 RID: 2065
	private PLSRecord #=zIWg$TzZj_0Ir;

	// Token: 0x04000812 RID: 2066
	private WorkspaceInformationRecord #=zcXkV2Pi1c$mP;

	// Token: 0x04000813 RID: 2067
	private int[] #=zF5g$dZZQGSkT;

	// Token: 0x04000814 RID: 2068
	private SheetSettings #=z6bRJXNQ=;

	// Token: 0x04000815 RID: 2069
	private WorkbookSettings #=zGgQ88FCSf3u6XZljng==;

	// Token: 0x04000816 RID: 2070
	private WorkbookParser #=zJY$tXiAJ_$AzbtOFtg==;

	// Token: 0x04000817 RID: 2071
	private SheetImpl #=zNEZ0SGey$A9J;
}
