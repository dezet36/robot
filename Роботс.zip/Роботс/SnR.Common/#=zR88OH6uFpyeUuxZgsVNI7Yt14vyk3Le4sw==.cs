﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Media;
using System.Windows.Forms;
using Skink.SnR.Common.Interface;

// Token: 0x0200018F RID: 399
internal sealed partial class #=zR88OH6uFpyeUuxZgsVNI7Yt14vyk3Le4sw== : Form
{
	// Token: 0x06000B67 RID: 2919 RVA: 0x000577F8 File Offset: 0x000559F8
	public #=zR88OH6uFpyeUuxZgsVNI7Yt14vyk3Le4sw==(Robot #=zP95I7AY=, string #=zx9NCziM=, string #=zyKmVS_NSR7h7)
	{
		this.#=zgpzgXirqPT5_();
		this.#=zmJrXR$548V1V = #=zP95I7AY=;
		this.#=zSUrlY_ytokX$.Text = #=zx9NCziM=;
		this.#=zksSn4UqyUPq8.Text = string.Empty;
		if (!string.IsNullOrEmpty(#=zyKmVS_NSR7h7))
		{
			try
			{
				SoundPlayer soundPlayer = new SoundPlayer(#=zyKmVS_NSR7h7);
				try
				{
					soundPlayer.Play();
				}
				finally
				{
					((IDisposable)soundPlayer).Dispose();
				}
			}
			catch (Exception ex)
			{
				this.#=zksSn4UqyUPq8.Text = ex.Message;
			}
		}
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06000B68 RID: 2920 RVA: 0x00057890 File Offset: 0x00055A90
	private void #=zdz4fwxNuF0Q2(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zmJrXR$548V1V.WindowState == FormWindowState.Minimized)
		{
			this.#=zmJrXR$548V1V.ShowAndRestore();
		}
		this.#=zmJrXR$548V1V.Focus();
		this.#=zmJrXR$548V1V.#=z$nFR3K_ghYU7(#=zP95I7AY=, #=z4Q$h3mE=);
		base.Close();
	}

	// Token: 0x06000B6A RID: 2922 RVA: 0x000578EC File Offset: 0x00055AEC
	private void #=zgpzgXirqPT5_()
	{
		this.#=zSUrlY_ytokX$ = new Label();
		this.#=zYogiCTU= = new Button();
		this.#=zksSn4UqyUPq8 = new Label();
		base.SuspendLayout();
		this.#=zSUrlY_ytokX$.AutoSize = true;
		this.#=zSUrlY_ytokX$.Font = new Font(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113796), 12f, FontStyle.Regular, GraphicsUnit.Point, 177);
		this.#=zSUrlY_ytokX$.Location = new Point(12, 9);
		this.#=zSUrlY_ytokX$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113763);
		this.#=zSUrlY_ytokX$.Size = new Size(51, 20);
		this.#=zSUrlY_ytokX$.TabIndex = 0;
		this.#=zSUrlY_ytokX$.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		this.#=zYogiCTU=.Location = new Point(203, 126);
		this.#=zYogiCTU=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113741);
		this.#=zYogiCTU=.Size = new Size(75, 23);
		this.#=zYogiCTU=.TabIndex = 1;
		this.#=zYogiCTU=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113458);
		this.#=zYogiCTU=.UseVisualStyleBackColor = true;
		this.#=zYogiCTU=.Click += this.#=zdz4fwxNuF0Q2;
		this.#=zksSn4UqyUPq8.AutoSize = true;
		this.#=zksSn4UqyUPq8.Location = new Point(13, 81);
		this.#=zksSn4UqyUPq8.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113455);
		this.#=zksSn4UqyUPq8.Size = new Size(35, 13);
		this.#=zksSn4UqyUPq8.TabIndex = 2;
		this.#=zksSn4UqyUPq8.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113744);
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(484, 161);
		base.Controls.Add(this.#=zksSn4UqyUPq8);
		base.Controls.Add(this.#=zYogiCTU=);
		base.Controls.Add(this.#=zSUrlY_ytokX$);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113436);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909113436);
		base.ResumeLayout(false);
		base.PerformLayout();
	}

	// Token: 0x04000622 RID: 1570
	private Robot #=zmJrXR$548V1V;

	// Token: 0x04000624 RID: 1572
	private Label #=zSUrlY_ytokX$;

	// Token: 0x04000625 RID: 1573
	private Button #=zYogiCTU=;

	// Token: 0x04000626 RID: 1574
	private Label #=zksSn4UqyUPq8;
}
