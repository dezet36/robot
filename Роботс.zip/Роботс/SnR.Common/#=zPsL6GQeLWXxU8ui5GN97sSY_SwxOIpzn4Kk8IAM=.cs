﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Skink.SnR.Common.GZip;

// Token: 0x02000183 RID: 387
internal sealed class #=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM= : Stream
{
	// Token: 0x06000B01 RID: 2817 RVA: 0x0005551C File Offset: 0x0005371C
	public #=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=(Stream #=zOKM0Ras=, CompressionMode #=zpIlCQeE5NwHK, CompressionLevel #=z5w6HcG4=, #=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM= #=zFBKIcq0=, bool #=zjxitMnvoqpr_)
	{
		this.#=zC9rjKjh8XW43 = FlushType.None;
		this.#=zCdleKCw= = #=zOKM0Ras=;
		this.#=znLOvLlPd3uyP = #=zjxitMnvoqpr_;
		this.#=zbjrH5jEMPl2s = #=zpIlCQeE5NwHK;
		this.#=ze1geZg0= = #=zFBKIcq0=;
		this.#=zhEnsRRk= = #=z5w6HcG4=;
		if (#=zFBKIcq0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952)
		{
			this.#=z9vd3658= = new #=zvC3r7NtXY$O9ow$C2FOpkWtzbVrAzqUanw==();
		}
	}

	// Token: 0x06000B02 RID: 2818 RVA: 0x00055590 File Offset: 0x00053790
	internal int #=zSJ6XpjBx5HmY()
	{
		if (this.#=z9vd3658= == null)
		{
			return 0;
		}
		return this.#=z9vd3658=.#=zyJPX604rf3AyxLt4Qg==();
	}

	// Token: 0x06000B03 RID: 2819 RVA: 0x000555A8 File Offset: 0x000537A8
	protected internal bool #=zfgEleQE7Wpws()
	{
		return this.#=zbjrH5jEMPl2s == CompressionMode.Compress;
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x000555B4 File Offset: 0x000537B4
	private #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zaszZXvs=()
	{
		if (this.#=zCBQCeoY= == null)
		{
			bool flag = this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1950;
			this.#=zCBQCeoY= = new #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg=();
			if (this.#=zbjrH5jEMPl2s == CompressionMode.Decompress)
			{
				this.#=zCBQCeoY=.#=zdtZWlb0YWO6XjySgaw==(flag);
			}
			else
			{
				this.#=zCBQCeoY=.#=zmVI4x4w= = this.#=zmVI4x4w=;
				this.#=zCBQCeoY=.#=zXgM3SNq1Zylk(this.#=zhEnsRRk=, flag);
			}
		}
		return this.#=zCBQCeoY=;
	}

	// Token: 0x06000B05 RID: 2821 RVA: 0x00055624 File Offset: 0x00053824
	private byte[] #=zmKecrbX9ExwC()
	{
		if (this.#=zDpdwR$4HWP97 == null)
		{
			this.#=zDpdwR$4HWP97 = new byte[this.#=zHzR3R0R082dC];
		}
		return this.#=zDpdwR$4HWP97;
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x00055648 File Offset: 0x00053848
	public override void Write(byte[] #=zt$AAAmQ=, int #=zcTvfij8=, int #=z4UDysxM=)
	{
		if (this.#=z9vd3658= != null)
		{
			this.#=z9vd3658=.#=zN5gkKlGrgCD0(#=zt$AAAmQ=, #=zcTvfij8=, #=z4UDysxM=);
		}
		if (this.#=zrvxPjW2q8uM2 == (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)2)
		{
			this.#=zrvxPjW2q8uM2 = (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)0;
		}
		else if (this.#=zrvxPjW2q8uM2 != (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)0)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063550));
		}
		if (#=z4UDysxM= == 0)
		{
			return;
		}
		this.#=zaszZXvs=().#=zJtQJROi1bLs0 = #=zt$AAAmQ=;
		this.#=zCBQCeoY=.#=z_f$vhX8= = #=zcTvfij8=;
		this.#=zCBQCeoY=.#=zEVNP$$evg7c3 = #=z4UDysxM=;
		for (;;)
		{
			this.#=zCBQCeoY=.#=zTkQEpCPgqFwZ = this.#=zmKecrbX9ExwC();
			this.#=zCBQCeoY=.#=z6v5OUYo= = 0;
			this.#=zCBQCeoY=.#=zRQNIMvX_JmPR = this.#=zDpdwR$4HWP97.Length;
			int num = this.#=zfgEleQE7Wpws() ? this.#=zCBQCeoY=.#=zYdo2_SU=(this.#=zC9rjKjh8XW43) : this.#=zCBQCeoY=.#=zlJv54NpQwKIa(this.#=zC9rjKjh8XW43);
			if (num != 0 && num != 1)
			{
				break;
			}
			this.#=zCdleKCw=.Write(this.#=zDpdwR$4HWP97, 0, this.#=zDpdwR$4HWP97.Length - this.#=zCBQCeoY=.#=zRQNIMvX_JmPR);
			bool flag = this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 0 && this.#=zCBQCeoY=.#=zRQNIMvX_JmPR != 0;
			if (this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952 && !this.#=zfgEleQE7Wpws())
			{
				flag = (this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 8 && this.#=zCBQCeoY=.#=zRQNIMvX_JmPR != 0);
			}
			if (flag)
			{
				return;
			}
		}
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==((this.#=zfgEleQE7Wpws() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067396) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063516)) + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063509) + this.#=zCBQCeoY=.#=znwxGN8g=);
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x000557E4 File Offset: 0x000539E4
	private void #=zODiGXBM=()
	{
		if (this.#=zCBQCeoY= == null)
		{
			return;
		}
		if (this.#=zrvxPjW2q8uM2 == (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)0)
		{
			int num;
			for (;;)
			{
				this.#=zCBQCeoY=.#=zTkQEpCPgqFwZ = this.#=zmKecrbX9ExwC();
				this.#=zCBQCeoY=.#=z6v5OUYo= = 0;
				this.#=zCBQCeoY=.#=zRQNIMvX_JmPR = this.#=zDpdwR$4HWP97.Length;
				num = (this.#=zfgEleQE7Wpws() ? this.#=zCBQCeoY=.#=zYdo2_SU=(FlushType.Finish) : this.#=zCBQCeoY=.#=zlJv54NpQwKIa(FlushType.Finish));
				if (num != 1 && num != 0)
				{
					break;
				}
				if (this.#=zDpdwR$4HWP97.Length - this.#=zCBQCeoY=.#=zRQNIMvX_JmPR > 0)
				{
					this.#=zCdleKCw=.Write(this.#=zDpdwR$4HWP97, 0, this.#=zDpdwR$4HWP97.Length - this.#=zCBQCeoY=.#=zRQNIMvX_JmPR);
				}
				bool flag = this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 0 && this.#=zCBQCeoY=.#=zRQNIMvX_JmPR != 0;
				if (this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952 && !this.#=zfgEleQE7Wpws())
				{
					flag = (this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 8 && this.#=zCBQCeoY=.#=zRQNIMvX_JmPR != 0);
				}
				if (flag)
				{
					goto Block_12;
				}
			}
			string text = (this.#=zfgEleQE7Wpws() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067396) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063516)) + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063493);
			if (this.#=zCBQCeoY=.#=znwxGN8g= == null)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063479), text, num));
			}
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(text + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070981) + this.#=zCBQCeoY=.#=znwxGN8g=);
			Block_12:
			this.Flush();
			if (this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952)
			{
				if (this.#=zfgEleQE7Wpws())
				{
					int value = this.#=z9vd3658=.#=zyJPX604rf3AyxLt4Qg==();
					this.#=zCdleKCw=.Write(BitConverter.GetBytes(value), 0, 4);
					int value2 = (int)(this.#=z9vd3658=.#=zyQ$1QGAO$aSm() & (long)((ulong)-1));
					this.#=zCdleKCw=.Write(BitConverter.GetBytes(value2), 0, 4);
					return;
				}
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063449));
			}
		}
		else if (this.#=zrvxPjW2q8uM2 == (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)1 && this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952)
		{
			if (this.#=zfgEleQE7Wpws())
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063660));
			}
			if (this.#=zCBQCeoY=.#=z0KaacqESNJ$P == 0L)
			{
				return;
			}
			byte[] array = new byte[8];
			if (this.#=zCBQCeoY=.#=zEVNP$$evg7c3 < 8)
			{
				Array.Copy(this.#=zCBQCeoY=.#=zJtQJROi1bLs0, this.#=zCBQCeoY=.#=z_f$vhX8=, array, 0, this.#=zCBQCeoY=.#=zEVNP$$evg7c3);
				int num2 = 8 - this.#=zCBQCeoY=.#=zEVNP$$evg7c3;
				int num3 = this.#=zCdleKCw=.Read(array, this.#=zCBQCeoY=.#=zEVNP$$evg7c3, num2);
				if (num2 != num3)
				{
				}
			}
			else
			{
				Array.Copy(this.#=zCBQCeoY=.#=zJtQJROi1bLs0, this.#=zCBQCeoY=.#=z_f$vhX8=, array, 0, array.Length);
			}
			BitConverter.ToInt32(array, 0);
			this.#=z9vd3658=.#=zyJPX604rf3AyxLt4Qg==();
			BitConverter.ToInt32(array, 4);
			long #=z0KaacqESNJ$P = this.#=zCBQCeoY=.#=z0KaacqESNJ$P;
			return;
		}
	}

	// Token: 0x06000B08 RID: 2824 RVA: 0x00055AE4 File Offset: 0x00053CE4
	private void #=zf$NwTlE=()
	{
		if (this.#=zaszZXvs=() == null)
		{
			return;
		}
		if (this.#=zfgEleQE7Wpws())
		{
			this.#=zCBQCeoY=.#=zgC46X9w=();
		}
		else
		{
			this.#=zCBQCeoY=.#=zQ70TW76HUgSSd3E9pg==();
		}
		this.#=zCBQCeoY= = null;
	}

	// Token: 0x06000B09 RID: 2825 RVA: 0x00055B18 File Offset: 0x00053D18
	public override void Close()
	{
		if (this.#=zCdleKCw= == null)
		{
			return;
		}
		try
		{
			this.#=zODiGXBM=();
		}
		finally
		{
			this.#=zf$NwTlE=();
			if (!this.#=znLOvLlPd3uyP)
			{
				this.#=zCdleKCw=.Close();
			}
			this.#=zCdleKCw= = null;
		}
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x00055B68 File Offset: 0x00053D68
	public override void Flush()
	{
		this.#=zCdleKCw=.Flush();
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x00055B78 File Offset: 0x00053D78
	public override long Seek(long #=zcTvfij8=, SeekOrigin #=zqZJEvgY=)
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x00055B80 File Offset: 0x00053D80
	public override void SetLength(long #=z$Ib9gYQ=)
	{
		this.#=zCdleKCw=.SetLength(#=z$Ib9gYQ=);
	}

	// Token: 0x06000B0D RID: 2829 RVA: 0x00055B90 File Offset: 0x00053D90
	private string #=zMrvtwyaY5zbO()
	{
		List<byte> list = new List<byte>();
		bool flag = false;
		while (this.#=zCdleKCw=.Read(this.#=ziytojaGEkT4_, 0, 1) == 1)
		{
			if (this.#=ziytojaGEkT4_[0] == 0)
			{
				flag = true;
			}
			else
			{
				list.Add(this.#=ziytojaGEkT4_[0]);
			}
			if (flag)
			{
				byte[] array = list.ToArray();
				return GZipStream.#=z1aI5hmwNY7xRkHfrkDqjKz4=.GetString(array, 0, array.Length);
			}
		}
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063613));
	}

	// Token: 0x06000B0E RID: 2830 RVA: 0x00055C00 File Offset: 0x00053E00
	private int #=z0lU6$xBqsogUUpNhRg==()
	{
		int num = 0;
		byte[] array = new byte[10];
		int num2 = this.#=zCdleKCw=.Read(array, 0, array.Length);
		if (num2 == 0)
		{
			return 0;
		}
		if (num2 != 10)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063563));
		}
		if (array[0] != 31 || array[1] != 139 || array[2] != 8)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063274));
		}
		int num3 = BitConverter.ToInt32(array, 4);
		this.#=z6h1N6Vvdnie$T7AQ7g== = GZipStream.#=z8Xv7veyDoklE.AddSeconds((double)num3);
		num += num2;
		if ((array[3] & 4) == 4)
		{
			num2 = this.#=zCdleKCw=.Read(array, 0, 2);
			num += num2;
			short num4 = (short)((int)array[0] + (int)array[1] * 256);
			byte[] array2 = new byte[(int)num4];
			num2 = this.#=zCdleKCw=.Read(array2, 0, array2.Length);
			if (num2 != (int)num4)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063261));
			}
			num += num2;
		}
		if ((array[3] & 8) == 8)
		{
			this.#=z2yczZs_Hxnkd = this.#=zMrvtwyaY5zbO();
		}
		if ((array[3] & 16) == 16)
		{
			this.#=z9RqeXR5KS3_z = this.#=zMrvtwyaY5zbO();
		}
		if ((array[3] & 2) == 2)
		{
			this.Read(this.#=ziytojaGEkT4_, 0, 1);
		}
		return num;
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x00055D2C File Offset: 0x00053F2C
	public override int Read(byte[] #=zt$AAAmQ=, int #=zcTvfij8=, int #=z4UDysxM=)
	{
		if (this.#=zrvxPjW2q8uM2 == (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)2)
		{
			if (!this.#=zCdleKCw=.CanRead)
			{
				throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063203));
			}
			this.#=zrvxPjW2q8uM2 = (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)1;
			this.#=zaszZXvs=().#=zEVNP$$evg7c3 = 0;
			if (this.#=ze1geZg0= == (#=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM=)1952)
			{
				this.#=zVyJpnhoYbBClzxnC1A== = this.#=z0lU6$xBqsogUUpNhRg==();
				if (this.#=zVyJpnhoYbBClzxnC1A== == 0)
				{
					return 0;
				}
			}
		}
		if (this.#=zrvxPjW2q8uM2 != (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)1)
		{
			throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063169));
		}
		if (#=z4UDysxM= == 0)
		{
			return 0;
		}
		if (this.#=z15MWBRkSnNuhPlikKw== && this.#=zfgEleQE7Wpws())
		{
			return 0;
		}
		if (#=zt$AAAmQ= == null)
		{
			throw new ArgumentNullException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063398));
		}
		if (#=z4UDysxM= < 0)
		{
			throw new ArgumentOutOfRangeException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063389));
		}
		if (#=zcTvfij8= < #=zt$AAAmQ=.GetLowerBound(0))
		{
			throw new ArgumentOutOfRangeException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063368));
		}
		if (#=zcTvfij8= + #=z4UDysxM= > #=zt$AAAmQ=.GetLength(0))
		{
			throw new ArgumentOutOfRangeException(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063367));
		}
		this.#=zCBQCeoY=.#=zTkQEpCPgqFwZ = #=zt$AAAmQ=;
		this.#=zCBQCeoY=.#=z6v5OUYo= = #=zcTvfij8=;
		this.#=zCBQCeoY=.#=zRQNIMvX_JmPR = #=z4UDysxM=;
		this.#=zCBQCeoY=.#=zJtQJROi1bLs0 = this.#=zmKecrbX9ExwC();
		int num;
		for (;;)
		{
			if (this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 0 && !this.#=z15MWBRkSnNuhPlikKw==)
			{
				this.#=zCBQCeoY=.#=z_f$vhX8= = 0;
				this.#=zCBQCeoY=.#=zEVNP$$evg7c3 = this.#=zCdleKCw=.Read(this.#=zDpdwR$4HWP97, 0, this.#=zDpdwR$4HWP97.Length);
				if (this.#=zCBQCeoY=.#=zEVNP$$evg7c3 == 0)
				{
					this.#=z15MWBRkSnNuhPlikKw== = true;
				}
			}
			num = (this.#=zfgEleQE7Wpws() ? this.#=zCBQCeoY=.#=zYdo2_SU=(this.#=zC9rjKjh8XW43) : this.#=zCBQCeoY=.#=zlJv54NpQwKIa(this.#=zC9rjKjh8XW43));
			if (this.#=z15MWBRkSnNuhPlikKw== && num == -5)
			{
				break;
			}
			if (num != 0 && num != 1)
			{
				goto Block_20;
			}
			if (((this.#=z15MWBRkSnNuhPlikKw== || num == 1) && this.#=zCBQCeoY=.#=zRQNIMvX_JmPR == #=z4UDysxM=) || this.#=zCBQCeoY=.#=zRQNIMvX_JmPR <= 0 || this.#=z15MWBRkSnNuhPlikKw== || num != 0)
			{
				goto IL_237;
			}
		}
		return 0;
		Block_20:
		throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063346), this.#=zfgEleQE7Wpws() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067396) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063516), num, this.#=zCBQCeoY=.#=znwxGN8g=));
		IL_237:
		if (this.#=zCBQCeoY=.#=zRQNIMvX_JmPR > 0)
		{
			if (num == 0)
			{
				int #=zEVNP$$evg7c = this.#=zCBQCeoY=.#=zEVNP$$evg7c3;
			}
			if (this.#=z15MWBRkSnNuhPlikKw== && this.#=zfgEleQE7Wpws())
			{
				num = this.#=zCBQCeoY=.#=zYdo2_SU=(FlushType.Finish);
				if (num != 0 && num != 1)
				{
					throw new #=z53g6mayx8J8yC339AKMmaSbKYHGDXQZdfw==(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909063313), num, this.#=zCBQCeoY=.#=znwxGN8g=));
				}
			}
		}
		num = #=z4UDysxM= - this.#=zCBQCeoY=.#=zRQNIMvX_JmPR;
		if (this.#=z9vd3658= != null)
		{
			this.#=z9vd3658=.#=zN5gkKlGrgCD0(#=zt$AAAmQ=, #=zcTvfij8=, num);
		}
		return num;
	}

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000B10 RID: 2832 RVA: 0x00055FFC File Offset: 0x000541FC
	public override bool CanRead
	{
		get
		{
			return this.#=zCdleKCw=.CanRead;
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000B11 RID: 2833 RVA: 0x0005600C File Offset: 0x0005420C
	public override bool CanSeek
	{
		get
		{
			return this.#=zCdleKCw=.CanSeek;
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000B12 RID: 2834 RVA: 0x0005601C File Offset: 0x0005421C
	public override bool CanWrite
	{
		get
		{
			return this.#=zCdleKCw=.CanWrite;
		}
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000B13 RID: 2835 RVA: 0x0005602C File Offset: 0x0005422C
	public override long Length
	{
		get
		{
			return this.#=zCdleKCw=.Length;
		}
	}

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000B14 RID: 2836 RVA: 0x0005603C File Offset: 0x0005423C
	// (set) Token: 0x06000B15 RID: 2837 RVA: 0x00056044 File Offset: 0x00054244
	public override long Position
	{
		get
		{
			throw new NotImplementedException();
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x0005604C File Offset: 0x0005424C
	public static void #=zZb7y7sI=(string #=zWj7xLq8=, Stream #=zW55xavZ_4KHm6VgnFw==)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(#=zWj7xLq8=);
		try
		{
			#=zW55xavZ_4KHm6VgnFw==.Write(bytes, 0, bytes.Length);
		}
		finally
		{
			if (#=zW55xavZ_4KHm6VgnFw== != null)
			{
				((IDisposable)#=zW55xavZ_4KHm6VgnFw==).Dispose();
			}
		}
	}

	// Token: 0x06000B17 RID: 2839 RVA: 0x00056090 File Offset: 0x00054290
	public static void #=zRBswV3mRGai2(byte[] #=zcltuPyw=, Stream #=zW55xavZ_4KHm6VgnFw==)
	{
		try
		{
			#=zW55xavZ_4KHm6VgnFw==.Write(#=zcltuPyw=, 0, #=zcltuPyw=.Length);
		}
		finally
		{
			if (#=zW55xavZ_4KHm6VgnFw== != null)
			{
				((IDisposable)#=zW55xavZ_4KHm6VgnFw==).Dispose();
			}
		}
	}

	// Token: 0x06000B18 RID: 2840 RVA: 0x000560C8 File Offset: 0x000542C8
	public static string #=z5W8gASrGN1ocqTPPVQ==(byte[] #=z2KaUNHk=, Stream #=zrQ7kNEzl6VzOIhIX4Z3naZ8=)
	{
		byte[] array = new byte[1024];
		Encoding utf = Encoding.UTF8;
		MemoryStream memoryStream = new MemoryStream();
		string result;
		try
		{
			try
			{
				int count;
				while ((count = #=zrQ7kNEzl6VzOIhIX4Z3naZ8=.Read(array, 0, array.Length)) != 0)
				{
					memoryStream.Write(array, 0, count);
				}
			}
			finally
			{
				if (#=zrQ7kNEzl6VzOIhIX4Z3naZ8= != null)
				{
					((IDisposable)#=zrQ7kNEzl6VzOIhIX4Z3naZ8=).Dispose();
				}
			}
			memoryStream.Seek(0L, SeekOrigin.Begin);
			result = new StreamReader(memoryStream, utf).ReadToEnd();
		}
		finally
		{
			((IDisposable)memoryStream).Dispose();
		}
		return result;
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x00056158 File Offset: 0x00054358
	public static byte[] #=z2IeFi8bAU3Lqn3$6$lljD7w=(byte[] #=z2KaUNHk=, Stream #=zrQ7kNEzl6VzOIhIX4Z3naZ8=)
	{
		byte[] array = new byte[1024];
		MemoryStream memoryStream = new MemoryStream();
		byte[] result;
		try
		{
			try
			{
				int count;
				while ((count = #=zrQ7kNEzl6VzOIhIX4Z3naZ8=.Read(array, 0, array.Length)) != 0)
				{
					memoryStream.Write(array, 0, count);
				}
			}
			finally
			{
				if (#=zrQ7kNEzl6VzOIhIX4Z3naZ8= != null)
				{
					((IDisposable)#=zrQ7kNEzl6VzOIhIX4Z3naZ8=).Dispose();
				}
			}
			result = memoryStream.ToArray();
		}
		finally
		{
			((IDisposable)memoryStream).Dispose();
		}
		return result;
	}

	// Token: 0x040005E2 RID: 1506
	protected internal #=zIPA2B43sUvMR5g8uDFkUXN1V3HGMkj$8mgAD8sg= #=zCBQCeoY=;

	// Token: 0x040005E3 RID: 1507
	protected internal #=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG #=zrvxPjW2q8uM2 = (#=zPsL6GQeLWXxU8ui5GN97sSY_SwxOIpzn4Kk8IAM=.#=z4sStKCj1ECoG)2;

	// Token: 0x040005E4 RID: 1508
	protected internal FlushType #=zC9rjKjh8XW43;

	// Token: 0x040005E5 RID: 1509
	protected internal #=zJZbYyIV1dlnNvmbAwfkhs_V8Me0F3IbERXUSAEM= #=ze1geZg0=;

	// Token: 0x040005E6 RID: 1510
	protected internal CompressionMode #=zbjrH5jEMPl2s;

	// Token: 0x040005E7 RID: 1511
	protected internal CompressionLevel #=zhEnsRRk=;

	// Token: 0x040005E8 RID: 1512
	protected internal bool #=znLOvLlPd3uyP;

	// Token: 0x040005E9 RID: 1513
	protected internal byte[] #=zDpdwR$4HWP97;

	// Token: 0x040005EA RID: 1514
	protected internal int #=zHzR3R0R082dC = 16384;

	// Token: 0x040005EB RID: 1515
	protected internal byte[] #=ziytojaGEkT4_ = new byte[1];

	// Token: 0x040005EC RID: 1516
	protected internal Stream #=zCdleKCw=;

	// Token: 0x040005ED RID: 1517
	protected internal CompressionStrategy #=zmVI4x4w=;

	// Token: 0x040005EE RID: 1518
	private #=zvC3r7NtXY$O9ow$C2FOpkWtzbVrAzqUanw== #=z9vd3658=;

	// Token: 0x040005EF RID: 1519
	protected internal string #=z2yczZs_Hxnkd;

	// Token: 0x040005F0 RID: 1520
	protected internal string #=z9RqeXR5KS3_z;

	// Token: 0x040005F1 RID: 1521
	protected internal DateTime #=z6h1N6Vvdnie$T7AQ7g==;

	// Token: 0x040005F2 RID: 1522
	protected internal int #=zVyJpnhoYbBClzxnC1A==;

	// Token: 0x040005F3 RID: 1523
	private bool #=z15MWBRkSnNuhPlikKw==;

	// Token: 0x02000184 RID: 388
	internal enum #=z4sStKCj1ECoG
	{

	}
}
