﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200012A RID: 298
internal sealed class #=zJCqcRccbIsetIoA5cBhjLtg= : RecordData
{
	// Token: 0x06000758 RID: 1880 RVA: 0x0003CDB4 File Offset: 0x0003AFB4
	internal #=zJCqcRccbIsetIoA5cBhjLtg=(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = this.getRecord().Data;
		int @int = IntegerHelper.getInt(data[0], data[1]);
		this.#=zk3gc7ld07Rln = (@int == 1);
	}

	// Token: 0x06000759 RID: 1881 RVA: 0x0003CDEC File Offset: 0x0003AFEC
	internal bool #=zpwQuD$4=()
	{
		return this.#=zk3gc7ld07Rln;
	}

	// Token: 0x04000468 RID: 1128
	private bool #=zk3gc7ld07Rln;
}
