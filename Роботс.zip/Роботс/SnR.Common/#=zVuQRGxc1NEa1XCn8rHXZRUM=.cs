﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x020001C4 RID: 452
internal sealed class #=zVuQRGxc1NEa1XCn8rHXZRUM= : CellValue, NumberCell, Cell
{
	// Token: 0x06000D65 RID: 3429 RVA: 0x00068CA4 File Offset: 0x00066EA4
	public #=zVuQRGxc1NEa1XCn8rHXZRUM=(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zaiKvawI= = DoubleHelper.getIEEEDouble(data, 6);
		this.#=zL0TJcHA= = #=zrRXQAB8=.getNumberFormat(this.XFIndex);
		if (this.#=zL0TJcHA= == null)
		{
			this.#=zL0TJcHA= = #=zVuQRGxc1NEa1XCn8rHXZRUM=.#=zk9NtXlk=;
		}
	}

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x06000D67 RID: 3431 RVA: 0x00068D10 File Offset: 0x00066F10
	public double DoubleValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x06000D68 RID: 3432 RVA: 0x00068D18 File Offset: 0x00066F18
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x06000D69 RID: 3433 RVA: 0x00068D28 File Offset: 0x00066F28
	public new string Contents
	{
		get
		{
			return string.Format(this.#=zL0TJcHA=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zaiKvawI=);
		}
	}

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x06000D6A RID: 3434 RVA: 0x00068D4C File Offset: 0x00066F4C
	public new CellType Type
	{
		get
		{
			return CellType.NUMBER;
		}
	}

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x06000D6B RID: 3435 RVA: 0x00068D54 File Offset: 0x00066F54
	public NumberFormatInfo NumberFormat
	{
		get
		{
			return this.#=zL0TJcHA=;
		}
	}

	// Token: 0x040007B3 RID: 1971
	private double #=zaiKvawI=;

	// Token: 0x040007B4 RID: 1972
	private NumberFormatInfo #=zL0TJcHA=;

	// Token: 0x040007B5 RID: 1973
	private static NumberFormatInfo #=zk9NtXlk= = new NumberFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077254));
}
