﻿using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

// Token: 0x0200000B RID: 11
internal static class #=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=
{
	// Token: 0x06000029 RID: 41 RVA: 0x000030C0 File Offset: 0x000012C0
	private static bool #=z8lSYOa5ZWO90DN4zeoXwWp_EmMZw(bool #=zP11DSFQ=)
	{
		DateTime t = DateTime.Parse(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074914), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
		DateTime utcNow = DateTime.UtcNow;
		if (utcNow > t || utcNow < t.AddDays(-21.0))
		{
			string name = typeof(#=zYoOaqJq4B7Cs4WSCE_Ah3tPG2YcA6zoN2KBtT2_yjTwb).Assembly.GetName().Name;
			string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074881), name);
			return true;
		}
		return true;
	}

	// Token: 0x0600002A RID: 42 RVA: 0x0000313C File Offset: 0x0000133C
	[MethodImpl(MethodImplOptions.NoInlining)]
	private static bool #=zb$P3KtOgLxLFKlzf7asiArY=(bool #=zP11DSFQ=)
	{
		#=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zm8PpuDU= #=zm8PpuDU= = new #=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zm8PpuDU=();
		#=zm8PpuDU=.#=zm8PpuDU= = null;
		try
		{
			string text = AppDomain.CurrentDomain.GetData(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074619)) as string;
			if (text != null)
			{
				if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596))
				{
					#=zm8PpuDU=.#=zm8PpuDU= = new bool?(false);
				}
				else if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588))
				{
					#=zm8PpuDU=.#=zm8PpuDU= = new bool?(true);
				}
			}
		}
		catch
		{
		}
		bool flag = #=zm8PpuDU=.#=zm8PpuDU= != null;
		if (#=zm8PpuDU=.#=zm8PpuDU= == null)
		{
			try
			{
				if (#=q9bZ4AyVZ1cGKwsxDUgqtKb$_mVgn6a3GWxEJb$8ZT_Q=.#=zBA4iw4OubjH304G9CX5qwe77bsimBm1m7g==())
				{
					#=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zZIcwFNgKJMwNeZS_yg==(new ThreadStart(#=zm8PpuDU=.#=zbiIJrQnhxQmraicL1A==));
				}
				else
				{
					#=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zZIcwFNgKJMwNeZS_yg==(new ThreadStart(#=zm8PpuDU=.#=zROXTJ1zyJtmwvk7wwykwNwrgKb15k07n0tMvemc=));
				}
			}
			catch
			{
			}
		}
		if (!flag && #=zm8PpuDU=.#=zm8PpuDU= != null)
		{
			try
			{
				AppDomain.CurrentDomain.SetData(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074619), #=zm8PpuDU=.#=zm8PpuDU=.Value ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596));
			}
			catch
			{
			}
		}
		if (#=zm8PpuDU=.#=zm8PpuDU=.GetValueOrDefault())
		{
			return true;
		}
		if (#=zP11DSFQ=)
		{
			throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074580));
		}
		return false;
	}

	// Token: 0x0600002B RID: 43 RVA: 0x000032A4 File Offset: 0x000014A4
	private static void #=zZIcwFNgKJMwNeZS_yg==(ThreadStart #=zP11DSFQ=)
	{
		#=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zcltuPyw= #=zcltuPyw= = new #=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=zcltuPyw=();
		#=zcltuPyw=.#=zm8PpuDU= = #=zP11DSFQ=;
		#=zcltuPyw=.#=zcltuPyw= = null;
		Thread thread = new Thread(new ThreadStart(#=zcltuPyw=.#=zjQPctxvWZEvqCmmr3p2nmvs9FZ8twLxVdZe1QDM=));
		thread.SetApartmentState(ApartmentState.STA);
		thread.IsBackground = true;
		thread.Start();
		thread.Join();
		if (#=zcltuPyw=.#=zcltuPyw= != null)
		{
			throw #=zcltuPyw=.#=zcltuPyw=;
		}
	}

	// Token: 0x0600002C RID: 44 RVA: 0x00003300 File Offset: 0x00001500
	private static void #=zjzzVIhg5_Y5h9mCf6bJI0QpvHvpT()
	{
		try
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
		}
		catch
		{
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x0000332C File Offset: 0x0000152C
	public static bool #=zJxMSUas=()
	{
		return #=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=z8lSYOa5ZWO90DN4zeoXwWp_EmMZw(false);
	}

	// Token: 0x0600002E RID: 46 RVA: 0x00003334 File Offset: 0x00001534
	public static void #=zVnDyQrg=()
	{
		#=qRYoKwj2asIjvZ$eOAKxXq8vJOfNT0Msl_3I9cmMvBlw=.#=z8lSYOa5ZWO90DN4zeoXwWp_EmMZw(true);
	}

	// Token: 0x0200000C RID: 12
	private sealed class #=zcltuPyw=
	{
		// Token: 0x06000030 RID: 48 RVA: 0x00003348 File Offset: 0x00001548
		internal void #=zjQPctxvWZEvqCmmr3p2nmvs9FZ8twLxVdZe1QDM=()
		{
			try
			{
				this.#=zm8PpuDU=();
			}
			catch (Exception ex)
			{
				this.#=zcltuPyw= = ex;
			}
		}

		// Token: 0x04000012 RID: 18
		public ThreadStart #=zm8PpuDU=;

		// Token: 0x04000013 RID: 19
		public Exception #=zcltuPyw=;
	}

	// Token: 0x0200000D RID: 13
	private sealed class #=zm8PpuDU=
	{
		// Token: 0x06000032 RID: 50 RVA: 0x00003384 File Offset: 0x00001584
		internal void #=zbiIJrQnhxQmraicL1A==()
		{
			#=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA= #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA= = new #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075437), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075112), MessageBoxButtons.YesNo)
			{
				BackColor = Color.White
			};
			this.#=zm8PpuDU= = new bool?(#=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=.ShowDialog() == DialogResult.Yes);
		}

		// Token: 0x06000033 RID: 51 RVA: 0x000033CC File Offset: 0x000015CC
		internal void #=zROXTJ1zyJtmwvk7wwykwNwrgKb15k07n0tMvemc=()
		{
			#=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA= #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA= = new #=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075084), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909075112))
			{
				BackColor = Color.White
			};
			this.#=zm8PpuDU= = new bool?(#=qIEQTubz20uFYDLVwMuHe5IeRJjzvOTjZxGePLBj5PZA=.ShowDialog() == DialogResult.OK);
		}

		// Token: 0x04000014 RID: 20
		public bool? #=zm8PpuDU=;
	}
}
