﻿using System;
using System.Collections.Generic;

// Token: 0x020001BD RID: 445
internal sealed class #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ= : List<#=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==>
{
	// Token: 0x06000D4A RID: 3402 RVA: 0x000685E4 File Offset: 0x000667E4
	public #=zVBRbe2nsNjc8m8Rq3rGUzHkPhxxCu6RTuhtOsQS$HlV102LedTfbRFQ=(object[] #=z5fQvC8_vUB9$fhRr4g==)
	{
		if (#=z5fQvC8_vUB9$fhRr4g== != null)
		{
			for (int i = 0; i < #=z5fQvC8_vUB9$fhRr4g==.Length; i++)
			{
				base.Add(new #=z7pUit14ouwon$3HxX825M3sorV38skB30VlU2WDyeTJexnGj7g==((Dictionary<string, object>)#=z5fQvC8_vUB9$fhRr4g==[i]));
			}
		}
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x0006861C File Offset: 0x0006681C
	public bool #=zMVECo3Lv7Wwz(int #=zTH01DjU=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			if (base[i].#=ziXknzq7jSfAR0g9mRA==().Contains(#=zTH01DjU=))
			{
				return true;
			}
		}
		return false;
	}
}
