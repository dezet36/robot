﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x0200015E RID: 350
internal sealed class #=zM6WLjlWzdT_uUu6fjdjjyIl14zQg : CellValue, LabelCell, Cell
{
	// Token: 0x0600094B RID: 2379 RVA: 0x0004BA9C File Offset: 0x00049C9C
	public #=zM6WLjlWzdT_uUu6fjdjjyIl14zQg(Record #=zJce$Sys=, SSTRecord #=z_MuT_7c=, FormattingRecords #=zrRXQAB8=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		sbyte[] data = this.getRecord().Data;
		this.#=zSPLDPE4= = IntegerHelper.getInt(data[6], data[7], data[8], data[9]);
		this.#=zaiKvawI= = #=z_MuT_7c=.getString(this.#=zSPLDPE4=);
	}

	// Token: 0x17000021 RID: 33
	// (get) Token: 0x0600094C RID: 2380 RVA: 0x0004BAEC File Offset: 0x00049CEC
	public string StringValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600094D RID: 2381 RVA: 0x0004BAF4 File Offset: 0x00049CF4
	public override object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600094E RID: 2382 RVA: 0x0004BAFC File Offset: 0x00049CFC
	public new string Contents
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600094F RID: 2383 RVA: 0x0004BB04 File Offset: 0x00049D04
	public new CellType Type
	{
		get
		{
			return CellType.LABEL;
		}
	}

	// Token: 0x04000556 RID: 1366
	private int #=zSPLDPE4=;

	// Token: 0x04000557 RID: 1367
	private string #=zaiKvawI=;
}
