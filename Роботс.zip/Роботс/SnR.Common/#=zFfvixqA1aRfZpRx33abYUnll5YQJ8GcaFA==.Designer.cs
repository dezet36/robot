﻿// Token: 0x020000F4 RID: 244
internal sealed partial class #=zFfvixqA1aRfZpRx33abYUnll5YQJ8GcaFA== : global::System.Windows.Forms.Form
{
	// Token: 0x06000659 RID: 1625 RVA: 0x00032DA8 File Offset: 0x00030FA8
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040002A1 RID: 673
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
