﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x02000299 RID: 665
internal sealed class #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600144C RID: 5196 RVA: 0x0009AA6C File Offset: 0x00098C6C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zJHP2CeDqtLIN = #=zuJjQ1XU=.#=z5bKdgpPzNS6dKj$3ew==();
		this.#=z1pahAF0JqdFM8mgjDQ== = #=zuJjQ1XU=.#=zNnx4xxtx9xYwefJwdg==();
		this.#=zJF2YTStZkxdpBvijgveKmkY= = #=zuJjQ1XU=.#=zS96aE1JwlopY1ifRovTglSw=();
		this.#=zkTFDbK1WLBVA = #=zuJjQ1XU=.#=zuMXv8DnEbNVrFpFzVw==();
		this.#=znmyDeS0OacNZwPmJ6YZ$l6Y= = #=zuJjQ1XU=.#=zIQDLqtJxqgZWX88MoNdeTR0k5rMf();
		this.#=z6Bha1HM= = #=zuJjQ1XU=.#=z6Kl4FbeUhsIC();
		this.#=zY5j036GBN4QD = new #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE=(this.#=z8StzeqE=, #=zuJjQ1XU=);
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpBuildingsWithBoostersMode > 0)
		{
			this.#=zZKzdsPms7IDM = new #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=(this.#=z8StzeqE=, #=zuJjQ1XU=);
		}
	}

	// Token: 0x0600144D RID: 5197 RVA: 0x0009AAF8 File Offset: 0x00098CF8
	protected override void #=zvb5bnug=()
	{
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
		List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>();
		string text = null;
		int[] array = this.#=zl6$epITyHBhD();
		if (array != null && this.#=z6niKiywuMMRWkFiHmA==(list, array[0], array[1]))
		{
			this.#=zOFVlYK1873yhafrNjA==(list, array[0], array[1], out text);
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsCreateRequestAllianceHelpBuilding)
		{
			#=zPRLK9sNt9R08Bm3FFTUUQnDJd90ED_dUOT8CKoF6CPGyoYHjsbvTmDgFVWt4.#=zAJFRSgr_hfdThPi0GVYGg5k=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=znmyDeS0OacNZwPmJ6YZ$l6Y=, list);
		}
		TimeSpan timeSpan = TimeSpan.MaxValue;
		if (list.Count > 0)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpBuildingsWithBoostersMode > 0)
			{
				if (text != null)
				{
					base.#=zL1HTbwC75LO$(text);
				}
			}
			else
			{
				for (int i = 0; i < list.Count; i++)
				{
					#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = list[i];
					TimeSpan timeSpan2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().#=zwX6NTlM=(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1);
					if (timeSpan > timeSpan2)
					{
						timeSpan = timeSpan2;
					}
				}
			}
		}
		if (this.#=zZKzdsPms7IDM != null)
		{
			timeSpan = TimeSpan.FromSeconds((double)this.#=zZKzdsPms7IDM.#=z1$O687c1sZryMVkkgbGT0jU=(this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJHP2CeDqtLIN, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA));
		}
		if (timeSpan < this.#=zcDRV51Ut$7oP.RepeatDelayMax)
		{
			this.#=zcDRV51Ut$7oP.NextExecutionTime = DateTime.Now + timeSpan + TimeSpan.FromSeconds(180.0);
		}
	}

	// Token: 0x0600144E RID: 5198 RVA: 0x0009AC78 File Offset: 0x00098E78
	private int[] #=zl6$epITyHBhD()
	{
		int[] array = this.#=zJHP2CeDqtLIN;
		if (array[0] > 0)
		{
			return array;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977872), Array.Empty<object>());
		return null;
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x0009ACBC File Offset: 0x00098EBC
	private bool #=z6niKiywuMMRWkFiHmA==(List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=zb2AOmKLGF1WIvmLdXQ==, int #=zaSp61aWriE$O, int #=z3ZbF6j6S0LYX)
	{
		bool result = true;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuildBuildings)
		{
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
			bool flag = false;
			foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn in this.#=z1pahAF0JqdFM8mgjDQ==)
			{
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() != null && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)5)
				{
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2 = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z3TrxKisw7nyXMkOe5PjuvHk=(this.#=z8StzeqE=, this.#=zBsXSanI=, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUseStandardBuildingsTemplate);
				if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2 == null)
				{
					return result;
				}
				string text;
				#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zFY9ihF5o2BCdfI$ovxZVFdA=(this.#=z8StzeqE=, this.#=zBsXSanI=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2, this.#=z6Bha1HM=, this.#=z1pahAF0JqdFM8mgjDQ==, out text);
				if (!string.IsNullOrEmpty(text))
				{
					base.#=zL1HTbwC75LO$(text);
				}
				#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.AddRange(#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zWJ0mpojmDSDhbmHstMK5HK8=(this.#=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA));
			}
			if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count > 0)
			{
				int num = 0;
				using (List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>.Enumerator enumerator = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (AbstractType.IsFutureWorld(enumerator.Current.#=zq2bPTdY=().World))
						{
							num++;
						}
					}
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977800), new object[]
				{
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count,
					num
				});
				int num2 = 7;
				using (List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>.Enumerator enumerator = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 = enumerator.Current;
						if (#=zaSp61aWriE$O <= 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977481), Array.Empty<object>());
							string text2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
							if (!string.IsNullOrEmpty(text2))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977446), new object[]
								{
									text2
								});
								break;
							}
							break;
						}
						else if (!AbstractType.IsFutureWorld(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().World) || (this.#=zkTFDbK1WLBVA && #=z3ZbF6j6S0LYX > 0))
						{
							if (!this.#=z8StzeqE=.#=zkXsxKS4OL0sN(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().RequireResources(1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890), this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForBuilding))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977637), new object[]
								{
									#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().Name
								});
								this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().RequireResources(1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
							}
							else if (this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zpNxB4dFKltIiFxvtTnzTdPw=().#=zVcIxe_4=() == null || !this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zpNxB4dFKltIiFxvtTnzTdPw=().#=zVcIxe_4=().Contains(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFMDiymuLQ7_4()))
							{
								if (num2-- <= 0)
								{
									break;
								}
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977568), new object[]
								{
									#=zaSp61aWriE$O,
									#=z3ZbF6j6S0LYX
								});
								#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== #=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== = this.#=zY5j036GBN4QD.#=zAXaL0AbspmvA(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=(), 1, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForBuilding, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyResPackIfNoResForBuilding);
								if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq().Count > 0)
								{
									if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zfYEVQUtPgwVj0BONZA==().Count == 0)
									{
										string text3 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
										if (!string.IsNullOrEmpty(text3))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977254), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().Name,
												text3
											});
										}
									}
								}
								else
								{
									string text4;
									if (!flag)
									{
										text4 = this.#=zBsXSanI=.#=zQ3GmQEFE_q6Y(#=zO6457TajDDxDJIsKqS1bbzDMLckn2, false);
									}
									else
									{
										text4 = this.#=zBsXSanI=.#=zDqCpkITFJ_yR(#=zO6457TajDDxDJIsKqS1bbzDMLckn2, false);
									}
									if (text4.Length < 10000)
									{
										if (text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977182), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
											});
											if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1)
											{
												result = false;
											}
										}
										else if (text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977298), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
											});
											result = false;
											string text5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
											if (!string.IsNullOrEmpty(text5))
											{
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977446), new object[]
												{
													text5
												});
												break;
											}
											break;
										}
										else if (text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926365)) && text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926336)))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978998), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
											});
										}
										else if (text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908925958)))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979153), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
											});
										}
										else if (text4.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978798)))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978746), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
											});
										}
										else
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978916), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=(),
												text4
											});
											if (this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zpNxB4dFKltIiFxvtTnzTdPw=().#=zVcIxe_4=() == null)
											{
												this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zpNxB4dFKltIiFxvtTnzTdPw=().#=zKTAVzhk=(new List<int>());
											}
											this.#=z8StzeqE=.#=z2qORYNmMpSU7().#=zpNxB4dFKltIiFxvtTnzTdPw=().#=zVcIxe_4=().Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zFMDiymuLQ7_4());
										}
									}
									else
									{
										this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978849), new object[]
										{
											#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zkfqcY3I=()
										});
										result = false;
										string text6 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977890));
										if (!string.IsNullOrEmpty(text6))
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977446), new object[]
											{
												text6
											});
										}
										#=zb2AOmKLGF1WIvmLdXQ==.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn2);
										if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zb_kBM1dDbvBBDUYVkQ==().Count > 0)
										{
											break;
										}
										#=zaSp61aWriE$O--;
										if (AbstractType.IsFutureWorld(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zq2bPTdY=().World))
										{
											#=z3ZbF6j6S0LYX--;
										}
									}
								}
							}
						}
					}
					return result;
				}
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976900), Array.Empty<object>());
		}
		return result;
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x0009B4D4 File Offset: 0x000996D4
	private void #=zOFVlYK1873yhafrNjA==(List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=zb2AOmKLGF1WIvmLdXQ==, int #=zaSp61aWriE$O, int #=z3ZbF6j6S0LYX, out string #=zIapFsKF23kqB)
	{
		#=zIapFsKF23kqB = null;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsUpgradeBuildings)
		{
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingPlan != null)
			{
				#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zNWA0F5SlspWAQNy25zp0XNA=(this.#=z8StzeqE=, this.#=z1pahAF0JqdFM8mgjDQ==, this.#=zJF2YTStZkxdpBvijgveKmkY=, this.#=zkTFDbK1WLBVA);
				if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count > 0)
				{
					int num = 7;
					int i = 0;
					while (i < #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==[i];
						if (#=zaSp61aWriE$O <= 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977481), Array.Empty<object>());
							string text = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
							if (!string.IsNullOrEmpty(text))
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978551), new object[]
								{
									text
								});
								return;
							}
							return;
						}
						else
						{
							if (!AbstractType.IsFutureWorld(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().World) || (this.#=zkTFDbK1WLBVA && #=z3ZbF6j6S0LYX > 0))
							{
								if (!this.#=z8StzeqE=.#=zkXsxKS4OL0sN(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().RequireResources(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883), this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForBuilding))
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978486), new object[]
									{
										#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Name
									});
									this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().RequireResources(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
								}
								else
								{
									if (num-- <= 0)
									{
										return;
									}
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977568), new object[]
									{
										#=zaSp61aWriE$O,
										#=z3ZbF6j6S0LYX
									});
									#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== #=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw== = this.#=zY5j036GBN4QD.#=zAXaL0AbspmvA(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=(), #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsOpenResPackIfNoResForBuilding, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyResPackIfNoResForBuilding);
									if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq().Count > 0)
									{
										if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zfYEVQUtPgwVj0BONZA==().Count == 0)
										{
											string text2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SetResourcePriorityLock(#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zm0AyJfNfliKq(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
											if (!string.IsNullOrEmpty(text2))
											{
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978675), new object[]
												{
													#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().Name,
													text2
												});
											}
										}
									}
									else
									{
										this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978614), new object[]
										{
											#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=(),
											#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1
										});
										string text3 = this.#=zBsXSanI=.#=zDqCpkITFJ_yR(#=zO6457TajDDxDJIsKqS1bbzDMLckn, false);
										if (text3.Length > 10000)
										{
											this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978303), new object[]
											{
												#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=(),
												#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1
											});
											#=zb2AOmKLGF1WIvmLdXQ==.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
											#=zIapFsKF23kqB = text3;
											string text4 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
											if (!string.IsNullOrEmpty(text4))
											{
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978551), new object[]
												{
													text4
												});
											}
											if (#=zx5tRrMOIeeBgfVP2RQpyfSoK3B2RxGWIImtdvKtki2Ir3FLrUw==.#=zb_kBM1dDbvBBDUYVkQ==().Count > 0)
											{
												return;
											}
											#=zaSp61aWriE$O--;
											if (AbstractType.IsFutureWorld(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().World))
											{
												#=z3ZbF6j6S0LYX--;
											}
										}
										else
										{
											if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908946965)))
											{
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978240), new object[]
												{
													#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=(),
													#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1,
													text3
												});
												return;
											}
											if (text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908926209)))
											{
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978190), Array.Empty<object>());
											}
											else
											{
												if (!text3.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977340)))
												{
													this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980042), new object[]
													{
														#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=(),
														#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du() + 1,
														text3
													});
													return;
												}
												this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978344), Array.Empty<object>());
												string text5 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().ReleaseResourcePriorityLock(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908977883));
												if (!string.IsNullOrEmpty(text5))
												{
													this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908978551), new object[]
													{
														text5
													});
													return;
												}
												return;
											}
										}
									}
								}
							}
							i++;
						}
					}
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979981), Array.Empty<object>());
				return;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980136), Array.Empty<object>());
			}
		}
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x0009BA84 File Offset: 0x00099C84
	public static #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z3TrxKisw7nyXMkOe5PjuvHk=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, string #=znUBh3vsamsjU, bool #=zDimk7Z3epoHI)
	{
		if (string.IsNullOrWhiteSpace(#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords))
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979835), Array.Empty<object>());
		}
		else
		{
			int #=zhfS69jI= = 0;
			int #=zmWD8vxE= = 0;
			if (!#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zpFuBGU_pbGgs(#=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingsTemplateCoords, out #=zhfS69jI=, out #=zmWD8vxE=))
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979762), Array.Empty<object>());
			}
			else
			{
				#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zk55d778IdJE5fRurDw==(#=z8StzeqE=, #=zhfS69jI=, #=zmWD8vxE=, #=zBsXSanI=);
				if (#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== != null)
				{
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979906), Array.Empty<object>());
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=zlyCLPsuy3rpAPUSxS2tGO93GljjE8K1Hsw==(#=zBsXSanI=.#=zOpP1dT8=(#=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==.#=zMuFMjGQ=())).#=zNnx4xxtx9xYwefJwdg==();
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979854), new object[]
					{
						#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Count
					});
					return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==;
				}
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979960), Array.Empty<object>());
			}
		}
		if (#=zDimk7Z3epoHI)
		{
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2 = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
			#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
			ReadFileManager readFileManager = new ReadFileManager(FileResources.BuildingTempl, false);
			int num = 1;
			bool flag = GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=();
			while (readFileManager.NextLine())
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = new #=zO6457TajDDxDJIsKqS1bbzDMLckn();
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zbsxKkj4=(num++);
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zedb$WwBQsoJF(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071322), 0));
				#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zzQwUIEs=(#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zk$6QZNA=(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4()));
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() == null || !#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().#=zrmfzXr6EXxL0VG1ofw==() || #=z8StzeqE=.#=zYgvZuBwR$a1C() == 1)
				{
					string text;
					if (!flag)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zHD9M6IxBLboIezSsHQ==(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089994), 2));
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z2WdNm_CMtqBR6ukyUw==(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071019), 3));
						text = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979556), 4);
					}
					else
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zNzS1JlWmGn84_d6f9A==(readFileManager.ReadInt(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979537), 2));
						text = readFileManager.Read(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979556), 3);
					}
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zSIKgNs5Taw6RyqqQZw==(text != null && text.Trim().ToUpper().StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071019)));
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zQx7wBUdkq1I088Sg0Q==((#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=() != null && #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=().World > Worlds.Default) ? 1 : 0);
					#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFzGvi_S6jJhE(1);
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn);
				}
			}
			if (#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Count != 0)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979477), new object[]
				{
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Count
				});
				return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2;
			}
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979532), Array.Empty<object>());
		}
		return null;
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x0009BD5C File Offset: 0x00099F5C
	public static bool #=zpFuBGU_pbGgs(string #=zcpJ6bUA=, out int #=zQrqFdos=, out int #=zKFlJyLE=)
	{
		#=zQrqFdos= = 0;
		#=zKFlJyLE= = 0;
		bool result;
		try
		{
			string[] array = #=zcpJ6bUA=.Split(new char[]
			{
				' ',
				',',
				';',
				'\t'
			}, StringSplitOptions.RemoveEmptyEntries);
			if (array.Length != 2)
			{
				result = false;
			}
			else if (!int.TryParse(array[0], out #=zQrqFdos=))
			{
				result = false;
			}
			else if (!int.TryParse(array[1], out #=zKFlJyLE=))
			{
				result = false;
			}
			else
			{
				result = true;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x0009BDCC File Offset: 0x00099FCC
	public static void #=zFY9ihF5o2BCdfI$ovxZVFdA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1QvPqajXKeyc4qXXOw==, int #=zIgt60A6qs8ln, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z4xl2DHYn_KeXWgxDyQ==, out string #=zIapFsKF23kqB)
	{
		#=zIapFsKF23kqB = null;
		int num = #=zIgt60A6qs8ln - 4;
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.AddRange(#=z1QvPqajXKeyc4qXXOw==);
		#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ== comparer = new #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==((#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)1);
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Sort(comparer);
		#=z4xl2DHYn_KeXWgxDyQ==.Sort(comparer);
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2 = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		bool flag = GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=();
		bool flag2 = false;
		Dictionary<int, int> dictionary = #=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zFHkCBp9mRlgs();
		Dictionary<int, #=zO6457TajDDxDJIsKqS1bbzDMLckn> dictionary2 = new Dictionary<int, #=zO6457TajDDxDJIsKqS1bbzDMLckn>();
		for (int i = 0; i < #=z4xl2DHYn_KeXWgxDyQ==.Count; i++)
		{
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=z4xl2DHYn_KeXWgxDyQ==[i];
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn2 = null;
			foreach (#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn3 in #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==)
			{
				bool flag3 = false;
				if (#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4() == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4())
				{
					flag3 = true;
				}
				else if (dictionary.ContainsKey(#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4()) && dictionary[#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zFMDiymuLQ7_4()] == #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4())
				{
					flag3 = true;
				}
				if (flag3)
				{
					if (#=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zfTB62qendhk_VEy8rw==() < num && #=zO6457TajDDxDJIsKqS1bbzDMLckn3.#=zY0soxphmGIACbOHy6A==() < num)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn2 = #=zO6457TajDDxDJIsKqS1bbzDMLckn3;
					}
					#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Remove(#=zO6457TajDDxDJIsKqS1bbzDMLckn3);
					break;
				}
			}
			#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn4;
			if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2 == null)
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn4 = #=zO6457TajDDxDJIsKqS1bbzDMLckn;
			}
			else
			{
				#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn5 = new #=zO6457TajDDxDJIsKqS1bbzDMLckn();
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zbsxKkj4=(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zMuFMjGQ=());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zedb$WwBQsoJF(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zFMDiymuLQ7_4());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zzQwUIEs=(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zq2bPTdY=());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zFzGvi_S6jJhE(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zvnZc$RhG_1Du());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zSIKgNs5Taw6RyqqQZw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zAdM$oWHPKFC_gx1bYQ==());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zHD9M6IxBLboIezSsHQ==(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zfTB62qendhk_VEy8rw==());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=z2WdNm_CMtqBR6ukyUw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zY0soxphmGIACbOHy6A==());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zNzS1JlWmGn84_d6f9A==(#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zlSY2GGkBa6S3MkHuDQ==());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zQx7wBUdkq1I088Sg0Q==(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=z_ffm9$kcf9Y8EY_3cw==());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=z6zRvpPP_$ZVF(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zH9V7bObvvn_m());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn5.#=zdU1a9B$ueh_3(#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zGhmoNZChgwf8());
				#=zO6457TajDDxDJIsKqS1bbzDMLckn4 = #=zO6457TajDDxDJIsKqS1bbzDMLckn5;
				if (!flag2 && (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zAdM$oWHPKFC_gx1bYQ==() != #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zAdM$oWHPKFC_gx1bYQ==() || (flag ? (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zlSY2GGkBa6S3MkHuDQ==() != #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zlSY2GGkBa6S3MkHuDQ==()) : (#=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zfTB62qendhk_VEy8rw==() != #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zfTB62qendhk_VEy8rw==() || #=zO6457TajDDxDJIsKqS1bbzDMLckn2.#=zY0soxphmGIACbOHy6A==() != #=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zY0soxphmGIACbOHy6A==()))))
				{
					flag2 = true;
				}
			}
			if (flag)
			{
				int key = #=zO6457TajDDxDJIsKqS1bbzDMLckn4.#=z_ffm9$kcf9Y8EY_3cw==() * 1000 + #=zO6457TajDDxDJIsKqS1bbzDMLckn4.#=zlSY2GGkBa6S3MkHuDQ==();
				if (dictionary2.ContainsKey(key))
				{
					#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn6;
					#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn7;
					if (#=zO6457TajDDxDJIsKqS1bbzDMLckn2 == null)
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn6 = dictionary2[key];
						#=zO6457TajDDxDJIsKqS1bbzDMLckn7 = #=zO6457TajDDxDJIsKqS1bbzDMLckn4;
					}
					else
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn6 = #=zO6457TajDDxDJIsKqS1bbzDMLckn4;
						#=zO6457TajDDxDJIsKqS1bbzDMLckn7 = dictionary2[key];
					}
					#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979684), new object[]
					{
						#=zO6457TajDDxDJIsKqS1bbzDMLckn6.#=zkfqcY3I=(),
						#=zO6457TajDDxDJIsKqS1bbzDMLckn7.#=zkfqcY3I=()
					});
					return;
				}
				dictionary2.Add(key, #=zO6457TajDDxDJIsKqS1bbzDMLckn4);
			}
			#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2.Add(#=zO6457TajDDxDJIsKqS1bbzDMLckn4);
		}
		if (!flag2)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981097), Array.Empty<object>());
			return;
		}
		#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979433), Array.Empty<object>());
		string text = #=zBsXSanI=.#=zEi$_BOHBK5pT(#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==2, #=zIgt60A6qs8ln);
		if (text.Length > 10000)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979392), Array.Empty<object>());
			#=zIapFsKF23kqB = text;
			return;
		}
		#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zBsXSanI=.#=zI4J7zo5ZdOzg(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908979357), new object[]
		{
			JSONManager.Cut(text)
		});
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x0009C118 File Offset: 0x0009A318
	public static #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zWJ0mpojmDSDhbmHstMK5HK8=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zgaHWT15t0nqAUOKEyQ==, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zQ$0f3cGFLLozYKVuNw==, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zN5T7Ehu0JaZbhMTLbqHxSKw=, bool #=z_sNmetJrIPOP)
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ== comparer = new #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==((#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)1);
		#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.#=zi1hFJwI=();
		bool flag = GameApplicationData.#=zCivQpaj5leA$8Hv6Jej83uw=();
		for (int i = 0; i < #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.Count; i++)
		{
			#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z3LYRIu3eNKOftnrkHP2p3Mk= #=z3LYRIu3eNKOftnrkHP2p3Mk= = new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z3LYRIu3eNKOftnrkHP2p3Mk=();
			#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=zvRLj9WQ= = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==[i];
			if (#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=zvRLj9WQ=.#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)1 || (#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=zvRLj9WQ=.#=zgFVkd5ydGXNJ() == (#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.#=zOct_nIs=)4 && #=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuildHermes))
			{
				List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = #=zgaHWT15t0nqAUOKEyQ==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=zzt1b$pxyr5enJGAMIdN7Qo3A8i7$));
				List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = #=zQ$0f3cGFLLozYKVuNw==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=znAPuuctOd9bt5yu63nvv6F31PXQg));
				if (list.Count > list2.Count && #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=z3LYRIu3eNKOftnrkHP2p3Mk=.#=zvRLj9WQ=, 1, #=z8StzeqE=, #=zQ$0f3cGFLLozYKVuNw==, #=zN5T7Ehu0JaZbhMTLbqHxSKw=, #=z_sNmetJrIPOP))
				{
					list.Sort(comparer);
					list2.Sort(comparer);
					int j = list2.Count;
					while (j < list.Count)
					{
						#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z$Wqf929oYfjChSCK3j28uas= #=z$Wqf929oYfjChSCK3j28uas= = new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=z$Wqf929oYfjChSCK3j28uas=();
						#=z$Wqf929oYfjChSCK3j28uas=.#=zwTatGRABiBcSRHA9hg== = list[j];
						#=z$Wqf929oYfjChSCK3j28uas=.#=zwTatGRABiBcSRHA9hg==.#=zFzGvi_S6jJhE(0);
						if (!flag)
						{
							goto IL_147;
						}
						#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zO6457TajDDxDJIsKqS1bbzDMLckn = #=zQ$0f3cGFLLozYKVuNw==.Find(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=z$Wqf929oYfjChSCK3j28uas=.#=zuKB$6VlBoj2tVtlytz_peQ1pXJOv));
						if (#=zO6457TajDDxDJIsKqS1bbzDMLckn == null)
						{
							goto IL_147;
						}
						#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908981049), new object[]
						{
							#=z$Wqf929oYfjChSCK3j28uas=.#=zwTatGRABiBcSRHA9hg==.#=zkfqcY3I=(),
							#=zO6457TajDDxDJIsKqS1bbzDMLckn.#=zkfqcY3I=()
						});
						IL_154:
						j++;
						continue;
						IL_147:
						#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.Add(#=z$Wqf929oYfjChSCK3j28uas=.#=zwTatGRABiBcSRHA9hg==);
						goto IL_154;
					}
				}
			}
		}
		return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==;
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x0009C2A0 File Offset: 0x0009A4A0
	public static #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zNWA0F5SlspWAQNy25zp0XNA=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=zatMRdFUxBCRS1oul8g==, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zZ61w3rgvgY1YOZ4EoCDelTU=, bool #=z_sNmetJrIPOP)
	{
		#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== = new #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==();
		foreach (BuildingPlanFrame buildingPlanFrame in #=z8StzeqE=.#=zv2Kyu17YrGOC().BuildingPlan)
		{
			List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list = new List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>();
			using (List<#=zO6457TajDDxDJIsKqS1bbzDMLckn>.Enumerator enumerator2 = #=zatMRdFUxBCRS1oul8g==.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zDGOhd_SqjfKVkoyLDxVdoms= #=zDGOhd_SqjfKVkoyLDxVdoms= = new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zDGOhd_SqjfKVkoyLDxVdoms=();
					#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA== = enumerator2.Current;
					if (#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=() != null && (!AbstractType.IsFutureWorld(#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=().World) || #=z_sNmetJrIPOP) && buildingPlanFrame.Types.Contains(#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=().Id) && buildingPlanFrame.Level > #=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() && !#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=z5kpAZQpjT2b7() && #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zq2bPTdY=(), #=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zvnZc$RhG_1Du() + 1, #=z8StzeqE=, #=zatMRdFUxBCRS1oul8g==, #=zZ61w3rgvgY1YOZ4EoCDelTU=, #=z_sNmetJrIPOP))
					{
						bool flag = false;
						if (buildingPlanFrame.Number > 0)
						{
							List<#=zO6457TajDDxDJIsKqS1bbzDMLckn> list2 = #=zatMRdFUxBCRS1oul8g==.FindAll(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zNgsT_poBcrBYOKbGsabH2ZWRnvvd));
							list2.Sort(new Comparison<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zyDNvciU=.#=zLkw0NRU=.#=zuevnZKhy5JdMyqW_fHj9GEHOddkE0CJtzw==));
							for (int i = buildingPlanFrame.Number; i < list2.Count; i++)
							{
								if (list2[i].#=zMuFMjGQ=() == #=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==.#=zMuFMjGQ=())
								{
									flag = true;
									break;
								}
							}
						}
						if (!flag)
						{
							list.Add(#=zDGOhd_SqjfKVkoyLDxVdoms=.#=zUOCbBE7lBfRpv5tNuA==);
						}
					}
				}
			}
			if (list.Count > 0)
			{
				list.Sort(new #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==());
				#=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==.AddRange(list);
			}
		}
		return #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA==;
	}

	// Token: 0x06001456 RID: 5206 RVA: 0x0009C4A8 File Offset: 0x0009A6A8
	public static bool #=ziWUxnNfpZNMT(AbstractType #=zvRLj9WQ=, int #=z5w6HcG4=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=, bool #=zkTFDbK1WLBVA)
	{
		bool result = false;
		if (AbstractType.IsFutureWorld(#=zvRLj9WQ=.World) && !#=zkTFDbK1WLBVA)
		{
			return false;
		}
		if (#=z5w6HcG4= > 1)
		{
			if (#=zvRLj9WQ= is #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==)
			{
				List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==> list = (#=zvRLj9WQ= as #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==).#=z2fOvUeiaHzR6();
				if (list.Count >= #=z5w6HcG4=)
				{
					result = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(list[#=z5w6HcG4= - 1].#=z6Uo9D2yKen_Y(), #=z8StzeqE=, #=z1pahAF0JqdFM8mgjDQ==, #=zJF2YTStZkxdpBvijgveKmkY=);
				}
			}
		}
		else if (#=zvRLj9WQ= is #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==)
		{
			result = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT((#=zvRLj9WQ= as #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==).#=zdL$RcwsYpqvy(), #=z8StzeqE=, #=z1pahAF0JqdFM8mgjDQ==, #=zJF2YTStZkxdpBvijgveKmkY=);
		}
		else if (#=zvRLj9WQ= is AbstractNotupgradeableType)
		{
			result = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT((#=zvRLj9WQ= as AbstractNotupgradeableType).#=zdL$RcwsYpqvy(), #=z8StzeqE=, #=z1pahAF0JqdFM8mgjDQ==, #=zJF2YTStZkxdpBvijgveKmkY=);
		}
		else
		{
			result = #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=ziWUxnNfpZNMT(#=zvRLj9WQ=.#=zdL$RcwsYpqvy(), #=z8StzeqE=, #=z1pahAF0JqdFM8mgjDQ==, #=zJF2YTStZkxdpBvijgveKmkY=);
		}
		return result;
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x0009C554 File Offset: 0x0009A754
	public static bool #=ziWUxnNfpZNMT(List<#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==> #=zVL9JLxq$0pEZRzin7xAxrpg=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==, #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=)
	{
		for (int i = 0; i < #=zVL9JLxq$0pEZRzin7xAxrpg=.Count; i++)
		{
			#=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zT6r7w5H96Om0aarMsp4N2$4= #=zT6r7w5H96Om0aarMsp4N2$4= = new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zT6r7w5H96Om0aarMsp4N2$4=();
			#=zT6r7w5H96Om0aarMsp4N2$4=.#=zDMC3L_4= = #=zVL9JLxq$0pEZRzin7xAxrpg=[i];
			if (#=zT6r7w5H96Om0aarMsp4N2$4=.#=zDMC3L_4=.#=zbOVbkzM=() == (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=z3L1b1JM=)2)
			{
				if (#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zvnZc$RhG_1Du() < #=zT6r7w5H96Om0aarMsp4N2$4=.#=zDMC3L_4=.#=zvnZc$RhG_1Du())
				{
					return false;
				}
			}
			else if (#=zT6r7w5H96Om0aarMsp4N2$4=.#=zDMC3L_4=.#=zq2bPTdY=() != null)
			{
				Entities entity = #=zT6r7w5H96Om0aarMsp4N2$4=.#=zDMC3L_4=.#=zq2bPTdY=().Entity;
				if (entity != Entities.Building)
				{
					if (entity == Entities.Technology)
					{
						if (!#=zJF2YTStZkxdpBvijgveKmkY=.Exists(new Predicate<#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g==>(#=zT6r7w5H96Om0aarMsp4N2$4=.#=zZhXgbb7kwyIH6b1QtA==)))
						{
							return false;
						}
					}
				}
				else if (!#=z1pahAF0JqdFM8mgjDQ==.Exists(new Predicate<#=zO6457TajDDxDJIsKqS1bbzDMLckn>(#=zT6r7w5H96Om0aarMsp4N2$4=.#=zEeG3bTN1YU8uoQPJbg==)))
				{
					return false;
				}
			}
		}
		return true;
	}

	// Token: 0x04000B9C RID: 2972
	private int[] #=zJHP2CeDqtLIN;

	// Token: 0x04000B9D RID: 2973
	private #=z0rw_IRQkbhWty94934YWsvBETp6s0LyMZA== #=z1pahAF0JqdFM8mgjDQ==;

	// Token: 0x04000B9E RID: 2974
	private #=zvn7n2IbTSwW8w09PeIfOTdRq_VpOkcLsgg== #=zJF2YTStZkxdpBvijgveKmkY=;

	// Token: 0x04000B9F RID: 2975
	private bool #=zkTFDbK1WLBVA;

	// Token: 0x04000BA0 RID: 2976
	private List<#=zrxTIsDg4rk9lnID8_GvL_XCb4aIvy_dpEPgCLyUbTKSl> #=znmyDeS0OacNZwPmJ6YZ$l6Y=;

	// Token: 0x04000BA1 RID: 2977
	private int #=z6Bha1HM=;

	// Token: 0x04000BA2 RID: 2978
	private #=zqXsiO8TrLS8wpS1dHqomKrwM$1J3dSWxTMtTwIE= #=zY5j036GBN4QD;

	// Token: 0x04000BA3 RID: 2979
	private #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E= #=zZKzdsPms7IDM;

	// Token: 0x0200029A RID: 666
	private sealed class #=z$Wqf929oYfjChSCK3j28uas=
	{
		// Token: 0x06001459 RID: 5209 RVA: 0x0009C610 File Offset: 0x0009A810
		internal bool #=zuKB$6VlBoj2tVtlytz_peQ1pXJOv(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zlSY2GGkBa6S3MkHuDQ==() == this.#=zwTatGRABiBcSRHA9hg==.#=zlSY2GGkBa6S3MkHuDQ==();
		}

		// Token: 0x04000BA4 RID: 2980
		public #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zwTatGRABiBcSRHA9hg==;
	}

	// Token: 0x0200029B RID: 667
	private sealed class #=z3LYRIu3eNKOftnrkHP2p3Mk=
	{
		// Token: 0x0600145B RID: 5211 RVA: 0x0009C630 File Offset: 0x0009A830
		internal bool #=zzt1b$pxyr5enJGAMIdN7Qo3A8i7$(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zvRLj9WQ=.Id;
		}

		// Token: 0x0600145C RID: 5212 RVA: 0x0009C648 File Offset: 0x0009A848
		internal bool #=znAPuuctOd9bt5yu63nvv6F31PXQg(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zvRLj9WQ=.Id;
		}

		// Token: 0x04000BA5 RID: 2981
		public #=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zvRLj9WQ=;
	}

	// Token: 0x0200029C RID: 668
	private sealed class #=zDGOhd_SqjfKVkoyLDxVdoms=
	{
		// Token: 0x0600145E RID: 5214 RVA: 0x0009C668 File Offset: 0x0009A868
		internal bool #=zNgsT_poBcrBYOKbGsabH2ZWRnvvd(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zUOCbBE7lBfRpv5tNuA==.#=zFMDiymuLQ7_4();
		}

		// Token: 0x04000BA6 RID: 2982
		public #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zUOCbBE7lBfRpv5tNuA==;
	}

	// Token: 0x0200029D RID: 669
	private sealed class #=zT6r7w5H96Om0aarMsp4N2$4=
	{
		// Token: 0x06001460 RID: 5216 RVA: 0x0009C688 File Offset: 0x0009A888
		internal bool #=zEeG3bTN1YU8uoQPJbg==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4() == this.#=zDMC3L_4=.#=zFMDiymuLQ7_4() && #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=zDMC3L_4=.#=zvnZc$RhG_1Du();
		}

		// Token: 0x06001461 RID: 5217 RVA: 0x0009C6B8 File Offset: 0x0009A8B8
		internal bool #=zZhXgbb7kwyIH6b1QtA==(#=zK79dXyFHYVy2Iyv_VibeSWVXKBXL98RM7g== #=zQrqFdos=)
		{
			return #=zQrqFdos=.#=zq2bPTdY=().Id == this.#=zDMC3L_4=.#=zFMDiymuLQ7_4() && #=zQrqFdos=.#=zvnZc$RhG_1Du() >= this.#=zDMC3L_4=.#=zvnZc$RhG_1Du();
		}

		// Token: 0x04000BA7 RID: 2983
		public #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=zDMC3L_4=;
	}

	// Token: 0x0200029E RID: 670
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06001464 RID: 5220 RVA: 0x0009C700 File Offset: 0x0009A900
		internal int #=zuevnZKhy5JdMyqW_fHj9GEHOddkE0CJtzw==(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zm8PpuDU=, #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
			{
				#=zcltuPyw=.#=zvnZc$RhG_1Du().CompareTo(#=zm8PpuDU=.#=zvnZc$RhG_1Du()),
				#=zcltuPyw=.#=z5kpAZQpjT2b7().CompareTo(#=zm8PpuDU=.#=z5kpAZQpjT2b7()),
				#=zm8PpuDU=.#=zMuFMjGQ=().CompareTo(#=zcltuPyw=.#=zMuFMjGQ=())
			});
		}

		// Token: 0x04000BA8 RID: 2984
		public static readonly #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zyDNvciU= #=zLkw0NRU= = new #=zoAVb2NlRo3MZJhHj1IFxkBf8toNj8rK9w6OY_iA7dzLjOfY8RQ==.#=zyDNvciU=();

		// Token: 0x04000BA9 RID: 2985
		public static Comparison<#=zO6457TajDDxDJIsKqS1bbzDMLckn> #=z$rMXTGIaeSvhDZLrrA==;
	}
}
