﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020002A4 RID: 676
internal sealed class #=zp$20c7790ptYd19cWkfPpLYZ2IHCiL$hUIuDCJzKuEEiTgGUvOPTPaYHrpUN : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x0600148D RID: 5261 RVA: 0x0009C904 File Offset: 0x0009AB04
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg== = #=zuJjQ1XU=.#=zl_$OYx3PHSNAdh69QDm5gb0EdPFq59rdaQ8eMQoykJYqYTCfHg==();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x0009C92C File Offset: 0x0009AB2C
	protected override void #=zvb5bnug=()
	{
		string #=zsGkziQH4l9Fpi_2cMg==;
		if (this.#=zcDRV51Ut$7oP is #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==)
		{
			#=zsGkziQH4l9Fpi_2cMg== = (this.#=zcDRV51Ut$7oP as #=zJ$lcqXwcnhT_EctpSc9MYUQWHpk27kxARA==).#=zs6AfR9w58BN2();
		}
		else
		{
			#=zsGkziQH4l9Fpi_2cMg== = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().TroopsToSendAsBeacons;
		}
		#=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD = null;
		try
		{
			if (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==() <= 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879113), Array.Empty<object>());
			}
			else
			{
				#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zBsXSanI= = this.#=zBsXSanI=;
				int i = this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zO1FX6YkNZlqlvFZqJg==();
				object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(#=zBsXSanI=.#=zXTTYoqGLxWmVM2mBWQ==(i.ToString(), this.#=z8StzeqE=.#=zjV_wsuvJ0R_B())), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088037));
				int num = 0;
				if (array != null)
				{
					foreach (Dictionary<string, object> dictionary in array)
					{
						int num2 = JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0);
						if (dictionary.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)) && num2 != this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
						{
							#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = null;
							foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in this.#=zVG1EPv1OUDdyLeGHGQ==)
							{
								if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_() == num2 && (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0 || #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)1) && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5)
								{
									#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2;
									break;
								}
							}
							if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== == null)
							{
								Dictionary<string, object> dictionary2 = dictionary[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891)] as Dictionary<string, object>;
								int num3 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069827)]);
								int num4 = Convert.ToInt32(dictionary2[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069669)]);
								UnitSquadCollection unitSquadCollection;
								UnitSquadCollection unitSquadCollection2;
								int num5;
								#=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zwNOfqVYF7bWUWGMaPw==(#=zsGkziQH4l9Fpi_2cMg==, this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==, this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo, out unitSquadCollection, out unitSquadCollection2, out num5);
								if (num5 == 0)
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879349), Array.Empty<object>());
									break;
								}
								if (UnitSquadCollection.IsEmpty(new UnitSquadCollection[]
								{
									unitSquadCollection,
									unitSquadCollection2
								}))
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879290), Array.Empty<object>());
									break;
								}
								string text = this.#=zBsXSanI=.#=zWYvEC7HhMxBOcSI89TZRLg0=(num2, unitSquadCollection, unitSquadCollection2, 0);
								string text2 = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970383));
								string text3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879263), num3, num4);
								string text4 = #=zF9alE$xlsnmIXJmFl35C3EHgj$FT4evAOVBqJTWf678y.#=zy0P4$vJTLTxpa7WEqw==(unitSquadCollection, unitSquadCollection2, null);
								if (text.Length > 10000)
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958854), new object[]
									{
										text2,
										text3,
										text4
									});
									this.#=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==.RemoveUnits(unitSquadCollection);
									this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection2);
									num++;
								}
								else
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878687), new object[]
									{
										text2,
										text3,
										text4,
										text
									});
								}
							}
						}
					}
				}
				if (num > 0)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879246), new object[]
					{
						num
					});
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878943), Array.Empty<object>());
				}
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=zN_s5Z5A=);
		}
	}

	// Token: 0x04000BB6 RID: 2998
	private UnitSquadCollection #=z_QEvgUl5_ZdZeROLvq7fXvmjNdeOi2HfRJRFTLJSo_wf_JYWUg==;

	// Token: 0x04000BB7 RID: 2999
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x04000BB8 RID: 3000
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;
}
