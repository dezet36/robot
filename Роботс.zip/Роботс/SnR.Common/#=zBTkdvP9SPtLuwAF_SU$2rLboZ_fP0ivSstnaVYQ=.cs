﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000CA RID: 202
internal sealed class #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=
{
	// Token: 0x06000562 RID: 1378 RVA: 0x0002E178 File Offset: 0x0002C378
	public #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=(Dictionary<string, object> #=zOurwV8f4EneEUWOrkQ==)
	{
		this.#=zhzxR35UMHI9d(new Dictionary<string, int>());
		this.#=zC5_hvmNO69o$FmJ1Ow==(new Dictionary<string, int>());
		if (#=zOurwV8f4EneEUWOrkQ==.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601)))
		{
			this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			this.#=zM5z33liKcNKa(JSONManager.ExtractInt(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684), 0));
			this.#=zAbLVF6SEYRJ7(DateTime.MinValue);
			Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071601));
			this.#=zkA6yZXbNxRfm4zicxUuujUA=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0));
			this.#=znzS5nj2fiJwC(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
			Dictionary<string, object> dictionary2 = JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
			if (dictionary2 != null)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)1);
				using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary2.Keys.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string key = enumerator.Current;
						this.#=zbDGFGfruzAcP().Add(key, Convert.ToInt32(dictionary2[key]));
					}
					return;
				}
			}
			if (JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)) != null)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)2);
				return;
			}
			if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0) > 0)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)3);
				return;
			}
			this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)0);
			return;
		}
		else
		{
			this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			this.#=zM5z33liKcNKa(JSONManager.ExtractInt(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759), 0));
			this.#=zAbLVF6SEYRJ7(JSONManager.ExtractDate(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), false));
			Dictionary<string, object> dictionary3 = JSONManager.ExtractDictionary(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069684));
			this.#=zkA6yZXbNxRfm4zicxUuujUA=(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581), 0));
			this.#=znzS5nj2fiJwC(JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0));
			Dictionary<string, object> dictionary4 = JSONManager.ExtractDictionary(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
			if (dictionary4 != null)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)1);
				using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary4.Keys.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						string key2 = enumerator.Current;
						this.#=zbDGFGfruzAcP().Add(key2, Convert.ToInt32(dictionary4[key2]));
					}
					goto IL_279;
				}
			}
			if (JSONManager.ExtractDictionary(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069875)) != null)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)2);
			}
			else if (JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0) > 0)
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)3);
			}
			else
			{
				this.#=ztlKB8mFOaBW3((#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU)0);
			}
			IL_279:
			Dictionary<string, object> dictionary5 = JSONManager.ExtractDictionary(JSONManager.ExtractDictionary(#=zOurwV8f4EneEUWOrkQ==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
			if (dictionary5 != null)
			{
				foreach (string key3 in dictionary5.Keys)
				{
					this.#=zTyB2FIk29LkISjxh3Q==().Add(key3, Convert.ToInt32(dictionary5[key3]));
				}
			}
		}
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x0002E498 File Offset: 0x0002C698
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x0002E4A0 File Offset: 0x0002C6A0
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x0002E4AC File Offset: 0x0002C6AC
	public int #=zVVorJLug3m2L()
	{
		return this.#=zfA6$cc8wPlWau8OwIw==;
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x0002E4B4 File Offset: 0x0002C6B4
	public void #=zM5z33liKcNKa(int #=z$Ib9gYQ=)
	{
		this.#=zfA6$cc8wPlWau8OwIw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x0002E4C0 File Offset: 0x0002C6C0
	public DateTime #=z8zMIXPnMfdS3()
	{
		return this.#=zS3yjjlt9YCy_4g1RkA==;
	}

	// Token: 0x06000568 RID: 1384 RVA: 0x0002E4C8 File Offset: 0x0002C6C8
	public void #=zAbLVF6SEYRJ7(DateTime #=z$Ib9gYQ=)
	{
		this.#=zS3yjjlt9YCy_4g1RkA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x0002E4D4 File Offset: 0x0002C6D4
	public #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU #=zr6MSgaIVrD1E()
	{
		return this.#=zN_6WauQKjCf1IaKNUw==;
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x0002E4DC File Offset: 0x0002C6DC
	public void #=ztlKB8mFOaBW3(#=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU #=z$Ib9gYQ=)
	{
		this.#=zN_6WauQKjCf1IaKNUw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x0002E4E8 File Offset: 0x0002C6E8
	public int #=zokCzXrV0ersD0W_QcNKZ29M=()
	{
		return this.#=zzx1s2vaeDJ6aWCQQDfgqBH$UXZ81;
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x0002E4F0 File Offset: 0x0002C6F0
	public void #=zkA6yZXbNxRfm4zicxUuujUA=(int #=z$Ib9gYQ=)
	{
		this.#=zzx1s2vaeDJ6aWCQQDfgqBH$UXZ81 = #=z$Ib9gYQ=;
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x0002E4FC File Offset: 0x0002C6FC
	public Dictionary<string, int> #=zbDGFGfruzAcP()
	{
		return this.#=za$y_zDeWhqLcIbbIU1XVY1Q=;
	}

	// Token: 0x0600056E RID: 1390 RVA: 0x0002E504 File Offset: 0x0002C704
	public void #=zhzxR35UMHI9d(Dictionary<string, int> #=z$Ib9gYQ=)
	{
		this.#=za$y_zDeWhqLcIbbIU1XVY1Q= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600056F RID: 1391 RVA: 0x0002E510 File Offset: 0x0002C710
	public Dictionary<string, int> #=zTyB2FIk29LkISjxh3Q==()
	{
		return this.#=zojAIvpJSbx2GViFSNg4oqNw=;
	}

	// Token: 0x06000570 RID: 1392 RVA: 0x0002E518 File Offset: 0x0002C718
	public void #=zC5_hvmNO69o$FmJ1Ow==(Dictionary<string, int> #=z$Ib9gYQ=)
	{
		this.#=zojAIvpJSbx2GViFSNg4oqNw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x0002E524 File Offset: 0x0002C724
	public int #=zcJnW9C5gbycS()
	{
		return this.#=zmRhfLrysyZ9l_i7fT07aPYE=;
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x0002E52C File Offset: 0x0002C72C
	public void #=znzS5nj2fiJwC(int #=z$Ib9gYQ=)
	{
		this.#=zmRhfLrysyZ9l_i7fT07aPYE= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000222 RID: 546
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000223 RID: 547
	private int #=zfA6$cc8wPlWau8OwIw==;

	// Token: 0x04000224 RID: 548
	private DateTime #=zS3yjjlt9YCy_4g1RkA==;

	// Token: 0x04000225 RID: 549
	private #=zBTkdvP9SPtLuwAF_SU$2rLboZ_fP0ivSstnaVYQ=.#=z9bFOfjXkPMVU #=zN_6WauQKjCf1IaKNUw==;

	// Token: 0x04000226 RID: 550
	private int #=zzx1s2vaeDJ6aWCQQDfgqBH$UXZ81;

	// Token: 0x04000227 RID: 551
	private Dictionary<string, int> #=za$y_zDeWhqLcIbbIU1XVY1Q=;

	// Token: 0x04000228 RID: 552
	private Dictionary<string, int> #=zojAIvpJSbx2GViFSNg4oqNw=;

	// Token: 0x04000229 RID: 553
	private int #=zmRhfLrysyZ9l_i7fT07aPYE=;

	// Token: 0x020000CB RID: 203
	public enum #=z9bFOfjXkPMVU
	{

	}
}
