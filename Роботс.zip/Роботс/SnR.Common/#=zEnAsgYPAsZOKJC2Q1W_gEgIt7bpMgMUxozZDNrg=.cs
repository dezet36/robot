﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000EA RID: 234
internal sealed class #=zEnAsgYPAsZOKJC2Q1W_gEgIt7bpMgMUxozZDNrg= : List<#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=>
{
	// Token: 0x06000620 RID: 1568 RVA: 0x00031B70 File Offset: 0x0002FD70
	public #=zEnAsgYPAsZOKJC2Q1W_gEgIt7bpMgMUxozZDNrg=(Dictionary<string, object> #=zp3uk2zqaqGa9FPbo$NQrmMI5PhiT)
	{
		if (#=zp3uk2zqaqGa9FPbo$NQrmMI5PhiT == null)
		{
			return;
		}
		this.#=zPcnh48WblVvc$0LydQ0Ss5F2Zndd(JSONManager.GetInt(#=zp3uk2zqaqGa9FPbo$NQrmMI5PhiT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060655), 0));
		object[] array = JSONManager.GetArray(#=zp3uk2zqaqGa9FPbo$NQrmMI5PhiT, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060635));
		if (array == null)
		{
			return;
		}
		foreach (Dictionary<string, object> dictionary in array)
		{
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= = new #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=();
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zbsxKkj4=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zIHYXCI8=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069966), 0));
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zEay$jMoC7T_kh1L51A==(new List<int>());
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zmlRGa1CBJDmM(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), false));
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=ztwk8eMODHmxTjLHNTw==(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), false));
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=2 = #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=;
			object[] array2 = JSONManager.ExtractArray(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
			if (array2 != null)
			{
				for (int j = 0; j < array2.Length; j++)
				{
					#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=2.#=zmEXh9AenN64_bRhjgQ==().Add(Convert.ToInt32(array2[j]));
				}
			}
			base.Add(#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=2);
		}
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x00031C80 File Offset: 0x0002FE80
	public int #=zU8Ih$XGWPaBB6guu3uHs3e0wKKyh()
	{
		return this.#=zDp7hNVWPCaTLeEayOH$h_L9VSEcYl5$jetWhZT4=;
	}

	// Token: 0x06000622 RID: 1570 RVA: 0x00031C88 File Offset: 0x0002FE88
	public void #=zPcnh48WblVvc$0LydQ0Ss5F2Zndd(int #=z$Ib9gYQ=)
	{
		this.#=zDp7hNVWPCaTLeEayOH$h_L9VSEcYl5$jetWhZT4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000623 RID: 1571 RVA: 0x00031C94 File Offset: 0x0002FE94
	public #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=zSwuC41Ya81kR()
	{
		for (int i = 0; i < base.Count; i++)
		{
			#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk= = base[i];
			if (#=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=ziPEmQdbHj7fJ() < DateTime.Now && #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=.#=zOPOUMr79bBnqNvgahw==() - TimeSpan.FromMinutes(1.0) > DateTime.Now)
			{
				return #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=;
			}
		}
		return null;
	}

	// Token: 0x04000289 RID: 649
	private int #=zDp7hNVWPCaTLeEayOH$h_L9VSEcYl5$jetWhZT4=;
}
