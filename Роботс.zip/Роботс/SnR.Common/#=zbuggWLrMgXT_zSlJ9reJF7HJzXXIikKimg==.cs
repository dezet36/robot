﻿using System;
using System.Collections.Generic;

// Token: 0x0200020E RID: 526
internal sealed class #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==
{
	// Token: 0x06001018 RID: 4120 RVA: 0x0007BFC0 File Offset: 0x0007A1C0
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06001019 RID: 4121 RVA: 0x0007BFC8 File Offset: 0x0007A1C8
	public void #=zzQwUIEs=(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600101A RID: 4122 RVA: 0x0007BFD4 File Offset: 0x0007A1D4
	public Dictionary<int, int> #=zo4gR$B4ZVFdYTDxEaw==()
	{
		return this.#=z_g8OI1DYAIAFvM8xc1$c8U8=;
	}

	// Token: 0x0600101B RID: 4123 RVA: 0x0007BFDC File Offset: 0x0007A1DC
	public void #=z9cbTL9Fte7ios6efTw==(Dictionary<int, int> #=z$Ib9gYQ=)
	{
		this.#=z_g8OI1DYAIAFvM8xc1$c8U8= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600101C RID: 4124 RVA: 0x0007BFE8 File Offset: 0x0007A1E8
	public bool #=zTiHFkB7xQT2C(int #=zrjon8Kw=)
	{
		return this.#=zo4gR$B4ZVFdYTDxEaw==().ContainsKey(#=zrjon8Kw=) && this.#=zo4gR$B4ZVFdYTDxEaw==()[#=zrjon8Kw=] > 0;
	}

	// Token: 0x0600101D RID: 4125 RVA: 0x0007C00C File Offset: 0x0007A20C
	public bool #=z_ePdViDI7p1r5Oy9Eg==()
	{
		for (int i = 0; i < this.#=zq2bPTdY=().#=z6ZIr13K_h_d4(); i++)
		{
			if (!this.#=zTiHFkB7xQT2C(i))
			{
				return false;
			}
		}
		return true;
	}

	// Token: 0x040008E0 RID: 2272
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040008E1 RID: 2273
	private Dictionary<int, int> #=z_g8OI1DYAIAFvM8xc1$c8U8=;
}
