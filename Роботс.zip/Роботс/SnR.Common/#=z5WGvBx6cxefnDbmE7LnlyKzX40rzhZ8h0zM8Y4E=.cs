﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Units;

// Token: 0x02000072 RID: 114
internal sealed class #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E= : #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw=, #=zjHJS68VLpllSFNj0KyzmfEMBmAe2nRLOOpekFX8=
{
	// Token: 0x06000332 RID: 818 RVA: 0x0001E068 File Offset: 0x0001C268
	public #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=()
	{
		this.#=zaEPuOTSAdGJD(new List<UnitType.Functions>());
		this.#=zQdtWXXpldI3d(new List<UnitType.Classes>());
		this.#=zZiRzMZtSPNEd(new List<UnitType.Modifications>());
		this.#=zDn3d_$$N3duv(new List<UnitType.Resources>());
		this.#=zH9cSjnN7o2BE(new List<int>());
	}

	// Token: 0x06000333 RID: 819 RVA: 0x0001E0A8 File Offset: 0x0001C2A8
	public List<UnitType.Functions> #=zUVM9FAFk5XA$()
	{
		return this.#=zou7GMUdkhvmoQrMpFQ==;
	}

	// Token: 0x06000334 RID: 820 RVA: 0x0001E0B0 File Offset: 0x0001C2B0
	public void #=zaEPuOTSAdGJD(List<UnitType.Functions> #=z$Ib9gYQ=)
	{
		this.#=zou7GMUdkhvmoQrMpFQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000335 RID: 821 RVA: 0x0001E0BC File Offset: 0x0001C2BC
	public List<UnitType.Classes> #=zPE_3V$ajAABC()
	{
		return this.#=ztRZzT$W3tQfkO6LWJQ==;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x0001E0C4 File Offset: 0x0001C2C4
	public void #=zQdtWXXpldI3d(List<UnitType.Classes> #=z$Ib9gYQ=)
	{
		this.#=ztRZzT$W3tQfkO6LWJQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000337 RID: 823 RVA: 0x0001E0D0 File Offset: 0x0001C2D0
	public List<UnitType.Modifications> #=zyW3m1RMTX3PA()
	{
		return this.#=zr78SD4At9mqaU5PrAg==;
	}

	// Token: 0x06000338 RID: 824 RVA: 0x0001E0D8 File Offset: 0x0001C2D8
	public void #=zZiRzMZtSPNEd(List<UnitType.Modifications> #=z$Ib9gYQ=)
	{
		this.#=zr78SD4At9mqaU5PrAg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000339 RID: 825 RVA: 0x0001E0E4 File Offset: 0x0001C2E4
	public List<UnitType.Resources> #=z_tcU3ov4mZ9V()
	{
		return this.#=za_GZrBlIijB72VhfHg==;
	}

	// Token: 0x0600033A RID: 826 RVA: 0x0001E0EC File Offset: 0x0001C2EC
	public void #=zDn3d_$$N3duv(List<UnitType.Resources> #=z$Ib9gYQ=)
	{
		this.#=za_GZrBlIijB72VhfHg== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600033B RID: 827 RVA: 0x0001E0F8 File Offset: 0x0001C2F8
	public List<int> #=zZd7ZjBPjoeVB()
	{
		return this.#=zbe1uEbiu0fr8LMksHQ==;
	}

	// Token: 0x0600033C RID: 828 RVA: 0x0001E100 File Offset: 0x0001C300
	public void #=zH9cSjnN7o2BE(List<int> #=z$Ib9gYQ=)
	{
		this.#=zbe1uEbiu0fr8LMksHQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600033D RID: 829 RVA: 0x0001E10C File Offset: 0x0001C30C
	public bool #=zQLl7KKs=(UnitSquad #=zCtbXRq2SiURL)
	{
		return this.#=zQLl7KKs=(#=zCtbXRq2SiURL.Type);
	}

	// Token: 0x0600033E RID: 830 RVA: 0x0001E11C File Offset: 0x0001C31C
	public bool #=zQLl7KKs=(UnitType #=zvRLj9WQ=)
	{
		if ((#=zvRLj9WQ=.Category & UnitType.Categories.p_Unusual) == UnitType.Categories.p_Unusual)
		{
			return this.#=zZd7ZjBPjoeVB().Contains(#=zvRLj9WQ=.Id);
		}
		if (#=zvRLj9WQ=.Function == UnitType.Functions.OffenseAndDefense)
		{
			if (!this.#=zUVM9FAFk5XA$().Contains(UnitType.Functions.Offence) && !this.#=zUVM9FAFk5XA$().Contains(UnitType.Functions.Defence))
			{
				return false;
			}
		}
		else if (!this.#=zUVM9FAFk5XA$().Contains(#=zvRLj9WQ=.Function))
		{
			return false;
		}
		if (!this.#=zPE_3V$ajAABC().Contains(#=zvRLj9WQ=.Class))
		{
			return false;
		}
		UnitType.Modifications item;
		UnitType.Resources resources;
		if (#=zvRLj9WQ=.IsStrategic)
		{
			item = (UnitType.Modifications)5;
			resources = ((#=zvRLj9WQ=.Resource == UnitType.Resources.Drachmas) ? UnitType.Resources.Resource : #=zvRLj9WQ=.Resource);
		}
		else if (#=zvRLj9WQ=.World == Worlds.Elisium)
		{
			item = (UnitType.Modifications)6;
			resources = ((#=zvRLj9WQ=.Resource == UnitType.Resources.Future) ? UnitType.Resources.Resource : #=zvRLj9WQ=.Resource);
		}
		else
		{
			item = #=zvRLj9WQ=.Modification;
			resources = #=zvRLj9WQ=.Resource;
		}
		if (!this.#=zyW3m1RMTX3PA().Contains(item))
		{
			return false;
		}
		if (resources == UnitType.Resources.ResourceTitanium || resources == UnitType.Resources.ResourceUranium)
		{
			resources = UnitType.Resources.Resource;
		}
		return this.#=z_tcU3ov4mZ9V().Contains(resources);
	}

	// Token: 0x0600033F RID: 831 RVA: 0x0001E21C File Offset: 0x0001C41C
	public static List<UnitType.Functions> #=z_rf_fmg1gw6t()
	{
		return new List<UnitType.Functions>
		{
			UnitType.Functions.Offence,
			UnitType.Functions.Defence,
			UnitType.Functions.Scouting
		};
	}

	// Token: 0x06000340 RID: 832 RVA: 0x0001E238 File Offset: 0x0001C438
	public static List<UnitType.Classes> #=zaagZ41IDziU3()
	{
		return new List<UnitType.Classes>
		{
			UnitType.Classes.LightInfantry,
			UnitType.Classes.HeavyInfantry,
			UnitType.Classes.Phalanx,
			UnitType.Classes.Cavalry
		};
	}

	// Token: 0x06000341 RID: 833 RVA: 0x0001E25C File Offset: 0x0001C45C
	public static List<UnitType.Modifications> #=zpEtRtsHhMi0C()
	{
		List<UnitType.Modifications> list = new List<UnitType.Modifications>();
		list.Add(UnitType.Modifications.Ordinary);
		if (GameApplicationData.#=zU4SoYfB3bJLfD4zFc9Klv$_bydkg())
		{
			list.Add(UnitType.Modifications.Elite);
		}
		list.Add(UnitType.Modifications.Mutated);
		list.Add(UnitType.Modifications.Imperial);
		list.Add((UnitType.Modifications)5);
		if (GameApplicationData.#=zFp3v5CbiiaCH())
		{
			list.Add((UnitType.Modifications)6);
		}
		return list;
	}

	// Token: 0x06000342 RID: 834 RVA: 0x0001E2A8 File Offset: 0x0001C4A8
	public static List<UnitType.Resources> #=zAyS369CRLvZu()
	{
		return new List<UnitType.Resources>
		{
			UnitType.Resources.Resource,
			UnitType.Resources.Denaries,
			UnitType.Resources.Special
		};
	}

	// Token: 0x06000343 RID: 835 RVA: 0x0001E2C4 File Offset: 0x0001C4C4
	public static List<int> #=zAw1EIzRREaKz_nggig==()
	{
		List<int> list = new List<int>();
		UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
		for (int i = 0; i < unitTypeCollection.Count; i++)
		{
			if ((unitTypeCollection[i].Category & UnitType.Categories.p_Unusual) == UnitType.Categories.p_Unusual)
			{
				list.Add(unitTypeCollection[i].Id);
			}
		}
		return list;
	}

	// Token: 0x06000344 RID: 836 RVA: 0x0001E31C File Offset: 0x0001C51C
	public static bool #=z9HJwcKInmGpn(string #=zdPovgAA=)
	{
		return !string.IsNullOrEmpty(#=zdPovgAA=) && #=zdPovgAA=[0] == 'R';
	}

	// Token: 0x06000345 RID: 837 RVA: 0x0001E334 File Offset: 0x0001C534
	public static bool #=zzfuUJztcOt9$(string #=zdPovgAA=)
	{
		return #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z9HJwcKInmGpn(#=zdPovgAA=) || #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=z84ZpbGPv0D55(#=zdPovgAA=);
	}

	// Token: 0x06000346 RID: 838 RVA: 0x0001E348 File Offset: 0x0001C548
	public static #=zAsRzPry48BjtolHKhzt1GU8wis45j4Y6VUx3abw= #=zRNqnDZfnmn0P(string #=zB2DSYM9PsWD8)
	{
		if (#=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=.#=z84ZpbGPv0D55(#=zB2DSYM9PsWD8))
		{
			return new #=zl898UBEBUPR4uJokqSds9TOlveJu1n2YWtMSwTk=(#=zB2DSYM9PsWD8);
		}
		return #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zcEIrFP4=(#=zB2DSYM9PsWD8);
	}

	// Token: 0x06000347 RID: 839 RVA: 0x0001E360 File Offset: 0x0001C560
	public static #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E= #=zcEIrFP4=(string #=zB2DSYM9PsWD8)
	{
		#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E= #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E= = new #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=();
		if (!#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z9HJwcKInmGpn(#=zB2DSYM9PsWD8))
		{
			return null;
		}
		string[] array = #=zB2DSYM9PsWD8.Substring(1).Split(new char[]
		{
			'/'
		});
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].Length > 0)
			{
				string[] array2 = array[i].Substring(1).Split(new char[]
				{
					','
				}, StringSplitOptions.RemoveEmptyEntries);
				char c = array[i][0];
				if (c <= 'F')
				{
					if (c != 'C')
					{
						if (c == 'F')
						{
							if (array2.Length == 1 && array2[0] == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026829))
							{
								#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zUVM9FAFk5XA$().AddRange(#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z_rf_fmg1gw6t());
							}
							else
							{
								for (int j = 0; j < array2.Length; j++)
								{
									#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zUVM9FAFk5XA$().Add((UnitType.Functions)Convert.ToInt32(array2[j]));
								}
							}
						}
					}
					else if (array2.Length == 1 && array2[0] == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026829))
					{
						#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zPE_3V$ajAABC().AddRange(#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zaagZ41IDziU3());
					}
					else
					{
						for (int k = 0; k < array2.Length; k++)
						{
							#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zPE_3V$ajAABC().Add((UnitType.Classes)Convert.ToInt32(array2[k]));
						}
					}
				}
				else if (c != 'M')
				{
					if (c != 'S')
					{
						if (c == 'U')
						{
							for (int l = 0; l < array2.Length; l++)
							{
								#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zZd7ZjBPjoeVB().Add(Convert.ToInt32(array2[l]));
							}
						}
					}
					else if (array2.Length == 1 && array2[0] == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026829))
					{
						#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z_tcU3ov4mZ9V().AddRange(#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAyS369CRLvZu());
					}
					else
					{
						for (int m = 0; m < array2.Length; m++)
						{
							#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z_tcU3ov4mZ9V().Add((UnitType.Resources)Convert.ToInt32(array2[m]));
						}
					}
				}
				else if (array2.Length == 1 && array2[0] == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909026829))
				{
					#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zyW3m1RMTX3PA().AddRange(#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zpEtRtsHhMi0C());
				}
				else
				{
					for (int n = 0; n < array2.Length; n++)
					{
						#=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zyW3m1RMTX3PA().Add((UnitType.Modifications)Convert.ToInt32(array2[n]));
					}
				}
			}
		}
		return #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=;
	}

	// Token: 0x06000348 RID: 840 RVA: 0x0001E59C File Offset: 0x0001C79C
	public override string ToString()
	{
		StringBuilder stringBuilder = new StringBuilder(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070846));
		stringBuilder.Append('F');
		if (this.#=zUVM9FAFk5XA$().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z_rf_fmg1gw6t().Count)
		{
			stringBuilder.Append('A');
		}
		else
		{
			for (int i = 0; i < this.#=zUVM9FAFk5XA$().Count; i++)
			{
				if (i > 0)
				{
					stringBuilder.Append(',');
				}
				stringBuilder.Append((int)this.#=zUVM9FAFk5XA$()[i]);
			}
		}
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876741));
		if (this.#=zPE_3V$ajAABC().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zaagZ41IDziU3().Count)
		{
			stringBuilder.Append('A');
		}
		else
		{
			for (int j = 0; j < this.#=zPE_3V$ajAABC().Count; j++)
			{
				if (j > 0)
				{
					stringBuilder.Append(',');
				}
				stringBuilder.Append((int)this.#=zPE_3V$ajAABC()[j]);
			}
		}
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876722));
		if (this.#=zyW3m1RMTX3PA().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zpEtRtsHhMi0C().Count)
		{
			stringBuilder.Append('A');
		}
		else
		{
			for (int k = 0; k < this.#=zyW3m1RMTX3PA().Count; k++)
			{
				if (k > 0)
				{
					stringBuilder.Append(',');
				}
				stringBuilder.Append((int)this.#=zyW3m1RMTX3PA()[k]);
			}
		}
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876715));
		if (this.#=z_tcU3ov4mZ9V().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAyS369CRLvZu().Count)
		{
			stringBuilder.Append('A');
		}
		else
		{
			for (int l = 0; l < this.#=z_tcU3ov4mZ9V().Count; l++)
			{
				if (l > 0)
				{
					stringBuilder.Append(',');
				}
				stringBuilder.Append((int)this.#=z_tcU3ov4mZ9V()[l]);
			}
		}
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876704));
		for (int m = 0; m < this.#=zZd7ZjBPjoeVB().Count; m++)
		{
			if (m > 0)
			{
				stringBuilder.Append(',');
			}
			stringBuilder.Append(this.#=zZd7ZjBPjoeVB()[m]);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000349 RID: 841 RVA: 0x0001E7B0 File Offset: 0x0001C9B0
	public string ToStringLabels()
	{
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg== = new #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077031));
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876790), Array.Empty<object>());
		if (this.#=zUVM9FAFk5XA$().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=z_rf_fmg1gw6t().Count)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060931), Array.Empty<object>());
		}
		else if (this.#=zUVM9FAFk5XA$().Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876697), Array.Empty<object>());
		}
		else
		{
			for (int i = 0; i < this.#=zUVM9FAFk5XA$().Count; i++)
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ((i == this.#=zUVM9FAFk5XA$().Count - 1) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002), UnitType.GetName(this.#=zUVM9FAFk5XA$()[i]), Array.Empty<object>());
			}
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876772), Array.Empty<object>());
		if (this.#=zPE_3V$ajAABC().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zaagZ41IDziU3().Count)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060931), Array.Empty<object>());
		}
		else if (this.#=zPE_3V$ajAABC().Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876697), Array.Empty<object>());
		}
		else
		{
			for (int j = 0; j < this.#=zPE_3V$ajAABC().Count; j++)
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ((j == this.#=zPE_3V$ajAABC().Count - 1) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002), UnitType.GetName(this.#=zPE_3V$ajAABC()[j]), Array.Empty<object>());
			}
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909022901), Array.Empty<object>());
		if (this.#=zyW3m1RMTX3PA().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zpEtRtsHhMi0C().Count)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060931), Array.Empty<object>());
		}
		else if (this.#=zyW3m1RMTX3PA().Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876697), Array.Empty<object>());
		}
		else
		{
			for (int k = 0; k < this.#=zyW3m1RMTX3PA().Count; k++)
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ((k == this.#=zyW3m1RMTX3PA().Count - 1) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002), UnitType.GetName(this.#=zyW3m1RMTX3PA()[k]), Array.Empty<object>());
			}
		}
		#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909015185), Array.Empty<object>());
		if (this.#=z_tcU3ov4mZ9V().Count == #=z5WGvBx6cxefnDbmE7LnlyKzX40rzhZ8h0zM8Y4E=.#=zAyS369CRLvZu().Count)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060931), Array.Empty<object>());
		}
		else if (this.#=z_tcU3ov4mZ9V().Count == 0)
		{
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908876697), Array.Empty<object>());
		}
		else
		{
			for (int l = 0; l < this.#=z_tcU3ov4mZ9V().Count; l++)
			{
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ((l == this.#=z_tcU3ov4mZ9V().Count - 1) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909057931) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002), UnitType.GetName(this.#=z_tcU3ov4mZ9V()[l]), Array.Empty<object>());
			}
		}
		if (this.#=zZd7ZjBPjoeVB().Count > 0)
		{
			UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
			#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zSodKUHcR$yPQ(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909016943), Array.Empty<object>());
			for (int m = 0; m < this.#=zZd7ZjBPjoeVB().Count; m++)
			{
				UnitType unitType = unitTypeCollection.Find(this.#=zZd7ZjBPjoeVB()[m]);
				#=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.#=zfJXgQf0BnVvU((m > 0) ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090002) : string.Empty, (unitType != null) ? unitType.Name : this.#=zZd7ZjBPjoeVB()[m].ToString(), Array.Empty<object>());
			}
		}
		return #=zvrm1ya7_bQ_xhakYr7AfDtjKJskFnpf$SkQWVUWgGBfF87D_Eg==.ToString();
	}

	// Token: 0x04000127 RID: 295
	private List<UnitType.Functions> #=zou7GMUdkhvmoQrMpFQ==;

	// Token: 0x04000128 RID: 296
	private List<UnitType.Classes> #=ztRZzT$W3tQfkO6LWJQ==;

	// Token: 0x04000129 RID: 297
	private List<UnitType.Modifications> #=zr78SD4At9mqaU5PrAg==;

	// Token: 0x0400012A RID: 298
	private List<UnitType.Resources> #=za_GZrBlIijB72VhfHg==;

	// Token: 0x0400012B RID: 299
	private List<int> #=zbe1uEbiu0fr8LMksHQ==;
}
