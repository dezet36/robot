﻿using System;
using System.Collections.Generic;
using System.Threading;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200003C RID: 60
internal sealed class #=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==
{
	// Token: 0x060001E8 RID: 488 RVA: 0x00012B78 File Offset: 0x00010D78
	public static void #=zLNBY$dFeyK95()
	{
		if (DateTime.Now >= #=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zqCdBoz3jo0J$T31T7g==)
		{
			object obj = #=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zSV4$mlFB34WM;
			lock (obj)
			{
				#=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zqCdBoz3jo0J$T31T7g== = DateTime.Now + TimeSpan.FromMinutes(60.0);
				new Thread(new ThreadStart(#=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zpyVL5hn1NFVC)).Start();
			}
		}
	}

	// Token: 0x060001E9 RID: 489 RVA: 0x00012BF8 File Offset: 0x00010DF8
	public static void #=zpyVL5hn1NFVC()
	{
		object obj = #=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zSV4$mlFB34WM;
		lock (obj)
		{
			try
			{
				string text = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zp8YKVzmTER2u();
				if (!string.IsNullOrEmpty(text))
				{
					object[] array = JSONManager.ExtractArray((Dictionary<string, object>)JSONManager.DeserializeData(text), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958));
					if (array.Length != 0)
					{
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
						if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
						{
							Dictionary<string, object> dictionary = new Dictionary<string, object>();
							for (int i = 0; i < array.Length; i++)
							{
								try
								{
									RemoteTask remoteTask = new RemoteTask((Dictionary<string, object>)array[i]);
									List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==> list = new List<#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==>();
									foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== in #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zOdy_aU_tk1aY())
									{
										if (remoteTask.GameUserIds.Contains(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zCCBXDJ5n_DGghKXXmA==()))
										{
											foreach (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== in #=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==.#=zol80P7TKoihZ())
											{
												if (#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zYgvZuBwR$a1C() == remoteTask.ServerIndex)
												{
													list.Add(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
												}
											}
										}
									}
									if (list.Count > 1)
									{
										object[] array2 = new object[list.Count];
										MasterTask #=zwcZwAIGe3vUR = #=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zXqyemJ7PVoRw(remoteTask.UsersTask);
										for (int j = 0; j < list.Count; j++)
										{
											#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2 = list[j];
											Task #=zcTyyNys=;
											if (remoteTask.UsersTask is #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==)
											{
												#=zcTyyNys= = new #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==(#=zwcZwAIGe3vUR);
											}
											else
											{
												#=zcTyyNys= = Task.#=zErO$$v4=(remoteTask.UsersTask.Serialize());
											}
											#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zeR3QFrc=(#=zcTyyNys=);
											#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2);
											array2[j] = #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==2.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==();
										}
										dictionary[remoteTask.Id] = array2;
									}
									else if (list.Count == 1)
									{
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3 = list[0];
										#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3.#=zeR3QFrc=(remoteTask.UsersTask);
										#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3);
										dictionary[remoteTask.Id] = new object[]
										{
											#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==3.#=zh5Q$jgycqA15().#=zCCBXDJ5n_DGghKXXmA==()
										};
									}
								}
								catch (Exception #=zN_s5Z5A=)
								{
									#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
								}
							}
							if (dictionary.Count > 0)
							{
								#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zLAsqqvHbp_SVIBZG6A==(dictionary);
							}
						}
					}
				}
			}
			catch (Exception #=zN_s5Z5A=2)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=2);
			}
		}
	}

	// Token: 0x060001EA RID: 490 RVA: 0x00012EB0 File Offset: 0x000110B0
	public static void #=zt1VrUkwJ$Xqa(List<RemoteTask> #=zJu1XQuZg59ao)
	{
		if (#=zJu1XQuZg59ao.Count > 0)
		{
			object obj = #=z1LKwK$6XsiBlAiUodOwQYV9qjOPIbtYH7g==.#=zSV4$mlFB34WM;
			lock (obj)
			{
				object[] array = new object[#=zJu1XQuZg59ao.Count];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = #=zJu1XQuZg59ao[i].Serialize();
				}
				#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zt1VrUkwJ$Xqa(new Dictionary<string, object>
				{
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
						array
					}
				});
			}
		}
	}

	// Token: 0x0400006F RID: 111
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x04000070 RID: 112
	private static DateTime #=zqCdBoz3jo0J$T31T7g== = DateTime.MinValue;
}
