﻿using System;
using Microsoft.Win32;

// Token: 0x020001AC RID: 428
internal sealed class #=zU9IkKF6Qct$jGu2oqZQbiz_dZ$p_
{
	// Token: 0x06000CEE RID: 3310 RVA: 0x000670B0 File Offset: 0x000652B0
	internal static string #=z4Mfgap0RU15D()
	{
		bool flag;
		return #=zU9IkKF6Qct$jGu2oqZQbiz_dZ$p_.#=z4Mfgap0RU15D(out flag);
	}

	// Token: 0x06000CEF RID: 3311 RVA: 0x000670C4 File Offset: 0x000652C4
	internal static string #=z4Mfgap0RU15D(out bool #=zR7jmq$8=)
	{
		string result;
		using (RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry32).OpenSubKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064845)))
		{
			result = #=zU9IkKF6Qct$jGu2oqZQbiz_dZ$p_.#=z2xDZdYlqbOZcwfL_cg==(Convert.ToInt32(registryKey.GetValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064523))), out #=zR7jmq$8=);
		}
		return result;
	}

	// Token: 0x06000CF0 RID: 3312 RVA: 0x0006712C File Offset: 0x0006532C
	private static string #=z2xDZdYlqbOZcwfL_cg==(int #=z6PAPV8k=, out bool #=zR7jmq$8=)
	{
		#=zR7jmq$8= = false;
		if (#=z6PAPV8k= >= 528040)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064517);
		}
		if (#=z6PAPV8k= >= 461808)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064499);
		}
		if (#=z6PAPV8k= >= 461308)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064495);
		}
		if (#=z6PAPV8k= >= 460798)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064475);
		}
		if (#=z6PAPV8k= >= 394802)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064465);
		}
		if (#=z6PAPV8k= >= 394254)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064461);
		}
		if (#=z6PAPV8k= >= 393295)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064697);
		}
		if (#=z6PAPV8k= >= 393273)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064695);
		}
		if (#=z6PAPV8k= >= 379893)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064672);
		}
		if (#=z6PAPV8k= >= 378675)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064668);
		}
		if (#=z6PAPV8k= >= 378389)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064648);
		}
		#=zR7jmq$8= = true;
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064646);
	}
}
