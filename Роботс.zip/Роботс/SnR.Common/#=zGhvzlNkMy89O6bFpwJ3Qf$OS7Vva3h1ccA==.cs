﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;

// Token: 0x02000100 RID: 256
internal sealed partial class #=zGhvzlNkMy89O6bFpwJ3Qf$OS7Vva3h1ccA== : Form
{
	// Token: 0x06000699 RID: 1689 RVA: 0x00033E18 File Offset: 0x00032018
	public #=zGhvzlNkMy89O6bFpwJ3Qf$OS7Vva3h1ccA==(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf)
	{
		this.#=zeJZsbgM= = #=zJUGTDqUtMnBf;
		this.#=zgpzgXirqPT5_();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x00033E40 File Offset: 0x00032040
	private void #=zEGW15DLHHQmbJW9X1g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			this.#=zzSMRk$PPcuzoo_T5fw==.Text = this.#=zCUN19c9t5CcN(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=z0vCXuEah_ZW$(this.#=zF0iDtirpI3GWYY5ZZA==.Text, null, true));
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message + Environment.NewLine + Environment.NewLine + ex.StackTrace);
		}
	}

	// Token: 0x0600069B RID: 1691 RVA: 0x00033EA8 File Offset: 0x000320A8
	private void #=zXKIXOFoVpWQntmQzmL80yRRr2oMd(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			this.#=zzSMRk$PPcuzoo_T5fw==.Text = this.#=zCUN19c9t5CcN(#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zdKHhrpikgPKG(this.#=zF0iDtirpI3GWYY5ZZA==.Text, this.#=zeJZsbgM=));
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message + Environment.NewLine + Environment.NewLine + ex.StackTrace);
		}
	}

	// Token: 0x0600069C RID: 1692 RVA: 0x00033F14 File Offset: 0x00032114
	private void #=zl$VHbYfNRvgbAINp4g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = null;
		try
		{
			if (this.#=zeJZsbgM= == null)
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102337));
			}
			#=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zeJZsbgM=);
			try
			{
				this.#=zzSMRk$PPcuzoo_T5fw==.Text = this.#=zCUN19c9t5CcN(JSONManager.SerializeData(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zuq1FOz8SJbyH()) + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064410));
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=zeJZsbgM=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (object obj in #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers.Keys)
			{
				string text = (string)obj;
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102575), text, #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers[text], Environment.NewLine);
			}
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102556), #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=ziywd55xwWd2r(), Environment.NewLine);
			this.#=zF0iDtirpI3GWYY5ZZA==.Text = stringBuilder.ToString();
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zeJZsbgM=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=2);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=2));
		}
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x000340C0 File Offset: 0x000322C0
	public string #=zCUN19c9t5CcN(string #=zvq0$kQI=)
	{
		string text = this.#=z31x9m5lKp07YnIe2zw==.Text;
		if (string.IsNullOrWhiteSpace(text))
		{
			return #=zvq0$kQI=;
		}
		return JSONManager.FormatJSON(#=zvq0$kQI=, text);
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x000340EC File Offset: 0x000322EC
	private void #=zNZqR9s9eR3kj8rgKBmgq0mI=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = null;
		try
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zeJZsbgM=);
			try
			{
				this.#=zzSMRk$PPcuzoo_T5fw==.Text = this.#=zCUN19c9t5CcN(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zeoI_JM$qmO3Jp7VRURuP390=());
			}
			catch (Exception #=zN_s5Z5A=)
			{
				this.#=zeJZsbgM=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=);
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
			}
			StringBuilder stringBuilder = new StringBuilder();
			foreach (object obj in #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers.Keys)
			{
				string text = (string)obj;
				stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102575), text, #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=zJgvbqC5Kxvxk().Headers[text], Environment.NewLine);
			}
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102556), #=z0fnp28WHdHHIomvTDkV56EngzJg.#=z2fpO5C$YR90A().#=ziywd55xwWd2r(), Environment.NewLine);
			this.#=zF0iDtirpI3GWYY5ZZA==.Text = stringBuilder.ToString();
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			this.#=zeJZsbgM=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zI4J7zo5ZdOzg(), #=zN_s5Z5A=2);
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=2));
		}
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x00034248 File Offset: 0x00032448
	private void #=z5KtDH10gMTDy5t7D8g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=zzSMRk$PPcuzoo_T5fw==.Text = this.#=zCUN19c9t5CcN(this.#=zF0iDtirpI3GWYY5ZZA==.Text);
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x00034268 File Offset: 0x00032468
	private void #=z$tNjd_nK7mzGxZRFhw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			if (string.IsNullOrEmpty(this.#=z0V$nmb3XQqjfRQahnA==.Text) && string.IsNullOrEmpty(this.#=znLNrCV$UyhVcDTkCGw==.Text))
			{
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102537));
			}
			else
			{
				object data = JSONManager.GetData(this.#=zIHup4hf8F5mH.Text);
				StringBuilder stringBuilder = new StringBuilder();
				this.#=zmczXnC2vmqD$(data, this.#=znLNrCV$UyhVcDTkCGw==.Text, this.#=z0V$nmb3XQqjfRQahnA==.Text, this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.Checked, new List<string>(), stringBuilder);
				this.#=zIHup4hf8F5mH.Text = stringBuilder.ToString();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zIHup4hf8F5mH.Text = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
		}
	}

	// Token: 0x060006A1 RID: 1697 RVA: 0x00034328 File Offset: 0x00032528
	private void #=zmczXnC2vmqD$(object #=zJ5GWysk=, string #=zaODZuSQ=, string #=zdBD5ZXA=, bool #=zjc6inYs=, List<string> #=zf1DEGiA=, StringBuilder #=zrhvCoyA=)
	{
		if (#=zJ5GWysk= is Dictionary<string, object>)
		{
			Dictionary<string, object> dictionary = (Dictionary<string, object>)#=zJ5GWysk=;
			using (Dictionary<string, object>.KeyCollection.Enumerator enumerator = dictionary.Keys.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					string text = enumerator.Current;
					List<string> list = new List<string>();
					list.AddRange(#=zf1DEGiA=);
					list.Add(text);
					this.#=zmczXnC2vmqD$(dictionary[text], #=zaODZuSQ=, #=zdBD5ZXA=, #=zjc6inYs=, list, #=zrhvCoyA=);
				}
				return;
			}
		}
		if (#=zJ5GWysk= is object[])
		{
			object[] array = (object[])#=zJ5GWysk=;
			for (int i = 0; i < array.Length; i++)
			{
				List<string> list2 = new List<string>();
				list2.AddRange(#=zf1DEGiA=);
				list2.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051197) + i.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077473));
				this.#=zmczXnC2vmqD$(array[i], #=zaODZuSQ=, #=zdBD5ZXA=, #=zjc6inYs=, list2, #=zrhvCoyA=);
			}
			return;
		}
		string text2 = #=zJ5GWysk=.ToString();
		if ((string.IsNullOrEmpty(#=zaODZuSQ=) || #=zf1DEGiA=[#=zf1DEGiA=.Count - 1] == #=zaODZuSQ=) && (string.IsNullOrEmpty(#=zdBD5ZXA=) || text2 == #=zdBD5ZXA= || (!#=zjc6inYs= && text2.Contains(#=zdBD5ZXA=))))
		{
			foreach (string value in #=zf1DEGiA=)
			{
				#=zrhvCoyA=.Append(value);
				#=zrhvCoyA=.Append('/');
			}
			#=zrhvCoyA=.Append(Environment.NewLine);
		}
	}

	// Token: 0x060006A2 RID: 1698 RVA: 0x000344BC File Offset: 0x000326BC
	private void #=z4DwQ4q8JW4kTcYEU4g==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			this.#=zIHup4hf8F5mH.Text = JSONManager.FormatJSON(this.#=zIHup4hf8F5mH.Text, this.#=znLNrCV$UyhVcDTkCGw==.Text);
		}
		catch (Exception #=zN_s5Z5A=)
		{
			this.#=zIHup4hf8F5mH.Text = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=);
		}
	}

	// Token: 0x060006A3 RID: 1699 RVA: 0x00034518 File Offset: 0x00032718
	private void #=zwtOInYEOegviJialUw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			this.#=zUq8qakitAT0T.Value = JSONManager.DecodeTime(this.#=zQ_Eu0invnmQn.Text, this.#=zAbTyfXq9F_iMxy$gvA==.Checked);
			this.#=zHTlwsOilVXij4r019w==.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102497), new object[]
			{
				Environment.NewLine,
				TimeZone.CurrentTimeZone.StandardName,
				TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).TotalHours,
				TimeZone.CurrentTimeZone.GetUtcOffset(this.#=zUq8qakitAT0T.Value).TotalHours
			});
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x060006A4 RID: 1700 RVA: 0x000345E4 File Offset: 0x000327E4
	private void #=zg5Q3Q61NeGRmOh34Hw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			this.#=zQ_Eu0invnmQn.Text = JSONManager.EncodeTime(this.#=zUq8qakitAT0T.Value, this.#=zAbTyfXq9F_iMxy$gvA==.Checked);
			this.#=zHTlwsOilVXij4r019w==.Text = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102497), new object[]
			{
				Environment.NewLine,
				TimeZone.CurrentTimeZone.StandardName,
				TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).TotalHours,
				TimeZone.CurrentTimeZone.GetUtcOffset(this.#=zUq8qakitAT0T.Value).TotalHours
			});
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message);
		}
	}

	// Token: 0x060006A5 RID: 1701 RVA: 0x000346B0 File Offset: 0x000328B0
	private void #=zCl3BduT5v5zdFrTqdg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102170), MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102164), Array.Empty<object>()) != DialogResult.OK)
		{
			return;
		}
		try
		{
			#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zeJZsbgM=;
			string[] array = Clipboard.GetText().Split(new string[]
			{
				Environment.NewLine
			}, StringSplitOptions.None);
			bool flag = false;
			foreach (string text in array)
			{
				if (string.IsNullOrWhiteSpace(text))
				{
					flag = true;
				}
				else if (!flag && text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074)))
				{
					string text2 = text.Substring(0, text.IndexOf(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077074))).Trim();
					string text3 = text.Substring(text2.Length + 1).Trim();
					if (!(text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102114)))
					{
						if (!(text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102103)))
						{
							if (!(text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102331)))
							{
								if (text2 == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102317))
								{
									#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zchs2LGrZFGl4(text3);
								}
							}
							else
							{
								#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=zPzFoe9Yoa4Jh(text3);
							}
						}
						else
						{
							#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zh5Q$jgycqA15().#=z9l$gimR8dkJhDCQJAw==(text3.Replace(GameApplicationData.#=z0Jq5DpdI2gB$(), string.Empty));
						}
					}
					else
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zgi8txbeKnNhG(text3);
					}
				}
			}
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102294));
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x060006A6 RID: 1702 RVA: 0x00034848 File Offset: 0x00032A48
	private void #=zySGVds6UXTl1s8RD3A==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=z0fnp28WHdHHIomvTDkV56EngzJg = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(this.#=zeJZsbgM=);
		this.#=zYTPe7rYLIURVmE0yzg==.Text = JSONManager.FormatJSON(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zeoI_JM$qmO3Jp7VRURuP390=());
		#=z0fnp28WHdHHIomvTDkV56EngzJg6.#=zdKHhrpikgPKG(this.#=zH4_Sd4jXFaos.Text, this.#=zeJZsbgM=);
		this.#=zRa59PRf4Hxg$2zukRw==.Text = JSONManager.FormatJSON(#=z0fnp28WHdHHIomvTDkV56EngzJg.#=zeoI_JM$qmO3Jp7VRURuP390=());
	}

	// Token: 0x060006A7 RID: 1703 RVA: 0x000348A4 File Offset: 0x00032AA4
	private void #=zHtxIfLJq_6UzEhQHyPnb8Mg=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			new #=z4D$ECR7YZvHgryv3YAxotD7_$U_0aXMDnCbugdhZRhWriT4OLg==(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(new #=zYx6ZIQtt5u4F4RrJpPGOqI0El7NKEvSrUw==(new #=zkO3OALYBGNilukMF5u7j7K3EsP5C(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074588)), new ProxyInfo(ProxyTypes.NoProxy, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102270), 0)), true, this.#=zeJZsbgM=), this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Text).#=zPp7Q6VI=(true);
			this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Text = this.#=zeJZsbgM=.#=zDZReNK0=().#=zdz_5DLjhAG09Q78wOA==().#=zKjxpeZXEbqufx39jhxAXfMk=(#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.#=zi1hFJwI=());
		}
		catch (Exception ex)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(ex.Message + Environment.NewLine + Environment.NewLine + ex.StackTrace);
		}
	}

	// Token: 0x060006A8 RID: 1704 RVA: 0x00034954 File Offset: 0x00032B54
	private void #=z9C$hQsITgl7ymOTc2Q==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z$ctZ69FG4Rp6.#=zPC48eGFZAOd4(this.#=zdx$vkZ5vTREZ.Text);
	}

	// Token: 0x060006A9 RID: 1705 RVA: 0x0003496C File Offset: 0x00032B6C
	private void #=zSvGXSB2zc9QU2e_PAg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		try
		{
			object value = this.#=z$ctZ69FG4Rp6.#=zx0uresqDtFaL(this.#=zdx$vkZ5vTREZ.Text);
			this.#=z1xh4O4rr9zys.Text = Convert.ToString(value);
		}
		catch (Exception ex)
		{
			this.#=z1xh4O4rr9zys.Text = ex.Message;
		}
	}

	// Token: 0x060006AA RID: 1706 RVA: 0x000349C8 File Offset: 0x00032BC8
	private void #=zr6sYKzVyXNh$Oq0Jgg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z$ctZ69FG4Rp6.#=z5GlD5yOMF10k(null);
	}

	// Token: 0x060006AB RID: 1707 RVA: 0x000349D8 File Offset: 0x00032BD8
	private void #=zKzGs8s7CxHD89XyYeA==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z$ctZ69FG4Rp6.#=zO9hEXZnX7tvi();
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x000349E8 File Offset: 0x00032BE8
	private void #=zpHSy4J1il67bK5DQqw==(object #=zP95I7AY=, FormClosingEventArgs #=z4Q$h3mE=)
	{
		this.#=z$ctZ69FG4Rp6.Dispose();
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x000349F8 File Offset: 0x00032BF8
	private void #=zU_VeaYb0kTFJmEQF5mjOrto=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA==.#=zBBdtOIwHrS6fN4w4iA==(this.#=zIHup4hf8F5mH.Text);
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x00034A2C File Offset: 0x00032C2C
	private void #=zgpzgXirqPT5_()
	{
		this.#=z9bBc6uTdnfHYaew$UvMQizU= = new TabControl();
		this.#=zb0dg7H$SUesy = new TabPage();
		this.#=zSkJFO7wY3x1SlT7atw== = new SplitContainer();
		this.#=zF0iDtirpI3GWYY5ZZA== = new TextBox();
		this.#=zP8Wyt4o_jMJuXyiteA== = new SplitContainer();
		this.#=zPPXBB3BV4IZC = new Button();
		this.#=zU7ODVJwxeL_gnyC7uA== = new Button();
		this.#=zLlwnrJwELmO0iqfMkGsOm$8= = new Button();
		this.#=zXLUTjdX0sB6$IbitQQ== = new Button();
		this.#=z31x9m5lKp07YnIe2zw== = new TextBox();
		this.#=za3Qez0HfYeNU = new Button();
		this.#=zzSMRk$PPcuzoo_T5fw== = new TextBox();
		this.#=znMm9YPgxt_OP = new TabPage();
		this.#=zuXYlF5T9nG4_ = new Label();
		this.#=zFNS55jhY3HNA = new Label();
		this.#=zMO$Hw0rSwIDzNrspyg== = new Button();
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I= = new CheckBox();
		this.#=z8O3DKSuP63ohiEaHGg== = new Button();
		this.#=zDWV$wnwpiC4f = new Button();
		this.#=zIHup4hf8F5mH = new TextBox();
		this.#=znLNrCV$UyhVcDTkCGw== = new TextBox();
		this.#=z0V$nmb3XQqjfRQahnA== = new TextBox();
		this.#=zezx_HtkB$LCq = new TabPage();
		this.#=zAbTyfXq9F_iMxy$gvA== = new CheckBox();
		this.#=zHTlwsOilVXij4r019w== = new Label();
		this.#=zrebyNXWxE6iP = new Button();
		this.#=zRBY4n6Y9xJyf = new Button();
		this.#=zQ_Eu0invnmQn = new TextBox();
		this.#=zUq8qakitAT0T = new DateTimePicker();
		this.#=zEYh4AmR2eXtIxy9k$g== = new TabPage();
		this.#=zHz4hpM3FzRjU = new Button();
		this.#=zRa59PRf4Hxg$2zukRw== = new TextBox();
		this.#=zYTPe7rYLIURVmE0yzg== = new TextBox();
		this.#=zH4_Sd4jXFaos = new TextBox();
		this.#=zVBsL45$iFGnJcXxMAQ== = new TabPage();
		this.#=zikzcbGe_63kIoyWO$A== = new Button();
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE= = new TextBox();
		this.#=zpPLP_sjnQJ$s = new TabPage();
		this.#=zY_gWJo98uUqE = new Button();
		this.#=zrRk0nhoV5FrM = new Button();
		this.#=zMMCNsL3DJB2B = new Button();
		this.#=zGHoFFfOPC6aekNaUQw== = new Button();
		this.#=z1xh4O4rr9zys = new TextBox();
		this.#=zdx$vkZ5vTREZ = new TextBox();
		this.#=zLdQ0Xy2_R8X7nofEmA== = new Button();
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.SuspendLayout();
		this.#=zb0dg7H$SUesy.SuspendLayout();
		((ISupportInitialize)this.#=zSkJFO7wY3x1SlT7atw==).BeginInit();
		this.#=zSkJFO7wY3x1SlT7atw==.Panel1.SuspendLayout();
		this.#=zSkJFO7wY3x1SlT7atw==.Panel2.SuspendLayout();
		this.#=zSkJFO7wY3x1SlT7atw==.SuspendLayout();
		((ISupportInitialize)this.#=zP8Wyt4o_jMJuXyiteA==).BeginInit();
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.SuspendLayout();
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel2.SuspendLayout();
		this.#=zP8Wyt4o_jMJuXyiteA==.SuspendLayout();
		this.#=znMm9YPgxt_OP.SuspendLayout();
		this.#=zezx_HtkB$LCq.SuspendLayout();
		this.#=zEYh4AmR2eXtIxy9k$g==.SuspendLayout();
		this.#=zVBsL45$iFGnJcXxMAQ==.SuspendLayout();
		this.#=zpPLP_sjnQJ$s.SuspendLayout();
		base.SuspendLayout();
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=zb0dg7H$SUesy);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=znMm9YPgxt_OP);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=zezx_HtkB$LCq);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=zEYh4AmR2eXtIxy9k$g==);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=zVBsL45$iFGnJcXxMAQ==);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Controls.Add(this.#=zpPLP_sjnQJ$s);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Dock = DockStyle.Fill;
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Location = new Point(0, 0);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102254);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.SelectedIndex = 0;
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.Size = new Size(941, 516);
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.TabIndex = 11;
		this.#=zb0dg7H$SUesy.Controls.Add(this.#=zSkJFO7wY3x1SlT7atw==);
		this.#=zb0dg7H$SUesy.Location = new Point(4, 22);
		this.#=zb0dg7H$SUesy.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909102218);
		this.#=zb0dg7H$SUesy.Padding = new Padding(3);
		this.#=zb0dg7H$SUesy.Size = new Size(933, 490);
		this.#=zb0dg7H$SUesy.TabIndex = 0;
		this.#=zb0dg7H$SUesy.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103986);
		this.#=zb0dg7H$SUesy.UseVisualStyleBackColor = true;
		this.#=zSkJFO7wY3x1SlT7atw==.Dock = DockStyle.Fill;
		this.#=zSkJFO7wY3x1SlT7atw==.IsSplitterFixed = true;
		this.#=zSkJFO7wY3x1SlT7atw==.Location = new Point(3, 3);
		this.#=zSkJFO7wY3x1SlT7atw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103968);
		this.#=zSkJFO7wY3x1SlT7atw==.Panel1.Controls.Add(this.#=zF0iDtirpI3GWYY5ZZA==);
		this.#=zSkJFO7wY3x1SlT7atw==.Panel2.Controls.Add(this.#=zP8Wyt4o_jMJuXyiteA==);
		this.#=zSkJFO7wY3x1SlT7atw==.Size = new Size(927, 484);
		this.#=zSkJFO7wY3x1SlT7atw==.SplitterDistance = 462;
		this.#=zSkJFO7wY3x1SlT7atw==.TabIndex = 9;
		this.#=zF0iDtirpI3GWYY5ZZA==.Dock = DockStyle.Fill;
		this.#=zF0iDtirpI3GWYY5ZZA==.Location = new Point(0, 0);
		this.#=zF0iDtirpI3GWYY5ZZA==.MaxLength = 1000000000;
		this.#=zF0iDtirpI3GWYY5ZZA==.Multiline = true;
		this.#=zF0iDtirpI3GWYY5ZZA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103939);
		this.#=zF0iDtirpI3GWYY5ZZA==.ScrollBars = ScrollBars.Vertical;
		this.#=zF0iDtirpI3GWYY5ZZA==.Size = new Size(462, 484);
		this.#=zF0iDtirpI3GWYY5ZZA==.TabIndex = 5;
		this.#=zP8Wyt4o_jMJuXyiteA==.Dock = DockStyle.Fill;
		this.#=zP8Wyt4o_jMJuXyiteA==.FixedPanel = FixedPanel.Panel1;
		this.#=zP8Wyt4o_jMJuXyiteA==.Location = new Point(0, 0);
		this.#=zP8Wyt4o_jMJuXyiteA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103906);
		this.#=zP8Wyt4o_jMJuXyiteA==.Orientation = Orientation.Horizontal;
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=zPPXBB3BV4IZC);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=zU7ODVJwxeL_gnyC7uA==);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=zLlwnrJwELmO0iqfMkGsOm$8=);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=zXLUTjdX0sB6$IbitQQ==);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=z31x9m5lKp07YnIe2zw==);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.Controls.Add(this.#=za3Qez0HfYeNU);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel2.Controls.Add(this.#=zzSMRk$PPcuzoo_T5fw==);
		this.#=zP8Wyt4o_jMJuXyiteA==.Size = new Size(461, 484);
		this.#=zP8Wyt4o_jMJuXyiteA==.SplitterDistance = 30;
		this.#=zP8Wyt4o_jMJuXyiteA==.TabIndex = 0;
		this.#=zPPXBB3BV4IZC.Location = new Point(160, 3);
		this.#=zPPXBB3BV4IZC.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103878);
		this.#=zPPXBB3BV4IZC.Size = new Size(58, 23);
		this.#=zPPXBB3BV4IZC.TabIndex = 12;
		this.#=zPPXBB3BV4IZC.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104096);
		this.#=zPPXBB3BV4IZC.UseVisualStyleBackColor = true;
		this.#=zPPXBB3BV4IZC.Click += this.#=z5KtDH10gMTDy5t7D8g==;
		this.#=zU7ODVJwxeL_gnyC7uA==.Location = new Point(334, 3);
		this.#=zU7ODVJwxeL_gnyC7uA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104082);
		this.#=zU7ODVJwxeL_gnyC7uA==.Size = new Size(75, 23);
		this.#=zU7ODVJwxeL_gnyC7uA==.TabIndex = 11;
		this.#=zU7ODVJwxeL_gnyC7uA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104048);
		this.#=zU7ODVJwxeL_gnyC7uA==.UseVisualStyleBackColor = true;
		this.#=zU7ODVJwxeL_gnyC7uA==.Click += this.#=zNZqR9s9eR3kj8rgKBmgq0mI=;
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.Location = new Point(68, 3);
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104038);
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.Size = new Size(86, 23);
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.TabIndex = 10;
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104007);
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.UseVisualStyleBackColor = true;
		this.#=zLlwnrJwELmO0iqfMkGsOm$8=.Click += this.#=zXKIXOFoVpWQntmQzmL80yRRr2oMd;
		this.#=zXLUTjdX0sB6$IbitQQ==.Location = new Point(415, 3);
		this.#=zXLUTjdX0sB6$IbitQQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103733);
		this.#=zXLUTjdX0sB6$IbitQQ==.Size = new Size(61, 23);
		this.#=zXLUTjdX0sB6$IbitQQ==.TabIndex = 9;
		this.#=zXLUTjdX0sB6$IbitQQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103702);
		this.#=zXLUTjdX0sB6$IbitQQ==.UseVisualStyleBackColor = true;
		this.#=zXLUTjdX0sB6$IbitQQ==.Click += this.#=zl$VHbYfNRvgbAINp4g==;
		this.#=z31x9m5lKp07YnIe2zw==.Location = new Point(224, 5);
		this.#=z31x9m5lKp07YnIe2zw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103680);
		this.#=z31x9m5lKp07YnIe2zw==.Size = new Size(104, 20);
		this.#=z31x9m5lKp07YnIe2zw==.TabIndex = 6;
		this.#=za3Qez0HfYeNU.Location = new Point(3, 3);
		this.#=za3Qez0HfYeNU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103643);
		this.#=za3Qez0HfYeNU.Size = new Size(59, 23);
		this.#=za3Qez0HfYeNU.TabIndex = 8;
		this.#=za3Qez0HfYeNU.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103617);
		this.#=za3Qez0HfYeNU.UseVisualStyleBackColor = true;
		this.#=za3Qez0HfYeNU.Click += this.#=zEGW15DLHHQmbJW9X1g==;
		this.#=zzSMRk$PPcuzoo_T5fw==.Dock = DockStyle.Fill;
		this.#=zzSMRk$PPcuzoo_T5fw==.Location = new Point(0, 0);
		this.#=zzSMRk$PPcuzoo_T5fw==.Multiline = true;
		this.#=zzSMRk$PPcuzoo_T5fw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103871);
		this.#=zzSMRk$PPcuzoo_T5fw==.ScrollBars = ScrollBars.Vertical;
		this.#=zzSMRk$PPcuzoo_T5fw==.Size = new Size(461, 450);
		this.#=zzSMRk$PPcuzoo_T5fw==.TabIndex = 7;
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zLdQ0Xy2_R8X7nofEmA==);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zuXYlF5T9nG4_);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zFNS55jhY3HNA);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zMO$Hw0rSwIDzNrspyg==);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zkxg$U5$7IDsCq1tVFu9FM2I=);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=z8O3DKSuP63ohiEaHGg==);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zDWV$wnwpiC4f);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=zIHup4hf8F5mH);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=znLNrCV$UyhVcDTkCGw==);
		this.#=znMm9YPgxt_OP.Controls.Add(this.#=z0V$nmb3XQqjfRQahnA==);
		this.#=znMm9YPgxt_OP.Location = new Point(4, 22);
		this.#=znMm9YPgxt_OP.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103839);
		this.#=znMm9YPgxt_OP.Padding = new Padding(3);
		this.#=znMm9YPgxt_OP.Size = new Size(933, 490);
		this.#=znMm9YPgxt_OP.TabIndex = 1;
		this.#=znMm9YPgxt_OP.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103815);
		this.#=znMm9YPgxt_OP.UseVisualStyleBackColor = true;
		this.#=zuXYlF5T9nG4_.AutoSize = true;
		this.#=zuXYlF5T9nG4_.Location = new Point(146, 9);
		this.#=zuXYlF5T9nG4_.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103797);
		this.#=zuXYlF5T9nG4_.Size = new Size(25, 13);
		this.#=zuXYlF5T9nG4_.TabIndex = 32;
		this.#=zuXYlF5T9nG4_.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103775);
		this.#=zFNS55jhY3HNA.AutoSize = true;
		this.#=zFNS55jhY3HNA.Location = new Point(6, 9);
		this.#=zFNS55jhY3HNA.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103754);
		this.#=zFNS55jhY3HNA.Size = new Size(28, 13);
		this.#=zFNS55jhY3HNA.TabIndex = 32;
		this.#=zFNS55jhY3HNA.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103487);
		this.#=zMO$Hw0rSwIDzNrspyg==.Location = new Point(813, 361);
		this.#=zMO$Hw0rSwIDzNrspyg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103466);
		this.#=zMO$Hw0rSwIDzNrspyg==.Size = new Size(94, 80);
		this.#=zMO$Hw0rSwIDzNrspyg==.TabIndex = 31;
		this.#=zMO$Hw0rSwIDzNrspyg==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103439);
		this.#=zMO$Hw0rSwIDzNrspyg==.UseVisualStyleBackColor = true;
		this.#=zMO$Hw0rSwIDzNrspyg==.Click += this.#=zCl3BduT5v5zdFrTqdg==;
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.AutoSize = true;
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.Location = new Point(283, 8);
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103405);
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.Size = new Size(74, 17);
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.TabIndex = 4;
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103373);
		this.#=zkxg$U5$7IDsCq1tVFu9FM2I=.UseVisualStyleBackColor = true;
		this.#=z8O3DKSuP63ohiEaHGg==.Location = new Point(474, 4);
		this.#=z8O3DKSuP63ohiEaHGg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103613);
		this.#=z8O3DKSuP63ohiEaHGg==.Size = new Size(75, 23);
		this.#=z8O3DKSuP63ohiEaHGg==.TabIndex = 3;
		this.#=z8O3DKSuP63ohiEaHGg==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103581);
		this.#=z8O3DKSuP63ohiEaHGg==.UseVisualStyleBackColor = true;
		this.#=z8O3DKSuP63ohiEaHGg==.Click += this.#=z4DwQ4q8JW4kTcYEU4g==;
		this.#=zDWV$wnwpiC4f.Location = new Point(363, 4);
		this.#=zDWV$wnwpiC4f.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103566);
		this.#=zDWV$wnwpiC4f.Size = new Size(75, 23);
		this.#=zDWV$wnwpiC4f.TabIndex = 1;
		this.#=zDWV$wnwpiC4f.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103537);
		this.#=zDWV$wnwpiC4f.UseVisualStyleBackColor = true;
		this.#=zDWV$wnwpiC4f.Click += this.#=z$tNjd_nK7mzGxZRFhw==;
		this.#=zIHup4hf8F5mH.Location = new Point(4, 32);
		this.#=zIHup4hf8F5mH.MaxLength = 1000000000;
		this.#=zIHup4hf8F5mH.Multiline = true;
		this.#=zIHup4hf8F5mH.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103522);
		this.#=zIHup4hf8F5mH.ScrollBars = ScrollBars.Vertical;
		this.#=zIHup4hf8F5mH.Size = new Size(759, 409);
		this.#=zIHup4hf8F5mH.TabIndex = 0;
		this.#=znLNrCV$UyhVcDTkCGw==.Location = new Point(40, 6);
		this.#=znLNrCV$UyhVcDTkCGw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103509);
		this.#=znLNrCV$UyhVcDTkCGw==.Size = new Size(100, 20);
		this.#=znLNrCV$UyhVcDTkCGw==.TabIndex = 0;
		this.#=z0V$nmb3XQqjfRQahnA==.Location = new Point(177, 7);
		this.#=z0V$nmb3XQqjfRQahnA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103228);
		this.#=z0V$nmb3XQqjfRQahnA==.Size = new Size(100, 20);
		this.#=z0V$nmb3XQqjfRQahnA==.TabIndex = 0;
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zAbTyfXq9F_iMxy$gvA==);
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zHTlwsOilVXij4r019w==);
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zrebyNXWxE6iP);
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zRBY4n6Y9xJyf);
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zQ_Eu0invnmQn);
		this.#=zezx_HtkB$LCq.Controls.Add(this.#=zUq8qakitAT0T);
		this.#=zezx_HtkB$LCq.Location = new Point(4, 22);
		this.#=zezx_HtkB$LCq.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103204);
		this.#=zezx_HtkB$LCq.Size = new Size(933, 490);
		this.#=zezx_HtkB$LCq.TabIndex = 3;
		this.#=zezx_HtkB$LCq.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103178);
		this.#=zezx_HtkB$LCq.UseVisualStyleBackColor = true;
		this.#=zAbTyfXq9F_iMxy$gvA==.AutoSize = true;
		this.#=zAbTyfXq9F_iMxy$gvA==.Location = new Point(195, 54);
		this.#=zAbTyfXq9F_iMxy$gvA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103169);
		this.#=zAbTyfXq9F_iMxy$gvA==.Size = new Size(48, 17);
		this.#=zAbTyfXq9F_iMxy$gvA==.TabIndex = 34;
		this.#=zAbTyfXq9F_iMxy$gvA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103136);
		this.#=zAbTyfXq9F_iMxy$gvA==.UseVisualStyleBackColor = true;
		this.#=zHTlwsOilVXij4r019w==.AutoSize = true;
		this.#=zHTlwsOilVXij4r019w==.Location = new Point(310, 27);
		this.#=zHTlwsOilVXij4r019w==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103134);
		this.#=zHTlwsOilVXij4r019w==.Size = new Size(82, 13);
		this.#=zHTlwsOilVXij4r019w==.TabIndex = 32;
		this.#=zHTlwsOilVXij4r019w==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103109);
		this.#=zrebyNXWxE6iP.Location = new Point(73, 50);
		this.#=zrebyNXWxE6iP.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103342);
		this.#=zrebyNXWxE6iP.Size = new Size(33, 23);
		this.#=zrebyNXWxE6iP.TabIndex = 31;
		this.#=zrebyNXWxE6iP.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070767);
		this.#=zrebyNXWxE6iP.UseVisualStyleBackColor = true;
		this.#=zrebyNXWxE6iP.Click += this.#=zwtOInYEOegviJialUw==;
		this.#=zRBY4n6Y9xJyf.Location = new Point(145, 50);
		this.#=zRBY4n6Y9xJyf.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103313);
		this.#=zRBY4n6Y9xJyf.Size = new Size(34, 23);
		this.#=zRBY4n6Y9xJyf.TabIndex = 31;
		this.#=zRBY4n6Y9xJyf.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080192);
		this.#=zRBY4n6Y9xJyf.UseVisualStyleBackColor = true;
		this.#=zRBY4n6Y9xJyf.Click += this.#=zg5Q3Q61NeGRmOh34Hw==;
		this.#=zQ_Eu0invnmQn.Location = new Point(30, 24);
		this.#=zQ_Eu0invnmQn.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103288);
		this.#=zQ_Eu0invnmQn.Size = new Size(227, 20);
		this.#=zQ_Eu0invnmQn.TabIndex = 0;
		this.#=zUq8qakitAT0T.CustomFormat = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103265);
		this.#=zUq8qakitAT0T.Format = DateTimePickerFormat.Custom;
		this.#=zUq8qakitAT0T.Location = new Point(30, 79);
		this.#=zUq8qakitAT0T.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909103247);
		this.#=zUq8qakitAT0T.Size = new Size(227, 20);
		this.#=zUq8qakitAT0T.TabIndex = 30;
		this.#=zEYh4AmR2eXtIxy9k$g==.Controls.Add(this.#=zHz4hpM3FzRjU);
		this.#=zEYh4AmR2eXtIxy9k$g==.Controls.Add(this.#=zRa59PRf4Hxg$2zukRw==);
		this.#=zEYh4AmR2eXtIxy9k$g==.Controls.Add(this.#=zYTPe7rYLIURVmE0yzg==);
		this.#=zEYh4AmR2eXtIxy9k$g==.Controls.Add(this.#=zH4_Sd4jXFaos);
		this.#=zEYh4AmR2eXtIxy9k$g==.Location = new Point(4, 22);
		this.#=zEYh4AmR2eXtIxy9k$g==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105013);
		this.#=zEYh4AmR2eXtIxy9k$g==.Size = new Size(933, 490);
		this.#=zEYh4AmR2eXtIxy9k$g==.TabIndex = 4;
		this.#=zEYh4AmR2eXtIxy9k$g==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104977);
		this.#=zEYh4AmR2eXtIxy9k$g==.UseVisualStyleBackColor = true;
		this.#=zHz4hpM3FzRjU.Location = new Point(436, 8);
		this.#=zHz4hpM3FzRjU.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104952);
		this.#=zHz4hpM3FzRjU.Size = new Size(204, 23);
		this.#=zHz4hpM3FzRjU.TabIndex = 7;
		this.#=zHz4hpM3FzRjU.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104943);
		this.#=zHz4hpM3FzRjU.UseVisualStyleBackColor = true;
		this.#=zHz4hpM3FzRjU.Click += this.#=zySGVds6UXTl1s8RD3A==;
		this.#=zRa59PRf4Hxg$2zukRw==.Location = new Point(436, 229);
		this.#=zRa59PRf4Hxg$2zukRw==.MaxLength = 1000000000;
		this.#=zRa59PRf4Hxg$2zukRw==.Multiline = true;
		this.#=zRa59PRf4Hxg$2zukRw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104904);
		this.#=zRa59PRf4Hxg$2zukRw==.ScrollBars = ScrollBars.Vertical;
		this.#=zRa59PRf4Hxg$2zukRw==.Size = new Size(407, 173);
		this.#=zRa59PRf4Hxg$2zukRw==.TabIndex = 6;
		this.#=zYTPe7rYLIURVmE0yzg==.Location = new Point(436, 50);
		this.#=zYTPe7rYLIURVmE0yzg==.MaxLength = 1000000000;
		this.#=zYTPe7rYLIURVmE0yzg==.Multiline = true;
		this.#=zYTPe7rYLIURVmE0yzg==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105138);
		this.#=zYTPe7rYLIURVmE0yzg==.ScrollBars = ScrollBars.Vertical;
		this.#=zYTPe7rYLIURVmE0yzg==.Size = new Size(407, 173);
		this.#=zYTPe7rYLIURVmE0yzg==.TabIndex = 6;
		this.#=zH4_Sd4jXFaos.Location = new Point(8, 8);
		this.#=zH4_Sd4jXFaos.MaxLength = 1000000000;
		this.#=zH4_Sd4jXFaos.Multiline = true;
		this.#=zH4_Sd4jXFaos.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105125);
		this.#=zH4_Sd4jXFaos.ScrollBars = ScrollBars.Vertical;
		this.#=zH4_Sd4jXFaos.Size = new Size(422, 484);
		this.#=zH4_Sd4jXFaos.TabIndex = 6;
		this.#=zVBsL45$iFGnJcXxMAQ==.Controls.Add(this.#=zikzcbGe_63kIoyWO$A==);
		this.#=zVBsL45$iFGnJcXxMAQ==.Controls.Add(this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=);
		this.#=zVBsL45$iFGnJcXxMAQ==.Location = new Point(4, 22);
		this.#=zVBsL45$iFGnJcXxMAQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105101);
		this.#=zVBsL45$iFGnJcXxMAQ==.Size = new Size(933, 490);
		this.#=zVBsL45$iFGnJcXxMAQ==.TabIndex = 5;
		this.#=zVBsL45$iFGnJcXxMAQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074059);
		this.#=zVBsL45$iFGnJcXxMAQ==.UseVisualStyleBackColor = true;
		this.#=zikzcbGe_63kIoyWO$A==.Location = new Point(437, 13);
		this.#=zikzcbGe_63kIoyWO$A==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105079);
		this.#=zikzcbGe_63kIoyWO$A==.Size = new Size(75, 23);
		this.#=zikzcbGe_63kIoyWO$A==.TabIndex = 1;
		this.#=zikzcbGe_63kIoyWO$A==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105053);
		this.#=zikzcbGe_63kIoyWO$A==.UseVisualStyleBackColor = true;
		this.#=zikzcbGe_63kIoyWO$A==.Click += this.#=zHtxIfLJq_6UzEhQHyPnb8Mg=;
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Location = new Point(8, 13);
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Multiline = true;
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909105033);
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.ScrollBars = ScrollBars.Vertical;
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.Size = new Size(411, 449);
		this.#=zVhyFxU6jP__ZLZQ8U0G$kLE=.TabIndex = 0;
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=zY_gWJo98uUqE);
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=zrRk0nhoV5FrM);
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=zMMCNsL3DJB2B);
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=zGHoFFfOPC6aekNaUQw==);
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=z1xh4O4rr9zys);
		this.#=zpPLP_sjnQJ$s.Controls.Add(this.#=zdx$vkZ5vTREZ);
		this.#=zpPLP_sjnQJ$s.Location = new Point(4, 22);
		this.#=zpPLP_sjnQJ$s.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104759);
		this.#=zpPLP_sjnQJ$s.Size = new Size(933, 490);
		this.#=zpPLP_sjnQJ$s.TabIndex = 6;
		this.#=zpPLP_sjnQJ$s.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104728);
		this.#=zpPLP_sjnQJ$s.UseVisualStyleBackColor = true;
		this.#=zY_gWJo98uUqE.Location = new Point(246, 62);
		this.#=zY_gWJo98uUqE.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104714);
		this.#=zY_gWJo98uUqE.Size = new Size(75, 23);
		this.#=zY_gWJo98uUqE.TabIndex = 6;
		this.#=zY_gWJo98uUqE.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104694);
		this.#=zY_gWJo98uUqE.UseVisualStyleBackColor = true;
		this.#=zY_gWJo98uUqE.Click += this.#=zKzGs8s7CxHD89XyYeA==;
		this.#=zrRk0nhoV5FrM.Location = new Point(165, 62);
		this.#=zrRk0nhoV5FrM.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104677);
		this.#=zrRk0nhoV5FrM.Size = new Size(75, 23);
		this.#=zrRk0nhoV5FrM.TabIndex = 5;
		this.#=zrRk0nhoV5FrM.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104640);
		this.#=zrRk0nhoV5FrM.UseVisualStyleBackColor = true;
		this.#=zrRk0nhoV5FrM.Click += this.#=zr6sYKzVyXNh$Oq0Jgg==;
		this.#=zMMCNsL3DJB2B.Location = new Point(84, 62);
		this.#=zMMCNsL3DJB2B.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104883);
		this.#=zMMCNsL3DJB2B.Size = new Size(75, 23);
		this.#=zMMCNsL3DJB2B.TabIndex = 4;
		this.#=zMMCNsL3DJB2B.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104861);
		this.#=zMMCNsL3DJB2B.UseVisualStyleBackColor = true;
		this.#=zMMCNsL3DJB2B.Click += this.#=zSvGXSB2zc9QU2e_PAg==;
		this.#=zGHoFFfOPC6aekNaUQw==.Location = new Point(3, 62);
		this.#=zGHoFFfOPC6aekNaUQw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104834);
		this.#=zGHoFFfOPC6aekNaUQw==.Size = new Size(75, 23);
		this.#=zGHoFFfOPC6aekNaUQw==.TabIndex = 3;
		this.#=zGHoFFfOPC6aekNaUQw==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104809);
		this.#=zGHoFFfOPC6aekNaUQw==.UseVisualStyleBackColor = true;
		this.#=zGHoFFfOPC6aekNaUQw==.Click += this.#=z9C$hQsITgl7ymOTc2Q==;
		this.#=z1xh4O4rr9zys.Location = new Point(8, 141);
		this.#=z1xh4O4rr9zys.Multiline = true;
		this.#=z1xh4O4rr9zys.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104793);
		this.#=z1xh4O4rr9zys.Size = new Size(471, 341);
		this.#=z1xh4O4rr9zys.TabIndex = 1;
		this.#=zdx$vkZ5vTREZ.Location = new Point(3, 3);
		this.#=zdx$vkZ5vTREZ.Multiline = true;
		this.#=zdx$vkZ5vTREZ.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104772);
		this.#=zdx$vkZ5vTREZ.Size = new Size(476, 53);
		this.#=zdx$vkZ5vTREZ.TabIndex = 0;
		this.#=zLdQ0Xy2_R8X7nofEmA==.Location = new Point(594, 4);
		this.#=zLdQ0Xy2_R8X7nofEmA==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104482);
		this.#=zLdQ0Xy2_R8X7nofEmA==.Size = new Size(169, 23);
		this.#=zLdQ0Xy2_R8X7nofEmA==.TabIndex = 33;
		this.#=zLdQ0Xy2_R8X7nofEmA==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104450);
		this.#=zLdQ0Xy2_R8X7nofEmA==.UseVisualStyleBackColor = true;
		this.#=zLdQ0Xy2_R8X7nofEmA==.Click += this.#=zU_VeaYb0kTFJmEQF5mjOrto=;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(941, 516);
		base.Controls.Add(this.#=z9bBc6uTdnfHYaew$UvMQizU=);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104428);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104428);
		base.FormClosing += this.#=zpHSy4J1il67bK5DQqw==;
		this.#=z9bBc6uTdnfHYaew$UvMQizU=.ResumeLayout(false);
		this.#=zb0dg7H$SUesy.ResumeLayout(false);
		this.#=zSkJFO7wY3x1SlT7atw==.Panel1.ResumeLayout(false);
		this.#=zSkJFO7wY3x1SlT7atw==.Panel1.PerformLayout();
		this.#=zSkJFO7wY3x1SlT7atw==.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zSkJFO7wY3x1SlT7atw==).EndInit();
		this.#=zSkJFO7wY3x1SlT7atw==.ResumeLayout(false);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.ResumeLayout(false);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel1.PerformLayout();
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel2.ResumeLayout(false);
		this.#=zP8Wyt4o_jMJuXyiteA==.Panel2.PerformLayout();
		((ISupportInitialize)this.#=zP8Wyt4o_jMJuXyiteA==).EndInit();
		this.#=zP8Wyt4o_jMJuXyiteA==.ResumeLayout(false);
		this.#=znMm9YPgxt_OP.ResumeLayout(false);
		this.#=znMm9YPgxt_OP.PerformLayout();
		this.#=zezx_HtkB$LCq.ResumeLayout(false);
		this.#=zezx_HtkB$LCq.PerformLayout();
		this.#=zEYh4AmR2eXtIxy9k$g==.ResumeLayout(false);
		this.#=zEYh4AmR2eXtIxy9k$g==.PerformLayout();
		this.#=zVBsL45$iFGnJcXxMAQ==.ResumeLayout(false);
		this.#=zVBsL45$iFGnJcXxMAQ==.PerformLayout();
		this.#=zpPLP_sjnQJ$s.ResumeLayout(false);
		this.#=zpPLP_sjnQJ$s.PerformLayout();
		base.ResumeLayout(false);
	}

	// Token: 0x040002BE RID: 702
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zeJZsbgM=;

	// Token: 0x040002BF RID: 703
	private #=zTseZhcIhfyCywJnhZNmOlF0q38Tpt4VaeA== #=z$ctZ69FG4Rp6 = new #=zTseZhcIhfyCywJnhZNmOlF0q38Tpt4VaeA==();

	// Token: 0x040002C1 RID: 705
	private TabControl #=z9bBc6uTdnfHYaew$UvMQizU=;

	// Token: 0x040002C2 RID: 706
	private TabPage #=zb0dg7H$SUesy;

	// Token: 0x040002C3 RID: 707
	private SplitContainer #=zSkJFO7wY3x1SlT7atw==;

	// Token: 0x040002C4 RID: 708
	private TextBox #=zF0iDtirpI3GWYY5ZZA==;

	// Token: 0x040002C5 RID: 709
	private SplitContainer #=zP8Wyt4o_jMJuXyiteA==;

	// Token: 0x040002C6 RID: 710
	private Button #=zPPXBB3BV4IZC;

	// Token: 0x040002C7 RID: 711
	private Button #=zU7ODVJwxeL_gnyC7uA==;

	// Token: 0x040002C8 RID: 712
	private Button #=zLlwnrJwELmO0iqfMkGsOm$8=;

	// Token: 0x040002C9 RID: 713
	private Button #=zXLUTjdX0sB6$IbitQQ==;

	// Token: 0x040002CA RID: 714
	private TextBox #=z31x9m5lKp07YnIe2zw==;

	// Token: 0x040002CB RID: 715
	private Button #=za3Qez0HfYeNU;

	// Token: 0x040002CC RID: 716
	private TextBox #=zzSMRk$PPcuzoo_T5fw==;

	// Token: 0x040002CD RID: 717
	private TabPage #=znMm9YPgxt_OP;

	// Token: 0x040002CE RID: 718
	private Button #=zMO$Hw0rSwIDzNrspyg==;

	// Token: 0x040002CF RID: 719
	private CheckBox #=zkxg$U5$7IDsCq1tVFu9FM2I=;

	// Token: 0x040002D0 RID: 720
	private Button #=z8O3DKSuP63ohiEaHGg==;

	// Token: 0x040002D1 RID: 721
	private Button #=zDWV$wnwpiC4f;

	// Token: 0x040002D2 RID: 722
	private TextBox #=zIHup4hf8F5mH;

	// Token: 0x040002D3 RID: 723
	private TextBox #=z0V$nmb3XQqjfRQahnA==;

	// Token: 0x040002D4 RID: 724
	private TabPage #=zezx_HtkB$LCq;

	// Token: 0x040002D5 RID: 725
	private Label #=zHTlwsOilVXij4r019w==;

	// Token: 0x040002D6 RID: 726
	private Button #=zrebyNXWxE6iP;

	// Token: 0x040002D7 RID: 727
	private Button #=zRBY4n6Y9xJyf;

	// Token: 0x040002D8 RID: 728
	private TextBox #=zQ_Eu0invnmQn;

	// Token: 0x040002D9 RID: 729
	protected DateTimePicker #=zUq8qakitAT0T;

	// Token: 0x040002DA RID: 730
	private TabPage #=zEYh4AmR2eXtIxy9k$g==;

	// Token: 0x040002DB RID: 731
	private TextBox #=zRa59PRf4Hxg$2zukRw==;

	// Token: 0x040002DC RID: 732
	private TextBox #=zYTPe7rYLIURVmE0yzg==;

	// Token: 0x040002DD RID: 733
	private TextBox #=zH4_Sd4jXFaos;

	// Token: 0x040002DE RID: 734
	private Button #=zHz4hpM3FzRjU;

	// Token: 0x040002DF RID: 735
	private TabPage #=zVBsL45$iFGnJcXxMAQ==;

	// Token: 0x040002E0 RID: 736
	private Button #=zikzcbGe_63kIoyWO$A==;

	// Token: 0x040002E1 RID: 737
	private TextBox #=zVhyFxU6jP__ZLZQ8U0G$kLE=;

	// Token: 0x040002E2 RID: 738
	private TextBox #=znLNrCV$UyhVcDTkCGw==;

	// Token: 0x040002E3 RID: 739
	private Label #=zuXYlF5T9nG4_;

	// Token: 0x040002E4 RID: 740
	private Label #=zFNS55jhY3HNA;

	// Token: 0x040002E5 RID: 741
	private CheckBox #=zAbTyfXq9F_iMxy$gvA==;

	// Token: 0x040002E6 RID: 742
	private TabPage #=zpPLP_sjnQJ$s;

	// Token: 0x040002E7 RID: 743
	private Button #=zMMCNsL3DJB2B;

	// Token: 0x040002E8 RID: 744
	private Button #=zGHoFFfOPC6aekNaUQw==;

	// Token: 0x040002E9 RID: 745
	private TextBox #=z1xh4O4rr9zys;

	// Token: 0x040002EA RID: 746
	private TextBox #=zdx$vkZ5vTREZ;

	// Token: 0x040002EB RID: 747
	private Button #=zY_gWJo98uUqE;

	// Token: 0x040002EC RID: 748
	private Button #=zrRk0nhoV5FrM;

	// Token: 0x040002ED RID: 749
	private Button #=zLdQ0Xy2_R8X7nofEmA==;
}
