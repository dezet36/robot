﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;

// Token: 0x0200007F RID: 127
internal sealed class #=z6WGF48kImHdKxLII90Za03kTJT$Rkt3QzFO_G5ewawyrVmLbGg== : IComparer<#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1>
{
	// Token: 0x06000390 RID: 912 RVA: 0x0001FBD8 File Offset: 0x0001DDD8
	public #=z6WGF48kImHdKxLII90Za03kTJT$Rkt3QzFO_G5ewawyrVmLbGg==(#=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=zy0tqKwE=)
	{
		this.#=z3yL5bKs= = #=zy0tqKwE=;
	}

	// Token: 0x06000391 RID: 913 RVA: 0x0001FBE8 File Offset: 0x0001DDE8
	public int Compare(#=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=zXg4BqCM=, #=z6fxFsMgelAshh1EluoE6HpDoSpCAJ1DFz_hgdVEQZYd1 #=zcf4mMM4=)
	{
		int num = this.#=z3yL5bKs=[ResourceTypes.Lumber];
		int num2 = this.#=z3yL5bKs=[ResourceTypes.Bronze];
		int num3 = this.#=z3yL5bKs=[ResourceTypes.Grain];
		if (num <= num2 && num <= num3)
		{
			return #=zcf4mMM4=.#=zCF7_RpkTiHMeBeLmww==().CompareTo(#=zXg4BqCM=.#=zCF7_RpkTiHMeBeLmww==());
		}
		if (num2 <= num && num2 <= num3)
		{
			return #=zcf4mMM4=.#=zIDq8g$CbFZo_EGdo3A==().CompareTo(#=zXg4BqCM=.#=zIDq8g$CbFZo_EGdo3A==());
		}
		return #=zcf4mMM4=.#=zlOl3uc8MyINDqgsIig==().CompareTo(#=zXg4BqCM=.#=zlOl3uc8MyINDqgsIig==());
	}

	// Token: 0x04000140 RID: 320
	private #=zRq2AEW0okvKAl3LdOqWDdBwtgdy2 #=z3yL5bKs=;
}
