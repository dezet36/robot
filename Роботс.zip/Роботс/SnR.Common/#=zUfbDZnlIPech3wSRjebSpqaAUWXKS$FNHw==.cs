﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x020001B6 RID: 438
internal sealed class #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==
{
	// Token: 0x06000D21 RID: 3361 RVA: 0x00067DB8 File Offset: 0x00065FB8
	public #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==()
	{
		this.#=zlZlDJ5r94$1D = new Dictionary<string, #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs=>();
	}

	// Token: 0x06000D23 RID: 3363 RVA: 0x00067DE0 File Offset: 0x00065FE0
	private static #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw== #=zKVN4CRU=()
	{
		if (#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zOAzeRO$HqsMN == null)
		{
			object obj = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zOAzeRO$HqsMN == null)
				{
					#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zOAzeRO$HqsMN = new #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==();
				}
			}
		}
		return #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zOAzeRO$HqsMN;
	}

	// Token: 0x06000D24 RID: 3364 RVA: 0x00067E3C File Offset: 0x0006603C
	private #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs= #=zpVF79J0Mi3dE(string #=zNraCe1Y=)
	{
		#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs= #=zMkcauqs= = null;
		if (this.#=zlZlDJ5r94$1D.ContainsKey(#=zNraCe1Y=))
		{
			#=zMkcauqs= = this.#=zlZlDJ5r94$1D[#=zNraCe1Y=];
			if (#=zMkcauqs=.#=zbK2hBFM1$8vd() < DateTime.Now)
			{
				#=zMkcauqs= = null;
			}
		}
		return #=zMkcauqs=;
	}

	// Token: 0x06000D25 RID: 3365 RVA: 0x00067E7C File Offset: 0x0006607C
	public static bool #=zxoq6CXk=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, Task #=zcTyyNys=, out #=zDSiRXECNe4Awos25aECUKlmR8FRd #=zx9NCziM=)
	{
		bool result;
		try
		{
			if (!(#=zcTyyNys= is #=z7xmkP2Q4y7elpLLAWHm$jC1Yj2rFp60Dkw==))
			{
				#=zx9NCziM= = null;
				result = true;
			}
			else
			{
				string text = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zTaM7WO5ywOjP(#=zcTyyNys=);
				#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs= #=zMkcauqs= = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zKVN4CRU=().#=zpVF79J0Mi3dE(text);
				if (#=zMkcauqs= == null)
				{
					object obj = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zSV4$mlFB34WM;
					lock (obj)
					{
						#=zMkcauqs= = #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zKVN4CRU=().#=zpVF79J0Mi3dE(text);
						if (#=zMkcauqs= == null)
						{
							string text2 = #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zw374AcbLnrWfTy2Hqg==(#=z8StzeqE=, #=zcTyyNys=);
							if (string.IsNullOrEmpty(text2))
							{
								#=zMkcauqs= = new #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs=();
							}
							else
							{
								Dictionary<string, object> dictionary = null;
								try
								{
									dictionary = (Dictionary<string, object>)JSONManager.DeserializeData(text2);
								}
								catch
								{
								}
								if (dictionary == null)
								{
									#=zMkcauqs= = new #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs=(new #=zDSiRXECNe4Awos25aECUKlmR8FRd(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050160), new object[]
									{
										JSONManager.Cut(text2)
									}));
								}
								else
								{
									string text3 = JSONManager.ExtractString(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050124), string.Empty);
									#=zMkcauqs= = new #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs=(JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050362), 0) == 1, JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050352), 0) == 1, JSONManager.ExtractDictionary(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076656)), (!string.IsNullOrEmpty(text3)) ? new #=zDSiRXECNe4Awos25aECUKlmR8FRd(null, LogTypes.Exception, text3, new object[0]) : null);
								}
							}
							#=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zKVN4CRU=().#=zlZlDJ5r94$1D[text] = #=zMkcauqs=;
						}
					}
				}
				if (#=zMkcauqs=.#=zUs7RMuHXC7oD() && #=zMkcauqs=.#=zUB9fT3ms2kyK() != null)
				{
					Dictionary<string, object> dictionary2 = #=zcTyyNys=.Serialize();
					foreach (string key in #=zMkcauqs=.#=zUB9fT3ms2kyK().Keys)
					{
						dictionary2[key] = #=zMkcauqs=.#=zUB9fT3ms2kyK()[key];
					}
					#=zcTyyNys=.UpdateTask(dictionary2);
				}
				#=zx9NCziM= = #=zMkcauqs=.#=zqjHOR9Q=();
				result = !#=zMkcauqs=.#=zeEOxr4vkuv5V();
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zx9NCziM= = new #=zDSiRXECNe4Awos25aECUKlmR8FRd(null, LogTypes.Exception, #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=), new object[0]);
			result = true;
		}
		return result;
	}

	// Token: 0x06000D26 RID: 3366 RVA: 0x000680C8 File Offset: 0x000662C8
	private static string #=zTaM7WO5ywOjP(Task #=zcTyyNys=)
	{
		Dictionary<string, object> dictionary = #=zcTyyNys=.Serialize();
		dictionary.Remove(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050350));
		dictionary.Remove(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050329));
		dictionary.Remove(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050312));
		dictionary.Remove(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050289));
		dictionary.Remove(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050285));
		return JSONManager.SerializeData(dictionary);
	}

	// Token: 0x0400079B RID: 1947
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x0400079C RID: 1948
	private static #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw== #=zOAzeRO$HqsMN = null;

	// Token: 0x0400079D RID: 1949
	private Dictionary<string, #=zUfbDZnlIPech3wSRjebSpqaAUWXKS$FNHw==.#=zMkcauqs=> #=zlZlDJ5r94$1D;

	// Token: 0x020001B7 RID: 439
	private sealed class #=zMkcauqs=
	{
		// Token: 0x06000D27 RID: 3367 RVA: 0x00068138 File Offset: 0x00066338
		public #=zMkcauqs=()
		{
			this.#=z$iMfIGmiGOXW(DateTime.Now + TimeSpan.FromMinutes(60.0));
			this.#=zaJGouI4ccZa2(false);
			this.#=zIENcxvRKpA17(false);
			this.#=zu87TGQumLnTN(null);
			this.#=zeAChU_4=(null);
		}

		// Token: 0x06000D28 RID: 3368 RVA: 0x00068188 File Offset: 0x00066388
		public #=zMkcauqs=(#=zDSiRXECNe4Awos25aECUKlmR8FRd #=zx9NCziM=)
		{
			this.#=z$iMfIGmiGOXW(DateTime.Now + TimeSpan.FromMinutes(60.0));
			this.#=zaJGouI4ccZa2(false);
			this.#=zIENcxvRKpA17(false);
			this.#=zu87TGQumLnTN(null);
			this.#=zeAChU_4=(#=zx9NCziM=);
		}

		// Token: 0x06000D29 RID: 3369 RVA: 0x000681D8 File Offset: 0x000663D8
		public #=zMkcauqs=(bool #=zNn_iGHk=, bool #=ziM$w0hk=, Dictionary<string, object> #=zdbWtuEI=, #=zDSiRXECNe4Awos25aECUKlmR8FRd #=zx9NCziM=)
		{
			this.#=z$iMfIGmiGOXW(DateTime.Now + TimeSpan.FromMinutes(60.0));
			this.#=zaJGouI4ccZa2(#=zNn_iGHk=);
			this.#=zIENcxvRKpA17(#=ziM$w0hk=);
			this.#=zu87TGQumLnTN(#=zdbWtuEI=);
			this.#=zeAChU_4=(#=zx9NCziM=);
		}

		// Token: 0x06000D2A RID: 3370 RVA: 0x00068228 File Offset: 0x00066428
		public DateTime #=zbK2hBFM1$8vd()
		{
			return this.#=zhnwN1sPFxZqWFkYnrw==;
		}

		// Token: 0x06000D2B RID: 3371 RVA: 0x00068230 File Offset: 0x00066430
		public void #=z$iMfIGmiGOXW(DateTime #=z$Ib9gYQ=)
		{
			this.#=zhnwN1sPFxZqWFkYnrw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D2C RID: 3372 RVA: 0x0006823C File Offset: 0x0006643C
		public bool #=zeEOxr4vkuv5V()
		{
			return this.#=z7eGuj4O6pdwvrS4CNQ==;
		}

		// Token: 0x06000D2D RID: 3373 RVA: 0x00068244 File Offset: 0x00066444
		public void #=zaJGouI4ccZa2(bool #=z$Ib9gYQ=)
		{
			this.#=z7eGuj4O6pdwvrS4CNQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D2E RID: 3374 RVA: 0x00068250 File Offset: 0x00066450
		public bool #=zUs7RMuHXC7oD()
		{
			return this.#=zkDuoNSuV1RPtNitFzQ==;
		}

		// Token: 0x06000D2F RID: 3375 RVA: 0x00068258 File Offset: 0x00066458
		public void #=zIENcxvRKpA17(bool #=z$Ib9gYQ=)
		{
			this.#=zkDuoNSuV1RPtNitFzQ== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D30 RID: 3376 RVA: 0x00068264 File Offset: 0x00066464
		public Dictionary<string, object> #=zUB9fT3ms2kyK()
		{
			return this.#=znRkVuXTf5nFbsGpYuA==;
		}

		// Token: 0x06000D31 RID: 3377 RVA: 0x0006826C File Offset: 0x0006646C
		public void #=zu87TGQumLnTN(Dictionary<string, object> #=z$Ib9gYQ=)
		{
			this.#=znRkVuXTf5nFbsGpYuA== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000D32 RID: 3378 RVA: 0x00068278 File Offset: 0x00066478
		public #=zDSiRXECNe4Awos25aECUKlmR8FRd #=zqjHOR9Q=()
		{
			return this.#=zMOn$W0DW3iFpiytW9w==;
		}

		// Token: 0x06000D33 RID: 3379 RVA: 0x00068280 File Offset: 0x00066480
		public void #=zeAChU_4=(#=zDSiRXECNe4Awos25aECUKlmR8FRd #=z$Ib9gYQ=)
		{
			this.#=zMOn$W0DW3iFpiytW9w== = #=z$Ib9gYQ=;
		}

		// Token: 0x0400079E RID: 1950
		private DateTime #=zhnwN1sPFxZqWFkYnrw==;

		// Token: 0x0400079F RID: 1951
		private bool #=z7eGuj4O6pdwvrS4CNQ==;

		// Token: 0x040007A0 RID: 1952
		private bool #=zkDuoNSuV1RPtNitFzQ==;

		// Token: 0x040007A1 RID: 1953
		private Dictionary<string, object> #=znRkVuXTf5nFbsGpYuA==;

		// Token: 0x040007A2 RID: 1954
		private #=zDSiRXECNe4Awos25aECUKlmR8FRd #=zMOn$W0DW3iFpiytW9w==;
	}
}
