﻿using System;

// Token: 0x0200008A RID: 138
internal sealed class #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg== : #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==
{
	// Token: 0x060003B7 RID: 951 RVA: 0x00021138 File Offset: 0x0001F338
	public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==()
	{
		this.#=zAsCgbAN02olKpq2GjA==(0);
		this.#=zZSkNRUgj8yXAH6_cQElO$6Y=(0);
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x00021150 File Offset: 0x0001F350
	public #=z788pJBQqlBHWMzvigs7oLTif0YwOU1Q8Jg==(int #=zAk8mKBk=, string #=z6QPrZ_4=, int #=zQrqFdos=, int #=zKFlJyLE=)
	{
		base.#=zbsxKkj4=(#=zAk8mKBk=);
		base.#=zwXKUV2c=(#=z6QPrZ_4=);
		base.#=zHD9M6IxBLboIezSsHQ==(#=zQrqFdos=);
		base.#=z2WdNm_CMtqBR6ukyUw==(#=zKFlJyLE=);
		this.#=zAsCgbAN02olKpq2GjA==(0);
	}

	// Token: 0x060003B9 RID: 953 RVA: 0x0002117C File Offset: 0x0001F37C
	public string #=zHXS2On1IrCDk()
	{
		return this.#=zGJxu9Ui_Ym3M9VdyaEPo1lc=;
	}

	// Token: 0x060003BA RID: 954 RVA: 0x00021184 File Offset: 0x0001F384
	public void #=zgZ2Z53kGvTF4(string #=z$Ib9gYQ=)
	{
		this.#=zGJxu9Ui_Ym3M9VdyaEPo1lc= = #=z$Ib9gYQ=;
	}

	// Token: 0x060003BB RID: 955 RVA: 0x00021190 File Offset: 0x0001F390
	public string #=zTqDBdc7DKJmY()
	{
		return this.#=zHmMuYQbBjidCBK_H6A==;
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00021198 File Offset: 0x0001F398
	public void #=zn60ui3ChU5Yk(string #=z$Ib9gYQ=)
	{
		this.#=zHmMuYQbBjidCBK_H6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060003BD RID: 957 RVA: 0x000211A4 File Offset: 0x0001F3A4
	public int #=zO1FX6YkNZlqlvFZqJg==()
	{
		return this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;
	}

	// Token: 0x060003BE RID: 958 RVA: 0x000211AC File Offset: 0x0001F3AC
	public void #=zAsCgbAN02olKpq2GjA==(int #=z$Ib9gYQ=)
	{
		this.#=zkIDD5KOz_oJkQTLXHadOASpf_Ktk = #=z$Ib9gYQ=;
	}

	// Token: 0x060003BF RID: 959 RVA: 0x000211B8 File Offset: 0x0001F3B8
	public int #=zxWJWBWxyVjKWhkQ0ywNvzKs=()
	{
		return this.#=zRS6JqBEKTbnP4uLsWpzLmEw4_zWm;
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x000211C0 File Offset: 0x0001F3C0
	public void #=zZSkNRUgj8yXAH6_cQElO$6Y=(int #=z$Ib9gYQ=)
	{
		this.#=zRS6JqBEKTbnP4uLsWpzLmEw4_zWm = #=z$Ib9gYQ=;
	}

	// Token: 0x060003C1 RID: 961 RVA: 0x000211CC File Offset: 0x0001F3CC
	public string #=zj661vGqZTMsoJ4JrPg==()
	{
		return this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1;
	}

	// Token: 0x060003C2 RID: 962 RVA: 0x000211D4 File Offset: 0x0001F3D4
	public void #=z6AhOmwNDely78tSumg==(string #=z$Ib9gYQ=)
	{
		this.#=zmNuFeIk1PExEPxrcVomfAICh_vk1 = #=z$Ib9gYQ=;
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x000211E0 File Offset: 0x0001F3E0
	public int #=zw10jEpGax3aM3DGZDfjgXOQ=()
	{
		return this.#=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe;
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x000211E8 File Offset: 0x0001F3E8
	public void #=zL1nSSuED6_G9CQfsch1Gzg0=(int #=z$Ib9gYQ=)
	{
		this.#=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe = #=z$Ib9gYQ=;
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x000211F4 File Offset: 0x0001F3F4
	public int #=zTaNnMMVkGUSWqea4iYYvripNAQdU()
	{
		return this.#=zWV08wFPg1btCoKBirqOtYBxkAW1hRj4uZ6AT3dQ=;
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x000211FC File Offset: 0x0001F3FC
	public void #=zBtU0oqFKR8zKww67yQxSBhTpjdEV(int #=z$Ib9gYQ=)
	{
		this.#=zWV08wFPg1btCoKBirqOtYBxkAW1hRj4uZ6AT3dQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x060003C7 RID: 967 RVA: 0x00021208 File Offset: 0x0001F408
	public string #=zq9Z3UfxRng$ow$YiwbNmJtQ=()
	{
		int num = this.#=zw10jEpGax3aM3DGZDfjgXOQ=();
		string #=zcpJ6bUA=;
		if (num <= 45)
		{
			if (num <= 20)
			{
				if (num == 10)
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862274);
					goto IL_105;
				}
				if (num == 20)
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862258);
					goto IL_105;
				}
			}
			else
			{
				if (num == 30)
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862240);
					goto IL_105;
				}
				if (num == 40)
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862231);
					goto IL_105;
				}
				if (num == 45)
				{
					#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862463);
					goto IL_105;
				}
			}
		}
		else if (num <= 60)
		{
			if (num == 50)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862434);
				goto IL_105;
			}
			if (num == 55)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862418);
				goto IL_105;
			}
			if (num == 60)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862412);
				goto IL_105;
			}
		}
		else
		{
			if (num == 70)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862386);
				goto IL_105;
			}
			if (num == 80)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862370);
				goto IL_105;
			}
			if (num == 90)
			{
				#=zcpJ6bUA= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908862354);
				goto IL_105;
			}
		}
		#=zcpJ6bUA= = string.Empty;
		IL_105:
		return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zcpJ6bUA=);
	}

	// Token: 0x0400014F RID: 335
	private string #=zGJxu9Ui_Ym3M9VdyaEPo1lc=;

	// Token: 0x04000150 RID: 336
	private string #=zHmMuYQbBjidCBK_H6A==;

	// Token: 0x04000151 RID: 337
	private int #=zkIDD5KOz_oJkQTLXHadOASpf_Ktk;

	// Token: 0x04000152 RID: 338
	private int #=zRS6JqBEKTbnP4uLsWpzLmEw4_zWm;

	// Token: 0x04000153 RID: 339
	private string #=zmNuFeIk1PExEPxrcVomfAICh_vk1;

	// Token: 0x04000154 RID: 340
	private int #=zPtnIQbeKZj21ZpWqeBcSvu4a5fwe;

	// Token: 0x04000155 RID: 341
	private int #=zWV08wFPg1btCoKBirqOtYBxkAW1hRj4uZ6AT3dQ=;
}
