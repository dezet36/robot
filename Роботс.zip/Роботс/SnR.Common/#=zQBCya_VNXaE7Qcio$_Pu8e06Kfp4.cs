﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

// Token: 0x02000188 RID: 392
internal sealed class #=zQBCya_VNXaE7Qcio$_Pu8e06Kfp4
{
	// Token: 0x06000B2D RID: 2861 RVA: 0x000563A8 File Offset: 0x000545A8
	public Encoding #=zr0UgkCOqbu$s()
	{
		return this.#=zWlVRS0RCZxffG6mHnA==;
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x000563B0 File Offset: 0x000545B0
	public void #=zk_HcutVoOsuQ(Encoding #=z$Ib9gYQ=)
	{
		this.#=zWlVRS0RCZxffG6mHnA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B2F RID: 2863 RVA: 0x000563BC File Offset: 0x000545BC
	public string #=zUorwLJaGMjZ6()
	{
		return this.#=ztGkYdBMlSPtDf7xjyA==;
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x000563C4 File Offset: 0x000545C4
	public void #=zJgSvWYozGNUy(string #=z$Ib9gYQ=)
	{
		this.#=ztGkYdBMlSPtDf7xjyA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x000563D0 File Offset: 0x000545D0
	public HttpStatusCode #=z9ZHUN$Y=()
	{
		return this.#=zZqJ39hEu7SS_bez5Ag==;
	}

	// Token: 0x06000B32 RID: 2866 RVA: 0x000563D8 File Offset: 0x000545D8
	public void #=zbrtvpkQ=(HttpStatusCode #=z$Ib9gYQ=)
	{
		this.#=zZqJ39hEu7SS_bez5Ag== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B33 RID: 2867 RVA: 0x000563E4 File Offset: 0x000545E4
	public Dictionary<string, string> #=z5aV1tF47CwIR()
	{
		return this.#=zo7wcrmkeg5ySbOxEOw==;
	}

	// Token: 0x06000B34 RID: 2868 RVA: 0x000563EC File Offset: 0x000545EC
	public void #=zU_xQHn4tKaS4(Dictionary<string, string> #=z$Ib9gYQ=)
	{
		this.#=zo7wcrmkeg5ySbOxEOw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B35 RID: 2869 RVA: 0x000563F8 File Offset: 0x000545F8
	public string #=z0KhF75_5Qux2()
	{
		return this.#=zWoq968uVg8VPo6IAAQ==;
	}

	// Token: 0x06000B36 RID: 2870 RVA: 0x00056400 File Offset: 0x00054600
	public void #=zLJA68V6kgd4y(string #=z$Ib9gYQ=)
	{
		this.#=zWoq968uVg8VPo6IAAQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B37 RID: 2871 RVA: 0x0005640C File Offset: 0x0005460C
	public string #=z37JbfhBQfNof()
	{
		return this.#=zU$cJ2IT6vqI12uxV7g==;
	}

	// Token: 0x06000B38 RID: 2872 RVA: 0x00056414 File Offset: 0x00054614
	public void #=zegbyLruW1Ya2(string #=z$Ib9gYQ=)
	{
		this.#=zU$cJ2IT6vqI12uxV7g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000B39 RID: 2873 RVA: 0x00056420 File Offset: 0x00054620
	public string #=zo1_wEK0h2ir8(string #=zMH5y1Xo=)
	{
		string b = #=zMH5y1Xo=.ToLower();
		foreach (string text in this.#=z5aV1tF47CwIR().Keys)
		{
			if (text.ToLower() == b)
			{
				return this.#=z5aV1tF47CwIR()[text];
			}
		}
		return null;
	}

	// Token: 0x040005FA RID: 1530
	private Encoding #=zWlVRS0RCZxffG6mHnA==;

	// Token: 0x040005FB RID: 1531
	private string #=ztGkYdBMlSPtDf7xjyA==;

	// Token: 0x040005FC RID: 1532
	private HttpStatusCode #=zZqJ39hEu7SS_bez5Ag==;

	// Token: 0x040005FD RID: 1533
	private Dictionary<string, string> #=zo7wcrmkeg5ySbOxEOw==;

	// Token: 0x040005FE RID: 1534
	private string #=zWoq968uVg8VPo6IAAQ==;

	// Token: 0x040005FF RID: 1535
	private string #=zU$cJ2IT6vqI12uxV7g==;
}
