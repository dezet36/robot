﻿using System;
using Skink.SnR.Common.Tasks;

// Token: 0x02000207 RID: 519
internal sealed class #=zbL7n$53iGUBjdarp3LrY4L8XPgRHrxa87s2dT7Xho4eU$xwhLbiWYMlSoGCa : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001000 RID: 4096 RVA: 0x0007BC10 File Offset: 0x00079E10
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
	}

	// Token: 0x06001001 RID: 4097 RVA: 0x0007BC14 File Offset: 0x00079E14
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==))
		{
			return;
		}
		#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg== = (#=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==)this.#=zcDRV51Ut$7oP;
		#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobbery);
		#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null) ? #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=z5_3JqsL118hV() : #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGV9CLmCENINvspF3MQ==(this.#=z8StzeqE=, this.#=zBsXSanI=);
		#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==.#=z4jMUBqOjoL$2(this.#=z8StzeqE=, #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==.#=zs6AfR9w58BN2() == 1);
		if (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= != null)
		{
			#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=.#=zGSYXNAWR258T(0);
			return;
		}
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGncKSH4oJhxW9OLT6A==(#=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ==, this.#=z8StzeqE=);
	}
}
