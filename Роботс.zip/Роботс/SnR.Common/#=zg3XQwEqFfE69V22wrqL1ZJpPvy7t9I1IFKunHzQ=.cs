﻿using System;

// Token: 0x02000242 RID: 578
internal sealed class #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=
{
	// Token: 0x060011A1 RID: 4513 RVA: 0x00089B88 File Offset: 0x00087D88
	public #=zg3XQwEqFfE69V22wrqL1ZJpPvy7t9I1IFKunHzQ=(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=z6QPrZ_4=, int #=zXHTER4Q=)
	{
		this.#=zwXKUV2c=(#=z6QPrZ_4=);
		this.#=z6LUCX1zMpXIf(#=zXHTER4Q=);
	}

	// Token: 0x060011A2 RID: 4514 RVA: 0x00089BA0 File Offset: 0x00087DA0
	public #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zkfqcY3I=()
	{
		return this.#=zWd4PtJyWoTk_ZThs2A==;
	}

	// Token: 0x060011A3 RID: 4515 RVA: 0x00089BA8 File Offset: 0x00087DA8
	public void #=zwXKUV2c=(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=z$Ib9gYQ=)
	{
		this.#=zWd4PtJyWoTk_ZThs2A== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011A4 RID: 4516 RVA: 0x00089BB4 File Offset: 0x00087DB4
	public int #=z2UCBrfce7z8r()
	{
		return this.#=z$67euFAUnKwkyTDxKw==;
	}

	// Token: 0x060011A5 RID: 4517 RVA: 0x00089BBC File Offset: 0x00087DBC
	public void #=z6LUCX1zMpXIf(int #=z$Ib9gYQ=)
	{
		this.#=z$67euFAUnKwkyTDxKw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011A6 RID: 4518 RVA: 0x00089BC8 File Offset: 0x00087DC8
	public void #=z48rEd0A=(int #=zXHTER4Q=)
	{
		this.#=z6LUCX1zMpXIf(this.#=z2UCBrfce7z8r() + #=zXHTER4Q=);
	}

	// Token: 0x040009E4 RID: 2532
	private #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zWd4PtJyWoTk_ZThs2A==;

	// Token: 0x040009E5 RID: 2533
	private int #=z$67euFAUnKwkyTDxKw==;
}
