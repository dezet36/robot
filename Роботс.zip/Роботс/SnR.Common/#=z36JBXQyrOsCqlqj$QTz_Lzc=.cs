﻿using System;
using System.Collections;
using System.Text;
using common;

// Token: 0x0200004C RID: 76
internal abstract class #=z36JBXQyrOsCqlqj$QTz_Lzc= : #=zrACqpkJvpkMu2ypmK4UXXdQ=
{
	// Token: 0x06000246 RID: 582 RVA: 0x000158E4 File Offset: 0x00013AE4
	protected internal #=z36JBXQyrOsCqlqj$QTz_Lzc=()
	{
	}

	// Token: 0x06000247 RID: 583 RVA: 0x000158EC File Offset: 0x00013AEC
	internal override int #=zXiDCyaHY58$0()
	{
		Assert.verify(false);
		return 0;
	}

	// Token: 0x06000248 RID: 584 RVA: 0x000158F8 File Offset: 0x00013AF8
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		Assert.verify(false);
		return null;
	}

	// Token: 0x06000249 RID: 585
	internal abstract #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zZAPsYpRBEGf_();

	// Token: 0x0600024A RID: 586
	internal abstract #=zrACqpkJvpkMu2ypmK4UXXdQ= #=zlyKJojCmkfuG();

	// Token: 0x0600024B RID: 587 RVA: 0x00015904 File Offset: 0x00013B04
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		Assert.verify(false);
	}

	// Token: 0x0600024C RID: 588 RVA: 0x0001590C File Offset: 0x00013B0C
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		Assert.verify(false);
	}

	// Token: 0x0600024D RID: 589 RVA: 0x00015914 File Offset: 0x00013B14
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		Assert.verify(false);
	}

	// Token: 0x0600024E RID: 590 RVA: 0x0001591C File Offset: 0x00013B1C
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		Assert.verify(false);
	}

	// Token: 0x0600024F RID: 591 RVA: 0x00015924 File Offset: 0x00013B24
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		Assert.verify(false);
	}

	// Token: 0x06000250 RID: 592 RVA: 0x0001592C File Offset: 0x00013B2C
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		Assert.verify(false);
	}

	// Token: 0x06000251 RID: 593 RVA: 0x00015934 File Offset: 0x00013B34
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		Assert.verify(false);
	}
}
