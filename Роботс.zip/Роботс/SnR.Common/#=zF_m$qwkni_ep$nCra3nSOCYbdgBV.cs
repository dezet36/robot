﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000F2 RID: 242
internal sealed class #=zF_m$qwkni_ep$nCra3nSOCYbdgBV
{
	// Token: 0x0600064A RID: 1610 RVA: 0x000327A4 File Offset: 0x000309A4
	public #=zF_m$qwkni_ep$nCra3nSOCYbdgBV(Dictionary<string, object> #=zTUb1WaU=, #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== #=zC7NDbDM=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractInt(#=zTUb1WaU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zzQwUIEs=(#=zC7NDbDM=.#=zd634hMCtcd$T(JSONManager.ExtractInt(#=zTUb1WaU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0)));
		this.#=zhkEwduXK4AJ6((#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw=)JSONManager.GetInt(#=zTUb1WaU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070032), 0));
		this.#=zegiMUQR6gDJUR$lOVQ==(JSONManager.GetDateTime(#=zTUb1WaU=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070030), false));
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x00032824 File Offset: 0x00030A24
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x0003282C File Offset: 0x00030A2C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x00032838 File Offset: 0x00030A38
	public #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x00032840 File Offset: 0x00030A40
	public void #=zzQwUIEs=(#=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x0003284C File Offset: 0x00030A4C
	public string #=zkfqcY3I=()
	{
		return this.#=zq2bPTdY=().#=zkfqcY3I=();
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x0003285C File Offset: 0x00030A5C
	public #=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw= #=zi66ZCDXN_8bo()
	{
		return this.#=ztDDvs041_yK6QS4oWQ==;
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x00032864 File Offset: 0x00030A64
	public void #=zhkEwduXK4AJ6(#=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw= #=z$Ib9gYQ=)
	{
		this.#=ztDDvs041_yK6QS4oWQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00032870 File Offset: 0x00030A70
	public DateTime #=zM9ux$svU_qlRnylQMQ==()
	{
		return this.#=zDcCgdF8bY8ebB5PhHcJOozE=;
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x00032878 File Offset: 0x00030A78
	public void #=zegiMUQR6gDJUR$lOVQ==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zDcCgdF8bY8ebB5PhHcJOozE= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000298 RID: 664
	public static int #=zsDT9OIOutcCTJVL9cA== = 2;

	// Token: 0x04000299 RID: 665
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400029A RID: 666
	private #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x0400029B RID: 667
	private #=zF_m$qwkni_ep$nCra3nSOCYbdgBV.#=zbGFpMLw= #=ztDDvs041_yK6QS4oWQ==;

	// Token: 0x0400029C RID: 668
	private DateTime #=zDcCgdF8bY8ebB5PhHcJOozE=;

	// Token: 0x020000F3 RID: 243
	public enum #=zbGFpMLw=
	{

	}
}
