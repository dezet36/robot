﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020001D2 RID: 466
internal sealed class #=zX8yC7RnVbFRg1JrW_W26WK6gVt0OMcFmf3yWwXbxrEnDgI5y6A== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000E0C RID: 3596 RVA: 0x00070E88 File Offset: 0x0006F088
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zB$o5bdf2JMShix1hlL___F0= = #=zuJjQ1XU=.#=zn3lmtbueoIUfikFOI78eK$8=();
	}

	// Token: 0x06000E0D RID: 3597 RVA: 0x00070EB0 File Offset: 0x0006F0B0
	protected override void #=zvb5bnug=()
	{
		List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> list = this.#=zB$o5bdf2JMShix1hlL___F0=;
		#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = null;
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in list)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zL4D9WC8RTH921DofgQ==() == DateTime.MinValue && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3)
			{
				#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2;
				break;
			}
		}
		if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== == null)
		{
			if (!string.IsNullOrEmpty(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationArmyId))
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationArmyId = null;
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LastOccupationBreakAttemptTime = null;
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878253), Array.Empty<object>());
				return;
			}
		}
		else
		{
			bool flag = false;
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationArmyId != #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=().ToString())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878228), Array.Empty<object>());
				flag = true;
			}
			else if (JSONManager.DecodeTime(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LastOccupationBreakAttemptTime, false) + TimeSpan.FromHours(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationBreakIntervalHours) < DateTime.Now)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877914), Array.Empty<object>());
				flag = true;
			}
			else
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878064), Array.Empty<object>());
			}
			if (flag)
			{
				UnitSquadCollection unitSquadCollection = new UnitSquadCollection();
				foreach (UnitSquad unitSquad in this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo)
				{
					if (unitSquad.Number >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationBreakUnits && unitSquad.Type.Function == UnitType.Functions.Offence && unitSquad.Type.Class == UnitType.Classes.LightInfantry && unitSquad.Type.Categories_HasNoneBut(new UnitType.Categories[]
					{
						UnitType.Categories.m_Elite,
						UnitType.Categories.r_Free
					}))
					{
						unitSquadCollection.Add(new UnitSquad(unitSquad.Type, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationBreakUnits));
						break;
					}
				}
				if (unitSquadCollection.Count > 0)
				{
					string text = this.#=zBsXSanI=.#=zWYvEC7HhMxBOcSI89TZRLg0=(this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), null, unitSquadCollection, 0);
					if (text.Length > 10000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878015), new object[]
						{
							unitSquadCollection.ToStringLabels()
						});
						this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection);
						this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection);
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908877965), new object[]
						{
							unitSquadCollection.ToStringLabels(),
							text
						});
					}
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().OccupationArmyId = #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z$lI_VTM=().ToString();
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().LastOccupationBreakAttemptTime = JSONManager.EncodeTime(DateTime.Now, false);
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908879688), Array.Empty<object>());
			}
		}
	}

	// Token: 0x040007E1 RID: 2017
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x040007E2 RID: 2018
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x040007E3 RID: 2019
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zB$o5bdf2JMShix1hlL___F0=;
}
