﻿using System;

// Token: 0x02000235 RID: 565
internal static class #=zetVTzoUFoGvLK6mdrc866PPlONBUDEz7EF5B8mBSOSVD
{
	// Token: 0x0400095D RID: 2397
	internal static readonly int[] #=zmWx_sTaa2o8wgxHBZw== = new int[]
	{
		0,
		1,
		3,
		7,
		15,
		31,
		63,
		127,
		255,
		511,
		1023,
		2047,
		4095,
		8191,
		16383,
		32767,
		65535
	};
}
