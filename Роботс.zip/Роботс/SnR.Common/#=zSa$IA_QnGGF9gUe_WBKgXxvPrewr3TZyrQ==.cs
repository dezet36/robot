﻿using System;
using Skink.SnR.Common.City;

// Token: 0x020001A1 RID: 417
internal sealed class #=zSa$IA_QnGGF9gUe_WBKgXxvPrewr3TZyrQ==
{
	// Token: 0x06000C4C RID: 3148 RVA: 0x00063A1C File Offset: 0x00061C1C
	public ResourceTypes #=ziXIUsXqcVZz_()
	{
		return this.#=zs6RsPpRPQit4GvJuJ5l2HCw=;
	}

	// Token: 0x06000C4D RID: 3149 RVA: 0x00063A24 File Offset: 0x00061C24
	public void #=zqIMvfJkiJpU0(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zs6RsPpRPQit4GvJuJ5l2HCw= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C4E RID: 3150 RVA: 0x00063A30 File Offset: 0x00061C30
	public ResourceTypes #=zfpJ8QMEsD58B()
	{
		return this.#=zGl571S$qGwULDAIWokQv3RE=;
	}

	// Token: 0x06000C4F RID: 3151 RVA: 0x00063A38 File Offset: 0x00061C38
	public void #=zJQFoA8xQqtwZ(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zGl571S$qGwULDAIWokQv3RE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C50 RID: 3152 RVA: 0x00063A44 File Offset: 0x00061C44
	public double #=zisvlKsvs85jd()
	{
		return this.#=zwrxFSXxdh_fTOBnHX1jxmt0=;
	}

	// Token: 0x06000C51 RID: 3153 RVA: 0x00063A4C File Offset: 0x00061C4C
	public void #=z2a_u_nRabC8z(double #=z$Ib9gYQ=)
	{
		this.#=zwrxFSXxdh_fTOBnHX1jxmt0= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000720 RID: 1824
	private ResourceTypes #=zs6RsPpRPQit4GvJuJ5l2HCw=;

	// Token: 0x04000721 RID: 1825
	private ResourceTypes #=zGl571S$qGwULDAIWokQv3RE=;

	// Token: 0x04000722 RID: 1826
	private double #=zwrxFSXxdh_fTOBnHX1jxmt0=;
}
