﻿using System;

// Token: 0x020001AE RID: 430
internal sealed class #=zUCFY4XfDhjO0V0C6PepmzBAj2dB9STInsOZulUcEt47u : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000CFD RID: 3325 RVA: 0x00067374 File Offset: 0x00065574
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=z7hSXlqExDIFT = #=zuJjQ1XU=.#=zvQRf_STy5v8Sm5tuw7Xh278usASc();
	}

	// Token: 0x06000CFE RID: 3326 RVA: 0x00067384 File Offset: 0x00065584
	protected override void #=zvb5bnug=()
	{
		#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5.#=zi1hFJwI=();
		#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = null;
		foreach (int #=zAk8mKBk= in this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonAbilitiesToUpgradeIds)
		{
			#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2 = this.#=z7hSXlqExDIFT.#=zk$6QZNA=(#=zAk8mKBk=);
			if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2 != null)
			{
				if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2.#=zvnZc$RhG_1Du() < #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2.#=zq2bPTdY=().#=zaDKBEnk8Vsod() && (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2.#=zq2bPTdY=().#=zVaUA5_qegiur() != 3 || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonMax3rdLevel <= 0 || #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2.#=zvnZc$RhG_1Du() < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().DragonMax3rdLevel))
				{
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN2;
					break;
				}
			}
			else
			{
				#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(#=zAk8mKBk=);
				if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW != null)
				{
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN3 = new #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN();
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN3.#=zzQwUIEs=(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW);
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN3.#=zFzGvi_S6jJhE(0);
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN3;
					break;
				}
			}
		}
		if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN != null)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980640), new object[]
			{
				#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=()
			});
			while (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh() > 0)
			{
				if (this.#=z7hSXlqExDIFT.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh()) != null)
				{
					IL_241:
					while (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=z5irrWqrwWHrPajKrZw==() > 0)
					{
						#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN4 = this.#=z7hSXlqExDIFT.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=z5irrWqrwWHrPajKrZw==());
						if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN4 != null)
						{
							if (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN4.#=zvnZc$RhG_1Du() < #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN4.#=zq2bPTdY=().#=zaDKBEnk8Vsod())
							{
								#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN4;
							}
							else
							{
								IL_2D3:
								while (#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh() > 0 && this.#=z7hSXlqExDIFT.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh()) == null)
								{
									#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW2 = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh());
									if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW2 != null)
									{
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN5 = new #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN();
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN5.#=zzQwUIEs=(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW2);
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN5.#=zFzGvi_S6jJhE(0);
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN5;
									}
									else
									{
										this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980334), new object[]
										{
											#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh()
										});
									}
								}
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980243), new object[]
								{
									#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=()
								});
								string text = this.#=zBsXSanI=.#=zrS14yt$Txd4pewSVwcZQ1JaFO7U$nnDS4g==(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zMuFMjGQ=());
								text = text.Trim();
								if (text.Length >= 10000)
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982252), new object[]
									{
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=(),
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zvnZc$RhG_1Du() + 1
									});
									return;
								}
								if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980453)))
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980415), new object[]
									{
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=(),
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zvnZc$RhG_1Du() + 1
									});
									return;
								}
								if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976435)))
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982127), new object[]
									{
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=(),
										#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zvnZc$RhG_1Du() + 1
									});
									return;
								}
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982052), new object[]
								{
									#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zkfqcY3I=(),
									#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zvnZc$RhG_1Du() + 1,
									text
								});
								return;
							}
						}
						else
						{
							#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW3 = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=z5irrWqrwWHrPajKrZw==());
							if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW3 != null)
							{
								#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN6 = new #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN();
								#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN6.#=zzQwUIEs=(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW3);
								#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN6.#=zFzGvi_S6jJhE(0);
								#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN6;
							}
							else
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980334), new object[]
								{
									#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh()
								});
							}
						}
					}
					goto IL_2D3;
				}
				#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW #=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW4 = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=zk$6QZNA=(#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh());
				if (#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW4 != null)
				{
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN7 = new #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN();
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN7.#=zzQwUIEs=(#=z1Yuowbsexo2tKq_o8FtRjRv3pePc7LBHAKhnoT8Jv_FW4);
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN7.#=zFzGvi_S6jJhE(0);
					#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN = #=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN7;
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908980334), new object[]
					{
						#=z19zG65VxnOgJKOw8oA_$ndG6rEx9vW0wjrzD9sg2DkUN.#=zq2bPTdY=().#=zkZNDu8up5Nuh()
					});
				}
			}
			goto IL_241;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908982200), Array.Empty<object>());
	}

	// Token: 0x04000778 RID: 1912
	private #=z2AqwjH44IoAjOpKYvnKgqrqVXTUu2U5xfTfXuUobmKc_ #=z7hSXlqExDIFT;
}
