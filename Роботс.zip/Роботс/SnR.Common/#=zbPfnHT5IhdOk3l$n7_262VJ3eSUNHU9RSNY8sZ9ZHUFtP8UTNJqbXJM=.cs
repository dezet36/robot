﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Tasks;
using Skink.SnR.Common.Units;

// Token: 0x02000208 RID: 520
internal sealed class #=zbPfnHT5IhdOk3l$n7_262VJ3eSUNHU9RSNY8sZ9ZHUFtP8UTNJqbXJM= : #=z0MYNW4JWALo_8U95iDe9_LuS1FMt1VNRIeHEi$Lu$8mUD3khcw==
{
	// Token: 0x06001003 RID: 4099 RVA: 0x0007BCA4 File Offset: 0x00079EA4
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		base.#=z20ohAjI=(#=zuJjQ1XU=);
		this.#=zNA3wycrO1gxV = #=zuJjQ1XU=.#=zw$fMJ65lvs2ECx153Q==();
		this.#=ziN8NUtQ= = #=zuJjQ1XU=.#=zZan5aKOWyPR5();
	}

	// Token: 0x06001004 RID: 4100 RVA: 0x0007BCC8 File Offset: 0x00079EC8
	protected override bool #=z5thIYRgpTTs8KNlZHQ==()
	{
		return base.#=z5thIYRgpTTs8KNlZHQ==() || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroopsTimeBoost;
	}

	// Token: 0x06001005 RID: 4101 RVA: 0x0007BCE4 File Offset: 0x00079EE4
	protected override void #=zvb5bnug=()
	{
		this.#=zKH4fronL4ey1dHCnfazYFyA=();
	}

	// Token: 0x06001006 RID: 4102 RVA: 0x0007BCEC File Offset: 0x00079EEC
	private void #=zKH4fronL4ey1dHCnfazYFyA=()
	{
		UnitTypeCollection #=zlhLE8UQVU0AG = UnitTypeCollection.Get();
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroops && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().VeorHiringPlan != null)
		{
			bool #=z8GAhfBs_fhwN = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroopsMultiple || (this.#=zcDRV51Ut$7oP.Options & TaskOptions.Cyclic) == TaskOptions.Cyclic;
			base.#=zANXaSexKcWE6QaKrzVUaQlM=(#=zlhLE8UQVU0AG, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().VeorHiringPlan, #=z8GAhfBs_fhwN, null, false);
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroopsTimeBoost && this.#=zZKzdsPms7IDM != null)
			{
				if (!string.IsNullOrEmpty(this.#=zFhEyBouv8Ijn4t019A==))
				{
					base.#=zL1HTbwC75LO$(this.#=zFhEyBouv8Ijn4t019A==);
				}
				if (this.#=zZKzdsPms7IDM.#=zL3JA$w7RjoU3Y7bfM2rOgkXWzpjiRIbUtw==(this.#=zvPVvZaDW5sGehlg4AA==, this.#=z3yL5bKs=, this.#=zNA3wycrO1gxV, this.#=ziN8NUtQ=) && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsVeorHireTroopsMultiple)
				{
					this.#=zcDRV51Ut$7oP.NextExecutionTime = DateTime.Now;
				}
			}
		}
	}

	// Token: 0x040008D8 RID: 2264
	private List<#=zm0Z_csmOCne$foR4D4lG8DFExnhm$SNw7g==> #=zNA3wycrO1gxV;

	// Token: 0x040008D9 RID: 2265
	private DateTime #=ziN8NUtQ=;
}
