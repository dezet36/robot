﻿// Token: 0x020001FF RID: 511
internal sealed partial class #=zanGez1y6ixXU2ZoYLARJoROLRVz3eGwc9IcUDyA= : global::System.Windows.Forms.Form
{
	// Token: 0x06000FB1 RID: 4017 RVA: 0x0007A7FC File Offset: 0x000789FC
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x040008AD RID: 2221
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
