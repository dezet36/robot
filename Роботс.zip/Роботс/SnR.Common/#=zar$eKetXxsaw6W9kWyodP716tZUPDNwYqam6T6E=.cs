﻿using System;

// Token: 0x02000204 RID: 516
internal sealed class #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=
{
	// Token: 0x06000FD0 RID: 4048 RVA: 0x0007B580 File Offset: 0x00079780
	public #=zar$eKetXxsaw6W9kWyodP716tZUPDNwYqam6T6E=(Guid #=zAk8mKBk=, int #=zvPiOyGQ=, string #=zYEWEW3Orb0v1, #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z3v_Pt336Xf0A, int #=z9e4VniQ=)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=z_MMDqXnekqn_(#=zvPiOyGQ=);
		this.#=zkSJVJVV8nRz7(#=zYEWEW3Orb0v1);
		this.#=zLwHDcYFPPsYN(#=z3v_Pt336Xf0A);
		this.#=ziTN2FZmq8TpP(#=z9e4VniQ=);
		this.#=zHQopOEXFlU$wegdg7g==(false);
		this.#=zUn4qbBk$AaeQ(0);
		this.#=zSUCWEnKUzUex(DateTime.MinValue);
		this.#=zV6Dquhr54Is2(0);
		this.#=z5EKKr48gTsJaScefJw==(DateTime.MinValue);
		this.#=zS5uus3Bg_NuG(false);
	}

	// Token: 0x06000FD1 RID: 4049 RVA: 0x0007B5EC File Offset: 0x000797EC
	public Guid #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000FD2 RID: 4050 RVA: 0x0007B5F4 File Offset: 0x000797F4
	public void #=zbsxKkj4=(Guid #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FD3 RID: 4051 RVA: 0x0007B600 File Offset: 0x00079800
	public int #=zEpmJu0QO9VH_()
	{
		return this.#=zv1cPvddGDW17yRoN6A==;
	}

	// Token: 0x06000FD4 RID: 4052 RVA: 0x0007B608 File Offset: 0x00079808
	public void #=z_MMDqXnekqn_(int #=z$Ib9gYQ=)
	{
		this.#=zv1cPvddGDW17yRoN6A== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FD5 RID: 4053 RVA: 0x0007B614 File Offset: 0x00079814
	public string #=z9Yordw6ZFjQe()
	{
		return this.#=zvSOO0qmN6tcT_pnNfw==;
	}

	// Token: 0x06000FD6 RID: 4054 RVA: 0x0007B61C File Offset: 0x0007981C
	public void #=zkSJVJVV8nRz7(string #=z$Ib9gYQ=)
	{
		this.#=zvSOO0qmN6tcT_pnNfw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FD7 RID: 4055 RVA: 0x0007B628 File Offset: 0x00079828
	public #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zvx02C9X4TUpz()
	{
		return this.#=zUHb$6MEqcpMvyqXxM$UD4NA=;
	}

	// Token: 0x06000FD8 RID: 4056 RVA: 0x0007B630 File Offset: 0x00079830
	public void #=zLwHDcYFPPsYN(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=z$Ib9gYQ=)
	{
		this.#=zUHb$6MEqcpMvyqXxM$UD4NA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FD9 RID: 4057 RVA: 0x0007B63C File Offset: 0x0007983C
	public int #=zXAysPE5a2IRR()
	{
		return this.#=z5m4bdSqChVaoeuHomg==;
	}

	// Token: 0x06000FDA RID: 4058 RVA: 0x0007B644 File Offset: 0x00079844
	public void #=ziTN2FZmq8TpP(int #=z$Ib9gYQ=)
	{
		this.#=z5m4bdSqChVaoeuHomg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FDB RID: 4059 RVA: 0x0007B650 File Offset: 0x00079850
	public bool #=z7Ss1uIfnRw1fbvsZpg==()
	{
		return this.#=zXJicIU0ABqZfBShhJang$A7C5k4z;
	}

	// Token: 0x06000FDC RID: 4060 RVA: 0x0007B658 File Offset: 0x00079858
	public void #=zHQopOEXFlU$wegdg7g==(bool #=z$Ib9gYQ=)
	{
		this.#=zXJicIU0ABqZfBShhJang$A7C5k4z = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FDD RID: 4061 RVA: 0x0007B664 File Offset: 0x00079864
	public int #=zN3pqKKv6fQGP()
	{
		return this.#=zCZH2ABDJUdioH1GoKNcdJcM=;
	}

	// Token: 0x06000FDE RID: 4062 RVA: 0x0007B66C File Offset: 0x0007986C
	public void #=zUn4qbBk$AaeQ(int #=z$Ib9gYQ=)
	{
		this.#=zCZH2ABDJUdioH1GoKNcdJcM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FDF RID: 4063 RVA: 0x0007B678 File Offset: 0x00079878
	public DateTime #=zyoX988soxa4C()
	{
		return this.#=zE53uJoA3LDt9u6gHs$SSNZQ=;
	}

	// Token: 0x06000FE0 RID: 4064 RVA: 0x0007B680 File Offset: 0x00079880
	public void #=zSUCWEnKUzUex(DateTime #=z$Ib9gYQ=)
	{
		this.#=zE53uJoA3LDt9u6gHs$SSNZQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FE1 RID: 4065 RVA: 0x0007B68C File Offset: 0x0007988C
	public int #=z8UpTpY7EO8gZ()
	{
		return this.#=zG9oAlubBX7KGAAyyOA5uKA0=;
	}

	// Token: 0x06000FE2 RID: 4066 RVA: 0x0007B694 File Offset: 0x00079894
	public void #=zV6Dquhr54Is2(int #=z$Ib9gYQ=)
	{
		this.#=zG9oAlubBX7KGAAyyOA5uKA0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FE3 RID: 4067 RVA: 0x0007B6A0 File Offset: 0x000798A0
	public DateTime #=z4iM29j0EtduuG84aag==()
	{
		return this.#=z_M__UD$s6PkuCO$DZCtRVlE=;
	}

	// Token: 0x06000FE4 RID: 4068 RVA: 0x0007B6A8 File Offset: 0x000798A8
	public void #=z5EKKr48gTsJaScefJw==(DateTime #=z$Ib9gYQ=)
	{
		this.#=z_M__UD$s6PkuCO$DZCtRVlE= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FE5 RID: 4069 RVA: 0x0007B6B4 File Offset: 0x000798B4
	public bool #=zosN4hoVyBAOs()
	{
		return this.#=zaFZUECPzOjLIRd12Tg==;
	}

	// Token: 0x06000FE6 RID: 4070 RVA: 0x0007B6BC File Offset: 0x000798BC
	public void #=zS5uus3Bg_NuG(bool #=z$Ib9gYQ=)
	{
		this.#=zaFZUECPzOjLIRd12Tg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000FE7 RID: 4071 RVA: 0x0007B6C8 File Offset: 0x000798C8
	public bool #=zrNIiQ09PozZW(int #=zvPiOyGQ=)
	{
		if (this.#=zosN4hoVyBAOs())
		{
			return true;
		}
		if (this.#=z8UpTpY7EO8gZ() > 1)
		{
			if (!(this.#=z4iM29j0EtduuG84aag==() < DateTime.Now))
			{
				return true;
			}
			this.#=zV6Dquhr54Is2(0);
		}
		if (this.#=zN3pqKKv6fQGP() > 0 && this.#=zN3pqKKv6fQGP() != #=zvPiOyGQ=)
		{
			if (!(this.#=zyoX988soxa4C() < DateTime.Now))
			{
				return true;
			}
			this.#=zUn4qbBk$AaeQ(0);
		}
		return false;
	}

	// Token: 0x06000FE8 RID: 4072 RVA: 0x0007B738 File Offset: 0x00079938
	public override string ToString()
	{
		return string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943016), this.#=zvx02C9X4TUpz().Name, this.#=zXAysPE5a2IRR(), this.#=z9Yordw6ZFjQe());
	}

	// Token: 0x040008C3 RID: 2243
	private Guid #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x040008C4 RID: 2244
	private int #=zv1cPvddGDW17yRoN6A==;

	// Token: 0x040008C5 RID: 2245
	private string #=zvSOO0qmN6tcT_pnNfw==;

	// Token: 0x040008C6 RID: 2246
	private #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zUHb$6MEqcpMvyqXxM$UD4NA=;

	// Token: 0x040008C7 RID: 2247
	private int #=z5m4bdSqChVaoeuHomg==;

	// Token: 0x040008C8 RID: 2248
	private bool #=zXJicIU0ABqZfBShhJang$A7C5k4z;

	// Token: 0x040008C9 RID: 2249
	private int #=zCZH2ABDJUdioH1GoKNcdJcM=;

	// Token: 0x040008CA RID: 2250
	private DateTime #=zE53uJoA3LDt9u6gHs$SSNZQ=;

	// Token: 0x040008CB RID: 2251
	private int #=zG9oAlubBX7KGAAyyOA5uKA0=;

	// Token: 0x040008CC RID: 2252
	private DateTime #=z_M__UD$s6PkuCO$DZCtRVlE=;

	// Token: 0x040008CD RID: 2253
	private bool #=zaFZUECPzOjLIRd12Tg==;
}
