﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;

// Token: 0x020001D1 RID: 465
internal sealed class #=zX8yC7RnVbFRg1JrW_W26WDdlNK_APxBPDMLH7I$_5ejEfnwaQ_CQfLiovBcN : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000E09 RID: 3593 RVA: 0x00070C1C File Offset: 0x0006EE1C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
	}

	// Token: 0x06000E0A RID: 3594 RVA: 0x00070C2C File Offset: 0x0006EE2C
	protected override void #=zvb5bnug=()
	{
		Dictionary<ResourceTypes, int> dictionary = new Dictionary<ResourceTypes, int>();
		dictionary[ResourceTypes.Bronze] = 0;
		dictionary[ResourceTypes.Lumber] = 0;
		foreach (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= in this.#=zCY4az9$WUjLsEJ7fgg==.Values)
		{
			if (#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)2010 && dictionary.ContainsKey(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zQ4pGtq_Ng_rixBGQrQ==()))
			{
				Dictionary<ResourceTypes, int> dictionary2 = dictionary;
				ResourceTypes key = #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zQ4pGtq_Ng_rixBGQrQ==();
				dictionary2[key] += (int)#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zq2bPTdY=().#=zjw43QGFcPyHH() * #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=.#=zlIXJ9$NfUZc_();
			}
		}
		#=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc= = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.#=zi1hFJwI=();
		for (int i = 1; i < 100; i++)
		{
			ResourceTypes resourceTypes = ResourceTypes.Bronze;
			int num = int.MaxValue;
			foreach (ResourceTypes resourceTypes2 in dictionary.Keys)
			{
				if (dictionary[resourceTypes2] < num)
				{
					resourceTypes = resourceTypes2;
					num = dictionary[resourceTypes2];
				}
			}
			#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = null;
			for (int j = 0; j < #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=.Count; j++)
			{
				#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2 = #=znZRejen0zjMBxg3LuEdiVAxTzkVZSF1AOf92goc=[j];
				if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=z9gSOax4=() == (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zj19KhTM=)2010 && #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zQ4pGtq_Ng_rixBGQrQ==() == resourceTypes && !#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zJVAdIDg9hSidub8$Uw==())
				{
					if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= == null)
					{
						#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2;
					}
					else if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2.#=zjw43QGFcPyHH() > #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zjw43QGFcPyHH())
					{
						#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= = #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=2;
					}
				}
			}
			if (#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= != null)
			{
				string text = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zMuFMjGQ=(), 1, false);
				if (text.Length <= 10000)
				{
					text = JSONManager.Cut(text);
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924077), new object[]
					{
						#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zkfqcY3I=(),
						text
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908924118), new object[]
				{
					#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zkfqcY3I=()
				});
				Dictionary<ResourceTypes, int> dictionary2 = dictionary;
				ResourceTypes key = resourceTypes;
				dictionary2[key] += (int)#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4=.#=zjw43QGFcPyHH();
			}
		}
	}

	// Token: 0x040007E0 RID: 2016
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;
}
