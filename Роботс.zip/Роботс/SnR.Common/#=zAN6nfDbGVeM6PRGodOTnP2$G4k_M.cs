﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x020000B9 RID: 185
internal sealed class #=zAN6nfDbGVeM6PRGodOTnP2$G4k_M : #=zk0bxu_9ri56pLWrVZ_xFGIw=, DateCell, Cell, FormulaData, DateFormulaCell, FormulaCell
{
	// Token: 0x060004E7 RID: 1255 RVA: 0x0002808C File Offset: 0x0002628C
	public #=zAN6nfDbGVeM6PRGodOTnP2$G4k_M(#=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, bool #=z1xdZb6s=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zJce$Sys=.XFIndex, #=zrRXQAB8=, #=z1xdZb6s=, #=z99eVqbg=)
	{
		this.#=z$qdebj6dfyrP = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
		this.#=zJ5GWysk= = #=zJce$Sys=.getFormulaData();
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060004E8 RID: 1256 RVA: 0x000280BC File Offset: 0x000262BC
	public override CellType Type
	{
		get
		{
			return CellType.DATE_FORMULA;
		}
	}

	// Token: 0x17000015 RID: 21
	// (get) Token: 0x060004E9 RID: 1257 RVA: 0x000280C4 File Offset: 0x000262C4
	public string Formula
	{
		get
		{
			if (this.#=z06z1muCn8UNxP0yekw== == null)
			{
				sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 16];
				Array.Copy(this.#=zJ5GWysk=, 16, array, 0, array.Length);
				FormulaParser formulaParser = new FormulaParser(array, this, this.#=z$qdebj6dfyrP, this.#=zLJGAifU=, this.#=zP5HMqyyjoirP().#=znmG_kF0igveL8fwbqw==().Settings);
				formulaParser.parse();
				this.#=z06z1muCn8UNxP0yekw== = formulaParser.Formula;
			}
			return this.#=z06z1muCn8UNxP0yekw==;
		}
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x00028138 File Offset: 0x00026338
	public NumberFormatInfo #=zt8qXUwrx6nIC()
	{
		return null;
	}

	// Token: 0x060004EB RID: 1259 RVA: 0x0002813C File Offset: 0x0002633C
	public sbyte[] getFormulaData()
	{
		return this.#=zJ5GWysk=;
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x00028144 File Offset: 0x00026344
	public double #=z1bSEHQ8=()
	{
		return this.#=zziO1gvU=;
	}

	// Token: 0x040001E1 RID: 481
	private double #=zziO1gvU=;

	// Token: 0x040001E2 RID: 482
	private string #=z06z1muCn8UNxP0yekw==;

	// Token: 0x040001E3 RID: 483
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x040001E4 RID: 484
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x040001E5 RID: 485
	private sbyte[] #=zJ5GWysk=;
}
