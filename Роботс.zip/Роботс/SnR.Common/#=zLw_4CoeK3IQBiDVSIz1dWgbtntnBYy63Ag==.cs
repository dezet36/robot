﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using OpenQA.Selenium;
using Skink.SnR.Common;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;

// Token: 0x0200015A RID: 346
internal sealed class #=zLw_4CoeK3IQBiDVSIz1dWgbtntnBYy63Ag== : #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==
{
	// Token: 0x06000930 RID: 2352 RVA: 0x0004A86C File Offset: 0x00048A6C
	private #=zLw_4CoeK3IQBiDVSIz1dWgbtntnBYy63Ag==()
	{
		this.#=z1oEF8gM= = GameApplicationData.#=z7wsmjLWw49AC();
		this.#=zSg73axlT2_0Z = GameApplicationData.#=zZ2dsDUeWDYAN();
	}

	// Token: 0x06000931 RID: 2353 RVA: 0x0004A88C File Offset: 0x00048A8C
	public #=zLw_4CoeK3IQBiDVSIz1dWgbtntnBYy63Ag==(GameApplicationData.GameHosters #=zFm0zVu_cMnGG, GameApplicationData.Games #=zlyzKs1MzFCwV)
	{
		this.#=z1oEF8gM= = #=zFm0zVu_cMnGG;
		this.#=zSg73axlT2_0Z = #=zlyzKs1MzFCwV;
	}

	// Token: 0x06000932 RID: 2354 RVA: 0x0004A8A4 File Offset: 0x00048AA4
	public static #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 #=z6i3mHuw=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, out string #=z143ZALc=)
	{
		return new #=zLw_4CoeK3IQBiDVSIz1dWgbtntnBYy63Ag==().#=zX1$yTVY=(#=zhoOF5s8=, out #=z143ZALc=, null, false, false);
	}

	// Token: 0x06000933 RID: 2355 RVA: 0x0004A8B8 File Offset: 0x00048AB8
	public static void #=zJbYvdjP7FN1U(List<#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ==> #=zEhGRLRSSQTM3nxmPHQ==)
	{
		foreach (#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8= in #=zEhGRLRSSQTM3nxmPHQ==)
		{
			string text;
			new #=zLw_4CoeK3IQBiDVSIz1dWgbtntnBYy63Ag==().#=zX1$yTVY=(#=zhoOF5s8=, out text, null, false, true);
		}
	}

	// Token: 0x06000934 RID: 2356 RVA: 0x0004A910 File Offset: 0x00048B10
	private #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 #=zX1$yTVY=(#=zJgdPtusdHGp1P1jrnKIg5CgTZ84ltOMhDQ== #=zhoOF5s8=, out string #=z143ZALc=, string #=zGDzCGRjAmWMe, bool #=zImOUMkABhtzu, bool #=zrgTTrYoszEKs)
	{
		string text = #=zhoOF5s8=.#=zh5Q$jgycqA15().#=zCCvotbi$42tS();
		string #=ze7ZtytQ= = #=zhoOF5s8=.#=zh5Q$jgycqA15().#=zNX$RlG6YBqR7();
		#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== = null;
		string path = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052919), text);
		if (File.Exists(path) && !#=zImOUMkABhtzu)
		{
			string text2 = File.ReadAllText(path);
			if (!string.IsNullOrEmpty(text2))
			{
				try
				{
					#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== = #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=z8jJCAkXvwc0s(text2);
				}
				catch (Exception #=zN_s5Z5A=)
				{
					#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Exception, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052884) + #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=), Array.Empty<object>());
				}
			}
		}
		#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 result;
		try
		{
			List<string> list = new List<string>();
			GameApplicationData.GameHosters gameHosters = this.#=z1oEF8gM=;
			if (gameHosters <= GameApplicationData.GameHosters.VKontakte)
			{
				switch (gameHosters)
				{
				case GameApplicationData.GameHosters.MyMail:
					list.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052844));
					break;
				case GameApplicationData.GameHosters.GamesMail:
				case (GameApplicationData.GameHosters)3:
					break;
				case GameApplicationData.GameHosters.Odnoklassniki:
					list.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052418));
					break;
				default:
					if (gameHosters == GameApplicationData.GameHosters.VKontakte)
					{
						list.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052279));
					}
					break;
				}
			}
			else if (gameHosters == GameApplicationData.GameHosters.PlariumRu || gameHosters == GameApplicationData.GameHosters.PlariumEn)
			{
				list.Add(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052378));
			}
			#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 #=z$_muzYvJ5U = base.#=z4HyKJ7m74sB_1gVqzA==(list);
			if (#=z$_muzYvJ5U != (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)1)
			{
				if (#=z$_muzYvJ5U == (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)2)
				{
					#=z143ZALc= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051996);
					result = #=z$_muzYvJ5U;
				}
				else
				{
					bool flag = false;
					string #=zVI_2r0M= = this.#=zPqA7VxdZI_AN();
					if (this.#=z1oEF8gM= == GameApplicationData.GameHosters.MyMail)
					{
						base.#=zPC48eGFZAOd4(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051936), 1);
						if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== != null)
						{
							base.#=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051915), true);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
							flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052151));
						}
						if (!flag)
						{
							if (base.#=z76wb7HEJGHqx() != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051936))
							{
								base.#=zSCUvZ$3Q$yPk();
								base.#=zPC48eGFZAOd4(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051936), 1);
							}
							base.#=zPC48eGFZAOd4(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052100), 1);
							base.#=z44RlC5dM$t$7(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052054), text, 1);
							base.#=zG_jEWD8=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053729), 2);
							base.#=zNnK3AQdmKNju(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053898), #=ze7ZtytQ=, 2);
							base.#=zG_jEWD8=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053893), 1);
							if (base.#=z76wb7HEJGHqx().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053526)) || base.#=z76wb7HEJGHqx().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053488)))
							{
								base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
								flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052151));
								if (flag)
								{
									#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==2 = base.#=z6gOaJJZTJ8VJ();
									if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==2.#=zKh04cf8=() > 0)
									{
										File.WriteAllText(path, #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zmocA6lfLwHhL(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==2));
									}
								}
							}
						}
						if (flag && !#=zhoOF5s8=.#=zObGzldk_Y5$c())
						{
							base.#=z1l8Ok3M=().Replace(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053451), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077055));
							new CookieContainer();
						}
					}
					else if (this.#=z1oEF8gM= == GameApplicationData.GameHosters.GamesMail)
					{
						#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053447), Array.Empty<object>());
						if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== != null)
						{
							base.#=zPC48eGFZAOd4(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053667), 1);
							base.#=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053643), true);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
							flag = base.#=zTfuhy4tr_RnrTxO_9g==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053624));
							#=zhoOF5s8=.#=zNmZpyTRuIxka(null, LogTypes.Tracing, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053599) + flag.ToString(), Array.Empty<object>());
						}
					}
					else if (this.#=z1oEF8gM= == GameApplicationData.GameHosters.Odnoklassniki)
					{
						if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== != null)
						{
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 1);
							base.#=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053310), true);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
							flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053291));
						}
						if (!flag)
						{
							base.#=zPC48eGFZAOd4(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053250), 1);
							IWebElement webElement = base.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053238), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053229));
							if (webElement != null)
							{
								base.#=zo_LdvbgbKdtT(webElement);
								base.#=z44RlC5dM$t$7(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053423), text, 0);
								base.#=z44RlC5dM$t$7(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053387), #=ze7ZtytQ=, 0);
								webElement.Submit();
								base.#=zo_LdvbgbKdtT(null);
								base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
								flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053291));
							}
						}
						if (flag)
						{
							#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==3 = base.#=zHaPdjrG08$z8();
							if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==3.#=zKh04cf8=() > 0)
							{
								File.WriteAllText(path, #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zmocA6lfLwHhL(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==3));
							}
							if (!#=zhoOF5s8=.#=zObGzldk_Y5$c())
							{
								base.#=z1l8Ok3M=();
								new CookieContainer();
							}
						}
					}
					else if (this.#=z1oEF8gM= == GameApplicationData.GameHosters.VKontakte)
					{
						if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== != null)
						{
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 1);
							base.#=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051915), true);
							base.#=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053353), false);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 2);
							base.#=z5GlD5yOMF10k(null);
							flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053339));
						}
						if (!flag)
						{
							base.#=zSCUvZ$3Q$yPk();
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=, 1);
							if (base.#=z76wb7HEJGHqx().Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053042)))
							{
								base.#=z44RlC5dM$t$7(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053038), text, 0);
								base.#=z44RlC5dM$t$7(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053023), #=ze7ZtytQ=, 1);
								base.#=zG_jEWD8=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053007), 1);
							}
							base.#=z5GlD5yOMF10k(null);
							flag = base.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053339));
							if (flag)
							{
								#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==4 = base.#=zHaPdjrG08$z8();
								#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z88V33U9I4DoN = base.#=z$r5qqTT2P9vZIEL3tw==(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052982));
								#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==4.#=zghsJ8VM=(#=z88V33U9I4DoN);
								if (#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==4.#=zKh04cf8=() > 0)
								{
									File.WriteAllText(path, #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zmocA6lfLwHhL(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==4));
								}
							}
						}
						if (flag && !#=zhoOF5s8=.#=zObGzldk_Y5$c())
						{
							while (base.#=z5GlD5yOMF10k(null))
							{
							}
							base.#=z1l8Ok3M=();
							new CookieContainer();
						}
					}
					else if (this.#=z1oEF8gM= == GameApplicationData.GameHosters.PlariumRu || this.#=z1oEF8gM= == GameApplicationData.GameHosters.PlariumEn)
					{
						if (!#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=z1YiK06BjkZhJ62B0rQ==())
						{
							Dictionary<string, object> data = new Dictionary<string, object>
							{
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052955),
									(int)this.#=z1oEF8gM=
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052950),
									#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(this.#=zSg73axlT2_0Z)
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052941),
									#=zhoOF5s8=.#=zCCBXDJ5n_DGghKXXmA==()
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053182),
									#=zhoOF5s8=.#=z9Yordw6ZFjQe()
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053166),
									HttpUtility.UrlEncode(#=zhoOF5s8=.#=zbfOGJA_8wt3H())
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053145),
									HttpUtility.UrlEncode(#=zhoOF5s8=.#=zUBdNbQEy4rFD())
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053131),
									HttpUtility.UrlEncode(#=zhoOF5s8=.#=zG96rwfOikL5q())
								},
								{
									#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053114),
									HttpUtility.UrlEncode(#=zhoOF5s8=.#=zxSNRMjqS3yCO())
								}
							};
							string arg = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053108), (int)this.#=z1oEF8gM=, #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(this.#=zSg73axlT2_0Z), #=zhoOF5s8=.#=zCCBXDJ5n_DGghKXXmA==());
							string #=zVI_2r0M=2 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053067), #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zc6nxpDwQGYzXkRSaV8fwIZ8=(), arg);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=2, 1);
							string arg2 = Convert.ToBase64String(Encoding.UTF8.GetBytes(JSONManager.SerializeData(data)));
							base.#=zx0uresqDtFaL(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053061), arg2));
							flag = true;
						}
						else
						{
							string arg3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054822), new object[]
							{
								(int)this.#=z1oEF8gM=,
								#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zetA27_gYDu_0b8eNlA==(this.#=zSg73axlT2_0Z),
								#=zhoOF5s8=.#=zCCBXDJ5n_DGghKXXmA==(),
								#=zhoOF5s8=.#=z9Yordw6ZFjQe(),
								HttpUtility.UrlEncode(#=zhoOF5s8=.#=zbfOGJA_8wt3H()),
								HttpUtility.UrlEncode(#=zhoOF5s8=.#=zUBdNbQEy4rFD()),
								HttpUtility.UrlEncode(#=zhoOF5s8=.#=zG96rwfOikL5q()),
								HttpUtility.UrlEncode(#=zhoOF5s8=.#=zxSNRMjqS3yCO())
							});
							string #=zVI_2r0M=3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909053067), #=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=zc6nxpDwQGYzXkRSaV8fwIZ8=(), arg3);
							base.#=zPC48eGFZAOd4(#=zVI_2r0M=3, 1);
							flag = true;
						}
					}
					#=z143ZALc= = null;
					if (flag)
					{
						if (#=zrgTTrYoszEKs)
						{
							base.#=zR5_i$$YlhjkS1_OAZw==();
						}
						result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)0;
					}
					else
					{
						result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)3;
					}
				}
			}
			else
			{
				#=z143ZALc= = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051964);
				result = #=z$_muzYvJ5U;
			}
		}
		catch (Exception #=zN_s5Z5A=2)
		{
			#=z143ZALc= = #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=2);
			result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)1;
		}
		finally
		{
			base.#=z_EpreNHtxGbU();
		}
		return result;
	}

	// Token: 0x06000935 RID: 2357 RVA: 0x0004B1B4 File Offset: 0x000493B4
	private string #=zPqA7VxdZI_AN()
	{
		GameApplicationData.GameHosters gameHosters = this.#=z1oEF8gM=;
		if (gameHosters <= GameApplicationData.GameHosters.VKontakte)
		{
			switch (gameHosters)
			{
			case GameApplicationData.GameHosters.MyMail:
				switch (this.#=zSg73axlT2_0Z)
				{
				case GameApplicationData.Games.RulesOfWar:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054725);
				case GameApplicationData.Games.CodexOfPirate:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054942);
				case GameApplicationData.Games.WarOfThrones:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054899);
				case GameApplicationData.Games.Konflikt:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054868);
				case GameApplicationData.Games.Sparta:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054569);
				}
				break;
			case GameApplicationData.GameHosters.GamesMail:
				switch (this.#=zSg73axlT2_0Z)
				{
				case GameApplicationData.Games.CodexOfPirate:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054530);
				case GameApplicationData.Games.WarOfThrones:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054499);
				case GameApplicationData.Games.Sparta:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054698);
				}
				break;
			case (GameApplicationData.GameHosters)3:
				break;
			case GameApplicationData.GameHosters.Odnoklassniki:
				switch (this.#=zSg73axlT2_0Z)
				{
				case GameApplicationData.Games.RulesOfWar:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054653);
				case GameApplicationData.Games.CodexOfPirate:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054615);
				case GameApplicationData.Games.WarOfThrones:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054313);
				case GameApplicationData.Games.Konflikt:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054285);
				case GameApplicationData.Games.Sparta:
					return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054243);
				}
				break;
			default:
				if (gameHosters == GameApplicationData.GameHosters.VKontakte)
				{
					switch (this.#=zSg73axlT2_0Z)
					{
					case GameApplicationData.Games.RulesOfWar:
						return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054211);
					case GameApplicationData.Games.CodexOfPirate:
						return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054420);
					case GameApplicationData.Games.WarOfThrones:
						return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054361);
					case GameApplicationData.Games.Konflikt:
						return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054050);
					case GameApplicationData.Games.Sparta:
						return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054007);
					}
				}
				break;
			}
		}
		else if (gameHosters == GameApplicationData.GameHosters.PlariumRu || gameHosters == GameApplicationData.GameHosters.PlariumEn)
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054200);
		}
		throw new Exception(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055839), this.#=z1oEF8gM=, this.#=zSg73axlT2_0Z));
	}

	// Token: 0x04000543 RID: 1347
	protected GameApplicationData.GameHosters #=z1oEF8gM=;

	// Token: 0x04000544 RID: 1348
	protected GameApplicationData.Games #=zSg73axlT2_0Z;
}
