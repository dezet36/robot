﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

// Token: 0x0200011F RID: 287
internal sealed class #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA== : UserControl
{
	// Token: 0x06000705 RID: 1797 RVA: 0x0003A3A8 File Offset: 0x000385A8
	public #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==()
	{
		this.#=zgpzgXirqPT5_();
		this.#=zG_DebDU= = false;
		this.#=zQ5a7Kd4pj2aY2yDtag== = -1;
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x0003A3C4 File Offset: 0x000385C4
	public void #=z20ohAjI=(List<#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==> #=zk656SlQ=, bool #=ztWom1j9sf9LO, bool #=zfGMolP0BO6ma)
	{
		this.#=zG_DebDU= = true;
		base.Controls.Clear();
		if (#=ztWom1j9sf9LO)
		{
			CheckBox checkBox = new CheckBox();
			checkBox.Text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114224));
			checkBox.Checked = true;
			foreach (#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A== #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A== in #=zk656SlQ=)
			{
				if (#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A== != null && !#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==.#=z6TVs_49LbvRB())
				{
					checkBox.Checked = false;
					break;
				}
			}
			checkBox.Left = 0;
			checkBox.Top = 0;
			checkBox.Width = base.Width - 10;
			checkBox.CheckedChanged += this.#=zBHESgrZM0_36NGDk1A==;
			base.Controls.Add(checkBox);
			this.#=z$vei7Q2$xWsm = checkBox;
		}
		else
		{
			this.#=z$vei7Q2$xWsm = null;
		}
		ToolTip toolTip = new ToolTip();
		toolTip.AutoPopDelay = 5000;
		toolTip.InitialDelay = 1000;
		toolTip.ReshowDelay = 500;
		toolTip.ShowAlways = true;
		this.#=zl$bo_xY51ocvsImYkQ== = new List<#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$>();
		int num = #=ztWom1j9sf9LO ? 20 : 0;
		foreach (#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A== #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2 in #=zk656SlQ=)
		{
			CheckBox checkBox2 = new CheckBox();
			checkBox2.Text = #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2.#=z2IL0kQNNQ7kA();
			if (!string.IsNullOrWhiteSpace(#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2.#=zyby4OyHCd0Yd()))
			{
				toolTip.SetToolTip(checkBox2, #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2.#=zyby4OyHCd0Yd());
			}
			checkBox2.Checked = #=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2.#=z6TVs_49LbvRB();
			checkBox2.Left = 0;
			checkBox2.Top = this.#=zl$bo_xY51ocvsImYkQ==.Count * 20 + num;
			checkBox2.Width = base.Width - 10;
			checkBox2.CheckedChanged += this.#=zRLkrHsCq4UUtDacFAw==;
			base.Controls.Add(checkBox2);
			this.#=zl$bo_xY51ocvsImYkQ==.Add(new #=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$(#=zwmU_x7FODlrRUpNY6FMJ1q2zhqeYHVF03A==2.#=zMuFMjGQ=(), checkBox2));
		}
		this.#=zG_DebDU= = false;
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x0003A5CC File Offset: 0x000387CC
	public void #=zsIWrSzQ=(List<int> #=zjTqS$AHF9GhD)
	{
		this.#=zG_DebDU= = true;
		foreach (#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$ #=zPI14QtnXQ3M$ in this.#=zl$bo_xY51ocvsImYkQ==)
		{
			#=zPI14QtnXQ3M$.#=zDNmrW4jNLyJk().Checked = #=zjTqS$AHF9GhD.Contains(#=zPI14QtnXQ3M$.#=zMuFMjGQ=());
		}
		this.#=zG_DebDU= = false;
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x0003A640 File Offset: 0x00038840
	public List<int> #=zBziBGR4jZQ9z()
	{
		List<int> list = new List<int>();
		if (this.#=zl$bo_xY51ocvsImYkQ== != null)
		{
			foreach (#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$ #=zPI14QtnXQ3M$ in this.#=zl$bo_xY51ocvsImYkQ==)
			{
				if (#=zPI14QtnXQ3M$.#=zDNmrW4jNLyJk().Checked)
				{
					list.Add(#=zPI14QtnXQ3M$.#=zMuFMjGQ=());
				}
			}
		}
		return list;
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x0003A6B4 File Offset: 0x000388B4
	public int #=zqust6dSu_GiZ()
	{
		int num = 0;
		if (this.#=zl$bo_xY51ocvsImYkQ== != null)
		{
			foreach (#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$ #=zPI14QtnXQ3M$ in this.#=zl$bo_xY51ocvsImYkQ==)
			{
				if (#=zPI14QtnXQ3M$.#=zDNmrW4jNLyJk().Checked)
				{
					num |= #=zPI14QtnXQ3M$.#=zMuFMjGQ=();
				}
			}
		}
		return num;
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x0003A724 File Offset: 0x00038924
	public void #=zVuRPdgKAVYF7(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=zbZe55QA=;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Combine(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=zbZe55QA=, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x0003A75C File Offset: 0x0003895C
	public void #=zX0JP0pJqcJV4(EventHandler #=z$Ib9gYQ=)
	{
		EventHandler eventHandler = this.#=zbZe55QA=;
		EventHandler eventHandler2;
		do
		{
			eventHandler2 = eventHandler;
			EventHandler value = (EventHandler)Delegate.Remove(eventHandler2, #=z$Ib9gYQ=);
			eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.#=zbZe55QA=, value, eventHandler2);
		}
		while (eventHandler != eventHandler2);
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x0003A794 File Offset: 0x00038994
	private void #=zBHESgrZM0_36NGDk1A==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zG_DebDU=)
		{
			return;
		}
		this.#=zG_DebDU= = true;
		bool @checked = (#=zP95I7AY= as CheckBox).Checked;
		foreach (#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$ #=zPI14QtnXQ3M$ in this.#=zl$bo_xY51ocvsImYkQ==)
		{
			#=zPI14QtnXQ3M$.#=zDNmrW4jNLyJk().Checked = @checked;
		}
		this.#=zQ5a7Kd4pj2aY2yDtag== = -1;
		this.#=zG_DebDU= = false;
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x0003A814 File Offset: 0x00038A14
	private void #=zRLkrHsCq4UUtDacFAw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		if (this.#=zG_DebDU=)
		{
			return;
		}
		this.#=zG_DebDU= = true;
		int num = -1;
		for (int i = 0; i < this.#=zl$bo_xY51ocvsImYkQ==.Count; i++)
		{
			if (this.#=zl$bo_xY51ocvsImYkQ==[i].#=zDNmrW4jNLyJk() == #=zP95I7AY=)
			{
				num = i;
				break;
			}
		}
		if (this.#=zQ5a7Kd4pj2aY2yDtag== >= 0 && this.#=zQ5a7Kd4pj2aY2yDtag== < this.#=zl$bo_xY51ocvsImYkQ==.Count && num >= 0 && num < this.#=zl$bo_xY51ocvsImYkQ==.Count && (Control.ModifierKeys & Keys.Shift) != Keys.None)
		{
			int num2 = this.#=zQ5a7Kd4pj2aY2yDtag==;
			if (num2 >= 0 && num2 < this.#=zl$bo_xY51ocvsImYkQ==.Count)
			{
				bool @checked = this.#=zl$bo_xY51ocvsImYkQ==[num2].#=zDNmrW4jNLyJk().Checked;
				if (@checked == this.#=zl$bo_xY51ocvsImYkQ==[num].#=zDNmrW4jNLyJk().Checked)
				{
					int num3;
					if (num2 < num)
					{
						num3 = num;
					}
					else
					{
						num3 = num2;
						num2 = num;
					}
					if (num3 - num2 > 1)
					{
						for (int j = num2 + 1; j < num3; j++)
						{
							this.#=zl$bo_xY51ocvsImYkQ==[j].#=zDNmrW4jNLyJk().Checked = @checked;
						}
					}
				}
			}
		}
		this.#=zQ5a7Kd4pj2aY2yDtag== = num;
		if (this.#=z$vei7Q2$xWsm != null)
		{
			if ((#=zP95I7AY= as CheckBox).Checked)
			{
				bool flag = true;
				using (List<#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$>.Enumerator enumerator = this.#=zl$bo_xY51ocvsImYkQ==.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (!enumerator.Current.#=zDNmrW4jNLyJk().Checked)
						{
							flag = false;
							break;
						}
					}
				}
				if (flag)
				{
					this.#=z$vei7Q2$xWsm.Checked = true;
				}
			}
			else
			{
				this.#=z$vei7Q2$xWsm.Checked = false;
			}
		}
		this.#=zG_DebDU= = false;
		EventHandler eventHandler = this.#=zbZe55QA=;
		if (eventHandler == null)
		{
			return;
		}
		eventHandler(this, #=z4Q$h3mE=);
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x0003A9D8 File Offset: 0x00038BD8
	public void #=z5I8TOV_q$Yz8()
	{
		this.#=zG_DebDU= = true;
		if (this.#=z$vei7Q2$xWsm != null)
		{
			this.#=z$vei7Q2$xWsm.Checked = false;
		}
		foreach (#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$ #=zPI14QtnXQ3M$ in this.#=zl$bo_xY51ocvsImYkQ==)
		{
			#=zPI14QtnXQ3M$.#=zDNmrW4jNLyJk().Checked = false;
		}
		this.#=zG_DebDU= = false;
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x0003AA50 File Offset: 0x00038C50
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x06000710 RID: 1808 RVA: 0x0003AA70 File Offset: 0x00038C70
	private void #=zgpzgXirqPT5_()
	{
		base.SuspendLayout();
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114851);
		base.ResumeLayout(false);
	}

	// Token: 0x0400042D RID: 1069
	private List<#=zIgdBHXIVggDpIIgR2T3QP7ocTiCGLis6JA==.#=zPI14QtnXQ3M$> #=zl$bo_xY51ocvsImYkQ==;

	// Token: 0x0400042E RID: 1070
	private CheckBox #=z$vei7Q2$xWsm;

	// Token: 0x0400042F RID: 1071
	private bool #=zG_DebDU=;

	// Token: 0x04000430 RID: 1072
	private int #=zQ5a7Kd4pj2aY2yDtag==;

	// Token: 0x04000431 RID: 1073
	private EventHandler #=zbZe55QA=;

	// Token: 0x04000432 RID: 1074
	private IContainer #=zRWEHIqY=;

	// Token: 0x02000120 RID: 288
	private sealed class #=zPI14QtnXQ3M$
	{
		// Token: 0x06000711 RID: 1809 RVA: 0x0003AAAC File Offset: 0x00038CAC
		public #=zPI14QtnXQ3M$(int #=zAk8mKBk=, CheckBox #=zfAg8rhgoixjM)
		{
			this.#=zbsxKkj4=(#=zAk8mKBk=);
			this.#=z$DzDfPKq6TG4(#=zfAg8rhgoixjM);
		}

		// Token: 0x06000712 RID: 1810 RVA: 0x0003AAC4 File Offset: 0x00038CC4
		public int #=zMuFMjGQ=()
		{
			return this.#=zdw4aIlzRxu5LWjlGFw==;
		}

		// Token: 0x06000713 RID: 1811 RVA: 0x0003AACC File Offset: 0x00038CCC
		public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
		{
			this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x0003AAD8 File Offset: 0x00038CD8
		public CheckBox #=zDNmrW4jNLyJk()
		{
			return this.#=z2A2gUNm3VkKx01f1359dB$U=;
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0003AAE0 File Offset: 0x00038CE0
		public void #=z$DzDfPKq6TG4(CheckBox #=z$Ib9gYQ=)
		{
			this.#=z2A2gUNm3VkKx01f1359dB$U= = #=z$Ib9gYQ=;
		}

		// Token: 0x04000433 RID: 1075
		private int #=zdw4aIlzRxu5LWjlGFw==;

		// Token: 0x04000434 RID: 1076
		private CheckBox #=z2A2gUNm3VkKx01f1359dB$U=;
	}
}
