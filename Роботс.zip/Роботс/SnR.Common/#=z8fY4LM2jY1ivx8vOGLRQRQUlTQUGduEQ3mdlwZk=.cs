﻿using System;

// Token: 0x020000A7 RID: 167
internal sealed class #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=
{
	// Token: 0x0600045C RID: 1116 RVA: 0x00025B58 File Offset: 0x00023D58
	public #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zvRLj9WQ=, int #=zNvCMwussKumm)
	{
		this.#=zzQwUIEs=(#=zvRLj9WQ=);
		this.#=zqoCq5j01dD5w(#=zNvCMwussKumm);
	}

	// Token: 0x0600045D RID: 1117 RVA: 0x00025B70 File Offset: 0x00023D70
	public #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x0600045E RID: 1118 RVA: 0x00025B78 File Offset: 0x00023D78
	public void #=zzQwUIEs=(#=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x00025B84 File Offset: 0x00023D84
	public int #=zlIXJ9$NfUZc_()
	{
		return this.#=zxojFZYWVfXhu329mAA==;
	}

	// Token: 0x06000460 RID: 1120 RVA: 0x00025B8C File Offset: 0x00023D8C
	public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
	{
		this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x040001A0 RID: 416
	private #=zJ3n6WGXBRu9RCsB3qQptA53GxemdboXKhQuvIi4= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x040001A1 RID: 417
	private int #=zxojFZYWVfXhu329mAA==;
}
