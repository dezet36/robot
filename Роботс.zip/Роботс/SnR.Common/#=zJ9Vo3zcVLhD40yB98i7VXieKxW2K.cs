﻿using System;
using System.Net;
using System.Text;

// Token: 0x02000128 RID: 296
internal class #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K : Exception
{
	// Token: 0x06000751 RID: 1873 RVA: 0x0003CB54 File Offset: 0x0003AD54
	public #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(string #=zgwWl6XLIWh1y, params object[] #=zlP66l7Q4Pzmc) : base(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=zgwWl6XLIWh1y, #=zlP66l7Q4Pzmc).ToString())
	{
		this.#=zzQwUIEs=((#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)0);
	}

	// Token: 0x06000752 RID: 1874 RVA: 0x0003CB70 File Offset: 0x0003AD70
	public #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs= #=zvRLj9WQ=, string #=zgwWl6XLIWh1y, params object[] #=zlP66l7Q4Pzmc) : base(new #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A==(#=zgwWl6XLIWh1y, #=zlP66l7Q4Pzmc).ToString())
	{
		this.#=zzQwUIEs=(#=zvRLj9WQ=);
	}

	// Token: 0x06000753 RID: 1875 RVA: 0x0003CB8C File Offset: 0x0003AD8C
	public #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs= #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x06000754 RID: 1876 RVA: 0x0003CB94 File Offset: 0x0003AD94
	private void #=zzQwUIEs=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs= #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000755 RID: 1877 RVA: 0x0003CBA0 File Offset: 0x0003ADA0
	public static bool #=zOYMXOJADXFX8(Exception #=zN_s5Z5A=)
	{
		return #=zN_s5Z5A= is #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K && (#=zN_s5Z5A= as #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K).#=zq2bPTdY=() != (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)0;
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x0003CBBC File Offset: 0x0003ADBC
	public static string #=z4mZAjSM=(Exception #=zN_s5Z5A=)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append(#=zN_s5Z5A=.Message);
		if (#=zN_s5Z5A= is WebException)
		{
			WebException ex = #=zN_s5Z5A= as WebException;
			stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929681));
			stringBuilder.Append(ex.Status.ToString());
			stringBuilder.Append(')');
		}
		stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929665));
		stringBuilder.Append(#=zN_s5Z5A=.StackTrace);
		if (#=zN_s5Z5A=.InnerException != null)
		{
			stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908929404));
			stringBuilder.Append(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=.InnerException));
		}
		return stringBuilder.ToString();
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x0003CC70 File Offset: 0x0003AE70
	public void #=zlWRHwq8=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ== #=zG2wnL_q7IxpD, out bool #=zgCH_VLfF_0Mj)
	{
		#=zgCH_VLfF_0Mj = false;
		if (this.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)4)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, this);
			#=z8StzeqE=.#=zh5Q$jgycqA15().#=z_CMx39SmGb4B(false);
			return;
		}
		if (this.#=zq2bPTdY=() == (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)2)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(#=zG2wnL_q7IxpD, this.Message, Array.Empty<object>());
			if (!#=z8StzeqE=.#=zQ$VqUtt$6rBX())
			{
				if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRunBackground)
				{
					if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsInstantBackgroundOff)
					{
						#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941413), Array.Empty<object>());
						#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRunBackground = false;
						#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
						#=z8StzeqE=.#=zgi8txbeKnNhG(null);
					}
					else if (#=z8StzeqE=.#=zv2Kyu17YrGOC().IsAutoBackgroundOff && DateTime.Now - #=z8StzeqE=.#=zueZ$FCyRT_UZyAN7rg==() < TimeSpan.FromMinutes(#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoBackgroundOffMinutes))
					{
						#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908941348), Array.Empty<object>());
						#=z8StzeqE=.#=zv2Kyu17YrGOC().IsRunBackground = false;
						#=z8StzeqE=.#=zv2Kyu17YrGOC().IsNeedsSynchronization = true;
					}
					#=z8StzeqE=.#=zgi8txbeKnNhG(null);
				}
				#=zgCH_VLfF_0Mj = true;
				return;
			}
		}
		else if (this.#=zq2bPTdY=() != (#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs=)3)
		{
			#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(#=zG2wnL_q7IxpD, this);
		}
	}

	// Token: 0x04000466 RID: 1126
	private #=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=zArez$Gs= #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x02000129 RID: 297
	public enum #=zArez$Gs=
	{

	}
}
