﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000E5 RID: 229
internal sealed class #=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx
{
	// Token: 0x0600060E RID: 1550 RVA: 0x0003188C File Offset: 0x0002FA8C
	public #=zEQYvD1jEOqlF7FGH2i42N$dpKwEGI2pgvm48AZjKN6Mx(Dictionary<string, object> #=z0gt$UpBfvud1)
	{
		this.#=zM_tYMjXvmqJR(JSONManager.ExtractInt(#=z0gt$UpBfvud1, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zG4td73$YMsBD(JSONManager.ExtractInt(#=z0gt$UpBfvud1, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094), 0));
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x000318C4 File Offset: 0x0002FAC4
	public int #=z9$XFwTaUKMJD()
	{
		return this.#=zKlNoO_yqqS_jEHSr$WYFu$4=;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x000318CC File Offset: 0x0002FACC
	public void #=zM_tYMjXvmqJR(int #=z$Ib9gYQ=)
	{
		this.#=zKlNoO_yqqS_jEHSr$WYFu$4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x000318D8 File Offset: 0x0002FAD8
	public int #=z0WoJ$Aom2jMB()
	{
		return this.#=zRc4Kmhamq42FWyRwbZNGUHA=;
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x000318E0 File Offset: 0x0002FAE0
	public void #=zG4td73$YMsBD(int #=z$Ib9gYQ=)
	{
		this.#=zRc4Kmhamq42FWyRwbZNGUHA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x000318EC File Offset: 0x0002FAEC
	public bool #=zRoHefI4d0IZD()
	{
		return this.#=z0WoJ$Aom2jMB() == 33554431;
	}

	// Token: 0x04000281 RID: 641
	private int #=zKlNoO_yqqS_jEHSr$WYFu$4=;

	// Token: 0x04000282 RID: 642
	private int #=zRc4Kmhamq42FWyRwbZNGUHA=;
}
