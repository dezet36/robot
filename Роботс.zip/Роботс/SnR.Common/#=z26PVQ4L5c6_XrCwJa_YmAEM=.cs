﻿using System;

// Token: 0x02000044 RID: 68
internal sealed class #=z26PVQ4L5c6_XrCwJa_YmAEM= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000224 RID: 548 RVA: 0x00014F20 File Offset: 0x00013120
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zeXig7da_G152sdRShw==;
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00014F28 File Offset: 0x00013128
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x06000226 RID: 550 RVA: 0x00014F2C File Offset: 0x0001312C
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263);
	}
}
