﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000230 RID: 560
internal sealed class #=ze_csdS6D0DG7gOcVFJ_prdT2gQrOixPG56d2ohLYOySadsGSIA== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06001128 RID: 4392 RVA: 0x000837BC File Offset: 0x000819BC
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zsUAjCQwjeHewB1krNJlOKEY= = #=zuJjQ1XU=.#=zow71wfuy88DngCDjGxC$_qOPtUTd();
		this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo = #=zuJjQ1XU=.#=zkKWAs5XIIg99xgy4_4osDhhsGVDT7VlBZ0PcNTHCMz60Q7aIrA==();
		this.#=zVG1EPv1OUDdyLeGHGQ== = #=zuJjQ1XU=.#=zqWzt0eB5fbATSwpS3Q==();
		this.#=zxZjYVP2XT8qmcT9c2Q== = #=zuJjQ1XU=.#=zdz_5DLjhAG09Q78wOA==();
	}

	// Token: 0x06001129 RID: 4393 RVA: 0x000837F0 File Offset: 0x000819F0
	protected override void #=zvb5bnug=()
	{
		bool flag = true;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeFrom >= 0.0 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeTo >= 0.0)
		{
			double totalHours = DateTime.Now.TimeOfDay.TotalHours;
			if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeFrom > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeTo)
			{
				if (totalHours < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeFrom && totalHours > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeTo)
				{
					flag = false;
				}
			}
			else if (totalHours < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeFrom || totalHours > this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptireTimeTo)
			{
				flag = false;
			}
		}
		if (!flag)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959438), Array.Empty<object>());
			return;
		}
		int num = 0;
		foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
		{
			if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zK5gF1KeGk_H_() < 0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3 && JSONManager.GetObject(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z4l00L2Q=(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959391)) == null)
			{
				num++;
			}
		}
		if (num >= this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaMaxNumber)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959370), new object[]
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaMaxNumber
			});
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959057), new object[]
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaMaxNumber - num
			});
			object[] array = (object[])JSONManager.GetObject(JSONManager.GetData(this.#=zBsXSanI=.#=zLNDNAVTQHosqz4Uifw==()), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909091704));
			List<#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==> list = new List<#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==>();
			object[] array2 = array;
			for (int i = 0; i < array2.Length; i++)
			{
				#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== = #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==.#=zi1hFJwI=((Dictionary<string, object>)array2[i], this.#=z8StzeqE=);
				if (#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== != null)
				{
					list.Add(#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==);
				}
			}
			list.Sort();
			int j = 0;
			List<int> list2 = new List<int>();
			for (int k = 0; k < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaMaxNumber - num; k++)
			{
				#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2 = null;
				while (j < list.Count)
				{
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA== #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==3 = list[j];
					j++;
					if (#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==3.#=zjfs8R6GBNpnXKfCf$w==() == 0 && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaTypes.Contains((int)#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==3.#=zq2bPTdY=()))
					{
						bool flag2 = false;
						using (List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==>.Enumerator enumerator = this.#=zVG1EPv1OUDdyLeGHGQ==.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								if (enumerator.Current.#=zK5gF1KeGk_H_() == -#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==3.#=zMuFMjGQ=())
								{
									flag2 = true;
									break;
								}
							}
						}
						if (!flag2)
						{
							#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2 = #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==3;
							break;
						}
					}
				}
				if (#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2 == null)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958763), Array.Empty<object>());
					break;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959009), new object[]
				{
					#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=zq2bPTdY=().ToString(),
					string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959216), #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=zfTB62qendhk_VEy8rw==(), #=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=zY0soxphmGIACbOHy6A==())
				});
				int num2 = 0;
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaUseGeneral > 0)
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = this.#=zxZjYVP2XT8qmcT9c2Q==.#=zIIyQciJSnOoKi3wyQA==(this.#=z8StzeqE=, this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaUseGeneral, this.#=zVG1EPv1OUDdyLeGHGQ==, list2);
					if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959200), new object[]
						{
							#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF()
						});
						num2 = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=();
						list2.Add(num2);
					}
				}
				UnitSquadCollection unitSquadCollection = UnitSquadCollection.FromString(#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=z$NyihN71ouQU() ? this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptureFutureTroops : this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaCaptureTroops, null);
				string text = this.#=zBsXSanI=.#=zrOsS4uPdgCzmsIi3DSpcKVM=(#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=zMuFMjGQ=(), (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3, null, unitSquadCollection, num2);
				if (text.Length > 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959170), Array.Empty<object>());
					this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection);
					this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection);
				}
				else
				{
					if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959148)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959119), Array.Empty<object>());
						break;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958821), new object[]
					{
						text
					});
				}
				if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaCaptureMessagesRemove || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaLoseMessagesRemove)
				{
					object[] array3 = this.#=zBsXSanI=.#=z_WwoAi$Ptgio();
					List<int> list3 = new List<int>();
					foreach (Dictionary<string, object> obj in array3)
					{
						Dictionary<string, object> dictionary = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908942987));
						if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), 0) == -#=z9ka1Op2TLbYzVl8Z03B3itqsK0KIlkFCuA==2.#=zMuFMjGQ=())
						{
							if (JSONManager.ExtractInt(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0) == this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=())
							{
								if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaCaptureMessagesRemove)
								{
									list3.Add(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943005), 0));
								}
							}
							else if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsEmporiaLoseMessagesRemove)
							{
								list3.Add(JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908943005), 0));
							}
						}
					}
					if (list3.Count > 0)
					{
						this.#=zBsXSanI=.#=zzrC2GSZBc9MG(list3);
					}
				}
			}
		}
		this.#=z5yKh65ylSmT$im5xS$1AcUQ=();
	}

	// Token: 0x0600112A RID: 4394 RVA: 0x00083E7C File Offset: 0x0008207C
	private void #=z5yKh65ylSmT$im5xS$1AcUQ=()
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaIntervalToSendBoostGeneralMin > 1E-06)
		{
			int num = 16000;
			#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = null;
			foreach (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2 in this.#=zxZjYVP2XT8qmcT9c2Q==)
			{
				if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zFMDiymuLQ7_4() == num && #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2.#=zIttox1M=() > ((#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null) ? #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zIttox1M=() : 0.0))
				{
					#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ = #=zrDcgv9ny10MzDWIXXLpHLoin_0n$2;
				}
			}
			if (#=zrDcgv9ny10MzDWIXXLpHLoin_0n$ != null)
			{
				bool flag = false;
				foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== in this.#=zVG1EPv1OUDdyLeGHGQ==)
				{
					if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT() != null && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjWdm34YCajRT().Contains(#=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=()))
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					List<int> list = new List<int>();
					foreach (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA== #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2 in this.#=zVG1EPv1OUDdyLeGHGQ==)
					{
						if (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_() < 0 && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zzasQXAPWhOif() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)3 && JSONManager.GetObject(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z4l00L2Q=(), #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908959391)) == null && #=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=z8waQMcfHThTd() == (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=z58gkp7O0WOEx)0)
						{
							list.Add(#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==2.#=zK5gF1KeGk_H_());
						}
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958742), new object[]
					{
						list.Count
					});
					if (list.Count > 0)
					{
						Dictionary<int, #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==> dictionary = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zH9Mroh$wsz82(this.#=z8StzeqE=, list, false, this.#=zBsXSanI=);
						#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = null;
						DateTime t = DateTime.Now - TimeSpan.FromMinutes(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().EmporiaIntervalToSendBoostGeneralMin);
						StringBuilder stringBuilder = new StringBuilder();
						foreach (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2 in dictionary.Values)
						{
							if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2.#=z2D1nHbya04wr() > DateTime.MinValue)
							{
								if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2.#=z2D1nHbya04wr() < t)
								{
									if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== == null)
									{
										#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2;
									}
									else if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=z2D1nHbya04wr() > #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2.#=z2D1nHbya04wr())
									{
										#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== = #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2;
									}
								}
							}
							else
							{
								if (stringBuilder.Length > 0)
								{
									stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
								}
								stringBuilder.Append(#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==2.#=zMuFMjGQ=());
							}
						}
						if (stringBuilder.Length > 0)
						{
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958961), new object[]
							{
								stringBuilder
							});
						}
						if (#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ== != null)
						{
							List<UnitType> list2 = new List<UnitType>();
							foreach (UnitSquad unitSquad in this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo)
							{
								if (unitSquad.Number >= 1 && unitSquad.Type.Function == UnitType.Functions.Defence && unitSquad.Type.Class == UnitType.Classes.LightInfantry && unitSquad.Type.Categories_HasNoneBut(new UnitType.Categories[]
								{
									UnitType.Categories.m_Elite,
									UnitType.Categories.r_Free
								}))
								{
									list2.Add(unitSquad.Type);
									break;
								}
							}
							if (list2.Count == 0)
							{
								throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958919));
							}
							list2.Sort(new Comparison<UnitType>(#=ze_csdS6D0DG7gOcVFJ_prdT2gQrOixPG56d2ohLYOySadsGSIA==.#=zyDNvciU=.#=zLkw0NRU=.#=zT6nCrtkF2Kv_0L5D$o74fn8o6iVQLJCAVA==));
							UnitSquadCollection unitSquadCollection = new UnitSquadCollection
							{
								new UnitSquad(list2[0], 1)
							};
							string text = this.#=zBsXSanI=.#=zrOsS4uPdgCzmsIi3DSpcKVM=(#=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zMuFMjGQ=(), (#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==.#=zjSSQZRrQ8d_l)5, null, unitSquadCollection, #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zMuFMjGQ=());
							string text2 = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908970383));
							string text3 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958871), #=zrDcgv9ny10MzDWIXXLpHLoin_0n$.#=zTbtwDpWhYGtF(), unitSquadCollection.ToStringLabels());
							string text4 = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070458), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zkfqcY3I=(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zfTB62qendhk_VEy8rw==(), #=zYHV2IZ4xEFstpN0wd5B2sFk$fTRULjWyNQ==.#=zY0soxphmGIACbOHy6A==());
							if (text.Length > 1000)
							{
								this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908958854), new object[]
								{
									text2,
									text4,
									text3
								});
								this.#=zsUAjCQwjeHewB1krNJlOKEY=.RemoveUnits(unitSquadCollection);
								this.#=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo.RemoveUnits(unitSquadCollection);
								return;
							}
							this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908878687), new object[]
							{
								text2,
								text4,
								text3,
								text
							});
						}
					}
				}
			}
		}
	}

	// Token: 0x04000948 RID: 2376
	private UnitSquadCollection #=zsUAjCQwjeHewB1krNJlOKEY=;

	// Token: 0x04000949 RID: 2377
	private UnitSquadCollection #=z33gwVPuSJS9J3Ag1uchFUgYSbhxdK5sh72qlBIsi9BLo;

	// Token: 0x0400094A RID: 2378
	private List<#=z3syt_vBdMICKu0$3cwzYyJ6nK5hQosOMeA==> #=zVG1EPv1OUDdyLeGHGQ==;

	// Token: 0x0400094B RID: 2379
	private #=zVXkwmeQWMxRV$1NJY0wv7gIvn$PU #=zxZjYVP2XT8qmcT9c2Q==;

	// Token: 0x02000231 RID: 561
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x0600112D RID: 4397 RVA: 0x00084388 File Offset: 0x00082588
		internal int #=zT6nCrtkF2Kv_0L5D$o74fn8o6iVQLJCAVA==(UnitType #=zm8PpuDU=, UnitType #=zcltuPyw=)
		{
			return #=zm8PpuDU=.Strength.Attack.CompareTo(#=zcltuPyw=.Strength.Attack);
		}

		// Token: 0x0400094C RID: 2380
		public static readonly #=ze_csdS6D0DG7gOcVFJ_prdT2gQrOixPG56d2ohLYOySadsGSIA==.#=zyDNvciU= #=zLkw0NRU= = new #=ze_csdS6D0DG7gOcVFJ_prdT2gQrOixPG56d2ohLYOySadsGSIA==.#=zyDNvciU=();

		// Token: 0x0400094D RID: 2381
		public static Comparison<UnitType> #=zMOsJR8bvCgQXhudXEw==;
	}
}
