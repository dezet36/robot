﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000C6 RID: 198
internal sealed class #=zBJfJNgk6OsvVsjubap5k9iWQrMb0ay4cA_2oIguuw9zD : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000538 RID: 1336 RVA: 0x0002CE78 File Offset: 0x0002B078
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zzfM$f6olDLFw = #=zuJjQ1XU=.#=z0jPLsvetj9_C();
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0002CE88 File Offset: 0x0002B088
	protected override void #=zvb5bnug=()
	{
		if (this.#=zzfM$f6olDLFw.Count > 0)
		{
			for (int i = 0; i < this.#=zzfM$f6olDLFw.Count; i++)
			{
				#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ== #=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ== = this.#=zzfM$f6olDLFw[i];
				string text = this.#=zBsXSanI=.#=zPqLTAl9NPKhi7JX8uLKz7Q8R7E_B(#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==.#=zMuFMjGQ=());
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971751), Array.Empty<object>());
				}
				else
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908971687), new object[]
					{
						JSONManager.Cut(text)
					});
				}
			}
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908952479), Array.Empty<object>());
	}

	// Token: 0x0400020F RID: 527
	private List<#=zHx2iO5n$MSVhVyhw4n2GOk$VrQAihJf8OQ==> #=zzfM$f6olDLFw;
}
