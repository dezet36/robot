﻿using System;

// Token: 0x020000FF RID: 255
internal sealed class #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=
{
	// Token: 0x06000693 RID: 1683 RVA: 0x00033DC0 File Offset: 0x00031FC0
	public #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z6De$pow=, string #=zcdC9Wnk=)
	{
		this.#=zRarUcoiqSiy3(#=z6De$pow=);
		this.#=zXak1QLBPme3_(#=zcdC9Wnk=);
	}

	// Token: 0x06000694 RID: 1684 RVA: 0x00033DD8 File Offset: 0x00031FD8
	public #=zGftB4ipDwW6sBHFruf09oy_qdINwRu6xU$tiR6o=(string #=zcdC9Wnk=)
	{
		this.#=zRarUcoiqSiy3(null);
		this.#=zXak1QLBPme3_(#=zcdC9Wnk=);
	}

	// Token: 0x06000695 RID: 1685 RVA: 0x00033DF0 File Offset: 0x00031FF0
	public #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zKWa_xovuFS15()
	{
		return this.#=zwqZuqjYuFoub586xcA==;
	}

	// Token: 0x06000696 RID: 1686 RVA: 0x00033DF8 File Offset: 0x00031FF8
	public void #=zRarUcoiqSiy3(#=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=z$Ib9gYQ=)
	{
		this.#=zwqZuqjYuFoub586xcA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x00033E04 File Offset: 0x00032004
	public string #=zv5TFggBD$2IC()
	{
		return this.#=zO1mRmPpGt671FsIHPw==;
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00033E0C File Offset: 0x0003200C
	public void #=zXak1QLBPme3_(string #=z$Ib9gYQ=)
	{
		this.#=zO1mRmPpGt671FsIHPw== = #=z$Ib9gYQ=;
	}

	// Token: 0x040002BC RID: 700
	private #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= #=zwqZuqjYuFoub586xcA==;

	// Token: 0x040002BD RID: 701
	private string #=zO1mRmPpGt671FsIHPw==;
}
