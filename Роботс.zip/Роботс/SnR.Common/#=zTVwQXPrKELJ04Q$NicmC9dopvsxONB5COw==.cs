﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020001A3 RID: 419
internal sealed class #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==
{
	// Token: 0x06000C55 RID: 3157 RVA: 0x00063BC8 File Offset: 0x00061DC8
	public #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==()
	{
		this.#=z6DdkLuHqTsH_(false);
		this.#=zWjnsORfNXn3mkzL2B6M2iM0WRLKa = 4.0;
		this.#=zwVnroWd_HlgNc1Y4TmBRGEBbtXhk = 6.0;
		this.#=z_4XA8dqkAP0V7theBvB0JzguE9WM = DateTime.Now;
		this.#=zvm9nJrl54We1hMNxrA==(false);
		this.#=zKXfdEG_SRmlW3RDnQw==(180);
		this.#=zbFxcPH$h2Pyozd$HmA==(false);
		this.#=zL8uc7e8Mgqms(new Dictionary<string, int>());
		this.#=zqvsTI2pZsK$WYewZMg==(5);
		this.#=zGDF9FhnW2XdR9t7SLgPSE2q5HYQU(10);
		this.#=zVzUJkQE1IS$VeSPi2A==(false);
		this.#=z8hsbIcjDAb1QrLOilgCsx6St8e5d(false);
		this.#=zRSr8inJmIRdenO2Kx3fAd7mAq_BbK$tLcA==(false);
		this.#=z9ivAyW4kJ8CsXoR7IA==(false);
		this.#=zcGgkwprFf4jMm6zoww==(false);
		this.#=zPyvlbY_6up$o(null);
		this.#=zbyDiyVoj8UoZ(null);
		this.#=z3feBcWbQtZMMROY1Iw==(DateTime.MinValue);
		this.#=zA5paZH613b0CL2$_7A==(false);
		this.#=zLFRiaK_JMAMe2ckY2Oom7pg=(60);
		this.#=zpXLX_3i5lnU$$w8oQw9YxRD26Uui(true);
		this.#=z2Hpm03d_VZLO(false);
		this.#=zsWBzTCz304YK_806RooV1d_3HAzn_uZsVQ==(false);
		this.#=zkm$17$IlTaR2oM7WDU49iyU=(false);
		this.#=z3anSr65fJmAvGYgh9WMMlFQ=(false);
		this.#=zotjktKGp3XIW62npm5dfU8$W47mCR_183Q==(false);
		this.#=zniLh3STpapKu(false);
		this.#=zjYfh5RMTctgdSZMAZRcXzCs=(false);
		this.#=z3cpv8KFh8oSKYPFmtw==(false);
		this.#=zmBAbn8lVjzIxwUk4MQ==(true);
		this.#=zvpXQdiVrdaM09eg3Zw==(7);
		this.#=zKMkR0RCsJW3J$G2ZVOji$Ec=(50000);
		this.#=zBgVYmVRHN2wEuC5Baw==(50000);
		this.#=zHGnCecmvyt2BatHqzg==(false);
		this.#=z33IiNiiFsCw9od2q2K0PfQw3V4OkL7GcIA==(true);
		this.#=zst$ihAPKUnFr(1);
		this.#=zeERjfsoxtJoG2wzeDTXwjYs=(true);
		this.#=z6TlDAOtvSn994p7Nq9XYMYQ=(false);
		this.#=zvZS0089oji1A59BAw6JoJqs=(0);
		this.#=zjg9CGODqQRqZ(false);
		this.#=zDx485GAPH90Z(1);
		this.#=zz151EFo35TnJ(DateTime.MinValue);
		this.#=zrStz1Xlk9yosi9zyRg==(false);
		this.#=z9pCo1XzOwHnRILSrrSNR6mMOP_78(true);
		this.#=zEomkcsrzzqfsIGcH7g==(null);
		this.#=zpDsoy3py9wOfP$gWsQ==(false);
		this.#=z7_P2Ssq75CUN(new #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg==());
		this.#=ztHX$itXFogPzZ_6JAg==(JSONManager.GetConfigValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069133)) == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909076716));
	}

	// Token: 0x06000C57 RID: 3159 RVA: 0x00063D90 File Offset: 0x00061F90
	public static #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=zv2Kyu17YrGOC()
	{
		if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=z5Q7Y7VtY5PdS == null)
		{
			object obj = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zdDVWRLKtNQo0;
			lock (obj)
			{
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=z5Q7Y7VtY5PdS == null)
				{
					#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=z5Q7Y7VtY5PdS = new #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==();
				}
			}
		}
		return #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=z5Q7Y7VtY5PdS;
	}

	// Token: 0x06000C58 RID: 3160 RVA: 0x00063DEC File Offset: 0x00061FEC
	public static void #=zdMaX3XaC3vQm(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=z$Ib9gYQ=)
	{
		object obj = #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zdDVWRLKtNQo0;
		lock (obj)
		{
			#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=z5Q7Y7VtY5PdS = #=z$Ib9gYQ=;
		}
	}

	// Token: 0x06000C59 RID: 3161 RVA: 0x00063E2C File Offset: 0x0006202C
	public bool #=zlagZNybfs0v_()
	{
		return this.#=zCpb212U3F$6Zfx86X3QYeTk=;
	}

	// Token: 0x06000C5A RID: 3162 RVA: 0x00063E34 File Offset: 0x00062034
	public void #=z6DdkLuHqTsH_(bool #=z$Ib9gYQ=)
	{
		this.#=zCpb212U3F$6Zfx86X3QYeTk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C5B RID: 3163 RVA: 0x00063E40 File Offset: 0x00062040
	public double #=zxMqWLjBM_xQfC2XbxMxlIDdPVncC()
	{
		return this.#=zWjnsORfNXn3mkzL2B6M2iM0WRLKa;
	}

	// Token: 0x06000C5C RID: 3164 RVA: 0x00063E48 File Offset: 0x00062048
	public void #=zeK8uW$k$r3SqISDGBizDKLCXPH6E(double #=z$Ib9gYQ=)
	{
		this.#=zWjnsORfNXn3mkzL2B6M2iM0WRLKa = #=z$Ib9gYQ=;
		this.#=z_4XA8dqkAP0V7theBvB0JzguE9WM = DateTime.Now;
	}

	// Token: 0x06000C5D RID: 3165 RVA: 0x00063E5C File Offset: 0x0006205C
	public double #=zxZUNpQr446iF4sFzC4IllHyNkuAk()
	{
		return this.#=zwVnroWd_HlgNc1Y4TmBRGEBbtXhk;
	}

	// Token: 0x06000C5E RID: 3166 RVA: 0x00063E64 File Offset: 0x00062064
	public void #=z85QWZwOqZayxq6LoxcnelCWHl6xw(double #=z$Ib9gYQ=)
	{
		this.#=zwVnroWd_HlgNc1Y4TmBRGEBbtXhk = #=z$Ib9gYQ=;
		this.#=z_4XA8dqkAP0V7theBvB0JzguE9WM = DateTime.Now;
	}

	// Token: 0x06000C5F RID: 3167 RVA: 0x00063E78 File Offset: 0x00062078
	public DateTime #=zkNpw_HkXGbLlGZ02xXjTauDMITO4()
	{
		return this.#=z_4XA8dqkAP0V7theBvB0JzguE9WM;
	}

	// Token: 0x06000C60 RID: 3168 RVA: 0x00063E80 File Offset: 0x00062080
	public void #=zy9zHV2WIukq_6fxsXZU_2cZnj_CL(DateTime #=z$Ib9gYQ=)
	{
		this.#=z_4XA8dqkAP0V7theBvB0JzguE9WM = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C61 RID: 3169 RVA: 0x00063E8C File Offset: 0x0006208C
	public bool #=zsJ3LVoBnMJ5KlcKlZw==()
	{
		return this.#=zmLIf4DMD8rru_n4AmGwHduQ=;
	}

	// Token: 0x06000C62 RID: 3170 RVA: 0x00063E94 File Offset: 0x00062094
	public void #=zvm9nJrl54We1hMNxrA==(bool #=z$Ib9gYQ=)
	{
		this.#=zmLIf4DMD8rru_n4AmGwHduQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C63 RID: 3171 RVA: 0x00063EA0 File Offset: 0x000620A0
	public int #=zi5UL_sLuZ3kXXvtS4g==()
	{
		return this.#=zP55EI2UApfrK0bzBGqQmEuvK$BxA;
	}

	// Token: 0x06000C64 RID: 3172 RVA: 0x00063EA8 File Offset: 0x000620A8
	public void #=zKXfdEG_SRmlW3RDnQw==(int #=z$Ib9gYQ=)
	{
		this.#=zP55EI2UApfrK0bzBGqQmEuvK$BxA = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C65 RID: 3173 RVA: 0x00063EB4 File Offset: 0x000620B4
	public bool #=zD4i5XsuB4tQfZEBJSw==()
	{
		return this.#=zGsG3Wr2OStMPYapzqiMcUFQ=;
	}

	// Token: 0x06000C66 RID: 3174 RVA: 0x00063EBC File Offset: 0x000620BC
	public void #=zbFxcPH$h2Pyozd$HmA==(bool #=z$Ib9gYQ=)
	{
		this.#=zGsG3Wr2OStMPYapzqiMcUFQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C67 RID: 3175 RVA: 0x00063EC8 File Offset: 0x000620C8
	public Dictionary<string, int> #=zUySUFPd4ZTeE()
	{
		return this.#=zYxEdINumWTLLICXi89YC9qs=;
	}

	// Token: 0x06000C68 RID: 3176 RVA: 0x00063ED0 File Offset: 0x000620D0
	private void #=zL8uc7e8Mgqms(Dictionary<string, int> #=z$Ib9gYQ=)
	{
		this.#=zYxEdINumWTLLICXi89YC9qs= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C69 RID: 3177 RVA: 0x00063EDC File Offset: 0x000620DC
	public int #=zvQM7hTETWDsDiXZCaw==()
	{
		return this.#=zKlG$Q2HWj4W2P7d$fc8dapo=;
	}

	// Token: 0x06000C6A RID: 3178 RVA: 0x00063EE4 File Offset: 0x000620E4
	public void #=zqvsTI2pZsK$WYewZMg==(int #=z$Ib9gYQ=)
	{
		this.#=zKlG$Q2HWj4W2P7d$fc8dapo= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C6B RID: 3179 RVA: 0x00063EF0 File Offset: 0x000620F0
	public int #=zw2h_ju8xFkKozhcDJ6vjwpSYxkI6()
	{
		return this.#=zOQuZ6tl6OE3LEVPFkzBzFL5UeBAtKBLq$g==;
	}

	// Token: 0x06000C6C RID: 3180 RVA: 0x00063EF8 File Offset: 0x000620F8
	public void #=zGDF9FhnW2XdR9t7SLgPSE2q5HYQU(int #=z$Ib9gYQ=)
	{
		this.#=zOQuZ6tl6OE3LEVPFkzBzFL5UeBAtKBLq$g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C6D RID: 3181 RVA: 0x00063F04 File Offset: 0x00062104
	public bool #=z0vyMSSgQNFYClT1jJg==()
	{
		return this.#=zcddFPiJ7FhhVaA2KfM7E2Wc=;
	}

	// Token: 0x06000C6E RID: 3182 RVA: 0x00063F0C File Offset: 0x0006210C
	public void #=zVzUJkQE1IS$VeSPi2A==(bool #=z$Ib9gYQ=)
	{
		this.#=zcddFPiJ7FhhVaA2KfM7E2Wc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C6F RID: 3183 RVA: 0x00063F18 File Offset: 0x00062118
	public bool #=zNIPvwbLh3eAI1kQdaS1a8Vi4cP4G()
	{
		return this.#=zCvaEn2Qj0ds9hia0NVRN$Bzm4dqhcsOGZ_P5Xj8=;
	}

	// Token: 0x06000C70 RID: 3184 RVA: 0x00063F20 File Offset: 0x00062120
	public void #=z8hsbIcjDAb1QrLOilgCsx6St8e5d(bool #=z$Ib9gYQ=)
	{
		this.#=zCvaEn2Qj0ds9hia0NVRN$Bzm4dqhcsOGZ_P5Xj8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C71 RID: 3185 RVA: 0x00063F2C File Offset: 0x0006212C
	public bool #=zrXOjFBdb5lleq1hEe$0hzQ_8RWgEbT9mog==()
	{
		return this.#=zXAPfdWQmdJEHLZIFj6fp9kg3sfRGb3w2Fk2sAR8=;
	}

	// Token: 0x06000C72 RID: 3186 RVA: 0x00063F34 File Offset: 0x00062134
	public void #=zRSr8inJmIRdenO2Kx3fAd7mAq_BbK$tLcA==(bool #=z$Ib9gYQ=)
	{
		this.#=zXAPfdWQmdJEHLZIFj6fp9kg3sfRGb3w2Fk2sAR8= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C73 RID: 3187 RVA: 0x00063F40 File Offset: 0x00062140
	public string #=zOyga2HEau$YaaQwjOw==()
	{
		return this.#=zo26hyVfO1IihmcO3H6ljP_62Qr$Z;
	}

	// Token: 0x06000C74 RID: 3188 RVA: 0x00063F48 File Offset: 0x00062148
	public void #=zlLOUC1_lSSSM_bwpIw==(string #=z$Ib9gYQ=)
	{
		this.#=zo26hyVfO1IihmcO3H6ljP_62Qr$Z = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C75 RID: 3189 RVA: 0x00063F54 File Offset: 0x00062154
	public bool #=zoLzPtcVDz1OXV9drqA==()
	{
		return this.#=zu_ciqI3ATEZJYwgXV6_TM7HGFAOQ;
	}

	// Token: 0x06000C76 RID: 3190 RVA: 0x00063F5C File Offset: 0x0006215C
	public void #=z9ivAyW4kJ8CsXoR7IA==(bool #=z$Ib9gYQ=)
	{
		this.#=zu_ciqI3ATEZJYwgXV6_TM7HGFAOQ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C77 RID: 3191 RVA: 0x00063F68 File Offset: 0x00062168
	public string #=zK6IaAIJJxtyc()
	{
		return this.#=zoc74bZtNqdRKvV1mY2g3BqU=;
	}

	// Token: 0x06000C78 RID: 3192 RVA: 0x00063F70 File Offset: 0x00062170
	public void #=zPyvlbY_6up$o(string #=z$Ib9gYQ=)
	{
		this.#=zoc74bZtNqdRKvV1mY2g3BqU= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C79 RID: 3193 RVA: 0x00063F7C File Offset: 0x0006217C
	public string #=zspiARYMWXWCQ()
	{
		return this.#=zFpG$uF$pU_J97CHXorsHSJg=;
	}

	// Token: 0x06000C7A RID: 3194 RVA: 0x00063F84 File Offset: 0x00062184
	public void #=zbyDiyVoj8UoZ(string #=z$Ib9gYQ=)
	{
		this.#=zFpG$uF$pU_J97CHXorsHSJg= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C7B RID: 3195 RVA: 0x00063F90 File Offset: 0x00062190
	public DateTime #=zHa_mQ_k2vULVf6_XNw==()
	{
		return this.#=zdrbgFt5iJYs1VIMXKlKT67pUpK6s;
	}

	// Token: 0x06000C7C RID: 3196 RVA: 0x00063F98 File Offset: 0x00062198
	public void #=z3feBcWbQtZMMROY1Iw==(DateTime #=z$Ib9gYQ=)
	{
		this.#=zdrbgFt5iJYs1VIMXKlKT67pUpK6s = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C7D RID: 3197 RVA: 0x00063FA4 File Offset: 0x000621A4
	public bool #=z5gsZrvYx_Krzuff_zw==()
	{
		return this.#=zT3dffT423kJkmwtVkh3gJcI=;
	}

	// Token: 0x06000C7E RID: 3198 RVA: 0x00063FAC File Offset: 0x000621AC
	public void #=zA5paZH613b0CL2$_7A==(bool #=z$Ib9gYQ=)
	{
		this.#=zT3dffT423kJkmwtVkh3gJcI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C7F RID: 3199 RVA: 0x00063FB8 File Offset: 0x000621B8
	public int #=zHXf6R08vedD$hfpwG5Ci3WE=()
	{
		return this.#=zUhEqsI6nHhkQH5K4ERVvAmxJMtCs9VzEkQ==;
	}

	// Token: 0x06000C80 RID: 3200 RVA: 0x00063FC0 File Offset: 0x000621C0
	public void #=zLFRiaK_JMAMe2ckY2Oom7pg=(int #=z$Ib9gYQ=)
	{
		this.#=zUhEqsI6nHhkQH5K4ERVvAmxJMtCs9VzEkQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C81 RID: 3201 RVA: 0x00063FCC File Offset: 0x000621CC
	public bool #=zSDzL$lsR3vYFW9AP7Wibl1x6NGFq()
	{
		return this.#=zpzaiA$EEbNcQIUOCggUnQ5XrajATbI8nN8yr1Wc=;
	}

	// Token: 0x06000C82 RID: 3202 RVA: 0x00063FD4 File Offset: 0x000621D4
	public void #=zpXLX_3i5lnU$$w8oQw9YxRD26Uui(bool #=z$Ib9gYQ=)
	{
		this.#=zpzaiA$EEbNcQIUOCggUnQ5XrajATbI8nN8yr1Wc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C83 RID: 3203 RVA: 0x00063FE0 File Offset: 0x000621E0
	public bool #=zoB_PPwnFbKCa()
	{
		return this.#=zrCAOCMtQUzV7cUgB9zDoiNA=;
	}

	// Token: 0x06000C84 RID: 3204 RVA: 0x00063FE8 File Offset: 0x000621E8
	public void #=z2Hpm03d_VZLO(bool #=z$Ib9gYQ=)
	{
		this.#=zrCAOCMtQUzV7cUgB9zDoiNA= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C85 RID: 3205 RVA: 0x00063FF4 File Offset: 0x000621F4
	public bool #=zOfJCiJK$ZVVkuth4jDES0lb35dZpcHbrSQ==()
	{
		return this.#=zjk$mhROM97E4ZzV$IJLEuWVVw1F_$KDqPfgdRhk=;
	}

	// Token: 0x06000C86 RID: 3206 RVA: 0x00063FFC File Offset: 0x000621FC
	public void #=zsWBzTCz304YK_806RooV1d_3HAzn_uZsVQ==(bool #=z$Ib9gYQ=)
	{
		this.#=zjk$mhROM97E4ZzV$IJLEuWVVw1F_$KDqPfgdRhk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C87 RID: 3207 RVA: 0x00064008 File Offset: 0x00062208
	public bool #=zQmMP6wt1RftoX0jGx5VWOLw=()
	{
		return this.#=zgHDSB4OzqSAxkvn4_SYdZ$8HAvB_hWiUMg==;
	}

	// Token: 0x06000C88 RID: 3208 RVA: 0x00064010 File Offset: 0x00062210
	public void #=zkm$17$IlTaR2oM7WDU49iyU=(bool #=z$Ib9gYQ=)
	{
		this.#=zgHDSB4OzqSAxkvn4_SYdZ$8HAvB_hWiUMg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C89 RID: 3209 RVA: 0x0006401C File Offset: 0x0006221C
	public bool #=zKatp2kKFbWctd3l7feJusRE=()
	{
		return this.#=z4vmHLqhw9wRICZXpKnHeDDWEizLWK1UrTg==;
	}

	// Token: 0x06000C8A RID: 3210 RVA: 0x00064024 File Offset: 0x00062224
	public void #=z3anSr65fJmAvGYgh9WMMlFQ=(bool #=z$Ib9gYQ=)
	{
		this.#=z4vmHLqhw9wRICZXpKnHeDDWEizLWK1UrTg== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C8B RID: 3211 RVA: 0x00064030 File Offset: 0x00062230
	public bool #=zK0Bl_aLmVIcfjen9YvGM2N2U4PVP7Hbgng==()
	{
		return this.#=zsgRvYoDArd$ZspReBbzeyGLXMxrAMfjNK9fkzvQ=;
	}

	// Token: 0x06000C8C RID: 3212 RVA: 0x00064038 File Offset: 0x00062238
	public void #=zotjktKGp3XIW62npm5dfU8$W47mCR_183Q==(bool #=z$Ib9gYQ=)
	{
		this.#=zsgRvYoDArd$ZspReBbzeyGLXMxrAMfjNK9fkzvQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C8D RID: 3213 RVA: 0x00064044 File Offset: 0x00062244
	public bool #=zpCmQXZTzH4U2()
	{
		return this.#=zlWJ1F8GONZqmahT6VJG$HYQ=;
	}

	// Token: 0x06000C8E RID: 3214 RVA: 0x0006404C File Offset: 0x0006224C
	public void #=zniLh3STpapKu(bool #=z$Ib9gYQ=)
	{
		this.#=zlWJ1F8GONZqmahT6VJG$HYQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C8F RID: 3215 RVA: 0x00064058 File Offset: 0x00062258
	public bool #=zgS33aA7O0JjP5mZqsY2xXXg=()
	{
		return this.#=znni0wHmIqKqxUg8Zew7H$0H9i7ZuSL9Fjw==;
	}

	// Token: 0x06000C90 RID: 3216 RVA: 0x00064060 File Offset: 0x00062260
	public void #=zjYfh5RMTctgdSZMAZRcXzCs=(bool #=z$Ib9gYQ=)
	{
		this.#=znni0wHmIqKqxUg8Zew7H$0H9i7ZuSL9Fjw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C91 RID: 3217 RVA: 0x0006406C File Offset: 0x0006226C
	public bool #=zgPkXqnTbuiTDilNJGQ==()
	{
		return this.#=zvGJslVhitZ_8MU3sPhJzodxFv65G;
	}

	// Token: 0x06000C92 RID: 3218 RVA: 0x00064074 File Offset: 0x00062274
	public void #=z3cpv8KFh8oSKYPFmtw==(bool #=z$Ib9gYQ=)
	{
		this.#=zvGJslVhitZ_8MU3sPhJzodxFv65G = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C93 RID: 3219 RVA: 0x00064080 File Offset: 0x00062280
	public bool #=zgr_b3nv857lLfLmFjw==()
	{
		return this.#=z2Ix9r5LG6KcfLmTHmGgHjDc=;
	}

	// Token: 0x06000C94 RID: 3220 RVA: 0x00064088 File Offset: 0x00062288
	public void #=zmBAbn8lVjzIxwUk4MQ==(bool #=z$Ib9gYQ=)
	{
		this.#=z2Ix9r5LG6KcfLmTHmGgHjDc= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C95 RID: 3221 RVA: 0x00064094 File Offset: 0x00062294
	public int #=z_B7PL3U2K4yBHXwnUg==()
	{
		return this.#=zZvnm3jmi6yxOPWIIARPPOMVsgIY4;
	}

	// Token: 0x06000C96 RID: 3222 RVA: 0x0006409C File Offset: 0x0006229C
	public void #=zvpXQdiVrdaM09eg3Zw==(int #=z$Ib9gYQ=)
	{
		this.#=zZvnm3jmi6yxOPWIIARPPOMVsgIY4 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C97 RID: 3223 RVA: 0x000640A8 File Offset: 0x000622A8
	public bool #=zUNAFeezgOQfGT9FBVQ==()
	{
		return this.#=z08S$u5HnTtf1im1P4Tte7TQ=;
	}

	// Token: 0x06000C98 RID: 3224 RVA: 0x000640B0 File Offset: 0x000622B0
	public void #=z7FPPTK1VtmJMIFT1cA==(bool #=z$Ib9gYQ=)
	{
		this.#=z08S$u5HnTtf1im1P4Tte7TQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C99 RID: 3225 RVA: 0x000640BC File Offset: 0x000622BC
	public bool #=zLaUjBTtNYih22fW_EQ==()
	{
		return this.#=z72VZ5TgXkB9GvltxaISN$y$DAe8N;
	}

	// Token: 0x06000C9A RID: 3226 RVA: 0x000640C4 File Offset: 0x000622C4
	public void #=zcGgkwprFf4jMm6zoww==(bool #=z$Ib9gYQ=)
	{
		this.#=z72VZ5TgXkB9GvltxaISN$y$DAe8N = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C9B RID: 3227 RVA: 0x000640D0 File Offset: 0x000622D0
	public bool #=zlRrfRpmZlokbwl5Xnw==()
	{
		return this.#=zU919la7L9DpSIz8vidnAN6bOC8mm;
	}

	// Token: 0x06000C9C RID: 3228 RVA: 0x000640D8 File Offset: 0x000622D8
	public void #=ztHX$itXFogPzZ_6JAg==(bool #=z$Ib9gYQ=)
	{
		this.#=zU919la7L9DpSIz8vidnAN6bOC8mm = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C9D RID: 3229 RVA: 0x000640E4 File Offset: 0x000622E4
	public int #=zqGZod7DuP$m614qxIj6v4lE=()
	{
		return this.#=zxTYY2Ln0f0I6AsSmjJaxMIn7EybY;
	}

	// Token: 0x06000C9E RID: 3230 RVA: 0x000640EC File Offset: 0x000622EC
	public void #=zKMkR0RCsJW3J$G2ZVOji$Ec=(int #=z$Ib9gYQ=)
	{
		this.#=zxTYY2Ln0f0I6AsSmjJaxMIn7EybY = #=z$Ib9gYQ=;
	}

	// Token: 0x06000C9F RID: 3231 RVA: 0x000640F8 File Offset: 0x000622F8
	public int #=zDDkQ_RdZgdNGO6OtyQ==()
	{
		return this.#=zd0$HEKA49WsMJSJDgnMWKjrYTfT_;
	}

	// Token: 0x06000CA0 RID: 3232 RVA: 0x00064100 File Offset: 0x00062300
	public void #=zBgVYmVRHN2wEuC5Baw==(int #=z$Ib9gYQ=)
	{
		this.#=zd0$HEKA49WsMJSJDgnMWKjrYTfT_ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CA1 RID: 3233 RVA: 0x0006410C File Offset: 0x0006230C
	public bool #=zydSN$ZobqYZXe5Kw7A==()
	{
		return false;
	}

	// Token: 0x06000CA2 RID: 3234 RVA: 0x00064110 File Offset: 0x00062310
	public void #=zHGnCecmvyt2BatHqzg==(bool #=z$Ib9gYQ=)
	{
	}

	// Token: 0x06000CA3 RID: 3235 RVA: 0x00064114 File Offset: 0x00062314
	public bool #=zOR7fTvmTu73NfJN7OcVEOIaIdTad2ijeeg==()
	{
		return this.#=zEhKaE3s14d73ICnnMexKBTVr8S8fnSlXlxMknRk=;
	}

	// Token: 0x06000CA4 RID: 3236 RVA: 0x0006411C File Offset: 0x0006231C
	public void #=z33IiNiiFsCw9od2q2K0PfQw3V4OkL7GcIA==(bool #=z$Ib9gYQ=)
	{
		this.#=zEhKaE3s14d73ICnnMexKBTVr8S8fnSlXlxMknRk= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CA5 RID: 3237 RVA: 0x00064128 File Offset: 0x00062328
	public int #=zpxNt6CS3$Hsx()
	{
		return this.#=z3tMB0ILe5jETq8H1OjVCJCs=;
	}

	// Token: 0x06000CA6 RID: 3238 RVA: 0x00064130 File Offset: 0x00062330
	public void #=zst$ihAPKUnFr(int #=z$Ib9gYQ=)
	{
		this.#=z3tMB0ILe5jETq8H1OjVCJCs= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CA7 RID: 3239 RVA: 0x0006413C File Offset: 0x0006233C
	public bool #=zEENapEnsc_FcfPHADJ3whqs=()
	{
		return this.#=z0dXu1NJxEkJPdy4H0TsmwcPWQg32;
	}

	// Token: 0x06000CA8 RID: 3240 RVA: 0x00064144 File Offset: 0x00062344
	public void #=zeERjfsoxtJoG2wzeDTXwjYs=(bool #=z$Ib9gYQ=)
	{
		this.#=z0dXu1NJxEkJPdy4H0TsmwcPWQg32 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CA9 RID: 3241 RVA: 0x00064150 File Offset: 0x00062350
	public bool #=ztmwqj9gOfD5f3LJDJXnN16s=()
	{
		return this.#=z2eqsmwLiN4KyA8hq9fO4yHm0zWX1;
	}

	// Token: 0x06000CAA RID: 3242 RVA: 0x00064158 File Offset: 0x00062358
	public void #=z6TlDAOtvSn994p7Nq9XYMYQ=(bool #=z$Ib9gYQ=)
	{
		this.#=z2eqsmwLiN4KyA8hq9fO4yHm0zWX1 = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CAB RID: 3243 RVA: 0x00064164 File Offset: 0x00062364
	public int #=zLTcKZ4NeSgHgtq5frELA$x0=()
	{
		return this.#=zBsVLucrWkdyyP1x7BvM_xdzaOTiL;
	}

	// Token: 0x06000CAC RID: 3244 RVA: 0x0006416C File Offset: 0x0006236C
	public void #=zvZS0089oji1A59BAw6JoJqs=(int #=z$Ib9gYQ=)
	{
		this.#=zBsVLucrWkdyyP1x7BvM_xdzaOTiL = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CAD RID: 3245 RVA: 0x00064178 File Offset: 0x00062378
	public bool #=z97Z7CxekCb4f()
	{
		return this.#=znzvXC36IeqTI7ZzQsJaaTV0=;
	}

	// Token: 0x06000CAE RID: 3246 RVA: 0x00064180 File Offset: 0x00062380
	public void #=zjg9CGODqQRqZ(bool #=z$Ib9gYQ=)
	{
		this.#=znzvXC36IeqTI7ZzQsJaaTV0= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CAF RID: 3247 RVA: 0x0006418C File Offset: 0x0006238C
	public int #=zrQfDHfQ_N5CC()
	{
		return this.#=zKFfuXrXRxshXUDH$J19bjDY=;
	}

	// Token: 0x06000CB0 RID: 3248 RVA: 0x00064194 File Offset: 0x00062394
	public void #=zDx485GAPH90Z(int #=z$Ib9gYQ=)
	{
		this.#=zKFfuXrXRxshXUDH$J19bjDY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CB1 RID: 3249 RVA: 0x000641A0 File Offset: 0x000623A0
	public DateTime #=z14zJFR90Z1eo()
	{
		return this.#=zXy10wKc9w$bTJYsS4CTGEfY=;
	}

	// Token: 0x06000CB2 RID: 3250 RVA: 0x000641A8 File Offset: 0x000623A8
	public void #=zz151EFo35TnJ(DateTime #=z$Ib9gYQ=)
	{
		this.#=zXy10wKc9w$bTJYsS4CTGEfY= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CB3 RID: 3251 RVA: 0x000641B4 File Offset: 0x000623B4
	public bool #=z1YiK06BjkZhJ62B0rQ==()
	{
		return this.#=zLsfzmGUVZG4aP9_9mljtqneWmZh_;
	}

	// Token: 0x06000CB4 RID: 3252 RVA: 0x000641BC File Offset: 0x000623BC
	public void #=zrStz1Xlk9yosi9zyRg==(bool #=z$Ib9gYQ=)
	{
		this.#=zLsfzmGUVZG4aP9_9mljtqneWmZh_ = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CB5 RID: 3253 RVA: 0x000641C8 File Offset: 0x000623C8
	public bool #=zL7ZDlcYJHrdWKPBrLfJWbCXAFa2U()
	{
		return this.#=zoRAipG5EdEuJgqVAPNebPgsjeeoRevVLOA==;
	}

	// Token: 0x06000CB6 RID: 3254 RVA: 0x000641D0 File Offset: 0x000623D0
	public void #=z9pCo1XzOwHnRILSrrSNR6mMOP_78(bool #=z$Ib9gYQ=)
	{
		this.#=zoRAipG5EdEuJgqVAPNebPgsjeeoRevVLOA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CB7 RID: 3255 RVA: 0x000641DC File Offset: 0x000623DC
	public string #=zNqNm8eiTRoJhiqVdyQ==()
	{
		return this.#=zQCTlRnP2xLiGC7_3oGYVemQ=;
	}

	// Token: 0x06000CB8 RID: 3256 RVA: 0x000641E4 File Offset: 0x000623E4
	public void #=zEomkcsrzzqfsIGcH7g==(string #=z$Ib9gYQ=)
	{
		this.#=zQCTlRnP2xLiGC7_3oGYVemQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CB9 RID: 3257 RVA: 0x000641F0 File Offset: 0x000623F0
	public bool #=zPkjkJEby6e8taWhnVQ==()
	{
		return this.#=zILPJkL9UhuPhdL5beMNoglSXNYlk;
	}

	// Token: 0x06000CBA RID: 3258 RVA: 0x000641F8 File Offset: 0x000623F8
	public void #=zpDsoy3py9wOfP$gWsQ==(bool #=z$Ib9gYQ=)
	{
		this.#=zILPJkL9UhuPhdL5beMNoglSXNYlk = #=z$Ib9gYQ=;
	}

	// Token: 0x06000CBB RID: 3259 RVA: 0x00064204 File Offset: 0x00062404
	public #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg== #=zMhe8jCbQi4yh()
	{
		return this.#=zrbsk77xMGzantiRJVQ==;
	}

	// Token: 0x06000CBC RID: 3260 RVA: 0x0006420C File Offset: 0x0006240C
	public void #=z7_P2Ssq75CUN(#=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg== #=z$Ib9gYQ=)
	{
		this.#=zrbsk77xMGzantiRJVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x04000723 RID: 1827
	private static object #=zdDVWRLKtNQo0 = new object();

	// Token: 0x04000724 RID: 1828
	private double #=zWjnsORfNXn3mkzL2B6M2iM0WRLKa;

	// Token: 0x04000725 RID: 1829
	private double #=zwVnroWd_HlgNc1Y4TmBRGEBbtXhk;

	// Token: 0x04000726 RID: 1830
	private DateTime #=z_4XA8dqkAP0V7theBvB0JzguE9WM;

	// Token: 0x04000727 RID: 1831
	private static #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw== #=z5Q7Y7VtY5PdS = null;

	// Token: 0x04000728 RID: 1832
	private bool #=zCpb212U3F$6Zfx86X3QYeTk=;

	// Token: 0x04000729 RID: 1833
	private bool #=zmLIf4DMD8rru_n4AmGwHduQ=;

	// Token: 0x0400072A RID: 1834
	private int #=zP55EI2UApfrK0bzBGqQmEuvK$BxA;

	// Token: 0x0400072B RID: 1835
	private bool #=zGsG3Wr2OStMPYapzqiMcUFQ=;

	// Token: 0x0400072C RID: 1836
	private Dictionary<string, int> #=zYxEdINumWTLLICXi89YC9qs=;

	// Token: 0x0400072D RID: 1837
	private int #=zKlG$Q2HWj4W2P7d$fc8dapo=;

	// Token: 0x0400072E RID: 1838
	private int #=zOQuZ6tl6OE3LEVPFkzBzFL5UeBAtKBLq$g==;

	// Token: 0x0400072F RID: 1839
	private bool #=zcddFPiJ7FhhVaA2KfM7E2Wc=;

	// Token: 0x04000730 RID: 1840
	private bool #=zCvaEn2Qj0ds9hia0NVRN$Bzm4dqhcsOGZ_P5Xj8=;

	// Token: 0x04000731 RID: 1841
	private bool #=zXAPfdWQmdJEHLZIFj6fp9kg3sfRGb3w2Fk2sAR8=;

	// Token: 0x04000732 RID: 1842
	private string #=zo26hyVfO1IihmcO3H6ljP_62Qr$Z;

	// Token: 0x04000733 RID: 1843
	private bool #=zu_ciqI3ATEZJYwgXV6_TM7HGFAOQ;

	// Token: 0x04000734 RID: 1844
	private string #=zoc74bZtNqdRKvV1mY2g3BqU=;

	// Token: 0x04000735 RID: 1845
	private string #=zFpG$uF$pU_J97CHXorsHSJg=;

	// Token: 0x04000736 RID: 1846
	private DateTime #=zdrbgFt5iJYs1VIMXKlKT67pUpK6s;

	// Token: 0x04000737 RID: 1847
	private bool #=zT3dffT423kJkmwtVkh3gJcI=;

	// Token: 0x04000738 RID: 1848
	private int #=zUhEqsI6nHhkQH5K4ERVvAmxJMtCs9VzEkQ==;

	// Token: 0x04000739 RID: 1849
	private bool #=zpzaiA$EEbNcQIUOCggUnQ5XrajATbI8nN8yr1Wc=;

	// Token: 0x0400073A RID: 1850
	private bool #=zrCAOCMtQUzV7cUgB9zDoiNA=;

	// Token: 0x0400073B RID: 1851
	private bool #=zjk$mhROM97E4ZzV$IJLEuWVVw1F_$KDqPfgdRhk=;

	// Token: 0x0400073C RID: 1852
	private bool #=zgHDSB4OzqSAxkvn4_SYdZ$8HAvB_hWiUMg==;

	// Token: 0x0400073D RID: 1853
	private bool #=z4vmHLqhw9wRICZXpKnHeDDWEizLWK1UrTg==;

	// Token: 0x0400073E RID: 1854
	private bool #=zsgRvYoDArd$ZspReBbzeyGLXMxrAMfjNK9fkzvQ=;

	// Token: 0x0400073F RID: 1855
	private bool #=zlWJ1F8GONZqmahT6VJG$HYQ=;

	// Token: 0x04000740 RID: 1856
	private bool #=znni0wHmIqKqxUg8Zew7H$0H9i7ZuSL9Fjw==;

	// Token: 0x04000741 RID: 1857
	private bool #=zvGJslVhitZ_8MU3sPhJzodxFv65G;

	// Token: 0x04000742 RID: 1858
	private bool #=z2Ix9r5LG6KcfLmTHmGgHjDc=;

	// Token: 0x04000743 RID: 1859
	private int #=zZvnm3jmi6yxOPWIIARPPOMVsgIY4;

	// Token: 0x04000744 RID: 1860
	private bool #=z08S$u5HnTtf1im1P4Tte7TQ=;

	// Token: 0x04000745 RID: 1861
	private bool #=z72VZ5TgXkB9GvltxaISN$y$DAe8N;

	// Token: 0x04000746 RID: 1862
	private bool #=zU919la7L9DpSIz8vidnAN6bOC8mm;

	// Token: 0x04000747 RID: 1863
	private int #=zxTYY2Ln0f0I6AsSmjJaxMIn7EybY;

	// Token: 0x04000748 RID: 1864
	private int #=zd0$HEKA49WsMJSJDgnMWKjrYTfT_;

	// Token: 0x04000749 RID: 1865
	private bool #=zEhKaE3s14d73ICnnMexKBTVr8S8fnSlXlxMknRk=;

	// Token: 0x0400074A RID: 1866
	private int #=z3tMB0ILe5jETq8H1OjVCJCs=;

	// Token: 0x0400074B RID: 1867
	private bool #=z0dXu1NJxEkJPdy4H0TsmwcPWQg32;

	// Token: 0x0400074C RID: 1868
	private bool #=z2eqsmwLiN4KyA8hq9fO4yHm0zWX1;

	// Token: 0x0400074D RID: 1869
	private int #=zBsVLucrWkdyyP1x7BvM_xdzaOTiL;

	// Token: 0x0400074E RID: 1870
	private bool #=znzvXC36IeqTI7ZzQsJaaTV0=;

	// Token: 0x0400074F RID: 1871
	private int #=zKFfuXrXRxshXUDH$J19bjDY=;

	// Token: 0x04000750 RID: 1872
	private DateTime #=zXy10wKc9w$bTJYsS4CTGEfY=;

	// Token: 0x04000751 RID: 1873
	private bool #=zLsfzmGUVZG4aP9_9mljtqneWmZh_;

	// Token: 0x04000752 RID: 1874
	private bool #=zoRAipG5EdEuJgqVAPNebPgsjeeoRevVLOA==;

	// Token: 0x04000753 RID: 1875
	private string #=zQCTlRnP2xLiGC7_3oGYVemQ=;

	// Token: 0x04000754 RID: 1876
	private bool #=zILPJkL9UhuPhdL5beMNoglSXNYlk;

	// Token: 0x04000755 RID: 1877
	private #=zeoLGHcJQcLJRs23XNWLGZylt_SNf0BjRVg== #=zrbsk77xMGzantiRJVQ==;
}
