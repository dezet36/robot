﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x020000DC RID: 220
internal sealed class #=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO : RecordData
{
	// Token: 0x060005E1 RID: 1505 RVA: 0x00030980 File Offset: 0x0002EB80
	public #=zD9Qcmx8rH4NtaEcrXmFwql$Q$$fO(Record #=zb31wEKg=) : base(#=zb31wEKg=)
	{
		sbyte[] data = #=zb31wEKg=.Data;
		this.#=zyknxYG4Xrts7 = (data[0] == 1);
	}

	// Token: 0x060005E2 RID: 1506 RVA: 0x000309A8 File Offset: 0x0002EBA8
	public bool #=z35rwe4u2YH1T()
	{
		return this.#=zyknxYG4Xrts7;
	}

	// Token: 0x0400026F RID: 623
	private bool #=zyknxYG4Xrts7;
}
