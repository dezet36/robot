﻿using System;

// Token: 0x020001B5 RID: 437
internal sealed class #=zUf7AkUo_mcA$WAagIXOMiDs= : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000D1E RID: 3358 RVA: 0x00067DA0 File Offset: 0x00065FA0
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zhovzSfs8pQ7Q;
	}

	// Token: 0x06000D1F RID: 3359 RVA: 0x00067DA8 File Offset: 0x00065FA8
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x06000D20 RID: 3360 RVA: 0x00067DAC File Offset: 0x00065FAC
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077055);
	}
}
