﻿// Token: 0x02000121 RID: 289
internal sealed partial class #=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU= : global::System.Windows.Forms.Form
{
	// Token: 0x06000728 RID: 1832 RVA: 0x0003B42C File Offset: 0x0003962C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400043A RID: 1082
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
