﻿using System;
using System.Collections.Generic;

// Token: 0x0200024A RID: 586
internal sealed class #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ== : IComparer<#=zO6457TajDDxDJIsKqS1bbzDMLckn>
{
	// Token: 0x060011DA RID: 4570 RVA: 0x0008A324 File Offset: 0x00088524
	public #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==()
	{
		this.#=zQ4_NWTk= = (#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)0;
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x0008A334 File Offset: 0x00088534
	public #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==(#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs= #=zvRLj9WQ=)
	{
		this.#=zQ4_NWTk= = #=zvRLj9WQ=;
	}

	// Token: 0x060011DC RID: 4572 RVA: 0x0008A344 File Offset: 0x00088544
	public int Compare(#=zO6457TajDDxDJIsKqS1bbzDMLckn #=zQrqFdos=, #=zO6457TajDDxDJIsKqS1bbzDMLckn #=zKFlJyLE=)
	{
		if (this.#=zQ4_NWTk= != (#=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs=)1)
		{
			return #=zQrqFdos=.#=zvnZc$RhG_1Du().CompareTo(#=zKFlJyLE=.#=zvnZc$RhG_1Du());
		}
		if (#=zQrqFdos=.#=zFMDiymuLQ7_4() != #=zKFlJyLE=.#=zFMDiymuLQ7_4())
		{
			return #=zQrqFdos=.#=zFMDiymuLQ7_4().CompareTo(#=zKFlJyLE=.#=zFMDiymuLQ7_4());
		}
		return #=zQrqFdos=.#=zMuFMjGQ=().CompareTo(#=zKFlJyLE=.#=zMuFMjGQ=());
	}

	// Token: 0x040009FA RID: 2554
	private #=zglx1ra98E8y6JISOYEjaV4$5JVTaE7CXVQ==.#=zArez$Gs= #=zQ4_NWTk=;

	// Token: 0x0200024B RID: 587
	public enum #=zArez$Gs=
	{

	}
}
