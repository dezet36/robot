﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000234 RID: 564
internal sealed class #=zesBR9QdKGIBsSHNpxZRXyrToxyjs2cT1owEG06E=
{
	// Token: 0x06001142 RID: 4418 RVA: 0x000847B0 File Offset: 0x000829B0
	public #=zesBR9QdKGIBsSHNpxZRXyrToxyjs2cT1owEG06E=(Dictionary<string, object> #=zwIagxaleiGlavydUhA==)
	{
		this.#=zbsxKkj4=(JSONManager.GetInt(#=zwIagxaleiGlavydUhA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0));
		this.#=zM_tYMjXvmqJR(Convert.ToInt32(#=zwIagxaleiGlavydUhA==[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883)]));
		this.#=zouz5bItYqB1z((#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ==)JSONManager.GetInt(#=zwIagxaleiGlavydUhA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070399), 0));
		this.#=zGScny1FXrXT3(Convert.ToInt32(#=zwIagxaleiGlavydUhA==[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094)]));
		Dictionary<string, object> dictionary = JSONManager.ExtractDictionary(#=zwIagxaleiGlavydUhA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581));
		this.#=ziwANwdpi$fyQ(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102), false));
		this.#=zmbLvS_SO9hoz(JSONManager.ExtractDate(dictionary, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069086), false));
		this.#=zZOcUKRjdBdxesL0MVA==(TimeSpan.FromMilliseconds((double)(JSONManager.ExtractLong(#=zwIagxaleiGlavydUhA==, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907), 0L) / 10000L)));
	}

	// Token: 0x06001143 RID: 4419 RVA: 0x0008488C File Offset: 0x00082A8C
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06001144 RID: 4420 RVA: 0x00084894 File Offset: 0x00082A94
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001145 RID: 4421 RVA: 0x000848A0 File Offset: 0x00082AA0
	public int #=z9$XFwTaUKMJD()
	{
		return this.#=zKlNoO_yqqS_jEHSr$WYFu$4=;
	}

	// Token: 0x06001146 RID: 4422 RVA: 0x000848A8 File Offset: 0x00082AA8
	public void #=zM_tYMjXvmqJR(int #=z$Ib9gYQ=)
	{
		this.#=zKlNoO_yqqS_jEHSr$WYFu$4= = #=z$Ib9gYQ=;
	}

	// Token: 0x06001147 RID: 4423 RVA: 0x000848B4 File Offset: 0x00082AB4
	public #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zTmF_oj8L9Zp6()
	{
		return this.#=zosL6CFSBc27tQtbS0Q==;
	}

	// Token: 0x06001148 RID: 4424 RVA: 0x000848BC File Offset: 0x00082ABC
	public void #=zouz5bItYqB1z(#=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=z$Ib9gYQ=)
	{
		this.#=zosL6CFSBc27tQtbS0Q== = #=z$Ib9gYQ=;
	}

	// Token: 0x06001149 RID: 4425 RVA: 0x000848C8 File Offset: 0x00082AC8
	public int #=z_0mmdVV3_scA()
	{
		return this.#=z7if2vyv1Xq1wde1RDQ==;
	}

	// Token: 0x0600114A RID: 4426 RVA: 0x000848D0 File Offset: 0x00082AD0
	public void #=zGScny1FXrXT3(int #=z$Ib9gYQ=)
	{
		this.#=z7if2vyv1Xq1wde1RDQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600114B RID: 4427 RVA: 0x000848DC File Offset: 0x00082ADC
	public DateTime #=zkviZ5fzRH2Z7()
	{
		return this.#=zRkCNiQuSgtQ67wRaQtuY_2Q=;
	}

	// Token: 0x0600114C RID: 4428 RVA: 0x000848E4 File Offset: 0x00082AE4
	public void #=ziwANwdpi$fyQ(DateTime #=z$Ib9gYQ=)
	{
		this.#=zRkCNiQuSgtQ67wRaQtuY_2Q= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600114D RID: 4429 RVA: 0x000848F0 File Offset: 0x00082AF0
	public DateTime #=zfliie8E9uUw0()
	{
		return this.#=zJb9tUdGgTGHerS7K_Bur4iQ=;
	}

	// Token: 0x0600114E RID: 4430 RVA: 0x000848F8 File Offset: 0x00082AF8
	public void #=zmbLvS_SO9hoz(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJb9tUdGgTGHerS7K_Bur4iQ= = #=z$Ib9gYQ=;
	}

	// Token: 0x0600114F RID: 4431 RVA: 0x00084904 File Offset: 0x00082B04
	public TimeSpan #=zcfezcX9BWjs0gO0tLA==()
	{
		return this.#=zrheBsDOZjqJ$OGn_yez$ZCD7mcF$;
	}

	// Token: 0x06001150 RID: 4432 RVA: 0x0008490C File Offset: 0x00082B0C
	public void #=zZOcUKRjdBdxesL0MVA==(TimeSpan #=z$Ib9gYQ=)
	{
		this.#=zrheBsDOZjqJ$OGn_yez$ZCD7mcF$ = #=z$Ib9gYQ=;
	}

	// Token: 0x04000956 RID: 2390
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000957 RID: 2391
	private int #=zKlNoO_yqqS_jEHSr$WYFu$4=;

	// Token: 0x04000958 RID: 2392
	private #=zcle_Zo8QQ6acCVD2KrAxidjvvtAGMOGvAQ== #=zosL6CFSBc27tQtbS0Q==;

	// Token: 0x04000959 RID: 2393
	private int #=z7if2vyv1Xq1wde1RDQ==;

	// Token: 0x0400095A RID: 2394
	private DateTime #=zRkCNiQuSgtQ67wRaQtuY_2Q=;

	// Token: 0x0400095B RID: 2395
	private DateTime #=zJb9tUdGgTGHerS7K_Bur4iQ=;

	// Token: 0x0400095C RID: 2396
	private TimeSpan #=zrheBsDOZjqJ$OGn_yez$ZCD7mcF$;
}
