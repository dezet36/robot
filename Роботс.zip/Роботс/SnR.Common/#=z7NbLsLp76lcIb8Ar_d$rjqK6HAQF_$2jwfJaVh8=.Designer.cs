﻿// Token: 0x0200008C RID: 140
internal sealed partial class #=z7NbLsLp76lcIb8Ar_d$rjqK6HAQF_$2jwfJaVh8= : global::System.Windows.Forms.Form
{
	// Token: 0x060003D2 RID: 978 RVA: 0x00021780 File Offset: 0x0001F980
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x04000158 RID: 344
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
