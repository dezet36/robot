﻿using System;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000280 RID: 640
internal sealed class #=zlsoMZFdAX0vDkkzGOA_uys_lXE7s : RecordData
{
	// Token: 0x06001359 RID: 4953 RVA: 0x000961E0 File Offset: 0x000943E0
	public #=zlsoMZFdAX0vDkkzGOA_uys_lXE7s(Record #=zLrbWuhk=) : base(#=zLrbWuhk=)
	{
		sbyte[] data = #=zLrbWuhk=.Data;
		this.#=zmSUW2Tjz0XuU = (data[0] == 1);
	}

	// Token: 0x0600135A RID: 4954 RVA: 0x00096208 File Offset: 0x00094408
	public bool #=zdtRq1EhsFB049kj0cA==()
	{
		return this.#=zmSUW2Tjz0XuU;
	}

	// Token: 0x04000B2E RID: 2862
	private bool #=zmSUW2Tjz0XuU;
}
