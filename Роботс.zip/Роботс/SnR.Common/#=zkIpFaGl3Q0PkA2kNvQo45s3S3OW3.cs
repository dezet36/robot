﻿using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Globalization;
using System.Resources;

// Token: 0x02000273 RID: 627
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
[DebuggerNonUserCode]
internal sealed class #=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3
{
	// Token: 0x060012F2 RID: 4850 RVA: 0x00092B30 File Offset: 0x00090D30
	internal #=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3()
	{
	}

	// Token: 0x060012F3 RID: 4851 RVA: 0x00092B38 File Offset: 0x00090D38
	internal static ResourceManager #=z8xqHywTQ1rB7()
	{
		if (#=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3.#=zwJeRUqAT1Dmo == null)
		{
			#=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3.#=zwJeRUqAT1Dmo = new ResourceManager(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908928970), typeof(#=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3).Assembly);
		}
		return #=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3.#=zwJeRUqAT1Dmo;
	}

	// Token: 0x060012F4 RID: 4852 RVA: 0x00092B6C File Offset: 0x00090D6C
	internal static CultureInfo #=zvcRBQ2hMeYnd()
	{
		return #=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3.#=zjiZH9pMOnU8R;
	}

	// Token: 0x060012F5 RID: 4853 RVA: 0x00092B74 File Offset: 0x00090D74
	internal static void #=zD5KPgUzCsgYC(CultureInfo #=z$Ib9gYQ=)
	{
		#=zkIpFaGl3Q0PkA2kNvQo45s3S3OW3.#=zjiZH9pMOnU8R = #=z$Ib9gYQ=;
	}

	// Token: 0x04000AE2 RID: 2786
	private static ResourceManager #=zwJeRUqAT1Dmo;

	// Token: 0x04000AE3 RID: 2787
	private static CultureInfo #=zjiZH9pMOnU8R;
}
