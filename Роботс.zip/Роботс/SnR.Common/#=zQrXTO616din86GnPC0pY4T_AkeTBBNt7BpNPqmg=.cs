﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Tasks;

// Token: 0x0200018B RID: 395
internal sealed class #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=
{
	// Token: 0x06000B49 RID: 2889 RVA: 0x00056E6C File Offset: 0x0005506C
	private #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=(int #=zLeeSKrg=)
	{
		this.#=z5Fzkwmc= = #=zLeeSKrg=;
		this.#=zXuAj7VpzdrhL = new ConcurrentDictionary<int, int>();
		this.#=zgFYJd8hfo6F_ = null;
	}

	// Token: 0x06000B4B RID: 2891 RVA: 0x00056EA4 File Offset: 0x000550A4
	public static #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zkXP_Qng=(int #=zLeeSKrg=)
	{
		object obj;
		if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE == null)
		{
			obj = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE == null)
				{
					#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE = new List<#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=>();
				}
			}
		}
		int count = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE.Count;
		for (int i = 0; i < count; i++)
		{
			if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE[i].#=z5Fzkwmc= == #=zLeeSKrg=)
			{
				return #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE[i];
			}
		}
		obj = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zSV4$mlFB34WM;
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= result;
		lock (obj)
		{
			count = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE.Count;
			for (int j = 0; j < count; j++)
			{
				if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE[j].#=z5Fzkwmc= == #=zLeeSKrg=)
				{
					return #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE[j];
				}
			}
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= = new #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=(#=zLeeSKrg=);
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zJIH24ArZ8MmE.Add(#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=);
			result = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=;
		}
		return result;
	}

	// Token: 0x06000B4C RID: 2892 RVA: 0x00056FB0 File Offset: 0x000551B0
	public bool #=zBBWgm0Q=(int #=zvPiOyGQ=, int #=zbwrJfOI=)
	{
		return this.#=zXuAj7VpzdrhL.GetOrAdd(#=zbwrJfOI=, #=zvPiOyGQ=) == #=zvPiOyGQ=;
	}

	// Token: 0x06000B4D RID: 2893 RVA: 0x00056FC4 File Offset: 0x000551C4
	public bool #=zfKZKx18=(int #=zvPiOyGQ=, int #=zbwrJfOI=)
	{
		int num;
		return this.#=zXuAj7VpzdrhL.TryGetValue(#=zbwrJfOI=, ref num) && num != #=zvPiOyGQ=;
	}

	// Token: 0x06000B4E RID: 2894 RVA: 0x00056FEC File Offset: 0x000551EC
	public void #=zv1sSxaY=(int #=zbwrJfOI=)
	{
		int num;
		this.#=zXuAj7VpzdrhL.TryRemove(#=zbwrJfOI=, ref num);
	}

	// Token: 0x06000B4F RID: 2895 RVA: 0x00057008 File Offset: 0x00055208
	public void #=zywN9YWzCtruB(int #=zvPiOyGQ=)
	{
		List<int> list = new List<int>();
		foreach (int num in this.#=zXuAj7VpzdrhL.Keys)
		{
			if (this.#=zXuAj7VpzdrhL[num] == #=zvPiOyGQ=)
			{
				list.Add(num);
			}
		}
		foreach (int num2 in list)
		{
			int num3;
			this.#=zXuAj7VpzdrhL.TryRemove(num2, ref num3);
		}
	}

	// Token: 0x06000B50 RID: 2896 RVA: 0x000570B8 File Offset: 0x000552B8
	public static DateTime #=ztENUqEM=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, Task #=zbl0jxDRgnLpz, out bool #=zS_OFaonDOolLAMepqw==)
	{
		return #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(#=z8StzeqE=.#=zYgvZuBwR$a1C()).#=zIO8Scmh2ir2R(#=z8StzeqE=, #=zbl0jxDRgnLpz, out #=zS_OFaonDOolLAMepqw==);
	}

	// Token: 0x06000B51 RID: 2897 RVA: 0x000570D0 File Offset: 0x000552D0
	private DateTime #=zIO8Scmh2ir2R(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, Task #=zbl0jxDRgnLpz, out bool #=zul2epUUa8tHZKwGmmQ==)
	{
		if (this.#=zgFYJd8hfo6F_ == null)
		{
			object obj = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (this.#=zgFYJd8hfo6F_ == null)
				{
					this.#=zwmvx4la336R7(#=z8StzeqE=, #=zbl0jxDRgnLpz);
				}
			}
		}
		if (!this.#=zgFYJd8hfo6F_.ContainsKey(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()))
		{
			object obj = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zSV4$mlFB34WM;
			lock (obj)
			{
				DateTime dateTime = #=zbl0jxDRgnLpz.ExecutionTime.Date + this.#=zwEAsmns=;
				if (dateTime < DateTime.Now - this.#=zXZ73WrE=)
				{
					dateTime += TimeSpan.FromDays(1.0);
				}
				if (dateTime <= DateTime.Now)
				{
					dateTime = DateTime.MinValue;
				}
				this.#=zgFYJd8hfo6F_.Add(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=(), new #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A
				{
					#=zkuHl9zU= = ((dateTime != DateTime.MinValue) ? dateTime : DateTime.Now),
					#=zta9r1iA= = TimeSpan.FromHours(24.0),
					#=zjVz2N3Kphgjg = false
				});
				this.#=zwEAsmns= += this.#=zXZ73WrE=;
				if (this.#=zwEAsmns= > this.#=zrm_K2fJRh3OP)
				{
					this.#=zXZ73WrE= = TimeSpan.FromSeconds(this.#=zXZ73WrE=.TotalSeconds / 2.0);
					this.#=zwEAsmns= = this.#=zod3C$sl8NPsd + TimeSpan.FromSeconds(this.#=zXZ73WrE=.TotalSeconds / 2.0);
				}
				this.#=z6vCq2FuH03Y7();
				#=zul2epUUa8tHZKwGmmQ== = false;
				return dateTime;
			}
		}
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A #=z4X5R9wJscP5A = this.#=zgFYJd8hfo6F_[#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()];
		#=zul2epUUa8tHZKwGmmQ== = true;
		if (!#=z4X5R9wJscP5A.#=zjVz2N3Kphgjg)
		{
			#=z4X5R9wJscP5A.#=zjVz2N3Kphgjg = true;
			return #=z4X5R9wJscP5A.#=zkuHl9zU=;
		}
		return DateTime.MinValue;
	}

	// Token: 0x06000B52 RID: 2898 RVA: 0x000572E4 File Offset: 0x000554E4
	public static void #=z_JR3E3WhnnqK(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, DateTime #=z7qfihz8dN9jM, TimeSpan #=zDMrQCas=)
	{
		#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zkXP_Qng=(#=z8StzeqE=.#=zYgvZuBwR$a1C());
		if (#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg= != null && #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zgFYJd8hfo6F_ != null && #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zgFYJd8hfo6F_.ContainsKey(#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()))
		{
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A #=z4X5R9wJscP5A = #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=zgFYJd8hfo6F_[#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zMuFMjGQ=()];
			#=z4X5R9wJscP5A.#=zkuHl9zU= = #=z7qfihz8dN9jM;
			#=z4X5R9wJscP5A.#=zta9r1iA= = #=zDMrQCas=;
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z6vCq2FuH03Y7();
		}
	}

	// Token: 0x06000B53 RID: 2899 RVA: 0x0005734C File Offset: 0x0005554C
	private void #=z6vCq2FuH03Y7()
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938447), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), null, this.#=z5Fzkwmc=);
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938415), new object[]
		{
			(long)this.#=zod3C$sl8NPsd.TotalMilliseconds,
			(long)this.#=zrm_K2fJRh3OP.TotalMilliseconds,
			(long)this.#=zwEAsmns=.TotalMilliseconds,
			(long)this.#=zXZ73WrE=.TotalMilliseconds
		});
		foreach (int num in this.#=zgFYJd8hfo6F_.Keys)
		{
			#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A #=z4X5R9wJscP5A = this.#=zgFYJd8hfo6F_[num];
			stringBuilder.AppendFormat(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938385), num, JSONManager.EncodeTime(#=z4X5R9wJscP5A.#=zkuHl9zU=, false), #=z4X5R9wJscP5A.#=zta9r1iA=.TotalMilliseconds);
		}
		#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, stringBuilder.ToString(), Encoding.UTF8, false);
	}

	// Token: 0x06000B54 RID: 2900 RVA: 0x00057480 File Offset: 0x00055680
	private void #=zwmvx4la336R7(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=, Task #=zbl0jxDRgnLpz)
	{
		string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908938447), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==(), null, this.#=z5Fzkwmc=);
		this.#=zgFYJd8hfo6F_ = new Dictionary<int, #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A>();
		if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
		{
			try
			{
				string text = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=);
				if (!string.IsNullOrEmpty(text))
				{
					string[] array = text.Split(new char[]
					{
						'|'
					});
					if (array.Length != 0)
					{
						string[] array2 = array[0].Split(new char[]
						{
							','
						});
						if (array2.Length == 4)
						{
							for (int i = 1; i < array.Length; i++)
							{
								string[] array3 = array[i].Split(new char[]
								{
									','
								});
								if (array3.Length == 3)
								{
									#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A #=z4X5R9wJscP5A = new #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A
									{
										#=zkuHl9zU= = JSONManager.DecodeTime(array3[1], false),
										#=zta9r1iA= = TimeSpan.FromMilliseconds((double)Convert.ToInt64(array3[2])),
										#=zjVz2N3Kphgjg = false
									};
									while (#=z4X5R9wJscP5A.#=zkuHl9zU= < DateTime.Now - TimeSpan.FromMinutes(10.0))
									{
										#=z4X5R9wJscP5A.#=zkuHl9zU= += #=z4X5R9wJscP5A.#=zta9r1iA=;
									}
									this.#=zgFYJd8hfo6F_.Add(Convert.ToInt32(array3[0]), #=z4X5R9wJscP5A);
								}
							}
							this.#=zod3C$sl8NPsd = TimeSpan.FromMilliseconds((double)Convert.ToInt64(array2[0]));
							this.#=zrm_K2fJRh3OP = TimeSpan.FromMilliseconds((double)Convert.ToInt64(array2[1]));
							this.#=zwEAsmns= = TimeSpan.FromMilliseconds((double)Convert.ToInt64(array2[2]));
							this.#=zXZ73WrE= = TimeSpan.FromMilliseconds((double)Convert.ToInt64(array2[3]));
							return;
						}
					}
				}
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(null, #=zN_s5Z5A=);
			}
		}
		this.#=zod3C$sl8NPsd = #=zbl0jxDRgnLpz.ExecutionTime.TimeOfDay;
		this.#=zrm_K2fJRh3OP = this.#=zod3C$sl8NPsd + TimeSpan.FromHours(#=z8StzeqE=.#=zv2Kyu17YrGOC().AutoRobMaxPeriodHours);
		this.#=zwEAsmns= = this.#=zod3C$sl8NPsd;
		this.#=zXZ73WrE= = TimeSpan.FromHours(0.5);
	}

	// Token: 0x04000610 RID: 1552
	private int #=z5Fzkwmc=;

	// Token: 0x04000611 RID: 1553
	private ConcurrentDictionary<int, int> #=zXuAj7VpzdrhL;

	// Token: 0x04000612 RID: 1554
	private TimeSpan #=zod3C$sl8NPsd;

	// Token: 0x04000613 RID: 1555
	private TimeSpan #=zrm_K2fJRh3OP;

	// Token: 0x04000614 RID: 1556
	private TimeSpan #=zwEAsmns=;

	// Token: 0x04000615 RID: 1557
	private TimeSpan #=zXZ73WrE=;

	// Token: 0x04000616 RID: 1558
	private Dictionary<int, #=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=.#=z4X5R9wJscP5A> #=zgFYJd8hfo6F_;

	// Token: 0x04000617 RID: 1559
	private static List<#=zQrXTO616din86GnPC0pY4T_AkeTBBNt7BpNPqmg=> #=zJIH24ArZ8MmE = null;

	// Token: 0x04000618 RID: 1560
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x0200018C RID: 396
	internal sealed class #=z4X5R9wJscP5A
	{
		// Token: 0x04000619 RID: 1561
		public DateTime #=zkuHl9zU=;

		// Token: 0x0400061A RID: 1562
		public TimeSpan #=zta9r1iA=;

		// Token: 0x0400061B RID: 1563
		public bool #=zjVz2N3Kphgjg;
	}
}
