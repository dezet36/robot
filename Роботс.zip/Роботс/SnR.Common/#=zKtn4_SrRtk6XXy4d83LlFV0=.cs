﻿using System;
using System.Collections;
using System.Text;
using common;
using NExcel;
using NExcel.Biff;

// Token: 0x02000137 RID: 311
internal sealed class #=zKtn4_SrRtk6XXy4d83LlFV0= : #=zrACqpkJvpkMu2ypmK4UXXdQ=, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000822 RID: 2082 RVA: 0x000418C4 File Offset: 0x0003FAC4
	public #=zKtn4_SrRtk6XXy4d83LlFV0=(WorkbookSettings #=z4JisLog=)
	{
		this.#=z6bRJXNQ= = #=z4JisLog=;
	}

	// Token: 0x06000823 RID: 2083 RVA: 0x000418D4 File Offset: 0x0003FAD4
	public #=zKtn4_SrRtk6XXy4d83LlFV0=(#=zya1IgD5Efg9ZmZdd$BLsbHs= #=zeIs4bFM=, WorkbookSettings #=z4JisLog=)
	{
		this.#=z6bRJXNQ= = #=z4JisLog=;
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=) == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zS_qq6Ks=)
		{
			this.#=zvn3I_mE= |= 16;
			return;
		}
		if (#=zeIs4bFM=.#=zWTaLiHU=(this.#=z6bRJXNQ=) == #=zGjUKOJRgFhfLTz4NT1WbagM=.#=zJ$VOQdA=)
		{
			this.#=zvn3I_mE= |= 2;
		}
	}

	// Token: 0x06000825 RID: 2085 RVA: 0x0004194C File Offset: 0x0003FB4C
	internal void #=zVy1K$GX42gsg(#=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=z$Ib9gYQ=)
	{
		this.#=zCD3_rQp2Bjyz = #=z$Ib9gYQ=;
		this.#=zvn3I_mE= |= 2;
	}

	// Token: 0x06000826 RID: 2086 RVA: 0x00041964 File Offset: 0x0003FB64
	public bool #=zZOFUOewkm7ea()
	{
		return (this.#=zvn3I_mE= & 18) != 0;
	}

	// Token: 0x06000827 RID: 2087 RVA: 0x00041974 File Offset: 0x0003FB74
	public bool #=zFslVfpdTyVHi()
	{
		return (this.#=zvn3I_mE= & 16) != 0;
	}

	// Token: 0x06000828 RID: 2088 RVA: 0x00041984 File Offset: 0x0003FB84
	public bool #=z6Qzp6XDq8A9H()
	{
		return (this.#=zvn3I_mE= & 8) != 0;
	}

	// Token: 0x06000829 RID: 2089 RVA: 0x00041994 File Offset: 0x0003FB94
	internal override sbyte[] #=ztbIWLuVjfGLU()
	{
		sbyte[] array = new sbyte[0];
		if (this.#=zFslVfpdTyVHi())
		{
			#=zoImewjUBfkPyF1oU_G4atTk=[] array2 = this.#=zb$ssayA=();
			for (int i = array2.Length - 1; i >= 0; i--)
			{
				sbyte[] array3 = array2[i].#=ztbIWLuVjfGLU();
				sbyte[] array4 = new sbyte[array.Length + array3.Length];
				Array.Copy(array, 0, array4, 0, array.Length);
				Array.Copy(array3, 0, array4, array.Length, array3.Length);
				array = array4;
			}
			sbyte[] array5 = new sbyte[array.Length + 4];
			Array.Copy(array, 0, array5, 0, array.Length);
			array5[array.Length] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=.#=zd$BbM3Y=();
			array5[array.Length + 1] = 16;
			array = array5;
		}
		else if (this.#=z0bYFz5k=())
		{
			return this.#=zCiZcbUA=();
		}
		return array;
	}

	// Token: 0x0600082A RID: 2090 RVA: 0x00041A48 File Offset: 0x0003FC48
	internal override int #=zXiDCyaHY58$0()
	{
		return 3;
	}

	// Token: 0x0600082B RID: 2091 RVA: 0x00041A4C File Offset: 0x0003FC4C
	public int #=zJjGe$TU=(sbyte[] #=zJ5GWysk=, int #=z4J_G3VM=)
	{
		this.#=zvn3I_mE= = (int)#=zJ5GWysk=[#=z4J_G3VM=];
		this.#=zp8czxHA= = IntegerHelper.getInt(#=zJ5GWysk=[#=z4J_G3VM= + 1], #=zJ5GWysk=[#=z4J_G3VM= + 2]);
		return 3;
	}

	// Token: 0x0600082C RID: 2092 RVA: 0x00041A70 File Offset: 0x0003FC70
	public bool #=z0bYFz5k=()
	{
		return (this.#=zvn3I_mE= & 2) != 0;
	}

	// Token: 0x0600082D RID: 2093 RVA: 0x00041A80 File Offset: 0x0003FC80
	public override void #=zb$ssayA=(Stack #=zWj7xLq8=)
	{
		if ((this.#=zvn3I_mE= & 16) != 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4= = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
			this.#=zdJYbEvQ=(#=zpvGJrv4=);
			return;
		}
		if ((this.#=zvn3I_mE= & 2) != 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk= #=zpvGJrv4=2 = (#=zoImewjUBfkPyF1oU_G4atTk=)#=zWj7xLq8=.Pop();
			this.#=zdJYbEvQ=(#=zpvGJrv4=2);
		}
	}

	// Token: 0x0600082E RID: 2094 RVA: 0x00041ACC File Offset: 0x0003FCCC
	public override void #=zSpOkW5A=(StringBuilder #=zXvwCnz8=)
	{
		if ((this.#=zvn3I_mE= & 16) != 0)
		{
			#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
			#=zXvwCnz8=.Append(#=zGjUKOJRgFhfLTz4NT1WbagM=.#=zS_qq6Ks=.#=zLCn5oL8=(this.#=z6bRJXNQ=));
			#=zXvwCnz8=.Append('(');
			array[0].#=zSpOkW5A=(#=zXvwCnz8=);
			#=zXvwCnz8=.Append(')');
			return;
		}
		if ((this.#=zvn3I_mE= & 2) != 0)
		{
			#=zXvwCnz8=.Append(#=zGjUKOJRgFhfLTz4NT1WbagM=.#=zJ$VOQdA=.#=zLCn5oL8=(this.#=z6bRJXNQ=));
			#=zXvwCnz8=.Append('(');
			#=zoImewjUBfkPyF1oU_G4atTk=[] array2 = this.#=zCD3_rQp2Bjyz.#=zb$ssayA=();
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].#=zSpOkW5A=(#=zXvwCnz8=);
				#=zXvwCnz8=.Append(',');
			}
			array2[0].#=zSpOkW5A=(#=zXvwCnz8=);
			#=zXvwCnz8=.Append(')');
		}
	}

	// Token: 0x0600082F RID: 2095 RVA: 0x00041B84 File Offset: 0x0003FD84
	private sbyte[] #=zCiZcbUA=()
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zCD3_rQp2Bjyz.#=zb$ssayA=();
		int num = array.Length;
		sbyte[] array2 = array[0].#=ztbIWLuVjfGLU();
		int num2 = array2.Length;
		sbyte[] array3 = new sbyte[array2.Length + 4];
		Array.Copy(array2, 0, array3, 0, array2.Length);
		array2 = array3;
		array2[num2] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=.#=zd$BbM3Y=();
		array2[num2 + 1] = 2;
		int num3 = num2 + 2;
		sbyte[] array4 = array[1].#=ztbIWLuVjfGLU();
		array3 = new sbyte[array2.Length + array4.Length];
		Array.Copy(array2, 0, array3, 0, array2.Length);
		Array.Copy(array4, 0, array3, array2.Length, array4.Length);
		array2 = array3;
		num2 = array2.Length;
		array3 = new sbyte[array2.Length + 4];
		Array.Copy(array2, 0, array3, 0, array2.Length);
		array2 = array3;
		array2[num2] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=.#=zd$BbM3Y=();
		array2[num2 + 1] = 8;
		int num4 = num2 + 2;
		if (num > 2)
		{
			IntegerHelper.getTwoBytes(array2.Length - num3 - 2, array2, num3);
			sbyte[] array5 = array[num - 1].#=ztbIWLuVjfGLU();
			array3 = new sbyte[array2.Length + array5.Length];
			Array.Copy(array2, 0, array3, 0, array2.Length);
			Array.Copy(array5, 0, array3, array2.Length, array5.Length);
			array2 = array3;
			num2 = array2.Length;
			array3 = new sbyte[array2.Length + 4];
			Array.Copy(array2, 0, array3, 0, array2.Length);
			array2 = array3;
			array2[num2] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zk80xNLY=.#=zd$BbM3Y=();
			array2[num2 + 1] = 8;
			array2[num2 + 2] = 3;
		}
		num2 = array2.Length;
		array3 = new sbyte[array2.Length + 4];
		Array.Copy(array2, 0, array3, 0, array2.Length);
		array2 = array3;
		array2[num2] = #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zgIROC21YZTQqCTzn6i884to=.#=zd$BbM3Y=();
		array2[num2 + 1] = (sbyte)num;
		array2[num2 + 2] = 1;
		array2[num2 + 3] = 0;
		int num5 = array2.Length - 1;
		if (num < 3)
		{
			IntegerHelper.getTwoBytes(num5 - num3 - 5, array2, num3);
		}
		IntegerHelper.getTwoBytes(num5 - num4 - 2, array2, num4);
		return array2;
	}

	// Token: 0x06000830 RID: 2096 RVA: 0x00041D40 File Offset: 0x0003FF40
	public override void #=zQTeahir6c1bXCjjSVA==(int #=zUFUpoGQeXcCf, int #=zJhSli$dVSPlw)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zQTeahir6c1bXCjjSVA==(#=zUFUpoGQeXcCf, #=zJhSli$dVSPlw);
		}
	}

	// Token: 0x06000831 RID: 2097 RVA: 0x00041D6C File Offset: 0x0003FF6C
	public override void #=z8np1KO7r9jOa(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z8np1KO7r9jOa(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06000832 RID: 2098 RVA: 0x00041D9C File Offset: 0x0003FF9C
	internal override void #=z3rv1QMSnkjhC(int #=zoAAA4zDu4OU$, int #=zMYEXL$w=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z3rv1QMSnkjhC(#=zoAAA4zDu4OU$, #=zMYEXL$w=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06000833 RID: 2099 RVA: 0x00041DCC File Offset: 0x0003FFCC
	internal override void #=z6ameTnv5qfpk(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=z6ameTnv5qfpk(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x06000834 RID: 2100 RVA: 0x00041DFC File Offset: 0x0003FFFC
	internal override void #=zskShM9_RW9FD(int #=zoAAA4zDu4OU$, int #=zg9A8_dw=, bool #=z8f56V5lpWtIC)
	{
		#=zoImewjUBfkPyF1oU_G4atTk=[] array = this.#=zb$ssayA=();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].#=zskShM9_RW9FD(#=zoAAA4zDu4OU$, #=zg9A8_dw=, #=z8f56V5lpWtIC);
		}
	}

	// Token: 0x040004AB RID: 1195
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=zKtn4_SrRtk6XXy4d83LlFV0=));

	// Token: 0x040004AC RID: 1196
	private int #=zvn3I_mE=;

	// Token: 0x040004AD RID: 1197
	private int #=zp8czxHA=;

	// Token: 0x040004AE RID: 1198
	private WorkbookSettings #=z6bRJXNQ=;

	// Token: 0x040004AF RID: 1199
	private #=zhedbtRjZ$dqqQmBqcqCp80cF$3Q1 #=zCD3_rQp2Bjyz;
}
