﻿using System;
using System.Collections.Generic;
using System.Text;
using Skink.SnR.Common.City;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x020001DE RID: 478
internal sealed class #=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw== : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x06000E7A RID: 3706 RVA: 0x0007355C File Offset: 0x0007175C
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zawloLR4AQAF_32q7rQ== = #=zuJjQ1XU=.#=zXzBC$aJalrr0Db$QLCfSwSA=();
		this.#=ze1Gd_NVFuPrnOCdIWtBZBBk= = #=zuJjQ1XU=.#=zdZA4x4oPUECN4Za4xxkSMFn4pxoU();
		this.#=zCY4az9$WUjLsEJ7fgg== = #=zuJjQ1XU=.#=zu0512GNdOuq21KSBDS8fmqw=();
		this.#=z4KB$bKo= = #=zuJjQ1XU=.#=zcVljhXy3TCOtJ0MIzgy$uEY=();
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsSpeedUpWLItemBreakingWithBoosters)
		{
			this.#=zZKzdsPms7IDM = new #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E=(this.#=z8StzeqE=, #=zuJjQ1XU=);
		}
	}

	// Token: 0x06000E7B RID: 3707 RVA: 0x000735C0 File Offset: 0x000717C0
	protected override void #=zvb5bnug=()
	{
		#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM= = #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95.#=zi1hFJwI=();
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zDD3FFppStvqM;
		List<int> list;
		Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz = this.#=zldPKdTSMuVYS(out #=zDD3FFppStvqM, out list);
		Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zbu0tMEwpFQv = this.#=zYMu2dyaJPpZk();
		TimeSpan timeSpan = TimeSpan.MaxValue;
		string #=zQtK9D3Etaxd_;
		#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = this.#=zQ1sOEE_VNKs7(#=zrJCtPlbREqtz, #=zbu0tMEwpFQv, #=zC7NDbDM=, out #=zQtK9D3Etaxd_);
		this.#=z13x0diI1ygJE(#=zrJCtPlbREqtz, #=zbu0tMEwpFQv, #=zC7NDbDM=);
		this.#=zStNV$ojBpnYB(#=zrJCtPlbREqtz, #=zC7NDbDM=);
		this.#=zhLGkHxVzB648uViERg==(#=zC7NDbDM=);
		this.#=zzAgV6gTNgLF7();
		this.#=zFBr8mHfDg2bD(#=zDD3FFppStvqM, list);
		bool flag = false;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsSpeedUpWLItemBreakingWithBoosters && this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==() - list.Count < this.#=z8StzeqE=.#=zv2Kyu17YrGOC().SpeedUpWLItemBreakingFreeCells)
		{
			flag = true;
		}
		if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= != null)
		{
			if (flag)
			{
				base.#=zL1HTbwC75LO$(#=zQtK9D3Etaxd_);
			}
			else
			{
				timeSpan = TimeSpan.FromSeconds((double)#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zZwcQkwkOzFoj());
			}
		}
		if (flag && this.#=zZKzdsPms7IDM != null)
		{
			timeSpan = TimeSpan.FromSeconds((double)this.#=zZKzdsPms7IDM.#=zooxTzWuNzmISknjjazw$BD4GOot5(this.#=zawloLR4AQAF_32q7rQ==));
		}
		if (timeSpan < TimeSpan.Zero)
		{
			timeSpan = TimeSpan.Zero;
		}
		if (timeSpan < this.#=zcDRV51Ut$7oP.RepeatDelayMax)
		{
			this.#=zcDRV51Ut$7oP.NextExecutionTime = DateTime.Now + timeSpan + TimeSpan.FromSeconds(180.0);
		}
	}

	// Token: 0x06000E7C RID: 3708 RVA: 0x000736F4 File Offset: 0x000718F4
	private Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zldPKdTSMuVYS(out List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zDD3FFppStvqM, out List<int> #=zw1YH1npzZNWxxlSqikR7758=)
	{
		int count = this.#=zawloLR4AQAF_32q7rQ==.Count;
		Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> dictionary = new Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>>();
		#=zDD3FFppStvqM = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
		#=zw1YH1npzZNWxxlSqikR7758= = new List<int>();
		for (int i = 0; i < count; i++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = this.#=zawloLR4AQAF_32q7rQ==[i];
			if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)1 || #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
			{
				Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary2;
				if (dictionary.ContainsKey(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zZOFUOewkm7ea()))
				{
					dictionary2 = dictionary[#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zZOFUOewkm7ea()];
				}
				else
				{
					dictionary2 = new Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>();
					dictionary.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zZOFUOewkm7ea(), dictionary2);
				}
				List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list;
				if (dictionary2.ContainsKey(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur()))
				{
					list = dictionary2[#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur()];
				}
				else
				{
					list = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
					dictionary2.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(), list);
				}
				bool flag = false;
				for (int j = 0; j < list.Count; j++)
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list[j];
					if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r() < #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() || (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r() == #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() && !#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=ztP$zSGbniHTJ() && #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=ztP$zSGbniHTJ()))
					{
						list.Insert(j, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
				}
			}
			#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q== #=zpym8P$oCmghwvUlJ3Q== = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo();
			if (#=zpym8P$oCmghwvUlJ3Q== != (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)2)
			{
				if (#=zpym8P$oCmghwvUlJ3Q== == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
				{
					#=zw1YH1npzZNWxxlSqikR7758=.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zdDINCgoQlCgN());
				}
			}
			else if (!#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zLjjRU3hSvJfH())
			{
				#=zDD3FFppStvqM.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
			}
		}
		for (int k = 0; k < this.#=ze1Gd_NVFuPrnOCdIWtBZBBk=.Count; k++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3 = this.#=ze1Gd_NVFuPrnOCdIWtBZBBk=[k];
			#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q== #=zpym8P$oCmghwvUlJ3Q== = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zi66ZCDXN_8bo();
			if (#=zpym8P$oCmghwvUlJ3Q== != (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)2)
			{
				if (#=zpym8P$oCmghwvUlJ3Q== == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
				{
					#=zw1YH1npzZNWxxlSqikR7758=.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zdDINCgoQlCgN());
				}
			}
			else if (!#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zLjjRU3hSvJfH())
			{
				#=zDD3FFppStvqM.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3);
			}
		}
		return dictionary;
	}

	// Token: 0x06000E7D RID: 3709 RVA: 0x000738C8 File Offset: 0x00071AC8
	private Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zYMu2dyaJPpZk()
	{
		int count = this.#=zawloLR4AQAF_32q7rQ==.Count;
		Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> dictionary = new Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>>();
		for (int i = 0; i < count; i++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = this.#=zawloLR4AQAF_32q7rQ==[i];
			if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zehX0B69q4EZn() > 0 && (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)1 || #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3))
			{
				Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary2;
				if (dictionary.ContainsKey(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zehX0B69q4EZn()))
				{
					dictionary2 = dictionary[#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zehX0B69q4EZn()];
				}
				else
				{
					dictionary2 = new Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>();
					dictionary.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zq2bPTdY=().#=zehX0B69q4EZn(), dictionary2);
				}
				List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list;
				if (dictionary2.ContainsKey(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zZOFUOewkm7ea()))
				{
					list = dictionary2[#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zZOFUOewkm7ea()];
				}
				else
				{
					list = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
					dictionary2.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zZOFUOewkm7ea(), list);
				}
				bool flag = false;
				for (int j = 0; j < list.Count; j++)
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list[j];
					if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r() < #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() || (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r() == #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() && !#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=ztP$zSGbniHTJ() && #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=ztP$zSGbniHTJ()))
					{
						list.Insert(j, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
				}
			}
		}
		return dictionary;
	}

	// Token: 0x06000E7E RID: 3710 RVA: 0x00073A0C File Offset: 0x00071C0C
	private List<int> #=zplwvbB2f8W07(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		List<int> list = new List<int>();
		StringBuilder stringBuilder = new StringBuilder();
		foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions functions in #=zrJCtPlbREqtz.Keys)
		{
			Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary = #=zrJCtPlbREqtz[functions];
			List<#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> list2 = new List<#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>();
			for (int i = 1; i <= #=zC7NDbDM=.#=zyowZ9U1Cgv5d(); i++)
			{
				#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM = new #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(new #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if((#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)1, i));
				#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2 = new #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(new #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if((#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)2, i));
				for (int j = #=zC7NDbDM=.#=zyowZ9U1Cgv5d(); j >= i; j--)
				{
					if (dictionary.ContainsKey(j))
					{
						List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list3 = dictionary[j];
						for (int k = 0; k < list3.Count; k++)
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zsbwXxuA= = list3[k];
							if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.AnywayBreakItem, #=zsbwXxuA=, #=zC7NDbDM=))
							{
								#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM.#=z48rEd0A=(#=zsbwXxuA=);
								#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2.#=z48rEd0A=(#=zsbwXxuA=);
							}
						}
					}
				}
				list2.Add(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM);
				list2.Add(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2);
			}
			int #=zXHTER4Q= = #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zdW1iUhMLgxS2(functions).Length;
			foreach (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= in #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>.#=z65EelYE=(list2, #=zXHTER4Q=))
			{
				list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id);
				if (stringBuilder.Length > 0)
				{
					stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
				}
				stringBuilder.Append(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.ToString());
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973359), new object[]
		{
			stringBuilder
		});
		return list;
	}

	// Token: 0x06000E7F RID: 3711 RVA: 0x00073BF8 File Offset: 0x00071DF8
	private List<int> #=zUlmf8FP6XCvc(List<int> #=zb$rZg6Y7pIQywRIhCvriClM=, Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zbu0tMEwpFQv3, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		List<int> list = new List<int>();
		StringBuilder stringBuilder = new StringBuilder();
		foreach (int key in #=zbu0tMEwpFQv3.Keys)
		{
			Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary = #=zbu0tMEwpFQv3[key];
			foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions functions in dictionary.Keys)
			{
				List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list2 = dictionary[functions];
				#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM = new #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(new #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if((#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)1, 4));
				#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2 = new #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(new #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if((#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)2, 4));
				for (int i = 0; i < list2.Count; i++)
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zsbwXxuA= = list2[i];
					if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.AnywayBreakItem, #=zsbwXxuA=, #=zC7NDbDM=))
					{
						#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM.#=z48rEd0A=(#=zsbwXxuA=);
						#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2.#=z48rEd0A=(#=zsbwXxuA=);
					}
				}
				List<#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> list3 = new List<#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>();
				list3.Add(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM);
				list3.Add(#=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM2);
				int #=zXHTER4Q= = #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zdW1iUhMLgxS2(functions).Length;
				foreach (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= in #=z9iEWQzfeI5qaPWIrtc0PH2Nd6HURZHk4PlKk9GaWG7kyZNXsZA==<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>.#=z65EelYE=(list3, #=zXHTER4Q=))
				{
					if (!#=zb$rZg6Y7pIQywRIhCvriClM=.Contains(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id))
					{
						list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id);
						if (stringBuilder.Length > 0)
						{
							stringBuilder.Append(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070988));
						}
						stringBuilder.Append(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.ToString());
					}
				}
			}
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973563), new object[]
		{
			stringBuilder
		});
		return list;
	}

	// Token: 0x06000E80 RID: 3712 RVA: 0x00073E04 File Offset: 0x00072004
	private #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zQ1sOEE_VNKs7(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz, Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zbu0tMEwpFQv3, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=, out string #=zIapFsKF23kqB)
	{
		#=zIapFsKF23kqB = null;
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBreakWarlordItems)
		{
			return null;
		}
		int count = this.#=zawloLR4AQAF_32q7rQ==.Count;
		for (int i = 0; i < count; i++)
		{
			if (this.#=zawloLR4AQAF_32q7rQ==[i].#=zdln9Op$NubUKpgj1nPP6ujU=())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973518), Array.Empty<object>());
				return null;
			}
		}
		List<int> list = this.#=zplwvbB2f8W07(#=zrJCtPlbREqtz, #=zC7NDbDM=);
		List<int> list2;
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBreakWarlordDivineItems)
		{
			list2 = this.#=zUlmf8FP6XCvc(list, #=zbu0tMEwpFQv3, #=zC7NDbDM=);
		}
		else
		{
			list2 = new List<int>();
		}
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list3 = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
		for (int j = 0; j < count; j++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = this.#=zawloLR4AQAF_32q7rQ==[j];
			if (!list.Contains(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id) && !list2.Contains(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id) && #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3 && !#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=ztP$zSGbniHTJ() && !this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.DontBreakItem, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=, #=zC7NDbDM=) && (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==() < 5 || this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoBreakWarlordDivineItems))
			{
				list3.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
			}
		}
		#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= result = null;
		if (list3.Count > 0)
		{
			list3.Sort(new #=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if((#=zPMhE1c9BgGRC0JkhV6g3tdU0T9XGYcPZoI2$KB9BK$if.#=zArez$Gs=)0, 0));
			for (int k = 0; k < list3.Count; k++)
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list3[k];
				string text = this.#=zBsXSanI=.#=zvXKYDXUsyUlB8R7AwvmeEUE2bd3D(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.Id);
				if (text.Length > 1000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973470), new object[]
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r()
					});
					result = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2;
					#=zIapFsKF23kqB = text;
					break;
				}
				if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973120)))
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973109), new object[]
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r()
					});
				}
				else
				{
					if (!text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973261)))
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973232), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r(),
							JSONManager.Cut(text)
						});
						break;
					}
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908973232), new object[]
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==(),
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zmLisBvRBDI2r(),
						JSONManager.Cut(text)
					});
				}
			}
		}
		else
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974938), Array.Empty<object>());
		}
		return result;
	}

	// Token: 0x06000E81 RID: 3713 RVA: 0x00074180 File Offset: 0x00072380
	private void #=zStNV$ojBpnYB(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zTHZYHBBUTyvN(InventoryActionRule.Types.UpgradeItem))
		{
			return;
		}
		int count = this.#=zawloLR4AQAF_32q7rQ==.Count;
		for (int i = 0; i < count; i++)
		{
			if (this.#=zawloLR4AQAF_32q7rQ==[i].#=z5kpAZQpjT2b7())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974880), Array.Empty<object>());
				return;
			}
		}
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
		foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions functions in #=zrJCtPlbREqtz.Keys)
		{
			Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary = #=zrJCtPlbREqtz[functions];
			int num = #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zdW1iUhMLgxS2(functions).Length;
			List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list2 = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
			for (int j = #=zC7NDbDM=.#=zyowZ9U1Cgv5d(); j >= 1; j--)
			{
				if (dictionary.ContainsKey(j))
				{
					List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list3 = dictionary[j];
					int num2 = Math.Min(list3.Count, num);
					for (int k = 0; k < num2; k++)
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = list3[k];
						if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.UpgradeItem, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=, #=zC7NDbDM=))
						{
							if (list2.Count < num)
							{
								list2.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
							}
							else
							{
								int num3 = 0;
								for (int l = 0; l < list2.Count; l++)
								{
									if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zA8HgqWet8sw7() <= list2[l].#=zA8HgqWet8sw7())
									{
										num3++;
										if (num3 >= num)
										{
											break;
										}
									}
								}
								if (num3 < num)
								{
									list2.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
								}
							}
						}
					}
				}
			}
			for (int m = list2.Count - 1; m >= 0; m--)
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list2[m];
				if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=z30ZZ1Pg0cZ7u() < #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=().#=zFpfdS67Awhv4Ns$3NQ==())
				{
					list.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2);
				}
			}
		}
		if (list.Count <= 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974656), Array.Empty<object>());
			return;
		}
		list.Sort(new Comparison<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(#=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==.#=zyDNvciU=.#=zLkw0NRU=.#=zxDS1$Z3cLKB9m3hIxYhlM$4=));
		#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3 = list[0];
		string text = this.#=zBsXSanI=.#=zf1Ph8ErZxXPwLzTYiu0wtRQ=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.Id);
		if (text.Length > 1000)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975091), new object[]
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zq2bPTdY=(),
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zVaUA5_qegiur(),
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zaKAy47_E$9SRuF6oiw==(),
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=z30ZZ1Pg0cZ7u() + 1
			});
			return;
		}
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975003), new object[]
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zq2bPTdY=(),
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zVaUA5_qegiur(),
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zaKAy47_E$9SRuF6oiw==(),
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=z30ZZ1Pg0cZ7u() + 1,
			JSONManager.Cut(text)
		});
	}

	// Token: 0x06000E82 RID: 3714 RVA: 0x000744C8 File Offset: 0x000726C8
	private void #=zhLGkHxVzB648uViERg==(#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsDoOpenKeyedWarlordChests)
		{
			return;
		}
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list = this.#=ze1Gd_NVFuPrnOCdIWtBZBBk=;
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list2 = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zfo$NmJo=(this.#=zCY4az9$WUjLsEJ7fgg==, #=zC7NDbDM=);
		bool flag = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zTHZYHBBUTyvN(InventoryActionRule.Types.BuyKeyForChest);
		this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zTHZYHBBUTyvN(InventoryActionRule.Types.DiscardChest);
		for (int i = 0; i < list.Count; i++)
		{
			#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = list[i];
			if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = null;
				for (int j = 0; j < list2.Count; j++)
				{
					if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur() == list2[j].#=zVaUA5_qegiur() && #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==() == list2[j].#=zaKAy47_E$9SRuF6oiw==())
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list2[j];
						break;
					}
				}
				if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 != null && #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=z30ZZ1Pg0cZ7u() <= 0)
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = null;
				}
				if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 == null && flag && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.BuyKeyForChest, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=, #=zC7NDbDM=))
				{
					int num = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zdrJQ84H34axG(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(), #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==());
					string text = this.#=zBsXSanI=.#=zFUjrYLmBgtGt(num, 1, false);
					if (text.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974612), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==()
						});
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmoQIeq0=(num, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(), #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==(), 1);
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974797), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==(),
							JSONManager.Cut(text)
						});
						flag = false;
					}
				}
				if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 != null)
				{
					string text2 = this.#=zBsXSanI=.#=zt5Y3ZLShoZgj7hxathmKRvEfUC7i(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id);
					if (text2.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974449), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==()
						});
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3 = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2;
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=zG3bIaEVzYjly(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=3.#=z30ZZ1Pg0cZ7u() - 1);
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974370), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==(),
							JSONManager.Cut(text2)
						});
					}
				}
				else if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemRules.#=zQLl7KKs=(InventoryActionRule.Types.DiscardChest, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=, #=zC7NDbDM=))
				{
					string text3 = this.#=zBsXSanI=.#=zwVGSk0x9RWfpaK5p7n7$X4c=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id);
					if (text3.Length > 1000)
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974537), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==()
						});
					}
					else
					{
						this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974475), new object[]
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zVaUA5_qegiur(),
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zaKAy47_E$9SRuF6oiw==(),
							JSONManager.Cut(text3)
						});
					}
				}
			}
		}
	}

	// Token: 0x06000E83 RID: 3715 RVA: 0x00074850 File Offset: 0x00072A50
	private Dictionary<int, Dictionary<int, int>> #=z7stKqyCDqYt2(#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2 #=zkJHod8k=)
	{
		UnitTypeCollection unitTypeCollection = UnitTypeCollection.Get();
		Dictionary<int, Dictionary<int, int>> dictionary = new Dictionary<int, Dictionary<int, int>>();
		foreach (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= in #=zkJHod8k=)
		{
			Dictionary<int, int> dictionary2 = new Dictionary<int, int>();
			dictionary.Add(#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=.Id, dictionary2);
			UnitType unitType = (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=.#=ziJ$YU1JNP2G7091OKNlTPms=() > 0) ? unitTypeCollection.Find(#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=.#=ziJ$YU1JNP2G7091OKNlTPms=()) : null;
			#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions[] array = (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions[])Enum.GetValues(typeof(#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions));
			int num = 0;
			for (int i = 1; i <= array.Length; i++)
			{
				int num2;
				if (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=.#=zEJwR6o0uD87uOKs2BdWvRnY=().ContainsKey(i))
				{
					num2 = (int)((double)#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=.#=zEJwR6o0uD87uOKs2BdWvRnY=()[i] * Math.Max(unitType.Strength.Attack, unitType.Strength.Defense));
					num = num2;
				}
				else
				{
					num2 = num;
				}
				dictionary2[i] = num2;
			}
		}
		return dictionary;
	}

	// Token: 0x06000E84 RID: 3716 RVA: 0x00074950 File Offset: 0x00072B50
	private Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int> #=zosbG4gvpgHrVL3lXTw==(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz, Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zbu0tMEwpFQv3, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int> dictionary = new Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int>();
		int num = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordDivineItemsPriority;
		if (num == 0)
		{
			return dictionary;
		}
		#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2 #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE = #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2.#=zi1hFJwI=();
		Dictionary<int, Dictionary<int, int>> #=zow5SegM= = this.#=z7stKqyCDqYt2(#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE);
		#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= = null;
		foreach (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=2 in #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE)
		{
			if (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=2.Id == num)
			{
				#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= = #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=2;
				break;
			}
		}
		if (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= == null)
		{
			num = 0;
		}
		else if (#=zbu0tMEwpFQv3.ContainsKey(num))
		{
			foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions key in #=zbu0tMEwpFQv3[num].Keys)
			{
				dictionary[key] = num;
			}
		}
		foreach (#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I= #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3 in #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE)
		{
			if (#=zbu0tMEwpFQv3.ContainsKey(#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id) && #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id != num && #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.#=zEJwR6o0uD87uOKs2BdWvRnY=().Count > 0)
			{
				List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions> list = new List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions>();
				foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions functions in #=zbu0tMEwpFQv3[#=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id].Keys)
				{
					if (dictionary.ContainsKey(functions))
					{
						if (dictionary[functions] != num)
						{
							list.Add(functions);
						}
					}
					else
					{
						dictionary[functions] = #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id;
					}
				}
				if (list.Count > 0)
				{
					Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int> dictionary2 = new Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int>(dictionary);
					int num2 = this.#=z7oGWyCQdCCOL(dictionary2, #=zow5SegM=);
					int num3 = 0;
					for (int i = 0; i < list.Count; i++)
					{
						dictionary2[list[i]] = #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id;
						int num4 = this.#=z7oGWyCQdCCOL(dictionary2, #=zow5SegM=);
						if (num4 > num2)
						{
							num2 = num4;
							num3 = i + 1;
						}
					}
					if (num3 == list.Count)
					{
						dictionary = dictionary2;
					}
					else if (num3 > 0)
					{
						List<KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double>> list2 = new List<KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double>>();
						foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions key2 in list)
						{
							#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = #=zbu0tMEwpFQv3[dictionary[key2]][key2][0];
							double value = #=zbu0tMEwpFQv3[dictionary2[key2]][key2][0].#=zmLisBvRBDI2r() - #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r();
							list2.Add(new KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double>(key2, value));
						}
						list2.Sort(new Comparison<KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double>>(#=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==.#=zyDNvciU=.#=zLkw0NRU=.#=zRDVRM_Uhazv7885LngYvPdICPDlw));
						for (int j = 0; j < num3; j++)
						{
							dictionary[list2[j].Key] = #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=3.Id;
						}
					}
				}
			}
		}
		return dictionary;
	}

	// Token: 0x06000E85 RID: 3717 RVA: 0x00074CCC File Offset: 0x00072ECC
	private int #=z7oGWyCQdCCOL(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int> #=za6PtZjk=, Dictionary<int, Dictionary<int, int>> #=zow5SegM=)
	{
		int num = 0;
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		foreach (int num2 in #=za6PtZjk=.Values)
		{
			if (dictionary.ContainsKey(num2))
			{
				Dictionary<int, int> dictionary2 = dictionary;
				int key = num2;
				int num3 = dictionary2[key];
				dictionary2[key] = num3 + 1;
			}
			else
			{
				dictionary.Add(num2, 1);
			}
		}
		foreach (int key2 in dictionary.Keys)
		{
			num += #=zow5SegM=[key2][dictionary[key2]];
		}
		return num;
	}

	// Token: 0x06000E86 RID: 3718 RVA: 0x00074DA0 File Offset: 0x00072FA0
	private void #=z13x0diI1ygJE(Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zrJCtPlbREqtz, Dictionary<int, Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>>> #=zbu0tMEwpFQv3, #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zC7NDbDM=)
	{
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemsPriority <= 0)
		{
			return;
		}
		List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list = this.#=zawloLR4AQAF_32q7rQ==;
		#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2.#=zi1hFJwI=();
		int[] array = new int[11];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = -1;
		}
		for (int j = 0; j < list.Count; j++)
		{
			if (list[j].#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)1)
			{
				array[list[j].#=zdDINCgoQlCgN()] = list[j].Id;
			}
		}
		int num = (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemsPriority + 1) / 2;
		bool flag = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().WarlordItemsPriority % 2 == 1;
		Dictionary<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, int> dictionary = this.#=zosbG4gvpgHrVL3lXTw==(#=zrJCtPlbREqtz, #=zbu0tMEwpFQv3, #=zC7NDbDM=);
		foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions functions in #=zrJCtPlbREqtz.Keys)
		{
			if ((functions != #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack && functions != #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingDefense) || #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zXkKSxVcvanF8qkH_$A==(functions) == flag)
			{
				List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list2 = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
				if (dictionary.Count > 0)
				{
					List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions> list3;
					if (functions == #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack || functions == #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingDefense)
					{
						list3 = new List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions>
						{
							#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingAttack,
							#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions.RingDefense
						};
					}
					else
					{
						list3 = new List<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions>
						{
							functions
						};
					}
					foreach (#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions key in list3)
					{
						if (dictionary.ContainsKey(key))
						{
							int key2 = dictionary[key];
							if (#=zbu0tMEwpFQv3.ContainsKey(key2))
							{
								List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list4 = #=zbu0tMEwpFQv3[key2][key];
								if (list4.Count > 0)
								{
									list2.Add(list4[0]);
								}
							}
						}
					}
				}
				List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list5 = new List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>();
				int num2 = #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.#=zdW1iUhMLgxS2(functions).Length;
				if (list2.Count < num2)
				{
					num2 -= list2.Count;
					Dictionary<int, List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>> dictionary2 = #=zrJCtPlbREqtz[functions];
					int num3 = #=zC7NDbDM=.#=zyowZ9U1Cgv5d();
					while (num3 >= 1 && (num3 >= num || list5.Count < num2))
					{
						if (dictionary2.ContainsKey(num3))
						{
							List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> list6 = dictionary2[num3];
							int num4 = Math.Min(list6.Count, num2);
							for (int k = 0; k < num4; k++)
							{
								#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = list6[k];
								if (num3 >= num || list5.Count < num2)
								{
									if (list5.Count == 0)
									{
										list5.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
									}
									else if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() > list5[list5.Count - 1].#=zmLisBvRBDI2r())
									{
										for (int l = 0; l < list5.Count; l++)
										{
											if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.#=zmLisBvRBDI2r() > list5[l].#=zmLisBvRBDI2r())
											{
												list5.Insert(l, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
												break;
											}
										}
										if (list5.Count > num2)
										{
											list5.RemoveAt(list5.Count - 1);
										}
									}
									else if (list5.Count < num2)
									{
										list5.Add(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=);
									}
								}
							}
						}
						num3--;
					}
				}
				if (list2.Count > 0)
				{
					list5.InsertRange(0, list2);
				}
				if (list5.Count > 0)
				{
					for (int m = 0; m < list5.Count; m++)
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2 = list5[m];
						if (#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zi66ZCDXN_8bo() == (#=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a.#=zpym8P$oCmghwvUlJ3Q==)3)
						{
							int num5 = -1;
							int[] array2 = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=().#=zjUdjHK39LnOi();
							for (int n = 0; n < array2.Length; n++)
							{
								if (array[array2[n]] < 0)
								{
									num5 = array2[n];
									break;
								}
							}
							if (num5 < 0)
							{
								for (int num6 = 0; num6 < array2.Length; num6++)
								{
									bool flag2 = false;
									for (int num7 = 0; num7 < list5.Count; num7++)
									{
										if (array[array2[num6]] == list5[num7].Id)
										{
											flag2 = true;
											break;
										}
									}
									if (!flag2)
									{
										num5 = array2[num6];
										break;
									}
								}
							}
							if (num5 > 0)
							{
								string text;
								if (array[num5] < 0)
								{
									text = this.#=zBsXSanI=.#=zoM5fsPTicZqKM1FOfYPYRug8ZNKf(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.Id, num5);
								}
								else
								{
									text = this.#=zBsXSanI=.#=zAGw__qiYN$H8QTo_aAKo9xk=(array[num5], #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.Id);
								}
								if (text.Length > 1000)
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974144), new object[]
									{
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==()
									});
									array[num5] = #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.Id;
								}
								else
								{
									this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974081), new object[]
									{
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zq2bPTdY=(),
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zVaUA5_qegiur(),
										#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=2.#=zaKAy47_E$9SRuF6oiw==(),
										JSONManager.Cut(text)
									});
								}
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06000E87 RID: 3719 RVA: 0x000752CC File Offset: 0x000734CC
	private void #=zzAgV6gTNgLF7()
	{
		if (!this.#=z8StzeqE=.#=zv2Kyu17YrGOC().IsBuyWarlordItemSlots)
		{
			return;
		}
		if (this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuyWarlordItemSlotsRows * 6 > (this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==() + this.#=z4KB$bKo=.#=zOCBHgkyzUdifcaSWcA==()) * 2)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zbbu$0jU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908974268), new object[]
			{
				this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuyWarlordItemSlotsRows
			});
			return;
		}
		int num = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuyWarlordItemSlotsRows * 6;
		this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975972), new object[]
		{
			this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==(),
			this.#=z4KB$bKo=.#=zOCBHgkyzUdifcaSWcA==(),
			num,
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuyWarlordItemSlotsRows
		});
		if (this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==() >= num)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975872), Array.Empty<object>());
			return;
		}
		if (this.#=z4KB$bKo=.#=zOCBHgkyzUdifcaSWcA==() == 0)
		{
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976082), Array.Empty<object>());
			return;
		}
		int num2 = this.#=z8StzeqE=.#=zv2Kyu17YrGOC().BuyWarlordItemSlotsRows - this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==() / 6;
		for (int i = 0; i < num2; i++)
		{
			string text = this.#=zBsXSanI=.#=zJ4zfSLLM3eKI_fyYRcmtYsl1yUYZ();
			if (text.Length <= 10000)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976023), new object[]
				{
					JSONManager.Cut(text)
				});
				return;
			}
			this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908976055), Array.Empty<object>());
		}
	}

	// Token: 0x06000E88 RID: 3720 RVA: 0x000754DC File Offset: 0x000736DC
	private void #=zFBr8mHfDg2bD(List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zDD3FFppStvqM, List<int> #=zw1YH1npzZNWxxlSqikR7758=)
	{
		#=zDD3FFppStvqM.Sort(new Comparison<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=>(#=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==.#=zyDNvciU=.#=zLkw0NRU=.#=zcghDM8QY4TgQQ3X2V8PQtfI=));
		for (int i = this.#=z4KB$bKo=.#=zTRW$aE$gba$c$ScVqw==(); i <= this.#=z4KB$bKo=.#=zyq3US4V39TsN3oKSrA==(); i++)
		{
			if (#=zDD3FFppStvqM.Count == 0)
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975715), Array.Empty<object>());
				return;
			}
			if (#=zw1YH1npzZNWxxlSqikR7758=.Count >= this.#=z4KB$bKo=.#=zlgiJcK9NKBvv9ufWeQ==())
			{
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=z9tn1xKU=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975667), Array.Empty<object>());
				return;
			}
			if (!#=zw1YH1npzZNWxxlSqikR7758=.Contains(i))
			{
				#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= = #=zDD3FFppStvqM[0];
				string text = this.#=zBsXSanI=.#=zQCyQnxaR4rpCWqnksHJELNl5x9F5(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=.Id, i);
				if (text.Length <= 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975816), new object[]
					{
						#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=,
						JSONManager.Cut(text)
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908975616), new object[]
				{
					#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=
				});
				#=zDD3FFppStvqM.RemoveAt(0);
				#=zw1YH1npzZNWxxlSqikR7758=.Add(i);
			}
		}
	}

	// Token: 0x04000818 RID: 2072
	private List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zawloLR4AQAF_32q7rQ==;

	// Token: 0x04000819 RID: 2073
	private List<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=ze1Gd_NVFuPrnOCdIWtBZBBk=;

	// Token: 0x0400081A RID: 2074
	private #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= #=zCY4az9$WUjLsEJ7fgg==;

	// Token: 0x0400081B RID: 2075
	private #=zKxnyQTN5C0oanipxZ55nHCxUQFqVet6sI2QOpxF5d_6a #=z4KB$bKo=;

	// Token: 0x0400081C RID: 2076
	private #=z8K1J9u60hWic8E8aWAmP$qWRvhKHKYzZbwzci4E= #=zZKzdsPms7IDM;

	// Token: 0x020001DF RID: 479
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x06000E8B RID: 3723 RVA: 0x00075654 File Offset: 0x00073854
		internal int #=zxDS1$Z3cLKB9m3hIxYhlM$4=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zm8PpuDU=, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zcltuPyw=)
		{
			return #=zpE3AzJjXfgqbIatZBQpZqI23wVLdvjfDcA==.#=zpPS$foY=(new int[]
			{
				#=zm8PpuDU=.#=z30ZZ1Pg0cZ7u().CompareTo(#=zcltuPyw=.#=z30ZZ1Pg0cZ7u()),
				#=zcltuPyw=.#=zVaUA5_qegiur().CompareTo(#=zm8PpuDU=.#=zVaUA5_qegiur()),
				#=zcltuPyw=.#=zaKAy47_E$9SRuF6oiw==().CompareTo(#=zm8PpuDU=.#=zaKAy47_E$9SRuF6oiw==())
			});
		}

		// Token: 0x06000E8C RID: 3724 RVA: 0x000756B4 File Offset: 0x000738B4
		internal int #=zRDVRM_Uhazv7885LngYvPdICPDlw(KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double> #=zm8PpuDU=, KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double> #=zcltuPyw=)
		{
			return #=zcltuPyw=.Value.CompareTo(#=zm8PpuDU=.Value);
		}

		// Token: 0x06000E8D RID: 3725 RVA: 0x000756D8 File Offset: 0x000738D8
		internal int #=zcghDM8QY4TgQQ3X2V8PQtfI=(#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zm8PpuDU=, #=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw= #=zcltuPyw=)
		{
			return #=zm8PpuDU=.Id.CompareTo(#=zcltuPyw=.Id);
		}

		// Token: 0x0400081D RID: 2077
		public static readonly #=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==.#=zyDNvciU= #=zLkw0NRU= = new #=zYQYF2gHI3C0TT_J54pwvsMSGRantnP4WOnNuSBrLI0rJwTORJw==.#=zyDNvciU=();

		// Token: 0x0400081E RID: 2078
		public static Comparison<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=zbaoW3zbmp2urVzSQ6A==;

		// Token: 0x0400081F RID: 2079
		public static Comparison<KeyValuePair<#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=.Functions, double>> #=zWNKd_oHTgb2zyXAGeA==;

		// Token: 0x04000820 RID: 2080
		public static Comparison<#=zvxDqzxkm_bVRDOklm$xIY8O0qSxkMGySc7rh0vw=> #=z0PVLN2ffnigTth5$Iw==;
	}
}
