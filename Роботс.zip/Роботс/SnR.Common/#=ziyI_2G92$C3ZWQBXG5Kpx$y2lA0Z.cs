﻿using System;
using NExcel;
using NExcel.Biff;
using NExcel.Biff.Formula;
using NExcel.Read.Biff;
using NExcelUtils;

// Token: 0x02000265 RID: 613
internal sealed class #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z : CellValue, NumberCell, Cell, FormulaData, NumberFormulaCell, FormulaCell
{
	// Token: 0x06001293 RID: 4755 RVA: 0x000916EC File Offset: 0x0008F8EC
	public #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z(Record #=zJce$Sys=, FormattingRecords #=zrRXQAB8=, ExternalSheet #=z8MJaPcg=, WorkbookMethods #=z94tQSvc=, SheetImpl #=z99eVqbg=) : base(#=zJce$Sys=, #=zrRXQAB8=, #=z99eVqbg=)
	{
		this.#=z$qdebj6dfyrP = #=z8MJaPcg=;
		this.#=zLJGAifU= = #=z94tQSvc=;
		this.#=zJ5GWysk= = this.getRecord().Data;
		this.#=zL0TJcHA= = #=zrRXQAB8=.getNumberFormat(this.XFIndex);
		if (this.#=zL0TJcHA= == null)
		{
			this.#=zL0TJcHA= = #=ziyI_2G92$C3ZWQBXG5Kpx$y2lA0Z.#=zk9NtXlk=;
		}
		int @int = IntegerHelper.getInt(this.#=zJ5GWysk=[6], this.#=zJ5GWysk=[7], this.#=zJ5GWysk=[8], this.#=zJ5GWysk=[9]);
		int int2 = IntegerHelper.getInt(this.#=zJ5GWysk=[10], this.#=zJ5GWysk=[11], this.#=zJ5GWysk=[12], this.#=zJ5GWysk=[13]);
		string text = Convert.ToString(@int, 2);
		while (text.Length < 32)
		{
			text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909074596) + text;
		}
		bool flag = ((long)int2 & (long)((ulong)int.MinValue)) != 0L;
		long value = Convert.ToInt64(Convert.ToString(int2 & int.MaxValue, 2) + text, 2);
		this.#=zaiKvawI= = BitConverter.Int64BitsToDouble(value);
		if (flag)
		{
			this.#=zaiKvawI= = -this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700005B RID: 91
	// (get) Token: 0x06001295 RID: 4757 RVA: 0x00091818 File Offset: 0x0008FA18
	public double DoubleValue
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700005C RID: 92
	// (get) Token: 0x06001296 RID: 4758 RVA: 0x00091820 File Offset: 0x0008FA20
	public new object Value
	{
		get
		{
			return this.#=zaiKvawI=;
		}
	}

	// Token: 0x1700005D RID: 93
	// (get) Token: 0x06001297 RID: 4759 RVA: 0x00091830 File Offset: 0x0008FA30
	public new string Contents
	{
		get
		{
			return string.Format(this.#=zL0TJcHA=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068264), this.#=zaiKvawI=);
		}
	}

	// Token: 0x1700005E RID: 94
	// (get) Token: 0x06001298 RID: 4760 RVA: 0x00091854 File Offset: 0x0008FA54
	public new CellType Type
	{
		get
		{
			return CellType.NUMBER_FORMULA;
		}
	}

	// Token: 0x1700005F RID: 95
	// (get) Token: 0x06001299 RID: 4761 RVA: 0x0009185C File Offset: 0x0008FA5C
	public string Formula
	{
		get
		{
			if (this.#=z06z1muCn8UNxP0yekw== == null)
			{
				sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 22];
				Array.Copy(this.#=zJ5GWysk=, 22, array, 0, array.Length);
				FormulaParser formulaParser = new FormulaParser(array, this, this.#=z$qdebj6dfyrP, this.#=zLJGAifU=, this.Sheet.#=znmG_kF0igveL8fwbqw==().Settings);
				formulaParser.parse();
				this.#=z06z1muCn8UNxP0yekw== = formulaParser.Formula;
			}
			return this.#=z06z1muCn8UNxP0yekw==;
		}
	}

	// Token: 0x17000060 RID: 96
	// (get) Token: 0x0600129A RID: 4762 RVA: 0x000918D0 File Offset: 0x0008FAD0
	public NumberFormatInfo NumberFormat
	{
		get
		{
			return this.#=zL0TJcHA=;
		}
	}

	// Token: 0x0600129B RID: 4763 RVA: 0x000918D8 File Offset: 0x0008FAD8
	public sbyte[] getFormulaData()
	{
		sbyte[] array = new sbyte[this.#=zJ5GWysk=.Length - 6];
		Array.Copy(this.#=zJ5GWysk=, 6, array, 0, this.#=zJ5GWysk=.Length - 6);
		return array;
	}

	// Token: 0x04000AB3 RID: 2739
	private double #=zaiKvawI=;

	// Token: 0x04000AB4 RID: 2740
	private NumberFormatInfo #=zL0TJcHA=;

	// Token: 0x04000AB5 RID: 2741
	private static readonly NumberFormatInfo #=zk9NtXlk= = new NumberFormatInfo(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077254));

	// Token: 0x04000AB6 RID: 2742
	private string #=z06z1muCn8UNxP0yekw==;

	// Token: 0x04000AB7 RID: 2743
	private ExternalSheet #=z$qdebj6dfyrP;

	// Token: 0x04000AB8 RID: 2744
	private WorkbookMethods #=zLJGAifU=;

	// Token: 0x04000AB9 RID: 2745
	private sbyte[] #=zJ5GWysk=;
}
