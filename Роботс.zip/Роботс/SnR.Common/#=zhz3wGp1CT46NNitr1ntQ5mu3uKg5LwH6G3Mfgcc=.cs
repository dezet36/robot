﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// Token: 0x02000256 RID: 598
internal sealed class #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc= : Dictionary<int, #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk=>
{
	// Token: 0x0600121B RID: 4635 RVA: 0x0008B624 File Offset: 0x00089824
	public #=zhz3wGp1CT46NNitr1ntQ5mu3uKg5LwH6G3Mfgcc=()
	{
		this.#=z8MmIBq3WuwD1k4Tygg==(false);
	}

	// Token: 0x0600121C RID: 4636 RVA: 0x0008B634 File Offset: 0x00089834
	public bool #=ztdA9BMY81Cs3tvO$LA==()
	{
		return this.#=zgHOYv3vzW0X8K1Y1HC64ClU=;
	}

	// Token: 0x0600121D RID: 4637 RVA: 0x0008B63C File Offset: 0x0008983C
	public void #=z8MmIBq3WuwD1k4Tygg==(bool #=z$Ib9gYQ=)
	{
		this.#=zgHOYv3vzW0X8K1Y1HC64ClU= = #=z$Ib9gYQ=;
	}

	// Token: 0x17000058 RID: 88
	[IndexerName("#=zx6APBRk=")]
	public #=z8fY4LM2jY1ivx8vOGLRQRQUlTQUGduEQ3mdlwZk= this[int #=zH2f5zJg=]
	{
		get
		{
			if (base.ContainsKey(#=zH2f5zJg=))
			{
				return base[#=zH2f5zJg=];
			}
			return null;
		}
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x0008B65C File Offset: 0x0008985C
	public int #=z2cw4dd0=(int #=zH2f5zJg=)
	{
		if (base.ContainsKey(#=zH2f5zJg=))
		{
			return base[#=zH2f5zJg=].#=zlIXJ9$NfUZc_();
		}
		return 0;
	}

	// Token: 0x04000A22 RID: 2594
	private bool #=zgHOYv3vzW0X8K1Y1HC64ClU=;
}
