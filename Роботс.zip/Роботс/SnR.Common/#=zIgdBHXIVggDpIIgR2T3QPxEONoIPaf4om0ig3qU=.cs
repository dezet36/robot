﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Skink.SnR.Common.Tasks;

// Token: 0x02000121 RID: 289
internal sealed partial class #=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU= : Form
{
	// Token: 0x06000716 RID: 1814 RVA: 0x0003AAEC File Offset: 0x00038CEC
	public #=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU=(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=z8S9_Kvw=, #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zJUGTDqUtMnBf)
	{
		this.#=zgpzgXirqPT5_();
		this.#=zshVEGQI= = #=z8S9_Kvw=;
		this.#=z8StzeqE= = #=zJUGTDqUtMnBf;
		this.#=zFeWgWXbidVjG8v4xww== = (#=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w=)this.#=z8StzeqE=.#=zGQl3yUpez1XJ().#=zEh7CJ2RYceMs(TaskTypes.AutoRobbery);
		if (this.#=zFeWgWXbidVjG8v4xww== != null)
		{
			this.#=zDMUQkPc= = this.#=zFeWgWXbidVjG8v4xww==.#=z5_3JqsL118hV();
		}
		else
		{
			#=z0fnp28WHdHHIomvTDkV56EngzJg6 #=zSJY$s3o= = new #=z0fnp28WHdHHIomvTDkV56EngzJg6(new #=zd7gddKq0NyBeznX8q8B6jeAiSw7t_WXfDQ==(null, true, this.#=z8StzeqE=));
			this.#=zDMUQkPc= = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGV9CLmCENINvspF3MQ==(this.#=z8StzeqE=, #=zSJY$s3o=);
		}
		this.#=zcBSiDOgQqUjT();
		#=zjsNdMKWp6YGRdL2sa2vcIiIO1mqgPrmH2A==.#=zqmx6FcA8x_j0(this);
	}

	// Token: 0x06000718 RID: 1816 RVA: 0x0003AB84 File Offset: 0x00038D84
	private void #=z4guiCTpG$48S9DfSJQ==(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zz3ywcefYEZcr.Columns[#=z4Q$h3mE=.ColumnIndex].Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089100))
		{
			int #=zQrqFdos= = Convert.ToInt32(this.#=zz3ywcefYEZcr.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU=.#=zCKvsCStAOVeE].Value);
			int #=zKFlJyLE= = Convert.ToInt32(this.#=zz3ywcefYEZcr.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU=.#=zCKvsCStAOVeE + 1].Value);
			this.#=zorxJD84=(#=zQrqFdos=, #=zKFlJyLE=);
			this.#=zcBSiDOgQqUjT();
		}
	}

	// Token: 0x06000719 RID: 1817 RVA: 0x0003AC30 File Offset: 0x00038E30
	private void #=zqQLFIHECI_qu()
	{
		if (this.#=zFeWgWXbidVjG8v4xww== != null)
		{
			this.#=zDMUQkPc=.#=zsobh2arZ__ufEqVOvA==(true);
			return;
		}
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zGncKSH4oJhxW9OLT6A==(this.#=zDMUQkPc=, this.#=z8StzeqE=);
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x0003AC58 File Offset: 0x00038E58
	private #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zorxJD84=(int #=zQrqFdos=, int #=zKFlJyLE=)
	{
		#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zkSQmO1E= = null;
		for (int i = 0; i < this.#=zDMUQkPc=.Count; i++)
		{
			if (this.#=zDMUQkPc=[i].#=zfTB62qendhk_VEy8rw==() == #=zQrqFdos= && this.#=zDMUQkPc=[i].#=zY0soxphmGIACbOHy6A==() == #=zKFlJyLE=)
			{
				#=zkSQmO1E= = this.#=zDMUQkPc=[i];
				break;
			}
		}
		this.#=zorxJD84=(#=zkSQmO1E=);
		this.#=zqQLFIHECI_qu();
		return this.#=zDMUQkPc=;
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x0003ACC8 File Offset: 0x00038EC8
	private void #=zorxJD84=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zkSQmO1E=)
	{
		if (#=zkSQmO1E= != null)
		{
			if (#=zkSQmO1E=.#=zu_rEcX_K9l9O())
			{
				for (int i = 0; i < this.#=zDMUQkPc=.Count; i++)
				{
					if (this.#=zDMUQkPc=[i].#=zMuFMjGQ=() == #=zkSQmO1E=.#=zMuFMjGQ=())
					{
						this.#=zDMUQkPc=.RemoveAt(i);
						return;
					}
				}
				return;
			}
			#=zkSQmO1E=.#=zu2gIox_y5kvk(!#=zkSQmO1E=.#=zsVa4US_DOpbi());
		}
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x0003AD2C File Offset: 0x00038F2C
	private void #=zcBSiDOgQqUjT()
	{
		try
		{
			this.#=zz3ywcefYEZcr.Rows.Clear();
			for (int i = 0; i < this.#=zDMUQkPc=.Count; i++)
			{
				this.#=zz3ywcefYEZcr.Rows.Add(this.#=zZlQBHLQ=(this.#=zDMUQkPc=[i]));
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=zJ9Vo3zcVLhD40yB98i7VXieKxW2K.#=z4mZAjSM=(#=zN_s5Z5A=));
		}
	}

	// Token: 0x0600071D RID: 1821 RVA: 0x0003ADA4 File Offset: 0x00038FA4
	private object[] #=zZlQBHLQ=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=z40sk5mc=)
	{
		int num = (this.#=z8StzeqE=.#=zjV_wsuvJ0R_B() != null) ? ((int)Math.Round(#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zOnM0lrc=((double)this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zfTB62qendhk_VEy8rw==(), (double)this.#=z8StzeqE=.#=zjV_wsuvJ0R_B().#=zY0soxphmGIACbOHy6A==(), (double)#=z40sk5mc=.#=zfTB62qendhk_VEy8rw==(), (double)#=z40sk5mc=.#=zY0soxphmGIACbOHy6A==()))) : 0;
		string text = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=z40sk5mc=.#=zsVa4US_DOpbi() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051727) : (#=z40sk5mc=.#=zSL$CHR_zajMs() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089069) : (#=z40sk5mc=.#=zu_rEcX_K9l9O() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089075) : string.Empty)));
		string text2 = #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=z40sk5mc=.#=zsVa4US_DOpbi() ? #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089043) : #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051668));
		return new object[]
		{
			false,
			#=z40sk5mc=.#=zkfqcY3I=(),
			#=z40sk5mc=.#=zj661vGqZTMsoJ4JrPg==(),
			#=z40sk5mc=.#=zfTB62qendhk_VEy8rw==(),
			#=z40sk5mc=.#=zY0soxphmGIACbOHy6A==(),
			num,
			#=z40sk5mc=.#=zmj4J_vTRu57u(),
			text,
			text2
		};
	}

	// Token: 0x0600071E RID: 1822 RVA: 0x0003AEC8 File Offset: 0x000390C8
	private void #=zqT_5Jl0y9J3a(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		new #=zstCrSbc6VhhAGh4PcKf7MoNnA0sJEvwuAk6RYXmHpegA(this.#=zshVEGQI=, this.#=z8StzeqE=).Show();
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x0003AEE0 File Offset: 0x000390E0
	private void #=z1M_Urc69srSW$YhWGQ==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		List<int> list = this.#=zAquQ$GaLn4CE();
		for (int i = this.#=zDMUQkPc=.Count - 1; i >= 0; i--)
		{
			#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= #=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk= = this.#=zDMUQkPc=[i];
			if (list.Contains(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=.#=zMuFMjGQ=()))
			{
				this.#=zorxJD84=(#=zXvV3JyMXsGmHH1EmlhgJls8l01NrbN3zAVdyZRk=);
			}
		}
		this.#=zqQLFIHECI_qu();
		this.#=zcBSiDOgQqUjT();
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x0003AF3C File Offset: 0x0003913C
	private List<int> #=zAquQ$GaLn4CE()
	{
		List<int> list = new List<int>();
		int index = this.#=zz3ywcefYEZcr.Columns[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089030)].Index;
		for (int i = 0; i < this.#=zz3ywcefYEZcr.RowCount; i++)
		{
			if (Convert.ToBoolean(this.#=zz3ywcefYEZcr.Rows[i].Cells[index].Value))
			{
				int num = Convert.ToInt32(this.#=zz3ywcefYEZcr.Rows[i].Cells[#=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU=.#=zCKvsCStAOVeE].Value);
				int num2 = Convert.ToInt32(this.#=zz3ywcefYEZcr.Rows[i].Cells[#=zIgdBHXIVggDpIIgR2T3QPxEONoIPaf4om0ig3qU=.#=zCKvsCStAOVeE + 1].Value);
				for (int j = 0; j < this.#=zDMUQkPc=.Count; j++)
				{
					if (this.#=zDMUQkPc=[j].#=zfTB62qendhk_VEy8rw==() == num && this.#=zDMUQkPc=[j].#=zY0soxphmGIACbOHy6A==() == num2)
					{
						list.Add(this.#=zDMUQkPc=[j].#=zMuFMjGQ=());
						break;
					}
				}
			}
		}
		return list;
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x0003B06C File Offset: 0x0003926C
	private void #=zGU2ezEr4VilYgWIWyX2CF4s=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== = new #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==(this.#=zshVEGQI=, this.#=z8StzeqE=);
		try
		{
			if (#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.ShowDialog() == DialogResult.OK && #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==().Count > 0)
			{
				List<int> collection = this.#=zAquQ$GaLn4CE();
				foreach (int index in #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==())
				{
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[index];
					#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE= = new #=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=();
					#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=.#=zoCWPowk7whj_().AddRange(collection);
					#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(#=z$DfPxgGV4hD9Sh2mAVSdoc6R2hFzra_SBQsIDrE=);
					#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
				}
				#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089268));
			}
		}
		finally
		{
			((IDisposable)#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==).Dispose();
		}
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x0003B140 File Offset: 0x00039340
	private void #=z_uB7T1QhcM2M6Zwakw==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		int index = this.#=zz3ywcefYEZcr.Columns[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089030)].Index;
		object value = true;
		if (Convert.ToBoolean(this.#=zz3ywcefYEZcr.Rows[0].Cells[index].Value))
		{
			value = false;
		}
		for (int i = 0; i < this.#=zz3ywcefYEZcr.Rows.Count; i++)
		{
			this.#=zz3ywcefYEZcr.Rows[i].Cells[index].Value = value;
		}
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x0003B1E0 File Offset: 0x000393E0
	private void #=zmxYiGebWEwwz70K2oQ==(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (this.#=zz3ywcefYEZcr.Columns[#=z4Q$h3mE=.ColumnIndex].Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089030))
		{
			object value = this.#=zz3ywcefYEZcr.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=z4Q$h3mE=.ColumnIndex].Value;
			for (int i = 0; i < this.#=zz3ywcefYEZcr.Rows.Count; i++)
			{
				DataGridViewCell dataGridViewCell = this.#=zz3ywcefYEZcr.Rows[i].Cells[#=z4Q$h3mE=.ColumnIndex];
				if (dataGridViewCell.Selected)
				{
					dataGridViewCell.Value = value;
				}
			}
		}
	}

	// Token: 0x06000724 RID: 1828 RVA: 0x0003B294 File Offset: 0x00039494
	private void #=zoXGJXK2q9zn1nyAZwg==(object #=zP95I7AY=, DataGridViewCellMouseEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex >= 0 && #=z4Q$h3mE=.ColumnIndex < this.#=zz3ywcefYEZcr.Columns.Count && #=z4Q$h3mE=.RowIndex >= 0 && this.#=zz3ywcefYEZcr.Columns[#=z4Q$h3mE=.ColumnIndex].Name == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089030))
		{
			this.#=zz3ywcefYEZcr.EndEdit();
		}
	}

	// Token: 0x06000725 RID: 1829 RVA: 0x0003B304 File Offset: 0x00039504
	private void #=ziGbqexAQQZMS9O_EQg==(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z_H9QVXY=(true);
	}

	// Token: 0x06000726 RID: 1830 RVA: 0x0003B310 File Offset: 0x00039510
	private void #=zLEpw9X0H7SAJuDO24ygPxfI=(object #=zP95I7AY=, EventArgs #=z4Q$h3mE=)
	{
		this.#=z_H9QVXY=(false);
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x0003B31C File Offset: 0x0003951C
	private void #=z_H9QVXY=(bool #=z6HbTWYF1cpty)
	{
		if (#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909095231), MessageBoxButtons.OKCancel, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089191), Array.Empty<object>()) == DialogResult.OK)
		{
			#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA== = new #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==(this.#=zshVEGQI=, this.#=z8StzeqE=);
			try
			{
				if (#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.ShowDialog() == DialogResult.OK && #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==().Count > 0)
				{
					foreach (int index in #=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==.#=zq7_P5s5zGTyvq8S1AQ==())
					{
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== = this.#=zshVEGQI=.#=zol80P7TKoihZ()[index];
						Task #=zcTyyNys= = new #=zqZPxJSs3sURdsC99ko6nt5TBhsY_pDpkQg==((#=z6HbTWYF1cpty > false) ? 1 : 0, TaskSources.ManualNotSavable, TaskSeverities.Background, TaskTypes.AutoRobberyTargetsReset, DateTime.Now, TimeSpan.Zero, TimeSpan.Zero, TimeSpan.Zero, DateTime.MaxValue, false);
						#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==.#=zeR3QFrc=(#=zcTyyNys=);
						#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zRbePuvFOUozd(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g==);
					}
					#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zdVW_C6o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088798));
				}
			}
			finally
			{
				((IDisposable)#=zmvyzxPNYlQlQSEXjMqwinHubd4c3EzJfLA==).Dispose();
			}
		}
	}

	// Token: 0x06000729 RID: 1833 RVA: 0x0003B44C File Offset: 0x0003964C
	private void #=zgpzgXirqPT5_()
	{
		this.#=zByiHPAwyKD$Q = new SplitContainer();
		this.#=zz3ywcefYEZcr = new DataGridView();
		this.#=z3wxSjZQ= = new DataGridViewCheckBoxColumn();
		this.#=zNSJ3LeRswQSB = new DataGridViewTextBoxColumn();
		this.#=z$8DBnRJvkTbl5sZUKw== = new DataGridViewTextBoxColumn();
		this.#=zifmiSkXn668S = new DataGridViewTextBoxColumn();
		this.#=zKYX4u4Gf$yRq = new DataGridViewTextBoxColumn();
		this.#=z03hL3EY= = new DataGridViewTextBoxColumn();
		this.#=zom4VhGBFtHwC = new DataGridViewTextBoxColumn();
		this.#=zyBG4yj8MmzND = new DataGridViewTextBoxColumn();
		this.#=zE7oVqcc= = new DataGridViewButtonColumn();
		this.#=zdRrDVcy$1MtO = new Button();
		this.#=zyV7V4kdv5Xc$ = new Button();
		this.#=zXiNS6xHqfHuvKt87UQ== = new Button();
		this.#=zAJunRlG6czaK = new Button();
		this.#=zOorC8YMLEeH$ = new Button();
		this.#=zFPt1oNKskZFUHAjrMQ== = new Button();
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).BeginInit();
		this.#=zByiHPAwyKD$Q.Panel1.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Panel2.SuspendLayout();
		this.#=zByiHPAwyKD$Q.SuspendLayout();
		((ISupportInitialize)this.#=zz3ywcefYEZcr).BeginInit();
		base.SuspendLayout();
		this.#=zByiHPAwyKD$Q.Dock = DockStyle.Fill;
		this.#=zByiHPAwyKD$Q.FixedPanel = FixedPanel.Panel2;
		this.#=zByiHPAwyKD$Q.Location = new Point(0, 0);
		this.#=zByiHPAwyKD$Q.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111121);
		this.#=zByiHPAwyKD$Q.Orientation = Orientation.Horizontal;
		this.#=zByiHPAwyKD$Q.Panel1.Controls.Add(this.#=zz3ywcefYEZcr);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zFPt1oNKskZFUHAjrMQ==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zdRrDVcy$1MtO);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zyV7V4kdv5Xc$);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zXiNS6xHqfHuvKt87UQ==);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zAJunRlG6czaK);
		this.#=zByiHPAwyKD$Q.Panel2.Controls.Add(this.#=zOorC8YMLEeH$);
		this.#=zByiHPAwyKD$Q.Size = new Size(980, 561);
		this.#=zByiHPAwyKD$Q.SplitterDistance = 495;
		this.#=zByiHPAwyKD$Q.TabIndex = 0;
		this.#=zz3ywcefYEZcr.AllowUserToAddRows = false;
		this.#=zz3ywcefYEZcr.AllowUserToDeleteRows = false;
		this.#=zz3ywcefYEZcr.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.#=zz3ywcefYEZcr.Columns.AddRange(new DataGridViewColumn[]
		{
			this.#=z3wxSjZQ=,
			this.#=zNSJ3LeRswQSB,
			this.#=z$8DBnRJvkTbl5sZUKw==,
			this.#=zifmiSkXn668S,
			this.#=zKYX4u4Gf$yRq,
			this.#=z03hL3EY=,
			this.#=zom4VhGBFtHwC,
			this.#=zyBG4yj8MmzND,
			this.#=zE7oVqcc=
		});
		this.#=zz3ywcefYEZcr.Dock = DockStyle.Fill;
		this.#=zz3ywcefYEZcr.Location = new Point(0, 0);
		this.#=zz3ywcefYEZcr.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104521);
		this.#=zz3ywcefYEZcr.Size = new Size(980, 495);
		this.#=zz3ywcefYEZcr.TabIndex = 0;
		this.#=zz3ywcefYEZcr.CellContentClick += this.#=z4guiCTpG$48S9DfSJQ==;
		this.#=zz3ywcefYEZcr.CellMouseUp += this.#=zoXGJXK2q9zn1nyAZwg==;
		this.#=zz3ywcefYEZcr.CellValueChanged += this.#=zmxYiGebWEwwz70K2oQ==;
		this.#=z3wxSjZQ=.HeaderText = string.Empty;
		this.#=z3wxSjZQ=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089030);
		this.#=z3wxSjZQ=.Resizable = DataGridViewTriState.True;
		this.#=z3wxSjZQ=.SortMode = DataGridViewColumnSortMode.Automatic;
		this.#=z3wxSjZQ=.Width = 30;
		this.#=zNSJ3LeRswQSB.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909111246);
		this.#=zNSJ3LeRswQSB.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088955);
		this.#=zNSJ3LeRswQSB.ReadOnly = true;
		this.#=z$8DBnRJvkTbl5sZUKw==.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104272);
		this.#=z$8DBnRJvkTbl5sZUKw==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088949);
		this.#=z$8DBnRJvkTbl5sZUKw==.ReadOnly = true;
		this.#=zifmiSkXn668S.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104363);
		this.#=zifmiSkXn668S.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088923);
		this.#=zifmiSkXn668S.ReadOnly = true;
		this.#=zKYX4u4Gf$yRq.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909104340);
		this.#=zKYX4u4Gf$yRq.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088916);
		this.#=zKYX4u4Gf$yRq.ReadOnly = true;
		this.#=z03hL3EY=.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909088897);
		this.#=z03hL3EY=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090678);
		this.#=z03hL3EY=.ReadOnly = true;
		this.#=zom4VhGBFtHwC.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090657);
		this.#=zom4VhGBFtHwC.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090640);
		this.#=zom4VhGBFtHwC.ReadOnly = true;
		this.#=zyBG4yj8MmzND.HeaderText = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090630);
		this.#=zyBG4yj8MmzND.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090611);
		this.#=zyBG4yj8MmzND.ReadOnly = true;
		this.#=zE7oVqcc=.HeaderText = string.Empty;
		this.#=zE7oVqcc=.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909089100);
		this.#=zE7oVqcc=.Resizable = DataGridViewTriState.True;
		this.#=zE7oVqcc=.SortMode = DataGridViewColumnSortMode.Automatic;
		this.#=zdRrDVcy$1MtO.Location = new Point(487, 31);
		this.#=zdRrDVcy$1MtO.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090607);
		this.#=zdRrDVcy$1MtO.Size = new Size(185, 23);
		this.#=zdRrDVcy$1MtO.TabIndex = 4;
		this.#=zdRrDVcy$1MtO.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090577);
		this.#=zdRrDVcy$1MtO.UseVisualStyleBackColor = true;
		this.#=zdRrDVcy$1MtO.Click += this.#=ziGbqexAQQZMS9O_EQg==;
		this.#=zyV7V4kdv5Xc$.Location = new Point(362, 2);
		this.#=zyV7V4kdv5Xc$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090564);
		this.#=zyV7V4kdv5Xc$.Size = new Size(119, 23);
		this.#=zyV7V4kdv5Xc$.TabIndex = 3;
		this.#=zyV7V4kdv5Xc$.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909114224);
		this.#=zyV7V4kdv5Xc$.UseVisualStyleBackColor = true;
		this.#=zyV7V4kdv5Xc$.Click += this.#=z_uB7T1QhcM2M6Zwakw==;
		this.#=zXiNS6xHqfHuvKt87UQ==.Location = new Point(678, 3);
		this.#=zXiNS6xHqfHuvKt87UQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090785);
		this.#=zXiNS6xHqfHuvKt87UQ==.Size = new Size(290, 23);
		this.#=zXiNS6xHqfHuvKt87UQ==.TabIndex = 2;
		this.#=zXiNS6xHqfHuvKt87UQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090755);
		this.#=zXiNS6xHqfHuvKt87UQ==.UseVisualStyleBackColor = true;
		this.#=zXiNS6xHqfHuvKt87UQ==.Click += this.#=zGU2ezEr4VilYgWIWyX2CF4s=;
		this.#=zAJunRlG6czaK.Location = new Point(487, 2);
		this.#=zAJunRlG6czaK.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090712);
		this.#=zAJunRlG6czaK.Size = new Size(185, 23);
		this.#=zAJunRlG6czaK.TabIndex = 1;
		this.#=zAJunRlG6czaK.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090694);
		this.#=zAJunRlG6czaK.UseVisualStyleBackColor = true;
		this.#=zAJunRlG6czaK.Click += this.#=z1M_Urc69srSW$YhWGQ==;
		this.#=zOorC8YMLEeH$.Location = new Point(12, 3);
		this.#=zOorC8YMLEeH$.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090406);
		this.#=zOorC8YMLEeH$.Size = new Size(124, 23);
		this.#=zOorC8YMLEeH$.TabIndex = 0;
		this.#=zOorC8YMLEeH$.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090377);
		this.#=zOorC8YMLEeH$.UseVisualStyleBackColor = true;
		this.#=zOorC8YMLEeH$.Click += this.#=zqT_5Jl0y9J3a;
		this.#=zFPt1oNKskZFUHAjrMQ==.Location = new Point(678, 32);
		this.#=zFPt1oNKskZFUHAjrMQ==.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090365);
		this.#=zFPt1oNKskZFUHAjrMQ==.Size = new Size(290, 23);
		this.#=zFPt1oNKskZFUHAjrMQ==.TabIndex = 5;
		this.#=zFPt1oNKskZFUHAjrMQ==.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090323);
		this.#=zFPt1oNKskZFUHAjrMQ==.UseVisualStyleBackColor = true;
		this.#=zFPt1oNKskZFUHAjrMQ==.Click += this.#=zLEpw9X0H7SAJuDO24ygPxfI=;
		base.AutoScaleDimensions = new SizeF(6f, 13f);
		base.AutoScaleMode = AutoScaleMode.Font;
		base.ClientSize = new Size(980, 561);
		base.Controls.Add(this.#=zByiHPAwyKD$Q);
		base.Name = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090536);
		this.Text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909090513);
		this.#=zByiHPAwyKD$Q.Panel1.ResumeLayout(false);
		this.#=zByiHPAwyKD$Q.Panel2.ResumeLayout(false);
		((ISupportInitialize)this.#=zByiHPAwyKD$Q).EndInit();
		this.#=zByiHPAwyKD$Q.ResumeLayout(false);
		((ISupportInitialize)this.#=zz3ywcefYEZcr).EndInit();
		base.ResumeLayout(false);
	}

	// Token: 0x04000435 RID: 1077
	private static int #=zCKvsCStAOVeE = 3;

	// Token: 0x04000436 RID: 1078
	private #=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zshVEGQI=;

	// Token: 0x04000437 RID: 1079
	private #=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=;

	// Token: 0x04000438 RID: 1080
	private #=zMOQr5ct1VigKXIo_ce42z43wEAs$6wd3AOlnV4w= #=zFeWgWXbidVjG8v4xww==;

	// Token: 0x04000439 RID: 1081
	private #=zWU8TDBR88x5Gq0zlM$su$TvzWTpJd78mdE5WUOwo0zWS2PEBHQ== #=zDMUQkPc=;

	// Token: 0x0400043B RID: 1083
	private SplitContainer #=zByiHPAwyKD$Q;

	// Token: 0x0400043C RID: 1084
	private DataGridView #=zz3ywcefYEZcr;

	// Token: 0x0400043D RID: 1085
	private Button #=zOorC8YMLEeH$;

	// Token: 0x0400043E RID: 1086
	private Button #=zXiNS6xHqfHuvKt87UQ==;

	// Token: 0x0400043F RID: 1087
	private Button #=zAJunRlG6czaK;

	// Token: 0x04000440 RID: 1088
	private Button #=zyV7V4kdv5Xc$;

	// Token: 0x04000441 RID: 1089
	private DataGridViewCheckBoxColumn #=z3wxSjZQ=;

	// Token: 0x04000442 RID: 1090
	private DataGridViewTextBoxColumn #=zNSJ3LeRswQSB;

	// Token: 0x04000443 RID: 1091
	private DataGridViewTextBoxColumn #=z$8DBnRJvkTbl5sZUKw==;

	// Token: 0x04000444 RID: 1092
	private DataGridViewTextBoxColumn #=zifmiSkXn668S;

	// Token: 0x04000445 RID: 1093
	private DataGridViewTextBoxColumn #=zKYX4u4Gf$yRq;

	// Token: 0x04000446 RID: 1094
	private DataGridViewTextBoxColumn #=z03hL3EY=;

	// Token: 0x04000447 RID: 1095
	private DataGridViewTextBoxColumn #=zom4VhGBFtHwC;

	// Token: 0x04000448 RID: 1096
	private DataGridViewTextBoxColumn #=zyBG4yj8MmzND;

	// Token: 0x04000449 RID: 1097
	private DataGridViewButtonColumn #=zE7oVqcc=;

	// Token: 0x0400044A RID: 1098
	private Button #=zdRrDVcy$1MtO;

	// Token: 0x0400044B RID: 1099
	private Button #=zFPt1oNKskZFUHAjrMQ==;
}
