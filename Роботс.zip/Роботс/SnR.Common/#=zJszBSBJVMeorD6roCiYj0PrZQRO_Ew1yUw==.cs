﻿using System;
using System.Collections.Generic;

// Token: 0x02000131 RID: 305
internal sealed class #=zJszBSBJVMeorD6roCiYj0PrZQRO_Ew1yUw==
{
	// Token: 0x060007B0 RID: 1968 RVA: 0x0003E3F0 File Offset: 0x0003C5F0
	public #=zJszBSBJVMeorD6roCiYj0PrZQRO_Ew1yUw==()
	{
		this.#=z6gtgVe82xxleW$aCVA==(new List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==>());
		this.#=zZblmvvfb4_sTsrnDEmOrNdE=(new List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==>());
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x0003E410 File Offset: 0x0003C610
	public List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=zb1dVS05Z9T9fehB4nw==()
	{
		return this.#=zJE_qp2SqAtx4KW8byCxKxRk=;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x0003E418 File Offset: 0x0003C618
	public void #=z6gtgVe82xxleW$aCVA==(List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=z$Ib9gYQ=)
	{
		this.#=zJE_qp2SqAtx4KW8byCxKxRk= = #=z$Ib9gYQ=;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x0003E424 File Offset: 0x0003C624
	public List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=zbPjqGaqJRDAevSEJtxEsxHA=()
	{
		return this.#=z9AuqahDtg2iVelwojl4FYPj7ZeiO;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x0003E42C File Offset: 0x0003C62C
	public void #=zZblmvvfb4_sTsrnDEmOrNdE=(List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=z$Ib9gYQ=)
	{
		this.#=z9AuqahDtg2iVelwojl4FYPj7ZeiO = #=z$Ib9gYQ=;
	}

	// Token: 0x060007B5 RID: 1973 RVA: 0x0003E438 File Offset: 0x0003C638
	public void #=zZLCBaFk=(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string text = #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z4FxeL2E=(#=z8StzeqE=);
		if (#=z8StzeqE=.#=z5CQ3MMGT7KZ6NzsrOA==() <= DateTime.Now)
		{
			#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = null;
			for (int i = 0; i < this.#=zb1dVS05Z9T9fehB4nw==().Count; i++)
			{
				if (this.#=zb1dVS05Z9T9fehB4nw==()[i].#=z5VV8Oo_dYzMg() == text)
				{
					#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = this.#=zb1dVS05Z9T9fehB4nw==()[i];
					break;
				}
			}
			if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== == null)
			{
				#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = new #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==(text, false);
				this.#=zb1dVS05Z9T9fehB4nw==().Add(#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==);
			}
			#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.#=z48rEd0A=(#=z8StzeqE=);
		}
	}

	// Token: 0x060007B6 RID: 1974 RVA: 0x0003E4BC File Offset: 0x0003C6BC
	public void #=z8mTF0fLVPqOZ(#=zaAxge$JqW6QB2G47sKvHpXJzPGHiK95f4g== #=z8StzeqE=)
	{
		string text = #=zkO3OALYBGNilukMF5u7j7K3EsP5C.#=z4FxeL2E=(#=z8StzeqE=);
		if (#=z8StzeqE=.#=zXhmu8wtI1QFueNwTW0lbj2Q=() <= DateTime.Now)
		{
			#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = null;
			for (int i = 0; i < this.#=zbPjqGaqJRDAevSEJtxEsxHA=().Count; i++)
			{
				if (this.#=zbPjqGaqJRDAevSEJtxEsxHA=()[i].#=z5VV8Oo_dYzMg() == text)
				{
					#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = this.#=zbPjqGaqJRDAevSEJtxEsxHA=()[i];
					break;
				}
			}
			if (#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== == null)
			{
				#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== = new #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==(text, true);
				this.#=zbPjqGaqJRDAevSEJtxEsxHA=().Add(#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==);
			}
			#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==.#=z48rEd0A=(#=z8StzeqE=);
		}
	}

	// Token: 0x060007B7 RID: 1975 RVA: 0x0003E540 File Offset: 0x0003C740
	public #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=zIxy9Fv4gtoZd(string #=z7sMfGqU=)
	{
		for (int i = 0; i < this.#=zb1dVS05Z9T9fehB4nw==().Count; i++)
		{
			if (this.#=zb1dVS05Z9T9fehB4nw==()[i].#=z5VV8Oo_dYzMg() == #=z7sMfGqU=)
			{
				return this.#=zb1dVS05Z9T9fehB4nw==()[i];
			}
		}
		return null;
	}

	// Token: 0x060007B8 RID: 1976 RVA: 0x0003E58C File Offset: 0x0003C78C
	public #=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw== #=z23_js2cNQaAmWuNtfw==(string #=z7sMfGqU=)
	{
		for (int i = 0; i < this.#=zbPjqGaqJRDAevSEJtxEsxHA=().Count; i++)
		{
			if (this.#=zbPjqGaqJRDAevSEJtxEsxHA=()[i].#=z5VV8Oo_dYzMg() == #=z7sMfGqU=)
			{
				return this.#=zbPjqGaqJRDAevSEJtxEsxHA=()[i];
			}
		}
		return null;
	}

	// Token: 0x04000488 RID: 1160
	private List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=zJE_qp2SqAtx4KW8byCxKxRk=;

	// Token: 0x04000489 RID: 1161
	private List<#=zsnlulVOEcR$gqEWKCGFNUPzTq9GNVQKyiw==> #=z9AuqahDtg2iVelwojl4FYPj7ZeiO;
}
