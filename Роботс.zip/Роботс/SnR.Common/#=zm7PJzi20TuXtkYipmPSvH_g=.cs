﻿using System;
using System.Collections;
using NExcel.Biff;
using NExcel.Biff.Drawing;

// Token: 0x02000283 RID: 643
internal sealed class #=zm7PJzi20TuXtkYipmPSvH_g= : #=zmTlNNx1Q756_tSfkVV6gsHcXWFp6
{
	// Token: 0x0600138A RID: 5002 RVA: 0x00096C6C File Offset: 0x00094E6C
	public #=zm7PJzi20TuXtkYipmPSvH_g=(EscherRecordData #=zF$dCX$w=) : base(#=zF$dCX$w=)
	{
		this.#=zhNa4uX1b5edYYzWAUw== = new ArrayList();
		sbyte[] array = this.#=ztbIWLuVjfGLU();
		this.#=zymMIlJcRPOrP = IntegerHelper.getInt(array[0], array[1], array[2], array[3]);
		this.#=zYOxbFc6Kp096cvwmSw== = IntegerHelper.getInt(array[4], array[5], array[6], array[7]);
		this.#=zjeDeCeTc3c1_FNOb$g== = IntegerHelper.getInt(array[8], array[9], array[10], array[11]);
		this.#=z$LQVf$yye9K9oHh77g== = IntegerHelper.getInt(array[12], array[13], array[14], array[15]);
		int num = 16;
		for (int i = 0; i < this.#=zYOxbFc6Kp096cvwmSw==; i++)
		{
			int @int = IntegerHelper.getInt(array[num], array[num + 1]);
			int int2 = IntegerHelper.getInt(array[num + 2], array[num + 3]);
			#=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs= value = new #=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs=(@int, int2);
			this.#=zhNa4uX1b5edYYzWAUw==.Add(value);
			num += 4;
		}
	}

	// Token: 0x0600138B RID: 5003 RVA: 0x00096D40 File Offset: 0x00094F40
	public #=zm7PJzi20TuXtkYipmPSvH_g=(int #=z8a6vp4WIeHcV, int #=zGb7A6IvAklNb2verzA==) : base(EscherRecordType.DGG)
	{
		this.#=zjeDeCeTc3c1_FNOb$g== = #=z8a6vp4WIeHcV;
		this.#=z$LQVf$yye9K9oHh77g== = #=zGb7A6IvAklNb2verzA==;
		this.#=zhNa4uX1b5edYYzWAUw== = new ArrayList();
	}

	// Token: 0x0600138C RID: 5004 RVA: 0x00096D68 File Offset: 0x00094F68
	internal int #=z_nyW0QQLKHCc()
	{
		return this.#=zjeDeCeTc3c1_FNOb$g==;
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x00096D70 File Offset: 0x00094F70
	internal void #=zTzZTdTg=(int #=zRCeBzjfrLfSC, int #=zr8_Qi5IuVNoN)
	{
		#=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs= value = new #=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs=(#=zRCeBzjfrLfSC, #=zr8_Qi5IuVNoN);
		this.#=zhNa4uX1b5edYYzWAUw==.Add(value);
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x0600138E RID: 5006 RVA: 0x00096D94 File Offset: 0x00094F94
	public override sbyte[] Data
	{
		get
		{
			this.#=zYOxbFc6Kp096cvwmSw== = this.#=zhNa4uX1b5edYYzWAUw==.Count;
			this.#=zJ5GWysk= = new sbyte[16 + this.#=zYOxbFc6Kp096cvwmSw== * 4];
			IntegerHelper.getFourBytes(1024 + this.#=zjeDeCeTc3c1_FNOb$g==, this.#=zJ5GWysk=, 0);
			IntegerHelper.getFourBytes(this.#=zYOxbFc6Kp096cvwmSw==, this.#=zJ5GWysk=, 4);
			IntegerHelper.getFourBytes(this.#=zjeDeCeTc3c1_FNOb$g==, this.#=zJ5GWysk=, 8);
			IntegerHelper.getFourBytes(1, this.#=zJ5GWysk=, 12);
			int num = 16;
			for (int i = 0; i < this.#=zYOxbFc6Kp096cvwmSw==; i++)
			{
				#=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs= #=zYC3P3Rs= = (#=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs=)this.#=zhNa4uX1b5edYYzWAUw==[i];
				IntegerHelper.getTwoBytes(#=zYC3P3Rs=.#=zq6ob7F9jJHvH, this.#=zJ5GWysk=, num);
				IntegerHelper.getTwoBytes(#=zYC3P3Rs=.#=z68uOLenoriWu, this.#=zJ5GWysk=, num + 2);
				num += 4;
			}
			return base.#=zkDlCfm_Lhg38(this.#=zJ5GWysk=);
		}
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x00096E6C File Offset: 0x0009506C
	internal #=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs= #=zo7Vpc9Q=(int #=zH2f5zJg=)
	{
		return (#=zm7PJzi20TuXtkYipmPSvH_g=.#=zYC3P3Rs=)this.#=zhNa4uX1b5edYYzWAUw==[#=zH2f5zJg=];
	}

	// Token: 0x04000B47 RID: 2887
	private sbyte[] #=zJ5GWysk=;

	// Token: 0x04000B48 RID: 2888
	private int #=zYOxbFc6Kp096cvwmSw==;

	// Token: 0x04000B49 RID: 2889
	private int #=zymMIlJcRPOrP;

	// Token: 0x04000B4A RID: 2890
	private int #=zjeDeCeTc3c1_FNOb$g==;

	// Token: 0x04000B4B RID: 2891
	private int #=z$LQVf$yye9K9oHh77g==;

	// Token: 0x04000B4C RID: 2892
	private ArrayList #=zhNa4uX1b5edYYzWAUw==;

	// Token: 0x02000284 RID: 644
	internal sealed class #=zYC3P3Rs=
	{
		// Token: 0x06001390 RID: 5008 RVA: 0x00096E80 File Offset: 0x00095080
		internal #=zYC3P3Rs=(int #=zz5L9yvw=, int #=zr8_Qi5IuVNoN)
		{
			this.#=zq6ob7F9jJHvH = #=zz5L9yvw=;
			this.#=z68uOLenoriWu = #=zr8_Qi5IuVNoN;
		}

		// Token: 0x04000B4D RID: 2893
		internal int #=zq6ob7F9jJHvH;

		// Token: 0x04000B4E RID: 2894
		internal int #=z68uOLenoriWu;
	}
}
