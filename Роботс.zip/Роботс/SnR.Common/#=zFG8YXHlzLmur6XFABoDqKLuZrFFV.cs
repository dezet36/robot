﻿using System;

// Token: 0x020000EF RID: 239
internal sealed class #=zFG8YXHlzLmur6XFABoDqKLuZrFFV : #=z5f6TTGxcn4$84XHZwuuLpuiShv55, #=zTjU5ztoD1isZ9QpSGdX_ICyrcsI_
{
	// Token: 0x06000640 RID: 1600 RVA: 0x00032598 File Offset: 0x00030798
	internal override #=zwUe4tm5XLL76xe$ToMjBTwE= #=znmVMpDg=()
	{
		return #=zwUe4tm5XLL76xe$ToMjBTwE=.#=zU1NYwIqXXdrZ;
	}

	// Token: 0x06000641 RID: 1601 RVA: 0x000325A0 File Offset: 0x000307A0
	internal override int #=zXiDCyaHY58$0()
	{
		return 5;
	}

	// Token: 0x06000642 RID: 1602 RVA: 0x000325A4 File Offset: 0x000307A4
	public override string #=ze3HB9kQ=()
	{
		return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080286);
	}
}
