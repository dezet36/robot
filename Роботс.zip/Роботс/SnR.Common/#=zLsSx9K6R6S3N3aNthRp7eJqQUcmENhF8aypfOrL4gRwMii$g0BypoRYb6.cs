﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x02000158 RID: 344
internal sealed class #=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM=
{
	// Token: 0x0600091E RID: 2334 RVA: 0x0004A628 File Offset: 0x00048828
	public #=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM=(string #=zAk8mKBk=)
	{
		this.#=zbsxKkj4=(#=zAk8mKBk=);
		this.#=zOZ8nuSJfgqCG(false);
		this.#=zlWZ9EMs_D$lcSpZd9w==(null);
		this.#=zR_ocueNGHnIr(1);
	}

	// Token: 0x0600091F RID: 2335 RVA: 0x0004A64C File Offset: 0x0004884C
	public #=zLsSx9K6R6S3N3aNthRp7eJqQUcmENhF8aypfOrL4gRwMii$g0BypoRYb6rGfVhYJT_eiMZM=(Dictionary<string, object> #=zJ5GWysk=)
	{
		this.#=zbsxKkj4=(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), string.Empty));
		this.#=zOZ8nuSJfgqCG(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), 0) == 1);
		this.#=zlWZ9EMs_D$lcSpZd9w==(JSONManager.ExtractString(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), string.Empty));
		this.#=zR_ocueNGHnIr(JSONManager.ExtractInt(#=zJ5GWysk=, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045), 0));
	}

	// Token: 0x06000920 RID: 2336 RVA: 0x0004A6C8 File Offset: 0x000488C8
	public string #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x06000921 RID: 2337 RVA: 0x0004A6D0 File Offset: 0x000488D0
	public void #=zbsxKkj4=(string #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000922 RID: 2338 RVA: 0x0004A6DC File Offset: 0x000488DC
	public bool #=zN$YQEP7uWF8f()
	{
		return this.#=z3UVpjzli1Qlru0Bl9g==;
	}

	// Token: 0x06000923 RID: 2339 RVA: 0x0004A6E4 File Offset: 0x000488E4
	public void #=zOZ8nuSJfgqCG(bool #=z$Ib9gYQ=)
	{
		this.#=z3UVpjzli1Qlru0Bl9g== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000924 RID: 2340 RVA: 0x0004A6F0 File Offset: 0x000488F0
	public string #=zaMFTrsik9X1nKi3x1g==()
	{
		return this.#=zLM_wIwS3mLlDMNswu2elqTM=;
	}

	// Token: 0x06000925 RID: 2341 RVA: 0x0004A6F8 File Offset: 0x000488F8
	public void #=zlWZ9EMs_D$lcSpZd9w==(string #=z$Ib9gYQ=)
	{
		this.#=zLM_wIwS3mLlDMNswu2elqTM= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000926 RID: 2342 RVA: 0x0004A704 File Offset: 0x00048904
	public int #=zz89PpumJ7HSr()
	{
		return this.#=zNgHG7lNZfbaBSbFhhA==;
	}

	// Token: 0x06000927 RID: 2343 RVA: 0x0004A70C File Offset: 0x0004890C
	public void #=zR_ocueNGHnIr(int #=z$Ib9gYQ=)
	{
		this.#=zNgHG7lNZfbaBSbFhhA== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000928 RID: 2344 RVA: 0x0004A718 File Offset: 0x00048918
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253),
				this.#=zMuFMjGQ=()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237),
				(this.#=zN$YQEP7uWF8f() > false) ? 1 : 0
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958),
				this.#=zaMFTrsik9X1nKi3x1g==()
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045),
				this.#=zz89PpumJ7HSr()
			}
		};
	}

	// Token: 0x0400053C RID: 1340
	private string #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x0400053D RID: 1341
	private bool #=z3UVpjzli1Qlru0Bl9g==;

	// Token: 0x0400053E RID: 1342
	private string #=zLM_wIwS3mLlDMNswu2elqTM=;

	// Token: 0x0400053F RID: 1343
	private int #=zNgHG7lNZfbaBSbFhhA==;
}
