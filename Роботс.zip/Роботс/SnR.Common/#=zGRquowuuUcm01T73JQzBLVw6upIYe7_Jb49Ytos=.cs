﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

// Token: 0x020000FD RID: 253
internal sealed class #=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos=
{
	// Token: 0x0600068B RID: 1675 RVA: 0x00033B0C File Offset: 0x00031D0C
	private #=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos=(DataGridView #=zTNBXCzs=, DataGridViewCellEventHandler #=zpBB5W0noG0OT)
	{
		this.#=zCKPevQOlZNKv = #=zTNBXCzs=;
		this.#=ztnV0N_pYorQcEf0BOtDDRKE= = new Dictionary<string, int>();
		this.#=z46Orh7qDQ71P = #=zpBB5W0noG0OT;
		this.#=zCKPevQOlZNKv.CellMouseUp += this.#=zf7bBx$9kiKYy;
		this.#=zCKPevQOlZNKv.CellValueChanged += this.#=zHkGdRYCkDxu0;
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x00033B68 File Offset: 0x00031D68
	public static #=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos= #=zcBW$PBE=(DataGridView #=zTNBXCzs=, DataGridViewCellEventHandler #=zpBB5W0noG0OT)
	{
		return new #=zGRquowuuUcm01T73JQzBLVw6upIYe7_Jb49Ytos=(#=zTNBXCzs=, #=zpBB5W0noG0OT);
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x00033B74 File Offset: 0x00031D74
	private void #=zf7bBx$9kiKYy(object #=zP95I7AY=, DataGridViewCellMouseEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex >= 0 && #=z4Q$h3mE=.ColumnIndex < this.#=zCKPevQOlZNKv.Columns.Count && #=z4Q$h3mE=.RowIndex >= 0 && this.#=zCKPevQOlZNKv.Columns[#=z4Q$h3mE=.ColumnIndex] is DataGridViewCheckBoxColumn)
		{
			this.#=zCKPevQOlZNKv.EndEdit();
		}
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x00033BD4 File Offset: 0x00031DD4
	private void #=zHkGdRYCkDxu0(object #=zP95I7AY=, DataGridViewCellEventArgs #=z4Q$h3mE=)
	{
		if (#=z4Q$h3mE=.ColumnIndex >= 0 && #=z4Q$h3mE=.ColumnIndex < this.#=zCKPevQOlZNKv.Columns.Count && #=z4Q$h3mE=.RowIndex >= 0 && #=z4Q$h3mE=.RowIndex < this.#=zCKPevQOlZNKv.Rows.Count)
		{
			DataGridViewColumn dataGridViewColumn = this.#=zCKPevQOlZNKv.Columns[#=z4Q$h3mE=.ColumnIndex];
			if (dataGridViewColumn is DataGridViewCheckBoxColumn)
			{
				if ((Control.ModifierKeys & Keys.Shift) != Keys.None && this.#=ztnV0N_pYorQcEf0BOtDDRKE=.ContainsKey(dataGridViewColumn.Name))
				{
					int num = this.#=ztnV0N_pYorQcEf0BOtDDRKE=[dataGridViewColumn.Name];
					if (num >= 0 && num < this.#=zCKPevQOlZNKv.Rows.Count)
					{
						bool flag = Convert.ToBoolean(this.#=zCKPevQOlZNKv.Rows[num].Cells[#=z4Q$h3mE=.ColumnIndex].Value);
						if (flag == Convert.ToBoolean(this.#=zCKPevQOlZNKv.Rows[#=z4Q$h3mE=.RowIndex].Cells[#=z4Q$h3mE=.ColumnIndex].Value))
						{
							int num2;
							if (num < #=z4Q$h3mE=.RowIndex)
							{
								num2 = #=z4Q$h3mE=.RowIndex;
							}
							else
							{
								num2 = num;
								num = #=z4Q$h3mE=.RowIndex;
							}
							if (num2 - num > 1)
							{
								for (int i = num + 1; i < num2; i++)
								{
									this.#=zCKPevQOlZNKv.Rows[i].Cells[#=z4Q$h3mE=.ColumnIndex].Value = flag;
									DataGridViewCellEventHandler dataGridViewCellEventHandler = this.#=z46Orh7qDQ71P;
									if (dataGridViewCellEventHandler != null)
									{
										dataGridViewCellEventHandler(this.#=zCKPevQOlZNKv, new DataGridViewCellEventArgs(#=z4Q$h3mE=.ColumnIndex, i));
									}
								}
							}
						}
					}
				}
				this.#=ztnV0N_pYorQcEf0BOtDDRKE=[dataGridViewColumn.Name] = #=z4Q$h3mE=.RowIndex;
			}
		}
	}

	// Token: 0x040002B9 RID: 697
	private DataGridView #=zCKPevQOlZNKv;

	// Token: 0x040002BA RID: 698
	private Dictionary<string, int> #=ztnV0N_pYorQcEf0BOtDDRKE=;

	// Token: 0x040002BB RID: 699
	private DataGridViewCellEventHandler #=z46Orh7qDQ71P;
}
