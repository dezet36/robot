﻿using System;
using Skink.SnR.Common.Managers;

// Token: 0x0200005D RID: 93
internal sealed class #=z44F_lbUYkIWRkTSXKNO4MN5DR73Q4EYgT75fO6w8YDVW : #=z9VT47ElS3WRJTBeIWnNjnhFI9N1eJm3jOw==
{
	// Token: 0x060002C0 RID: 704 RVA: 0x00016D58 File Offset: 0x00014F58
	protected override void #=z20ohAjI=(#=zP8oGWsB5Ry42JYXu8GYfc9OUCRR36sDfVA== #=zuJjQ1XU=)
	{
		this.#=zcr21mh8= = #=zuJjQ1XU=.#=zTqDBdc7DKJmY();
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00016D68 File Offset: 0x00014F68
	protected override void #=zvb5bnug=()
	{
		if (!(this.#=zcDRV51Ut$7oP is #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=))
		{
			return;
		}
		#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k= #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k= = this.#=zcDRV51Ut$7oP as #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=;
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2().Length < 4)
		{
			return;
		}
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[0] != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964025))
		{
			this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zpVBlD$IJ4abR(#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[0]);
			this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zh5Q$jgycqA15().#=z0yzdXaRNk7l4(this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zSByqmFV12x0z());
		}
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[1] != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964025))
		{
			this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zVOkdnwLzxOWf(#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[1]);
			this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zh5Q$jgycqA15().#=z0yzdXaRNk7l4(this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zSByqmFV12x0z());
		}
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[2] != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964025))
		{
			this.#=z8StzeqE=.#=zh5Q$jgycqA15().#=zhWr8WM11sNyG(#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[2]);
		}
		this.#=zBsXSanI=.#=zuq1FOz8SJbyH();
		if (#=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[3] != #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964025))
		{
			this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName = #=z7s4RbnD9S77ecX0MicNPg8x2K2W2WF4JBkN9G5k=.#=zs6AfR9w58BN2()[3];
			if (!string.IsNullOrWhiteSpace(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName) && this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName != this.#=zcr21mh8=)
			{
				string text = this.#=zBsXSanI=.#=zLbAeSYCTLemU(this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName);
				if (text.Length > 10000)
				{
					this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908964023), new object[]
					{
						this.#=zcr21mh8=,
						this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName
					});
					return;
				}
				this.#=z8StzeqE=.#=z3YtB02S6CjKY().#=zJWtlXjI=(this.#=zG2wnL_q7IxpD, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(908963972), new object[]
				{
					this.#=zcr21mh8=,
					this.#=z8StzeqE=.#=zv2Kyu17YrGOC().InitiationCityName,
					JSONManager.Cut(text)
				});
			}
		}
	}

	// Token: 0x040000DF RID: 223
	private string #=zcr21mh8=;
}
