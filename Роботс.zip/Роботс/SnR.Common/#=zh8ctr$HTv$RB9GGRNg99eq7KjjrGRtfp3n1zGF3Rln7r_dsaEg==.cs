﻿using System;
using System.Collections.Generic;

// Token: 0x02000251 RID: 593
internal sealed class #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==
{
	// Token: 0x060011F8 RID: 4600 RVA: 0x0008A5F8 File Offset: 0x000887F8
	public #=zh8ctr$HTv$RB9GGRNg99eq7KjjrGRtfp3n1zGF3Rln7r_dsaEg==(int #=zXHTER4Q=, object[] #=zeJY$3yxiRLlf)
	{
		this.#=z6LUCX1zMpXIf(#=zXHTER4Q=);
		this.#=zZ3H6S9pCFqAp5iZyPg==(new List<#=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=>());
		for (int i = 0; i < #=zeJY$3yxiRLlf.Length; i++)
		{
			this.#=z60bm6Tbh2NS2Gf1JMg==().Add(new #=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=((Dictionary<string, object>)#=zeJY$3yxiRLlf[i]));
		}
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x0008A644 File Offset: 0x00088844
	public int #=z2UCBrfce7z8r()
	{
		return this.#=z$67euFAUnKwkyTDxKw==;
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x0008A64C File Offset: 0x0008884C
	public void #=z6LUCX1zMpXIf(int #=z$Ib9gYQ=)
	{
		this.#=z$67euFAUnKwkyTDxKw== = #=z$Ib9gYQ=;
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x0008A658 File Offset: 0x00088858
	public List<#=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=> #=z60bm6Tbh2NS2Gf1JMg==()
	{
		return this.#=zTmJA4Y9msAWAzMeJ4DNIKOI=;
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x0008A660 File Offset: 0x00088860
	public void #=zZ3H6S9pCFqAp5iZyPg==(List<#=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=> #=z$Ib9gYQ=)
	{
		this.#=zTmJA4Y9msAWAzMeJ4DNIKOI= = #=z$Ib9gYQ=;
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x0008A66C File Offset: 0x0008886C
	public string #=zkfqcY3I=()
	{
		return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(this.#=zJUSSLS0miOWtJMzQ6I0Pwpk=());
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x0008A67C File Offset: 0x0008887C
	private string #=zJUSSLS0miOWtJMzQ6I0Pwpk=()
	{
		switch (this.#=z2UCBrfce7z8r())
		{
		case 1:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060213);
		case 2:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060189);
		case 3:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060161);
		case 4:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060137);
		case 5:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060112);
		case 6:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060102);
		case 7:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060322);
		default:
			return this.#=z2UCBrfce7z8r().ToString();
		}
	}

	// Token: 0x04000A0B RID: 2571
	private int #=z$67euFAUnKwkyTDxKw==;

	// Token: 0x04000A0C RID: 2572
	private List<#=zUA$Tp8ljyymNH6Syhre7Mn4eafHyurUj3TLSp9pJoAwCa6SU4vFmNEQ=> #=zTmJA4Y9msAWAzMeJ4DNIKOI=;
}
