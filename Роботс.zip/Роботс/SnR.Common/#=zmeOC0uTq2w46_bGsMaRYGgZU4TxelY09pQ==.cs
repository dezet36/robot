﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Microsoft.Win32;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using Skink.SnR.Common.Managers;

// Token: 0x0200028B RID: 651
internal class #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ== : IDisposable
{
	// Token: 0x060013BF RID: 5055 RVA: 0x00098044 File Offset: 0x00096244
	protected #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==()
	{
		this.#=zZ0HnSD5WuSKL = null;
	}

	// Token: 0x060013C0 RID: 5056 RVA: 0x00098054 File Offset: 0x00096254
	public static int #=z6b6ng0lr3mAC()
	{
		for (int i = 0; i < 3; i++)
		{
			try
			{
				TcpListener tcpListener = new TcpListener(IPAddress.Loopback, 0);
				tcpListener.Start();
				int port = ((IPEndPoint)tcpListener.LocalEndpoint).Port;
				tcpListener.Stop();
				return port;
			}
			catch
			{
				Thread.Sleep(1000);
			}
		}
		return 0;
	}

	// Token: 0x060013C1 RID: 5057 RVA: 0x000980BC File Offset: 0x000962BC
	protected IWebElement #=zM0kt7HA=(string #=zTTxwPk8=, string #=zRvgpNx8=)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		if (!string.IsNullOrEmpty(#=zRvgpNx8=))
		{
			string[] array = #=zRvgpNx8=.Split(new char[]
			{
				',',
				';'
			});
			for (int i = 0; i < array.Length; i++)
			{
				string[] array2 = array[i].Split(new char[]
				{
					':'
				});
				if (array2.Length == 2)
				{
					dictionary[array2[0]] = array2[1];
				}
			}
		}
		for (int j = 0; j < 5; j++)
		{
			ReadOnlyCollection<IWebElement> readOnlyCollection;
			if (this.#=zZ0HnSD5WuSKL == null)
			{
				readOnlyCollection = this.#=zHyfIJ4cGh5WhxFCgnw==.FindElementsByTagName(#=zTTxwPk8=);
			}
			else
			{
				readOnlyCollection = this.#=zZ0HnSD5WuSKL.FindElements(By.TagName(#=zTTxwPk8=));
			}
			foreach (IWebElement webElement in readOnlyCollection)
			{
				bool flag = true;
				foreach (string text in dictionary.Keys)
				{
					if (text == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055783))
					{
						if (!#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=zHyRU2Xu3mG$P(webElement.Text, dictionary[text]))
						{
							flag = false;
							break;
						}
					}
					else if (!#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=zHyRU2Xu3mG$P(webElement.GetAttribute(text), dictionary[text]))
					{
						flag = false;
						break;
					}
				}
				if (flag)
				{
					return webElement;
				}
			}
			Thread.Sleep(1000);
		}
		return null;
	}

	// Token: 0x060013C2 RID: 5058 RVA: 0x00098244 File Offset: 0x00096444
	private static bool #=zHyRU2Xu3mG$P(string #=zdPovgAA=, string #=zX0mt5B0ekoTu)
	{
		string[] array;
		bool flag;
		if (#=zX0mt5B0ekoTu.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055763)))
		{
			array = #=zX0mt5B0ekoTu.Split(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055763)
			}, StringSplitOptions.None);
			flag = false;
		}
		else
		{
			array = #=zX0mt5B0ekoTu.Split(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055752)
			}, StringSplitOptions.None);
			flag = true;
		}
		bool result = false;
		foreach (string #=ze7ZtytQ= in array)
		{
			if (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=zQm9A$kvSyPh2(#=zdPovgAA=, #=ze7ZtytQ=))
			{
				result = true;
				if (flag)
				{
					break;
				}
			}
			else
			{
				result = false;
				if (!flag)
				{
					break;
				}
			}
		}
		return result;
	}

	// Token: 0x060013C3 RID: 5059 RVA: 0x000982CC File Offset: 0x000964CC
	private static bool #=zQm9A$kvSyPh2(string #=zdPovgAA=, string #=ze7ZtytQ=)
	{
		if (#=ze7ZtytQ=.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055745)))
		{
			return !#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=zQm9A$kvSyPh2(#=zdPovgAA=, #=ze7ZtytQ=.Substring(1));
		}
		if (#=ze7ZtytQ=.StartsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263)))
		{
			if (#=ze7ZtytQ=.EndsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263)))
			{
				if (#=zdPovgAA=.Contains(#=ze7ZtytQ=.Trim(new char[]
				{
					'*'
				})))
				{
					return true;
				}
			}
			else if (#=zdPovgAA=.EndsWith(#=ze7ZtytQ=.Trim(new char[]
			{
				'*'
			})))
			{
				return true;
			}
		}
		else if (#=ze7ZtytQ=.EndsWith(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909080263)))
		{
			if (#=zdPovgAA=.StartsWith(#=ze7ZtytQ=.Trim(new char[]
			{
				'*'
			})))
			{
				return true;
			}
		}
		else if (#=zdPovgAA= == #=ze7ZtytQ=)
		{
			return true;
		}
		return false;
	}

	// Token: 0x060013C4 RID: 5060 RVA: 0x00098390 File Offset: 0x00096590
	protected bool #=zEdOMPyO4eTxD(string #=zTTxwPk8=, string #=zRvgpNx8=)
	{
		return this.#=zM0kt7HA=(#=zTTxwPk8=, #=zRvgpNx8=) != null;
	}

	// Token: 0x060013C5 RID: 5061 RVA: 0x000983A0 File Offset: 0x000965A0
	protected void #=z44RlC5dM$t$7(string #=zRvgpNx8=, string #=ze7ZtytQ=, int #=zu9f8oystJigQH7_Mdg==)
	{
		IWebElement webElement = this.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055993), #=zRvgpNx8=);
		if (webElement != null)
		{
			new Actions(this.#=zHyfIJ4cGh5WhxFCgnw==).MoveToElement(webElement).Click().SendKeys(#=ze7ZtytQ=).Perform();
			Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
		}
	}

	// Token: 0x060013C6 RID: 5062 RVA: 0x000983F0 File Offset: 0x000965F0
	protected void #=zG_jEWD8=(string #=zRvgpNx8=, int #=zu9f8oystJigQH7_Mdg==)
	{
		IWebElement webElement = this.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055989), #=zRvgpNx8=);
		if (webElement != null)
		{
			new Actions(this.#=zHyfIJ4cGh5WhxFCgnw==).MoveToElement(webElement).Click().Perform();
			Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
		}
	}

	// Token: 0x060013C7 RID: 5063 RVA: 0x0009843C File Offset: 0x0009663C
	protected void #=zoQjTitg=(string #=zRvgpNx8=, int #=zu9f8oystJigQH7_Mdg==)
	{
		IWebElement webElement = this.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070237), #=zRvgpNx8=);
		if (webElement != null)
		{
			new Actions(this.#=zHyfIJ4cGh5WhxFCgnw==).MoveToElement(webElement).Click().Perform();
			Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
		}
	}

	// Token: 0x060013C8 RID: 5064 RVA: 0x00098488 File Offset: 0x00096688
	protected void #=zfqBUobKkY4oj(string #=zRvgpNx8=, int #=zu9f8oystJigQH7_Mdg==)
	{
		IWebElement webElement = this.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055974), #=zRvgpNx8=);
		if (webElement != null)
		{
			new Actions(this.#=zHyfIJ4cGh5WhxFCgnw==).MoveToElement(webElement).Click().Perform();
			Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
		}
	}

	// Token: 0x060013C9 RID: 5065 RVA: 0x000984D4 File Offset: 0x000966D4
	protected void #=zNnK3AQdmKNju(string #=z6QPrZ_4=, string #=ze7ZtytQ=, int #=zu9f8oystJigQH7_Mdg==)
	{
		new Actions(this.#=zHyfIJ4cGh5WhxFCgnw==).MoveToElement(this.#=zHyfIJ4cGh5WhxFCgnw==.FindElementsByName(#=z6QPrZ_4=)[0]).Click().SendKeys(#=ze7ZtytQ=).Perform();
		Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
	}

	// Token: 0x060013CA RID: 5066 RVA: 0x00098514 File Offset: 0x00096714
	protected int #=zBiGvVOl0qHOo(string #=zAk8mKBk=)
	{
		return this.#=zHyfIJ4cGh5WhxFCgnw==.FindElementsById(#=zAk8mKBk=).Count;
	}

	// Token: 0x060013CB RID: 5067 RVA: 0x00098528 File Offset: 0x00096728
	protected void #=zo_LdvbgbKdtT(IWebElement #=zL6pG0RQ=)
	{
		this.#=zZ0HnSD5WuSKL = #=zL6pG0RQ=;
	}

	// Token: 0x060013CC RID: 5068 RVA: 0x00098534 File Offset: 0x00096734
	protected bool #=z5GlD5yOMF10k(string #=zRvgpNx8=)
	{
		IWebElement webElement = this.#=zM0kt7HA=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909052154), #=zRvgpNx8=);
		if (webElement != null)
		{
			this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().Frame(webElement);
			return true;
		}
		return false;
	}

	// Token: 0x060013CD RID: 5069 RVA: 0x0009856C File Offset: 0x0009676C
	protected void #=zO9hEXZnX7tvi()
	{
		this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().DefaultContent();
	}

	// Token: 0x060013CE RID: 5070 RVA: 0x00098580 File Offset: 0x00096780
	protected string #=z1l8Ok3M=()
	{
		return this.#=zHyfIJ4cGh5WhxFCgnw==.PageSource;
	}

	// Token: 0x060013CF RID: 5071 RVA: 0x00098590 File Offset: 0x00096790
	protected bool #=zTfuhy4tr_RnrTxO_9g==(string #=zM9Kl6phdnjS2oHGjkQ==)
	{
		if (!this.#=z5GlD5yOMF10k(#=zM9Kl6phdnjS2oHGjkQ==))
		{
			return false;
		}
		bool result = this.#=zEdOMPyO4eTxD(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055964), null);
		this.#=zO9hEXZnX7tvi();
		return result;
	}

	// Token: 0x060013D0 RID: 5072 RVA: 0x000985B4 File Offset: 0x000967B4
	public static string #=zHZdHTFFkQZf0gnBrmA==()
	{
		RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055945));
		RegistryKey registryKey2 = null;
		string result = null;
		foreach (string text in registryKey.GetSubKeyNames())
		{
			if (text.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055920)))
			{
				registryKey2 = registryKey.OpenSubKey(text);
				break;
			}
		}
		if (registryKey2 == null)
		{
			registryKey = Registry.LocalMachine.OpenSubKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055945));
			foreach (string text2 in registryKey.GetSubKeyNames())
			{
				if (text2.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055920)))
				{
					registryKey2 = registryKey.OpenSubKey(text2);
				}
			}
		}
		if (registryKey2 != null)
		{
			string text3 = Convert.ToString(Registry.GetValue(registryKey2.Name.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055907), null, null));
			if (text3 != null)
			{
				string[] array = text3.Split(new char[]
				{
					'"'
				});
				if (array.Length >= 2)
				{
					result = array[1];
				}
			}
		}
		return result;
	}

	// Token: 0x060013D1 RID: 5073 RVA: 0x000986B4 File Offset: 0x000968B4
	public static string #=z8eVNVeh1mC9H()
	{
		string text = null;
		try
		{
			object value = Registry.GetValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055881), string.Empty, null);
			if (value != null)
			{
				text = value.ToString();
			}
			else
			{
				value = Registry.GetValue(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055536), string.Empty, null);
				if (value != null)
				{
					text = value.ToString();
				}
			}
		}
		catch
		{
		}
		if (text == null)
		{
			text = #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055704);
		}
		return text;
	}

	// Token: 0x060013D2 RID: 5074 RVA: 0x0009872C File Offset: 0x0009692C
	protected #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 #=z4HyKJ7m74sB_1gVqzA==(List<string> #=zKEMFONsOrcJ1)
	{
		#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 result;
		try
		{
			ChromeOptions chromeOptions = new ChromeOptions();
			string text = #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=zHZdHTFFkQZf0gnBrmA==();
			if (!File.Exists(text))
			{
				result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)2;
			}
			else
			{
				chromeOptions.BinaryLocation = text;
				if (#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zL7ZDlcYJHrdWKPBrLfJWbCXAFa2U())
				{
					chromeOptions.AddArguments(new string[]
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055646)
					});
				}
				chromeOptions.AddArguments(new string[]
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055628)
				});
				if (!string.IsNullOrEmpty(#=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zNqNm8eiTRoJhiqVdyQ==()))
				{
					chromeOptions.AddArguments(new string[]
					{
						#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055327) + #=zTVwQXPrKELJ04Q$NicmC9dopvsxONB5COw==.#=zv2Kyu17YrGOC().#=zNqNm8eiTRoJhiqVdyQ==()
					});
				}
				foreach (string argument in #=zKEMFONsOrcJ1)
				{
					chromeOptions.AddArgument(argument);
				}
				ChromePerformanceLoggingPreferences chromePerformanceLoggingPreferences = new ChromePerformanceLoggingPreferences();
				chromePerformanceLoggingPreferences.AddTracingCategories(new string[]
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055297)
				});
				chromeOptions.PerformanceLoggingPreferences = chromePerformanceLoggingPreferences;
				chromeOptions.AddAdditionalCapability(CapabilityType.EnableProfiling, true, true);
				chromeOptions.SetLoggingPreference(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055262), LogLevel.All);
				ChromeDriverService chromeDriverService = ChromeDriverService.CreateDefaultService();
				chromeDriverService.HideCommandPromptWindow = true;
				int num = #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z6b6ng0lr3mAC();
				if (num > 0)
				{
					chromeDriverService.Port = num;
				}
				this.#=zHyfIJ4cGh5WhxFCgnw== = new ChromeDriver(chromeDriverService, chromeOptions, TimeSpan.FromSeconds(120.0));
				this.#=z1GIW5p8= = chromeDriverService.ProcessId;
				this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Window.Maximize();
				result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)0;
			}
		}
		catch (Exception #=zN_s5Z5A=)
		{
			if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=() != null)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
			result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)1;
		}
		return result;
	}

	// Token: 0x060013D3 RID: 5075 RVA: 0x000988FC File Offset: 0x00096AFC
	protected #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 #=zANY5PbxjL_ZJ(List<string> #=zKEMFONsOrcJ1)
	{
		#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80 result;
		try
		{
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.AddArguments(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055646)
			});
			chromeOptions.AddArguments(new string[]
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055628)
			});
			foreach (string argument in #=zKEMFONsOrcJ1)
			{
				chromeOptions.AddArgument(argument);
			}
			ChromeDriverService chromeDriverService = ChromeDriverService.CreateDefaultService();
			chromeDriverService.HideCommandPromptWindow = true;
			int num = #=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z6b6ng0lr3mAC();
			if (num > 0)
			{
				chromeDriverService.Port = num;
			}
			this.#=zHyfIJ4cGh5WhxFCgnw== = new ChromeDriver(chromeDriverService, chromeOptions, TimeSpan.FromSeconds(120.0));
			this.#=z1GIW5p8= = chromeDriverService.ProcessId;
			this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Window.Maximize();
			result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)0;
		}
		catch (Exception #=zN_s5Z5A=)
		{
			if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=() != null)
			{
				#=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zfXC52bZ3r7yM(#=zN_s5Z5A=);
			}
			result = (#=zmeOC0uTq2w46_bGsMaRYGgZU4TxelY09pQ==.#=z$_muzYvJ5U80)1;
		}
		return result;
	}

	// Token: 0x060013D4 RID: 5076 RVA: 0x00098A04 File Offset: 0x00096C04
	protected void #=zR5_i$$YlhjkS1_OAZw==()
	{
		if (this.#=zHyfIJ4cGh5WhxFCgnw== != null)
		{
			this.#=zHyfIJ4cGh5WhxFCgnw==.Quit();
		}
	}

	// Token: 0x060013D5 RID: 5077 RVA: 0x00098A1C File Offset: 0x00096C1C
	protected string #=z76wb7HEJGHqx()
	{
		return this.#=zHyfIJ4cGh5WhxFCgnw==.Url;
	}

	// Token: 0x060013D6 RID: 5078 RVA: 0x00098A2C File Offset: 0x00096C2C
	protected void #=zPC48eGFZAOd4(string #=zVI_2r0M=, int #=zu9f8oystJigQH7_Mdg==)
	{
		this.#=zHyfIJ4cGh5WhxFCgnw==.Navigate().GoToUrl(#=zVI_2r0M=);
		int num = 4;
		while (this.#=zHyfIJ4cGh5WhxFCgnw==.PageSource.Contains(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055244)) && num > 0)
		{
			num--;
			this.#=zHyfIJ4cGh5WhxFCgnw==.Navigate().GoToUrl(#=zVI_2r0M=);
		}
		Thread.Sleep(#=zu9f8oystJigQH7_Mdg== * 1000);
	}

	// Token: 0x060013D7 RID: 5079 RVA: 0x00098A90 File Offset: 0x00096C90
	protected void #=zDrsiyDM=(#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z88V33U9I4DoN, string #=z9aCHa9o=, bool #=zUMLc6EZ2ikNk)
	{
		if (#=zUMLc6EZ2ikNk)
		{
			this.#=zSCUvZ$3Q$yPk();
		}
		foreach (#=zFK1EpQeH6KJD0Ki59YPGY91j162R #=zFK1EpQeH6KJD0Ki59YPGY91j162R in #=z88V33U9I4DoN.#=ztjK2jmKh1KjY().Values)
		{
			Cookie cookie = new Cookie(#=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zrsHDyhs=.Trim(), #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zziO1gvU=.Trim(), #=z9aCHa9o=, #=zFK1EpQeH6KJD0Ki59YPGY91j162R.#=zvuWqnvI=, new DateTime?(DateTime.Now.AddMonths(1)));
			this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Cookies.AddCookie(cookie);
		}
	}

	// Token: 0x060013D8 RID: 5080 RVA: 0x00098B38 File Offset: 0x00096D38
	protected void #=zSCUvZ$3Q$yPk()
	{
		while (this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Cookies.AllCookies.Count != 0)
		{
			this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Cookies.DeleteAllCookies();
			Thread.Sleep(1000);
		}
	}

	// Token: 0x060013D9 RID: 5081 RVA: 0x00098B78 File Offset: 0x00096D78
	protected #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z6gOaJJZTJ8VJ()
	{
		ReadOnlyCollection<LogEntry> log = this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Logs.GetLog(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055262));
		#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== = new #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==();
		foreach (LogEntry logEntry in log)
		{
			object obj = JSONManager.DeserializeData(logEntry.Message);
			string @string = JSONManager.GetString(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055467), null);
			if (string.IsNullOrEmpty(@string))
			{
				@string = JSONManager.GetString(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055415), null);
			}
			if (!string.IsNullOrEmpty(@string))
			{
				string[] array = @string.Split(new char[]
				{
					';'
				});
				for (int i = 0; i < array.Length; i++)
				{
					string[] array2 = array[i].Split(new char[]
					{
						'='
					});
					if (array2.Length >= 2)
					{
						#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==.#=z48rEd0A=(new #=zFK1EpQeH6KJD0Ki59YPGY91j162R(array2[0], array2[1]));
					}
				}
			}
		}
		return #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==;
	}

	// Token: 0x060013DA RID: 5082 RVA: 0x00098C78 File Offset: 0x00096E78
	protected #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zHaPdjrG08$z8()
	{
		ReadOnlyCollection<Cookie> allCookies = this.#=zHyfIJ4cGh5WhxFCgnw==.Manage().Cookies.AllCookies;
		#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== = new #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==();
		for (int i = 0; i < allCookies.Count; i++)
		{
			Cookie cookie = allCookies[i];
			#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==.#=z48rEd0A=(new #=zFK1EpQeH6KJD0Ki59YPGY91j162R(cookie.Name, cookie.Value, cookie.Path));
		}
		return #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==;
	}

	// Token: 0x060013DB RID: 5083 RVA: 0x00098CD8 File Offset: 0x00096ED8
	protected #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== #=z$r5qqTT2P9vZIEL3tw==(string #=zVI_2r0M=)
	{
		string currentWindowHandle = this.#=zHyfIJ4cGh5WhxFCgnw==.CurrentWindowHandle;
		this.#=zHyfIJ4cGh5WhxFCgnw==.ExecuteScript(string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055099), #=zVI_2r0M=), Array.Empty<object>());
		foreach (string text in this.#=zHyfIJ4cGh5WhxFCgnw==.WindowHandles)
		{
			if (text != currentWindowHandle)
			{
				this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().Window(text);
				#=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA== result = this.#=zHaPdjrG08$z8();
				this.#=zHyfIJ4cGh5WhxFCgnw==.Close();
				this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().Window(currentWindowHandle);
				return result;
			}
		}
		return new #=zY62Xh8BzTVCEyRgu$F1O4rhd752phzAkiA==();
	}

	// Token: 0x060013DC RID: 5084 RVA: 0x00098D98 File Offset: 0x00096F98
	protected void #=zpKUcNpMnsvbRGM5azw==()
	{
		ReadOnlyCollection<string> windowHandles = this.#=zHyfIJ4cGh5WhxFCgnw==.WindowHandles;
		if (windowHandles.Count > 1)
		{
			for (int i = 1; i < windowHandles.Count; i++)
			{
				this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().Window(windowHandles[i]);
				this.#=zHyfIJ4cGh5WhxFCgnw==.Close();
			}
			this.#=zHyfIJ4cGh5WhxFCgnw==.SwitchTo().Window(windowHandles[0]);
		}
	}

	// Token: 0x060013DD RID: 5085 RVA: 0x00098E08 File Offset: 0x00097008
	protected void #=z_5oUdWT1m93J(string #=zFpFnSNzP2RTc)
	{
		this.#=zHyfIJ4cGh5WhxFCgnw==.ExecuteChromeCommand(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055070), new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055037),
				#=zFpFnSNzP2RTc
			}
		});
	}

	// Token: 0x060013DE RID: 5086 RVA: 0x00098E38 File Offset: 0x00097038
	protected void #=z_EpreNHtxGbU()
	{
		foreach (Process process in Process.GetProcessesByName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055021)))
		{
			if (process.Id == this.#=z1GIW5p8=)
			{
				try
				{
					process.Kill();
				}
				catch (Exception)
				{
				}
			}
		}
	}

	// Token: 0x060013DF RID: 5087 RVA: 0x00098E90 File Offset: 0x00097090
	public static void #=zEEE6h4ojDpseoX1kvA==()
	{
		string fileName = Process.GetCurrentProcess().MainModule.FileName;
		string directoryName = Path.GetDirectoryName(fileName);
		Process[] processesByName = Process.GetProcessesByName(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909055021));
		for (int i = 0; i < processesByName.Length; i++)
		{
			try
			{
				Process process = processesByName[i];
				string fileName2 = process.MainModule.FileName;
				if (Path.GetDirectoryName(fileName2) == directoryName && fileName2 != fileName)
				{
					process.Kill();
				}
			}
			catch
			{
			}
		}
	}

	// Token: 0x060013E0 RID: 5088 RVA: 0x00098F20 File Offset: 0x00097120
	public void Dispose()
	{
		this.#=z_EpreNHtxGbU();
	}

	// Token: 0x060013E1 RID: 5089 RVA: 0x00098F28 File Offset: 0x00097128
	protected object #=zx0uresqDtFaL(string #=zUjJKM0I=)
	{
		return this.#=zHyfIJ4cGh5WhxFCgnw==.ExecuteScript(#=zUjJKM0I=, Array.Empty<object>());
	}

	// Token: 0x060013E2 RID: 5090 RVA: 0x00098F3C File Offset: 0x0009713C
	protected string #=zKDvQbwT9_cSo(string #=zLdBU9Mk=, out bool #=zVo8zBiw=)
	{
		string result;
		try
		{
			object value = this.#=zHyfIJ4cGh5WhxFCgnw==.ExecuteScript(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909054992) + #=zLdBU9Mk=, Array.Empty<object>());
			#=zVo8zBiw= = false;
			result = Convert.ToString(value);
		}
		catch
		{
			#=zVo8zBiw= = true;
			result = null;
		}
		return result;
	}

	// Token: 0x04000B68 RID: 2920
	private ChromeDriver #=zHyfIJ4cGh5WhxFCgnw==;

	// Token: 0x04000B69 RID: 2921
	private int #=z1GIW5p8=;

	// Token: 0x04000B6A RID: 2922
	private IWebElement #=zZ0HnSD5WuSKL;

	// Token: 0x0200028C RID: 652
	public enum #=z$_muzYvJ5U80
	{

	}
}
