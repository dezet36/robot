﻿using System;
using System.Globalization;
using System.Reflection;
using System.Resources;

// Token: 0x020000D4 RID: 212
internal sealed class #=zCeDfVZWmmevLtIZzDQ==
{
	// Token: 0x060005B5 RID: 1461 RVA: 0x0002F900 File Offset: 0x0002DB00
	public #=zCeDfVZWmmevLtIZzDQ==(string #=z6QPrZ_4=, CultureInfo #=zHGG5pVE=, Assembly #=zkL26RAY=)
	{
		this.#=zmM7vggA= = new ResourceManager(#=z6QPrZ_4= + this.#=z_IUzf7c=(#=zHGG5pVE=), #=zkL26RAY=);
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x0002F924 File Offset: 0x0002DB24
	public string #=zajgoHT8=(string #=zNraCe1Y=)
	{
		return this.#=zmM7vggA=.GetString(#=zNraCe1Y=);
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x0002F934 File Offset: 0x0002DB34
	private string #=z_IUzf7c=(CultureInfo #=zHGG5pVE=)
	{
		string name = #=zHGG5pVE=.Name;
		if (name == null)
		{
			return string.Empty;
		}
		if (name.Length < 2)
		{
			return string.Empty;
		}
		string a = name.Substring(0, 2).ToLower();
		if (a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909067396))
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069181);
		}
		if (a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069163))
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069152);
		}
		if (a == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069150))
		{
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069143);
		}
		return string.Empty;
	}

	// Token: 0x0400025E RID: 606
	private ResourceManager #=zmM7vggA=;
}
