﻿using System;
using Skink.SnR.Common.City;

// Token: 0x02000226 RID: 550
internal sealed class #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio
{
	// Token: 0x060010D3 RID: 4307 RVA: 0x000816F4 File Offset: 0x0007F8F4
	public #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio()
	{
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x000816FC File Offset: 0x0007F8FC
	public #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio(ResourceTypes #=zvRLj9WQ=, int #=zNvCMwussKumm)
	{
		this.#=zzQwUIEs=(#=zvRLj9WQ=);
		this.#=zqoCq5j01dD5w(#=zNvCMwussKumm);
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x00081714 File Offset: 0x0007F914
	public ResourceTypes #=zq2bPTdY=()
	{
		return this.#=zmgOIL9ya65ae7QIXVQ==;
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x0008171C File Offset: 0x0007F91C
	public void #=zzQwUIEs=(ResourceTypes #=z$Ib9gYQ=)
	{
		this.#=zmgOIL9ya65ae7QIXVQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x00081728 File Offset: 0x0007F928
	public int #=zlIXJ9$NfUZc_()
	{
		return this.#=zxojFZYWVfXhu329mAA==;
	}

	// Token: 0x060010D8 RID: 4312 RVA: 0x00081730 File Offset: 0x0007F930
	public void #=zqoCq5j01dD5w(int #=z$Ib9gYQ=)
	{
		this.#=zxojFZYWVfXhu329mAA== = #=z$Ib9gYQ=;
	}

	// Token: 0x060010D9 RID: 4313 RVA: 0x0008173C File Offset: 0x0007F93C
	public string #=z69SHZCTwoPe0()
	{
		return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=z9OFonzM=(this.#=zq2bPTdY=());
	}

	// Token: 0x060010DA RID: 4314 RVA: 0x0008174C File Offset: 0x0007F94C
	public string #=zyhMluFK2CBji()
	{
		return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=ziW1QRqvFMUe2(this.#=zq2bPTdY=());
	}

	// Token: 0x060010DB RID: 4315 RVA: 0x0008175C File Offset: 0x0007F95C
	public static string #=z9OFonzM=(ResourceTypes #=zvRLj9WQ=)
	{
		switch (#=zvRLj9WQ=)
		{
		case ResourceTypes.Grain:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069891);
		case ResourceTypes.Bronze:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958);
		case ResourceTypes.Lumber:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070759);
		case ResourceTypes.Gold:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045);
		case ResourceTypes.Denaries:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909068581);
		case ResourceTypes.Glory:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069907);
		case ResourceTypes.Schemas:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253);
		case ResourceTypes.GeneralsCurrency:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069094);
		case ResourceTypes.FutureCurrency:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082);
		case ResourceTypes.IdolsOfVeor:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070777);
		case ResourceTypes.AllianceSilver:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062075);
		case ResourceTypes.AllianceGold:
			return #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062064);
		default:
			return string.Empty;
		}
	}

	// Token: 0x060010DC RID: 4316 RVA: 0x00081830 File Offset: 0x0007FA30
	public static ResourceTypes #=zsJJ$G_g=(string #=zKJA8IWQ=)
	{
		if (#=zKJA8IWQ= != null)
		{
			int length = #=zKJA8IWQ=.Length;
			if (length != 1)
			{
				if (length == 2)
				{
					char c = #=zKJA8IWQ=[1];
					if (c != 'g')
					{
						switch (c)
						{
						case 'p':
							if (#=zKJA8IWQ= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062082))
							{
								return ResourceTypes.FutureCurrency;
							}
							break;
						case 'r':
							if (#=zKJA8IWQ= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070777))
							{
								return ResourceTypes.IdolsOfVeor;
							}
							break;
						case 's':
							if (#=zKJA8IWQ= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062075))
							{
								return ResourceTypes.AllianceSilver;
							}
							break;
						}
					}
					else if (#=zKJA8IWQ= == #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062064))
					{
						return ResourceTypes.AllianceGold;
					}
				}
			}
			else
			{
				char c = #=zKJA8IWQ=[0];
				if (c <= 'i')
				{
					if (c <= 'c')
					{
						if (c == 'b')
						{
							return ResourceTypes.Glory;
						}
						if (c == 'c')
						{
							return ResourceTypes.Denaries;
						}
					}
					else
					{
						if (c == 'g')
						{
							return ResourceTypes.Gold;
						}
						if (c == 'i')
						{
							return ResourceTypes.Schemas;
						}
					}
				}
				else if (c <= 'p')
				{
					if (c == 'm')
					{
						return ResourceTypes.Grain;
					}
					if (c == 'p')
					{
						return ResourceTypes.GeneralsCurrency;
					}
				}
				else
				{
					if (c == 't')
					{
						return ResourceTypes.Bronze;
					}
					if (c == 'u')
					{
						return ResourceTypes.Lumber;
					}
				}
			}
		}
		return ResourceTypes.Unknown;
	}

	// Token: 0x060010DD RID: 4317 RVA: 0x00081958 File Offset: 0x0007FB58
	public static string #=ziW1QRqvFMUe2(ResourceTypes #=zvRLj9WQ=)
	{
		switch (#=zvRLj9WQ=)
		{
		case ResourceTypes.Grain:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062057));
		case ResourceTypes.Bronze:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062043));
		case ResourceTypes.Lumber:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062026));
		case ResourceTypes.Gold:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909062021));
		case ResourceTypes.Denaries:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061738));
		case ResourceTypes.Glory:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061722));
		case ResourceTypes.Schemas:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061711));
		case ResourceTypes.GeneralsCurrency:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061692));
		case ResourceTypes.FutureCurrency:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061677));
		case ResourceTypes.IdolsOfVeor:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061651));
		case ResourceTypes.AllianceSilver:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061634));
		case ResourceTypes.AllianceGold:
			return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909061867));
		default:
			return #=zvRLj9WQ=.ToString();
		}
	}

	// Token: 0x060010DE RID: 4318 RVA: 0x00081A70 File Offset: 0x0007FC70
	public static string #=ziW1QRqvFMUe2(string #=zKJA8IWQ=)
	{
		return #=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=ziW1QRqvFMUe2(#=ze1Y8kJy10W9$YbxLyHe_w$3XUWio.#=zsJJ$G_g=(#=zKJA8IWQ=));
	}

	// Token: 0x04000915 RID: 2325
	private ResourceTypes #=zmgOIL9ya65ae7QIXVQ==;

	// Token: 0x04000916 RID: 2326
	private int #=zxojFZYWVfXhu329mAA==;
}
