﻿using System;
using System.Collections.Generic;
using System.Net;
using Skink.SnR.Common.AppLocal;
using Skink.SnR.Common.Global;
using Skink.SnR.Common.Managers;
using Skink.SnR.Common.Units;

// Token: 0x02000133 RID: 307
internal sealed class #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==
{
	// Token: 0x060007C5 RID: 1989 RVA: 0x0003E668 File Offset: 0x0003C868
	private #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==()
	{
		this.#=z9HdGFQI= = new Dictionary<string, object>();
	}

	// Token: 0x060007C7 RID: 1991 RVA: 0x0003E690 File Offset: 0x0003C890
	private static #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g== #=zKVN4CRU=()
	{
		if (#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOAzeRO$HqsMN == null)
		{
			object obj = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zSV4$mlFB34WM;
			lock (obj)
			{
				if (#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOAzeRO$HqsMN == null)
				{
					#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOAzeRO$HqsMN = new #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==();
					#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOAzeRO$HqsMN.#=z1jlGMrg=();
				}
			}
		}
		return #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zOAzeRO$HqsMN;
	}

	// Token: 0x060007C8 RID: 1992 RVA: 0x0003E6F4 File Offset: 0x0003C8F4
	private void #=z1jlGMrg=()
	{
		try
		{
			string text = string.Empty;
			try
			{
				text = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWHJEiAyx8u5z((HttpWebRequest)WebRequest.Create(GameApplicationData.#=zva6GhSFJKRlfSleOJA==()));
			}
			catch (Exception #=zN_s5Z5A=)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064636) + text, #=zN_s5Z5A=);
			}
			if (text.Length < 10000)
			{
				try
				{
					HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(#=zcsIgna2XJlarOA7v4qCXrywzRrfs.#=z9d79e5_LBtjxlNqMiw==());
					httpWebRequest.Headers[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064583)] = GameApplicationData.#=zva6GhSFJKRlfSleOJA==();
					text = #=zc4_wZHcaYTeZm0T9TL4sfpLuY$$T.#=zWHJEiAyx8u5z(httpWebRequest);
				}
				catch (Exception #=zN_s5Z5A=2)
				{
					#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064303) + text, #=zN_s5Z5A=2);
				}
			}
			try
			{
				string #=z0ONi4Bk= = string.Format(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064247), GameApplicationData.#=zIAr6v8hPlwD6n1k69g==());
				if (text.Length < 10000)
				{
					if (#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zTUmbCKI=(#=z0ONi4Bk=))
					{
						text = #=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=zE6GjVX8zbW5W(#=z0ONi4Bk=);
					}
				}
				else
				{
					#=zG1ljaUNG3MrT7vLQzyQE3QJS8EyQ.#=z49OzGHBofb6l(#=z0ONi4Bk=, text, null, false);
				}
			}
			catch (Exception #=zN_s5Z5A=3)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064213) + text.Length.ToString(), #=zN_s5Z5A=3);
			}
			object obj = null;
			try
			{
				text += #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064410);
				obj = JSONManager.GetData(text);
			}
			catch (Exception #=zN_s5Z5A=4)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064403) + text.Length.ToString() + #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064347) + JSONManager.Cut(text), #=zN_s5Z5A=4);
				return;
			}
			string[] array = new string[0];
			try
			{
				Dictionary<string, object> dictionary = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064330));
				string[] array2 = new string[]
				{
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909064323),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066084),
					#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066046)
				};
				string text2 = GameApplicationData.#=z6VBUQl_Cv5ltgUHRwg==();
				array = new string[array2.Length];
				for (int i = 0; i < array2.Length; i++)
				{
					string text3 = array2[i];
					if (!string.IsNullOrEmpty(text2))
					{
						array[i] = JSONManager.ExtractString(dictionary, text3 + text2, string.Empty);
					}
					if (string.IsNullOrEmpty(array[i]))
					{
						array[i] = JSONManager.ExtractString(dictionary, text3, string.Empty);
					}
				}
			}
			catch (Exception #=zN_s5Z5A=5)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066003), #=zN_s5Z5A=5);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066209)] = array;
			Dictionary<int, string> dictionary2 = new Dictionary<int, string>();
			try
			{
				foreach (Dictionary<string, object> dictionary3 in JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066199)))
				{
					dictionary2[JSONManager.ExtractInt(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0)] = JSONManager.GetString(dictionary3, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069932), null);
				}
			}
			catch (Exception #=zN_s5Z5A=6)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066176), #=zN_s5Z5A=6);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066122)] = dictionary2;
			#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2 #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE = new #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2();
			try
			{
				object[] array4 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065842));
				if (array4 != null)
				{
					for (int k = 0; k < array4.Length; k++)
					{
						#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE.Add(new #=z6NLmXMAz_pWKErj5yl9EIn5bRF3dKzUWtZL8i3I=((Dictionary<string, object>)array4[k]));
					}
				}
			}
			catch (Exception #=zN_s5Z5A=7)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065838), #=zN_s5Z5A=7);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065776)] = #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE;
			#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== = new #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==();
			#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== = new #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==();
			UnitTypeCollection unitTypeCollection = new UnitTypeCollection();
			#=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== = new #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==();
			#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F = new #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95();
			#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== = new #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==();
			Dictionary<int, Dictionary<string, object>> dictionary4 = new Dictionary<int, Dictionary<string, object>>();
			Dictionary<int, AbstractType> dictionary5 = new Dictionary<int, AbstractType>();
			try
			{
				foreach (Dictionary<string, object> dictionary6 in JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065752)))
				{
					Entities entities = Entities.Unknown;
					if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065750)))
					{
						entities = Entities.Building;
					}
					else if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065743)) || dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065732)))
					{
						entities = Entities.Technology;
					}
					else if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065981)))
					{
						entities = Entities.Unit;
					}
					else if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070020)))
					{
						entities = Entities.ArtifactItem;
					}
					else if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909060580)))
					{
						entities = Entities.WarlordInventoryItem;
					}
					else if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909059742)))
					{
						entities = Entities.GemItem;
					}
					switch (entities)
					{
					case Entities.Building:
					{
						#=zZ4TczVhhqPd03VvEaufX1hUlE1pF #=zZ4TczVhhqPd03VvEaufX1hUlE1pF = new #=zZ4TczVhhqPd03VvEaufX1hUlE1pF(dictionary6);
						#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==.Add(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF);
						dictionary5.Add(#=zZ4TczVhhqPd03VvEaufX1hUlE1pF.Id, #=zZ4TczVhhqPd03VvEaufX1hUlE1pF);
						break;
					}
					case Entities.Technology:
						if (dictionary6.ContainsKey(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065732)))
						{
							dictionary4.Add(Convert.ToInt32(dictionary6[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253)]), (Dictionary<string, object>)dictionary6[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065732)]);
						}
						else
						{
							#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== = new #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==(dictionary6);
							#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Add(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
							dictionary5.Add(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==.Id, #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==);
						}
						break;
					case Entities.Unit:
					{
						UnitType unitType = new UnitType(dictionary6);
						unitTypeCollection.Add(unitType);
						dictionary5.Add(unitType.Id, unitType);
						break;
					}
					case Entities.ArtifactItem:
					{
						#=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q item = new #=zgh63Y6$ph9NsT0uCek8QoNOKeo7Q(dictionary6);
						#=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==.Add(item);
						break;
					}
					case Entities.WarlordInventoryItem:
					{
						#=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck= #=zsbwXxuA= = new #=zYyZF3pxTCpy9TmSsKYtEHYabH4WFddvmZtGsDck=(dictionary6);
						#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F.#=z48rEd0A=(#=zsbwXxuA=);
						break;
					}
					case Entities.GemItem:
					{
						#=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg== item2 = new #=zEnAsgYPAsZOKJC2Q1W_gEqpqKB_DQwyvAg==(dictionary6, unitTypeCollection);
						#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==.Add(item2);
						break;
					}
					}
				}
				for (int m = 0; m < #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==.Count; m++)
				{
					#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA== #=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2 = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==[m];
					if (dictionary4.ContainsKey(#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.#=ziV0Qa4zwZEC4()))
					{
						#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.#=zceLS5g8CKZ6t(dictionary4[#=zBEQJSjRPNfQl2ybMvC3aiTQuMQbIysU6cA==2.#=ziV0Qa4zwZEC4()]);
					}
				}
				unitTypeCollection.FillUpgradeLevelsInfo(JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065962)));
				foreach (AbstractType abstractType in dictionary5.Values)
				{
					if (abstractType is #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==)
					{
						using (List<#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==>.Enumerator enumerator2 = (abstractType as #=zIMkY3iqDm5gOzm8KfJPbHLgio0UxMRfz1A==).#=z2fOvUeiaHzR6().GetEnumerator())
						{
							while (enumerator2.MoveNext())
							{
								#=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ== = enumerator2.Current;
								foreach (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== in #=zMUn42PhFrjPSad1_vm5s14OAkRxWrb2LkQ==.#=z6Uo9D2yKen_Y())
								{
									if (dictionary5.ContainsKey(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zFMDiymuLQ7_4()))
									{
										#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zzQwUIEs=(dictionary5[#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==.#=zFMDiymuLQ7_4()]);
									}
								}
							}
							goto IL_6C8;
						}
						goto IL_665;
					}
					goto IL_665;
					IL_6C8:
					foreach (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2 in abstractType.#=zdL$RcwsYpqvy())
					{
						if (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2.#=zFMDiymuLQ7_4() > 0 && #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2.#=zq2bPTdY=() == null && dictionary5.ContainsKey(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2.#=zFMDiymuLQ7_4()))
						{
							#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2.#=zzQwUIEs=(dictionary5[#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==2.#=zFMDiymuLQ7_4()]);
						}
					}
					if (!(abstractType is UnitType))
					{
						continue;
					}
					List<#=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ==> list = (abstractType as UnitType).#=zyChIvWGhg7eo();
					if (list != null)
					{
						foreach (#=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ== #=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ== in list)
						{
							foreach (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==3 in #=zBVq9mNQNUNorZOHjB1NRI9PBuNvm8EeBAQ==.#=z6Uo9D2yKen_Y())
							{
								if (dictionary5.ContainsKey(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==3.#=zFMDiymuLQ7_4()))
								{
									#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==3.#=zzQwUIEs=(dictionary5[#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==3.#=zFMDiymuLQ7_4()]);
								}
							}
						}
						continue;
					}
					continue;
					IL_665:
					if (abstractType is AbstractNotupgradeableType)
					{
						foreach (#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw== #=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==4 in (abstractType as AbstractNotupgradeableType).#=zdL$RcwsYpqvy())
						{
							if (dictionary5.ContainsKey(#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==4.#=zFMDiymuLQ7_4()))
							{
								#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==4.#=zzQwUIEs=(dictionary5[#=z2QeBIaAxW94IrvwUfpyzPrV4eureXtdyJw==4.#=zFMDiymuLQ7_4()]);
							}
						}
						goto IL_6C8;
					}
					goto IL_6C8;
				}
				UnitType.#=zivZdFs93KxJE(unitTypeCollection, #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==);
			}
			catch (Exception #=zN_s5Z5A=8)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065953), #=zN_s5Z5A=8);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065883)] = #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==;
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065871)] = #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==;
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065599)] = unitTypeCollection;
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065583)] = #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==;
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065555)] = #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F;
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065528)] = #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==;
			Dictionary<string, object> dictionary7 = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065515));
			if (dictionary7 != null)
			{
				#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== = new #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==();
				#=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw== #=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw== = null;
				try
				{
					Dictionary<string, object> dictionary8 = JSONManager.ExtractDictionary(dictionary7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
					Dictionary<string, object> #=z$P12ZiX0waGODqRr2IYFD6Y= = JSONManager.ExtractDictionary(dictionary7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070245));
					if (dictionary8 != null)
					{
						#=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw== = new #=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw==(dictionary8, #=z$P12ZiX0waGODqRr2IYFD6Y=);
					}
				}
				catch (Exception #=zN_s5Z5A=9)
				{
					#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065505), #=zN_s5Z5A=9);
				}
				try
				{
					Dictionary<string, object> dictionary9 = JSONManager.ExtractDictionary(dictionary7, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909071045));
					if (dictionary9 != null)
					{
						foreach (object obj2 in dictionary9.Values)
						{
							Dictionary<string, object> dictionary10 = (Dictionary<string, object>)obj2;
							int num = JSONManager.ExtractInt(dictionary10, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909077958), 0);
							#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG item3 = new #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG(num, JSONManager.GetString(dictionary10, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065718), null), JSONManager.GetInt(dictionary10, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065698), 0) == 1, JSONManager.ExtractArray(dictionary10, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069102)).Length, #=z2neEHCqEkW$0KUCU269IR_Qj7YuHW4$ziw==[num]);
							#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Add(item3);
						}
						#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==.Sort(new Comparison<#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG>(#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zyDNvciU=.#=zLkw0NRU=.#=zrbR2EkNuIm8pZv2ZRg==));
					}
				}
				catch (Exception #=zN_s5Z5A=10)
				{
					#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065505), #=zN_s5Z5A=10);
				}
				this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065694)] = #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==;
			}
			Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=> dictionary11 = new Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=>();
			try
			{
				object[] array6 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065677));
				if (array6 != null)
				{
					object[] array7 = array6;
					int n = 0;
					while (n < array7.Length)
					{
						Dictionary<string, object> dictionary12 = (Dictionary<string, object>)array7[n];
						int key = JSONManager.ExtractInt(dictionary12, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
						#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= value;
						switch (JSONManager.ExtractInt(dictionary12, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), -1))
						{
						case 0:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Attack;
							goto IL_AAA;
						case 1:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.Defense;
							goto IL_AAA;
						case 2:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackFuture;
							goto IL_AAA;
						case 3:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseFuture;
							goto IL_AAA;
						case 4:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseStronghold;
							goto IL_AAA;
						case 5:
							value = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackStronghold;
							goto IL_AAA;
						}
						IL_AB5:
						n++;
						continue;
						IL_AAA:
						dictionary11[key] = value;
						goto IL_AB5;
					}
					foreach (Dictionary<string, object> dictionary13 in JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065656)))
					{
						int num2 = JSONManager.ExtractInt(dictionary13, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
						object[] array8 = JSONManager.ExtractArray(dictionary13, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069899));
						int num3 = 0;
						while (num3 < array8.Length)
						{
							Dictionary<string, object> dictionary14 = (Dictionary<string, object>)array8[num3];
							int key2 = JSONManager.ExtractInt(dictionary14, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
							int num4 = JSONManager.ExtractInt(dictionary14, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909069883), -1);
							#=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs= value2;
							switch (num2)
							{
							case 1:
								if (num4 == 0)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackStory;
									goto IL_BBE;
								}
								if (num4 == 1)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseStory;
									goto IL_BBE;
								}
								break;
							case 4:
								if (num4 == 2)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackFutureStory;
									goto IL_BBE;
								}
								if (num4 == 3)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseFutureStory;
									goto IL_BBE;
								}
								break;
							case 5:
								if (num4 == 0)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackVeoraStory;
									goto IL_BBE;
								}
								if (num4 == 1)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseVeoraStory;
									goto IL_BBE;
								}
								break;
							case 6:
								if (num4 == 0)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.AttackTeam;
									goto IL_BBE;
								}
								if (num4 == 1)
								{
									value2 = #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=.DefenseTeam;
									goto IL_BBE;
								}
								break;
							}
							IL_BC9:
							num3++;
							continue;
							IL_BBE:
							dictionary11[key2] = value2;
							goto IL_BC9;
						}
					}
				}
			}
			catch (Exception #=zN_s5Z5A=11)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065654), #=zN_s5Z5A=11);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065604)] = dictionary11;
			Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> dictionary15 = new Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU>();
			try
			{
				object[] array9 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065320));
				if (array9 != null)
				{
					foreach (Dictionary<string, object> dictionary16 in array9)
					{
						int num6 = JSONManager.ExtractInt(dictionary16, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909070253), 0);
						dictionary15.Add(num6, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU.#=zcBW$PBE=(num6, dictionary16));
					}
				}
			}
			catch (Exception #=zN_s5Z5A=12)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065319), #=zN_s5Z5A=12);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065251)] = dictionary15;
			#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== = new #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==();
			try
			{
				object[] array10 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065229));
				if (array10 != null)
				{
					for (int num7 = 0; num7 < array10.Length; num7++)
					{
						#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==.Add(new #=z8fY4LM2jY1ivx8vOGLRQRSZn7fBZQodQDQ==((Dictionary<string, object>)array10[num7], #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zLvzZ1qlq9S5r()));
					}
				}
			}
			catch (Exception #=zN_s5Z5A=13)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065464), #=zN_s5Z5A=13);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065418)] = #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==;
			#=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ== value3 = null;
			try
			{
				Dictionary<string, object> dictionary17 = JSONManager.GetDictionary(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065402));
				if (dictionary17 != null)
				{
					value3 = new #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ==(dictionary17);
				}
			}
			catch (Exception #=zN_s5Z5A=14)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065393), #=zN_s5Z5A=14);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050745)] = value3;
			try
			{
				this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050727)] = JSONManager.GetInt(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050692), 0);
			}
			catch (Exception #=zN_s5Z5A=15)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050676), #=zN_s5Z5A=15);
			}
			Dictionary<int, string> dictionary18 = new Dictionary<int, string>();
			try
			{
				for (int num8 = 1; num8 <= 3; num8++)
				{
					string value4 = JSONManager.GetString(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050871) + num8.ToString(), null);
					if (string.IsNullOrEmpty(value4))
					{
						value4 = num8.ToString();
					}
					dictionary18.Add(num8, value4);
				}
			}
			catch (Exception #=zN_s5Z5A=16)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050676), #=zN_s5Z5A=16);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050838)] = dictionary18;
			#=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F = new #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F();
			try
			{
				object[] array11 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050812));
				#=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F.#=z20ohAjI=(array11, dictionary15, unitTypeCollection);
			}
			catch (Exception #=zN_s5Z5A=17)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050792), #=zN_s5Z5A=17);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050483)] = #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F;
			#=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= = new #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0=();
			try
			{
				object[] array12 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050456));
				#=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0=.#=z20ohAjI=(array12);
			}
			catch (Exception #=zN_s5Z5A=18)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050455), #=zN_s5Z5A=18);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050396)] = #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0=;
			#=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ = new #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$();
			try
			{
				object[] array13 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050619));
				#=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$.#=z20ohAjI=(array13, unitTypeCollection);
			}
			catch (Exception #=zN_s5Z5A=19)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050615), #=zN_s5Z5A=19);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050564)] = #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$;
			#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB = new #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5();
			try
			{
				object[] array14 = JSONManager.GetArray(obj, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050539));
				#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB.#=z20ohAjI=(array14);
			}
			catch (Exception #=zN_s5Z5A=20)
			{
				#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050534), #=zN_s5Z5A=20);
			}
			this.#=z9HdGFQI=[#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073380)] = #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB;
		}
		catch (Exception #=zN_s5Z5A=21)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zeMkkg8o=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050218), #=zN_s5Z5A=21);
		}
	}

	// Token: 0x060007C9 RID: 1993 RVA: 0x0003F950 File Offset: 0x0003DB50
	private static void #=zeMkkg8o=(string #=z0$tDJkI=, Exception #=zN_s5Z5A=)
	{
		#=zX1MiJczxPMCN9tCBUgectCHF$DQ2 #=zX1MiJczxPMCN9tCBUgectCHF$DQ = #=zX1MiJczxPMCN9tCBUgectCHF$DQ2.#=zKVN4CRU=();
		if (#=zX1MiJczxPMCN9tCBUgectCHF$DQ != null)
		{
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zLyaSD5E=(null, #=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050191), new object[]
			{
				#=z0$tDJkI=
			});
			#=zX1MiJczxPMCN9tCBUgectCHF$DQ.#=zknIUyoRVNcX2().#=zbbu$0jU=(null, #=zN_s5Z5A=);
		}
	}

	// Token: 0x060007CA RID: 1994 RVA: 0x0003F994 File Offset: 0x0003DB94
	private static object #=zi1hFJwI=(string #=zNraCe1Y=)
	{
		Dictionary<string, object> dictionary = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zKVN4CRU=().#=z9HdGFQI=;
		if (dictionary.ContainsKey(#=zNraCe1Y=))
		{
			return dictionary[#=zNraCe1Y=];
		}
		return null;
	}

	// Token: 0x060007CB RID: 1995 RVA: 0x0003F9C0 File Offset: 0x0003DBC0
	public static string[] #=zSol3JEv6Ohaf()
	{
		return (string[])#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066209));
	}

	// Token: 0x060007CC RID: 1996 RVA: 0x0003F9D8 File Offset: 0x0003DBD8
	public static #=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw== #=zW89SjO80IPkN()
	{
		return (#=zOqgb2TIe_Sm4miSci3a8uY8e0BfY_348vw==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065883));
	}

	// Token: 0x060007CD RID: 1997 RVA: 0x0003F9F0 File Offset: 0x0003DBF0
	public static #=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g== #=zqA7twkhFkuaUTrO8bg==()
	{
		return (#=zzLBD9Rm3f77VymWutsfX$6yjVEjYqB0p7g==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065871));
	}

	// Token: 0x060007CE RID: 1998 RVA: 0x0003FA08 File Offset: 0x0003DC08
	public static UnitTypeCollection #=zLvzZ1qlq9S5r()
	{
		return (UnitTypeCollection)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065599));
	}

	// Token: 0x060007CF RID: 1999 RVA: 0x0003FA20 File Offset: 0x0003DC20
	public static Dictionary<int, string> #=zVaSbJ9QgCetWbEk6RflqOR6esC81()
	{
		return (Dictionary<int, string>)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909066122));
	}

	// Token: 0x060007D0 RID: 2000 RVA: 0x0003FA38 File Offset: 0x0003DC38
	public static #=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw== #=zmHNyaeH1VqT_()
	{
		return (#=zD1pig7mVP$3oTJWhIaeZNqx4fvVRDWnuGw==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065694));
	}

	// Token: 0x060007D1 RID: 2001 RVA: 0x0003FA50 File Offset: 0x0003DC50
	public static Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=> #=zTWc1gtYKnjc_()
	{
		return (Dictionary<int, #=zUG_jF4MFrn8TZZ1SxiYcgVieyXZV.#=zArez$Gs=>)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065604));
	}

	// Token: 0x060007D2 RID: 2002 RVA: 0x0003FA68 File Offset: 0x0003DC68
	public static Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU> #=zkUUmwSA23UXVOIFutxPsL6ZrnvCf()
	{
		return (Dictionary<int, #=zhz3wGp1CT46NNitr1ntQ5pID6TD1NfYDIaDNiK5L73tU>)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065251));
	}

	// Token: 0x060007D3 RID: 2003 RVA: 0x0003FA80 File Offset: 0x0003DC80
	public static #=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A== #=zpwV01Fffu0h0tuAXRw==()
	{
		return (#=z_bAeyBsPiTEc0TWsTxy7CjyqoCpTR1if6A==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065418));
	}

	// Token: 0x060007D4 RID: 2004 RVA: 0x0003FA98 File Offset: 0x0003DC98
	public static #=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw== #=zDtK93_iTmZU7()
	{
		return (#=zx9xq1OsyNUHq3No85uvZFzzHXN6PffF3qw==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065583));
	}

	// Token: 0x060007D5 RID: 2005 RVA: 0x0003FAB0 File Offset: 0x0003DCB0
	public static #=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2 #=z5S_PFONatVzCtl6PBhYGu60=()
	{
		return (#=zrDcgv9ny10MzDWIXXLpHLu9oG87ShdV8ckh2cf3Z1wE2)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065776));
	}

	// Token: 0x060007D6 RID: 2006 RVA: 0x0003FAC8 File Offset: 0x0003DCC8
	public static #=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95 #=zvw0rWruSYIHsC4FAUwsBgMo=()
	{
		return (#=zYUCE8CFv0N_IAXfZJKOA_QPzPyAOWff4onGe4XXz1F95)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065555));
	}

	// Token: 0x060007D7 RID: 2007 RVA: 0x0003FAE0 File Offset: 0x0003DCE0
	public static #=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg== #=zPeypy81OWeno()
	{
		return (#=z_OTFAIftCTAaaMYnEs8Jkiza9Aqe1aAatg==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909065528));
	}

	// Token: 0x060007D8 RID: 2008 RVA: 0x0003FAF8 File Offset: 0x0003DCF8
	public static #=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ== #=zZsVcPWNCb1EbXEj_RqOp1M1R0ASC()
	{
		return (#=zzWeTAQ8YOGmIy5bFonwiSNQ9stIVh5yaPVEAW1qOVJMz1c0nUQ==)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050745));
	}

	// Token: 0x060007D9 RID: 2009 RVA: 0x0003FB10 File Offset: 0x0003DD10
	public static int #=zqNyrB2FzTjiIQP_Ize9NK318odoy()
	{
		return (int)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050727));
	}

	// Token: 0x060007DA RID: 2010 RVA: 0x0003FB28 File Offset: 0x0003DD28
	public static Dictionary<int, string> #=zLhrZP_oyOsqr()
	{
		return (Dictionary<int, string>)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050838));
	}

	// Token: 0x060007DB RID: 2011 RVA: 0x0003FB40 File Offset: 0x0003DD40
	public static #=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F #=zlphWys2OxuAyR77Tzy3p9xnFjRT5L46_HQ==()
	{
		return (#=ziPpIiFuPEn$SIQnZFvw2i2VNbt2tykcQBc$YwTFZ8r5F)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050483));
	}

	// Token: 0x060007DC RID: 2012 RVA: 0x0003FB58 File Offset: 0x0003DD58
	public static #=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0= #=zRNMbzapw7YG$2TckgCczwJRgHdTL$EF1cA==()
	{
		return (#=z$m$Uu1pd5SVieI0Nod_ANUGvmd6GoLtvPAF58$HGd5sIoXbkQr7SZK0=)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050396));
	}

	// Token: 0x060007DD RID: 2013 RVA: 0x0003FB70 File Offset: 0x0003DD70
	public static #=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$ #=zvyC00Y_9es8lCV0e9ILz5yw=()
	{
		return (#=zGknJuILumdwfq$wgbzkGR3JZjJhWtldHd3pePmCcOG8$)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909050564));
	}

	// Token: 0x060007DE RID: 2014 RVA: 0x0003FB88 File Offset: 0x0003DD88
	public static #=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5 #=zvQRf_STy5v8Sm5tuw7Xh278usASc()
	{
		return (#=z8fY4LM2jY1ivx8vOGLRQRSSGSkUzSeplwFmY4T3DSGB5)#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909073380));
	}

	// Token: 0x060007DF RID: 2015 RVA: 0x0003FBA0 File Offset: 0x0003DDA0
	public static object #=zp2obHa8=(string #=zNraCe1Y=)
	{
		return #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zi1hFJwI=(#=zNraCe1Y=);
	}

	// Token: 0x060007E0 RID: 2016 RVA: 0x0003FBA8 File Offset: 0x0003DDA8
	public static void #=zOlAKdDM=(string #=zNraCe1Y=, object #=z$Ib9gYQ=)
	{
		#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g== #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g== = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zKVN4CRU=();
		object obj = #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zSV4$mlFB34WM;
		lock (obj)
		{
			#=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=z9HdGFQI=[#=zNraCe1Y=] = #=z$Ib9gYQ=;
		}
	}

	// Token: 0x0400048D RID: 1165
	private static object #=zSV4$mlFB34WM = new object();

	// Token: 0x0400048E RID: 1166
	private static #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g== #=zOAzeRO$HqsMN = null;

	// Token: 0x0400048F RID: 1167
	private Dictionary<string, object> #=z9HdGFQI=;

	// Token: 0x02000134 RID: 308
	[Serializable]
	private sealed class #=zyDNvciU=
	{
		// Token: 0x060007E3 RID: 2019 RVA: 0x0003FC08 File Offset: 0x0003DE08
		internal int #=zrbR2EkNuIm8pZv2ZRg==(#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zQrqFdos=, #=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG #=zKFlJyLE=)
		{
			return #=zQrqFdos=.Id.CompareTo(#=zKFlJyLE=.Id);
		}

		// Token: 0x04000490 RID: 1168
		public static readonly #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zyDNvciU= #=zLkw0NRU= = new #=zKBqrCzXwcwDw_Akl8UpizB8ucNBKSVXB7g==.#=zyDNvciU=();

		// Token: 0x04000491 RID: 1169
		public static Comparison<#=zrmbZDjrTq6p29zJ0Kr8SmOWfCxkG> #=zMOsJR8bvCgQXhudXEw==;
	}
}
