﻿// Token: 0x020000D2 RID: 210
internal sealed partial class #=zCRVeVlCVj9mcO22J9_mc2RduCJRnINvoHg== : global::System.Windows.Forms.Form
{
	// Token: 0x060005A8 RID: 1448 RVA: 0x0002F03C File Offset: 0x0002D23C
	protected override void Dispose(bool #=zC01kOXg=)
	{
		if (#=zC01kOXg= && this.#=zRWEHIqY= != null)
		{
			this.#=zRWEHIqY=.Dispose();
		}
		base.Dispose(#=zC01kOXg=);
	}

	// Token: 0x0400024D RID: 589
	private global::System.ComponentModel.IContainer #=zRWEHIqY=;
}
