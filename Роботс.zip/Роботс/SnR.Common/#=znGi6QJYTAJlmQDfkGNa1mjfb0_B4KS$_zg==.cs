﻿using System;
using common;
using NExcel.Biff;
using NExcel.Read.Biff;

// Token: 0x02000291 RID: 657
internal sealed class #=znGi6QJYTAJlmQDfkGNa1mjfb0_B4KS$_zg== : RecordData
{
	// Token: 0x0600140E RID: 5134 RVA: 0x00099B64 File Offset: 0x00097D64
	public #=znGi6QJYTAJlmQDfkGNa1mjfb0_B4KS$_zg==(Record #=zJce$Sys=) : base(#=zJce$Sys=)
	{
		sbyte[] data = #=zJce$Sys=.Data;
		this.#=z2ar9PkA= = IntegerHelper.getInt(data[0], data[1]);
	}

	// Token: 0x06001410 RID: 5136 RVA: 0x00099BA8 File Offset: 0x00097DA8
	public int #=zGFlbdYbgR9_R()
	{
		return this.#=z2ar9PkA=;
	}

	// Token: 0x04000B85 RID: 2949
	private static Logger #=zJLdzGuI= = Logger.getLogger(typeof(#=znGi6QJYTAJlmQDfkGNa1mjfb0_B4KS$_zg==));

	// Token: 0x04000B86 RID: 2950
	private int #=z2ar9PkA=;
}
