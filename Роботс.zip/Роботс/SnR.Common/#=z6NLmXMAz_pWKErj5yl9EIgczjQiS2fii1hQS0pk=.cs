﻿using System;
using System.Collections.Generic;

// Token: 0x0200007A RID: 122
internal sealed class #=z6NLmXMAz_pWKErj5yl9EIgczjQiS2fii1hQS0pk=
{
	// Token: 0x0600036A RID: 874 RVA: 0x0001F734 File Offset: 0x0001D934
	public int #=zMuFMjGQ=()
	{
		return this.#=zdw4aIlzRxu5LWjlGFw==;
	}

	// Token: 0x0600036B RID: 875 RVA: 0x0001F73C File Offset: 0x0001D93C
	public void #=zbsxKkj4=(int #=z$Ib9gYQ=)
	{
		this.#=zdw4aIlzRxu5LWjlGFw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600036C RID: 876 RVA: 0x0001F748 File Offset: 0x0001D948
	public int #=zv4c9O3M=()
	{
		return this.#=zoBAWdDnfuR848vLacw==;
	}

	// Token: 0x0600036D RID: 877 RVA: 0x0001F750 File Offset: 0x0001D950
	public void #=zIHYXCI8=(int #=z$Ib9gYQ=)
	{
		this.#=zoBAWdDnfuR848vLacw== = #=z$Ib9gYQ=;
	}

	// Token: 0x0600036E RID: 878 RVA: 0x0001F75C File Offset: 0x0001D95C
	public List<int> #=zmEXh9AenN64_bRhjgQ==()
	{
		return this.#=zfSJMPAH$$cK2khnWJT_pgNTpA8Sf;
	}

	// Token: 0x0600036F RID: 879 RVA: 0x0001F764 File Offset: 0x0001D964
	public void #=zEay$jMoC7T_kh1L51A==(List<int> #=z$Ib9gYQ=)
	{
		this.#=zfSJMPAH$$cK2khnWJT_pgNTpA8Sf = #=z$Ib9gYQ=;
	}

	// Token: 0x06000370 RID: 880 RVA: 0x0001F770 File Offset: 0x0001D970
	public DateTime #=ziPEmQdbHj7fJ()
	{
		return this.#=zlib8nVfvSAE2rXZHdQ==;
	}

	// Token: 0x06000371 RID: 881 RVA: 0x0001F778 File Offset: 0x0001D978
	public void #=zmlRGa1CBJDmM(DateTime #=z$Ib9gYQ=)
	{
		this.#=zlib8nVfvSAE2rXZHdQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x06000372 RID: 882 RVA: 0x0001F784 File Offset: 0x0001D984
	public DateTime #=zOPOUMr79bBnqNvgahw==()
	{
		return this.#=z2_K_a$dZfeY0kVQt1DXvbqs=;
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0001F78C File Offset: 0x0001D98C
	public void #=ztwk8eMODHmxTjLHNTw==(DateTime #=z$Ib9gYQ=)
	{
		this.#=z2_K_a$dZfeY0kVQt1DXvbqs= = #=z$Ib9gYQ=;
	}

	// Token: 0x04000131 RID: 305
	private int #=zdw4aIlzRxu5LWjlGFw==;

	// Token: 0x04000132 RID: 306
	private int #=zoBAWdDnfuR848vLacw==;

	// Token: 0x04000133 RID: 307
	private List<int> #=zfSJMPAH$$cK2khnWJT_pgNTpA8Sf;

	// Token: 0x04000134 RID: 308
	private DateTime #=zlib8nVfvSAE2rXZHdQ==;

	// Token: 0x04000135 RID: 309
	private DateTime #=z2_K_a$dZfeY0kVQt1DXvbqs=;
}
