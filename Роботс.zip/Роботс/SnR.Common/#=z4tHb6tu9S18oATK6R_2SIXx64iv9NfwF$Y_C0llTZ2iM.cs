﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Global;

// Token: 0x0200006C RID: 108
internal sealed class #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM<#=zQSoxQMk=> : List<List<#=zQSoxQMk=>> where #=zQSoxQMk= : IIntID
{
	// Token: 0x06000319 RID: 793 RVA: 0x0001D604 File Offset: 0x0001B804
	public #=z4tHb6tu9S18oATK6R_2SIXx64iv9NfwF$Y_C0llTZ2iM(IComparer<#=zQSoxQMk=> #=z6_x9K_4=)
	{
		this.#=zREV6vEU= = #=z6_x9K_4=;
	}

	// Token: 0x0600031A RID: 794 RVA: 0x0001D614 File Offset: 0x0001B814
	public void #=z48rEd0A=(#=zQSoxQMk= #=zsbwXxuA=)
	{
		for (int i = 0; i < base.Count; i++)
		{
			List<#=zQSoxQMk=> list = base[i];
			if (list.Count == 0)
			{
				throw new Exception(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909051026));
			}
			int num = this.#=zREV6vEU=.Compare(#=zsbwXxuA=, list[0]);
			if (num < 0)
			{
				base.Insert(i, new List<#=zQSoxQMk=>
				{
					#=zsbwXxuA=
				});
				return;
			}
			if (num == 0)
			{
				list.Add(#=zsbwXxuA=);
				return;
			}
		}
		base.Add(new List<#=zQSoxQMk=>
		{
			#=zsbwXxuA=
		});
	}

	// Token: 0x0400011C RID: 284
	private IComparer<#=zQSoxQMk=> #=zREV6vEU=;
}
