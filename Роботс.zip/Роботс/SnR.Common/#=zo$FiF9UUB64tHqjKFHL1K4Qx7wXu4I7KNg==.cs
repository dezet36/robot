﻿using System;
using System.Windows.Forms;

// Token: 0x02000297 RID: 663
internal sealed class #=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==
{
	// Token: 0x06001431 RID: 5169 RVA: 0x0009A8E8 File Offset: 0x00098AE8
	public static DialogResult #=zdVW_C6o=(string #=zdBD5ZXA=)
	{
		return MessageBox.Show(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zdBD5ZXA=));
	}

	// Token: 0x06001432 RID: 5170 RVA: 0x0009A8F8 File Offset: 0x00098AF8
	public static DialogResult #=zdVW_C6o=(#=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=)
	{
		return MessageBox.Show(#=zdBD5ZXA=.ToString());
	}

	// Token: 0x06001433 RID: 5171 RVA: 0x0009A908 File Offset: 0x00098B08
	public static DialogResult #=zELdlHynwcS2l(string #=zdBD5ZXA=, object[] #=z3Bl1L6JXREI4)
	{
		return MessageBox.Show(#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zJHLHKso=(#=zdBD5ZXA=, #=z3Bl1L6JXREI4));
	}

	// Token: 0x06001434 RID: 5172 RVA: 0x0009A918 File Offset: 0x00098B18
	public static DialogResult #=zdVW_C6o=(string #=zFfGc8ng=, MessageBoxButtons #=zvM2sY5g=, string #=zdBD5ZXA=, object[] #=z3Bl1L6JXREI4)
	{
		return MessageBox.Show(#=zo$FiF9UUB64tHqjKFHL1K4Qx7wXu4I7KNg==.#=zJHLHKso=(#=zdBD5ZXA=, #=z3Bl1L6JXREI4), #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zFfGc8ng=), #=zvM2sY5g=);
	}

	// Token: 0x06001435 RID: 5173 RVA: 0x0009A930 File Offset: 0x00098B30
	public static DialogResult #=zdVW_C6o=(string #=zFfGc8ng=, MessageBoxButtons #=zvM2sY5g=, #=z39dE3lXvTdHnYzx$25AZ_qa14py90smvAMl2u6_JBOX1i8PI3A== #=zdBD5ZXA=)
	{
		return MessageBox.Show(#=zdBD5ZXA=.ToString(), #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zFfGc8ng=), #=zvM2sY5g=);
	}

	// Token: 0x06001436 RID: 5174 RVA: 0x0009A944 File Offset: 0x00098B44
	private static string #=zJHLHKso=(string #=zdBD5ZXA=, object[] #=z3Bl1L6JXREI4)
	{
		if (#=z3Bl1L6JXREI4.Length != 0)
		{
			return string.Format(#=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zdBD5ZXA=), #=z3Bl1L6JXREI4);
		}
		return #=zuM9BpkRix4ZupUG0ajGicPAvpVKa68Oneg==.#=zaaGryas=(#=zdBD5ZXA=);
	}
}
