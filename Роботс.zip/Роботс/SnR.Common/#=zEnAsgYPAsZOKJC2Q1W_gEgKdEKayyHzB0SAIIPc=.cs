﻿using System;
using System.Collections.Generic;

// Token: 0x020000EB RID: 235
internal sealed class #=zEnAsgYPAsZOKJC2Q1W_gEgKdEKayyHzB0SAIIPc= : List<#=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg==>
{
	// Token: 0x06000625 RID: 1573 RVA: 0x00031CFC File Offset: 0x0002FEFC
	public #=zbuggWLrMgXT_zSlJ9reJF7HJzXXIikKimg== #=zk$6QZNA=(int #=zAk8mKBk=)
	{
		for (int i = base.Count - 1; i >= 0; i--)
		{
			if (base[i].#=zq2bPTdY=().Id == #=zAk8mKBk=)
			{
				return base[i];
			}
		}
		return null;
	}
}
