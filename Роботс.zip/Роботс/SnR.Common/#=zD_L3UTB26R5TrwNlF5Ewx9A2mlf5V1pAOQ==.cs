﻿using System;
using System.Collections.Generic;
using Skink.SnR.Common.Managers;

// Token: 0x020000E0 RID: 224
internal class #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==
{
	// Token: 0x060005FA RID: 1530 RVA: 0x000310A8 File Offset: 0x0002F2A8
	public #=zD_L3UTB26R5TrwNlF5Ewx9A2mlf5V1pAOQ==(DateTime #=z9iiP2tA=, bool #=zwKNSAUQ=, int #=zo0v9afoi7vJW)
	{
		this.#=zIR9Xlcg=(#=z9iiP2tA=);
		this.#=zQjib6hnU4pL$(#=zwKNSAUQ=);
		this.#=z_OFZgd7OR2kC(#=zo0v9afoi7vJW);
	}

	// Token: 0x060005FB RID: 1531 RVA: 0x000310C8 File Offset: 0x0002F2C8
	public DateTime #=zPHMvvJ8=()
	{
		return this.#=zJDEdzIaDvHbnYM06$w==;
	}

	// Token: 0x060005FC RID: 1532 RVA: 0x000310D0 File Offset: 0x0002F2D0
	public void #=zIR9Xlcg=(DateTime #=z$Ib9gYQ=)
	{
		this.#=zJDEdzIaDvHbnYM06$w== = #=z$Ib9gYQ=;
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x000310DC File Offset: 0x0002F2DC
	public bool #=zpZQhzm3O9fac()
	{
		return this.#=zXbmK4sX7hPY8RyrYJQ==;
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x000310E4 File Offset: 0x0002F2E4
	public void #=zQjib6hnU4pL$(bool #=z$Ib9gYQ=)
	{
		this.#=zXbmK4sX7hPY8RyrYJQ== = #=z$Ib9gYQ=;
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x000310F0 File Offset: 0x0002F2F0
	public int #=znqRcj_cT3li8()
	{
		return this.#=z7qAlOBgqNJvQHEdH1IT8iQI=;
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x000310F8 File Offset: 0x0002F2F8
	public void #=z_OFZgd7OR2kC(int #=z$Ib9gYQ=)
	{
		this.#=z7qAlOBgqNJvQHEdH1IT8iQI= = #=z$Ib9gYQ=;
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x00031104 File Offset: 0x0002F304
	public Dictionary<string, object> #=zhv7OhlM=()
	{
		return new Dictionary<string, object>
		{
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909078463),
				this.#=zPHMvvJ8=().ToString(#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049969))
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049951),
				this.#=znqRcj_cT3li8() + 1
			},
			{
				#=qF06LM8Lcppb_UV_3RDUo1DL1Mwv5x$hcxWTlaIdsxZU=.#=ze04twNQ=(909049941),
				(this.#=zpZQhzm3O9fac() > false) ? 1 : 0
			}
		};
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x0003117C File Offset: 0x0002F37C
	public override string ToString()
	{
		return JSONManager.SerializeData(this.#=zhv7OhlM=());
	}

	// Token: 0x04000279 RID: 633
	private DateTime #=zJDEdzIaDvHbnYM06$w==;

	// Token: 0x0400027A RID: 634
	private bool #=zXbmK4sX7hPY8RyrYJQ==;

	// Token: 0x0400027B RID: 635
	private int #=z7qAlOBgqNJvQHEdH1IT8iQI=;
}
